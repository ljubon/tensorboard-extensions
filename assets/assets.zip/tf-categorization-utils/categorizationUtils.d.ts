declare namespace tf_categorization_utils {
    /**
     * Functions to extract categories of tags and/or run-tag combinations
     * from a run-to-tag mapping. The resulting categories can be fed to a
     * `tf-category-pane`, and their items can be `<dom-repeat>`ed in a
     * Polymer component.
     */
    type RunToTag = {
        [run: string]: string[];
    };
    enum CategoryType {
        SEARCH_RESULTS = 0,
        PREFIX_GROUP = 1
    }
    interface PrefixGroupMetadata {
        type: CategoryType;
    }
    interface SearchResultsMetadata {
        type: CategoryType;
        compositeSearch?: boolean;
        validRegex: boolean;
        universalRegex: boolean;
    }
    type CategoryMetadata = PrefixGroupMetadata | SearchResultsMetadata;
    interface Category<T> {
        name: string;
        metadata: CategoryMetadata;
        items: T[];
    }
    type TagCategory = Category<{
        tag: string;
        runs: string[];
    }>;
    type RunTagCategory = Category<{
        tag: string;
        run: string;
    }>;
    type Series = {
        experiment: tf_backend.Experiment;
        run: string;
        tag: string;
    };
    /**
     * Organize data by tagPrefix, tag, then list of series which is comprised of
     * an experiment and a run.
     */
    type SeriesCategory = Category<{
        tag: string;
        series: Series[];
    }>;
    type RawCategory = Category<string>;
    /**
     * Compute a category containing the search results for the given query.
     */
    function categorizeBySearchQuery(xs: string[], query: string): RawCategory;
    /**
     * Compute the quotient set $X/{\sim}$, where $a \sim b$ if $a$ and $b$
     * share a common `separator`-prefix. Order is preserved.
     */
    function categorizeByPrefix(xs: string[], separator?: string): RawCategory[];
    function categorize(xs: string[], query?: string): RawCategory[];
    function categorizeTags(runToTag: RunToTag, selectedRuns: string[], query?: string): TagCategory[];
    /**
     * Creates grouping of the data based on selection from tf-data-selector. It
     * groups data by prefixes of tag names and by tag names. Each group contains
     * series, a tuple of experiment name and run name.
     */
    function categorizeSelection(selection: tf_data_selector.Selection[], pluginName: string): SeriesCategory[];
    function categorizeRunTagCombinations(runToTag: RunToTag, selectedRuns: string[], query?: string): RunTagCategory[];
}
