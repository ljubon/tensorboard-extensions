/* Copyright 2015 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
var vz_bar_chart;
(function (vz_bar_chart) {
    Polymer({
        is: 'vz-bar-chart',
        properties: {
            /**
             * How to feed data to the bar chart.
             *
             * Each key within the `data` object corresponds to a data series,
             * each of which is associated with its own color of bars.
             *
             * Each entry within a list corresponds to an X-axis label (the string
             * 'x' property) and bar height (The numeric 'y' property).
             *
             * Example:
             * data = {'series0':[{ x: 'a', y: 1 }, { x: 'c', y: 3 }, { x: 'b', y: 2 }],
             *        'series1':[{ x: 'a', y: 4 }, { x: 'g', y: 3 }, { x: 'e', y: 5 }]}
             *
             * This will generate a Plottable ClusteredBar chart with two series and
             * 5 distinct classes ('a', 'b', 'c', 'g', 'e').
             */
            data: Object,
            /**
             * Scale that maps series names to colors. The default colors are from
             * d3.schemeCategory10. Use this property to replace the default coloration.
             *
             * Note that if a `colorScale` gets passed in, it gets mutated within this
             * component to have its domain set to the sorted keys of the `data` object.
             * e.g. .domain(['series0', 'series1'])
             * @type {Plottable.Scales.Color}
             */
            colorScale: {
                type: Object,
                value: function () {
                    return new Plottable.Scales.Color().range(d3.schemeCategory10);
                }
            },
            /**
             * How to format the tooltip.
             *
             * There should be a formatting object for each desired column.
             * Each formatting object gets applied to the datum bound to the closest
             * clustered bar.
             */
            tooltipColumns: {
                type: Array,
                value: function () {
                    return [
                        {
                            title: 'Name',
                            evaluate: function (d) {
                                return d.key;
                            },
                        },
                        {
                            title: 'X',
                            evaluate: function (d) {
                                return d.value.x;
                            },
                        },
                        {
                            title: 'Y',
                            evaluate: function (d) {
                                return d.value.y;
                            },
                        },
                    ];
                }
            },
            _attached: Boolean,
            _chart: Object,
        },
        observers: [
            '_makeChart(data, colorScale, tooltipColumns, _attached)',
        ],
        /**
         * Re-renders the chart. Useful if e.g. the container size changed.
         */
        redraw: function () {
            if (this._chart) {
                this._chart.redraw();
            }
        },
        attached: function () {
            this._attached = true;
        },
        detached: function () {
            this._attached = false;
        },
        ready: function () {
            // This is needed so Polymer can apply the CSS styles to elements we
            // created with d3.
            this.scopeSubtree(this.$.tooltip, true);
            this.scopeSubtree(this.$.chartdiv, true);
        },
        /**
         * Creates a chart, and asynchronously renders it. Fires a chart-rendered
         * event after the chart is rendered.
         */
        _makeChart: function (data, colorScale, tooltipColumns, _attached) {
            if (this._chart)
                this._chart.destroy();
            var tooltip = d3.select(this.$.tooltip);
            // We directly reference properties of `this` because this call is
            // asynchronous, and values may have changed in between the call being
            // initiated and actually being run.
            var chart = new BarChart(this.data, this.colorScale, tooltip, this.tooltipColumns);
            var div = d3.select(this.$.chartdiv);
            chart.renderTo(div);
            this._chart = chart;
        },
    });
    var BarChart = /** @class */ (function () {
        function BarChart(data, colorScale, tooltip, tooltipColumns) {
            // Assign each class a color.
            colorScale.domain(_.sortBy(_.keys(data)));
            // Assign arguments passed in constructor for future use.
            this.data = data;
            this.colorScale = colorScale;
            this.tooltip = tooltip;
            this.plot = null;
            this.outer = null;
            // Do things to actually build the chart.
            this.buildChart(data, colorScale);
            this.setupTooltips(tooltipColumns);
        }
        BarChart.prototype.buildChart = function (data, colorScale) {
            if (this.outer) {
                this.outer.destroy();
            }
            var xScale = new Plottable.Scales.Category();
            var yScale = new Plottable.Scales.Linear();
            var xAxis = new Plottable.Axes.Category(xScale, 'bottom');
            var yAxis = new Plottable.Axes.Numeric(yScale, 'left');
            var plot = new Plottable.Plots.ClusteredBar();
            plot.x(function (d) {
                return d.x;
            }, xScale);
            plot.y(function (d) {
                return d.y;
            }, yScale);
            var seriesNames = _.keys(data);
            seriesNames.forEach(function (seriesName) { return plot.addDataset(new Plottable.Dataset(data[seriesName]).metadata(seriesName)); });
            plot.attr('fill', function (d, i, dataset) {
                return colorScale.scale(dataset.metadata());
            });
            this.plot = plot;
            this.outer = new Plottable.Components.Table([[yAxis, plot], [null, xAxis]]);
        };
        BarChart.prototype.setupTooltips = function (tooltipColumns) {
            var _this = this;
            // Set up tooltip column headers.
            var tooltipHeaderRow = this.tooltip.select('thead tr');
            tooltipHeaderRow
                .selectAll('th')
                .data(tooltipColumns)
                .enter()
                .append('th')
                .text(function (d) { return d.title; });
            // Prepend empty header cell for the data series colored circle icon.
            tooltipHeaderRow.insert('th', ':first-child');
            var plot = this.plot;
            var pointer = new Plottable.Interactions.Pointer();
            pointer.attachTo(plot);
            var hideTooltips = function () {
                _this.tooltip.style('opacity', 0);
            };
            pointer.onPointerMove(function (p) {
                var target = plot.entityNearest(p);
                if (target) {
                    _this.drawTooltips(target, tooltipColumns);
                }
            });
            pointer.onPointerExit(hideTooltips);
        };
        BarChart.prototype.drawTooltips = function (target, tooltipColumns) {
            var hoveredClass = target.datum.x;
            var hoveredSeries = target.dataset.metadata();
            // The data is formatted in the way described on the  main element.
            // e.g. {'series0': [{ x: 'a', y: 1 }, { x: 'c', y: 3 },
            //       'series1': [{ x: 'a', y: 4 }, { x: 'g', y: 3 }, { x: 'e', y: 5 }]}
            // Filter down the data so each value contains 0 or 1 elements in the array,
            // which correspond to the value of the closest clustered bar (e.g. 'c').
            // This generates {series0: Array(1), series1: Array(0)}.
            var bars = _.mapValues(this.data, function (allValuesForSeries) {
                return _.filter(allValuesForSeries, function (elt) { return elt.x == hoveredClass; });
            });
            // Remove the keys that map to an empty array, and unpack the array.
            // This generates {series0: { x: 'c', y: 3 }}
            bars = _.pickBy(bars, function (val) { return val.length > 0; });
            var singleBars = _.mapValues(bars, function (val) { return val[0]; });
            // Rearrange the object for convenience.
            // This yields: [{key: 'series0', value: { x: 'c', y: 3 }}, ]
            var barEntries = d3.entries(singleBars);
            // Bind the bars data structure to the tooltip.
            var rows = this.tooltip.select('tbody')
                .html('')
                .selectAll('tr')
                .data(barEntries)
                .enter()
                .append('tr');
            rows.style('white-space', 'nowrap');
            rows.classed('closest', function (d) { return d.key == hoveredSeries; });
            var colorScale = this.colorScale;
            rows.append('td')
                .append('div')
                .classed('swatch', true)
                .style('background-color', function (d) { return colorScale.scale(d.key); });
            _.each(tooltipColumns, function (column) {
                rows.append('td').text(function (d) {
                    // Convince TypeScript to let us pass off a key-value entry of value
                    // type Bar as a Point since that's what TooltipColumn.evaluate wants.
                    // TODO(nickfelt): reconcile the incompatible typing here
                    var barEntryAsPoint = d;
                    return column.evaluate(barEntryAsPoint);
                });
            });
            var left = target.position.x;
            var top = target.position.y;
            this.tooltip.style('transform', 'translate(' + left + 'px,' + top + 'px)');
            this.tooltip.style('opacity', 1);
        };
        BarChart.prototype.renderTo = function (targetSVG) {
            // TODO(chihuahua): Figure out why we store targetSVG as a property.
            this.targetSVG = targetSVG;
            this.outer.renderTo(targetSVG);
        };
        BarChart.prototype.redraw = function () {
            this.outer.redraw();
        };
        BarChart.prototype.destroy = function () {
            this.outer.destroy();
        };
        return BarChart;
    }());
})(vz_bar_chart || (vz_bar_chart = {})); // namespace vz_bar_chart
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidnotYmFyLWNoYXJ0LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsidnotYmFyLWNoYXJ0LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7Ozs7Ozs7Ozs7O2dGQWFnRjtBQUNoRixJQUFVLFlBQVksQ0FrU3JCO0FBbFNELFdBQVUsWUFBWTtJQWF0QixPQUFPLENBQUM7UUFDTixFQUFFLEVBQUUsY0FBYztRQUNsQixVQUFVLEVBQUU7WUFDVjs7Ozs7Ozs7Ozs7Ozs7O2VBZUc7WUFDSCxJQUFJLEVBQUUsTUFBTTtZQUVaOzs7Ozs7OztlQVFHO1lBQ0gsVUFBVSxFQUFFO2dCQUNWLElBQUksRUFBRSxNQUFNO2dCQUNaLEtBQUssRUFBRTtvQkFDTCxPQUFPLElBQUksU0FBUyxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLGdCQUFnQixDQUFDLENBQUM7Z0JBQ2pFLENBQUM7YUFDRjtZQUVEOzs7Ozs7ZUFNRztZQUNILGNBQWMsRUFBRTtnQkFDZCxJQUFJLEVBQUUsS0FBSztnQkFDWCxLQUFLLEVBQUU7b0JBQ0wsT0FBTzt3QkFDTDs0QkFDRSxLQUFLLEVBQUUsTUFBTTs0QkFDYixRQUFRLEVBQUUsVUFBUyxDQUFDO2dDQUNsQixPQUFPLENBQUMsQ0FBQyxHQUFHLENBQUM7NEJBQ2YsQ0FBQzt5QkFDRjt3QkFDRDs0QkFDRSxLQUFLLEVBQUUsR0FBRzs0QkFDVixRQUFRLEVBQUUsVUFBUyxDQUFDO2dDQUNsQixPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDOzRCQUNuQixDQUFDO3lCQUNGO3dCQUNEOzRCQUNFLEtBQUssRUFBRSxHQUFHOzRCQUNWLFFBQVEsRUFBRSxVQUFTLENBQUM7Z0NBQ2xCLE9BQU8sQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7NEJBQ25CLENBQUM7eUJBQ0Y7cUJBQ0YsQ0FBQztnQkFDSixDQUFDO2FBQ0Y7WUFDRCxTQUFTLEVBQUUsT0FBTztZQUNsQixNQUFNLEVBQUUsTUFBTTtTQUNmO1FBQ0QsU0FBUyxFQUFFO1lBQ1QseURBQXlEO1NBQzFEO1FBQ0Q7O1dBRUc7UUFDSCxNQUFNLEVBQUU7WUFDTixJQUFJLElBQUksQ0FBQyxNQUFNLEVBQUU7Z0JBQ2YsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsQ0FBQzthQUN0QjtRQUNILENBQUM7UUFDRCxRQUFRLEVBQUU7WUFDUixJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQztRQUN4QixDQUFDO1FBQ0QsUUFBUSxFQUFFO1lBQ1IsSUFBSSxDQUFDLFNBQVMsR0FBRyxLQUFLLENBQUM7UUFDekIsQ0FBQztRQUNELEtBQUssRUFBRTtZQUNMLG9FQUFvRTtZQUNwRSxtQkFBbUI7WUFDbkIsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsQ0FBQztZQUN4QyxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQzNDLENBQUM7UUFDRDs7O1dBR0c7UUFDSCxVQUFVLEVBQUUsVUFBUyxJQUFJLEVBQUUsVUFBVSxFQUFFLGNBQWMsRUFBRSxTQUFTO1lBQzlELElBQUksSUFBSSxDQUFDLE1BQU07Z0JBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUUsQ0FBQztZQUN2QyxJQUFJLE9BQU8sR0FBRyxFQUFFLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7WUFDeEMsa0VBQWtFO1lBQ2xFLHNFQUFzRTtZQUN0RSxvQ0FBb0M7WUFDcEMsSUFBSSxLQUFLLEdBQ0wsSUFBSSxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsVUFBVSxFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUM7WUFDM0UsSUFBSSxHQUFHLEdBQUcsRUFBRSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQ3JDLEtBQUssQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDcEIsSUFBSSxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUM7UUFDdEIsQ0FBQztLQUNGLENBQUMsQ0FBQztJQUVIO1FBUUUsa0JBQ0ksSUFBOEIsRUFDOUIsVUFBa0MsRUFDbEMsT0FBeUMsRUFDekMsY0FBZ0Q7WUFDbEQsNkJBQTZCO1lBQzdCLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUUxQyx5REFBeUQ7WUFDekQsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUM7WUFDakIsSUFBSSxDQUFDLFVBQVUsR0FBRyxVQUFVLENBQUM7WUFDN0IsSUFBSSxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUM7WUFFdkIsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUM7WUFDakIsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUM7WUFFbEIseUNBQXlDO1lBQ3pDLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxFQUFFLFVBQVUsQ0FBQyxDQUFDO1lBQ2xDLElBQUksQ0FBQyxhQUFhLENBQUMsY0FBYyxDQUFDLENBQUM7UUFDckMsQ0FBQztRQUVPLDZCQUFVLEdBQWxCLFVBQ0ksSUFBOEIsRUFDOUIsVUFBa0M7WUFDcEMsSUFBSSxJQUFJLENBQUMsS0FBSyxFQUFFO2dCQUNkLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxFQUFFLENBQUM7YUFDdEI7WUFFRCxJQUFNLE1BQU0sR0FBRyxJQUFJLFNBQVMsQ0FBQyxNQUFNLENBQUMsUUFBUSxFQUFFLENBQUM7WUFDL0MsSUFBTSxNQUFNLEdBQUcsSUFBSSxTQUFTLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxDQUFDO1lBRTdDLElBQU0sS0FBSyxHQUFHLElBQUksU0FBUyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxFQUFFLFFBQVEsQ0FBQyxDQUFDO1lBQzVELElBQU0sS0FBSyxHQUFHLElBQUksU0FBUyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFLE1BQU0sQ0FBQyxDQUFDO1lBRXpELElBQU0sSUFBSSxHQUFHLElBQUksU0FBUyxDQUFDLEtBQUssQ0FBQyxZQUFZLEVBQWtCLENBQUM7WUFDaEUsSUFBSSxDQUFDLENBQUMsQ0FBQyxVQUFTLENBQUM7Z0JBQ2YsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ2IsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDO1lBQ1gsSUFBSSxDQUFDLENBQUMsQ0FBQyxVQUFTLENBQUM7Z0JBQ2YsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ2IsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDO1lBRVgsSUFBTSxXQUFXLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUNqQyxXQUFXLENBQUMsT0FBTyxDQUNmLFVBQUEsVUFBVSxJQUFJLE9BQUEsSUFBSSxDQUFDLFVBQVUsQ0FDekIsSUFBSSxTQUFTLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsQ0FBQyxFQURuRCxDQUNtRCxDQUFDLENBQUM7WUFDdkUsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsVUFBUyxDQUFDLEVBQUUsQ0FBQyxFQUFFLE9BQU87Z0JBQ3RDLE9BQU8sVUFBVSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQztZQUM5QyxDQUFDLENBQUMsQ0FBQztZQUVILElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDO1lBQ2pCLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxTQUFTLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FDdkMsQ0FBQyxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsRUFBRSxDQUFDLElBQUksRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDdEMsQ0FBQztRQUVPLGdDQUFhLEdBQXJCLFVBQXNCLGNBQWdEO1lBQXRFLGlCQTBCQztZQXpCQyxpQ0FBaUM7WUFDakMsSUFBTSxnQkFBZ0IsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsQ0FBQztZQUN6RCxnQkFBZ0I7aUJBQ1gsU0FBUyxDQUFDLElBQUksQ0FBQztpQkFDZixJQUFJLENBQUMsY0FBYyxDQUFDO2lCQUNwQixLQUFLLEVBQUU7aUJBQ1AsTUFBTSxDQUFDLElBQUksQ0FBQztpQkFDWixJQUFJLENBQUMsVUFBQSxDQUFDLElBQUksT0FBQSxDQUFDLENBQUMsS0FBSyxFQUFQLENBQU8sQ0FBQyxDQUFDO1lBQ3hCLHFFQUFxRTtZQUNyRSxnQkFBZ0IsQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFLGNBQWMsQ0FBQyxDQUFDO1lBRTlDLElBQU0sSUFBSSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUM7WUFDdkIsSUFBTSxPQUFPLEdBQUcsSUFBSSxTQUFTLENBQUMsWUFBWSxDQUFDLE9BQU8sRUFBRSxDQUFDO1lBQ3JELE9BQU8sQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUM7WUFFdkIsSUFBSSxZQUFZLEdBQUc7Z0JBQ2pCLEtBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUMsQ0FBQztZQUNuQyxDQUFDLENBQUM7WUFDRixPQUFPLENBQUMsYUFBYSxDQUFDLFVBQUMsQ0FBQztnQkFDdEIsSUFBTSxNQUFNLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDckMsSUFBSSxNQUFNLEVBQUU7b0JBQ1YsS0FBSSxDQUFDLFlBQVksQ0FBQyxNQUFNLEVBQUUsY0FBYyxDQUFDLENBQUM7aUJBQzNDO1lBQ0gsQ0FBQyxDQUFDLENBQUM7WUFDSCxPQUFPLENBQUMsYUFBYSxDQUFDLFlBQVksQ0FBQyxDQUFDO1FBQ3RDLENBQUM7UUFFTywrQkFBWSxHQUFwQixVQUNJLE1BQW1DLEVBQ25DLGNBQWdEO1lBQ2xELElBQU0sWUFBWSxHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO1lBQ3BDLElBQU0sYUFBYSxHQUFHLE1BQU0sQ0FBQyxPQUFPLENBQUMsUUFBUSxFQUFFLENBQUM7WUFFaEQsbUVBQW1FO1lBQ25FLHdEQUF3RDtZQUN4RCwyRUFBMkU7WUFFM0UsNEVBQTRFO1lBQzVFLHlFQUF5RTtZQUN6RSx5REFBeUQ7WUFDekQsSUFBSSxJQUFJLEdBQUcsQ0FBQyxDQUFDLFNBQVMsQ0FDbEIsSUFBSSxDQUFDLElBQUksRUFDVCxVQUFBLGtCQUFrQjtnQkFDZCxPQUFBLENBQUMsQ0FBQyxNQUFNLENBQUMsa0JBQWtCLEVBQUUsVUFBQSxHQUFHLElBQUksT0FBQSxHQUFHLENBQUMsQ0FBQyxJQUFJLFlBQVksRUFBckIsQ0FBcUIsQ0FBQztZQUExRCxDQUEwRCxDQUFDLENBQUM7WUFFcEUsb0VBQW9FO1lBQ3BFLDZDQUE2QztZQUM3QyxJQUFJLEdBQUksQ0FBUyxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsVUFBQSxHQUFHLElBQUksT0FBQSxHQUFHLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBZCxDQUFjLENBQUMsQ0FBQztZQUN0RCxJQUFNLFVBQVUsR0FBRyxDQUFDLENBQUMsU0FBUyxDQUFDLElBQUksRUFBRSxVQUFBLEdBQUcsSUFBSSxPQUFBLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBTixDQUFNLENBQUMsQ0FBQztZQUVwRCx3Q0FBd0M7WUFDeEMsNkRBQTZEO1lBQzdELElBQU0sVUFBVSxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7WUFFMUMsK0NBQStDO1lBQy9DLElBQU0sSUFBSSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQztpQkFDekIsSUFBSSxDQUFDLEVBQUUsQ0FBQztpQkFDUixTQUFTLENBQUMsSUFBSSxDQUFDO2lCQUNmLElBQUksQ0FBQyxVQUFVLENBQUM7aUJBQ2hCLEtBQUssRUFBRTtpQkFDUCxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUM7WUFFN0IsSUFBSSxDQUFDLEtBQUssQ0FBQyxhQUFhLEVBQUUsUUFBUSxDQUFDLENBQUM7WUFDcEMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTLEVBQUUsVUFBQSxDQUFDLElBQUksT0FBQSxDQUFDLENBQUMsR0FBRyxJQUFJLGFBQWEsRUFBdEIsQ0FBc0IsQ0FBQyxDQUFBO1lBQ3BELElBQU0sVUFBVSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUM7WUFDbkMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUM7aUJBQ1osTUFBTSxDQUFDLEtBQUssQ0FBQztpQkFDYixPQUFPLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQztpQkFDdkIsS0FBSyxDQUFDLGtCQUFrQixFQUFFLFVBQUEsQ0FBQyxJQUFJLE9BQUEsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQXZCLENBQXVCLENBQUMsQ0FBQztZQUM3RCxDQUFDLENBQUMsSUFBSSxDQUFDLGNBQWMsRUFBRSxVQUFDLE1BQU07Z0JBQzVCLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQUMsQ0FBQztvQkFDdkIsb0VBQW9FO29CQUNwRSxzRUFBc0U7b0JBQ3RFLHlEQUF5RDtvQkFDekQsSUFBTSxlQUFlLEdBQUcsQ0FBa0MsQ0FBQztvQkFDM0QsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUFDLGVBQWUsQ0FBQyxDQUFDO2dCQUMxQyxDQUFDLENBQUMsQ0FBQztZQUNMLENBQUMsQ0FBQyxDQUFDO1lBRUgsSUFBTSxJQUFJLEdBQUcsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7WUFDL0IsSUFBTSxHQUFHLEdBQUcsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7WUFDOUIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsV0FBVyxFQUFFLFlBQVksR0FBRyxJQUFJLEdBQUcsS0FBSyxHQUFHLEdBQUcsR0FBRyxLQUFLLENBQUMsQ0FBQztZQUMzRSxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFDbkMsQ0FBQztRQUVNLDJCQUFRLEdBQWYsVUFBZ0IsU0FBMkM7WUFDekQsb0VBQW9FO1lBQ3BFLElBQUksQ0FBQyxTQUFTLEdBQUcsU0FBUyxDQUFDO1lBQzNCLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQ2pDLENBQUM7UUFFTSx5QkFBTSxHQUFiO1lBQ0UsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUN0QixDQUFDO1FBRU0sMEJBQU8sR0FBZDtZQUNFLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxFQUFFLENBQUM7UUFDdkIsQ0FBQztRQUNILGVBQUM7SUFBRCxDQUFDLEFBbEtELElBa0tDO0FBRUQsQ0FBQyxFQWxTUyxZQUFZLEtBQVosWUFBWSxRQWtTckIsQ0FBQyx5QkFBeUIiLCJzb3VyY2VzQ29udGVudCI6WyIvKiBDb3B5cmlnaHQgMjAxNSBUaGUgVGVuc29yRmxvdyBBdXRob3JzLiBBbGwgUmlnaHRzIFJlc2VydmVkLlxuXG5MaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UsIFZlcnNpb24gMi4wICh0aGUgXCJMaWNlbnNlXCIpO1xueW91IG1heSBub3QgdXNlIHRoaXMgZmlsZSBleGNlcHQgaW4gY29tcGxpYW5jZSB3aXRoIHRoZSBMaWNlbnNlLlxuWW91IG1heSBvYnRhaW4gYSBjb3B5IG9mIHRoZSBMaWNlbnNlIGF0XG5cbiAgICBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcblxuVW5sZXNzIHJlcXVpcmVkIGJ5IGFwcGxpY2FibGUgbGF3IG9yIGFncmVlZCB0byBpbiB3cml0aW5nLCBzb2Z0d2FyZVxuZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIExpY2Vuc2UgaXMgZGlzdHJpYnV0ZWQgb24gYW4gXCJBUyBJU1wiIEJBU0lTLFxuV0lUSE9VVCBXQVJSQU5USUVTIE9SIENPTkRJVElPTlMgT0YgQU5ZIEtJTkQsIGVpdGhlciBleHByZXNzIG9yIGltcGxpZWQuXG5TZWUgdGhlIExpY2Vuc2UgZm9yIHRoZSBzcGVjaWZpYyBsYW5ndWFnZSBnb3Zlcm5pbmcgcGVybWlzc2lvbnMgYW5kXG5saW1pdGF0aW9ucyB1bmRlciB0aGUgTGljZW5zZS5cbj09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSovXG5uYW1lc3BhY2UgdnpfYmFyX2NoYXJ0IHtcblxuLyoqXG4gKiBFbmNhcHN1bGF0ZXMgaW5mb3JtYXRpb24gZm9yIGEgc2luZ2xlIGJhciB0byByZW5kZXJlZCBvbnRvIHRoZSBjaGFydC5cbiAqL1xuZXhwb3J0IGludGVyZmFjZSBCYXIge1xuICAvLyBUaGUgbGFiZWwgb24gdGhlIFgtYXhpcyBmb3IgdGhpcyBiYXIuXG4gIHg6IHN0cmluZyxcblxuICAvLyBUaGUgaGVpZ2h0IG9mIHRoZSBiYXIuXG4gIHk6IG51bWJlcixcbn1cblxuUG9seW1lcih7XG4gIGlzOiAndnotYmFyLWNoYXJ0JyxcbiAgcHJvcGVydGllczoge1xuICAgIC8qKlxuICAgICAqIEhvdyB0byBmZWVkIGRhdGEgdG8gdGhlIGJhciBjaGFydC5cbiAgICAgKlxuICAgICAqIEVhY2gga2V5IHdpdGhpbiB0aGUgYGRhdGFgIG9iamVjdCBjb3JyZXNwb25kcyB0byBhIGRhdGEgc2VyaWVzLFxuICAgICAqIGVhY2ggb2Ygd2hpY2ggaXMgYXNzb2NpYXRlZCB3aXRoIGl0cyBvd24gY29sb3Igb2YgYmFycy5cbiAgICAgKlxuICAgICAqIEVhY2ggZW50cnkgd2l0aGluIGEgbGlzdCBjb3JyZXNwb25kcyB0byBhbiBYLWF4aXMgbGFiZWwgKHRoZSBzdHJpbmdcbiAgICAgKiAneCcgcHJvcGVydHkpIGFuZCBiYXIgaGVpZ2h0IChUaGUgbnVtZXJpYyAneScgcHJvcGVydHkpLlxuICAgICAqXG4gICAgICogRXhhbXBsZTpcbiAgICAgKiBkYXRhID0geydzZXJpZXMwJzpbeyB4OiAnYScsIHk6IDEgfSwgeyB4OiAnYycsIHk6IDMgfSwgeyB4OiAnYicsIHk6IDIgfV0sXG4gICAgICogICAgICAgICdzZXJpZXMxJzpbeyB4OiAnYScsIHk6IDQgfSwgeyB4OiAnZycsIHk6IDMgfSwgeyB4OiAnZScsIHk6IDUgfV19XG4gICAgICpcbiAgICAgKiBUaGlzIHdpbGwgZ2VuZXJhdGUgYSBQbG90dGFibGUgQ2x1c3RlcmVkQmFyIGNoYXJ0IHdpdGggdHdvIHNlcmllcyBhbmRcbiAgICAgKiA1IGRpc3RpbmN0IGNsYXNzZXMgKCdhJywgJ2InLCAnYycsICdnJywgJ2UnKS5cbiAgICAgKi9cbiAgICBkYXRhOiBPYmplY3QsXG5cbiAgICAvKipcbiAgICAgKiBTY2FsZSB0aGF0IG1hcHMgc2VyaWVzIG5hbWVzIHRvIGNvbG9ycy4gVGhlIGRlZmF1bHQgY29sb3JzIGFyZSBmcm9tXG4gICAgICogZDMuc2NoZW1lQ2F0ZWdvcnkxMC4gVXNlIHRoaXMgcHJvcGVydHkgdG8gcmVwbGFjZSB0aGUgZGVmYXVsdCBjb2xvcmF0aW9uLlxuICAgICAqXG4gICAgICogTm90ZSB0aGF0IGlmIGEgYGNvbG9yU2NhbGVgIGdldHMgcGFzc2VkIGluLCBpdCBnZXRzIG11dGF0ZWQgd2l0aGluIHRoaXNcbiAgICAgKiBjb21wb25lbnQgdG8gaGF2ZSBpdHMgZG9tYWluIHNldCB0byB0aGUgc29ydGVkIGtleXMgb2YgdGhlIGBkYXRhYCBvYmplY3QuXG4gICAgICogZS5nLiAuZG9tYWluKFsnc2VyaWVzMCcsICdzZXJpZXMxJ10pXG4gICAgICogQHR5cGUge1Bsb3R0YWJsZS5TY2FsZXMuQ29sb3J9XG4gICAgICovXG4gICAgY29sb3JTY2FsZToge1xuICAgICAgdHlwZTogT2JqZWN0LFxuICAgICAgdmFsdWU6IGZ1bmN0aW9uKCkge1xuICAgICAgICByZXR1cm4gbmV3IFBsb3R0YWJsZS5TY2FsZXMuQ29sb3IoKS5yYW5nZShkMy5zY2hlbWVDYXRlZ29yeTEwKTtcbiAgICAgIH1cbiAgICB9LFxuXG4gICAgLyoqXG4gICAgICogSG93IHRvIGZvcm1hdCB0aGUgdG9vbHRpcC5cbiAgICAgKlxuICAgICAqIFRoZXJlIHNob3VsZCBiZSBhIGZvcm1hdHRpbmcgb2JqZWN0IGZvciBlYWNoIGRlc2lyZWQgY29sdW1uLlxuICAgICAqIEVhY2ggZm9ybWF0dGluZyBvYmplY3QgZ2V0cyBhcHBsaWVkIHRvIHRoZSBkYXR1bSBib3VuZCB0byB0aGUgY2xvc2VzdFxuICAgICAqIGNsdXN0ZXJlZCBiYXIuXG4gICAgICovXG4gICAgdG9vbHRpcENvbHVtbnM6IHtcbiAgICAgIHR5cGU6IEFycmF5LFxuICAgICAgdmFsdWU6IGZ1bmN0aW9uKCkge1xuICAgICAgICByZXR1cm4gW1xuICAgICAgICAgIHtcbiAgICAgICAgICAgIHRpdGxlOiAnTmFtZScsXG4gICAgICAgICAgICBldmFsdWF0ZTogZnVuY3Rpb24oZCkge1xuICAgICAgICAgICAgICByZXR1cm4gZC5rZXk7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgdGl0bGU6ICdYJyxcbiAgICAgICAgICAgIGV2YWx1YXRlOiBmdW5jdGlvbihkKSB7XG4gICAgICAgICAgICAgIHJldHVybiBkLnZhbHVlLng7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgdGl0bGU6ICdZJyxcbiAgICAgICAgICAgIGV2YWx1YXRlOiBmdW5jdGlvbihkKSB7XG4gICAgICAgICAgICAgIHJldHVybiBkLnZhbHVlLnk7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgIF07XG4gICAgICB9XG4gICAgfSxcbiAgICBfYXR0YWNoZWQ6IEJvb2xlYW4sXG4gICAgX2NoYXJ0OiBPYmplY3QsXG4gIH0sXG4gIG9ic2VydmVyczogW1xuICAgICdfbWFrZUNoYXJ0KGRhdGEsIGNvbG9yU2NhbGUsIHRvb2x0aXBDb2x1bW5zLCBfYXR0YWNoZWQpJyxcbiAgXSxcbiAgLyoqXG4gICAqIFJlLXJlbmRlcnMgdGhlIGNoYXJ0LiBVc2VmdWwgaWYgZS5nLiB0aGUgY29udGFpbmVyIHNpemUgY2hhbmdlZC5cbiAgICovXG4gIHJlZHJhdzogZnVuY3Rpb24oKSB7XG4gICAgaWYgKHRoaXMuX2NoYXJ0KSB7XG4gICAgICB0aGlzLl9jaGFydC5yZWRyYXcoKTtcbiAgICB9XG4gIH0sXG4gIGF0dGFjaGVkOiBmdW5jdGlvbigpIHtcbiAgICB0aGlzLl9hdHRhY2hlZCA9IHRydWU7XG4gIH0sXG4gIGRldGFjaGVkOiBmdW5jdGlvbigpIHtcbiAgICB0aGlzLl9hdHRhY2hlZCA9IGZhbHNlO1xuICB9LFxuICByZWFkeTogZnVuY3Rpb24oKSB7XG4gICAgLy8gVGhpcyBpcyBuZWVkZWQgc28gUG9seW1lciBjYW4gYXBwbHkgdGhlIENTUyBzdHlsZXMgdG8gZWxlbWVudHMgd2VcbiAgICAvLyBjcmVhdGVkIHdpdGggZDMuXG4gICAgdGhpcy5zY29wZVN1YnRyZWUodGhpcy4kLnRvb2x0aXAsIHRydWUpO1xuICAgIHRoaXMuc2NvcGVTdWJ0cmVlKHRoaXMuJC5jaGFydGRpdiwgdHJ1ZSk7XG4gIH0sXG4gIC8qKlxuICAgKiBDcmVhdGVzIGEgY2hhcnQsIGFuZCBhc3luY2hyb25vdXNseSByZW5kZXJzIGl0LiBGaXJlcyBhIGNoYXJ0LXJlbmRlcmVkXG4gICAqIGV2ZW50IGFmdGVyIHRoZSBjaGFydCBpcyByZW5kZXJlZC5cbiAgICovXG4gIF9tYWtlQ2hhcnQ6IGZ1bmN0aW9uKGRhdGEsIGNvbG9yU2NhbGUsIHRvb2x0aXBDb2x1bW5zLCBfYXR0YWNoZWQpIHtcbiAgICBpZiAodGhpcy5fY2hhcnQpIHRoaXMuX2NoYXJ0LmRlc3Ryb3koKTtcbiAgICB2YXIgdG9vbHRpcCA9IGQzLnNlbGVjdCh0aGlzLiQudG9vbHRpcCk7XG4gICAgLy8gV2UgZGlyZWN0bHkgcmVmZXJlbmNlIHByb3BlcnRpZXMgb2YgYHRoaXNgIGJlY2F1c2UgdGhpcyBjYWxsIGlzXG4gICAgLy8gYXN5bmNocm9ub3VzLCBhbmQgdmFsdWVzIG1heSBoYXZlIGNoYW5nZWQgaW4gYmV0d2VlbiB0aGUgY2FsbCBiZWluZ1xuICAgIC8vIGluaXRpYXRlZCBhbmQgYWN0dWFsbHkgYmVpbmcgcnVuLlxuICAgIHZhciBjaGFydCA9XG4gICAgICAgIG5ldyBCYXJDaGFydCh0aGlzLmRhdGEsIHRoaXMuY29sb3JTY2FsZSwgdG9vbHRpcCwgdGhpcy50b29sdGlwQ29sdW1ucyk7XG4gICAgdmFyIGRpdiA9IGQzLnNlbGVjdCh0aGlzLiQuY2hhcnRkaXYpO1xuICAgIGNoYXJ0LnJlbmRlclRvKGRpdik7XG4gICAgdGhpcy5fY2hhcnQgPSBjaGFydDtcbiAgfSxcbn0pO1xuXG5jbGFzcyBCYXJDaGFydCB7XG4gIHByaXZhdGUgZGF0YToge1trZXk6IHN0cmluZ106IChCYXJbXSl9O1xuICBwcml2YXRlIGNvbG9yU2NhbGU6IFBsb3R0YWJsZS5TY2FsZXMuQ29sb3I7XG4gIHByaXZhdGUgdG9vbHRpcDogZDMuU2VsZWN0aW9uPGFueSwgYW55LCBhbnksIGFueT47XG4gIHByaXZhdGUgb3V0ZXI6IFBsb3R0YWJsZS5Db21wb25lbnRzLlRhYmxlO1xuICBwcml2YXRlIHBsb3Q6IFBsb3R0YWJsZS5QbG90cy5DbHVzdGVyZWRCYXI8c3RyaW5nLCBudW1iZXI+O1xuICBwcml2YXRlIHRhcmdldFNWRzogZDMuU2VsZWN0aW9uPGFueSwgYW55LCBhbnksIGFueT47XG5cbiAgY29uc3RydWN0b3IoXG4gICAgICBkYXRhOiB7W2tleTogc3RyaW5nXTogKEJhcltdKX0sXG4gICAgICBjb2xvclNjYWxlOiBQbG90dGFibGUuU2NhbGVzLkNvbG9yLFxuICAgICAgdG9vbHRpcDogZDMuU2VsZWN0aW9uPGFueSwgYW55LCBhbnksIGFueT4sXG4gICAgICB0b29sdGlwQ29sdW1uczogdnpfY2hhcnRfaGVscGVycy5Ub29sdGlwQ29sdW1uW10pIHtcbiAgICAvLyBBc3NpZ24gZWFjaCBjbGFzcyBhIGNvbG9yLlxuICAgIGNvbG9yU2NhbGUuZG9tYWluKF8uc29ydEJ5KF8ua2V5cyhkYXRhKSkpO1xuXG4gICAgLy8gQXNzaWduIGFyZ3VtZW50cyBwYXNzZWQgaW4gY29uc3RydWN0b3IgZm9yIGZ1dHVyZSB1c2UuXG4gICAgdGhpcy5kYXRhID0gZGF0YTtcbiAgICB0aGlzLmNvbG9yU2NhbGUgPSBjb2xvclNjYWxlO1xuICAgIHRoaXMudG9vbHRpcCA9IHRvb2x0aXA7XG5cbiAgICB0aGlzLnBsb3QgPSBudWxsO1xuICAgIHRoaXMub3V0ZXIgPSBudWxsO1xuXG4gICAgLy8gRG8gdGhpbmdzIHRvIGFjdHVhbGx5IGJ1aWxkIHRoZSBjaGFydC5cbiAgICB0aGlzLmJ1aWxkQ2hhcnQoZGF0YSwgY29sb3JTY2FsZSk7XG4gICAgdGhpcy5zZXR1cFRvb2x0aXBzKHRvb2x0aXBDb2x1bW5zKTtcbiAgfVxuXG4gIHByaXZhdGUgYnVpbGRDaGFydChcbiAgICAgIGRhdGE6IHtba2V5OiBzdHJpbmddOiAoQmFyW10pfSxcbiAgICAgIGNvbG9yU2NhbGU6IFBsb3R0YWJsZS5TY2FsZXMuQ29sb3IpIHtcbiAgICBpZiAodGhpcy5vdXRlcikge1xuICAgICAgdGhpcy5vdXRlci5kZXN0cm95KCk7XG4gICAgfVxuXG4gICAgY29uc3QgeFNjYWxlID0gbmV3IFBsb3R0YWJsZS5TY2FsZXMuQ2F0ZWdvcnkoKTtcbiAgICBjb25zdCB5U2NhbGUgPSBuZXcgUGxvdHRhYmxlLlNjYWxlcy5MaW5lYXIoKTtcblxuICAgIGNvbnN0IHhBeGlzID0gbmV3IFBsb3R0YWJsZS5BeGVzLkNhdGVnb3J5KHhTY2FsZSwgJ2JvdHRvbScpO1xuICAgIGNvbnN0IHlBeGlzID0gbmV3IFBsb3R0YWJsZS5BeGVzLk51bWVyaWMoeVNjYWxlLCAnbGVmdCcpO1xuXG4gICAgY29uc3QgcGxvdCA9IG5ldyBQbG90dGFibGUuUGxvdHMuQ2x1c3RlcmVkQmFyPHN0cmluZywgbnVtYmVyPigpO1xuICAgIHBsb3QueChmdW5jdGlvbihkKSB7XG4gICAgICByZXR1cm4gZC54O1xuICAgIH0sIHhTY2FsZSk7XG4gICAgcGxvdC55KGZ1bmN0aW9uKGQpIHtcbiAgICAgIHJldHVybiBkLnk7XG4gICAgfSwgeVNjYWxlKTtcblxuICAgIGNvbnN0IHNlcmllc05hbWVzID0gXy5rZXlzKGRhdGEpO1xuICAgIHNlcmllc05hbWVzLmZvckVhY2goXG4gICAgICAgIHNlcmllc05hbWUgPT4gcGxvdC5hZGREYXRhc2V0KFxuICAgICAgICAgICAgbmV3IFBsb3R0YWJsZS5EYXRhc2V0KGRhdGFbc2VyaWVzTmFtZV0pLm1ldGFkYXRhKHNlcmllc05hbWUpKSk7XG4gICAgcGxvdC5hdHRyKCdmaWxsJywgZnVuY3Rpb24oZCwgaSwgZGF0YXNldCkge1xuICAgICAgcmV0dXJuIGNvbG9yU2NhbGUuc2NhbGUoZGF0YXNldC5tZXRhZGF0YSgpKTtcbiAgICB9KTtcblxuICAgIHRoaXMucGxvdCA9IHBsb3Q7XG4gICAgdGhpcy5vdXRlciA9IG5ldyBQbG90dGFibGUuQ29tcG9uZW50cy5UYWJsZShcbiAgICAgICAgW1t5QXhpcywgcGxvdF0sIFtudWxsLCB4QXhpc11dKTtcbiAgfVxuXG4gIHByaXZhdGUgc2V0dXBUb29sdGlwcyh0b29sdGlwQ29sdW1uczogdnpfY2hhcnRfaGVscGVycy5Ub29sdGlwQ29sdW1uW10pIHtcbiAgICAvLyBTZXQgdXAgdG9vbHRpcCBjb2x1bW4gaGVhZGVycy5cbiAgICBjb25zdCB0b29sdGlwSGVhZGVyUm93ID0gdGhpcy50b29sdGlwLnNlbGVjdCgndGhlYWQgdHInKTtcbiAgICB0b29sdGlwSGVhZGVyUm93XG4gICAgICAgIC5zZWxlY3RBbGwoJ3RoJylcbiAgICAgICAgLmRhdGEodG9vbHRpcENvbHVtbnMpXG4gICAgICAgIC5lbnRlcigpXG4gICAgICAgIC5hcHBlbmQoJ3RoJylcbiAgICAgICAgLnRleHQoZCA9PiBkLnRpdGxlKTtcbiAgICAvLyBQcmVwZW5kIGVtcHR5IGhlYWRlciBjZWxsIGZvciB0aGUgZGF0YSBzZXJpZXMgY29sb3JlZCBjaXJjbGUgaWNvbi5cbiAgICB0b29sdGlwSGVhZGVyUm93Lmluc2VydCgndGgnLCAnOmZpcnN0LWNoaWxkJyk7XG5cbiAgICBjb25zdCBwbG90ID0gdGhpcy5wbG90O1xuICAgIGNvbnN0IHBvaW50ZXIgPSBuZXcgUGxvdHRhYmxlLkludGVyYWN0aW9ucy5Qb2ludGVyKCk7XG4gICAgcG9pbnRlci5hdHRhY2hUbyhwbG90KTtcblxuICAgIHZhciBoaWRlVG9vbHRpcHMgPSAoKSA9PiB7XG4gICAgICB0aGlzLnRvb2x0aXAuc3R5bGUoJ29wYWNpdHknLCAwKTtcbiAgICB9O1xuICAgIHBvaW50ZXIub25Qb2ludGVyTW92ZSgocCkgPT4ge1xuICAgICAgY29uc3QgdGFyZ2V0ID0gcGxvdC5lbnRpdHlOZWFyZXN0KHApO1xuICAgICAgaWYgKHRhcmdldCkge1xuICAgICAgICB0aGlzLmRyYXdUb29sdGlwcyh0YXJnZXQsIHRvb2x0aXBDb2x1bW5zKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgICBwb2ludGVyLm9uUG9pbnRlckV4aXQoaGlkZVRvb2x0aXBzKTtcbiAgfVxuXG4gIHByaXZhdGUgZHJhd1Rvb2x0aXBzKFxuICAgICAgdGFyZ2V0OiBQbG90dGFibGUuUGxvdHMuSVBsb3RFbnRpdHksXG4gICAgICB0b29sdGlwQ29sdW1uczogdnpfY2hhcnRfaGVscGVycy5Ub29sdGlwQ29sdW1uW10pIHtcbiAgICBjb25zdCBob3ZlcmVkQ2xhc3MgPSB0YXJnZXQuZGF0dW0ueDtcbiAgICBjb25zdCBob3ZlcmVkU2VyaWVzID0gdGFyZ2V0LmRhdGFzZXQubWV0YWRhdGEoKTtcblxuICAgIC8vIFRoZSBkYXRhIGlzIGZvcm1hdHRlZCBpbiB0aGUgd2F5IGRlc2NyaWJlZCBvbiB0aGUgIG1haW4gZWxlbWVudC5cbiAgICAvLyBlLmcuIHsnc2VyaWVzMCc6IFt7IHg6ICdhJywgeTogMSB9LCB7IHg6ICdjJywgeTogMyB9LFxuICAgIC8vICAgICAgICdzZXJpZXMxJzogW3sgeDogJ2EnLCB5OiA0IH0sIHsgeDogJ2cnLCB5OiAzIH0sIHsgeDogJ2UnLCB5OiA1IH1dfVxuXG4gICAgLy8gRmlsdGVyIGRvd24gdGhlIGRhdGEgc28gZWFjaCB2YWx1ZSBjb250YWlucyAwIG9yIDEgZWxlbWVudHMgaW4gdGhlIGFycmF5LFxuICAgIC8vIHdoaWNoIGNvcnJlc3BvbmQgdG8gdGhlIHZhbHVlIG9mIHRoZSBjbG9zZXN0IGNsdXN0ZXJlZCBiYXIgKGUuZy4gJ2MnKS5cbiAgICAvLyBUaGlzIGdlbmVyYXRlcyB7c2VyaWVzMDogQXJyYXkoMSksIHNlcmllczE6IEFycmF5KDApfS5cbiAgICBsZXQgYmFycyA9IF8ubWFwVmFsdWVzKFxuICAgICAgICB0aGlzLmRhdGEsXG4gICAgICAgIGFsbFZhbHVlc0ZvclNlcmllcyA9PlxuICAgICAgICAgICAgXy5maWx0ZXIoYWxsVmFsdWVzRm9yU2VyaWVzLCBlbHQgPT4gZWx0LnggPT0gaG92ZXJlZENsYXNzKSk7XG5cbiAgICAvLyBSZW1vdmUgdGhlIGtleXMgdGhhdCBtYXAgdG8gYW4gZW1wdHkgYXJyYXksIGFuZCB1bnBhY2sgdGhlIGFycmF5LlxuICAgIC8vIFRoaXMgZ2VuZXJhdGVzIHtzZXJpZXMwOiB7IHg6ICdjJywgeTogMyB9fVxuICAgIGJhcnMgPSAoXyBhcyBhbnkpLnBpY2tCeShiYXJzLCB2YWwgPT4gdmFsLmxlbmd0aCA+IDApO1xuICAgIGNvbnN0IHNpbmdsZUJhcnMgPSBfLm1hcFZhbHVlcyhiYXJzLCB2YWwgPT4gdmFsWzBdKTtcblxuICAgIC8vIFJlYXJyYW5nZSB0aGUgb2JqZWN0IGZvciBjb252ZW5pZW5jZS5cbiAgICAvLyBUaGlzIHlpZWxkczogW3trZXk6ICdzZXJpZXMwJywgdmFsdWU6IHsgeDogJ2MnLCB5OiAzIH19LCBdXG4gICAgY29uc3QgYmFyRW50cmllcyA9IGQzLmVudHJpZXMoc2luZ2xlQmFycyk7XG5cbiAgICAvLyBCaW5kIHRoZSBiYXJzIGRhdGEgc3RydWN0dXJlIHRvIHRoZSB0b29sdGlwLlxuICAgIGNvbnN0IHJvd3MgPSB0aGlzLnRvb2x0aXAuc2VsZWN0KCd0Ym9keScpXG4gICAgICAgICAgICAgICAgICAgLmh0bWwoJycpXG4gICAgICAgICAgICAgICAgICAgLnNlbGVjdEFsbCgndHInKVxuICAgICAgICAgICAgICAgICAgIC5kYXRhKGJhckVudHJpZXMpXG4gICAgICAgICAgICAgICAgICAgLmVudGVyKClcbiAgICAgICAgICAgICAgICAgICAuYXBwZW5kKCd0cicpO1xuXG4gICAgcm93cy5zdHlsZSgnd2hpdGUtc3BhY2UnLCAnbm93cmFwJyk7XG4gICAgcm93cy5jbGFzc2VkKCdjbG9zZXN0JywgZCA9PiBkLmtleSA9PSBob3ZlcmVkU2VyaWVzKVxuICAgIGNvbnN0IGNvbG9yU2NhbGUgPSB0aGlzLmNvbG9yU2NhbGU7XG4gICAgcm93cy5hcHBlbmQoJ3RkJylcbiAgICAgICAgLmFwcGVuZCgnZGl2JylcbiAgICAgICAgLmNsYXNzZWQoJ3N3YXRjaCcsIHRydWUpXG4gICAgICAgIC5zdHlsZSgnYmFja2dyb3VuZC1jb2xvcicsIGQgPT4gY29sb3JTY2FsZS5zY2FsZShkLmtleSkpO1xuICAgIF8uZWFjaCh0b29sdGlwQ29sdW1ucywgKGNvbHVtbikgPT4ge1xuICAgICAgcm93cy5hcHBlbmQoJ3RkJykudGV4dCgoZCkgPT4ge1xuICAgICAgICAvLyBDb252aW5jZSBUeXBlU2NyaXB0IHRvIGxldCB1cyBwYXNzIG9mZiBhIGtleS12YWx1ZSBlbnRyeSBvZiB2YWx1ZVxuICAgICAgICAvLyB0eXBlIEJhciBhcyBhIFBvaW50IHNpbmNlIHRoYXQncyB3aGF0IFRvb2x0aXBDb2x1bW4uZXZhbHVhdGUgd2FudHMuXG4gICAgICAgIC8vIFRPRE8obmlja2ZlbHQpOiByZWNvbmNpbGUgdGhlIGluY29tcGF0aWJsZSB0eXBpbmcgaGVyZVxuICAgICAgICBjb25zdCBiYXJFbnRyeUFzUG9pbnQgPSBkIGFzIGFueSBhcyB2el9jaGFydF9oZWxwZXJzLlBvaW50O1xuICAgICAgICByZXR1cm4gY29sdW1uLmV2YWx1YXRlKGJhckVudHJ5QXNQb2ludCk7XG4gICAgICB9KTtcbiAgICB9KTtcblxuICAgIGNvbnN0IGxlZnQgPSB0YXJnZXQucG9zaXRpb24ueDtcbiAgICBjb25zdCB0b3AgPSB0YXJnZXQucG9zaXRpb24ueTtcbiAgICB0aGlzLnRvb2x0aXAuc3R5bGUoJ3RyYW5zZm9ybScsICd0cmFuc2xhdGUoJyArIGxlZnQgKyAncHgsJyArIHRvcCArICdweCknKTtcbiAgICB0aGlzLnRvb2x0aXAuc3R5bGUoJ29wYWNpdHknLCAxKTtcbiAgfVxuXG4gIHB1YmxpYyByZW5kZXJUbyh0YXJnZXRTVkc6IGQzLlNlbGVjdGlvbjxhbnksIGFueSwgYW55LCBhbnk+KSB7XG4gICAgLy8gVE9ETyhjaGlodWFodWEpOiBGaWd1cmUgb3V0IHdoeSB3ZSBzdG9yZSB0YXJnZXRTVkcgYXMgYSBwcm9wZXJ0eS5cbiAgICB0aGlzLnRhcmdldFNWRyA9IHRhcmdldFNWRztcbiAgICB0aGlzLm91dGVyLnJlbmRlclRvKHRhcmdldFNWRyk7XG4gIH1cblxuICBwdWJsaWMgcmVkcmF3KCkge1xuICAgIHRoaXMub3V0ZXIucmVkcmF3KCk7XG4gIH1cblxuICBwdWJsaWMgZGVzdHJveSgpIHtcbiAgICB0aGlzLm91dGVyLmRlc3Ryb3koKTtcbiAgfVxufVxuXG59IC8vIG5hbWVzcGFjZSB2el9iYXJfY2hhcnRcbiJdfQ==