/* Copyright 2018 The TensorFlow Authors. All Rights Reserved.
+
+Licensed under the Apache License, Version 2.0 (the "License");
+you may not use this file except in compliance with the License.
+You may obtain a copy of the License at
+
+    http://www.apache.org/licenses/LICENSE-2.0
+
+Unless required by applicable law or agreed to in writing, software
+distributed under the License is distributed on an "AS IS" BASIS,
+WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
+See the License for the specific language governing permissions and
+limitations under the License.
+==============================================================================*/
var tf_backend;
(function (tf_backend) {
    // A unique reference to a listener for an easier dereferencing.
    var ListenKey = /** @class */ (function () {
        function ListenKey(listener) {
            this.listener = listener;
        }
        return ListenKey;
    }());
    tf_backend.ListenKey = ListenKey;
    var BaseStore = /** @class */ (function () {
        function BaseStore() {
            this.requestManager = new tf_backend.RequestManager(1 /* simultaneous request */);
            this._listeners = new Set();
            this.initialized = false;
        }
        BaseStore.prototype.refresh = function () {
            var _this = this;
            return this.load().then(function () {
                _this.initialized = true;
            });
        };
        /**
         * Register a listener (nullary function) to be called when new runs are
         * available.
         */
        BaseStore.prototype.addListener = function (listener) {
            var key = new ListenKey(listener);
            this._listeners.add(key);
            return key;
        };
        /**
         * Remove a listener registered with `addListener`.
         */
        BaseStore.prototype.removeListenerByKey = function (listenKey) {
            this._listeners.delete(listenKey);
        };
        BaseStore.prototype.emitChange = function () {
            this._listeners.forEach(function (listenKey) {
                try {
                    listenKey.listener();
                }
                catch (e) {
                    // ignore exceptions on the listener side.
                }
            });
        };
        return BaseStore;
    }());
    tf_backend.BaseStore = BaseStore;
})(tf_backend || (tf_backend = {})); // namespace tf_backend
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYmFzZVN0b3JlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiYmFzZVN0b3JlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7Ozs7Ozs7Ozs7O2lGQWFpRjtBQUNqRixJQUFVLFVBQVUsQ0E4RG5CO0FBOURELFdBQVUsVUFBVTtJQUlwQixnRUFBZ0U7SUFDaEU7UUFFRSxtQkFBWSxRQUFrQjtZQUM1QixJQUFJLENBQUMsUUFBUSxHQUFHLFFBQVEsQ0FBQztRQUMzQixDQUFDO1FBQ0gsZ0JBQUM7SUFBRCxDQUFDLEFBTEQsSUFLQztJQUxZLG9CQUFTLFlBS3JCLENBQUE7SUFFRDtRQUFBO1lBQ1ksbUJBQWMsR0FDcEIsSUFBSSxXQUFBLGNBQWMsQ0FBQyxDQUFDLENBQUMsMEJBQTBCLENBQUMsQ0FBQztZQUM3QyxlQUFVLEdBQW1CLElBQUksR0FBRyxFQUFhLENBQUM7WUFDbkQsZ0JBQVcsR0FBWSxLQUFLLENBQUM7UUE0Q3RDLENBQUM7UUFqQ0MsMkJBQU8sR0FBUDtZQUFBLGlCQUlDO1lBSEMsT0FBTyxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUMsSUFBSSxDQUFDO2dCQUN0QixLQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQztZQUMxQixDQUFDLENBQUMsQ0FBQztRQUNMLENBQUM7UUFFRDs7O1dBR0c7UUFDSCwrQkFBVyxHQUFYLFVBQVksUUFBa0I7WUFDNUIsSUFBTSxHQUFHLEdBQUcsSUFBSSxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7WUFDcEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDekIsT0FBTyxHQUFHLENBQUM7UUFDYixDQUFDO1FBRUQ7O1dBRUc7UUFDSCx1Q0FBbUIsR0FBbkIsVUFBb0IsU0FBb0I7WUFDdEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDcEMsQ0FBQztRQUVTLDhCQUFVLEdBQXBCO1lBQ0UsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsVUFBQSxTQUFTO2dCQUMvQixJQUFJO29CQUNGLFNBQVMsQ0FBQyxRQUFRLEVBQUUsQ0FBQztpQkFDdEI7Z0JBQUMsT0FBTyxDQUFDLEVBQUU7b0JBQ1YsMENBQTBDO2lCQUMzQztZQUNILENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQztRQUVILGdCQUFDO0lBQUQsQ0FBQyxBQWhERCxJQWdEQztJQWhEcUIsb0JBQVMsWUFnRDlCLENBQUE7QUFFRCxDQUFDLEVBOURTLFVBQVUsS0FBVixVQUFVLFFBOERuQixDQUFDLHVCQUF1QiIsInNvdXJjZXNDb250ZW50IjpbIi8qIENvcHlyaWdodCAyMDE4IFRoZSBUZW5zb3JGbG93IEF1dGhvcnMuIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG4rXG4rTGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlLCBWZXJzaW9uIDIuMCAodGhlIFwiTGljZW5zZVwiKTtcbit5b3UgbWF5IG5vdCB1c2UgdGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlIHdpdGggdGhlIExpY2Vuc2UuXG4rWW91IG1heSBvYnRhaW4gYSBjb3B5IG9mIHRoZSBMaWNlbnNlIGF0XG4rXG4rICAgIGh0dHA6Ly93d3cuYXBhY2hlLm9yZy9saWNlbnNlcy9MSUNFTlNFLTIuMFxuK1xuK1VubGVzcyByZXF1aXJlZCBieSBhcHBsaWNhYmxlIGxhdyBvciBhZ3JlZWQgdG8gaW4gd3JpdGluZywgc29mdHdhcmVcbitkaXN0cmlidXRlZCB1bmRlciB0aGUgTGljZW5zZSBpcyBkaXN0cmlidXRlZCBvbiBhbiBcIkFTIElTXCIgQkFTSVMsXG4rV0lUSE9VVCBXQVJSQU5USUVTIE9SIENPTkRJVElPTlMgT0YgQU5ZIEtJTkQsIGVpdGhlciBleHByZXNzIG9yIGltcGxpZWQuXG4rU2VlIHRoZSBMaWNlbnNlIGZvciB0aGUgc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nIHBlcm1pc3Npb25zIGFuZFxuK2xpbWl0YXRpb25zIHVuZGVyIHRoZSBMaWNlbnNlLlxuKz09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSovXG5uYW1lc3BhY2UgdGZfYmFja2VuZCB7XG5cbmV4cG9ydCB0eXBlIExpc3RlbmVyID0gKCkgPT4gdm9pZDtcblxuLy8gQSB1bmlxdWUgcmVmZXJlbmNlIHRvIGEgbGlzdGVuZXIgZm9yIGFuIGVhc2llciBkZXJlZmVyZW5jaW5nLlxuZXhwb3J0IGNsYXNzIExpc3RlbktleSB7XG4gIHB1YmxpYyByZWFkb25seSBsaXN0ZW5lcjogTGlzdGVuZXI7XG4gIGNvbnN0cnVjdG9yKGxpc3RlbmVyOiBMaXN0ZW5lcikge1xuICAgIHRoaXMubGlzdGVuZXIgPSBsaXN0ZW5lcjtcbiAgfVxufVxuXG5leHBvcnQgYWJzdHJhY3QgY2xhc3MgQmFzZVN0b3JlIHtcbiAgcHJvdGVjdGVkIHJlcXVlc3RNYW5hZ2VyOiBSZXF1ZXN0TWFuYWdlciA9XG4gICAgICBuZXcgUmVxdWVzdE1hbmFnZXIoMSAvKiBzaW11bHRhbmVvdXMgcmVxdWVzdCAqLyk7XG4gIHByaXZhdGUgX2xpc3RlbmVyczogU2V0PExpc3RlbktleT4gPSBuZXcgU2V0PExpc3RlbktleT4oKTtcbiAgcHVibGljIGluaXRpYWxpemVkOiBib29sZWFuID0gZmFsc2U7XG5cbiAgLyoqXG4gICAqIEFzeW5jaHJvbm91c2x5IGxvYWQgb3IgcmVsb2FkIHRoZSBydW5zIGRhdGEuIExpc3RlbmVycyB3aWxsIGJlXG4gICAqIGludm9rZWQgaWYgdGhpcyBjYXVzZXMgdGhlIHJ1bnMgZGF0YSB0byBjaGFuZ2UuXG4gICAqXG4gICAqIEBzZWUgYWRkTGlzdGVuZXJcbiAgICogQHJldHVybiB7UHJvbWlzZTx2b2lkPn0gYSBwcm9taXNlIHRoYXQgcmVzb2x2ZXMgd2hlbiBuZXcgZGF0YSBoYXZlIGxvYWRlZC5cbiAgICovXG4gIHByb3RlY3RlZCBhYnN0cmFjdCBsb2FkKCk6IFByb21pc2U8dm9pZD47XG5cbiAgcmVmcmVzaCgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICByZXR1cm4gdGhpcy5sb2FkKCkudGhlbigoKSA9PiB7XG4gICAgICB0aGlzLmluaXRpYWxpemVkID0gdHJ1ZTtcbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZWdpc3RlciBhIGxpc3RlbmVyIChudWxsYXJ5IGZ1bmN0aW9uKSB0byBiZSBjYWxsZWQgd2hlbiBuZXcgcnVucyBhcmVcbiAgICogYXZhaWxhYmxlLlxuICAgKi9cbiAgYWRkTGlzdGVuZXIobGlzdGVuZXI6IExpc3RlbmVyKTogTGlzdGVuS2V5IHtcbiAgICBjb25zdCBrZXkgPSBuZXcgTGlzdGVuS2V5KGxpc3RlbmVyKTtcbiAgICB0aGlzLl9saXN0ZW5lcnMuYWRkKGtleSk7XG4gICAgcmV0dXJuIGtleTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZW1vdmUgYSBsaXN0ZW5lciByZWdpc3RlcmVkIHdpdGggYGFkZExpc3RlbmVyYC5cbiAgICovXG4gIHJlbW92ZUxpc3RlbmVyQnlLZXkobGlzdGVuS2V5OiBMaXN0ZW5LZXkpOiB2b2lkIHtcbiAgICB0aGlzLl9saXN0ZW5lcnMuZGVsZXRlKGxpc3RlbktleSk7XG4gIH1cblxuICBwcm90ZWN0ZWQgZW1pdENoYW5nZSgpOiB2b2lkIHtcbiAgICB0aGlzLl9saXN0ZW5lcnMuZm9yRWFjaChsaXN0ZW5LZXkgPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgbGlzdGVuS2V5Lmxpc3RlbmVyKCk7XG4gICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIC8vIGlnbm9yZSBleGNlcHRpb25zIG9uIHRoZSBsaXN0ZW5lciBzaWRlLlxuICAgICAgfVxuICAgIH0pO1xuICB9XG5cbn1cblxufSAvLyBuYW1lc3BhY2UgdGZfYmFja2VuZFxuIl19