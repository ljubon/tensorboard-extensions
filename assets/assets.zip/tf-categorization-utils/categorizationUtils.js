/* Copyright 2017 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
var tf_categorization_utils;
(function (tf_categorization_utils) {
    /**
     * Functions to extract categories of tags and/or run-tag combinations
     * from a run-to-tag mapping. The resulting categories can be fed to a
     * `tf-category-pane`, and their items can be `<dom-repeat>`ed in a
     * Polymer component.
     */
    var CategoryType;
    (function (CategoryType) {
        CategoryType[CategoryType["SEARCH_RESULTS"] = 0] = "SEARCH_RESULTS";
        CategoryType[CategoryType["PREFIX_GROUP"] = 1] = "PREFIX_GROUP";
    })(CategoryType = tf_categorization_utils.CategoryType || (tf_categorization_utils.CategoryType = {}));
    ;
    /**
     * Compute a category containing the search results for the given query.
     */
    function categorizeBySearchQuery(xs, query) {
        var re = (function () {
            try {
                return new RegExp(query);
            }
            catch (e) {
                return null;
            }
        })();
        return {
            name: query,
            metadata: {
                type: CategoryType.SEARCH_RESULTS,
                validRegex: !!re,
                universalRegex: query === '.*',
            },
            items: re ? xs.filter(function (x) { return x.match(re); }) : [],
        };
    }
    tf_categorization_utils.categorizeBySearchQuery = categorizeBySearchQuery;
    /**
     * Compute the quotient set $X/{\sim}$, where $a \sim b$ if $a$ and $b$
     * share a common `separator`-prefix. Order is preserved.
     */
    function categorizeByPrefix(xs, separator) {
        if (separator === void 0) { separator = '/'; }
        var categories = [];
        var categoriesByName = {};
        xs.forEach(function (x) {
            var index = x.indexOf(separator);
            var name = index >= 0 ? x.slice(0, index) : x;
            if (!categoriesByName[name]) {
                var category = {
                    name: name,
                    metadata: { type: CategoryType.PREFIX_GROUP },
                    items: [],
                };
                categoriesByName[name] = category;
                categories.push(category);
            }
            categoriesByName[name].items.push(x);
        });
        return categories;
    }
    tf_categorization_utils.categorizeByPrefix = categorizeByPrefix;
    /*
     * Compute the standard categorization of the given input, including
     * both search categories and prefix categories.
     */
    function categorize(xs, query) {
        if (query === void 0) { query = ''; }
        var byFilter = [categorizeBySearchQuery(xs, query)];
        var byPrefix = categorizeByPrefix(xs);
        return [].concat(byFilter, byPrefix);
    }
    tf_categorization_utils.categorize = categorize;
    function categorizeTags(runToTag, selectedRuns, query) {
        var tags = tf_backend.getTags(runToTag);
        var categories = categorize(tags, query);
        var tagToRuns = createTagToRuns(_.pick(runToTag, selectedRuns));
        return categories.map(function (_a) {
            var name = _a.name, metadata = _a.metadata, items = _a.items;
            return ({
                name: name,
                metadata: metadata,
                items: items.map(function (tag) { return ({
                    tag: tag,
                    runs: (tagToRuns.get(tag) || []).slice(),
                }); }),
            });
        });
    }
    tf_categorization_utils.categorizeTags = categorizeTags;
    /**
     * Creates grouping of the data based on selection from tf-data-selector. It
     * groups data by prefixes of tag names and by tag names. Each group contains
     * series, a tuple of experiment name and run name.
     */
    function categorizeSelection(selection, pluginName) {
        var tagToSeries = new Map();
        // `tagToSearchSeries` contains subset of `tagToSeries`. tagRegex in each
        // selection can omit series from a tag category.
        var tagToSearchSeries = new Map();
        var searchCategories = [];
        selection.forEach(function (_a) {
            var experiment = _a.experiment, runs = _a.runs, tagRegex = _a.tagRegex;
            var runNames = runs.map(function (_a) {
                var name = _a.name;
                return name;
            });
            var selectedRunToTag = createRunToTagForPlugin(runs, pluginName);
            var tagToSelectedRuns = createTagToRuns(selectedRunToTag);
            var tags = tf_backend.getTags(selectedRunToTag);
            // list of all tags that has selected runs.
            tags.forEach(function (tag) {
                var series = tagToSeries.get(tag) || [];
                series.push.apply(series, tagToSelectedRuns.get(tag)
                    .map(function (run) { return ({ experiment: experiment, run: run, tag: tag }); }));
                tagToSeries.set(tag, series);
            });
            var searchCategory = categorizeBySearchQuery(tags, tagRegex);
            searchCategories.push(searchCategory);
            // list of tags matching tagRegex in the selection.
            searchCategory.items.forEach(function (tag) {
                var series = tagToSearchSeries.get(tag) || [];
                series.push.apply(series, tagToSelectedRuns.get(tag)
                    .map(function (run) { return ({ experiment: experiment, run: run, tag: tag }); }));
                tagToSearchSeries.set(tag, series);
            });
        });
        var searchCategory = searchCategories.length == 1 ?
            searchCategories[0] :
            {
                name: searchCategories.every(function (c) { return !c.name; }) ? '' : 'multi',
                metadata: {
                    type: CategoryType.SEARCH_RESULTS,
                    compositeSearch: true,
                    validRegex: searchCategories.every(function (c) { return c.metadata.validRegex; }),
                    universalRegex: false,
                },
                items: Array.from(tagToSearchSeries.keys())
                    .sort(vz_sorting.compareTagNames),
            };
        var searchSeriesCategory = Object.assign({}, searchCategory, {
            items: searchCategory.items.map(function (tag) { return ({
                tag: tag,
                series: tagToSearchSeries.get(tag),
            }); }),
        });
        // Organize the tag to items by prefix.
        var prefixCategories = categorizeByPrefix(Array.from(tagToSeries.keys()))
            .map(function (_a) {
            var name = _a.name, metadata = _a.metadata, items = _a.items;
            return ({
                name: name,
                metadata: metadata,
                items: items.map(function (tag) { return ({
                    tag: tag,
                    series: tagToSeries.get(tag),
                }); }),
            });
        });
        return [
            searchSeriesCategory
        ].concat(prefixCategories);
    }
    tf_categorization_utils.categorizeSelection = categorizeSelection;
    function createTagToRuns(runToTag) {
        var tagToRun = new Map();
        Object.keys(runToTag).forEach(function (run) {
            runToTag[run].forEach(function (tag) {
                var runs = tagToRun.get(tag) || [];
                runs.push(run);
                tagToRun.set(tag, runs);
            });
        });
        return tagToRun;
    }
    function createRunToTagForPlugin(runs, pluginName) {
        var runToTag = {};
        runs.forEach(function (run) {
            runToTag[run.name] = run.tags
                .filter(function (tag) { return tag.pluginName == pluginName; })
                .map(function (_a) {
                var name = _a.name;
                return name;
            });
        });
        return runToTag;
    }
    function compareTagRun(a, b) {
        var c = vz_sorting.compareTagNames(a.tag, b.tag);
        if (c != 0) {
            return c;
        }
        return vz_sorting.compareTagNames(a.run, b.run);
    }
    function categorizeRunTagCombinations(runToTag, selectedRuns, query) {
        var tagCategories = categorizeTags(runToTag, selectedRuns, query);
        function explodeCategory(tagCategory) {
            var items = _.flatten(tagCategory.items.map(function (_a) {
                var tag = _a.tag, runs = _a.runs;
                return runs.map(function (run) { return ({ tag: tag, run: run }); });
            }));
            items.sort(compareTagRun);
            return {
                name: tagCategory.name,
                metadata: tagCategory.metadata,
                items: items,
            };
        }
        return tagCategories.map(explodeCategory);
    }
    tf_categorization_utils.categorizeRunTagCombinations = categorizeRunTagCombinations;
})(tf_categorization_utils || (tf_categorization_utils = {})); // namespace wtf_categorization_utils
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2F0ZWdvcml6YXRpb25VdGlscy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImNhdGVnb3JpemF0aW9uVXRpbHMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7Ozs7Ozs7Z0ZBYWdGO0FBQ2hGLElBQVUsdUJBQXVCLENBaVFoQztBQWpRRCxXQUFVLHVCQUF1QjtJQUVqQzs7Ozs7T0FLRztJQUlILElBQVksWUFHWDtJQUhELFdBQVksWUFBWTtRQUN0QixtRUFBYyxDQUFBO1FBQ2QsK0RBQVksQ0FBQTtJQUNkLENBQUMsRUFIVyxZQUFZLEdBQVosb0NBQVksS0FBWixvQ0FBWSxRQUd2QjtJQWdCQSxDQUFDO0lBcUJGOztPQUVHO0lBQ0gsaUNBQ0ksRUFBWSxFQUFFLEtBQWE7UUFDN0IsSUFBTSxFQUFFLEdBQUcsQ0FBQztZQUNWLElBQUk7Z0JBQ0YsT0FBTyxJQUFJLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUMxQjtZQUFDLE9BQU8sQ0FBQyxFQUFFO2dCQUNWLE9BQU8sSUFBSSxDQUFDO2FBQ2I7UUFDSCxDQUFDLENBQUMsRUFBRSxDQUFDO1FBQ0wsT0FBTztZQUNMLElBQUksRUFBRSxLQUFLO1lBQ1gsUUFBUSxFQUFFO2dCQUNSLElBQUksRUFBRSxZQUFZLENBQUMsY0FBYztnQkFDakMsVUFBVSxFQUFFLENBQUMsQ0FBQyxFQUFFO2dCQUNoQixjQUFjLEVBQUUsS0FBSyxLQUFLLElBQUk7YUFDL0I7WUFDRCxLQUFLLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLFVBQUEsQ0FBQyxJQUFJLE9BQUEsQ0FBQyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsRUFBWCxDQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRTtTQUM3QyxDQUFDO0lBQ0osQ0FBQztJQWxCZSwrQ0FBdUIsMEJBa0J0QyxDQUFBO0lBRUQ7OztPQUdHO0lBQ0gsNEJBQW1DLEVBQVksRUFBRSxTQUFlO1FBQWYsMEJBQUEsRUFBQSxlQUFlO1FBQzlELElBQU0sVUFBVSxHQUFHLEVBQUUsQ0FBQztRQUN0QixJQUFNLGdCQUFnQixHQUFHLEVBQUUsQ0FBQztRQUM1QixFQUFFLENBQUMsT0FBTyxDQUFDLFVBQUEsQ0FBQztZQUNWLElBQU0sS0FBSyxHQUFHLENBQUMsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUM7WUFDbkMsSUFBTSxJQUFJLEdBQUcsS0FBSyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUNoRCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLEVBQUU7Z0JBQzNCLElBQU0sUUFBUSxHQUFHO29CQUNmLElBQUksTUFBQTtvQkFDSixRQUFRLEVBQUUsRUFBQyxJQUFJLEVBQUUsWUFBWSxDQUFDLFlBQVksRUFBQztvQkFDM0MsS0FBSyxFQUFFLEVBQUU7aUJBQ1YsQ0FBQztnQkFDRixnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsR0FBRyxRQUFRLENBQUM7Z0JBQ2xDLFVBQVUsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7YUFDM0I7WUFDRCxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3ZDLENBQUMsQ0FBQyxDQUFDO1FBQ0gsT0FBTyxVQUFVLENBQUM7SUFDcEIsQ0FBQztJQWxCZSwwQ0FBa0IscUJBa0JqQyxDQUFBO0lBRUQ7OztPQUdHO0lBQ0gsb0JBQTJCLEVBQVksRUFBRSxLQUFVO1FBQVYsc0JBQUEsRUFBQSxVQUFVO1FBQ2pELElBQU0sUUFBUSxHQUFHLENBQUMsdUJBQXVCLENBQUMsRUFBRSxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUM7UUFDdEQsSUFBTSxRQUFRLEdBQUcsa0JBQWtCLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDeEMsT0FBTyxFQUFFLENBQUMsTUFBTSxDQUFDLFFBQVEsRUFBRSxRQUFRLENBQUMsQ0FBQztJQUN2QyxDQUFDO0lBSmUsa0NBQVUsYUFJekIsQ0FBQTtJQUVELHdCQUNJLFFBQWtCLEVBQ2xCLFlBQXNCLEVBQ3RCLEtBQWM7UUFDaEIsSUFBTSxJQUFJLEdBQUcsVUFBVSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUMxQyxJQUFNLFVBQVUsR0FBRyxVQUFVLENBQUMsSUFBSSxFQUFFLEtBQUssQ0FBQyxDQUFDO1FBQzNDLElBQU0sU0FBUyxHQUFHLGVBQWUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxZQUFZLENBQUMsQ0FBQyxDQUFDO1FBRWxFLE9BQU8sVUFBVSxDQUFDLEdBQUcsQ0FBQyxVQUFDLEVBQXVCO2dCQUF0QixjQUFJLEVBQUUsc0JBQVEsRUFBRSxnQkFBSztZQUFNLE9BQUEsQ0FBQztnQkFDbEQsSUFBSSxNQUFBO2dCQUNKLFFBQVEsVUFBQTtnQkFDUixLQUFLLEVBQUUsS0FBSyxDQUFDLEdBQUcsQ0FBQyxVQUFBLEdBQUcsSUFBSSxPQUFBLENBQUM7b0JBQ3ZCLEdBQUcsS0FBQTtvQkFDSCxJQUFJLEVBQUUsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLEtBQUssRUFBRTtpQkFDekMsQ0FBQyxFQUhzQixDQUd0QixDQUFDO2FBQ0osQ0FBQztRQVBpRCxDQU9qRCxDQUFDLENBQUM7SUFDTixDQUFDO0lBaEJlLHNDQUFjLGlCQWdCN0IsQ0FBQTtJQUVEOzs7O09BSUc7SUFDSCw2QkFDSSxTQUF1QyxFQUFFLFVBQWtCO1FBRTdELElBQU0sV0FBVyxHQUFHLElBQUksR0FBRyxFQUFvQixDQUFDO1FBQ2hELHlFQUF5RTtRQUN6RSxpREFBaUQ7UUFDakQsSUFBTSxpQkFBaUIsR0FBRyxJQUFJLEdBQUcsRUFBb0IsQ0FBQztRQUN0RCxJQUFNLGdCQUFnQixHQUFHLEVBQUUsQ0FBQztRQUU1QixTQUFTLENBQUMsT0FBTyxDQUFDLFVBQUMsRUFBNEI7Z0JBQTNCLDBCQUFVLEVBQUUsY0FBSSxFQUFFLHNCQUFRO1lBQzVDLElBQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsVUFBQyxFQUFNO29CQUFMLGNBQUk7Z0JBQU0sT0FBQSxJQUFJO1lBQUosQ0FBSSxDQUFDLENBQUM7WUFDNUMsSUFBTSxnQkFBZ0IsR0FBRyx1QkFBdUIsQ0FBQyxJQUFJLEVBQUUsVUFBVSxDQUFDLENBQUM7WUFDbkUsSUFBTSxpQkFBaUIsR0FBRyxlQUFlLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztZQUM1RCxJQUFNLElBQUksR0FBRyxVQUFVLENBQUMsT0FBTyxDQUFDLGdCQUFnQixDQUFDLENBQUM7WUFDbEQsMkNBQTJDO1lBQzNDLElBQUksQ0FBQyxPQUFPLENBQUMsVUFBQSxHQUFHO2dCQUNkLElBQU0sTUFBTSxHQUFHLFdBQVcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLElBQUksRUFBRSxDQUFDO2dCQUMxQyxNQUFNLENBQUMsSUFBSSxPQUFYLE1BQU0sRUFBUyxpQkFBaUIsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDO3FCQUNwQyxHQUFHLENBQUMsVUFBQSxHQUFHLElBQUksT0FBQSxDQUFDLEVBQUMsVUFBVSxZQUFBLEVBQUUsR0FBRyxLQUFBLEVBQUUsR0FBRyxLQUFBLEVBQUMsQ0FBQyxFQUF4QixDQUF3QixDQUFDLEVBQUU7Z0JBQzNDLFdBQVcsQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFFLE1BQU0sQ0FBQyxDQUFDO1lBQy9CLENBQUMsQ0FBQyxDQUFDO1lBRUgsSUFBTSxjQUFjLEdBQUcsdUJBQXVCLENBQUMsSUFBSSxFQUFFLFFBQVEsQ0FBQyxDQUFDO1lBQy9ELGdCQUFnQixDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQztZQUN0QyxtREFBbUQ7WUFDbkQsY0FBYyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsVUFBQSxHQUFHO2dCQUM5QixJQUFNLE1BQU0sR0FBRyxpQkFBaUIsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLElBQUksRUFBRSxDQUFDO2dCQUNoRCxNQUFNLENBQUMsSUFBSSxPQUFYLE1BQU0sRUFBUyxpQkFBaUIsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDO3FCQUNwQyxHQUFHLENBQUMsVUFBQSxHQUFHLElBQUksT0FBQSxDQUFDLEVBQUMsVUFBVSxZQUFBLEVBQUUsR0FBRyxLQUFBLEVBQUUsR0FBRyxLQUFBLEVBQUMsQ0FBQyxFQUF4QixDQUF3QixDQUFDLEVBQUU7Z0JBQzNDLGlCQUFpQixDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsTUFBTSxDQUFDLENBQUM7WUFDckMsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztRQUVILElBQU0sY0FBYyxHQUFnQixnQkFBZ0IsQ0FBQyxNQUFNLElBQUksQ0FBQyxDQUFDLENBQUM7WUFDOUQsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUNyQjtnQkFDRSxJQUFJLEVBQUUsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLFVBQUEsQ0FBQyxJQUFJLE9BQUEsQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFQLENBQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLE9BQU87Z0JBQ3pELFFBQVEsRUFBRTtvQkFDUixJQUFJLEVBQUUsWUFBWSxDQUFDLGNBQWM7b0JBQ2pDLGVBQWUsRUFBRSxJQUFJO29CQUNyQixVQUFVLEVBQUUsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLFVBQUEsQ0FBQyxJQUFJLE9BQUEsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxVQUFVLEVBQXJCLENBQXFCLENBQUM7b0JBQzlELGNBQWMsRUFBRSxLQUFLO2lCQUN0QjtnQkFDRCxLQUFLLEVBQUUsS0FBSyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLEVBQUUsQ0FBQztxQkFDdEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxlQUFlLENBQUM7YUFDdEMsQ0FBQztRQUVOLElBQU0sb0JBQW9CLEdBQW1CLE1BQU0sQ0FBQyxNQUFNLENBQ3hELEVBQUUsRUFDRixjQUFjLEVBQ2Q7WUFDRSxLQUFLLEVBQUUsY0FBYyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsVUFBQSxHQUFHLElBQUksT0FBQSxDQUFDO2dCQUN0QyxHQUFHLEtBQUE7Z0JBQ0gsTUFBTSxFQUFFLGlCQUFpQixDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUM7YUFDbkMsQ0FBQyxFQUhxQyxDQUdyQyxDQUFDO1NBQ0osQ0FDRixDQUFDO1FBRUYsdUNBQXVDO1FBQ3ZDLElBQU0sZ0JBQWdCLEdBQXFCLGtCQUFrQixDQUN6RCxLQUFLLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDO2FBQzFCLEdBQUcsQ0FBQyxVQUFDLEVBQXVCO2dCQUF0QixjQUFJLEVBQUUsc0JBQVEsRUFBRSxnQkFBSztZQUFNLE9BQUEsQ0FBQztnQkFDakMsSUFBSSxNQUFBO2dCQUNKLFFBQVEsVUFBQTtnQkFDUixLQUFLLEVBQUUsS0FBSyxDQUFDLEdBQUcsQ0FBQyxVQUFBLEdBQUcsSUFBSSxPQUFBLENBQUM7b0JBQ3ZCLEdBQUcsS0FBQTtvQkFDSCxNQUFNLEVBQUUsV0FBVyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUM7aUJBQzdCLENBQUMsRUFIc0IsQ0FHdEIsQ0FBQzthQUNKLENBQUM7UUFQZ0MsQ0FPaEMsQ0FBQyxDQUFDO1FBRVo7WUFDRSxvQkFBb0I7aUJBQ2pCLGdCQUFnQixFQUNuQjtJQUNKLENBQUM7SUExRWUsMkNBQW1CLHNCQTBFbEMsQ0FBQTtJQUVELHlCQUF5QixRQUFrQjtRQUN6QyxJQUFNLFFBQVEsR0FBRyxJQUFJLEdBQUcsRUFBRSxDQUFDO1FBQzNCLE1BQU0sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsT0FBTyxDQUFDLFVBQUEsR0FBRztZQUMvQixRQUFRLENBQUMsR0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDLFVBQUEsR0FBRztnQkFDdkIsSUFBTSxJQUFJLEdBQUcsUUFBUSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsSUFBSSxFQUFFLENBQUM7Z0JBQ3JDLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQ2YsUUFBUSxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLENBQUM7WUFDMUIsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztRQUNILE9BQU8sUUFBUSxDQUFDO0lBQ2xCLENBQUM7SUFFRCxpQ0FBaUMsSUFBc0IsRUFBRSxVQUFrQjtRQUV6RSxJQUFNLFFBQVEsR0FBRyxFQUFFLENBQUM7UUFDcEIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxVQUFDLEdBQUc7WUFDZixRQUFRLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxHQUFHLEdBQUcsQ0FBQyxJQUFJO2lCQUN4QixNQUFNLENBQUMsVUFBQSxHQUFHLElBQUksT0FBQSxHQUFHLENBQUMsVUFBVSxJQUFJLFVBQVUsRUFBNUIsQ0FBNEIsQ0FBQztpQkFDM0MsR0FBRyxDQUFDLFVBQUMsRUFBTTtvQkFBTCxjQUFJO2dCQUFNLE9BQUEsSUFBSTtZQUFKLENBQUksQ0FBQyxDQUFDO1FBQzdCLENBQUMsQ0FBQyxDQUFBO1FBQ0YsT0FBTyxRQUFRLENBQUM7SUFDbEIsQ0FBQztJQUVELHVCQUF1QixDQUFDLEVBQUUsQ0FBNkI7UUFDckQsSUFBTSxDQUFDLEdBQUcsVUFBVSxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUNuRCxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUU7WUFDVixPQUFPLENBQUMsQ0FBQztTQUNWO1FBQ0QsT0FBTyxVQUFVLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0lBQ2xELENBQUM7SUFFRCxzQ0FDSSxRQUFrQixFQUNsQixZQUFzQixFQUN0QixLQUFjO1FBQ2hCLElBQU0sYUFBYSxHQUNqQixjQUFjLENBQUMsUUFBUSxFQUFFLFlBQVksRUFBRSxLQUFLLENBQUMsQ0FBQztRQUNoRCx5QkFBeUIsV0FBd0I7WUFDL0MsSUFBTSxLQUFLLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FDM0MsVUFBQyxFQUFXO29CQUFWLFlBQUcsRUFBRSxjQUFJO2dCQUFNLE9BQUEsSUFBSSxDQUFDLEdBQUcsQ0FBQyxVQUFBLEdBQUcsSUFBSSxPQUFBLENBQUMsRUFBQyxHQUFHLEtBQUEsRUFBRSxHQUFHLEtBQUEsRUFBQyxDQUFDLEVBQVosQ0FBWSxDQUFDO1lBQTdCLENBQTZCLENBQUMsQ0FBQyxDQUFDO1lBQ25ELEtBQUssQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUM7WUFDMUIsT0FBTztnQkFDTCxJQUFJLEVBQUUsV0FBVyxDQUFDLElBQUk7Z0JBQ3RCLFFBQVEsRUFBRSxXQUFXLENBQUMsUUFBUTtnQkFDOUIsS0FBSyxPQUFBO2FBQ04sQ0FBQztRQUNKLENBQUM7UUFDRCxPQUFPLGFBQWEsQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUM7SUFDNUMsQ0FBQztJQWpCZSxvREFBNEIsK0JBaUIzQyxDQUFBO0FBRUQsQ0FBQyxFQWpRUyx1QkFBdUIsS0FBdkIsdUJBQXVCLFFBaVFoQyxDQUFFLHFDQUFxQyIsInNvdXJjZXNDb250ZW50IjpbIi8qIENvcHlyaWdodCAyMDE3IFRoZSBUZW5zb3JGbG93IEF1dGhvcnMuIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG5cbkxpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSBcIkxpY2Vuc2VcIik7XG55b3UgbWF5IG5vdCB1c2UgdGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlIHdpdGggdGhlIExpY2Vuc2UuXG5Zb3UgbWF5IG9idGFpbiBhIGNvcHkgb2YgdGhlIExpY2Vuc2UgYXRcblxuICAgIGh0dHA6Ly93d3cuYXBhY2hlLm9yZy9saWNlbnNlcy9MSUNFTlNFLTIuMFxuXG5Vbmxlc3MgcmVxdWlyZWQgYnkgYXBwbGljYWJsZSBsYXcgb3IgYWdyZWVkIHRvIGluIHdyaXRpbmcsIHNvZnR3YXJlXG5kaXN0cmlidXRlZCB1bmRlciB0aGUgTGljZW5zZSBpcyBkaXN0cmlidXRlZCBvbiBhbiBcIkFTIElTXCIgQkFTSVMsXG5XSVRIT1VUIFdBUlJBTlRJRVMgT1IgQ09ORElUSU9OUyBPRiBBTlkgS0lORCwgZWl0aGVyIGV4cHJlc3Mgb3IgaW1wbGllZC5cblNlZSB0aGUgTGljZW5zZSBmb3IgdGhlIHNwZWNpZmljIGxhbmd1YWdlIGdvdmVybmluZyBwZXJtaXNzaW9ucyBhbmRcbmxpbWl0YXRpb25zIHVuZGVyIHRoZSBMaWNlbnNlLlxuPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09Ki9cbm5hbWVzcGFjZSB0Zl9jYXRlZ29yaXphdGlvbl91dGlscyB7XG5cbi8qKlxuICogRnVuY3Rpb25zIHRvIGV4dHJhY3QgY2F0ZWdvcmllcyBvZiB0YWdzIGFuZC9vciBydW4tdGFnIGNvbWJpbmF0aW9uc1xuICogZnJvbSBhIHJ1bi10by10YWcgbWFwcGluZy4gVGhlIHJlc3VsdGluZyBjYXRlZ29yaWVzIGNhbiBiZSBmZWQgdG8gYVxuICogYHRmLWNhdGVnb3J5LXBhbmVgLCBhbmQgdGhlaXIgaXRlbXMgY2FuIGJlIGA8ZG9tLXJlcGVhdD5gZWQgaW4gYVxuICogUG9seW1lciBjb21wb25lbnQuXG4gKi9cblxuZXhwb3J0IHR5cGUgUnVuVG9UYWcgPSB7W3J1bjogc3RyaW5nXTogc3RyaW5nW119O1xuXG5leHBvcnQgZW51bSBDYXRlZ29yeVR5cGUge1xuICBTRUFSQ0hfUkVTVUxUUyxcbiAgUFJFRklYX0dST1VQLFxufVxuZXhwb3J0IGludGVyZmFjZSBQcmVmaXhHcm91cE1ldGFkYXRhIHtcbiAgdHlwZTogQ2F0ZWdvcnlUeXBlO1xufVxuZXhwb3J0IGludGVyZmFjZSBTZWFyY2hSZXN1bHRzTWV0YWRhdGEge1xuICB0eXBlOiBDYXRlZ29yeVR5cGU7XG4gIGNvbXBvc2l0ZVNlYXJjaD86IGJvb2xlYW47XG4gIHZhbGlkUmVnZXg6IGJvb2xlYW47XG4gIHVuaXZlcnNhbFJlZ2V4OiBib29sZWFuOyAgLy8gaXMgdGhlIHNlYXJjaCBxdWVyeSBcIi4qXCI/IChcIig/OilcIiBkb2Vzbid0IGNvdW50KVxufVxuZXhwb3J0IHR5cGUgQ2F0ZWdvcnlNZXRhZGF0YSA9IFByZWZpeEdyb3VwTWV0YWRhdGEgfCBTZWFyY2hSZXN1bHRzTWV0YWRhdGE7XG5cbmV4cG9ydCBpbnRlcmZhY2UgQ2F0ZWdvcnk8VD4ge1xuICBuYW1lOiBzdHJpbmcsXG4gIG1ldGFkYXRhOiBDYXRlZ29yeU1ldGFkYXRhLFxuICBpdGVtczogVFtdLFxufTtcbmV4cG9ydCB0eXBlIFRhZ0NhdGVnb3J5ID0gQ2F0ZWdvcnk8e3RhZzogc3RyaW5nLCBydW5zOiBzdHJpbmdbXX0+O1xuZXhwb3J0IHR5cGUgUnVuVGFnQ2F0ZWdvcnkgPSBDYXRlZ29yeTx7dGFnOiBzdHJpbmcsIHJ1bjogc3RyaW5nfT47XG5cbmV4cG9ydCB0eXBlIFNlcmllcyA9IHtcbiAgZXhwZXJpbWVudDogdGZfYmFja2VuZC5FeHBlcmltZW50LFxuICBydW46IHN0cmluZyxcbiAgdGFnOiBzdHJpbmcsXG59O1xuXG4vKipcbiAqIE9yZ2FuaXplIGRhdGEgYnkgdGFnUHJlZml4LCB0YWcsIHRoZW4gbGlzdCBvZiBzZXJpZXMgd2hpY2ggaXMgY29tcHJpc2VkIG9mXG4gKiBhbiBleHBlcmltZW50IGFuZCBhIHJ1bi5cbiAqL1xuZXhwb3J0IHR5cGUgU2VyaWVzQ2F0ZWdvcnkgPSBDYXRlZ29yeTx7XG4gIHRhZzogc3RyaW5nLFxuICBzZXJpZXM6IFNlcmllc1tdLFxufT47XG5cbmV4cG9ydCB0eXBlIFJhd0NhdGVnb3J5ID0gQ2F0ZWdvcnk8c3RyaW5nPjsgIC8vIEludGVybWVkaWF0ZSBzdHJ1Y3R1cmUuXG5cbi8qKlxuICogQ29tcHV0ZSBhIGNhdGVnb3J5IGNvbnRhaW5pbmcgdGhlIHNlYXJjaCByZXN1bHRzIGZvciB0aGUgZ2l2ZW4gcXVlcnkuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjYXRlZ29yaXplQnlTZWFyY2hRdWVyeShcbiAgICB4czogc3RyaW5nW10sIHF1ZXJ5OiBzdHJpbmcpOiBSYXdDYXRlZ29yeSB7XG4gIGNvbnN0IHJlID0gKCgpID0+IHtcbiAgICB0cnkge1xuICAgICAgcmV0dXJuIG5ldyBSZWdFeHAocXVlcnkpO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgfSkoKTtcbiAgcmV0dXJuIHtcbiAgICBuYW1lOiBxdWVyeSxcbiAgICBtZXRhZGF0YToge1xuICAgICAgdHlwZTogQ2F0ZWdvcnlUeXBlLlNFQVJDSF9SRVNVTFRTLFxuICAgICAgdmFsaWRSZWdleDogISFyZSxcbiAgICAgIHVuaXZlcnNhbFJlZ2V4OiBxdWVyeSA9PT0gJy4qJyxcbiAgICB9LFxuICAgIGl0ZW1zOiByZSA/IHhzLmZpbHRlcih4ID0+IHgubWF0Y2gocmUpKSA6IFtdLFxuICB9O1xufVxuXG4vKipcbiAqIENvbXB1dGUgdGhlIHF1b3RpZW50IHNldCAkWC97XFxzaW19JCwgd2hlcmUgJGEgXFxzaW0gYiQgaWYgJGEkIGFuZCAkYiRcbiAqIHNoYXJlIGEgY29tbW9uIGBzZXBhcmF0b3JgLXByZWZpeC4gT3JkZXIgaXMgcHJlc2VydmVkLlxuICovXG5leHBvcnQgZnVuY3Rpb24gY2F0ZWdvcml6ZUJ5UHJlZml4KHhzOiBzdHJpbmdbXSwgc2VwYXJhdG9yID0gJy8nKTogUmF3Q2F0ZWdvcnlbXSB7XG4gIGNvbnN0IGNhdGVnb3JpZXMgPSBbXTtcbiAgY29uc3QgY2F0ZWdvcmllc0J5TmFtZSA9IHt9O1xuICB4cy5mb3JFYWNoKHggPT4ge1xuICAgIGNvbnN0IGluZGV4ID0geC5pbmRleE9mKHNlcGFyYXRvcik7XG4gICAgY29uc3QgbmFtZSA9IGluZGV4ID49IDAgPyB4LnNsaWNlKDAsIGluZGV4KSA6IHg7XG4gICAgaWYgKCFjYXRlZ29yaWVzQnlOYW1lW25hbWVdKSB7XG4gICAgICBjb25zdCBjYXRlZ29yeSA9IHtcbiAgICAgICAgbmFtZSxcbiAgICAgICAgbWV0YWRhdGE6IHt0eXBlOiBDYXRlZ29yeVR5cGUuUFJFRklYX0dST1VQfSxcbiAgICAgICAgaXRlbXM6IFtdLFxuICAgICAgfTtcbiAgICAgIGNhdGVnb3JpZXNCeU5hbWVbbmFtZV0gPSBjYXRlZ29yeTtcbiAgICAgIGNhdGVnb3JpZXMucHVzaChjYXRlZ29yeSk7XG4gICAgfVxuICAgIGNhdGVnb3JpZXNCeU5hbWVbbmFtZV0uaXRlbXMucHVzaCh4KTtcbiAgfSk7XG4gIHJldHVybiBjYXRlZ29yaWVzO1xufVxuXG4vKlxuICogQ29tcHV0ZSB0aGUgc3RhbmRhcmQgY2F0ZWdvcml6YXRpb24gb2YgdGhlIGdpdmVuIGlucHV0LCBpbmNsdWRpbmdcbiAqIGJvdGggc2VhcmNoIGNhdGVnb3JpZXMgYW5kIHByZWZpeCBjYXRlZ29yaWVzLlxuICovXG5leHBvcnQgZnVuY3Rpb24gY2F0ZWdvcml6ZSh4czogc3RyaW5nW10sIHF1ZXJ5ID0gJycpOiBSYXdDYXRlZ29yeVtdIHtcbiAgY29uc3QgYnlGaWx0ZXIgPSBbY2F0ZWdvcml6ZUJ5U2VhcmNoUXVlcnkoeHMsIHF1ZXJ5KV07XG4gIGNvbnN0IGJ5UHJlZml4ID0gY2F0ZWdvcml6ZUJ5UHJlZml4KHhzKTtcbiAgcmV0dXJuIFtdLmNvbmNhdChieUZpbHRlciwgYnlQcmVmaXgpO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gY2F0ZWdvcml6ZVRhZ3MoXG4gICAgcnVuVG9UYWc6IFJ1blRvVGFnLFxuICAgIHNlbGVjdGVkUnVuczogc3RyaW5nW10sXG4gICAgcXVlcnk/OiBzdHJpbmcpOiBUYWdDYXRlZ29yeVtdIHtcbiAgY29uc3QgdGFncyA9IHRmX2JhY2tlbmQuZ2V0VGFncyhydW5Ub1RhZyk7XG4gIGNvbnN0IGNhdGVnb3JpZXMgPSBjYXRlZ29yaXplKHRhZ3MsIHF1ZXJ5KTtcbiAgY29uc3QgdGFnVG9SdW5zID0gY3JlYXRlVGFnVG9SdW5zKF8ucGljayhydW5Ub1RhZywgc2VsZWN0ZWRSdW5zKSk7XG5cbiAgcmV0dXJuIGNhdGVnb3JpZXMubWFwKCh7bmFtZSwgbWV0YWRhdGEsIGl0ZW1zfSkgPT4gKHtcbiAgICBuYW1lLFxuICAgIG1ldGFkYXRhLFxuICAgIGl0ZW1zOiBpdGVtcy5tYXAodGFnID0+ICh7XG4gICAgICB0YWcsXG4gICAgICBydW5zOiAodGFnVG9SdW5zLmdldCh0YWcpIHx8IFtdKS5zbGljZSgpLFxuICAgIH0pKSxcbiAgfSkpO1xufVxuXG4vKipcbiAqIENyZWF0ZXMgZ3JvdXBpbmcgb2YgdGhlIGRhdGEgYmFzZWQgb24gc2VsZWN0aW9uIGZyb20gdGYtZGF0YS1zZWxlY3Rvci4gSXRcbiAqIGdyb3VwcyBkYXRhIGJ5IHByZWZpeGVzIG9mIHRhZyBuYW1lcyBhbmQgYnkgdGFnIG5hbWVzLiBFYWNoIGdyb3VwIGNvbnRhaW5zXG4gKiBzZXJpZXMsIGEgdHVwbGUgb2YgZXhwZXJpbWVudCBuYW1lIGFuZCBydW4gbmFtZS5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGNhdGVnb3JpemVTZWxlY3Rpb24oXG4gICAgc2VsZWN0aW9uOiB0Zl9kYXRhX3NlbGVjdG9yLlNlbGVjdGlvbltdLCBwbHVnaW5OYW1lOiBzdHJpbmcpOlxuICAgIFNlcmllc0NhdGVnb3J5W10ge1xuICBjb25zdCB0YWdUb1NlcmllcyA9IG5ldyBNYXA8c3RyaW5nLCBTZXJpZXNbXT4oKTtcbiAgLy8gYHRhZ1RvU2VhcmNoU2VyaWVzYCBjb250YWlucyBzdWJzZXQgb2YgYHRhZ1RvU2VyaWVzYC4gdGFnUmVnZXggaW4gZWFjaFxuICAvLyBzZWxlY3Rpb24gY2FuIG9taXQgc2VyaWVzIGZyb20gYSB0YWcgY2F0ZWdvcnkuXG4gIGNvbnN0IHRhZ1RvU2VhcmNoU2VyaWVzID0gbmV3IE1hcDxzdHJpbmcsIFNlcmllc1tdPigpO1xuICBjb25zdCBzZWFyY2hDYXRlZ29yaWVzID0gW107XG5cbiAgc2VsZWN0aW9uLmZvckVhY2goKHtleHBlcmltZW50LCBydW5zLCB0YWdSZWdleH0pID0+IHtcbiAgICBjb25zdCBydW5OYW1lcyA9IHJ1bnMubWFwKCh7bmFtZX0pID0+IG5hbWUpO1xuICAgIGNvbnN0IHNlbGVjdGVkUnVuVG9UYWcgPSBjcmVhdGVSdW5Ub1RhZ0ZvclBsdWdpbihydW5zLCBwbHVnaW5OYW1lKTtcbiAgICBjb25zdCB0YWdUb1NlbGVjdGVkUnVucyA9IGNyZWF0ZVRhZ1RvUnVucyhzZWxlY3RlZFJ1blRvVGFnKTtcbiAgICBjb25zdCB0YWdzID0gdGZfYmFja2VuZC5nZXRUYWdzKHNlbGVjdGVkUnVuVG9UYWcpO1xuICAgIC8vIGxpc3Qgb2YgYWxsIHRhZ3MgdGhhdCBoYXMgc2VsZWN0ZWQgcnVucy5cbiAgICB0YWdzLmZvckVhY2godGFnID0+IHtcbiAgICAgIGNvbnN0IHNlcmllcyA9IHRhZ1RvU2VyaWVzLmdldCh0YWcpIHx8IFtdO1xuICAgICAgc2VyaWVzLnB1c2goLi4udGFnVG9TZWxlY3RlZFJ1bnMuZ2V0KHRhZylcbiAgICAgICAgICAubWFwKHJ1biA9PiAoe2V4cGVyaW1lbnQsIHJ1biwgdGFnfSkpKTtcbiAgICAgIHRhZ1RvU2VyaWVzLnNldCh0YWcsIHNlcmllcyk7XG4gICAgfSk7XG5cbiAgICBjb25zdCBzZWFyY2hDYXRlZ29yeSA9IGNhdGVnb3JpemVCeVNlYXJjaFF1ZXJ5KHRhZ3MsIHRhZ1JlZ2V4KTtcbiAgICBzZWFyY2hDYXRlZ29yaWVzLnB1c2goc2VhcmNoQ2F0ZWdvcnkpO1xuICAgIC8vIGxpc3Qgb2YgdGFncyBtYXRjaGluZyB0YWdSZWdleCBpbiB0aGUgc2VsZWN0aW9uLlxuICAgIHNlYXJjaENhdGVnb3J5Lml0ZW1zLmZvckVhY2godGFnID0+IHtcbiAgICAgIGNvbnN0IHNlcmllcyA9IHRhZ1RvU2VhcmNoU2VyaWVzLmdldCh0YWcpIHx8IFtdO1xuICAgICAgc2VyaWVzLnB1c2goLi4udGFnVG9TZWxlY3RlZFJ1bnMuZ2V0KHRhZylcbiAgICAgICAgICAubWFwKHJ1biA9PiAoe2V4cGVyaW1lbnQsIHJ1biwgdGFnfSkpKTtcbiAgICAgIHRhZ1RvU2VhcmNoU2VyaWVzLnNldCh0YWcsIHNlcmllcyk7XG4gICAgfSk7XG4gIH0pO1xuXG4gIGNvbnN0IHNlYXJjaENhdGVnb3J5OiBSYXdDYXRlZ29yeSA9IHNlYXJjaENhdGVnb3JpZXMubGVuZ3RoID09IDEgP1xuICAgICAgc2VhcmNoQ2F0ZWdvcmllc1swXSA6XG4gICAgICB7XG4gICAgICAgIG5hbWU6IHNlYXJjaENhdGVnb3JpZXMuZXZlcnkoYyA9PiAhYy5uYW1lKSA/ICcnIDogJ211bHRpJyxcbiAgICAgICAgbWV0YWRhdGE6IHtcbiAgICAgICAgICB0eXBlOiBDYXRlZ29yeVR5cGUuU0VBUkNIX1JFU1VMVFMsXG4gICAgICAgICAgY29tcG9zaXRlU2VhcmNoOiB0cnVlLFxuICAgICAgICAgIHZhbGlkUmVnZXg6IHNlYXJjaENhdGVnb3JpZXMuZXZlcnkoYyA9PiBjLm1ldGFkYXRhLnZhbGlkUmVnZXgpLFxuICAgICAgICAgIHVuaXZlcnNhbFJlZ2V4OiBmYWxzZSxcbiAgICAgICAgfSxcbiAgICAgICAgaXRlbXM6IEFycmF5LmZyb20odGFnVG9TZWFyY2hTZXJpZXMua2V5cygpKVxuICAgICAgICAgICAgLnNvcnQodnpfc29ydGluZy5jb21wYXJlVGFnTmFtZXMpLFxuICAgICAgfTtcblxuICBjb25zdCBzZWFyY2hTZXJpZXNDYXRlZ29yeTogU2VyaWVzQ2F0ZWdvcnkgPSBPYmplY3QuYXNzaWduKFxuICAgIHt9LFxuICAgIHNlYXJjaENhdGVnb3J5LFxuICAgIHtcbiAgICAgIGl0ZW1zOiBzZWFyY2hDYXRlZ29yeS5pdGVtcy5tYXAodGFnID0+ICh7XG4gICAgICAgIHRhZyxcbiAgICAgICAgc2VyaWVzOiB0YWdUb1NlYXJjaFNlcmllcy5nZXQodGFnKSxcbiAgICAgIH0pKSxcbiAgICB9LFxuICApO1xuXG4gIC8vIE9yZ2FuaXplIHRoZSB0YWcgdG8gaXRlbXMgYnkgcHJlZml4LlxuICBjb25zdCBwcmVmaXhDYXRlZ29yaWVzOiBTZXJpZXNDYXRlZ29yeVtdID0gY2F0ZWdvcml6ZUJ5UHJlZml4KFxuICAgICAgQXJyYXkuZnJvbSh0YWdUb1Nlcmllcy5rZXlzKCkpKVxuICAgICAgICAgIC5tYXAoKHtuYW1lLCBtZXRhZGF0YSwgaXRlbXN9KSA9PiAoe1xuICAgICAgICAgICAgbmFtZSxcbiAgICAgICAgICAgIG1ldGFkYXRhLFxuICAgICAgICAgICAgaXRlbXM6IGl0ZW1zLm1hcCh0YWcgPT4gKHtcbiAgICAgICAgICAgICAgdGFnLFxuICAgICAgICAgICAgICBzZXJpZXM6IHRhZ1RvU2VyaWVzLmdldCh0YWcpLFxuICAgICAgICAgICAgfSkpLFxuICAgICAgICAgIH0pKTtcblxuICByZXR1cm4gW1xuICAgIHNlYXJjaFNlcmllc0NhdGVnb3J5LFxuICAgIC4uLnByZWZpeENhdGVnb3JpZXMsXG4gIF07XG59XG5cbmZ1bmN0aW9uIGNyZWF0ZVRhZ1RvUnVucyhydW5Ub1RhZzogUnVuVG9UYWcpOiBNYXA8c3RyaW5nLCBzdHJpbmdbXT4ge1xuICBjb25zdCB0YWdUb1J1biA9IG5ldyBNYXAoKTtcbiAgT2JqZWN0LmtleXMocnVuVG9UYWcpLmZvckVhY2gocnVuID0+IHtcbiAgICBydW5Ub1RhZ1tydW5dLmZvckVhY2godGFnID0+IHtcbiAgICAgIGNvbnN0IHJ1bnMgPSB0YWdUb1J1bi5nZXQodGFnKSB8fCBbXTtcbiAgICAgIHJ1bnMucHVzaChydW4pO1xuICAgICAgdGFnVG9SdW4uc2V0KHRhZywgcnVucyk7XG4gICAgfSk7XG4gIH0pO1xuICByZXR1cm4gdGFnVG9SdW47XG59XG5cbmZ1bmN0aW9uIGNyZWF0ZVJ1blRvVGFnRm9yUGx1Z2luKHJ1bnM6IHRmX2JhY2tlbmQuUnVuW10sIHBsdWdpbk5hbWU6IHN0cmluZyk6XG4gICAgUnVuVG9UYWcge1xuICBjb25zdCBydW5Ub1RhZyA9IHt9O1xuICBydW5zLmZvckVhY2goKHJ1bikgPT4ge1xuICAgIHJ1blRvVGFnW3J1bi5uYW1lXSA9IHJ1bi50YWdzXG4gICAgICAgIC5maWx0ZXIodGFnID0+IHRhZy5wbHVnaW5OYW1lID09IHBsdWdpbk5hbWUpXG4gICAgICAgIC5tYXAoKHtuYW1lfSkgPT4gbmFtZSk7XG4gIH0pXG4gIHJldHVybiBydW5Ub1RhZztcbn1cblxuZnVuY3Rpb24gY29tcGFyZVRhZ1J1bihhLCBiOiB7dGFnOiBzdHJpbmcsIHJ1bjogc3RyaW5nfSk6IG51bWJlciB7XG4gIGNvbnN0IGMgPSB2el9zb3J0aW5nLmNvbXBhcmVUYWdOYW1lcyhhLnRhZywgYi50YWcpO1xuICBpZiAoYyAhPSAwKSB7XG4gICAgcmV0dXJuIGM7XG4gIH1cbiAgcmV0dXJuIHZ6X3NvcnRpbmcuY29tcGFyZVRhZ05hbWVzKGEucnVuLCBiLnJ1bik7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBjYXRlZ29yaXplUnVuVGFnQ29tYmluYXRpb25zKFxuICAgIHJ1blRvVGFnOiBSdW5Ub1RhZyxcbiAgICBzZWxlY3RlZFJ1bnM6IHN0cmluZ1tdLFxuICAgIHF1ZXJ5Pzogc3RyaW5nKTogUnVuVGFnQ2F0ZWdvcnlbXSB7XG4gIGNvbnN0IHRhZ0NhdGVnb3JpZXMgPVxuICAgIGNhdGVnb3JpemVUYWdzKHJ1blRvVGFnLCBzZWxlY3RlZFJ1bnMsIHF1ZXJ5KTtcbiAgZnVuY3Rpb24gZXhwbG9kZUNhdGVnb3J5KHRhZ0NhdGVnb3J5OiBUYWdDYXRlZ29yeSk6IFJ1blRhZ0NhdGVnb3J5IHtcbiAgICBjb25zdCBpdGVtcyA9IF8uZmxhdHRlbih0YWdDYXRlZ29yeS5pdGVtcy5tYXAoXG4gICAgICAoe3RhZywgcnVuc30pID0+IHJ1bnMubWFwKHJ1biA9PiAoe3RhZywgcnVufSkpKSk7XG4gICAgaXRlbXMuc29ydChjb21wYXJlVGFnUnVuKTtcbiAgICByZXR1cm4ge1xuICAgICAgbmFtZTogdGFnQ2F0ZWdvcnkubmFtZSxcbiAgICAgIG1ldGFkYXRhOiB0YWdDYXRlZ29yeS5tZXRhZGF0YSxcbiAgICAgIGl0ZW1zLFxuICAgIH07XG4gIH1cbiAgcmV0dXJuIHRhZ0NhdGVnb3JpZXMubWFwKGV4cGxvZGVDYXRlZ29yeSk7XG59XG5cbn0gIC8vIG5hbWVzcGFjZSB3dGZfY2F0ZWdvcml6YXRpb25fdXRpbHNcbiJdfQ==