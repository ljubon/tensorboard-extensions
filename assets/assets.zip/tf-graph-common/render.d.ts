/**
 * Package for the Render Hierarchy for TensorFlow graph.
 */
declare module tf.graph.render {
    type Point = {
        x: number;
        y: number;
    };
    /**
     * Color parameters for op nodes.
     */
    let OpNodeColors: {
        DEFAULT_FILL: string;
        DEFAULT_STROKE: string;
        COMPATIBLE: string;
        INCOMPATIBLE: string;
    };
    /**
     * Color parameters for node encoding.
     * @type {Object}
     */
    let MetanodeColors: {
        /**
         * Default fill and stroke to use when no other information is available.
         */
        DEFAULT_FILL: string;
        DEFAULT_STROKE: string;
        SATURATION: number;
        LIGHTNESS: number;
        /**
         * Neutral color to use when the node is expanded (used when coloring by
         * compute time, memory and device).
         */
        EXPANDED_COLOR: string;
        /**
         * Standard hue values for node color palette.
         */
        HUES: number[];
        STRUCTURE_PALETTE(id: number, lightened?: boolean): string;
        DEVICE_PALETTE(index: number): string;
        XLA_CLUSTER_PALETTE(index: number): string;
        UNKNOWN: string;
        GRADIENT_OUTLINE: string;
    };
    /**
     * Color parameters for op nodes.
     */
    let SeriesNodeColors: {
        DEFAULT_FILL: string;
        DEFAULT_STROKE: string;
    };
    /**
     * Function that computes edge thickness in pixels.
     */
    interface EdgeThicknessFunction {
        (edgeData: scene.edge.EdgeData, edgeClass: string): number;
    }
    /**
     * Function that computes edge label strings. This function accepts a Metaedge,
     * which could actually encapsulate several base edges. For instance, several
     * base edges may merge into a single metaedge.
     *
     * To determine whether a metaedge represents several edges, check the length of
     * its baseEdgeList property.
     */
    interface EdgeLabelFunction {
        (metaedge: Metaedge, renderInfo: render.RenderGraphInfo): string;
    }
    /**
     * Stores the rendering information, such as x and y coordinates,
     * for each node in the graph.
     */
    class RenderGraphInfo {
        hierarchy: hierarchy.Hierarchy;
        private displayingStats;
        private index;
        private renderedOpNames;
        private deviceColorMap;
        private xlaClusterColorMap;
        private memoryUsageScale;
        private computeTimeScale;
        /** Scale for the thickness of edges when there is no shape information. */
        edgeWidthSizedBasedScale: d3.ScaleLinear<number, number> | d3.ScalePower<number, number>;
        private hasSubhierarchy;
        root: RenderGroupNodeInfo;
        traceInputs: Boolean;
        edgeLabelFunction: EdgeLabelFunction;
        edgeWidthFunction: EdgeThicknessFunction;
        constructor(hierarchy: hierarchy.Hierarchy, displayingStats: boolean);
        computeScales(): void;
        /**
         * Get a previously created RenderNodeInfo by its node name.
         */
        getRenderNodeByName(nodeName: string): RenderNodeInfo;
        /**
         * Get the underlying node in the hierarchical graph by its name.
         */
        getNodeByName(nodeName: string): Node;
        private colorHistogram;
        /**
         * Get a previously created RenderNodeInfo for the specified node name,
         * or create one if it hasn't been created yet.
         */
        getOrCreateRenderNodeByName(nodeName: string): RenderNodeInfo;
        /**
         * Return the nearest ancestor node, including itself, that is visible
         * in the visualization. This method is used so that we can select
         * (highlight) a node that isn't drawn yet, by selecting (highlighting)
         * its nearest ancestor that has been drawn.
         */
        getNearestVisibleAncestor(name: string): string;
        setDepth(depth: number): void;
        /**
         * Returns true if the renderNode is an isolated node within its parent node.
         */
        isNodeAuxiliary(renderNode: RenderNodeInfo): boolean;
        /**
         * Returns a list of ops that have been rendered so far for this graph. More
         * ops may later be rendered if the user expands nodes for instance. The list
         * returned here can only stay the same size or grow on successive calls.
         */
        getNamesOfRenderedOps(): string[];
        /**
         * Clones an op node and adds it to a metagraph. Does nothing if an op node
         * with the same new name has already been created within the metagraph. This
         * method is used when duplicating a library function to be injected within a
         * metanode representing a function call.
         * @param parentMetanode The parent metanode on which to add the new node.
         * @param node The op node to clone.
         * @param newPrefix The prefix string to use in lieu of the one that merely
         *     indicates that the metanode represents a function defined in the
         *     library. This prefix should reflect graph hierarchy.
         * @return The newly created op node (the clone of the original).
         */
        private cloneAndAddFunctionOpNode;
        /**
         * Clones a Metanode that represents a function defined in the graph library.
         * We dynamically inject a clone of a function into a meta graph when the user
         * expands a function call. We cannot do this at the beginning because the
         * functions may recursively call themselves or other functions.
         * @param metagraph The metagraph we are currently rendering the sub-hierarchy
         *     for.
         * @param opNodeToReplace The op node in the graph to replace with a new
         *     (expandable) metanode that visualizes the innards of a function.
         * @param libraryMetanode The metanode for a library function to clone.
         * @param oldPrefix The old prefix to replace (that just reflects how this
         *     node is for a library function).
         * @param newPrefix The prefix string to use in lieu of the one that merely
         *     indicates that the metanode represents a function defined in the
         *     library. This prefix should reflect graph hierarchy.
         */
        private cloneFunctionLibraryMetanode;
        /**
         * A helper subroutine that performs the bulk of the logic for
         * `cloneFunctionLibraryMetanode`.
         * @param metagraph The metagraph we are currently rendering the sub-hierarchy
         *     for.
         * @param opNodeToReplace The op node in the graph to replace with a new
         *     (expandable) metanode that visualizes the innards of a function.
         * @param libraryMetanode The metanode for a library function to clone.
         * @param oldPrefix The old prefix to replace (that just reflects how this
         *     node is for a library function).
         * @param newPrefix The prefix string to use in lieu of the one that merely
         *     indicates that the metanode represents a function defined in the
         *     library. This prefix should reflect graph hierarchy.
         * @param functionOutputIndexToNode A mapping between function output index
         *     and the corresponding output node. Used to connect outputs with
         *     destinations outside of the function metanode.
         */
        private cloneFunctionLibraryMetanodeHelper;
        /**
         * Clones the edges within `libraryMetanode` and adds them to `newMetanode`.
         * The names of edge sources and destinations have their prefixes replaced
         * with new prefixes that reflect their hierarchical positions in the graph
         * instead of within the function library template. This is a subroutine for
         * dynamically injecting a function metanode into the graph.
         */
        private cloneLibraryMetanodeEdges;
        /**
         * When a metanode representing a function is cloned and placed into the
         * graph, we must create edges between inputs into the function call and the
         * input ops within the function. This function performs that patching.
         */
        private patchEdgesIntoFunctionInputs;
        /**
         * When a metanode representing a function is cloned and placed into the
         * graph, we must create edges between output ops within the new function
         * metanode to its successors. This function does that after scanning the
         * successors of the function call.
         */
        private patchEdgesFromFunctionOutputs;
        buildSubhierarchy(nodeName: string): void;
        /**
         * This method builds subhierarchies for function calls that are needed for
         * rendering edges in the current subhierarchy being built.
         *
         * When building subhierarchies for a metagraph M, the subhierarchies of
         * metanodes containing endpoint nodes for edges within metagraph M must
         * already be built. Otherwise, bridge edges will be missing from the graph.
         */
        private buildSubhierarchiesForNeededFunctions;
    }
    /**
     * A class for rendering annotation object which contains label
     * about the node embedded as annotation, type of annotation and the location
     * of both the annotation's node and edge.
     *
     * Annotation objects include embedded constants, embedded summary, and
     * edge shortcuts.
     */
    class Annotation {
        node: Node;
        renderNodeInfo: RenderNodeInfo;
        renderMetaedgeInfo: RenderMetaedgeInfo;
        annotationType: AnnotationType;
        /**
         * Center position of annotation relative to the host
         * node's center x.
         */
        dx: number;
        /**
         * Center position of annotation relative to the host
         * node's center y.
         */
        dy: number;
        width: number;
        height: number;
        /**
         * The names of nodes on either side of this edge.
         */
        v: string;
        w: string;
        /**
         * A flag whether it is an in-annotation (if true) or
         * out-annotation  (if false).
         */
        isIn: boolean;
        /** Label horizontal offset from the end of the node shape */
        labelOffset: number;
        /**
         * Array of points for edges from the annotation to its host
         * node. Each point contains the point location, relative to
         * the host node's center.
         */
        points: {
            dx: number;
            dy: number;
        }[];
        /**
         * Creates a new Annotation.
         *
         * @param node The underlying node this annotation points to.
         * @param renderNodeInfo The render information for the underlying node
         *     this annotation points to. This can be null if the annotation
         *     denotes an embedding (constant, summary), in which case we
         *     use the node property.
         * @param renderMetaedgeInfo The render information for the edge associated
         *     with the annotation.
         * @param type The type of the annotation.
         * @param isIn True if it is an in-annotation. False if it is an
         *     out-annotation.
         */
        constructor(node: Node, renderNodeInfo: RenderNodeInfo, renderMetaedgeInfo: RenderMetaedgeInfo, type: AnnotationType, isIn: boolean);
    }
    enum AnnotationType {
        SHORTCUT = 0,
        CONSTANT = 1,
        SUMMARY = 2,
        ELLIPSIS = 3
    }
    /**
     * Manages a list of annotations. Two will be used for each
     * RenderNodeInfo, one for in annotations and one for out annotations.
     */
    class AnnotationList {
        /**
         * List of visually drawable annotations, may include an ellipses annotation
         * if the number added exceeds the number specified by maxAnnotations.
         */
        list: Annotation[];
        /**
         * Set of nodes which have been added as annotations to this list, so we can
         * prevent duplicates.
         */
        nodeNames: {
            [nodeName: string]: boolean;
        };
        constructor();
        /**
         * Append an annotation to the list, or a stand-in ellipsis annotation instead
         * if this would make it too many.
         */
        push(annotation: Annotation): void;
    }
    /**
     * Contains rendering information about a node in the hierarchical graph.
     */
    class RenderNodeInfo {
        /** Reference to the original underlying Node from the hierarchical graph. */
        node: Node;
        /** Whether the node is expanded or not. */
        expanded: boolean;
        /**
         * List of rendering information about in-annotations like constants and
         * shortcuts to high-degree nodes.
         */
        inAnnotations: AnnotationList;
        /**
         * List of rendering information about out-annotations (e.g. summary nodes)
         */
        outAnnotations: AnnotationList;
        /** Center x position */
        x: number;
        /** Center y position */
        y: number;
        /**
         * Total width of the node's shape, including in- and out-annotations. This
         * property is used by dagre to layout the graph.
         */
        width: number;
        /**
         * Total height of the node's shape, including in- and out-annotations. This
         * property is used by dagre to layout the graph.
         */
        height: number;
        /**
         * Size of the main box of the node, excluding in- and out-annotations. This
         * property is used to draw the rectangle/ellipse shape denoting the node.
         */
        coreBox: {
            width: number;
            height: number;
        };
        /** Width of the bounding box for all in-annotations. */
        inboxWidth: number;
        /** Width of the bounding box for all out-annotations. */
        outboxWidth: number;
        /**
         * Whether the node should be excluded from the scene.
         * This is only used when there are too many items in a series so we only
         * want to include top N ones.
         */
        excluded: boolean;
        /**
         * All bridge nodes are meant to be invisible, but whereas most represent a
         * relationship from the underlying graph hierarchy, some exist solely for
         * layout reasons. Specifically, those bridge nodes which have only structural
         * rendering metaedges.
         */
        structural: boolean;
        /** Label vertical offset from the center of node shape */
        labelOffset: number;
        /** Rectangle radius (for making rounded rectangle) */
        radius: number;
        /** Label height for expanded node. */
        labelHeight: number;
        paddingTop: number;
        paddingLeft: number;
        paddingRight: number;
        paddingBottom: number;
        /**
         * Whether a node is extracted as source-like (having high out-degree or
         * matching predefined in-extract pattern.)
         */
        isInExtract: boolean;
        /**
         * Whether a node is extracted as sink-like (having high in-degree or matching
         * predefined out-extract pattern.)
         */
        isOutExtract: boolean;
        /**
         * Whether a node represents a function template within the library, in which
         * case it should be rendered in a special scene group.
         */
        isLibraryFunction: boolean;
        /**
         * List of (color, proportion) tuples based on the proportion of devices of
         * its children. If this node is an op node, this list will have only one
         * color with proportion 1.0.
         */
        deviceColors: Array<{
            color: string;
            proportion: number;
        }>;
        /**
         * List of (color, proportion) tuples based on the proportion of xlaClusters
         * of its children. If this node is an op node, this list will have only one
         * color with proportion 1.0.
         */
        xlaClusterColors: Array<{
            color: string;
            proportion: number;
        }>;
        /**
         * List of (color, proportion) tuples based on the proportion of compatible
         * nodes of its children. If this node is an op node, this list will have only
         * one color with proportion 1.0.
         */
        compatibilityColors: Array<{
            color: string;
            proportion: number;
        }>;
        /**
         * Color according to the memory usage of this node.
         */
        memoryColor: string;
        /**
         * Color according to the compute time of this node.
         */
        computeTimeColor: string;
        /**
         * Whether this node is faded out. Used when displaying stats.
         */
        isFadedOut: boolean;
        /**
         * The name string used to label the node in the graph.
         */
        displayName: string;
        constructor(node: Node);
        isInCore(): boolean;
    }
    /**
     * Contains rendering information about a Metaedge from the underlying
     * hierarchical graph. It may be from either a metagraph or a bridgegraph.
     */
    class RenderMetaedgeInfo {
        /**
         * Reference to the original underlying Metaedge from the hierarchical graph,
         * if any. This will be null for the edges which connect OpNodes to their
         * embeddings, for example.
         */
        metaedge: Metaedge;
        /**
         * Reference to the adjoining RenderMetaedgeInfo from the parent's
         * coreGraph. This is used during layout to determine the point at which this
         * edge should touch the node's bounding box. This property will be null for
         * edges which terminate at a node on both ends (all non-bridge edges).
         */
        adjoiningMetaedge: RenderMetaedgeInfo;
        /**
         * Most of the time, a RenderMetaedgeInfo object represents a real
         * edge between nodes in the underlying graph structure. But sometimes, an
         * edge only exists for layout purposes. These structural edges are added
         * during buildSubhierarchy() to force dagre.layout() to put bridge nodes
         * at the ends of the flow.
         * @see buildSubhierarchy()
         */
        structural: boolean;
        /**
         * Weight of the edge, used by dagre when deciding how important an edge is.
         * Edges with higher weight are made shorter and straighter. The default
         * dagre uses is 1.
         */
        weight: number;
        /**
         * X and Y coordinate pairs of the points in the path of the edge.
         * @see tf.graph.node.subsceneAdjustPaths
         */
        points: Point[];
        /**
         * D3 selection of the group containing the path that displays this edge.
         */
        edgeGroup: d3.Selection<RenderMetaedgeInfo & any, any, any, any>;
        /** Id of the <marker> used as a start-marker for the edge path. */
        startMarkerId: string;
        /** Id of the <marker> used as an end-marker for the edge path. */
        endMarkerId: string;
        /**
         * Whether this edge is faded out. Used for fading out unused edges when
         * displaying run statistics.
         */
        isFadedOut: boolean;
        constructor(metaedge: Metaedge);
    }
    class RenderGroupNodeInfo extends RenderNodeInfo {
        node: GroupNode;
        /**
         * The core graph is derived from the underlying node's metagraph, minus
         * the extracted source-like and sink-like nodes.
         */
        coreGraph: graphlib.Graph<RenderNodeInfo, RenderMetaedgeInfo>;
        /** Size of the bounding box for a metanode's isolated in-extract children. */
        inExtractBox: {
            width: number;
            height: number;
        };
        /**
         * Size of the bounding box for a metanode's isolated out-extract children.
         */
        outExtractBox: {
            width: number;
            height: number;
        };
        /** Size of the bounding box for the function library. */
        libraryFunctionsBox: {
            width: number;
            height: number;
        };
        /** Array of isolated in-extract nodes. */
        isolatedInExtract: RenderNodeInfo[];
        /** Array of isolated out-extract nodes. */
        isolatedOutExtract: RenderNodeInfo[];
        /** Array of nodes to show in the function library scene group. */
        libraryFunctionsExtract: RenderNodeInfo[];
        constructor(groupNode: GroupNode, graphOptions: graphlib.GraphOptions);
    }
    /**
     * Remove edges from a node, set its isInExtract property to true,
     * and remove the node and move it to isolatedInExtract.
     *
     * If detachAllEdgesForHighDegree or forceDetach is true, extract all of its
     * edges. Otherwise, only remove all out-edges.
     */
    function makeInExtract(renderNode: RenderGroupNodeInfo, n: string, forceDetach?: boolean): void;
    /**
     * Given an integer, picks a hue that is far apart from other colors.
     * The formula for picking color that avoid collision is:
     *     hue = (color range * golden ratio * index) % color range
     */
    function mapIndexToHue(id: number): number;
    /**
     * Expands nodes in the graph until the desired node is visible.
     *
     * @param scene The scene polymer component.
     * @param renderHierarchy The render hierarchy.
     * @param tensorName The name of a tensor.
     * @return A string that is the name of the node representing the given tensor.
     *     Note that the original tensor name might differ from this returned node
     *     name. Specifically, for instance, the tensor name usually ends with an
     *     output slot index (such as :0), while the node name lacks that suffix.
     */
    function expandUntilNodeIsShown(scene: any, renderHierarchy: any, tensorName: string): any;
}
