/* Copyright 2017 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
var tf_dashboard_common;
(function (tf_dashboard_common) {
    Polymer({
        is: 'tf-regex-group',
        properties: {
            rawRegexes: {
                type: Array,
                value: tf_storage.getObjectInitializer('rawRegexes', { defaultValue: [{ regex: '', valid: true }] }),
            },
            regexes: { type: Array, computed: 'usableRegexes(rawRegexes.*)', notify: true },
        },
        observers: [
            'addNewRegexIfNeeded(rawRegexes.*)',
            'checkValidity(rawRegexes.*)',
            '_uriStoreRegexes(rawRegexes.*)',
        ],
        _uriStoreRegexes: tf_storage.getObjectObserver('rawRegexes', { defaultValue: [{ regex: '', valid: true }] }),
        checkValidity: function (x) {
            var match = x.path.match(/rawRegexes\.(\d+)\.regex/);
            if (match) {
                var idx = match[1];
                this.set('rawRegexes.' + idx + '.valid', this.isValid(x.value));
            }
        },
        isValid: function (s) {
            try {
                new RegExp(s);
                return true;
            }
            catch (e) {
                return false;
            }
        },
        usableRegexes: function (regexes) {
            var isValid = this.isValid;
            return regexes.base
                .filter(function (r) {
                // Checking validity here (rather than using the data property)
                // is necessary because otherwise we might send invalid regexes due
                // to the fact that this function can call before the observer does
                return r.regex !== '' && isValid(r.regex);
            })
                .map(function (r) {
                return r.regex;
            });
        },
        addNewRegexIfNeeded: function () {
            var last = this.rawRegexes[this.rawRegexes.length - 1];
            if (last.regex !== '') {
                this.push('rawRegexes', { regex: '', valid: true });
            }
        },
        deleteRegex: function (e) {
            if (this.rawRegexes.length > 1) {
                this.splice('rawRegexes', e.model.index, 1);
            }
        },
        moveFocus: function (e) {
            if (e.keyCode === 13) {
                var idx = e.model.index;
                var inputs = Polymer.dom(this.root).querySelectorAll('.regex-input');
                if (idx < this.rawRegexes.length - 1) {
                    inputs[idx + 1].$.input.focus();
                }
                else {
                    document.activeElement.blur();
                }
            }
        }
    });
})(tf_dashboard_common || (tf_dashboard_common = {})); // namespace tf_dashboard_common
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGYtcmVnZXgtZ3JvdXAuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJ0Zi1yZWdleC1ncm91cC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7Ozs7Ozs7OztnRkFhZ0Y7QUFDaEYsSUFBVSxtQkFBbUIsQ0EwRTVCO0FBMUVELFdBQVUsbUJBQW1CO0lBRTdCLE9BQU8sQ0FBQztRQUNOLEVBQUUsRUFBRSxnQkFBZ0I7UUFDcEIsVUFBVSxFQUFFO1lBQ1YsVUFBVSxFQUFFO2dCQUNWLElBQUksRUFBRSxLQUFLO2dCQUNYLEtBQUssRUFBRSxVQUFVLENBQUMsb0JBQW9CLENBQ2xDLFlBQVksRUFDWixFQUFDLFlBQVksRUFBRSxDQUFDLEVBQUMsS0FBSyxFQUFFLEVBQUUsRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFDLENBQUMsRUFBQyxDQUFDO2FBQ2hEO1lBQ0QsT0FBTyxFQUNILEVBQUMsSUFBSSxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUUsNkJBQTZCLEVBQUUsTUFBTSxFQUFFLElBQUksRUFBQztTQUN6RTtRQUNELFNBQVMsRUFBRTtZQUNULG1DQUFtQztZQUNuQyw2QkFBNkI7WUFDN0IsZ0NBQWdDO1NBQ2pDO1FBQ0QsZ0JBQWdCLEVBQUUsVUFBVSxDQUFDLGlCQUFpQixDQUMxQyxZQUFZLEVBQ1osRUFBQyxZQUFZLEVBQUUsQ0FBQyxFQUFDLEtBQUssRUFBRSxFQUFFLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBQyxDQUFDLEVBQUMsQ0FBQztRQUMvQyxhQUFhLEVBQUUsVUFBUyxDQUFDO1lBQ3ZCLElBQUksS0FBSyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLDBCQUEwQixDQUFDLENBQUM7WUFDckQsSUFBSSxLQUFLLEVBQUU7Z0JBQ1QsSUFBSSxHQUFHLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNuQixJQUFJLENBQUMsR0FBRyxDQUFDLGFBQWEsR0FBRyxHQUFHLEdBQUcsUUFBUSxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7YUFDakU7UUFDSCxDQUFDO1FBQ0QsT0FBTyxFQUFFLFVBQVMsQ0FBQztZQUNqQixJQUFJO2dCQUNGLElBQUksTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNkLE9BQU8sSUFBSSxDQUFDO2FBQ2I7WUFBQyxPQUFPLENBQUMsRUFBRTtnQkFDVixPQUFPLEtBQUssQ0FBQzthQUNkO1FBQ0gsQ0FBQztRQUNELGFBQWEsRUFBRSxVQUFTLE9BQU87WUFDN0IsSUFBSSxPQUFPLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQztZQUMzQixPQUFPLE9BQU8sQ0FBQyxJQUFJO2lCQUNkLE1BQU0sQ0FBQyxVQUFTLENBQUM7Z0JBQ2hCLCtEQUErRDtnQkFDL0QsbUVBQW1FO2dCQUNuRSxtRUFBbUU7Z0JBQ25FLE9BQU8sQ0FBQyxDQUFDLEtBQUssS0FBSyxFQUFFLElBQUksT0FBTyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUM1QyxDQUFDLENBQUM7aUJBQ0QsR0FBRyxDQUFDLFVBQVMsQ0FBQztnQkFDYixPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUM7WUFDakIsQ0FBQyxDQUFDLENBQUM7UUFDVCxDQUFDO1FBQ0QsbUJBQW1CLEVBQUU7WUFDbkIsSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQztZQUN2RCxJQUFJLElBQUksQ0FBQyxLQUFLLEtBQUssRUFBRSxFQUFFO2dCQUNyQixJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksRUFBRSxFQUFDLEtBQUssRUFBRSxFQUFFLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBQyxDQUFDLENBQUM7YUFDbkQ7UUFDSCxDQUFDO1FBQ0QsV0FBVyxFQUFFLFVBQVMsQ0FBQztZQUNyQixJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtnQkFDOUIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxZQUFZLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLEVBQUUsQ0FBQyxDQUFDLENBQUM7YUFDN0M7UUFDSCxDQUFDO1FBQ0QsU0FBUyxFQUFFLFVBQVMsQ0FBQztZQUNuQixJQUFJLENBQUMsQ0FBQyxPQUFPLEtBQUssRUFBRSxFQUFFO2dCQUNwQixJQUFJLEdBQUcsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQztnQkFDeEIsSUFBSSxNQUFNLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsZ0JBQWdCLENBQUMsY0FBYyxDQUFDLENBQUM7Z0JBQ3JFLElBQUksR0FBRyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtvQkFDbkMsTUFBTSxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssRUFBRSxDQUFDO2lCQUMxQztxQkFBTTtvQkFDSixRQUFRLENBQUMsYUFBNkIsQ0FBQyxJQUFJLEVBQUUsQ0FBQztpQkFDaEQ7YUFDRjtRQUNILENBQUM7S0FDRixDQUFDLENBQUM7QUFFSCxDQUFDLEVBMUVTLG1CQUFtQixLQUFuQixtQkFBbUIsUUEwRTVCLENBQUUsZ0NBQWdDIiwic291cmNlc0NvbnRlbnQiOlsiLyogQ29weXJpZ2h0IDIwMTcgVGhlIFRlbnNvckZsb3cgQXV0aG9ycy4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cblxuTGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlLCBWZXJzaW9uIDIuMCAodGhlIFwiTGljZW5zZVwiKTtcbnlvdSBtYXkgbm90IHVzZSB0aGlzIGZpbGUgZXhjZXB0IGluIGNvbXBsaWFuY2Ugd2l0aCB0aGUgTGljZW5zZS5cbllvdSBtYXkgb2J0YWluIGEgY29weSBvZiB0aGUgTGljZW5zZSBhdFxuXG4gICAgaHR0cDovL3d3dy5hcGFjaGUub3JnL2xpY2Vuc2VzL0xJQ0VOU0UtMi4wXG5cblVubGVzcyByZXF1aXJlZCBieSBhcHBsaWNhYmxlIGxhdyBvciBhZ3JlZWQgdG8gaW4gd3JpdGluZywgc29mdHdhcmVcbmRpc3RyaWJ1dGVkIHVuZGVyIHRoZSBMaWNlbnNlIGlzIGRpc3RyaWJ1dGVkIG9uIGFuIFwiQVMgSVNcIiBCQVNJUyxcbldJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWSBLSU5ELCBlaXRoZXIgZXhwcmVzcyBvciBpbXBsaWVkLlxuU2VlIHRoZSBMaWNlbnNlIGZvciB0aGUgc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nIHBlcm1pc3Npb25zIGFuZFxubGltaXRhdGlvbnMgdW5kZXIgdGhlIExpY2Vuc2UuXG49PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0qL1xubmFtZXNwYWNlIHRmX2Rhc2hib2FyZF9jb21tb24ge1xuXG5Qb2x5bWVyKHtcbiAgaXM6ICd0Zi1yZWdleC1ncm91cCcsXG4gIHByb3BlcnRpZXM6IHtcbiAgICByYXdSZWdleGVzOiB7XG4gICAgICB0eXBlOiBBcnJheSxcbiAgICAgIHZhbHVlOiB0Zl9zdG9yYWdlLmdldE9iamVjdEluaXRpYWxpemVyKFxuICAgICAgICAgICdyYXdSZWdleGVzJyxcbiAgICAgICAgICB7ZGVmYXVsdFZhbHVlOiBbe3JlZ2V4OiAnJywgdmFsaWQ6IHRydWV9XX0pLFxuICAgIH0sXG4gICAgcmVnZXhlczpcbiAgICAgICAge3R5cGU6IEFycmF5LCBjb21wdXRlZDogJ3VzYWJsZVJlZ2V4ZXMocmF3UmVnZXhlcy4qKScsIG5vdGlmeTogdHJ1ZX0sXG4gIH0sXG4gIG9ic2VydmVyczogW1xuICAgICdhZGROZXdSZWdleElmTmVlZGVkKHJhd1JlZ2V4ZXMuKiknLFxuICAgICdjaGVja1ZhbGlkaXR5KHJhd1JlZ2V4ZXMuKiknLFxuICAgICdfdXJpU3RvcmVSZWdleGVzKHJhd1JlZ2V4ZXMuKiknLFxuICBdLFxuICBfdXJpU3RvcmVSZWdleGVzOiB0Zl9zdG9yYWdlLmdldE9iamVjdE9ic2VydmVyKFxuICAgICAgJ3Jhd1JlZ2V4ZXMnLFxuICAgICAge2RlZmF1bHRWYWx1ZTogW3tyZWdleDogJycsIHZhbGlkOiB0cnVlfV19KSxcbiAgY2hlY2tWYWxpZGl0eTogZnVuY3Rpb24oeCkge1xuICAgIHZhciBtYXRjaCA9IHgucGF0aC5tYXRjaCgvcmF3UmVnZXhlc1xcLihcXGQrKVxcLnJlZ2V4Lyk7XG4gICAgaWYgKG1hdGNoKSB7XG4gICAgICB2YXIgaWR4ID0gbWF0Y2hbMV07XG4gICAgICB0aGlzLnNldCgncmF3UmVnZXhlcy4nICsgaWR4ICsgJy52YWxpZCcsIHRoaXMuaXNWYWxpZCh4LnZhbHVlKSk7XG4gICAgfVxuICB9LFxuICBpc1ZhbGlkOiBmdW5jdGlvbihzKSB7XG4gICAgdHJ5IHtcbiAgICAgIG5ldyBSZWdFeHAocyk7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICB9LFxuICB1c2FibGVSZWdleGVzOiBmdW5jdGlvbihyZWdleGVzKSB7XG4gICAgdmFyIGlzVmFsaWQgPSB0aGlzLmlzVmFsaWQ7XG4gICAgcmV0dXJuIHJlZ2V4ZXMuYmFzZVxuICAgICAgICAuZmlsdGVyKGZ1bmN0aW9uKHIpIHtcbiAgICAgICAgICAvLyBDaGVja2luZyB2YWxpZGl0eSBoZXJlIChyYXRoZXIgdGhhbiB1c2luZyB0aGUgZGF0YSBwcm9wZXJ0eSlcbiAgICAgICAgICAvLyBpcyBuZWNlc3NhcnkgYmVjYXVzZSBvdGhlcndpc2Ugd2UgbWlnaHQgc2VuZCBpbnZhbGlkIHJlZ2V4ZXMgZHVlXG4gICAgICAgICAgLy8gdG8gdGhlIGZhY3QgdGhhdCB0aGlzIGZ1bmN0aW9uIGNhbiBjYWxsIGJlZm9yZSB0aGUgb2JzZXJ2ZXIgZG9lc1xuICAgICAgICAgIHJldHVybiByLnJlZ2V4ICE9PSAnJyAmJiBpc1ZhbGlkKHIucmVnZXgpO1xuICAgICAgICB9KVxuICAgICAgICAubWFwKGZ1bmN0aW9uKHIpIHtcbiAgICAgICAgICByZXR1cm4gci5yZWdleDtcbiAgICAgICAgfSk7XG4gIH0sXG4gIGFkZE5ld1JlZ2V4SWZOZWVkZWQ6IGZ1bmN0aW9uKCkge1xuICAgIHZhciBsYXN0ID0gdGhpcy5yYXdSZWdleGVzW3RoaXMucmF3UmVnZXhlcy5sZW5ndGggLSAxXTtcbiAgICBpZiAobGFzdC5yZWdleCAhPT0gJycpIHtcbiAgICAgIHRoaXMucHVzaCgncmF3UmVnZXhlcycsIHtyZWdleDogJycsIHZhbGlkOiB0cnVlfSk7XG4gICAgfVxuICB9LFxuICBkZWxldGVSZWdleDogZnVuY3Rpb24oZSkge1xuICAgIGlmICh0aGlzLnJhd1JlZ2V4ZXMubGVuZ3RoID4gMSkge1xuICAgICAgdGhpcy5zcGxpY2UoJ3Jhd1JlZ2V4ZXMnLCBlLm1vZGVsLmluZGV4LCAxKTtcbiAgICB9XG4gIH0sXG4gIG1vdmVGb2N1czogZnVuY3Rpb24oZSkge1xuICAgIGlmIChlLmtleUNvZGUgPT09IDEzKSB7XG4gICAgICB2YXIgaWR4ID0gZS5tb2RlbC5pbmRleDtcbiAgICAgIHZhciBpbnB1dHMgPSBQb2x5bWVyLmRvbSh0aGlzLnJvb3QpLnF1ZXJ5U2VsZWN0b3JBbGwoJy5yZWdleC1pbnB1dCcpO1xuICAgICAgaWYgKGlkeCA8IHRoaXMucmF3UmVnZXhlcy5sZW5ndGggLSAxKSB7XG4gICAgICAgIChpbnB1dHNbaWR4ICsgMV0gYXMgYW55KS4kLmlucHV0LmZvY3VzKCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICAoZG9jdW1lbnQuYWN0aXZlRWxlbWVudCBhcyBIVE1MRWxlbWVudCkuYmx1cigpO1xuICAgICAgfVxuICAgIH1cbiAgfVxufSk7XG5cbn0gIC8vIG5hbWVzcGFjZSB0Zl9kYXNoYm9hcmRfY29tbW9uXG4iXX0=