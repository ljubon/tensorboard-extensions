/* Copyright 2018 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
var vz_line_chart2;
(function (vz_line_chart2) {
    var TooltipColumnEvalType;
    (function (TooltipColumnEvalType) {
        TooltipColumnEvalType[TooltipColumnEvalType["TEXT"] = 0] = "TEXT";
        TooltipColumnEvalType[TooltipColumnEvalType["DOM"] = 1] = "DOM";
    })(TooltipColumnEvalType || (TooltipColumnEvalType = {}));
    /**
     * The maximum number of marker symbols within any line for a data series. Too
     * many markers clutter the chart.
     */
    var _MAX_MARKERS = 20;
    var LineChart = /** @class */ (function () {
        function LineChart(xComponentsCreationMethod, yValueAccessor, yScaleType, colorScale, tooltip, tooltipColumns, fillArea, defaultXRange, defaultYRange, symbolFunction, xAxisFormatter) {
            this.seriesNames = [];
            this.name2datasets = {};
            this.colorScale = colorScale;
            this.tooltip = tooltip;
            this.datasets = [];
            this._ignoreYOutliers = false;
            // lastPointDataset is a dataset that contains just the last point of
            // every dataset we're currently drawing.
            this.lastPointsDataset = new Plottable.Dataset();
            this.nanDataset = new Plottable.Dataset();
            this.yValueAccessor = yValueAccessor;
            // The symbol function maps series to marker. It uses a special dataset that
            // varies based on whether smoothing is enabled.
            this.symbolFunction = symbolFunction;
            // need to do a single bind, so we can deregister the callback from
            // old Plottable.Datasets. (Deregistration is done by identity checks.)
            this.onDatasetChanged = this._onDatasetChanged.bind(this);
            this._defaultXRange = defaultXRange;
            this._defaultYRange = defaultYRange;
            this.tooltipColumns = tooltipColumns;
            this.buildChart(xComponentsCreationMethod, yValueAccessor, yScaleType, fillArea, xAxisFormatter);
        }
        LineChart.prototype.buildChart = function (xComponentsCreationMethod, yValueAccessor, yScaleType, fillArea, xAxisFormatter) {
            var _this = this;
            this.destroy();
            var xComponents = xComponentsCreationMethod();
            this.xAccessor = xComponents.accessor;
            this.xScale = xComponents.scale;
            this.xAxis = xComponents.axis;
            this.xAxis.margin(0).tickLabelPadding(3);
            if (xAxisFormatter) {
                this.xAxis.formatter(xAxisFormatter);
            }
            this.yScale = LineChart.getYScaleFromType(yScaleType);
            this.yAxis = new Plottable.Axes.Numeric(this.yScale, 'left');
            var yFormatter = vz_chart_helpers.multiscaleFormatter(vz_chart_helpers.Y_AXIS_FORMATTER_PRECISION);
            this.yAxis.margin(0).tickLabelPadding(5).formatter(yFormatter);
            this.yAxis.usesTextWidthApproximation(true);
            this.fillArea = fillArea;
            var panZoomLayer = new vz_line_chart2.PanZoomDragLayer(this.xScale, this.yScale, function () { return _this.resetDomain(); });
            this.tooltipInteraction = this.createTooltipInteraction(panZoomLayer);
            this.tooltipPointsComponent = new Plottable.Component();
            var plot = this.buildPlot(this.xScale, this.yScale, fillArea);
            this.gridlines =
                new Plottable.Components.Gridlines(this.xScale, this.yScale);
            var xZeroLine = new Plottable.Components.GuideLineLayer('horizontal');
            xZeroLine.scale(this.yScale).value(0);
            var yZeroLine = new Plottable.Components.GuideLineLayer('vertical');
            yZeroLine.scale(this.xScale).value(0);
            this.center = new Plottable.Components.Group([
                this.gridlines, xZeroLine, yZeroLine, plot,
                panZoomLayer, this.tooltipPointsComponent
            ]);
            this.center.addClass('main');
            this.outer = new Plottable.Components.Table([[this.yAxis, this.center], [null, this.xAxis]]);
        };
        LineChart.prototype.buildPlot = function (xScale, yScale, fillArea) {
            var _this = this;
            if (fillArea) {
                this.marginAreaPlot = new Plottable.Plots.Area();
                this.marginAreaPlot.x(this.xAccessor, xScale);
                this.marginAreaPlot.y(fillArea.higherAccessor, yScale);
                this.marginAreaPlot.y0(fillArea.lowerAccessor);
                this.marginAreaPlot.attr('fill', function (d, i, dataset) {
                    return _this.colorScale.scale(dataset.metadata().name);
                });
                this.marginAreaPlot.attr('fill-opacity', 0.3);
                this.marginAreaPlot.attr('stroke-width', 0);
            }
            this.smoothedAccessor = function (d) { return d.smoothed; };
            var linePlot = new Plottable.Plots.Line();
            linePlot.x(this.xAccessor, xScale);
            linePlot.y(this.yValueAccessor, yScale);
            linePlot.attr('stroke', function (d, i, dataset) {
                return _this.colorScale.scale(dataset.metadata().name);
            });
            this.linePlot = linePlot;
            this.setupTooltips(linePlot);
            var smoothLinePlot = new Plottable.Plots.Line();
            smoothLinePlot.x(this.xAccessor, xScale);
            smoothLinePlot.y(this.smoothedAccessor, yScale);
            smoothLinePlot.attr('stroke', function (d, i, dataset) {
                return _this.colorScale.scale(dataset.metadata().name);
            });
            this.smoothLinePlot = smoothLinePlot;
            if (this.symbolFunction) {
                var markersScatterPlot = new Plottable.Plots.Scatter();
                markersScatterPlot.x(this.xAccessor, xScale);
                markersScatterPlot.y(this.yValueAccessor, yScale);
                markersScatterPlot.attr('fill', function (d, i, dataset) {
                    return _this.colorScale.scale(dataset.metadata().name);
                });
                markersScatterPlot.attr('opacity', 1);
                markersScatterPlot.size(vz_chart_helpers.TOOLTIP_CIRCLE_SIZE * 2);
                markersScatterPlot.symbol(function (d, i, dataset) {
                    return _this.symbolFunction(dataset.metadata().name);
                });
                // Use a special dataset because this scatter plot should use the accesor
                // that depends on whether smoothing is enabled.
                this.markersScatterPlot = markersScatterPlot;
            }
            // The scatterPlot will display the last point for each dataset.
            // This way, if there is only one datum for the series, it is still
            // visible. We hide it when tooltips are active to keep things clean.
            var scatterPlot = new Plottable.Plots.Scatter();
            scatterPlot.x(this.xAccessor, xScale);
            scatterPlot.y(this.yValueAccessor, yScale);
            scatterPlot.attr('fill', function (d) { return _this.colorScale.scale(d.name); });
            scatterPlot.attr('opacity', 1);
            scatterPlot.size(vz_chart_helpers.TOOLTIP_CIRCLE_SIZE * 2);
            scatterPlot.datasets([this.lastPointsDataset]);
            this.scatterPlot = scatterPlot;
            var nanDisplay = new Plottable.Plots.Scatter();
            nanDisplay.x(this.xAccessor, xScale);
            nanDisplay.y(function (x) { return x.displayY; }, yScale);
            nanDisplay.attr('fill', function (d) { return _this.colorScale.scale(d.name); });
            nanDisplay.attr('opacity', 1);
            nanDisplay.size(vz_chart_helpers.NAN_SYMBOL_SIZE * 2);
            nanDisplay.datasets([this.nanDataset]);
            nanDisplay.symbol(Plottable.SymbolFactories.triangle);
            this.nanDisplay = nanDisplay;
            var groups = [nanDisplay, scatterPlot, smoothLinePlot, linePlot];
            if (this.marginAreaPlot) {
                groups.push(this.marginAreaPlot);
            }
            if (this.markersScatterPlot) {
                groups.push(this.markersScatterPlot);
            }
            return new Plottable.Components.Group(groups);
        };
        /** Updates the chart when a dataset changes. Called every time the data of
         * a dataset changes to update the charts.
         */
        LineChart.prototype._onDatasetChanged = function (dataset) {
            if (this.smoothingEnabled) {
                this.resmoothDataset(dataset);
            }
            this.updateSpecialDatasets();
        };
        LineChart.prototype.ignoreYOutliers = function (ignoreYOutliers) {
            if (ignoreYOutliers !== this._ignoreYOutliers) {
                this._ignoreYOutliers = ignoreYOutliers;
                this.updateSpecialDatasets();
                this.resetYDomain();
            }
        };
        /** Constructs special datasets. Each special dataset contains exceptional
         * values from all of the regular datasets, e.g. last points in series, or
         * NaN values. Those points will have a `name` and `relative` property added
         * (since usually those are context in the surrounding dataset).
         */
        LineChart.prototype.updateSpecialDatasets = function () {
            var accessor = this.getYAxisAccessor();
            var lastPointsData = this.datasets
                .map(function (d) {
                var datum = null;
                // filter out NaNs to ensure last point is a clean one
                var nonNanData = d.data().filter(function (x) { return !isNaN(accessor(x, -1, d)); });
                if (nonNanData.length > 0) {
                    var idx = nonNanData.length - 1;
                    datum = nonNanData[idx];
                    datum.name = d.metadata().name;
                    datum.relative = vz_chart_helpers.relativeAccessor(datum, -1, d);
                }
                return datum;
            })
                .filter(function (x) { return x != null; });
            this.lastPointsDataset.data(lastPointsData);
            if (this.markersScatterPlot) {
                this.markersScatterPlot.datasets(this.datasets.map(this.createSampledDatasetForMarkers));
            }
            // Take a dataset, return an array of NaN data points
            // the NaN points will have a "displayY" property which is the
            // y-value of a nearby point that was not NaN (0 if all points are NaN)
            var datasetToNaNData = function (d) {
                var displayY = null;
                var data = d.data();
                var i = 0;
                while (i < data.length && displayY == null) {
                    if (!isNaN(accessor(data[i], -1, d))) {
                        displayY = accessor(data[i], -1, d);
                    }
                    i++;
                }
                if (displayY == null) {
                    displayY = 0;
                }
                var nanData = [];
                for (i = 0; i < data.length; i++) {
                    if (!isNaN(accessor(data[i], -1, d))) {
                        displayY = accessor(data[i], -1, d);
                    }
                    else {
                        data[i].name = d.metadata().name;
                        data[i].displayY = displayY;
                        data[i].relative = vz_chart_helpers.relativeAccessor(data[i], -1, d);
                        nanData.push(data[i]);
                    }
                }
                return nanData;
            };
            var nanData = _.flatten(this.datasets.map(datasetToNaNData));
            this.nanDataset.data(nanData);
        };
        LineChart.prototype.resetDomain = function () {
            this.resetXDomain();
            this.resetYDomain();
        };
        LineChart.prototype.resetXDomain = function () {
            var xDomain;
            if (this._defaultXRange != null) {
                // Use the range specified by the caller.
                xDomain = this._defaultXRange;
            }
            else {
                // (Copied from vz_line_chart.DragZoomLayer.unzoom.)
                var xScale = this.xScale;
                xScale._domainMin = null;
                xScale._domainMax = null;
                xDomain = xScale._getExtent();
            }
            this.xScale.domain(xDomain);
        };
        LineChart.prototype.resetYDomain = function () {
            var yDomain;
            if (this._defaultYRange != null) {
                // Use the range specified by the caller.
                yDomain = this._defaultYRange;
            }
            else {
                // Generate a reasonable range.
                var accessors_1 = this.getAccessorsForComputingYRange();
                var datasetToValues = function (d) {
                    return accessors_1.map(function (accessor) { return d.data().map(function (x) { return accessor(x, -1, d); }); });
                };
                var vals = _.flattenDeep(this.datasets.map(datasetToValues))
                    .filter(isFinite);
                yDomain = vz_chart_helpers.computeDomain(vals, this._ignoreYOutliers);
            }
            this.yScale.domain(yDomain);
        };
        LineChart.prototype.getAccessorsForComputingYRange = function () {
            var accessors = [this.getYAxisAccessor()];
            if (this.fillArea) {
                // Make the Y domain take margins into account.
                accessors.push(this.fillArea.lowerAccessor, this.fillArea.higherAccessor);
            }
            return accessors;
        };
        LineChart.prototype.getYAxisAccessor = function () {
            return this.smoothingEnabled ? this.smoothedAccessor : this.yValueAccessor;
        };
        LineChart.prototype.createTooltipInteraction = function (pzdl) {
            var _this = this;
            var pi = new Plottable.Interactions.Pointer();
            // Disable interaction while drag zooming.
            var disableTooltipUpdate = function () {
                pi.enabled(false);
                _this.hideTooltips();
            };
            var enableTooltipUpdate = function () { return pi.enabled(true); };
            pzdl.onPanStart(disableTooltipUpdate);
            pzdl.onDragZoomStart(disableTooltipUpdate);
            pzdl.onPanEnd(enableTooltipUpdate);
            pzdl.onDragZoomEnd(enableTooltipUpdate);
            // When using wheel, cursor position does not change. Redraw the tooltip
            // using the last known mouse position.
            pzdl.onScrollZoom(function () { return _this.updateTooltipContent(_this._lastMousePosition); });
            pi.onPointerMove(function (p) {
                _this._lastMousePosition = p;
                _this.updateTooltipContent(p);
            });
            pi.onPointerExit(function () { return _this.hideTooltips(); });
            return pi;
        };
        LineChart.prototype.updateTooltipContent = function (p) {
            var _this = this;
            // Line plot must be initialized to draw.
            if (!this.linePlot)
                return;
            window.cancelAnimationFrame(this._tooltipUpdateAnimationFrame);
            this._tooltipUpdateAnimationFrame = window.requestAnimationFrame(function () {
                var target = {
                    x: p.x,
                    y: p.y,
                    datum: null,
                    dataset: null,
                };
                var bbox = _this.gridlines.content().node().getBBox();
                // pts is the closets point to the tooltip for each dataset
                var pts = _this.linePlot.datasets()
                    .map(function (dataset) { return _this.findClosestPoint(target, dataset); })
                    .filter(Boolean);
                var intersectsBBox = Plottable.Utils.DOM.intersectsBBox;
                // We draw tooltips for points that are NaN, or are currently visible
                var ptsForTooltips = pts.filter(function (p) { return intersectsBBox(p.x, p.y, bbox) ||
                    isNaN(_this.yValueAccessor(p.datum, 0, p.dataset)); });
                // Only draw little indicator circles for the non-NaN points
                var ptsToCircle = ptsForTooltips.filter(function (p) { return !isNaN(_this.yValueAccessor(p.datum, 0, p.dataset)); });
                if (pts.length !== 0) {
                    _this.scatterPlot.attr('display', 'none');
                    var ptsSelection = _this.tooltipPointsComponent.content().selectAll('.point').data(ptsToCircle, function (p) { return p.dataset.metadata().name; });
                    ptsSelection.enter().append('circle').classed('point', true);
                    ptsSelection.attr('r', vz_chart_helpers.TOOLTIP_CIRCLE_SIZE)
                        .attr('cx', function (p) { return p.x; })
                        .attr('cy', function (p) { return p.y; })
                        .style('stroke', 'none')
                        .attr('fill', function (p) { return _this.colorScale.scale(p.dataset.metadata().name); });
                    ptsSelection.exit().remove();
                    _this.drawTooltips(ptsForTooltips, target, _this.tooltipColumns);
                }
                else {
                    _this.hideTooltips();
                }
            });
        };
        LineChart.prototype.hideTooltips = function () {
            window.cancelAnimationFrame(this._tooltipUpdateAnimationFrame);
            this.tooltip.hide();
            this.scatterPlot.attr('display', 'block');
            this.tooltipPointsComponent.content().selectAll('.point').remove();
        };
        LineChart.prototype.setupTooltips = function (plot) {
            var _this = this;
            plot.onDetach(function () {
                _this.tooltipInteraction.detachFrom(plot);
                _this.tooltipInteraction.enabled(false);
            });
            plot.onAnchor(function () {
                _this.tooltipInteraction.attachTo(plot);
                _this.tooltipInteraction.enabled(true);
            });
        };
        LineChart.prototype.drawTooltips = function (points, target, tooltipColumns) {
            var _this = this;
            if (!points.length) {
                this.tooltip.hide();
                return;
            }
            var colorScale = this.colorScale;
            var swatchCol = {
                title: '',
                static: false,
                evalType: TooltipColumnEvalType.DOM,
                evaluate: function (d) {
                    d3.select(this)
                        .select('span')
                        .style('background-color', function () { return colorScale.scale(d.dataset.metadata().name); });
                    return '';
                },
                enter: function (d) {
                    d3.select(this)
                        .append('span')
                        .classed('swatch', true)
                        .style('background-color', function () { return colorScale.scale(d.dataset.metadata().name); });
                },
            };
            tooltipColumns = [swatchCol].concat(tooltipColumns);
            // Formatters for value, step, and wall_time
            var valueFormatter = vz_chart_helpers.multiscaleFormatter(vz_chart_helpers.Y_TOOLTIP_FORMATTER_PRECISION);
            var dist = function (p) {
                return Math.pow(p.x - target.x, 2) + Math.pow(p.y - target.y, 2);
            };
            var closestDist = _.min(points.map(dist));
            var valueSortMethod = this.smoothingEnabled ?
                this.smoothedAccessor : this.yValueAccessor;
            if (this.tooltipSortingMethod === 'ascending') {
                points = _.sortBy(points, function (d) { return valueSortMethod(d.datum, -1, d.dataset); });
            }
            else if (this.tooltipSortingMethod === 'descending') {
                points = _.sortBy(points, function (d) { return valueSortMethod(d.datum, -1, d.dataset); })
                    .reverse();
            }
            else if (this.tooltipSortingMethod === 'nearest') {
                points = _.sortBy(points, dist);
            }
            else {
                // The 'default' sorting method maintains the order of names passed to
                // setVisibleSeries(). However we reverse that order when defining the
                // datasets. So we must call reverse again to restore the order.
                points = points.slice(0).reverse();
            }
            var self = this;
            var table = d3.select(this.tooltip.content()).select('table');
            var header = table.select('thead')
                .selectAll('th')
                .data(tooltipColumns, function (column, _, __) {
                return column.title;
            });
            var newHeaderNodes = header.enter()
                .append('th')
                .text(function (col) { return col.title; })
                .nodes();
            header.exit().remove();
            var rows = table.select('tbody')
                .selectAll('tr')
                .data(points, function (pt, _, __) {
                return pt.dataset.metadata().name;
            });
            rows.classed('distant', function (d) {
                // Grey out the point if any of the following are true:
                // - The cursor is outside of the x-extent of the dataset
                // - The point's y value is NaN
                var firstPoint = d.dataset.data()[0];
                var lastPoint = _.last(d.dataset.data());
                var firstX = _this.xScale.scale(_this.xAccessor(firstPoint, 0, d.dataset));
                var lastX = _this.xScale.scale(_this.xAccessor(lastPoint, 0, d.dataset));
                var s = _this.smoothingEnabled ?
                    d.datum.smoothed : _this.yValueAccessor(d.datum, 0, d.dataset);
                return target.x < firstX || target.x > lastX || isNaN(s);
            })
                .classed('closest', function (p) { return dist(p) === closestDist; })
                .each(function (point) {
                self.drawTooltipRow(this, tooltipColumns, point);
            })
                // reorders DOM to match the ordering of the `data`.
                .order();
            rows.exit().remove();
            var newRowNodes = rows.enter()
                .append('tr')
                .each(function (point) {
                self.drawTooltipRow(this, tooltipColumns, point);
            })
                .nodes();
            var newNodes = newHeaderNodes.concat(newRowNodes);
            this.tooltip.updateAndPosition(this.targetSVG.node(), newNodes);
        };
        LineChart.prototype.drawTooltipRow = function (row, tooltipColumns, point) {
            var self = this;
            var columns = d3.select(row).selectAll('td').data(tooltipColumns);
            columns.each(function (col) {
                // Skip column value update when the column is static.
                if (col.static)
                    return;
                self.drawTooltipColumn.call(self, this, col, point);
            });
            columns.enter()
                .append('td')
                .each(function (col) {
                if (col.enter)
                    col.enter.call(this, point);
                self.drawTooltipColumn.call(self, this, col, point);
            });
        };
        LineChart.prototype.drawTooltipColumn = function (column, tooltipCol, point) {
            var smoothingEnabled = this.smoothingEnabled;
            if (tooltipCol.evalType == TooltipColumnEvalType.DOM) {
                tooltipCol.evaluate.call(column, point, { smoothingEnabled: smoothingEnabled });
            }
            else {
                d3.select(column)
                    .text(tooltipCol.evaluate.call(column, point, { smoothingEnabled: smoothingEnabled }));
            }
        };
        LineChart.prototype.findClosestPoint = function (target, dataset) {
            var _this = this;
            var xPoints = dataset.data()
                .map(function (d, i) { return _this.xScale.scale(_this.xAccessor(d, i, dataset)); });
            var idx = _.sortedIndex(xPoints, target.x);
            if (xPoints.length == 0)
                return null;
            if (idx === xPoints.length) {
                idx = idx - 1;
            }
            else if (idx !== 0) {
                var prevDist = Math.abs(xPoints[idx - 1] - target.x);
                var nextDist = Math.abs(xPoints[idx] - target.x);
                idx = prevDist < nextDist ? idx - 1 : idx;
            }
            var datum = dataset.data()[idx];
            var y = this.smoothingEnabled ?
                this.smoothedAccessor(datum, idx, dataset) :
                this.yValueAccessor(datum, idx, dataset);
            return {
                x: xPoints[idx],
                y: this.yScale.scale(y),
                datum: datum,
                dataset: dataset,
            };
        };
        LineChart.prototype.resmoothDataset = function (dataset) {
            var _this = this;
            var data = dataset.data();
            var smoothingWeight = this.smoothingWeight;
            // 1st-order IIR low-pass filter to attenuate the higher-
            // frequency components of the time-series.
            var last = data.length > 0 ? 0 : NaN;
            var numAccum = 0;
            data.forEach(function (d, i) {
                var nextVal = _this.yValueAccessor(d, i, dataset);
                if (!_.isFinite(nextVal)) {
                    d.smoothed = nextVal;
                }
                else {
                    last = last * smoothingWeight + (1 - smoothingWeight) * nextVal;
                    numAccum++;
                    // The uncorrected moving average is biased towards the initial value.
                    // For example, if initialized with `0`, with smoothingWeight `s`, where
                    // every data point is `c`, after `t` steps the moving average is
                    // ```
                    //   EMA = 0*s^(t) + c*(1 - s)*s^(t-1) + c*(1 - s)*s^(t-2) + ...
                    //       = c*(1 - s^t)
                    // ```
                    // If initialized with `0`, dividing by (1 - s^t) is enough to debias
                    // the moving average. We count the number of finite data points and
                    // divide appropriately before storing the data.
                    var debiasWeight = 1;
                    if (smoothingWeight !== 1.0) {
                        debiasWeight = 1.0 - Math.pow(smoothingWeight, numAccum);
                    }
                    d.smoothed = last / debiasWeight;
                }
            });
        };
        LineChart.prototype.getDataset = function (name) {
            if (this.name2datasets[name] === undefined) {
                this.name2datasets[name] = new Plottable.Dataset([], {
                    name: name,
                    meta: null,
                });
            }
            return this.name2datasets[name];
        };
        LineChart.getYScaleFromType = function (yScaleType) {
            if (yScaleType === 'log') {
                return new Plottable.Scales.ModifiedLog();
            }
            else if (yScaleType === 'linear') {
                return new Plottable.Scales.Linear();
            }
            else {
                throw new Error('Unrecognized yScale type ' + yScaleType);
            }
        };
        /**
         * Update the selected series on the chart.
         */
        LineChart.prototype.setVisibleSeries = function (names) {
            var _this = this;
            names = names.sort();
            this.seriesNames = names;
            names.reverse(); // draw first series on top
            this.datasets.forEach(function (d) { return d.offUpdate(_this.onDatasetChanged); });
            this.datasets = names.map(function (r) { return _this.getDataset(r); });
            this.datasets.forEach(function (d) { return d.onUpdate(_this.onDatasetChanged); });
            this.linePlot.datasets(this.datasets);
            if (this.smoothingEnabled) {
                this.smoothLinePlot.datasets(this.datasets);
            }
            if (this.marginAreaPlot) {
                this.marginAreaPlot.datasets(this.datasets);
            }
            this.updateSpecialDatasets();
        };
        /**
         * Samples a dataset so that it contains no more than _MAX_MARKERS number of
         * data points. This function returns the original dataset if it does not
         * exceed that many points.
         */
        LineChart.prototype.createSampledDatasetForMarkers = function (original) {
            var originalData = original.data();
            if (originalData.length <= _MAX_MARKERS) {
                // This dataset is small enough. Do not sample.
                return original;
            }
            // Downsample the data. Otherwise, too many markers clutter the chart.
            var skipLength = Math.ceil(originalData.length / _MAX_MARKERS);
            var data = new Array(Math.floor(originalData.length / skipLength));
            for (var i = 0, j = 0; i < data.length; i++, j += skipLength) {
                data[i] = originalData[j];
            }
            return new Plottable.Dataset(data, original.metadata());
        };
        /**
         * Sets the data of a series on the chart.
         */
        LineChart.prototype.setSeriesData = function (name, data) {
            this.getDataset(name).data(data);
            this.measureBBoxAndMaybeInvalidateLayoutInRaf();
        };
        /**
         * Sets the metadata of a series on the chart.
         */
        LineChart.prototype.setSeriesMetadata = function (name, meta) {
            var newMeta = Object.assign({}, this.getDataset(name).metadata(), { meta: meta });
            this.getDataset(name).metadata(newMeta);
        };
        LineChart.prototype.smoothingUpdate = function (weight) {
            var _this = this;
            this.smoothingWeight = weight;
            this.datasets.forEach(function (d) { return _this.resmoothDataset(d); });
            if (!this.smoothingEnabled) {
                this.linePlot.addClass('ghost');
                this.scatterPlot.y(this.smoothedAccessor, this.yScale);
                this.smoothingEnabled = true;
                this.smoothLinePlot.datasets(this.datasets);
            }
            if (this.markersScatterPlot) {
                // Use the correct accessor for marker positioning.
                this.markersScatterPlot.y(this.getYAxisAccessor(), this.yScale);
            }
            this.updateSpecialDatasets();
        };
        LineChart.prototype.smoothingDisable = function () {
            if (this.smoothingEnabled) {
                this.linePlot.removeClass('ghost');
                this.scatterPlot.y(this.yValueAccessor, this.yScale);
                this.smoothLinePlot.datasets([]);
                this.smoothingEnabled = false;
                this.updateSpecialDatasets();
            }
            if (this.markersScatterPlot) {
                // Use the correct accessor (which depends on whether smoothing is
                // enabled) for marker positioning.
                this.markersScatterPlot.y(this.getYAxisAccessor(), this.yScale);
            }
        };
        LineChart.prototype.setTooltipSortingMethod = function (method) {
            this.tooltipSortingMethod = method;
        };
        LineChart.prototype.renderTo = function (targetSVG) {
            this.targetSVG = targetSVG;
            this.outer.renderTo(targetSVG);
            if (this._defaultXRange != null) {
                // A higher-level component provided a default range for the X axis.
                // Start with that range.
                this.resetXDomain();
            }
            if (this._defaultYRange != null) {
                // A higher-level component provided a default range for the Y axis.
                // Start with that range.
                this.resetYDomain();
            }
            this.measureBBoxAndMaybeInvalidateLayoutInRaf();
        };
        LineChart.prototype.redraw = function () {
            var _this = this;
            window.cancelAnimationFrame(this._redrawRaf);
            this._redrawRaf = window.requestAnimationFrame(function () {
                _this.measureBBoxAndMaybeInvalidateLayout();
                _this.outer.redraw();
            });
        };
        LineChart.prototype.measureBBoxAndMaybeInvalidateLayoutInRaf = function () {
            var _this = this;
            window.cancelAnimationFrame(this._invalidateLayoutRaf);
            this._invalidateLayoutRaf = window.requestAnimationFrame(function () {
                _this.measureBBoxAndMaybeInvalidateLayout();
            });
        };
        /**
         * Measures bounding box of the anchor node and determines whether the layout
         * needs to be re-done with measurement cache invalidated. Plottable improved
         * performance of rendering by caching expensive DOM measurement but this
         * cache can be poisoned in case the anchor node is in a wrong state -- namely
         * `display: none` where all dimensions are 0.
         */
        LineChart.prototype.measureBBoxAndMaybeInvalidateLayout = function () {
            if (this._lastDrawBBox) {
                var prevWidth = this._lastDrawBBox.width;
                var width = this.targetSVG.node().getBoundingClientRect().width;
                if (prevWidth == 0 && prevWidth < width)
                    this.outer.invalidateCache();
            }
            this._lastDrawBBox = this.targetSVG.node().getBoundingClientRect();
        };
        LineChart.prototype.destroy = function () {
            // Destroying outer destroys all subcomponents recursively.
            window.cancelAnimationFrame(this._redrawRaf);
            window.cancelAnimationFrame(this._invalidateLayoutRaf);
            if (this.outer)
                this.outer.destroy();
        };
        LineChart.prototype.onAnchor = function (fn) {
            if (this.outer)
                this.outer.onAnchor(fn);
        };
        return LineChart;
    }());
    vz_line_chart2.LineChart = LineChart;
})(vz_line_chart2 || (vz_line_chart2 = {})); // namespace vz_line_chart2
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibGluZS1jaGFydC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImxpbmUtY2hhcnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7Ozs7Ozs7Z0ZBYWdGO0FBQ2hGLElBQVUsY0FBYyxDQW0zQnZCO0FBbjNCRCxXQUFVLGNBQWM7SUFjeEIsSUFBSyxxQkFHSjtJQUhELFdBQUsscUJBQXFCO1FBQ3hCLGlFQUFJLENBQUE7UUFDSiwrREFBRyxDQUFBO0lBQ0wsQ0FBQyxFQUhJLHFCQUFxQixLQUFyQixxQkFBcUIsUUFHekI7SUFtQkQ7OztPQUdHO0lBQ0gsSUFBTSxZQUFZLEdBQUcsRUFBRSxDQUFDO0lBRXhCO1FBb0RFLG1CQUNJLHlCQUE2RCxFQUM3RCxjQUEyQyxFQUMzQyxVQUFrQixFQUNsQixVQUFrQyxFQUNsQyxPQUF1QyxFQUN2QyxjQUFnRCxFQUNoRCxRQUFrQixFQUNsQixhQUF3QixFQUN4QixhQUF3QixFQUN4QixjQUEwQyxFQUMxQyxjQUFtQztZQUNyQyxJQUFJLENBQUMsV0FBVyxHQUFHLEVBQUUsQ0FBQztZQUN0QixJQUFJLENBQUMsYUFBYSxHQUFHLEVBQUUsQ0FBQztZQUN4QixJQUFJLENBQUMsVUFBVSxHQUFHLFVBQVUsQ0FBQztZQUM3QixJQUFJLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQztZQUN2QixJQUFJLENBQUMsUUFBUSxHQUFHLEVBQUUsQ0FBQztZQUNuQixJQUFJLENBQUMsZ0JBQWdCLEdBQUcsS0FBSyxDQUFDO1lBQzlCLHFFQUFxRTtZQUNyRSx5Q0FBeUM7WUFDekMsSUFBSSxDQUFDLGlCQUFpQixHQUFHLElBQUksU0FBUyxDQUFDLE9BQU8sRUFBRSxDQUFDO1lBQ2pELElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxTQUFTLENBQUMsT0FBTyxFQUFFLENBQUM7WUFDMUMsSUFBSSxDQUFDLGNBQWMsR0FBRyxjQUFjLENBQUM7WUFFckMsNEVBQTRFO1lBQzVFLGdEQUFnRDtZQUNoRCxJQUFJLENBQUMsY0FBYyxHQUFHLGNBQWMsQ0FBQztZQUVyQyxtRUFBbUU7WUFDbkUsdUVBQXVFO1lBQ3ZFLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1lBRTFELElBQUksQ0FBQyxjQUFjLEdBQUcsYUFBYSxDQUFDO1lBQ3BDLElBQUksQ0FBQyxjQUFjLEdBQUcsYUFBYSxDQUFDO1lBQ3BDLElBQUksQ0FBQyxjQUFjLEdBQUcsY0FBYyxDQUFDO1lBRXJDLElBQUksQ0FBQyxVQUFVLENBQ1gseUJBQXlCLEVBQ3pCLGNBQWMsRUFDZCxVQUFVLEVBQ1YsUUFBUSxFQUNSLGNBQWMsQ0FBQyxDQUFDO1FBQ3RCLENBQUM7UUFFTyw4QkFBVSxHQUFsQixVQUNJLHlCQUE2RCxFQUM3RCxjQUEyQyxFQUMzQyxVQUFrQixFQUNsQixRQUFrQixFQUNsQixjQUFrQztZQUx0QyxpQkFrREM7WUE1Q0MsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDO1lBQ2YsSUFBTSxXQUFXLEdBQUcseUJBQXlCLEVBQUUsQ0FBQztZQUNoRCxJQUFJLENBQUMsU0FBUyxHQUFHLFdBQVcsQ0FBQyxRQUFRLENBQUM7WUFDdEMsSUFBSSxDQUFDLE1BQU0sR0FBRyxXQUFXLENBQUMsS0FBSyxDQUFDO1lBQ2hDLElBQUksQ0FBQyxLQUFLLEdBQUcsV0FBVyxDQUFDLElBQUksQ0FBQztZQUM5QixJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUN6QyxJQUFJLGNBQWMsRUFBRTtnQkFDbEIsSUFBSSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLENBQUM7YUFDdEM7WUFDRCxJQUFJLENBQUMsTUFBTSxHQUFHLFNBQVMsQ0FBQyxpQkFBaUIsQ0FBQyxVQUFVLENBQUMsQ0FBQztZQUN0RCxJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksU0FBUyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxNQUFNLENBQUMsQ0FBQztZQUM3RCxJQUFJLFVBQVUsR0FBRyxnQkFBZ0IsQ0FBQyxtQkFBbUIsQ0FDakQsZ0JBQWdCLENBQUMsMEJBQTBCLENBQUMsQ0FBQztZQUNqRCxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUM7WUFDL0QsSUFBSSxDQUFDLEtBQUssQ0FBQywwQkFBMEIsQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUM1QyxJQUFJLENBQUMsUUFBUSxHQUFHLFFBQVEsQ0FBQztZQUV6QixJQUFNLFlBQVksR0FBRyxJQUFJLGVBQUEsZ0JBQWdCLENBQ3JDLElBQUksQ0FBQyxNQUFNLEVBQ1gsSUFBSSxDQUFDLE1BQU0sRUFDWCxjQUFNLE9BQUEsS0FBSSxDQUFDLFdBQVcsRUFBRSxFQUFsQixDQUFrQixDQUFDLENBQUM7WUFFOUIsSUFBSSxDQUFDLGtCQUFrQixHQUFHLElBQUksQ0FBQyx3QkFBd0IsQ0FBQyxZQUFZLENBQUMsQ0FBQztZQUN0RSxJQUFJLENBQUMsc0JBQXNCLEdBQUcsSUFBSSxTQUFTLENBQUMsU0FBUyxFQUFFLENBQUM7WUFFeEQsSUFBTSxJQUFJLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FDdkIsSUFBSSxDQUFDLE1BQU0sRUFDWCxJQUFJLENBQUMsTUFBTSxFQUNYLFFBQVEsQ0FBQyxDQUFDO1lBRWQsSUFBSSxDQUFDLFNBQVM7Z0JBQ1YsSUFBSSxTQUFTLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUVqRSxJQUFJLFNBQVMsR0FBRyxJQUFJLFNBQVMsQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLFlBQVksQ0FBQyxDQUFDO1lBQ3RFLFNBQVMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUN0QyxJQUFJLFNBQVMsR0FBRyxJQUFJLFNBQVMsQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBQ3BFLFNBQVMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUV0QyxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksU0FBUyxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUM7Z0JBQ3pDLElBQUksQ0FBQyxTQUFTLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBRSxJQUFJO2dCQUMxQyxZQUFZLEVBQUUsSUFBSSxDQUFDLHNCQUFzQjthQUFDLENBQUMsQ0FBQztZQUNoRCxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUM3QixJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksU0FBUyxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQ3ZDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3ZELENBQUM7UUFFTyw2QkFBUyxHQUFqQixVQUFrQixNQUFNLEVBQUUsTUFBTSxFQUFFLFFBQVE7WUFBMUMsaUJBb0ZDO1lBbEZDLElBQUksUUFBUSxFQUFFO2dCQUNaLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxTQUFTLENBQUMsS0FBSyxDQUFDLElBQUksRUFBZSxDQUFDO2dCQUM5RCxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLE1BQU0sQ0FBQyxDQUFDO2dCQUM5QyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsY0FBYyxFQUFFLE1BQU0sQ0FBQyxDQUFDO2dCQUN2RCxJQUFJLENBQUMsY0FBYyxDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUMsYUFBYSxDQUFDLENBQUM7Z0JBQy9DLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUNwQixNQUFNLEVBQ04sVUFBQyxDQUF5QixFQUFFLENBQVMsRUFBRSxPQUEwQjtvQkFDN0QsT0FBQSxLQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsUUFBUSxFQUFFLENBQUMsSUFBSSxDQUFDO2dCQUE5QyxDQUE4QyxDQUFDLENBQUM7Z0JBQ3hELElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLGNBQWMsRUFBRSxHQUFHLENBQUMsQ0FBQztnQkFDOUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUMsQ0FBQyxDQUFDO2FBQzdDO1lBRUQsSUFBSSxDQUFDLGdCQUFnQixHQUFHLFVBQUMsQ0FBZ0MsSUFBSyxPQUFBLENBQUMsQ0FBQyxRQUFRLEVBQVYsQ0FBVSxDQUFDO1lBQ3pFLElBQUksUUFBUSxHQUFHLElBQUksU0FBUyxDQUFDLEtBQUssQ0FBQyxJQUFJLEVBQWUsQ0FBQztZQUN2RCxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsTUFBTSxDQUFDLENBQUM7WUFDbkMsUUFBUSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsY0FBYyxFQUFFLE1BQU0sQ0FBQyxDQUFDO1lBQ3hDLFFBQVEsQ0FBQyxJQUFJLENBQ1QsUUFBUSxFQUNSLFVBQUMsQ0FBeUIsRUFBRSxDQUFTLEVBQUUsT0FBMEI7Z0JBQzdELE9BQUEsS0FBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxDQUFDLElBQUksQ0FBQztZQUE5QyxDQUE4QyxDQUFDLENBQUM7WUFDeEQsSUFBSSxDQUFDLFFBQVEsR0FBRyxRQUFRLENBQUM7WUFDekIsSUFBSSxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUU3QixJQUFJLGNBQWMsR0FBRyxJQUFJLFNBQVMsQ0FBQyxLQUFLLENBQUMsSUFBSSxFQUFlLENBQUM7WUFDN0QsY0FBYyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLE1BQU0sQ0FBQyxDQUFDO1lBQ3pDLGNBQWMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGdCQUFnQixFQUFFLE1BQU0sQ0FBQyxDQUFDO1lBQ2hELGNBQWMsQ0FBQyxJQUFJLENBQ2YsUUFBUSxFQUNSLFVBQUMsQ0FBeUIsRUFBRSxDQUFTLEVBQUUsT0FBMEI7Z0JBQzdELE9BQUEsS0FBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxDQUFDLElBQUksQ0FBQztZQUE5QyxDQUE4QyxDQUFDLENBQUM7WUFDeEQsSUFBSSxDQUFDLGNBQWMsR0FBRyxjQUFjLENBQUM7WUFFckMsSUFBSSxJQUFJLENBQUMsY0FBYyxFQUFFO2dCQUN2QixJQUFNLGtCQUFrQixHQUFHLElBQUksU0FBUyxDQUFDLEtBQUssQ0FBQyxPQUFPLEVBQXVCLENBQUM7Z0JBQzlFLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLE1BQU0sQ0FBQyxDQUFDO2dCQUM3QyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGNBQWMsRUFBRSxNQUFNLENBQUMsQ0FBQztnQkFDbEQsa0JBQWtCLENBQUMsSUFBSSxDQUNuQixNQUFNLEVBQ04sVUFBQyxDQUF5QixFQUFFLENBQVMsRUFBRSxPQUEwQjtvQkFDN0QsT0FBQSxLQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsUUFBUSxFQUFFLENBQUMsSUFBSSxDQUFDO2dCQUE5QyxDQUE4QyxDQUFDLENBQUM7Z0JBQ3hELGtCQUFrQixDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFDLENBQUM7Z0JBQ3RDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxtQkFBbUIsR0FBRyxDQUFDLENBQUMsQ0FBQztnQkFDbEUsa0JBQWtCLENBQUMsTUFBTSxDQUNyQixVQUFDLENBQXlCLEVBQUUsQ0FBUyxFQUFFLE9BQTBCO29CQUMvRCxPQUFPLEtBQUksQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUN0RCxDQUFDLENBQUMsQ0FBQztnQkFDUCx5RUFBeUU7Z0JBQ3pFLGdEQUFnRDtnQkFDaEQsSUFBSSxDQUFDLGtCQUFrQixHQUFHLGtCQUFrQixDQUFDO2FBQzlDO1lBRUQsZ0VBQWdFO1lBQ2hFLG1FQUFtRTtZQUNuRSxxRUFBcUU7WUFDckUsSUFBSSxXQUFXLEdBQUcsSUFBSSxTQUFTLENBQUMsS0FBSyxDQUFDLE9BQU8sRUFBdUIsQ0FBQztZQUNyRSxXQUFXLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsTUFBTSxDQUFDLENBQUM7WUFDdEMsV0FBVyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsY0FBYyxFQUFFLE1BQU0sQ0FBQyxDQUFDO1lBQzNDLFdBQVcsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLFVBQUMsQ0FBTSxJQUFLLE9BQUEsS0FBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUE3QixDQUE2QixDQUFDLENBQUM7WUFDcEUsV0FBVyxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFDLENBQUM7WUFDL0IsV0FBVyxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxtQkFBbUIsR0FBRyxDQUFDLENBQUMsQ0FBQztZQUMzRCxXQUFXLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQztZQUMvQyxJQUFJLENBQUMsV0FBVyxHQUFHLFdBQVcsQ0FBQztZQUUvQixJQUFJLFVBQVUsR0FBRyxJQUFJLFNBQVMsQ0FBQyxLQUFLLENBQUMsT0FBTyxFQUF1QixDQUFDO1lBQ3BFLFVBQVUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxNQUFNLENBQUMsQ0FBQztZQUNyQyxVQUFVLENBQUMsQ0FBQyxDQUFDLFVBQUMsQ0FBQyxJQUFLLE9BQUEsQ0FBQyxDQUFDLFFBQVEsRUFBVixDQUFVLEVBQUUsTUFBTSxDQUFDLENBQUM7WUFDeEMsVUFBVSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsVUFBQyxDQUFNLElBQUssT0FBQSxLQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQTdCLENBQTZCLENBQUMsQ0FBQztZQUNuRSxVQUFVLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUMsQ0FBQztZQUM5QixVQUFVLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGVBQWUsR0FBRyxDQUFDLENBQUMsQ0FBQztZQUN0RCxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUM7WUFDdkMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsZUFBZSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQ3RELElBQUksQ0FBQyxVQUFVLEdBQUcsVUFBVSxDQUFDO1lBRTdCLElBQU0sTUFBTSxHQUFHLENBQUMsVUFBVSxFQUFFLFdBQVcsRUFBRSxjQUFjLEVBQUUsUUFBUSxDQUFDLENBQUM7WUFDbkUsSUFBSSxJQUFJLENBQUMsY0FBYyxFQUFFO2dCQUN2QixNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQzthQUNsQztZQUNELElBQUksSUFBSSxDQUFDLGtCQUFrQixFQUFFO2dCQUMzQixNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO2FBQ3RDO1lBQ0QsT0FBTyxJQUFJLFNBQVMsQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ2hELENBQUM7UUFFRDs7V0FFRztRQUNLLHFDQUFpQixHQUF6QixVQUEwQixPQUEwQjtZQUNsRCxJQUFJLElBQUksQ0FBQyxnQkFBZ0IsRUFBRTtnQkFDekIsSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsQ0FBQzthQUMvQjtZQUNELElBQUksQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO1FBQy9CLENBQUM7UUFFTSxtQ0FBZSxHQUF0QixVQUF1QixlQUF3QjtZQUM3QyxJQUFJLGVBQWUsS0FBSyxJQUFJLENBQUMsZ0JBQWdCLEVBQUU7Z0JBQzdDLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxlQUFlLENBQUM7Z0JBQ3hDLElBQUksQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO2dCQUM3QixJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7YUFDckI7UUFDSCxDQUFDO1FBRUQ7Ozs7V0FJRztRQUNLLHlDQUFxQixHQUE3QjtZQUNFLElBQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO1lBRXpDLElBQUksY0FBYyxHQUNkLElBQUksQ0FBQyxRQUFRO2lCQUNSLEdBQUcsQ0FBQyxVQUFDLENBQUM7Z0JBQ0wsSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDO2dCQUNqQixzREFBc0Q7Z0JBQ3RELElBQUksVUFBVSxHQUNWLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxNQUFNLENBQUMsVUFBQyxDQUFDLElBQUssT0FBQSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQTFCLENBQTBCLENBQUMsQ0FBQztnQkFDdkQsSUFBSSxVQUFVLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtvQkFDekIsSUFBSSxHQUFHLEdBQUcsVUFBVSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7b0JBQ2hDLEtBQUssR0FBRyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUM7b0JBQ3hCLEtBQUssQ0FBQyxJQUFJLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxDQUFDLElBQUksQ0FBQztvQkFDL0IsS0FBSyxDQUFDLFFBQVEsR0FBRyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFLLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7aUJBQ2xFO2dCQUNELE9BQU8sS0FBSyxDQUFDO1lBQ2YsQ0FBQyxDQUFDO2lCQUNELE1BQU0sQ0FBQyxVQUFDLENBQUMsSUFBSyxPQUFBLENBQUMsSUFBSSxJQUFJLEVBQVQsQ0FBUyxDQUFDLENBQUM7WUFDbEMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQztZQUU1QyxJQUFJLElBQUksQ0FBQyxrQkFBa0IsRUFBRTtnQkFDM0IsSUFBSSxDQUFDLGtCQUFrQixDQUFDLFFBQVEsQ0FDNUIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLDhCQUE4QixDQUFDLENBQUMsQ0FBQzthQUM3RDtZQUVELHFEQUFxRDtZQUNyRCw4REFBOEQ7WUFDOUQsdUVBQXVFO1lBQ3ZFLElBQUksZ0JBQWdCLEdBQUcsVUFBQyxDQUFvQjtnQkFDMUMsSUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDO2dCQUNwQixJQUFJLElBQUksR0FBRyxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7Z0JBQ3BCLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDVixPQUFPLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxJQUFJLFFBQVEsSUFBSSxJQUFJLEVBQUU7b0JBQzFDLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFO3dCQUNwQyxRQUFRLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztxQkFDckM7b0JBQ0QsQ0FBQyxFQUFFLENBQUM7aUJBQ0w7Z0JBQ0QsSUFBSSxRQUFRLElBQUksSUFBSSxFQUFFO29CQUNwQixRQUFRLEdBQUcsQ0FBQyxDQUFDO2lCQUNkO2dCQUNELElBQUksT0FBTyxHQUFHLEVBQUUsQ0FBQztnQkFDakIsS0FBSyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO29CQUNoQyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRTt3QkFDcEMsUUFBUSxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7cUJBQ3JDO3lCQUFNO3dCQUNMLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxDQUFDLElBQUksQ0FBQzt3QkFDakMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsR0FBRyxRQUFRLENBQUM7d0JBQzVCLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLEdBQUcsZ0JBQWdCLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO3dCQUNyRSxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO3FCQUN2QjtpQkFDRjtnQkFDRCxPQUFPLE9BQU8sQ0FBQztZQUNqQixDQUFDLENBQUM7WUFDRixJQUFJLE9BQU8sR0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQztZQUM3RCxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUNoQyxDQUFDO1FBRU0sK0JBQVcsR0FBbEI7WUFDRSxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7WUFDcEIsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1FBQ3RCLENBQUM7UUFFTyxnQ0FBWSxHQUFwQjtZQUNFLElBQUksT0FBTyxDQUFDO1lBQ1osSUFBSSxJQUFJLENBQUMsY0FBYyxJQUFJLElBQUksRUFBRTtnQkFDL0IseUNBQXlDO2dCQUN6QyxPQUFPLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQzthQUMvQjtpQkFBTTtnQkFDTCxvREFBb0Q7Z0JBQ3BELElBQU0sTUFBTSxHQUFHLElBQUksQ0FBQyxNQUFhLENBQUM7Z0JBQ2xDLE1BQU0sQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDO2dCQUN6QixNQUFNLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQztnQkFDekIsT0FBTyxHQUFHLE1BQU0sQ0FBQyxVQUFVLEVBQUUsQ0FBQzthQUMvQjtZQUNELElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQzlCLENBQUM7UUFFTyxnQ0FBWSxHQUFwQjtZQUNFLElBQUksT0FBTyxDQUFDO1lBQ1osSUFBSSxJQUFJLENBQUMsY0FBYyxJQUFJLElBQUksRUFBRTtnQkFDL0IseUNBQXlDO2dCQUN6QyxPQUFPLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQzthQUMvQjtpQkFBTTtnQkFDTCwrQkFBK0I7Z0JBQy9CLElBQU0sV0FBUyxHQUFHLElBQUksQ0FBQyw4QkFBOEIsRUFBRSxDQUFDO2dCQUN4RCxJQUFJLGVBQWUsR0FBeUMsVUFBQyxDQUFDO29CQUM1RCxPQUFPLFdBQVMsQ0FBQyxHQUFHLENBQUMsVUFBQSxRQUFRLElBQUksT0FBQSxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUMsR0FBRyxDQUFDLFVBQUEsQ0FBQyxJQUFJLE9BQUEsUUFBUSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBbEIsQ0FBa0IsQ0FBQyxFQUFyQyxDQUFxQyxDQUFDLENBQUM7Z0JBQzFFLENBQUMsQ0FBQztnQkFDRixJQUFNLElBQUksR0FBRyxDQUFDLENBQUMsV0FBVyxDQUFTLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFDO3FCQUNqRSxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUM7Z0JBQ3RCLE9BQU8sR0FBRyxnQkFBZ0IsQ0FBQyxhQUFhLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO2FBQ3ZFO1lBQ0QsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDOUIsQ0FBQztRQUVPLGtEQUE4QixHQUF0QztZQUNFLElBQU0sU0FBUyxHQUFHLENBQUMsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUMsQ0FBQztZQUM1QyxJQUFJLElBQUksQ0FBQyxRQUFRLEVBQUU7Z0JBQ2pCLCtDQUErQztnQkFDL0MsU0FBUyxDQUFDLElBQUksQ0FDVixJQUFJLENBQUMsUUFBUSxDQUFDLGFBQWEsRUFDM0IsSUFBSSxDQUFDLFFBQVEsQ0FBQyxjQUFjLENBQUMsQ0FBQzthQUNuQztZQUNELE9BQU8sU0FBUyxDQUFDO1FBQ25CLENBQUM7UUFFTyxvQ0FBZ0IsR0FBeEI7WUFDRSxPQUFPLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDO1FBQzdFLENBQUM7UUFFTyw0Q0FBd0IsR0FBaEMsVUFBaUMsSUFBc0I7WUFBdkQsaUJBc0JDO1lBcEJDLElBQU0sRUFBRSxHQUFHLElBQUksU0FBUyxDQUFDLFlBQVksQ0FBQyxPQUFPLEVBQUUsQ0FBQztZQUNoRCwwQ0FBMEM7WUFDMUMsSUFBTSxvQkFBb0IsR0FBRztnQkFDM0IsRUFBRSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFDbEIsS0FBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1lBQ3RCLENBQUMsQ0FBQztZQUNGLElBQU0sbUJBQW1CLEdBQUcsY0FBTSxPQUFBLEVBQUUsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEVBQWhCLENBQWdCLENBQUM7WUFDbkQsSUFBSSxDQUFDLFVBQVUsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO1lBQ3RDLElBQUksQ0FBQyxlQUFlLENBQUMsb0JBQW9CLENBQUMsQ0FBQztZQUMzQyxJQUFJLENBQUMsUUFBUSxDQUFDLG1CQUFtQixDQUFDLENBQUM7WUFDbkMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO1lBQ3hDLHdFQUF3RTtZQUN4RSx1Q0FBdUM7WUFDdkMsSUFBSSxDQUFDLFlBQVksQ0FBQyxjQUFNLE9BQUEsS0FBSSxDQUFDLG9CQUFvQixDQUFDLEtBQUksQ0FBQyxrQkFBa0IsQ0FBQyxFQUFsRCxDQUFrRCxDQUFDLENBQUM7WUFDNUUsRUFBRSxDQUFDLGFBQWEsQ0FBQyxVQUFDLENBQWtCO2dCQUNsQyxLQUFJLENBQUMsa0JBQWtCLEdBQUcsQ0FBQyxDQUFDO2dCQUM1QixLQUFJLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDL0IsQ0FBQyxDQUFDLENBQUM7WUFDSCxFQUFFLENBQUMsYUFBYSxDQUFDLGNBQU0sT0FBQSxLQUFJLENBQUMsWUFBWSxFQUFFLEVBQW5CLENBQW1CLENBQUMsQ0FBQztZQUM1QyxPQUFPLEVBQUUsQ0FBQztRQUNaLENBQUM7UUFFTyx3Q0FBb0IsR0FBNUIsVUFBNkIsQ0FBa0I7WUFBL0MsaUJBNENDO1lBM0NDLHlDQUF5QztZQUN6QyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVE7Z0JBQUUsT0FBTztZQUMzQixNQUFNLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLDRCQUE0QixDQUFDLENBQUM7WUFDL0QsSUFBSSxDQUFDLDRCQUE0QixHQUFHLE1BQU0sQ0FBQyxxQkFBcUIsQ0FBQztnQkFDL0QsSUFBSSxNQUFNLEdBQTJCO29CQUNuQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7b0JBQ04sQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO29CQUNOLEtBQUssRUFBRSxJQUFJO29CQUNYLE9BQU8sRUFBRSxJQUFJO2lCQUNkLENBQUM7Z0JBQ0YsSUFBSSxJQUFJLEdBQWtCLEtBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxFQUFFLENBQUMsSUFBSSxFQUFHLENBQUMsT0FBTyxFQUFFLENBQUM7Z0JBQ3JFLDJEQUEyRDtnQkFDM0QsSUFBSSxHQUFHLEdBQUcsS0FBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLEVBQUU7cUJBQzdCLEdBQUcsQ0FBQyxVQUFDLE9BQU8sSUFBSyxPQUFBLEtBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDLEVBQXRDLENBQXNDLENBQUM7cUJBQ3hELE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQztnQkFDckIsSUFBSSxjQUFjLEdBQUcsU0FBUyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsY0FBYyxDQUFDO2dCQUN4RCxxRUFBcUU7Z0JBQ3JFLElBQUksY0FBYyxHQUFHLEdBQUcsQ0FBQyxNQUFNLENBQzNCLFVBQUMsQ0FBQyxJQUFLLE9BQUEsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUM7b0JBQ2pDLEtBQUssQ0FBQyxLQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxLQUFLLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxFQUQ5QyxDQUM4QyxDQUFDLENBQUM7Z0JBQzNELDREQUE0RDtnQkFDNUQsSUFBSSxXQUFXLEdBQUcsY0FBYyxDQUFDLE1BQU0sQ0FDbkMsVUFBQyxDQUFDLElBQUssT0FBQSxDQUFDLEtBQUssQ0FBQyxLQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxLQUFLLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxFQUFsRCxDQUFrRCxDQUFDLENBQUM7Z0JBQy9ELElBQUksR0FBRyxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7b0JBQ3BCLEtBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxNQUFNLENBQUMsQ0FBQztvQkFDekMsSUFBTSxZQUFZLEdBQ2QsS0FBSSxDQUFDLHNCQUFzQixDQUFDLE9BQU8sRUFBRSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQzFELFdBQVcsRUFDWCxVQUFDLENBQXlCLElBQUssT0FBQSxDQUFDLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxDQUFDLElBQUksRUFBekIsQ0FBeUIsQ0FBQyxDQUFDO29CQUNsRSxZQUFZLENBQUMsS0FBSyxFQUFFLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUM7b0JBQzdELFlBQVksQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLGdCQUFnQixDQUFDLG1CQUFtQixDQUFDO3lCQUN2RCxJQUFJLENBQUMsSUFBSSxFQUFFLFVBQUMsQ0FBQyxJQUFLLE9BQUEsQ0FBQyxDQUFDLENBQUMsRUFBSCxDQUFHLENBQUM7eUJBQ3RCLElBQUksQ0FBQyxJQUFJLEVBQUUsVUFBQyxDQUFDLElBQUssT0FBQSxDQUFDLENBQUMsQ0FBQyxFQUFILENBQUcsQ0FBQzt5QkFDdEIsS0FBSyxDQUFDLFFBQVEsRUFBRSxNQUFNLENBQUM7eUJBQ3ZCLElBQUksQ0FDRCxNQUFNLEVBQ04sVUFBQyxDQUFDLElBQUssT0FBQSxLQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFoRCxDQUFnRCxDQUFDLENBQUM7b0JBQ2pFLFlBQVksQ0FBQyxJQUFJLEVBQUUsQ0FBQyxNQUFNLEVBQUUsQ0FBQztvQkFDN0IsS0FBSSxDQUFDLFlBQVksQ0FBQyxjQUFjLEVBQUUsTUFBTSxFQUFFLEtBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQztpQkFDaEU7cUJBQU07b0JBQ0wsS0FBSSxDQUFDLFlBQVksRUFBRSxDQUFDO2lCQUNyQjtZQUNILENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQztRQUVPLGdDQUFZLEdBQXBCO1lBQ0UsTUFBTSxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyw0QkFBNEIsQ0FBQyxDQUFDO1lBQy9ELElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFLENBQUM7WUFDcEIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1lBQzFDLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDckUsQ0FBQztRQUVPLGlDQUFhLEdBQXJCLFVBQXNCLElBQTJDO1lBQWpFLGlCQVNDO1lBUkMsSUFBSSxDQUFDLFFBQVEsQ0FBQztnQkFDWixLQUFJLENBQUMsa0JBQWtCLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUN6QyxLQUFJLENBQUMsa0JBQWtCLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ3pDLENBQUMsQ0FBQyxDQUFDO1lBQ0gsSUFBSSxDQUFDLFFBQVEsQ0FBQztnQkFDWixLQUFJLENBQUMsa0JBQWtCLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUN2QyxLQUFJLENBQUMsa0JBQWtCLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQ3hDLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQztRQUVPLGdDQUFZLEdBQXBCLFVBQ0ksTUFBZ0MsRUFDaEMsTUFBOEIsRUFDOUIsY0FBZ0Q7WUFIcEQsaUJBMEdDO1lBdEdDLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFO2dCQUNsQixJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxDQUFDO2dCQUNwQixPQUFPO2FBQ1I7WUFFTSxJQUFBLDRCQUFVLENBQVM7WUFDMUIsSUFBTSxTQUFTLEdBQUc7Z0JBQ2hCLEtBQUssRUFBRSxFQUFFO2dCQUNULE1BQU0sRUFBRSxLQUFLO2dCQUNiLFFBQVEsRUFBRSxxQkFBcUIsQ0FBQyxHQUFHO2dCQUNuQyxRQUFRLFlBQUMsQ0FBeUI7b0JBQ2hDLEVBQUUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDO3lCQUNWLE1BQU0sQ0FBQyxNQUFNLENBQUM7eUJBQ2QsS0FBSyxDQUNGLGtCQUFrQixFQUNsQixjQUFNLE9BQUEsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUEzQyxDQUEyQyxDQUFDLENBQUM7b0JBQzNELE9BQU8sRUFBRSxDQUFDO2dCQUNaLENBQUM7Z0JBQ0QsS0FBSyxZQUFDLENBQXlCO29CQUM3QixFQUFFLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQzt5QkFDVixNQUFNLENBQUMsTUFBTSxDQUFDO3lCQUNkLE9BQU8sQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDO3lCQUN2QixLQUFLLENBQ0Ysa0JBQWtCLEVBQ2xCLGNBQU0sT0FBQSxVQUFVLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsUUFBUSxFQUFFLENBQUMsSUFBSSxDQUFDLEVBQTNDLENBQTJDLENBQUMsQ0FBQztnQkFDN0QsQ0FBQzthQUNGLENBQUM7WUFDRixjQUFjLElBQUksU0FBUyxTQUFLLGNBQWMsQ0FBQyxDQUFDO1lBRWhELDRDQUE0QztZQUM1QyxJQUFJLGNBQWMsR0FBRyxnQkFBZ0IsQ0FBQyxtQkFBbUIsQ0FDckQsZ0JBQWdCLENBQUMsNkJBQTZCLENBQUMsQ0FBQztZQUVwRCxJQUFNLElBQUksR0FBRyxVQUFDLENBQXlCO2dCQUNuQyxPQUFBLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxNQUFNLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxNQUFNLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQztZQUF6RCxDQUF5RCxDQUFDO1lBQzlELElBQU0sV0FBVyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1lBRTVDLElBQU0sZUFBZSxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO2dCQUMzQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUM7WUFFaEQsSUFBSSxJQUFJLENBQUMsb0JBQW9CLEtBQUssV0FBVyxFQUFFO2dCQUM3QyxNQUFNLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsVUFBQyxDQUFDLElBQUssT0FBQSxlQUFlLENBQUMsQ0FBQyxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLEVBQXZDLENBQXVDLENBQUMsQ0FBQzthQUMzRTtpQkFBTSxJQUFJLElBQUksQ0FBQyxvQkFBb0IsS0FBSyxZQUFZLEVBQUU7Z0JBQ3JELE1BQU0sR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxVQUFDLENBQUMsSUFBSyxPQUFBLGVBQWUsQ0FBQyxDQUFDLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsRUFBdkMsQ0FBdUMsQ0FBQztxQkFDM0QsT0FBTyxFQUFFLENBQUM7YUFDekI7aUJBQU0sSUFBSSxJQUFJLENBQUMsb0JBQW9CLEtBQUssU0FBUyxFQUFFO2dCQUNsRCxNQUFNLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLENBQUM7YUFDakM7aUJBQU07Z0JBQ0wsc0VBQXNFO2dCQUN0RSxzRUFBc0U7Z0JBQ3RFLGdFQUFnRTtnQkFDaEUsTUFBTSxHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxFQUFFLENBQUM7YUFDcEM7WUFFRCxJQUFNLElBQUksR0FBRyxJQUFJLENBQUM7WUFDbEIsSUFBTSxLQUFLLEdBQUcsRUFBRSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQ2hFLElBQU0sTUFBTSxHQUFHLEtBQUssQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDO2lCQUMvQixTQUFTLENBQUMsSUFBSSxDQUFDO2lCQUNmLElBQUksQ0FDRCxjQUFjLEVBQ2QsVUFBQyxNQUFzQyxFQUFFLENBQUMsRUFBRSxFQUFFO2dCQUM1QyxPQUFPLE1BQU0sQ0FBQyxLQUFLLENBQUE7WUFDckIsQ0FBQyxDQUFDLENBQUM7WUFDWCxJQUFNLGNBQWMsR0FBRyxNQUFNLENBQUMsS0FBSyxFQUFFO2lCQUNoQyxNQUFNLENBQUMsSUFBSSxDQUFDO2lCQUNaLElBQUksQ0FBQyxVQUFBLEdBQUcsSUFBSSxPQUFBLEdBQUcsQ0FBQyxLQUFLLEVBQVQsQ0FBUyxDQUFDO2lCQUN0QixLQUFLLEVBQUUsQ0FBQztZQUNiLE1BQU0sQ0FBQyxJQUFJLEVBQUUsQ0FBQyxNQUFNLEVBQUUsQ0FBQztZQUV2QixJQUFNLElBQUksR0FBRyxLQUFLLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQztpQkFDN0IsU0FBUyxDQUFDLElBQUksQ0FBQztpQkFDZixJQUFJLENBQUMsTUFBTSxFQUFFLFVBQUMsRUFBMEIsRUFBRSxDQUFDLEVBQUUsRUFBRTtnQkFDOUMsT0FBTyxFQUFFLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxDQUFDLElBQUksQ0FBQztZQUNwQyxDQUFDLENBQUMsQ0FBQztZQUNQLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxFQUFFLFVBQUMsQ0FBQztnQkFDcEIsdURBQXVEO2dCQUN2RCx5REFBeUQ7Z0JBQ3pELCtCQUErQjtnQkFDL0IsSUFBSSxVQUFVLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDckMsSUFBSSxTQUFTLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxDQUFDLENBQUM7Z0JBQ3pDLElBQUksTUFBTSxHQUFHLEtBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEtBQUksQ0FBQyxTQUFTLENBQUMsVUFBVSxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztnQkFDekUsSUFBSSxLQUFLLEdBQUcsS0FBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsS0FBSSxDQUFDLFNBQVMsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO2dCQUN2RSxJQUFJLENBQUMsR0FBRyxLQUFJLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztvQkFDM0IsQ0FBQyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEtBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLEtBQUssRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO2dCQUNsRSxPQUFPLE1BQU0sQ0FBQyxDQUFDLEdBQUcsTUFBTSxJQUFJLE1BQU0sQ0FBQyxDQUFDLEdBQUcsS0FBSyxJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUMzRCxDQUFDLENBQUM7aUJBQ0QsT0FBTyxDQUFDLFNBQVMsRUFBRSxVQUFDLENBQUMsSUFBSyxPQUFBLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxXQUFXLEVBQXZCLENBQXVCLENBQUM7aUJBQ2xELElBQUksQ0FBQyxVQUFTLEtBQUs7Z0JBQ2xCLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxFQUFFLGNBQWMsRUFBRSxLQUFLLENBQUMsQ0FBQztZQUNuRCxDQUFDLENBQUM7Z0JBQ0Ysb0RBQW9EO2lCQUNuRCxLQUFLLEVBQUUsQ0FBQztZQUViLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQyxNQUFNLEVBQUUsQ0FBQztZQUNyQixJQUFNLFdBQVcsR0FBRyxJQUFJLENBQUMsS0FBSyxFQUFFO2lCQUMzQixNQUFNLENBQUMsSUFBSSxDQUFDO2lCQUNaLElBQUksQ0FBQyxVQUFTLEtBQUs7Z0JBQ2xCLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxFQUFFLGNBQWMsRUFBRSxLQUFLLENBQUMsQ0FBQztZQUNuRCxDQUFDLENBQUM7aUJBQ0QsS0FBSyxFQUFFLENBQUM7WUFDYixJQUFNLFFBQVEsR0FBTyxjQUFjLFFBQUssV0FBVyxDQUFjLENBQUM7WUFDbEUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksRUFBRSxFQUFFLFFBQVEsQ0FBQyxDQUFDO1FBQ2xFLENBQUM7UUFFTyxrQ0FBYyxHQUF0QixVQUNJLEdBQWdCLEVBQ2hCLGNBQWdELEVBQ2hELEtBQTZCO1lBQy9CLElBQU0sSUFBSSxHQUFHLElBQUksQ0FBQztZQUNsQixJQUFNLE9BQU8sR0FBRyxFQUFFLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUM7WUFFcEUsT0FBTyxDQUFDLElBQUksQ0FBQyxVQUFTLEdBQWtCO2dCQUN0QyxzREFBc0Q7Z0JBQ3RELElBQUksR0FBRyxDQUFDLE1BQU07b0JBQUUsT0FBTztnQkFDdkIsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsSUFBSSxFQUFFLEdBQUcsRUFBRSxLQUFLLENBQUMsQ0FBQztZQUN0RCxDQUFDLENBQUMsQ0FBQztZQUNILE9BQU8sQ0FBQyxLQUFLLEVBQUU7aUJBQ1YsTUFBTSxDQUFDLElBQUksQ0FBQztpQkFDWixJQUFJLENBQUMsVUFBUyxHQUFrQjtnQkFDL0IsSUFBSSxHQUFHLENBQUMsS0FBSztvQkFBRSxHQUFHLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsS0FBSyxDQUFDLENBQUM7Z0JBQzNDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLElBQUksRUFBRSxHQUFHLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFDdEQsQ0FBQyxDQUFDLENBQUM7UUFDVCxDQUFDO1FBRU8scUNBQWlCLEdBQXpCLFVBQ0ksTUFBbUIsRUFDbkIsVUFBeUIsRUFDekIsS0FBNkI7WUFDeEIsSUFBQSx3Q0FBZ0IsQ0FBUztZQUNoQyxJQUFJLFVBQVUsQ0FBQyxRQUFRLElBQUkscUJBQXFCLENBQUMsR0FBRyxFQUFFO2dCQUNwRCxVQUFVLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsS0FBSyxFQUFFLEVBQUMsZ0JBQWdCLGtCQUFBLEVBQUMsQ0FBQyxDQUFDO2FBQzdEO2lCQUFNO2dCQUNMLEVBQUUsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO3FCQUNaLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsS0FBSyxFQUFFLEVBQUMsZ0JBQWdCLGtCQUFBLEVBQUMsQ0FBQyxDQUFDLENBQUM7YUFDeEU7UUFDSCxDQUFDO1FBRU8sb0NBQWdCLEdBQXhCLFVBQ0ksTUFBOEIsRUFDOUIsT0FBMEI7WUFGOUIsaUJBMkJDO1lBeEJDLElBQU0sT0FBTyxHQUFhLE9BQU8sQ0FBQyxJQUFJLEVBQUU7aUJBQ25DLEdBQUcsQ0FBQyxVQUFDLENBQUMsRUFBRSxDQUFDLElBQUssT0FBQSxLQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxLQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsT0FBTyxDQUFDLENBQUMsRUFBaEQsQ0FBZ0QsQ0FBQyxDQUFDO1lBRXJFLElBQUksR0FBRyxHQUFXLENBQUMsQ0FBQyxXQUFXLENBQUMsT0FBTyxFQUFFLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUVuRCxJQUFJLE9BQU8sQ0FBQyxNQUFNLElBQUksQ0FBQztnQkFBRSxPQUFPLElBQUksQ0FBQztZQUNyQyxJQUFJLEdBQUcsS0FBSyxPQUFPLENBQUMsTUFBTSxFQUFFO2dCQUMxQixHQUFHLEdBQUcsR0FBRyxHQUFHLENBQUMsQ0FBQzthQUNmO2lCQUFNLElBQUksR0FBRyxLQUFLLENBQUMsRUFBRTtnQkFDcEIsSUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsR0FBRyxHQUFHLENBQUMsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDdkQsSUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNuRCxHQUFHLEdBQUksUUFBUSxHQUFHLFFBQVEsQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO2FBQzVDO1lBRUQsSUFBTSxLQUFLLEdBQUcsT0FBTyxDQUFDLElBQUksRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ2xDLElBQU0sQ0FBQyxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO2dCQUM3QixJQUFJLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxFQUFFLEdBQUcsRUFBRSxPQUFPLENBQUMsQ0FBQyxDQUFDO2dCQUM1QyxJQUFJLENBQUMsY0FBYyxDQUFDLEtBQUssRUFBRSxHQUFHLEVBQUUsT0FBTyxDQUFDLENBQUM7WUFDN0MsT0FBTztnQkFDTCxDQUFDLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQztnQkFDZixDQUFDLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO2dCQUN2QixLQUFLLE9BQUE7Z0JBQ0wsT0FBTyxTQUFBO2FBQ1IsQ0FBQztRQUNKLENBQUM7UUFFTyxtQ0FBZSxHQUF2QixVQUF3QixPQUEwQjtZQUFsRCxpQkErQkM7WUE5QkMsSUFBSSxJQUFJLEdBQUcsT0FBTyxDQUFDLElBQUksRUFBRSxDQUFDO1lBQzFCLElBQU0sZUFBZSxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUM7WUFDN0MseURBQXlEO1lBQ3pELDJDQUEyQztZQUMzQyxJQUFJLElBQUksR0FBRyxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7WUFDckMsSUFBSSxRQUFRLEdBQUcsQ0FBQyxDQUFDO1lBQ2pCLElBQUksQ0FBQyxPQUFPLENBQUMsVUFBQyxDQUFDLEVBQUUsQ0FBQztnQkFDaEIsSUFBSSxPQUFPLEdBQUcsS0FBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxDQUFDO2dCQUNqRCxJQUFJLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsRUFBRTtvQkFDeEIsQ0FBQyxDQUFDLFFBQVEsR0FBRyxPQUFPLENBQUM7aUJBQ3RCO3FCQUFNO29CQUNMLElBQUksR0FBRyxJQUFJLEdBQUcsZUFBZSxHQUFHLENBQUMsQ0FBQyxHQUFHLGVBQWUsQ0FBQyxHQUFHLE9BQU8sQ0FBQztvQkFDaEUsUUFBUSxFQUFFLENBQUM7b0JBQ1gsc0VBQXNFO29CQUN0RSx3RUFBd0U7b0JBQ3hFLGlFQUFpRTtvQkFDakUsTUFBTTtvQkFDTixnRUFBZ0U7b0JBQ2hFLHNCQUFzQjtvQkFDdEIsTUFBTTtvQkFDTixxRUFBcUU7b0JBQ3JFLG9FQUFvRTtvQkFDcEUsZ0RBQWdEO29CQUNoRCxJQUFJLFlBQVksR0FBRyxDQUFDLENBQUM7b0JBQ3JCLElBQUksZUFBZSxLQUFLLEdBQUcsRUFBRTt3QkFDM0IsWUFBWSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsRUFBRSxRQUFRLENBQUMsQ0FBQztxQkFDMUQ7b0JBQ0QsQ0FBQyxDQUFDLFFBQVEsR0FBRyxJQUFJLEdBQUcsWUFBWSxDQUFDO2lCQUNsQztZQUNILENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQztRQUVPLDhCQUFVLEdBQWxCLFVBQW1CLElBQVk7WUFDN0IsSUFBSSxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxLQUFLLFNBQVMsRUFBRTtnQkFDMUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsR0FBRyxJQUFJLFNBQVMsQ0FBQyxPQUFPLENBQUMsRUFBRSxFQUFFO29CQUNuRCxJQUFJLE1BQUE7b0JBQ0osSUFBSSxFQUFFLElBQUk7aUJBQ1gsQ0FBQyxDQUFDO2FBQ0o7WUFDRCxPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDbEMsQ0FBQztRQUVNLDJCQUFpQixHQUF4QixVQUF5QixVQUFrQjtZQUV6QyxJQUFJLFVBQVUsS0FBSyxLQUFLLEVBQUU7Z0JBQ3hCLE9BQU8sSUFBSSxTQUFTLENBQUMsTUFBTSxDQUFDLFdBQVcsRUFBRSxDQUFDO2FBQzNDO2lCQUFNLElBQUksVUFBVSxLQUFLLFFBQVEsRUFBRTtnQkFDbEMsT0FBTyxJQUFJLFNBQVMsQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFLENBQUM7YUFDdEM7aUJBQU07Z0JBQ0wsTUFBTSxJQUFJLEtBQUssQ0FBQywyQkFBMkIsR0FBRyxVQUFVLENBQUMsQ0FBQzthQUMzRDtRQUNILENBQUM7UUFFRDs7V0FFRztRQUNJLG9DQUFnQixHQUF2QixVQUF3QixLQUFlO1lBQXZDLGlCQWlCQztZQWhCQyxLQUFLLEdBQUcsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO1lBQ3JCLElBQUksQ0FBQyxXQUFXLEdBQUcsS0FBSyxDQUFDO1lBRXpCLEtBQUssQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFFLDJCQUEyQjtZQUM3QyxJQUFJLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxVQUFDLENBQUMsSUFBSyxPQUFBLENBQUMsQ0FBQyxTQUFTLENBQUMsS0FBSSxDQUFDLGdCQUFnQixDQUFDLEVBQWxDLENBQWtDLENBQUMsQ0FBQztZQUNqRSxJQUFJLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQyxHQUFHLENBQUMsVUFBQyxDQUFDLElBQUssT0FBQSxLQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxFQUFsQixDQUFrQixDQUFDLENBQUM7WUFDckQsSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsVUFBQyxDQUFDLElBQUssT0FBQSxDQUFDLENBQUMsUUFBUSxDQUFDLEtBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFqQyxDQUFpQyxDQUFDLENBQUM7WUFDaEUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBRXRDLElBQUksSUFBSSxDQUFDLGdCQUFnQixFQUFFO2dCQUN6QixJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7YUFDN0M7WUFDRCxJQUFJLElBQUksQ0FBQyxjQUFjLEVBQUU7Z0JBQ3ZCLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQzthQUM3QztZQUNELElBQUksQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO1FBQy9CLENBQUM7UUFFRDs7OztXQUlHO1FBQ0ksa0RBQThCLEdBQXJDLFVBQXNDLFFBQTJCO1lBRS9ELElBQU0sWUFBWSxHQUFHLFFBQVEsQ0FBQyxJQUFJLEVBQUUsQ0FBQztZQUNyQyxJQUFJLFlBQVksQ0FBQyxNQUFNLElBQUksWUFBWSxFQUFFO2dCQUN2QywrQ0FBK0M7Z0JBQy9DLE9BQU8sUUFBUSxDQUFDO2FBQ2pCO1lBRUQsc0VBQXNFO1lBQ3RFLElBQU0sVUFBVSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLE1BQU0sR0FBRyxZQUFZLENBQUMsQ0FBQztZQUNqRSxJQUFNLElBQUksR0FBRyxJQUFJLEtBQUssQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxNQUFNLEdBQUcsVUFBVSxDQUFDLENBQUMsQ0FBQztZQUNyRSxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsSUFBSSxVQUFVLEVBQUU7Z0JBQzVELElBQUksQ0FBQyxDQUFDLENBQUMsR0FBRyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFDM0I7WUFDRCxPQUFPLElBQUksU0FBUyxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsUUFBUSxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUM7UUFDMUQsQ0FBQztRQUVEOztXQUVHO1FBQ0ksaUNBQWEsR0FBcEIsVUFBcUIsSUFBWSxFQUFFLElBQW9DO1lBQ3JFLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQ2pDLElBQUksQ0FBQyx3Q0FBd0MsRUFBRSxDQUFDO1FBQ2xELENBQUM7UUFFRDs7V0FFRztRQUNJLHFDQUFpQixHQUF4QixVQUF5QixJQUFZLEVBQUUsSUFBUztZQUM5QyxJQUFNLE9BQU8sR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLEVBQUMsSUFBSSxNQUFBLEVBQUMsQ0FBQyxDQUFDO1lBQzVFLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQzFDLENBQUM7UUFFTSxtQ0FBZSxHQUF0QixVQUF1QixNQUFjO1lBQXJDLGlCQWlCQztZQWhCQyxJQUFJLENBQUMsZUFBZSxHQUFHLE1BQU0sQ0FBQztZQUM5QixJQUFJLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxVQUFDLENBQUMsSUFBSyxPQUFBLEtBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLEVBQXZCLENBQXVCLENBQUMsQ0FBQztZQUV0RCxJQUFJLENBQUMsSUFBSSxDQUFDLGdCQUFnQixFQUFFO2dCQUMxQixJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQztnQkFDaEMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGdCQUFnQixFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztnQkFDdkQsSUFBSSxDQUFDLGdCQUFnQixHQUFHLElBQUksQ0FBQztnQkFDN0IsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO2FBQzdDO1lBRUQsSUFBSSxJQUFJLENBQUMsa0JBQWtCLEVBQUU7Z0JBQzNCLG1EQUFtRDtnQkFDbkQsSUFBSSxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7YUFDakU7WUFFRCxJQUFJLENBQUMscUJBQXFCLEVBQUUsQ0FBQztRQUMvQixDQUFDO1FBRU0sb0NBQWdCLEdBQXZCO1lBQ0UsSUFBSSxJQUFJLENBQUMsZ0JBQWdCLEVBQUU7Z0JBQ3pCLElBQUksQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxDQUFDO2dCQUNuQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsY0FBYyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztnQkFDckQsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLENBQUM7Z0JBQ2pDLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxLQUFLLENBQUM7Z0JBQzlCLElBQUksQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO2FBQzlCO1lBQ0QsSUFBSSxJQUFJLENBQUMsa0JBQWtCLEVBQUU7Z0JBQzNCLGtFQUFrRTtnQkFDbEUsbUNBQW1DO2dCQUNuQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQzthQUNqRTtRQUNILENBQUM7UUFFTSwyQ0FBdUIsR0FBOUIsVUFBK0IsTUFBYztZQUMzQyxJQUFJLENBQUMsb0JBQW9CLEdBQUcsTUFBTSxDQUFDO1FBQ3JDLENBQUM7UUFFTSw0QkFBUSxHQUFmLFVBQWdCLFNBQTJDO1lBQ3pELElBQUksQ0FBQyxTQUFTLEdBQUcsU0FBUyxDQUFDO1lBQzNCLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBRS9CLElBQUksSUFBSSxDQUFDLGNBQWMsSUFBSSxJQUFJLEVBQUU7Z0JBQy9CLG9FQUFvRTtnQkFDcEUseUJBQXlCO2dCQUN6QixJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7YUFDckI7WUFFRCxJQUFJLElBQUksQ0FBQyxjQUFjLElBQUksSUFBSSxFQUFFO2dCQUMvQixvRUFBb0U7Z0JBQ3BFLHlCQUF5QjtnQkFDekIsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO2FBQ3JCO1lBRUQsSUFBSSxDQUFDLHdDQUF3QyxFQUFFLENBQUM7UUFDbEQsQ0FBQztRQUVNLDBCQUFNLEdBQWI7WUFBQSxpQkFNQztZQUxDLE1BQU0sQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7WUFDN0MsSUFBSSxDQUFDLFVBQVUsR0FBRyxNQUFNLENBQUMscUJBQXFCLENBQUM7Z0JBQzdDLEtBQUksQ0FBQyxtQ0FBbUMsRUFBRSxDQUFDO2dCQUMzQyxLQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDO1lBQ3RCLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQztRQUVPLDREQUF3QyxHQUFoRDtZQUFBLGlCQUtDO1lBSkMsTUFBTSxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO1lBQ3ZELElBQUksQ0FBQyxvQkFBb0IsR0FBRyxNQUFNLENBQUMscUJBQXFCLENBQUM7Z0JBQ3ZELEtBQUksQ0FBQyxtQ0FBbUMsRUFBRSxDQUFDO1lBQzdDLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQztRQUVEOzs7Ozs7V0FNRztRQUNLLHVEQUFtQyxHQUEzQztZQUNFLElBQUksSUFBSSxDQUFDLGFBQWEsRUFBRTtnQkFDZixJQUFBLG9DQUFnQixDQUF1QjtnQkFDdkMsSUFBQSwyREFBSyxDQUFrRDtnQkFDOUQsSUFBSSxTQUFTLElBQUksQ0FBQyxJQUFJLFNBQVMsR0FBRyxLQUFLO29CQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsZUFBZSxFQUFFLENBQUM7YUFDdkU7WUFDRCxJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFFLENBQUMscUJBQXFCLEVBQUUsQ0FBQztRQUNyRSxDQUFDO1FBRU0sMkJBQU8sR0FBZDtZQUNFLDJEQUEyRDtZQUMzRCxNQUFNLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBQzdDLE1BQU0sQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsb0JBQW9CLENBQUMsQ0FBQztZQUN2RCxJQUFJLElBQUksQ0FBQyxLQUFLO2dCQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxFQUFFLENBQUM7UUFDdkMsQ0FBQztRQUVNLDRCQUFRLEdBQWYsVUFBZ0IsRUFBYztZQUM1QixJQUFJLElBQUksQ0FBQyxLQUFLO2dCQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQzFDLENBQUM7UUFDSCxnQkFBQztJQUFELENBQUMsQUF2MEJELElBdTBCQztJQXYwQlksd0JBQVMsWUF1MEJyQixDQUFBO0FBRUQsQ0FBQyxFQW4zQlMsY0FBYyxLQUFkLGNBQWMsUUFtM0J2QixDQUFFLDJCQUEyQiIsInNvdXJjZXNDb250ZW50IjpbIi8qIENvcHlyaWdodCAyMDE4IFRoZSBUZW5zb3JGbG93IEF1dGhvcnMuIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG5cbkxpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSBcIkxpY2Vuc2VcIik7XG55b3UgbWF5IG5vdCB1c2UgdGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlIHdpdGggdGhlIExpY2Vuc2UuXG5Zb3UgbWF5IG9idGFpbiBhIGNvcHkgb2YgdGhlIExpY2Vuc2UgYXRcblxuICAgIGh0dHA6Ly93d3cuYXBhY2hlLm9yZy9saWNlbnNlcy9MSUNFTlNFLTIuMFxuXG5Vbmxlc3MgcmVxdWlyZWQgYnkgYXBwbGljYWJsZSBsYXcgb3IgYWdyZWVkIHRvIGluIHdyaXRpbmcsIHNvZnR3YXJlXG5kaXN0cmlidXRlZCB1bmRlciB0aGUgTGljZW5zZSBpcyBkaXN0cmlidXRlZCBvbiBhbiBcIkFTIElTXCIgQkFTSVMsXG5XSVRIT1VUIFdBUlJBTlRJRVMgT1IgQ09ORElUSU9OUyBPRiBBTlkgS0lORCwgZWl0aGVyIGV4cHJlc3Mgb3IgaW1wbGllZC5cblNlZSB0aGUgTGljZW5zZSBmb3IgdGhlIHNwZWNpZmljIGxhbmd1YWdlIGdvdmVybmluZyBwZXJtaXNzaW9ucyBhbmRcbmxpbWl0YXRpb25zIHVuZGVyIHRoZSBMaWNlbnNlLlxuPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09Ki9cbm5hbWVzcGFjZSB2el9saW5lX2NoYXJ0MiB7XG5cbi8qKlxuICogQW4gaW50ZXJmYWNlIHRoYXQgZGVzY3JpYmVzIGEgZmlsbCBhcmVhIHRvIHZpc3VhbGl6ZS4gVGhlIGZpbGwgYXJlYSBpc1xuICogdmlzdWFsaXplZCB3aXRoIGEgbGVzcyBpbnRlbnNlIHZlcnNpb24gb2YgdGhlIGNvbG9yIGZvciBhIGdpdmVuIHNlcmllcy5cbiAqL1xuaW50ZXJmYWNlIEZpbGxBcmVhIHtcbiAgLy8gVGhlIGxvd2VyIGVuZCBvZiB0aGUgZmlsbCBhcmVhLlxuICBsb3dlckFjY2Vzc29yOiBQbG90dGFibGUuSUFjY2Vzc29yPG51bWJlcj47XG5cbiAgLy8gVGhlIGhpZ2hlciBlbmQgb2YgdGhlIGZpbGwgYXJlYS5cbiAgaGlnaGVyQWNjZXNzb3I6IFBsb3R0YWJsZS5JQWNjZXNzb3I8bnVtYmVyPjtcbn1cblxuZW51bSBUb29sdGlwQ29sdW1uRXZhbFR5cGUge1xuICBURVhULFxuICBET00sXG59XG5cbmV4cG9ydCB0eXBlIExpbmVDaGFydFN0YXR1cyA9IHtcbiAgc21vb3RoaW5nRW5hYmxlZDogYm9vbGVhblxufTtcblxuLyoqXG4gKiBBZGRzIHByaXZhdGUgQVBJcyBmb3IgZGVmYXVsdCBzd2F0Y2ggY29sdW1uIG9uIHRoZSBmaXJzdCBjb2x1bW4uXG4gKi9cbmludGVyZmFjZSBUb29sdGlwQ29sdW1uIGV4dGVuZHMgdnpfY2hhcnRfaGVscGVycy5Ub29sdGlwQ29sdW1uIHtcbiAgZXZhbFR5cGU/OiBUb29sdGlwQ29sdW1uRXZhbFR5cGU7XG4gIGVudGVyOiAoKSA9PiB2b2lkO1xufVxuXG5leHBvcnQgdHlwZSBNZXRhZGF0YSA9IHtcbiAgbmFtZTogc3RyaW5nLFxuICBtZXRhOiBhbnksXG59O1xuXG4vKipcbiAqIFRoZSBtYXhpbXVtIG51bWJlciBvZiBtYXJrZXIgc3ltYm9scyB3aXRoaW4gYW55IGxpbmUgZm9yIGEgZGF0YSBzZXJpZXMuIFRvb1xuICogbWFueSBtYXJrZXJzIGNsdXR0ZXIgdGhlIGNoYXJ0LlxuICovXG5jb25zdCBfTUFYX01BUktFUlMgPSAyMDtcblxuZXhwb3J0IGNsYXNzIExpbmVDaGFydCB7XG4gIHByaXZhdGUgbmFtZTJkYXRhc2V0czoge1tuYW1lOiBzdHJpbmddOiBQbG90dGFibGUuRGF0YXNldH07XG4gIHByaXZhdGUgc2VyaWVzTmFtZXM6IHN0cmluZ1tdO1xuXG4gIHByaXZhdGUgeEFjY2Vzc29yOiBQbG90dGFibGUuSUFjY2Vzc29yPG51bWJlcnxEYXRlPjtcbiAgcHJpdmF0ZSB4U2NhbGU6IFBsb3R0YWJsZS5RdWFudGl0YXRpdmVTY2FsZTxudW1iZXJ8RGF0ZT47XG4gIHByaXZhdGUgeVNjYWxlOiBQbG90dGFibGUuUXVhbnRpdGF0aXZlU2NhbGU8bnVtYmVyPjtcbiAgcHJpdmF0ZSBncmlkbGluZXM6IFBsb3R0YWJsZS5Db21wb25lbnRzLkdyaWRsaW5lcztcbiAgcHJpdmF0ZSBjZW50ZXI6IFBsb3R0YWJsZS5Db21wb25lbnRzLkdyb3VwO1xuICBwcml2YXRlIHhBeGlzOiBQbG90dGFibGUuQXhlcy5OdW1lcmljfFBsb3R0YWJsZS5BeGVzLlRpbWU7XG4gIHByaXZhdGUgeUF4aXM6IFBsb3R0YWJsZS5BeGVzLk51bWVyaWM7XG4gIHByaXZhdGUgb3V0ZXI6IFBsb3R0YWJsZS5Db21wb25lbnRzLlRhYmxlO1xuICBwcml2YXRlIGNvbG9yU2NhbGU6IFBsb3R0YWJsZS5TY2FsZXMuQ29sb3I7XG4gIHByaXZhdGUgc3ltYm9sRnVuY3Rpb246IHZ6X2NoYXJ0X2hlbHBlcnMuU3ltYm9sRm47XG5cbiAgcHJpdmF0ZSB0b29sdGlwQ29sdW1uczogdnpfY2hhcnRfaGVscGVycy5Ub29sdGlwQ29sdW1uW107XG4gIHByaXZhdGUgdG9vbHRpcDogdnpfY2hhcnRfaGVscGVyLlZ6Q2hhcnRUb29sdGlwO1xuICBwcml2YXRlIHRvb2x0aXBJbnRlcmFjdGlvbjogUGxvdHRhYmxlLkludGVyYWN0aW9ucy5Qb2ludGVyO1xuICBwcml2YXRlIHRvb2x0aXBQb2ludHNDb21wb25lbnQ6IFBsb3R0YWJsZS5Db21wb25lbnQ7XG5cbiAgcHJpdmF0ZSBsaW5lUGxvdDogUGxvdHRhYmxlLlBsb3RzLkxpbmU8bnVtYmVyfERhdGU+O1xuICBwcml2YXRlIHNtb290aExpbmVQbG90OiBQbG90dGFibGUuUGxvdHMuTGluZTxudW1iZXJ8RGF0ZT47XG4gIHByaXZhdGUgbWFyZ2luQXJlYVBsb3Q/OiBQbG90dGFibGUuUGxvdHMuQXJlYTxudW1iZXJ8RGF0ZT47XG4gIHByaXZhdGUgc2NhdHRlclBsb3Q6IFBsb3R0YWJsZS5QbG90cy5TY2F0dGVyPG51bWJlcnxEYXRlLCBOdW1iZXI+O1xuICBwcml2YXRlIG5hbkRpc3BsYXk6IFBsb3R0YWJsZS5QbG90cy5TY2F0dGVyPG51bWJlcnxEYXRlLCBOdW1iZXI+O1xuICBwcml2YXRlIG1hcmtlcnNTY2F0dGVyUGxvdDogUGxvdHRhYmxlLlBsb3RzLlNjYXR0ZXI8bnVtYmVyfERhdGUsIG51bWJlcj47XG5cbiAgcHJpdmF0ZSB5VmFsdWVBY2Nlc3NvcjogUGxvdHRhYmxlLklBY2Nlc3NvcjxudW1iZXI+O1xuICBwcml2YXRlIHNtb290aGVkQWNjZXNzb3I6IFBsb3R0YWJsZS5JQWNjZXNzb3I8bnVtYmVyPjtcbiAgcHJpdmF0ZSBsYXN0UG9pbnRzRGF0YXNldDogUGxvdHRhYmxlLkRhdGFzZXQ7XG4gIHByaXZhdGUgZmlsbEFyZWE/OiBGaWxsQXJlYTtcbiAgcHJpdmF0ZSBkYXRhc2V0czogUGxvdHRhYmxlLkRhdGFzZXRbXTtcbiAgcHJpdmF0ZSBvbkRhdGFzZXRDaGFuZ2VkOiAoZGF0YXNldDogUGxvdHRhYmxlLkRhdGFzZXQpID0+IHZvaWQ7XG4gIHByaXZhdGUgbmFuRGF0YXNldDogUGxvdHRhYmxlLkRhdGFzZXQ7XG4gIHByaXZhdGUgc21vb3RoaW5nV2VpZ2h0OiBudW1iZXI7XG4gIHByaXZhdGUgc21vb3RoaW5nRW5hYmxlZDogYm9vbGVhbjtcbiAgcHJpdmF0ZSB0b29sdGlwU29ydGluZ01ldGhvZDogc3RyaW5nO1xuICBwcml2YXRlIF9pZ25vcmVZT3V0bGllcnM6IGJvb2xlYW47XG4gIHByaXZhdGUgX2xhc3RNb3VzZVBvc2l0aW9uOiBQbG90dGFibGUuUG9pbnQ7XG4gIHByaXZhdGUgX2xhc3REcmF3QkJveDogRE9NUmVjdDtcbiAgcHJpdmF0ZSBfcmVkcmF3UmFmOiBudW1iZXI7XG4gIHByaXZhdGUgX2ludmFsaWRhdGVMYXlvdXRSYWY6IG51bWJlcjtcblxuICAvLyBBbiBvcHRpb25hbCBsaXN0IG9mIDIgbnVtYmVycy5cbiAgcHJpdmF0ZSBfZGVmYXVsdFhSYW5nZTogbnVtYmVyW107XG4gIC8vIEFuIG9wdGlvbmFsIGxpc3Qgb2YgMiBudW1iZXJzLlxuICBwcml2YXRlIF9kZWZhdWx0WVJhbmdlOiBudW1iZXJbXTtcblxuICBwcml2YXRlIF90b29sdGlwVXBkYXRlQW5pbWF0aW9uRnJhbWU6IG51bWJlcjtcblxuICBwcml2YXRlIHRhcmdldFNWRzogZDMuU2VsZWN0aW9uPGFueSwgYW55LCBhbnksIGFueT47XG5cbiAgY29uc3RydWN0b3IoXG4gICAgICB4Q29tcG9uZW50c0NyZWF0aW9uTWV0aG9kOiAoKSA9PiB2el9jaGFydF9oZWxwZXJzLlhDb21wb25lbnRzLFxuICAgICAgeVZhbHVlQWNjZXNzb3I6IFBsb3R0YWJsZS5JQWNjZXNzb3I8bnVtYmVyPixcbiAgICAgIHlTY2FsZVR5cGU6IHN0cmluZyxcbiAgICAgIGNvbG9yU2NhbGU6IFBsb3R0YWJsZS5TY2FsZXMuQ29sb3IsXG4gICAgICB0b29sdGlwOiB2el9jaGFydF9oZWxwZXIuVnpDaGFydFRvb2x0aXAsXG4gICAgICB0b29sdGlwQ29sdW1uczogdnpfY2hhcnRfaGVscGVycy5Ub29sdGlwQ29sdW1uW10sXG4gICAgICBmaWxsQXJlYTogRmlsbEFyZWEsXG4gICAgICBkZWZhdWx0WFJhbmdlPzogbnVtYmVyW10sXG4gICAgICBkZWZhdWx0WVJhbmdlPzogbnVtYmVyW10sXG4gICAgICBzeW1ib2xGdW5jdGlvbj86IHZ6X2NoYXJ0X2hlbHBlcnMuU3ltYm9sRm4sXG4gICAgICB4QXhpc0Zvcm1hdHRlcj86IChudW1iZXIpID0+IHN0cmluZykge1xuICAgIHRoaXMuc2VyaWVzTmFtZXMgPSBbXTtcbiAgICB0aGlzLm5hbWUyZGF0YXNldHMgPSB7fTtcbiAgICB0aGlzLmNvbG9yU2NhbGUgPSBjb2xvclNjYWxlO1xuICAgIHRoaXMudG9vbHRpcCA9IHRvb2x0aXA7XG4gICAgdGhpcy5kYXRhc2V0cyA9IFtdO1xuICAgIHRoaXMuX2lnbm9yZVlPdXRsaWVycyA9IGZhbHNlO1xuICAgIC8vIGxhc3RQb2ludERhdGFzZXQgaXMgYSBkYXRhc2V0IHRoYXQgY29udGFpbnMganVzdCB0aGUgbGFzdCBwb2ludCBvZlxuICAgIC8vIGV2ZXJ5IGRhdGFzZXQgd2UncmUgY3VycmVudGx5IGRyYXdpbmcuXG4gICAgdGhpcy5sYXN0UG9pbnRzRGF0YXNldCA9IG5ldyBQbG90dGFibGUuRGF0YXNldCgpO1xuICAgIHRoaXMubmFuRGF0YXNldCA9IG5ldyBQbG90dGFibGUuRGF0YXNldCgpO1xuICAgIHRoaXMueVZhbHVlQWNjZXNzb3IgPSB5VmFsdWVBY2Nlc3NvcjtcblxuICAgIC8vIFRoZSBzeW1ib2wgZnVuY3Rpb24gbWFwcyBzZXJpZXMgdG8gbWFya2VyLiBJdCB1c2VzIGEgc3BlY2lhbCBkYXRhc2V0IHRoYXRcbiAgICAvLyB2YXJpZXMgYmFzZWQgb24gd2hldGhlciBzbW9vdGhpbmcgaXMgZW5hYmxlZC5cbiAgICB0aGlzLnN5bWJvbEZ1bmN0aW9uID0gc3ltYm9sRnVuY3Rpb247XG5cbiAgICAvLyBuZWVkIHRvIGRvIGEgc2luZ2xlIGJpbmQsIHNvIHdlIGNhbiBkZXJlZ2lzdGVyIHRoZSBjYWxsYmFjayBmcm9tXG4gICAgLy8gb2xkIFBsb3R0YWJsZS5EYXRhc2V0cy4gKERlcmVnaXN0cmF0aW9uIGlzIGRvbmUgYnkgaWRlbnRpdHkgY2hlY2tzLilcbiAgICB0aGlzLm9uRGF0YXNldENoYW5nZWQgPSB0aGlzLl9vbkRhdGFzZXRDaGFuZ2VkLmJpbmQodGhpcyk7XG5cbiAgICB0aGlzLl9kZWZhdWx0WFJhbmdlID0gZGVmYXVsdFhSYW5nZTtcbiAgICB0aGlzLl9kZWZhdWx0WVJhbmdlID0gZGVmYXVsdFlSYW5nZTtcbiAgICB0aGlzLnRvb2x0aXBDb2x1bW5zID0gdG9vbHRpcENvbHVtbnM7XG5cbiAgICB0aGlzLmJ1aWxkQ2hhcnQoXG4gICAgICAgIHhDb21wb25lbnRzQ3JlYXRpb25NZXRob2QsXG4gICAgICAgIHlWYWx1ZUFjY2Vzc29yLFxuICAgICAgICB5U2NhbGVUeXBlLFxuICAgICAgICBmaWxsQXJlYSxcbiAgICAgICAgeEF4aXNGb3JtYXR0ZXIpO1xuICB9XG5cbiAgcHJpdmF0ZSBidWlsZENoYXJ0KFxuICAgICAgeENvbXBvbmVudHNDcmVhdGlvbk1ldGhvZDogKCkgPT4gdnpfY2hhcnRfaGVscGVycy5YQ29tcG9uZW50cyxcbiAgICAgIHlWYWx1ZUFjY2Vzc29yOiBQbG90dGFibGUuSUFjY2Vzc29yPG51bWJlcj4sXG4gICAgICB5U2NhbGVUeXBlOiBzdHJpbmcsXG4gICAgICBmaWxsQXJlYTogRmlsbEFyZWEsXG4gICAgICB4QXhpc0Zvcm1hdHRlcjogKG51bWJlcikgPT4gc3RyaW5nKSB7XG4gICAgdGhpcy5kZXN0cm95KCk7XG4gICAgY29uc3QgeENvbXBvbmVudHMgPSB4Q29tcG9uZW50c0NyZWF0aW9uTWV0aG9kKCk7XG4gICAgdGhpcy54QWNjZXNzb3IgPSB4Q29tcG9uZW50cy5hY2Nlc3NvcjtcbiAgICB0aGlzLnhTY2FsZSA9IHhDb21wb25lbnRzLnNjYWxlO1xuICAgIHRoaXMueEF4aXMgPSB4Q29tcG9uZW50cy5heGlzO1xuICAgIHRoaXMueEF4aXMubWFyZ2luKDApLnRpY2tMYWJlbFBhZGRpbmcoMyk7XG4gICAgaWYgKHhBeGlzRm9ybWF0dGVyKSB7XG4gICAgICB0aGlzLnhBeGlzLmZvcm1hdHRlcih4QXhpc0Zvcm1hdHRlcik7XG4gICAgfVxuICAgIHRoaXMueVNjYWxlID0gTGluZUNoYXJ0LmdldFlTY2FsZUZyb21UeXBlKHlTY2FsZVR5cGUpO1xuICAgIHRoaXMueUF4aXMgPSBuZXcgUGxvdHRhYmxlLkF4ZXMuTnVtZXJpYyh0aGlzLnlTY2FsZSwgJ2xlZnQnKTtcbiAgICBsZXQgeUZvcm1hdHRlciA9IHZ6X2NoYXJ0X2hlbHBlcnMubXVsdGlzY2FsZUZvcm1hdHRlcihcbiAgICAgICAgdnpfY2hhcnRfaGVscGVycy5ZX0FYSVNfRk9STUFUVEVSX1BSRUNJU0lPTik7XG4gICAgdGhpcy55QXhpcy5tYXJnaW4oMCkudGlja0xhYmVsUGFkZGluZyg1KS5mb3JtYXR0ZXIoeUZvcm1hdHRlcik7XG4gICAgdGhpcy55QXhpcy51c2VzVGV4dFdpZHRoQXBwcm94aW1hdGlvbih0cnVlKTtcbiAgICB0aGlzLmZpbGxBcmVhID0gZmlsbEFyZWE7XG5cbiAgICBjb25zdCBwYW5ab29tTGF5ZXIgPSBuZXcgUGFuWm9vbURyYWdMYXllcihcbiAgICAgICAgdGhpcy54U2NhbGUsXG4gICAgICAgIHRoaXMueVNjYWxlLFxuICAgICAgICAoKSA9PiB0aGlzLnJlc2V0RG9tYWluKCkpO1xuXG4gICAgdGhpcy50b29sdGlwSW50ZXJhY3Rpb24gPSB0aGlzLmNyZWF0ZVRvb2x0aXBJbnRlcmFjdGlvbihwYW5ab29tTGF5ZXIpO1xuICAgIHRoaXMudG9vbHRpcFBvaW50c0NvbXBvbmVudCA9IG5ldyBQbG90dGFibGUuQ29tcG9uZW50KCk7XG5cbiAgICBjb25zdCBwbG90ID0gdGhpcy5idWlsZFBsb3QoXG4gICAgICAgIHRoaXMueFNjYWxlLFxuICAgICAgICB0aGlzLnlTY2FsZSxcbiAgICAgICAgZmlsbEFyZWEpO1xuXG4gICAgdGhpcy5ncmlkbGluZXMgPVxuICAgICAgICBuZXcgUGxvdHRhYmxlLkNvbXBvbmVudHMuR3JpZGxpbmVzKHRoaXMueFNjYWxlLCB0aGlzLnlTY2FsZSk7XG5cbiAgICBsZXQgeFplcm9MaW5lID0gbmV3IFBsb3R0YWJsZS5Db21wb25lbnRzLkd1aWRlTGluZUxheWVyKCdob3Jpem9udGFsJyk7XG4gICAgeFplcm9MaW5lLnNjYWxlKHRoaXMueVNjYWxlKS52YWx1ZSgwKTtcbiAgICBsZXQgeVplcm9MaW5lID0gbmV3IFBsb3R0YWJsZS5Db21wb25lbnRzLkd1aWRlTGluZUxheWVyKCd2ZXJ0aWNhbCcpO1xuICAgIHlaZXJvTGluZS5zY2FsZSh0aGlzLnhTY2FsZSkudmFsdWUoMCk7XG5cbiAgICB0aGlzLmNlbnRlciA9IG5ldyBQbG90dGFibGUuQ29tcG9uZW50cy5Hcm91cChbXG4gICAgICAgIHRoaXMuZ3JpZGxpbmVzLCB4WmVyb0xpbmUsIHlaZXJvTGluZSwgcGxvdCxcbiAgICAgICAgcGFuWm9vbUxheWVyLCB0aGlzLnRvb2x0aXBQb2ludHNDb21wb25lbnRdKTtcbiAgICB0aGlzLmNlbnRlci5hZGRDbGFzcygnbWFpbicpO1xuICAgIHRoaXMub3V0ZXIgPSBuZXcgUGxvdHRhYmxlLkNvbXBvbmVudHMuVGFibGUoXG4gICAgICAgIFtbdGhpcy55QXhpcywgdGhpcy5jZW50ZXJdLCBbbnVsbCwgdGhpcy54QXhpc11dKTtcbiAgfVxuXG4gIHByaXZhdGUgYnVpbGRQbG90KHhTY2FsZSwgeVNjYWxlLCBmaWxsQXJlYSk6XG4gICAgICBQbG90dGFibGUuQ29tcG9uZW50IHtcbiAgICBpZiAoZmlsbEFyZWEpIHtcbiAgICAgIHRoaXMubWFyZ2luQXJlYVBsb3QgPSBuZXcgUGxvdHRhYmxlLlBsb3RzLkFyZWE8bnVtYmVyfERhdGU+KCk7XG4gICAgICB0aGlzLm1hcmdpbkFyZWFQbG90LngodGhpcy54QWNjZXNzb3IsIHhTY2FsZSk7XG4gICAgICB0aGlzLm1hcmdpbkFyZWFQbG90LnkoZmlsbEFyZWEuaGlnaGVyQWNjZXNzb3IsIHlTY2FsZSk7XG4gICAgICB0aGlzLm1hcmdpbkFyZWFQbG90LnkwKGZpbGxBcmVhLmxvd2VyQWNjZXNzb3IpO1xuICAgICAgdGhpcy5tYXJnaW5BcmVhUGxvdC5hdHRyKFxuICAgICAgICAgICdmaWxsJyxcbiAgICAgICAgICAoZDogdnpfY2hhcnRfaGVscGVycy5EYXR1bSwgaTogbnVtYmVyLCBkYXRhc2V0OiBQbG90dGFibGUuRGF0YXNldCkgPT5cbiAgICAgICAgICAgICAgdGhpcy5jb2xvclNjYWxlLnNjYWxlKGRhdGFzZXQubWV0YWRhdGEoKS5uYW1lKSk7XG4gICAgICB0aGlzLm1hcmdpbkFyZWFQbG90LmF0dHIoJ2ZpbGwtb3BhY2l0eScsIDAuMyk7XG4gICAgICB0aGlzLm1hcmdpbkFyZWFQbG90LmF0dHIoJ3N0cm9rZS13aWR0aCcsIDApO1xuICAgIH1cblxuICAgIHRoaXMuc21vb3RoZWRBY2Nlc3NvciA9IChkOiAgdnpfY2hhcnRfaGVscGVycy5TY2FsYXJEYXR1bSkgPT4gZC5zbW9vdGhlZDtcbiAgICBsZXQgbGluZVBsb3QgPSBuZXcgUGxvdHRhYmxlLlBsb3RzLkxpbmU8bnVtYmVyfERhdGU+KCk7XG4gICAgbGluZVBsb3QueCh0aGlzLnhBY2Nlc3NvciwgeFNjYWxlKTtcbiAgICBsaW5lUGxvdC55KHRoaXMueVZhbHVlQWNjZXNzb3IsIHlTY2FsZSk7XG4gICAgbGluZVBsb3QuYXR0cihcbiAgICAgICAgJ3N0cm9rZScsXG4gICAgICAgIChkOiB2el9jaGFydF9oZWxwZXJzLkRhdHVtLCBpOiBudW1iZXIsIGRhdGFzZXQ6IFBsb3R0YWJsZS5EYXRhc2V0KSA9PlxuICAgICAgICAgICAgdGhpcy5jb2xvclNjYWxlLnNjYWxlKGRhdGFzZXQubWV0YWRhdGEoKS5uYW1lKSk7XG4gICAgdGhpcy5saW5lUGxvdCA9IGxpbmVQbG90O1xuICAgIHRoaXMuc2V0dXBUb29sdGlwcyhsaW5lUGxvdCk7XG5cbiAgICBsZXQgc21vb3RoTGluZVBsb3QgPSBuZXcgUGxvdHRhYmxlLlBsb3RzLkxpbmU8bnVtYmVyfERhdGU+KCk7XG4gICAgc21vb3RoTGluZVBsb3QueCh0aGlzLnhBY2Nlc3NvciwgeFNjYWxlKTtcbiAgICBzbW9vdGhMaW5lUGxvdC55KHRoaXMuc21vb3RoZWRBY2Nlc3NvciwgeVNjYWxlKTtcbiAgICBzbW9vdGhMaW5lUGxvdC5hdHRyKFxuICAgICAgICAnc3Ryb2tlJyxcbiAgICAgICAgKGQ6IHZ6X2NoYXJ0X2hlbHBlcnMuRGF0dW0sIGk6IG51bWJlciwgZGF0YXNldDogUGxvdHRhYmxlLkRhdGFzZXQpID0+XG4gICAgICAgICAgICB0aGlzLmNvbG9yU2NhbGUuc2NhbGUoZGF0YXNldC5tZXRhZGF0YSgpLm5hbWUpKTtcbiAgICB0aGlzLnNtb290aExpbmVQbG90ID0gc21vb3RoTGluZVBsb3Q7XG5cbiAgICBpZiAodGhpcy5zeW1ib2xGdW5jdGlvbikge1xuICAgICAgY29uc3QgbWFya2Vyc1NjYXR0ZXJQbG90ID0gbmV3IFBsb3R0YWJsZS5QbG90cy5TY2F0dGVyPG51bWJlcnxEYXRlLCBudW1iZXI+KCk7XG4gICAgICBtYXJrZXJzU2NhdHRlclBsb3QueCh0aGlzLnhBY2Nlc3NvciwgeFNjYWxlKTtcbiAgICAgIG1hcmtlcnNTY2F0dGVyUGxvdC55KHRoaXMueVZhbHVlQWNjZXNzb3IsIHlTY2FsZSk7XG4gICAgICBtYXJrZXJzU2NhdHRlclBsb3QuYXR0cihcbiAgICAgICAgICAnZmlsbCcsXG4gICAgICAgICAgKGQ6IHZ6X2NoYXJ0X2hlbHBlcnMuRGF0dW0sIGk6IG51bWJlciwgZGF0YXNldDogUGxvdHRhYmxlLkRhdGFzZXQpID0+XG4gICAgICAgICAgICAgIHRoaXMuY29sb3JTY2FsZS5zY2FsZShkYXRhc2V0Lm1ldGFkYXRhKCkubmFtZSkpO1xuICAgICAgbWFya2Vyc1NjYXR0ZXJQbG90LmF0dHIoJ29wYWNpdHknLCAxKTtcbiAgICAgIG1hcmtlcnNTY2F0dGVyUGxvdC5zaXplKHZ6X2NoYXJ0X2hlbHBlcnMuVE9PTFRJUF9DSVJDTEVfU0laRSAqIDIpO1xuICAgICAgbWFya2Vyc1NjYXR0ZXJQbG90LnN5bWJvbChcbiAgICAgICAgICAoZDogdnpfY2hhcnRfaGVscGVycy5EYXR1bSwgaTogbnVtYmVyLCBkYXRhc2V0OiBQbG90dGFibGUuRGF0YXNldCkgPT4ge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuc3ltYm9sRnVuY3Rpb24oZGF0YXNldC5tZXRhZGF0YSgpLm5hbWUpO1xuICAgICAgICAgIH0pO1xuICAgICAgLy8gVXNlIGEgc3BlY2lhbCBkYXRhc2V0IGJlY2F1c2UgdGhpcyBzY2F0dGVyIHBsb3Qgc2hvdWxkIHVzZSB0aGUgYWNjZXNvclxuICAgICAgLy8gdGhhdCBkZXBlbmRzIG9uIHdoZXRoZXIgc21vb3RoaW5nIGlzIGVuYWJsZWQuXG4gICAgICB0aGlzLm1hcmtlcnNTY2F0dGVyUGxvdCA9IG1hcmtlcnNTY2F0dGVyUGxvdDtcbiAgICB9XG5cbiAgICAvLyBUaGUgc2NhdHRlclBsb3Qgd2lsbCBkaXNwbGF5IHRoZSBsYXN0IHBvaW50IGZvciBlYWNoIGRhdGFzZXQuXG4gICAgLy8gVGhpcyB3YXksIGlmIHRoZXJlIGlzIG9ubHkgb25lIGRhdHVtIGZvciB0aGUgc2VyaWVzLCBpdCBpcyBzdGlsbFxuICAgIC8vIHZpc2libGUuIFdlIGhpZGUgaXQgd2hlbiB0b29sdGlwcyBhcmUgYWN0aXZlIHRvIGtlZXAgdGhpbmdzIGNsZWFuLlxuICAgIGxldCBzY2F0dGVyUGxvdCA9IG5ldyBQbG90dGFibGUuUGxvdHMuU2NhdHRlcjxudW1iZXJ8RGF0ZSwgbnVtYmVyPigpO1xuICAgIHNjYXR0ZXJQbG90LngodGhpcy54QWNjZXNzb3IsIHhTY2FsZSk7XG4gICAgc2NhdHRlclBsb3QueSh0aGlzLnlWYWx1ZUFjY2Vzc29yLCB5U2NhbGUpO1xuICAgIHNjYXR0ZXJQbG90LmF0dHIoJ2ZpbGwnLCAoZDogYW55KSA9PiB0aGlzLmNvbG9yU2NhbGUuc2NhbGUoZC5uYW1lKSk7XG4gICAgc2NhdHRlclBsb3QuYXR0cignb3BhY2l0eScsIDEpO1xuICAgIHNjYXR0ZXJQbG90LnNpemUodnpfY2hhcnRfaGVscGVycy5UT09MVElQX0NJUkNMRV9TSVpFICogMik7XG4gICAgc2NhdHRlclBsb3QuZGF0YXNldHMoW3RoaXMubGFzdFBvaW50c0RhdGFzZXRdKTtcbiAgICB0aGlzLnNjYXR0ZXJQbG90ID0gc2NhdHRlclBsb3Q7XG5cbiAgICBsZXQgbmFuRGlzcGxheSA9IG5ldyBQbG90dGFibGUuUGxvdHMuU2NhdHRlcjxudW1iZXJ8RGF0ZSwgbnVtYmVyPigpO1xuICAgIG5hbkRpc3BsYXkueCh0aGlzLnhBY2Nlc3NvciwgeFNjYWxlKTtcbiAgICBuYW5EaXNwbGF5LnkoKHgpID0+IHguZGlzcGxheVksIHlTY2FsZSk7XG4gICAgbmFuRGlzcGxheS5hdHRyKCdmaWxsJywgKGQ6IGFueSkgPT4gdGhpcy5jb2xvclNjYWxlLnNjYWxlKGQubmFtZSkpO1xuICAgIG5hbkRpc3BsYXkuYXR0cignb3BhY2l0eScsIDEpO1xuICAgIG5hbkRpc3BsYXkuc2l6ZSh2el9jaGFydF9oZWxwZXJzLk5BTl9TWU1CT0xfU0laRSAqIDIpO1xuICAgIG5hbkRpc3BsYXkuZGF0YXNldHMoW3RoaXMubmFuRGF0YXNldF0pO1xuICAgIG5hbkRpc3BsYXkuc3ltYm9sKFBsb3R0YWJsZS5TeW1ib2xGYWN0b3JpZXMudHJpYW5nbGUpO1xuICAgIHRoaXMubmFuRGlzcGxheSA9IG5hbkRpc3BsYXk7XG5cbiAgICBjb25zdCBncm91cHMgPSBbbmFuRGlzcGxheSwgc2NhdHRlclBsb3QsIHNtb290aExpbmVQbG90LCBsaW5lUGxvdF07XG4gICAgaWYgKHRoaXMubWFyZ2luQXJlYVBsb3QpIHtcbiAgICAgIGdyb3Vwcy5wdXNoKHRoaXMubWFyZ2luQXJlYVBsb3QpO1xuICAgIH1cbiAgICBpZiAodGhpcy5tYXJrZXJzU2NhdHRlclBsb3QpIHtcbiAgICAgIGdyb3Vwcy5wdXNoKHRoaXMubWFya2Vyc1NjYXR0ZXJQbG90KTtcbiAgICB9XG4gICAgcmV0dXJuIG5ldyBQbG90dGFibGUuQ29tcG9uZW50cy5Hcm91cChncm91cHMpO1xuICB9XG5cbiAgLyoqIFVwZGF0ZXMgdGhlIGNoYXJ0IHdoZW4gYSBkYXRhc2V0IGNoYW5nZXMuIENhbGxlZCBldmVyeSB0aW1lIHRoZSBkYXRhIG9mXG4gICAqIGEgZGF0YXNldCBjaGFuZ2VzIHRvIHVwZGF0ZSB0aGUgY2hhcnRzLlxuICAgKi9cbiAgcHJpdmF0ZSBfb25EYXRhc2V0Q2hhbmdlZChkYXRhc2V0OiBQbG90dGFibGUuRGF0YXNldCkge1xuICAgIGlmICh0aGlzLnNtb290aGluZ0VuYWJsZWQpIHtcbiAgICAgIHRoaXMucmVzbW9vdGhEYXRhc2V0KGRhdGFzZXQpO1xuICAgIH1cbiAgICB0aGlzLnVwZGF0ZVNwZWNpYWxEYXRhc2V0cygpO1xuICB9XG5cbiAgcHVibGljIGlnbm9yZVlPdXRsaWVycyhpZ25vcmVZT3V0bGllcnM6IGJvb2xlYW4pIHtcbiAgICBpZiAoaWdub3JlWU91dGxpZXJzICE9PSB0aGlzLl9pZ25vcmVZT3V0bGllcnMpIHtcbiAgICAgIHRoaXMuX2lnbm9yZVlPdXRsaWVycyA9IGlnbm9yZVlPdXRsaWVycztcbiAgICAgIHRoaXMudXBkYXRlU3BlY2lhbERhdGFzZXRzKCk7XG4gICAgICB0aGlzLnJlc2V0WURvbWFpbigpO1xuICAgIH1cbiAgfVxuXG4gIC8qKiBDb25zdHJ1Y3RzIHNwZWNpYWwgZGF0YXNldHMuIEVhY2ggc3BlY2lhbCBkYXRhc2V0IGNvbnRhaW5zIGV4Y2VwdGlvbmFsXG4gICAqIHZhbHVlcyBmcm9tIGFsbCBvZiB0aGUgcmVndWxhciBkYXRhc2V0cywgZS5nLiBsYXN0IHBvaW50cyBpbiBzZXJpZXMsIG9yXG4gICAqIE5hTiB2YWx1ZXMuIFRob3NlIHBvaW50cyB3aWxsIGhhdmUgYSBgbmFtZWAgYW5kIGByZWxhdGl2ZWAgcHJvcGVydHkgYWRkZWRcbiAgICogKHNpbmNlIHVzdWFsbHkgdGhvc2UgYXJlIGNvbnRleHQgaW4gdGhlIHN1cnJvdW5kaW5nIGRhdGFzZXQpLlxuICAgKi9cbiAgcHJpdmF0ZSB1cGRhdGVTcGVjaWFsRGF0YXNldHMoKSB7XG4gICAgY29uc3QgYWNjZXNzb3IgPSB0aGlzLmdldFlBeGlzQWNjZXNzb3IoKTtcblxuICAgIGxldCBsYXN0UG9pbnRzRGF0YSA9XG4gICAgICAgIHRoaXMuZGF0YXNldHNcbiAgICAgICAgICAgIC5tYXAoKGQpID0+IHtcbiAgICAgICAgICAgICAgbGV0IGRhdHVtID0gbnVsbDtcbiAgICAgICAgICAgICAgLy8gZmlsdGVyIG91dCBOYU5zIHRvIGVuc3VyZSBsYXN0IHBvaW50IGlzIGEgY2xlYW4gb25lXG4gICAgICAgICAgICAgIGxldCBub25OYW5EYXRhID1cbiAgICAgICAgICAgICAgICAgIGQuZGF0YSgpLmZpbHRlcigoeCkgPT4gIWlzTmFOKGFjY2Vzc29yKHgsIC0xLCBkKSkpO1xuICAgICAgICAgICAgICBpZiAobm9uTmFuRGF0YS5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICAgICAgbGV0IGlkeCA9IG5vbk5hbkRhdGEubGVuZ3RoIC0gMTtcbiAgICAgICAgICAgICAgICBkYXR1bSA9IG5vbk5hbkRhdGFbaWR4XTtcbiAgICAgICAgICAgICAgICBkYXR1bS5uYW1lID0gZC5tZXRhZGF0YSgpLm5hbWU7XG4gICAgICAgICAgICAgICAgZGF0dW0ucmVsYXRpdmUgPSB2el9jaGFydF9oZWxwZXJzLnJlbGF0aXZlQWNjZXNzb3IoZGF0dW0sIC0xLCBkKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICByZXR1cm4gZGF0dW07XG4gICAgICAgICAgICB9KVxuICAgICAgICAgICAgLmZpbHRlcigoeCkgPT4geCAhPSBudWxsKTtcbiAgICB0aGlzLmxhc3RQb2ludHNEYXRhc2V0LmRhdGEobGFzdFBvaW50c0RhdGEpO1xuXG4gICAgaWYgKHRoaXMubWFya2Vyc1NjYXR0ZXJQbG90KSB7XG4gICAgICB0aGlzLm1hcmtlcnNTY2F0dGVyUGxvdC5kYXRhc2V0cyhcbiAgICAgICAgICB0aGlzLmRhdGFzZXRzLm1hcCh0aGlzLmNyZWF0ZVNhbXBsZWREYXRhc2V0Rm9yTWFya2VycykpO1xuICAgIH1cblxuICAgIC8vIFRha2UgYSBkYXRhc2V0LCByZXR1cm4gYW4gYXJyYXkgb2YgTmFOIGRhdGEgcG9pbnRzXG4gICAgLy8gdGhlIE5hTiBwb2ludHMgd2lsbCBoYXZlIGEgXCJkaXNwbGF5WVwiIHByb3BlcnR5IHdoaWNoIGlzIHRoZVxuICAgIC8vIHktdmFsdWUgb2YgYSBuZWFyYnkgcG9pbnQgdGhhdCB3YXMgbm90IE5hTiAoMCBpZiBhbGwgcG9pbnRzIGFyZSBOYU4pXG4gICAgbGV0IGRhdGFzZXRUb05hTkRhdGEgPSAoZDogUGxvdHRhYmxlLkRhdGFzZXQpID0+IHtcbiAgICAgIGxldCBkaXNwbGF5WSA9IG51bGw7XG4gICAgICBsZXQgZGF0YSA9IGQuZGF0YSgpO1xuICAgICAgbGV0IGkgPSAwO1xuICAgICAgd2hpbGUgKGkgPCBkYXRhLmxlbmd0aCAmJiBkaXNwbGF5WSA9PSBudWxsKSB7XG4gICAgICAgIGlmICghaXNOYU4oYWNjZXNzb3IoZGF0YVtpXSwgLTEsIGQpKSkge1xuICAgICAgICAgIGRpc3BsYXlZID0gYWNjZXNzb3IoZGF0YVtpXSwgLTEsIGQpO1xuICAgICAgICB9XG4gICAgICAgIGkrKztcbiAgICAgIH1cbiAgICAgIGlmIChkaXNwbGF5WSA9PSBudWxsKSB7XG4gICAgICAgIGRpc3BsYXlZID0gMDtcbiAgICAgIH1cbiAgICAgIGxldCBuYW5EYXRhID0gW107XG4gICAgICBmb3IgKGkgPSAwOyBpIDwgZGF0YS5sZW5ndGg7IGkrKykge1xuICAgICAgICBpZiAoIWlzTmFOKGFjY2Vzc29yKGRhdGFbaV0sIC0xLCBkKSkpIHtcbiAgICAgICAgICBkaXNwbGF5WSA9IGFjY2Vzc29yKGRhdGFbaV0sIC0xLCBkKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBkYXRhW2ldLm5hbWUgPSBkLm1ldGFkYXRhKCkubmFtZTtcbiAgICAgICAgICBkYXRhW2ldLmRpc3BsYXlZID0gZGlzcGxheVk7XG4gICAgICAgICAgZGF0YVtpXS5yZWxhdGl2ZSA9IHZ6X2NoYXJ0X2hlbHBlcnMucmVsYXRpdmVBY2Nlc3NvcihkYXRhW2ldLCAtMSwgZCk7XG4gICAgICAgICAgbmFuRGF0YS5wdXNoKGRhdGFbaV0pO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXR1cm4gbmFuRGF0YTtcbiAgICB9O1xuICAgIGxldCBuYW5EYXRhID0gXy5mbGF0dGVuKHRoaXMuZGF0YXNldHMubWFwKGRhdGFzZXRUb05hTkRhdGEpKTtcbiAgICB0aGlzLm5hbkRhdGFzZXQuZGF0YShuYW5EYXRhKTtcbiAgfVxuXG4gIHB1YmxpYyByZXNldERvbWFpbigpIHtcbiAgICB0aGlzLnJlc2V0WERvbWFpbigpO1xuICAgIHRoaXMucmVzZXRZRG9tYWluKCk7XG4gIH1cblxuICBwcml2YXRlIHJlc2V0WERvbWFpbigpIHtcbiAgICBsZXQgeERvbWFpbjtcbiAgICBpZiAodGhpcy5fZGVmYXVsdFhSYW5nZSAhPSBudWxsKSB7XG4gICAgICAvLyBVc2UgdGhlIHJhbmdlIHNwZWNpZmllZCBieSB0aGUgY2FsbGVyLlxuICAgICAgeERvbWFpbiA9IHRoaXMuX2RlZmF1bHRYUmFuZ2U7XG4gICAgfSBlbHNlIHtcbiAgICAgIC8vIChDb3BpZWQgZnJvbSB2el9saW5lX2NoYXJ0LkRyYWdab29tTGF5ZXIudW56b29tLilcbiAgICAgIGNvbnN0IHhTY2FsZSA9IHRoaXMueFNjYWxlIGFzIGFueTtcbiAgICAgIHhTY2FsZS5fZG9tYWluTWluID0gbnVsbDtcbiAgICAgIHhTY2FsZS5fZG9tYWluTWF4ID0gbnVsbDtcbiAgICAgIHhEb21haW4gPSB4U2NhbGUuX2dldEV4dGVudCgpO1xuICAgIH1cbiAgICB0aGlzLnhTY2FsZS5kb21haW4oeERvbWFpbik7XG4gIH1cblxuICBwcml2YXRlIHJlc2V0WURvbWFpbigpIHtcbiAgICBsZXQgeURvbWFpbjtcbiAgICBpZiAodGhpcy5fZGVmYXVsdFlSYW5nZSAhPSBudWxsKSB7XG4gICAgICAvLyBVc2UgdGhlIHJhbmdlIHNwZWNpZmllZCBieSB0aGUgY2FsbGVyLlxuICAgICAgeURvbWFpbiA9IHRoaXMuX2RlZmF1bHRZUmFuZ2U7XG4gICAgfSBlbHNlIHtcbiAgICAgIC8vIEdlbmVyYXRlIGEgcmVhc29uYWJsZSByYW5nZS5cbiAgICAgIGNvbnN0IGFjY2Vzc29ycyA9IHRoaXMuZ2V0QWNjZXNzb3JzRm9yQ29tcHV0aW5nWVJhbmdlKCk7XG4gICAgICBsZXQgZGF0YXNldFRvVmFsdWVzOiAoZDogUGxvdHRhYmxlLkRhdGFzZXQpID0+IG51bWJlcltdW10gPSAoZCkgPT4ge1xuICAgICAgICByZXR1cm4gYWNjZXNzb3JzLm1hcChhY2Nlc3NvciA9PiBkLmRhdGEoKS5tYXAoeCA9PiBhY2Nlc3Nvcih4LCAtMSwgZCkpKTtcbiAgICAgIH07XG4gICAgICBjb25zdCB2YWxzID0gXy5mbGF0dGVuRGVlcDxudW1iZXI+KHRoaXMuZGF0YXNldHMubWFwKGRhdGFzZXRUb1ZhbHVlcykpXG4gICAgICAgICAgLmZpbHRlcihpc0Zpbml0ZSk7XG4gICAgICB5RG9tYWluID0gdnpfY2hhcnRfaGVscGVycy5jb21wdXRlRG9tYWluKHZhbHMsIHRoaXMuX2lnbm9yZVlPdXRsaWVycyk7XG4gICAgfVxuICAgIHRoaXMueVNjYWxlLmRvbWFpbih5RG9tYWluKTtcbiAgfVxuXG4gIHByaXZhdGUgZ2V0QWNjZXNzb3JzRm9yQ29tcHV0aW5nWVJhbmdlKCk6IFBsb3R0YWJsZS5JQWNjZXNzb3I8bnVtYmVyPltdIHtcbiAgICBjb25zdCBhY2Nlc3NvcnMgPSBbdGhpcy5nZXRZQXhpc0FjY2Vzc29yKCldO1xuICAgIGlmICh0aGlzLmZpbGxBcmVhKSB7XG4gICAgICAvLyBNYWtlIHRoZSBZIGRvbWFpbiB0YWtlIG1hcmdpbnMgaW50byBhY2NvdW50LlxuICAgICAgYWNjZXNzb3JzLnB1c2goXG4gICAgICAgICAgdGhpcy5maWxsQXJlYS5sb3dlckFjY2Vzc29yLFxuICAgICAgICAgIHRoaXMuZmlsbEFyZWEuaGlnaGVyQWNjZXNzb3IpO1xuICAgIH1cbiAgICByZXR1cm4gYWNjZXNzb3JzO1xuICB9XG5cbiAgcHJpdmF0ZSBnZXRZQXhpc0FjY2Vzc29yKCkge1xuICAgIHJldHVybiB0aGlzLnNtb290aGluZ0VuYWJsZWQgPyB0aGlzLnNtb290aGVkQWNjZXNzb3IgOiB0aGlzLnlWYWx1ZUFjY2Vzc29yO1xuICB9XG5cbiAgcHJpdmF0ZSBjcmVhdGVUb29sdGlwSW50ZXJhY3Rpb24ocHpkbDogUGFuWm9vbURyYWdMYXllcik6XG4gICAgICBQbG90dGFibGUuSW50ZXJhY3Rpb25zLlBvaW50ZXIge1xuICAgIGNvbnN0IHBpID0gbmV3IFBsb3R0YWJsZS5JbnRlcmFjdGlvbnMuUG9pbnRlcigpO1xuICAgIC8vIERpc2FibGUgaW50ZXJhY3Rpb24gd2hpbGUgZHJhZyB6b29taW5nLlxuICAgIGNvbnN0IGRpc2FibGVUb29sdGlwVXBkYXRlID0gKCkgPT4ge1xuICAgICAgcGkuZW5hYmxlZChmYWxzZSk7XG4gICAgICB0aGlzLmhpZGVUb29sdGlwcygpO1xuICAgIH07XG4gICAgY29uc3QgZW5hYmxlVG9vbHRpcFVwZGF0ZSA9ICgpID0+IHBpLmVuYWJsZWQodHJ1ZSk7XG4gICAgcHpkbC5vblBhblN0YXJ0KGRpc2FibGVUb29sdGlwVXBkYXRlKTtcbiAgICBwemRsLm9uRHJhZ1pvb21TdGFydChkaXNhYmxlVG9vbHRpcFVwZGF0ZSk7XG4gICAgcHpkbC5vblBhbkVuZChlbmFibGVUb29sdGlwVXBkYXRlKTtcbiAgICBwemRsLm9uRHJhZ1pvb21FbmQoZW5hYmxlVG9vbHRpcFVwZGF0ZSk7XG4gICAgLy8gV2hlbiB1c2luZyB3aGVlbCwgY3Vyc29yIHBvc2l0aW9uIGRvZXMgbm90IGNoYW5nZS4gUmVkcmF3IHRoZSB0b29sdGlwXG4gICAgLy8gdXNpbmcgdGhlIGxhc3Qga25vd24gbW91c2UgcG9zaXRpb24uXG4gICAgcHpkbC5vblNjcm9sbFpvb20oKCkgPT4gdGhpcy51cGRhdGVUb29sdGlwQ29udGVudCh0aGlzLl9sYXN0TW91c2VQb3NpdGlvbikpO1xuICAgIHBpLm9uUG9pbnRlck1vdmUoKHA6IFBsb3R0YWJsZS5Qb2ludCkgPT4ge1xuICAgICAgdGhpcy5fbGFzdE1vdXNlUG9zaXRpb24gPSBwO1xuICAgICAgdGhpcy51cGRhdGVUb29sdGlwQ29udGVudChwKTtcbiAgICB9KTtcbiAgICBwaS5vblBvaW50ZXJFeGl0KCgpID0+IHRoaXMuaGlkZVRvb2x0aXBzKCkpO1xuICAgIHJldHVybiBwaTtcbiAgfVxuXG4gIHByaXZhdGUgdXBkYXRlVG9vbHRpcENvbnRlbnQocDogUGxvdHRhYmxlLlBvaW50KTogdm9pZCB7XG4gICAgLy8gTGluZSBwbG90IG11c3QgYmUgaW5pdGlhbGl6ZWQgdG8gZHJhdy5cbiAgICBpZiAoIXRoaXMubGluZVBsb3QpIHJldHVybjtcbiAgICB3aW5kb3cuY2FuY2VsQW5pbWF0aW9uRnJhbWUodGhpcy5fdG9vbHRpcFVwZGF0ZUFuaW1hdGlvbkZyYW1lKTtcbiAgICB0aGlzLl90b29sdGlwVXBkYXRlQW5pbWF0aW9uRnJhbWUgPSB3aW5kb3cucmVxdWVzdEFuaW1hdGlvbkZyYW1lKCgpID0+IHtcbiAgICAgIGxldCB0YXJnZXQ6IHZ6X2NoYXJ0X2hlbHBlcnMuUG9pbnQgPSB7XG4gICAgICAgIHg6IHAueCxcbiAgICAgICAgeTogcC55LFxuICAgICAgICBkYXR1bTogbnVsbCxcbiAgICAgICAgZGF0YXNldDogbnVsbCxcbiAgICAgIH07XG4gICAgICBsZXQgYmJveDogU1ZHUmVjdCA9ICg8YW55PnRoaXMuZ3JpZGxpbmVzLmNvbnRlbnQoKS5ub2RlKCkpLmdldEJCb3goKTtcbiAgICAgIC8vIHB0cyBpcyB0aGUgY2xvc2V0cyBwb2ludCB0byB0aGUgdG9vbHRpcCBmb3IgZWFjaCBkYXRhc2V0XG4gICAgICBsZXQgcHRzID0gdGhpcy5saW5lUGxvdC5kYXRhc2V0cygpXG4gICAgICAgICAgLm1hcCgoZGF0YXNldCkgPT4gdGhpcy5maW5kQ2xvc2VzdFBvaW50KHRhcmdldCwgZGF0YXNldCkpXG4gICAgICAgICAgLmZpbHRlcihCb29sZWFuKTtcbiAgICAgIGxldCBpbnRlcnNlY3RzQkJveCA9IFBsb3R0YWJsZS5VdGlscy5ET00uaW50ZXJzZWN0c0JCb3g7XG4gICAgICAvLyBXZSBkcmF3IHRvb2x0aXBzIGZvciBwb2ludHMgdGhhdCBhcmUgTmFOLCBvciBhcmUgY3VycmVudGx5IHZpc2libGVcbiAgICAgIGxldCBwdHNGb3JUb29sdGlwcyA9IHB0cy5maWx0ZXIoXG4gICAgICAgICAgKHApID0+IGludGVyc2VjdHNCQm94KHAueCwgcC55LCBiYm94KSB8fFxuICAgICAgICAgICAgICBpc05hTih0aGlzLnlWYWx1ZUFjY2Vzc29yKHAuZGF0dW0sIDAsIHAuZGF0YXNldCkpKTtcbiAgICAgIC8vIE9ubHkgZHJhdyBsaXR0bGUgaW5kaWNhdG9yIGNpcmNsZXMgZm9yIHRoZSBub24tTmFOIHBvaW50c1xuICAgICAgbGV0IHB0c1RvQ2lyY2xlID0gcHRzRm9yVG9vbHRpcHMuZmlsdGVyKFxuICAgICAgICAgIChwKSA9PiAhaXNOYU4odGhpcy55VmFsdWVBY2Nlc3NvcihwLmRhdHVtLCAwLCBwLmRhdGFzZXQpKSk7XG4gICAgICBpZiAocHRzLmxlbmd0aCAhPT0gMCkge1xuICAgICAgICB0aGlzLnNjYXR0ZXJQbG90LmF0dHIoJ2Rpc3BsYXknLCAnbm9uZScpO1xuICAgICAgICBjb25zdCBwdHNTZWxlY3Rpb246IGFueSA9XG4gICAgICAgICAgICB0aGlzLnRvb2x0aXBQb2ludHNDb21wb25lbnQuY29udGVudCgpLnNlbGVjdEFsbCgnLnBvaW50JykuZGF0YShcbiAgICAgICAgICAgICAgICBwdHNUb0NpcmNsZSxcbiAgICAgICAgICAgICAgICAocDogdnpfY2hhcnRfaGVscGVycy5Qb2ludCkgPT4gcC5kYXRhc2V0Lm1ldGFkYXRhKCkubmFtZSk7XG4gICAgICAgIHB0c1NlbGVjdGlvbi5lbnRlcigpLmFwcGVuZCgnY2lyY2xlJykuY2xhc3NlZCgncG9pbnQnLCB0cnVlKTtcbiAgICAgICAgcHRzU2VsZWN0aW9uLmF0dHIoJ3InLCB2el9jaGFydF9oZWxwZXJzLlRPT0xUSVBfQ0lSQ0xFX1NJWkUpXG4gICAgICAgICAgICAuYXR0cignY3gnLCAocCkgPT4gcC54KVxuICAgICAgICAgICAgLmF0dHIoJ2N5JywgKHApID0+IHAueSlcbiAgICAgICAgICAgIC5zdHlsZSgnc3Ryb2tlJywgJ25vbmUnKVxuICAgICAgICAgICAgLmF0dHIoXG4gICAgICAgICAgICAgICAgJ2ZpbGwnLFxuICAgICAgICAgICAgICAgIChwKSA9PiB0aGlzLmNvbG9yU2NhbGUuc2NhbGUocC5kYXRhc2V0Lm1ldGFkYXRhKCkubmFtZSkpO1xuICAgICAgICBwdHNTZWxlY3Rpb24uZXhpdCgpLnJlbW92ZSgpO1xuICAgICAgICB0aGlzLmRyYXdUb29sdGlwcyhwdHNGb3JUb29sdGlwcywgdGFyZ2V0LCB0aGlzLnRvb2x0aXBDb2x1bW5zKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRoaXMuaGlkZVRvb2x0aXBzKCk7XG4gICAgICB9XG4gICAgfSk7XG4gIH1cblxuICBwcml2YXRlIGhpZGVUb29sdGlwcygpOiB2b2lkIHtcbiAgICB3aW5kb3cuY2FuY2VsQW5pbWF0aW9uRnJhbWUodGhpcy5fdG9vbHRpcFVwZGF0ZUFuaW1hdGlvbkZyYW1lKTtcbiAgICB0aGlzLnRvb2x0aXAuaGlkZSgpO1xuICAgIHRoaXMuc2NhdHRlclBsb3QuYXR0cignZGlzcGxheScsICdibG9jaycpO1xuICAgIHRoaXMudG9vbHRpcFBvaW50c0NvbXBvbmVudC5jb250ZW50KCkuc2VsZWN0QWxsKCcucG9pbnQnKS5yZW1vdmUoKTtcbiAgfVxuXG4gIHByaXZhdGUgc2V0dXBUb29sdGlwcyhwbG90OiBQbG90dGFibGUuWFlQbG90PG51bWJlcnxEYXRlLCBudW1iZXI+KTogdm9pZCB7XG4gICAgcGxvdC5vbkRldGFjaCgoKSA9PiB7XG4gICAgICB0aGlzLnRvb2x0aXBJbnRlcmFjdGlvbi5kZXRhY2hGcm9tKHBsb3QpO1xuICAgICAgdGhpcy50b29sdGlwSW50ZXJhY3Rpb24uZW5hYmxlZChmYWxzZSk7XG4gICAgfSk7XG4gICAgcGxvdC5vbkFuY2hvcigoKSA9PiB7XG4gICAgICB0aGlzLnRvb2x0aXBJbnRlcmFjdGlvbi5hdHRhY2hUbyhwbG90KTtcbiAgICAgIHRoaXMudG9vbHRpcEludGVyYWN0aW9uLmVuYWJsZWQodHJ1ZSk7XG4gICAgfSk7XG4gIH1cblxuICBwcml2YXRlIGRyYXdUb29sdGlwcyhcbiAgICAgIHBvaW50czogdnpfY2hhcnRfaGVscGVycy5Qb2ludFtdLFxuICAgICAgdGFyZ2V0OiB2el9jaGFydF9oZWxwZXJzLlBvaW50LFxuICAgICAgdG9vbHRpcENvbHVtbnM6IHZ6X2NoYXJ0X2hlbHBlcnMuVG9vbHRpcENvbHVtbltdKSB7XG4gICAgaWYgKCFwb2ludHMubGVuZ3RoKSB7XG4gICAgICB0aGlzLnRvb2x0aXAuaGlkZSgpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGNvbnN0IHtjb2xvclNjYWxlfSA9IHRoaXM7XG4gICAgY29uc3Qgc3dhdGNoQ29sID0ge1xuICAgICAgdGl0bGU6ICcnLFxuICAgICAgc3RhdGljOiBmYWxzZSxcbiAgICAgIGV2YWxUeXBlOiBUb29sdGlwQ29sdW1uRXZhbFR5cGUuRE9NLFxuICAgICAgZXZhbHVhdGUoZDogdnpfY2hhcnRfaGVscGVycy5Qb2ludCkge1xuICAgICAgICBkMy5zZWxlY3QodGhpcylcbiAgICAgICAgICAgIC5zZWxlY3QoJ3NwYW4nKVxuICAgICAgICAgICAgLnN0eWxlKFxuICAgICAgICAgICAgICAgICdiYWNrZ3JvdW5kLWNvbG9yJyxcbiAgICAgICAgICAgICAgICAoKSA9PiBjb2xvclNjYWxlLnNjYWxlKGQuZGF0YXNldC5tZXRhZGF0YSgpLm5hbWUpKTtcbiAgICAgICAgcmV0dXJuICcnO1xuICAgICAgfSxcbiAgICAgIGVudGVyKGQ6IHZ6X2NoYXJ0X2hlbHBlcnMuUG9pbnQpIHtcbiAgICAgICAgZDMuc2VsZWN0KHRoaXMpXG4gICAgICAgICAgICAuYXBwZW5kKCdzcGFuJylcbiAgICAgICAgICAgIC5jbGFzc2VkKCdzd2F0Y2gnLCB0cnVlKVxuICAgICAgICAgICAgLnN0eWxlKFxuICAgICAgICAgICAgICAgICdiYWNrZ3JvdW5kLWNvbG9yJyxcbiAgICAgICAgICAgICAgICAoKSA9PiBjb2xvclNjYWxlLnNjYWxlKGQuZGF0YXNldC5tZXRhZGF0YSgpLm5hbWUpKTtcbiAgICAgIH0sXG4gICAgfTtcbiAgICB0b29sdGlwQ29sdW1ucyA9IFtzd2F0Y2hDb2wsIC4uLnRvb2x0aXBDb2x1bW5zXTtcblxuICAgIC8vIEZvcm1hdHRlcnMgZm9yIHZhbHVlLCBzdGVwLCBhbmQgd2FsbF90aW1lXG4gICAgbGV0IHZhbHVlRm9ybWF0dGVyID0gdnpfY2hhcnRfaGVscGVycy5tdWx0aXNjYWxlRm9ybWF0dGVyKFxuICAgICAgICB2el9jaGFydF9oZWxwZXJzLllfVE9PTFRJUF9GT1JNQVRURVJfUFJFQ0lTSU9OKTtcblxuICAgIGNvbnN0IGRpc3QgPSAocDogdnpfY2hhcnRfaGVscGVycy5Qb2ludCkgPT5cbiAgICAgICAgTWF0aC5wb3cocC54IC0gdGFyZ2V0LngsIDIpICsgTWF0aC5wb3cocC55IC0gdGFyZ2V0LnksIDIpO1xuICAgIGNvbnN0IGNsb3Nlc3REaXN0ID0gXy5taW4ocG9pbnRzLm1hcChkaXN0KSk7XG5cbiAgICBjb25zdCB2YWx1ZVNvcnRNZXRob2QgPSB0aGlzLnNtb290aGluZ0VuYWJsZWQgP1xuICAgICAgICB0aGlzLnNtb290aGVkQWNjZXNzb3IgOiB0aGlzLnlWYWx1ZUFjY2Vzc29yO1xuXG4gICAgaWYgKHRoaXMudG9vbHRpcFNvcnRpbmdNZXRob2QgPT09ICdhc2NlbmRpbmcnKSB7XG4gICAgICBwb2ludHMgPSBfLnNvcnRCeShwb2ludHMsIChkKSA9PiB2YWx1ZVNvcnRNZXRob2QoZC5kYXR1bSwgLTEsIGQuZGF0YXNldCkpO1xuICAgIH0gZWxzZSBpZiAodGhpcy50b29sdGlwU29ydGluZ01ldGhvZCA9PT0gJ2Rlc2NlbmRpbmcnKSB7XG4gICAgICBwb2ludHMgPSBfLnNvcnRCeShwb2ludHMsIChkKSA9PiB2YWx1ZVNvcnRNZXRob2QoZC5kYXR1bSwgLTEsIGQuZGF0YXNldCkpXG4gICAgICAgICAgICAgICAgICAgLnJldmVyc2UoKTtcbiAgICB9IGVsc2UgaWYgKHRoaXMudG9vbHRpcFNvcnRpbmdNZXRob2QgPT09ICduZWFyZXN0Jykge1xuICAgICAgcG9pbnRzID0gXy5zb3J0QnkocG9pbnRzLCBkaXN0KTtcbiAgICB9IGVsc2Uge1xuICAgICAgLy8gVGhlICdkZWZhdWx0JyBzb3J0aW5nIG1ldGhvZCBtYWludGFpbnMgdGhlIG9yZGVyIG9mIG5hbWVzIHBhc3NlZCB0b1xuICAgICAgLy8gc2V0VmlzaWJsZVNlcmllcygpLiBIb3dldmVyIHdlIHJldmVyc2UgdGhhdCBvcmRlciB3aGVuIGRlZmluaW5nIHRoZVxuICAgICAgLy8gZGF0YXNldHMuIFNvIHdlIG11c3QgY2FsbCByZXZlcnNlIGFnYWluIHRvIHJlc3RvcmUgdGhlIG9yZGVyLlxuICAgICAgcG9pbnRzID0gcG9pbnRzLnNsaWNlKDApLnJldmVyc2UoKTtcbiAgICB9XG5cbiAgICBjb25zdCBzZWxmID0gdGhpcztcbiAgICBjb25zdCB0YWJsZSA9IGQzLnNlbGVjdCh0aGlzLnRvb2x0aXAuY29udGVudCgpKS5zZWxlY3QoJ3RhYmxlJyk7XG4gICAgY29uc3QgaGVhZGVyID0gdGFibGUuc2VsZWN0KCd0aGVhZCcpXG4gICAgICAgIC5zZWxlY3RBbGwoJ3RoJylcbiAgICAgICAgLmRhdGEoXG4gICAgICAgICAgICB0b29sdGlwQ29sdW1ucyxcbiAgICAgICAgICAgIChjb2x1bW46IHZ6X2NoYXJ0X2hlbHBlcnMuVG9vbHRpcENvbHVtbiwgXywgX18pID0+IHtcbiAgICAgICAgICAgICAgcmV0dXJuIGNvbHVtbi50aXRsZVxuICAgICAgICAgICAgfSk7XG4gICAgY29uc3QgbmV3SGVhZGVyTm9kZXMgPSBoZWFkZXIuZW50ZXIoKVxuICAgICAgICAuYXBwZW5kKCd0aCcpXG4gICAgICAgIC50ZXh0KGNvbCA9PiBjb2wudGl0bGUpXG4gICAgICAgIC5ub2RlcygpO1xuICAgIGhlYWRlci5leGl0KCkucmVtb3ZlKCk7XG5cbiAgICBjb25zdCByb3dzID0gdGFibGUuc2VsZWN0KCd0Ym9keScpXG4gICAgICAgIC5zZWxlY3RBbGwoJ3RyJylcbiAgICAgICAgLmRhdGEocG9pbnRzLCAocHQ6IHZ6X2NoYXJ0X2hlbHBlcnMuUG9pbnQsIF8sIF9fKSA9PiB7XG4gICAgICAgICAgcmV0dXJuIHB0LmRhdGFzZXQubWV0YWRhdGEoKS5uYW1lO1xuICAgICAgICB9KTtcbiAgICByb3dzLmNsYXNzZWQoJ2Rpc3RhbnQnLCAoZCkgPT4ge1xuICAgICAgICAgIC8vIEdyZXkgb3V0IHRoZSBwb2ludCBpZiBhbnkgb2YgdGhlIGZvbGxvd2luZyBhcmUgdHJ1ZTpcbiAgICAgICAgICAvLyAtIFRoZSBjdXJzb3IgaXMgb3V0c2lkZSBvZiB0aGUgeC1leHRlbnQgb2YgdGhlIGRhdGFzZXRcbiAgICAgICAgICAvLyAtIFRoZSBwb2ludCdzIHkgdmFsdWUgaXMgTmFOXG4gICAgICAgICAgbGV0IGZpcnN0UG9pbnQgPSBkLmRhdGFzZXQuZGF0YSgpWzBdO1xuICAgICAgICAgIGxldCBsYXN0UG9pbnQgPSBfLmxhc3QoZC5kYXRhc2V0LmRhdGEoKSk7XG4gICAgICAgICAgbGV0IGZpcnN0WCA9IHRoaXMueFNjYWxlLnNjYWxlKHRoaXMueEFjY2Vzc29yKGZpcnN0UG9pbnQsIDAsIGQuZGF0YXNldCkpO1xuICAgICAgICAgIGxldCBsYXN0WCA9IHRoaXMueFNjYWxlLnNjYWxlKHRoaXMueEFjY2Vzc29yKGxhc3RQb2ludCwgMCwgZC5kYXRhc2V0KSk7XG4gICAgICAgICAgbGV0IHMgPSB0aGlzLnNtb290aGluZ0VuYWJsZWQgP1xuICAgICAgICAgICAgICBkLmRhdHVtLnNtb290aGVkIDogdGhpcy55VmFsdWVBY2Nlc3NvcihkLmRhdHVtLCAwLCBkLmRhdGFzZXQpO1xuICAgICAgICAgIHJldHVybiB0YXJnZXQueCA8IGZpcnN0WCB8fCB0YXJnZXQueCA+IGxhc3RYIHx8IGlzTmFOKHMpO1xuICAgICAgICB9KVxuICAgICAgICAuY2xhc3NlZCgnY2xvc2VzdCcsIChwKSA9PiBkaXN0KHApID09PSBjbG9zZXN0RGlzdClcbiAgICAgICAgLmVhY2goZnVuY3Rpb24ocG9pbnQpIHtcbiAgICAgICAgICBzZWxmLmRyYXdUb29sdGlwUm93KHRoaXMsIHRvb2x0aXBDb2x1bW5zLCBwb2ludCk7XG4gICAgICAgIH0pXG4gICAgICAgIC8vIHJlb3JkZXJzIERPTSB0byBtYXRjaCB0aGUgb3JkZXJpbmcgb2YgdGhlIGBkYXRhYC5cbiAgICAgICAgLm9yZGVyKCk7XG5cbiAgICByb3dzLmV4aXQoKS5yZW1vdmUoKTtcbiAgICBjb25zdCBuZXdSb3dOb2RlcyA9IHJvd3MuZW50ZXIoKVxuICAgICAgICAuYXBwZW5kKCd0cicpXG4gICAgICAgIC5lYWNoKGZ1bmN0aW9uKHBvaW50KSB7XG4gICAgICAgICAgc2VsZi5kcmF3VG9vbHRpcFJvdyh0aGlzLCB0b29sdGlwQ29sdW1ucywgcG9pbnQpO1xuICAgICAgICB9KVxuICAgICAgICAubm9kZXMoKTtcbiAgICBjb25zdCBuZXdOb2RlcyA9IFsuLi5uZXdIZWFkZXJOb2RlcywgLi4ubmV3Um93Tm9kZXNdIGFzIEVsZW1lbnRbXTtcbiAgICB0aGlzLnRvb2x0aXAudXBkYXRlQW5kUG9zaXRpb24odGhpcy50YXJnZXRTVkcubm9kZSgpLCBuZXdOb2Rlcyk7XG4gIH1cblxuICBwcml2YXRlIGRyYXdUb29sdGlwUm93KFxuICAgICAgcm93OiBkMy5CYXNlVHlwZSxcbiAgICAgIHRvb2x0aXBDb2x1bW5zOiB2el9jaGFydF9oZWxwZXJzLlRvb2x0aXBDb2x1bW5bXSxcbiAgICAgIHBvaW50OiB2el9jaGFydF9oZWxwZXJzLlBvaW50KSB7XG4gICAgY29uc3Qgc2VsZiA9IHRoaXM7XG4gICAgY29uc3QgY29sdW1ucyA9IGQzLnNlbGVjdChyb3cpLnNlbGVjdEFsbCgndGQnKS5kYXRhKHRvb2x0aXBDb2x1bW5zKTtcblxuICAgIGNvbHVtbnMuZWFjaChmdW5jdGlvbihjb2w6IFRvb2x0aXBDb2x1bW4pIHtcbiAgICAgIC8vIFNraXAgY29sdW1uIHZhbHVlIHVwZGF0ZSB3aGVuIHRoZSBjb2x1bW4gaXMgc3RhdGljLlxuICAgICAgaWYgKGNvbC5zdGF0aWMpIHJldHVybjtcbiAgICAgIHNlbGYuZHJhd1Rvb2x0aXBDb2x1bW4uY2FsbChzZWxmLCB0aGlzLCBjb2wsIHBvaW50KTtcbiAgICB9KTtcbiAgICBjb2x1bW5zLmVudGVyKClcbiAgICAgICAgLmFwcGVuZCgndGQnKVxuICAgICAgICAuZWFjaChmdW5jdGlvbihjb2w6IFRvb2x0aXBDb2x1bW4pIHtcbiAgICAgICAgICBpZiAoY29sLmVudGVyKSBjb2wuZW50ZXIuY2FsbCh0aGlzLCBwb2ludCk7XG4gICAgICAgICAgc2VsZi5kcmF3VG9vbHRpcENvbHVtbi5jYWxsKHNlbGYsIHRoaXMsIGNvbCwgcG9pbnQpO1xuICAgICAgICB9KTtcbiAgfVxuXG4gIHByaXZhdGUgZHJhd1Rvb2x0aXBDb2x1bW4oXG4gICAgICBjb2x1bW46IGQzLkJhc2VUeXBlLFxuICAgICAgdG9vbHRpcENvbDogVG9vbHRpcENvbHVtbixcbiAgICAgIHBvaW50OiB2el9jaGFydF9oZWxwZXJzLlBvaW50KSB7XG4gICAgY29uc3Qge3Ntb290aGluZ0VuYWJsZWR9ID0gdGhpcztcbiAgICBpZiAodG9vbHRpcENvbC5ldmFsVHlwZSA9PSBUb29sdGlwQ29sdW1uRXZhbFR5cGUuRE9NKSB7XG4gICAgICB0b29sdGlwQ29sLmV2YWx1YXRlLmNhbGwoY29sdW1uLCBwb2ludCwge3Ntb290aGluZ0VuYWJsZWR9KTtcbiAgICB9IGVsc2Uge1xuICAgICAgZDMuc2VsZWN0KGNvbHVtbilcbiAgICAgICAgICAudGV4dCh0b29sdGlwQ29sLmV2YWx1YXRlLmNhbGwoY29sdW1uLCBwb2ludCwge3Ntb290aGluZ0VuYWJsZWR9KSk7XG4gICAgfVxuICB9XG5cbiAgcHJpdmF0ZSBmaW5kQ2xvc2VzdFBvaW50KFxuICAgICAgdGFyZ2V0OiB2el9jaGFydF9oZWxwZXJzLlBvaW50LFxuICAgICAgZGF0YXNldDogUGxvdHRhYmxlLkRhdGFzZXQpOiB2el9jaGFydF9oZWxwZXJzLlBvaW50IHwgbnVsbCB7XG4gICAgY29uc3QgeFBvaW50czogbnVtYmVyW10gPSBkYXRhc2V0LmRhdGEoKVxuICAgICAgICAubWFwKChkLCBpKSA9PiB0aGlzLnhTY2FsZS5zY2FsZSh0aGlzLnhBY2Nlc3NvcihkLCBpLCBkYXRhc2V0KSkpO1xuXG4gICAgbGV0IGlkeDogbnVtYmVyID0gXy5zb3J0ZWRJbmRleCh4UG9pbnRzLCB0YXJnZXQueCk7XG5cbiAgICBpZiAoeFBvaW50cy5sZW5ndGggPT0gMCkgcmV0dXJuIG51bGw7XG4gICAgaWYgKGlkeCA9PT0geFBvaW50cy5sZW5ndGgpIHtcbiAgICAgIGlkeCA9IGlkeCAtIDE7XG4gICAgfSBlbHNlIGlmIChpZHggIT09IDApIHtcbiAgICAgIGNvbnN0IHByZXZEaXN0ID0gTWF0aC5hYnMoeFBvaW50c1tpZHggLSAxXSAtIHRhcmdldC54KTtcbiAgICAgIGNvbnN0IG5leHREaXN0ID0gTWF0aC5hYnMoeFBvaW50c1tpZHhdIC0gdGFyZ2V0LngpO1xuICAgICAgaWR4ICA9IHByZXZEaXN0IDwgbmV4dERpc3QgPyBpZHggLSAxIDogaWR4O1xuICAgIH1cblxuICAgIGNvbnN0IGRhdHVtID0gZGF0YXNldC5kYXRhKClbaWR4XTtcbiAgICBjb25zdCB5ID0gdGhpcy5zbW9vdGhpbmdFbmFibGVkID9cbiAgICAgICAgdGhpcy5zbW9vdGhlZEFjY2Vzc29yKGRhdHVtLCBpZHgsIGRhdGFzZXQpIDpcbiAgICAgICAgdGhpcy55VmFsdWVBY2Nlc3NvcihkYXR1bSwgaWR4LCBkYXRhc2V0KTtcbiAgICByZXR1cm4ge1xuICAgICAgeDogeFBvaW50c1tpZHhdLFxuICAgICAgeTogdGhpcy55U2NhbGUuc2NhbGUoeSksXG4gICAgICBkYXR1bSxcbiAgICAgIGRhdGFzZXQsXG4gICAgfTtcbiAgfVxuXG4gIHByaXZhdGUgcmVzbW9vdGhEYXRhc2V0KGRhdGFzZXQ6IFBsb3R0YWJsZS5EYXRhc2V0KSB7XG4gICAgbGV0IGRhdGEgPSBkYXRhc2V0LmRhdGEoKTtcbiAgICBjb25zdCBzbW9vdGhpbmdXZWlnaHQgPSB0aGlzLnNtb290aGluZ1dlaWdodDtcbiAgICAvLyAxc3Qtb3JkZXIgSUlSIGxvdy1wYXNzIGZpbHRlciB0byBhdHRlbnVhdGUgdGhlIGhpZ2hlci1cbiAgICAvLyBmcmVxdWVuY3kgY29tcG9uZW50cyBvZiB0aGUgdGltZS1zZXJpZXMuXG4gICAgbGV0IGxhc3QgPSBkYXRhLmxlbmd0aCA+IDAgPyAwIDogTmFOO1xuICAgIGxldCBudW1BY2N1bSA9IDA7XG4gICAgZGF0YS5mb3JFYWNoKChkLCBpKSA9PiB7XG4gICAgICBsZXQgbmV4dFZhbCA9IHRoaXMueVZhbHVlQWNjZXNzb3IoZCwgaSwgZGF0YXNldCk7XG4gICAgICBpZiAoIV8uaXNGaW5pdGUobmV4dFZhbCkpIHtcbiAgICAgICAgZC5zbW9vdGhlZCA9IG5leHRWYWw7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBsYXN0ID0gbGFzdCAqIHNtb290aGluZ1dlaWdodCArICgxIC0gc21vb3RoaW5nV2VpZ2h0KSAqIG5leHRWYWw7XG4gICAgICAgIG51bUFjY3VtKys7XG4gICAgICAgIC8vIFRoZSB1bmNvcnJlY3RlZCBtb3ZpbmcgYXZlcmFnZSBpcyBiaWFzZWQgdG93YXJkcyB0aGUgaW5pdGlhbCB2YWx1ZS5cbiAgICAgICAgLy8gRm9yIGV4YW1wbGUsIGlmIGluaXRpYWxpemVkIHdpdGggYDBgLCB3aXRoIHNtb290aGluZ1dlaWdodCBgc2AsIHdoZXJlXG4gICAgICAgIC8vIGV2ZXJ5IGRhdGEgcG9pbnQgaXMgYGNgLCBhZnRlciBgdGAgc3RlcHMgdGhlIG1vdmluZyBhdmVyYWdlIGlzXG4gICAgICAgIC8vIGBgYFxuICAgICAgICAvLyAgIEVNQSA9IDAqc14odCkgKyBjKigxIC0gcykqc14odC0xKSArIGMqKDEgLSBzKSpzXih0LTIpICsgLi4uXG4gICAgICAgIC8vICAgICAgID0gYyooMSAtIHNedClcbiAgICAgICAgLy8gYGBgXG4gICAgICAgIC8vIElmIGluaXRpYWxpemVkIHdpdGggYDBgLCBkaXZpZGluZyBieSAoMSAtIHNedCkgaXMgZW5vdWdoIHRvIGRlYmlhc1xuICAgICAgICAvLyB0aGUgbW92aW5nIGF2ZXJhZ2UuIFdlIGNvdW50IHRoZSBudW1iZXIgb2YgZmluaXRlIGRhdGEgcG9pbnRzIGFuZFxuICAgICAgICAvLyBkaXZpZGUgYXBwcm9wcmlhdGVseSBiZWZvcmUgc3RvcmluZyB0aGUgZGF0YS5cbiAgICAgICAgbGV0IGRlYmlhc1dlaWdodCA9IDE7XG4gICAgICAgIGlmIChzbW9vdGhpbmdXZWlnaHQgIT09IDEuMCkge1xuICAgICAgICAgIGRlYmlhc1dlaWdodCA9IDEuMCAtIE1hdGgucG93KHNtb290aGluZ1dlaWdodCwgbnVtQWNjdW0pO1xuICAgICAgICB9XG4gICAgICAgIGQuc21vb3RoZWQgPSBsYXN0IC8gZGViaWFzV2VpZ2h0O1xuICAgICAgfVxuICAgIH0pO1xuICB9XG5cbiAgcHJpdmF0ZSBnZXREYXRhc2V0KG5hbWU6IHN0cmluZykge1xuICAgIGlmICh0aGlzLm5hbWUyZGF0YXNldHNbbmFtZV0gPT09IHVuZGVmaW5lZCkge1xuICAgICAgdGhpcy5uYW1lMmRhdGFzZXRzW25hbWVdID0gbmV3IFBsb3R0YWJsZS5EYXRhc2V0KFtdLCB7XG4gICAgICAgIG5hbWUsXG4gICAgICAgIG1ldGE6IG51bGwsXG4gICAgICB9KTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMubmFtZTJkYXRhc2V0c1tuYW1lXTtcbiAgfVxuXG4gIHN0YXRpYyBnZXRZU2NhbGVGcm9tVHlwZSh5U2NhbGVUeXBlOiBzdHJpbmcpOlxuICAgICAgUGxvdHRhYmxlLlF1YW50aXRhdGl2ZVNjYWxlPG51bWJlcj4ge1xuICAgIGlmICh5U2NhbGVUeXBlID09PSAnbG9nJykge1xuICAgICAgcmV0dXJuIG5ldyBQbG90dGFibGUuU2NhbGVzLk1vZGlmaWVkTG9nKCk7XG4gICAgfSBlbHNlIGlmICh5U2NhbGVUeXBlID09PSAnbGluZWFyJykge1xuICAgICAgcmV0dXJuIG5ldyBQbG90dGFibGUuU2NhbGVzLkxpbmVhcigpO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ1VucmVjb2duaXplZCB5U2NhbGUgdHlwZSAnICsgeVNjYWxlVHlwZSk7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIFVwZGF0ZSB0aGUgc2VsZWN0ZWQgc2VyaWVzIG9uIHRoZSBjaGFydC5cbiAgICovXG4gIHB1YmxpYyBzZXRWaXNpYmxlU2VyaWVzKG5hbWVzOiBzdHJpbmdbXSkge1xuICAgIG5hbWVzID0gbmFtZXMuc29ydCgpO1xuICAgIHRoaXMuc2VyaWVzTmFtZXMgPSBuYW1lcztcblxuICAgIG5hbWVzLnJldmVyc2UoKTsgIC8vIGRyYXcgZmlyc3Qgc2VyaWVzIG9uIHRvcFxuICAgIHRoaXMuZGF0YXNldHMuZm9yRWFjaCgoZCkgPT4gZC5vZmZVcGRhdGUodGhpcy5vbkRhdGFzZXRDaGFuZ2VkKSk7XG4gICAgdGhpcy5kYXRhc2V0cyA9IG5hbWVzLm1hcCgocikgPT4gdGhpcy5nZXREYXRhc2V0KHIpKTtcbiAgICB0aGlzLmRhdGFzZXRzLmZvckVhY2goKGQpID0+IGQub25VcGRhdGUodGhpcy5vbkRhdGFzZXRDaGFuZ2VkKSk7XG4gICAgdGhpcy5saW5lUGxvdC5kYXRhc2V0cyh0aGlzLmRhdGFzZXRzKTtcblxuICAgIGlmICh0aGlzLnNtb290aGluZ0VuYWJsZWQpIHtcbiAgICAgIHRoaXMuc21vb3RoTGluZVBsb3QuZGF0YXNldHModGhpcy5kYXRhc2V0cyk7XG4gICAgfVxuICAgIGlmICh0aGlzLm1hcmdpbkFyZWFQbG90KSB7XG4gICAgICB0aGlzLm1hcmdpbkFyZWFQbG90LmRhdGFzZXRzKHRoaXMuZGF0YXNldHMpO1xuICAgIH1cbiAgICB0aGlzLnVwZGF0ZVNwZWNpYWxEYXRhc2V0cygpO1xuICB9XG5cbiAgLyoqXG4gICAqIFNhbXBsZXMgYSBkYXRhc2V0IHNvIHRoYXQgaXQgY29udGFpbnMgbm8gbW9yZSB0aGFuIF9NQVhfTUFSS0VSUyBudW1iZXIgb2ZcbiAgICogZGF0YSBwb2ludHMuIFRoaXMgZnVuY3Rpb24gcmV0dXJucyB0aGUgb3JpZ2luYWwgZGF0YXNldCBpZiBpdCBkb2VzIG5vdFxuICAgKiBleGNlZWQgdGhhdCBtYW55IHBvaW50cy5cbiAgICovXG4gIHB1YmxpYyBjcmVhdGVTYW1wbGVkRGF0YXNldEZvck1hcmtlcnMob3JpZ2luYWw6IFBsb3R0YWJsZS5EYXRhc2V0KTpcbiAgICAgIFBsb3R0YWJsZS5EYXRhc2V0IHtcbiAgICBjb25zdCBvcmlnaW5hbERhdGEgPSBvcmlnaW5hbC5kYXRhKCk7XG4gICAgaWYgKG9yaWdpbmFsRGF0YS5sZW5ndGggPD0gX01BWF9NQVJLRVJTKSB7XG4gICAgICAvLyBUaGlzIGRhdGFzZXQgaXMgc21hbGwgZW5vdWdoLiBEbyBub3Qgc2FtcGxlLlxuICAgICAgcmV0dXJuIG9yaWdpbmFsO1xuICAgIH1cblxuICAgIC8vIERvd25zYW1wbGUgdGhlIGRhdGEuIE90aGVyd2lzZSwgdG9vIG1hbnkgbWFya2VycyBjbHV0dGVyIHRoZSBjaGFydC5cbiAgICBjb25zdCBza2lwTGVuZ3RoID0gTWF0aC5jZWlsKG9yaWdpbmFsRGF0YS5sZW5ndGggLyBfTUFYX01BUktFUlMpO1xuICAgIGNvbnN0IGRhdGEgPSBuZXcgQXJyYXkoTWF0aC5mbG9vcihvcmlnaW5hbERhdGEubGVuZ3RoIC8gc2tpcExlbmd0aCkpO1xuICAgIGZvciAobGV0IGkgPSAwLCBqID0gMDsgaSA8IGRhdGEubGVuZ3RoOyBpKyssIGogKz0gc2tpcExlbmd0aCkge1xuICAgICAgZGF0YVtpXSA9IG9yaWdpbmFsRGF0YVtqXTtcbiAgICB9XG4gICAgcmV0dXJuIG5ldyBQbG90dGFibGUuRGF0YXNldChkYXRhLCBvcmlnaW5hbC5tZXRhZGF0YSgpKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBTZXRzIHRoZSBkYXRhIG9mIGEgc2VyaWVzIG9uIHRoZSBjaGFydC5cbiAgICovXG4gIHB1YmxpYyBzZXRTZXJpZXNEYXRhKG5hbWU6IHN0cmluZywgZGF0YTogdnpfY2hhcnRfaGVscGVycy5TY2FsYXJEYXR1bVtdKSB7XG4gICAgdGhpcy5nZXREYXRhc2V0KG5hbWUpLmRhdGEoZGF0YSk7XG4gICAgdGhpcy5tZWFzdXJlQkJveEFuZE1heWJlSW52YWxpZGF0ZUxheW91dEluUmFmKCk7XG4gIH1cblxuICAvKipcbiAgICogU2V0cyB0aGUgbWV0YWRhdGEgb2YgYSBzZXJpZXMgb24gdGhlIGNoYXJ0LlxuICAgKi9cbiAgcHVibGljIHNldFNlcmllc01ldGFkYXRhKG5hbWU6IHN0cmluZywgbWV0YTogYW55KSB7XG4gICAgY29uc3QgbmV3TWV0YSA9IE9iamVjdC5hc3NpZ24oe30sIHRoaXMuZ2V0RGF0YXNldChuYW1lKS5tZXRhZGF0YSgpLCB7bWV0YX0pO1xuICAgIHRoaXMuZ2V0RGF0YXNldChuYW1lKS5tZXRhZGF0YShuZXdNZXRhKTtcbiAgfVxuXG4gIHB1YmxpYyBzbW9vdGhpbmdVcGRhdGUod2VpZ2h0OiBudW1iZXIpIHtcbiAgICB0aGlzLnNtb290aGluZ1dlaWdodCA9IHdlaWdodDtcbiAgICB0aGlzLmRhdGFzZXRzLmZvckVhY2goKGQpID0+IHRoaXMucmVzbW9vdGhEYXRhc2V0KGQpKTtcblxuICAgIGlmICghdGhpcy5zbW9vdGhpbmdFbmFibGVkKSB7XG4gICAgICB0aGlzLmxpbmVQbG90LmFkZENsYXNzKCdnaG9zdCcpO1xuICAgICAgdGhpcy5zY2F0dGVyUGxvdC55KHRoaXMuc21vb3RoZWRBY2Nlc3NvciwgdGhpcy55U2NhbGUpO1xuICAgICAgdGhpcy5zbW9vdGhpbmdFbmFibGVkID0gdHJ1ZTtcbiAgICAgIHRoaXMuc21vb3RoTGluZVBsb3QuZGF0YXNldHModGhpcy5kYXRhc2V0cyk7XG4gICAgfVxuXG4gICAgaWYgKHRoaXMubWFya2Vyc1NjYXR0ZXJQbG90KSB7XG4gICAgICAvLyBVc2UgdGhlIGNvcnJlY3QgYWNjZXNzb3IgZm9yIG1hcmtlciBwb3NpdGlvbmluZy5cbiAgICAgIHRoaXMubWFya2Vyc1NjYXR0ZXJQbG90LnkodGhpcy5nZXRZQXhpc0FjY2Vzc29yKCksIHRoaXMueVNjYWxlKTtcbiAgICB9XG5cbiAgICB0aGlzLnVwZGF0ZVNwZWNpYWxEYXRhc2V0cygpO1xuICB9XG5cbiAgcHVibGljIHNtb290aGluZ0Rpc2FibGUoKSB7XG4gICAgaWYgKHRoaXMuc21vb3RoaW5nRW5hYmxlZCkge1xuICAgICAgdGhpcy5saW5lUGxvdC5yZW1vdmVDbGFzcygnZ2hvc3QnKTtcbiAgICAgIHRoaXMuc2NhdHRlclBsb3QueSh0aGlzLnlWYWx1ZUFjY2Vzc29yLCB0aGlzLnlTY2FsZSk7XG4gICAgICB0aGlzLnNtb290aExpbmVQbG90LmRhdGFzZXRzKFtdKTtcbiAgICAgIHRoaXMuc21vb3RoaW5nRW5hYmxlZCA9IGZhbHNlO1xuICAgICAgdGhpcy51cGRhdGVTcGVjaWFsRGF0YXNldHMoKTtcbiAgICB9XG4gICAgaWYgKHRoaXMubWFya2Vyc1NjYXR0ZXJQbG90KSB7XG4gICAgICAvLyBVc2UgdGhlIGNvcnJlY3QgYWNjZXNzb3IgKHdoaWNoIGRlcGVuZHMgb24gd2hldGhlciBzbW9vdGhpbmcgaXNcbiAgICAgIC8vIGVuYWJsZWQpIGZvciBtYXJrZXIgcG9zaXRpb25pbmcuXG4gICAgICB0aGlzLm1hcmtlcnNTY2F0dGVyUGxvdC55KHRoaXMuZ2V0WUF4aXNBY2Nlc3NvcigpLCB0aGlzLnlTY2FsZSk7XG4gICAgfVxuICB9XG5cbiAgcHVibGljIHNldFRvb2x0aXBTb3J0aW5nTWV0aG9kKG1ldGhvZDogc3RyaW5nKSB7XG4gICAgdGhpcy50b29sdGlwU29ydGluZ01ldGhvZCA9IG1ldGhvZDtcbiAgfVxuXG4gIHB1YmxpYyByZW5kZXJUbyh0YXJnZXRTVkc6IGQzLlNlbGVjdGlvbjxhbnksIGFueSwgYW55LCBhbnk+KSB7XG4gICAgdGhpcy50YXJnZXRTVkcgPSB0YXJnZXRTVkc7XG4gICAgdGhpcy5vdXRlci5yZW5kZXJUbyh0YXJnZXRTVkcpO1xuXG4gICAgaWYgKHRoaXMuX2RlZmF1bHRYUmFuZ2UgIT0gbnVsbCkge1xuICAgICAgLy8gQSBoaWdoZXItbGV2ZWwgY29tcG9uZW50IHByb3ZpZGVkIGEgZGVmYXVsdCByYW5nZSBmb3IgdGhlIFggYXhpcy5cbiAgICAgIC8vIFN0YXJ0IHdpdGggdGhhdCByYW5nZS5cbiAgICAgIHRoaXMucmVzZXRYRG9tYWluKCk7XG4gICAgfVxuXG4gICAgaWYgKHRoaXMuX2RlZmF1bHRZUmFuZ2UgIT0gbnVsbCkge1xuICAgICAgLy8gQSBoaWdoZXItbGV2ZWwgY29tcG9uZW50IHByb3ZpZGVkIGEgZGVmYXVsdCByYW5nZSBmb3IgdGhlIFkgYXhpcy5cbiAgICAgIC8vIFN0YXJ0IHdpdGggdGhhdCByYW5nZS5cbiAgICAgIHRoaXMucmVzZXRZRG9tYWluKCk7XG4gICAgfVxuXG4gICAgdGhpcy5tZWFzdXJlQkJveEFuZE1heWJlSW52YWxpZGF0ZUxheW91dEluUmFmKCk7XG4gIH1cblxuICBwdWJsaWMgcmVkcmF3KCkge1xuICAgIHdpbmRvdy5jYW5jZWxBbmltYXRpb25GcmFtZSh0aGlzLl9yZWRyYXdSYWYpO1xuICAgIHRoaXMuX3JlZHJhd1JhZiA9IHdpbmRvdy5yZXF1ZXN0QW5pbWF0aW9uRnJhbWUoKCkgPT4ge1xuICAgICAgdGhpcy5tZWFzdXJlQkJveEFuZE1heWJlSW52YWxpZGF0ZUxheW91dCgpO1xuICAgICAgdGhpcy5vdXRlci5yZWRyYXcoKTtcbiAgICB9KTtcbiAgfVxuXG4gIHByaXZhdGUgbWVhc3VyZUJCb3hBbmRNYXliZUludmFsaWRhdGVMYXlvdXRJblJhZigpIHtcbiAgICB3aW5kb3cuY2FuY2VsQW5pbWF0aW9uRnJhbWUodGhpcy5faW52YWxpZGF0ZUxheW91dFJhZik7XG4gICAgdGhpcy5faW52YWxpZGF0ZUxheW91dFJhZiA9IHdpbmRvdy5yZXF1ZXN0QW5pbWF0aW9uRnJhbWUoKCkgPT4ge1xuICAgICAgdGhpcy5tZWFzdXJlQkJveEFuZE1heWJlSW52YWxpZGF0ZUxheW91dCgpO1xuICAgIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIE1lYXN1cmVzIGJvdW5kaW5nIGJveCBvZiB0aGUgYW5jaG9yIG5vZGUgYW5kIGRldGVybWluZXMgd2hldGhlciB0aGUgbGF5b3V0XG4gICAqIG5lZWRzIHRvIGJlIHJlLWRvbmUgd2l0aCBtZWFzdXJlbWVudCBjYWNoZSBpbnZhbGlkYXRlZC4gUGxvdHRhYmxlIGltcHJvdmVkXG4gICAqIHBlcmZvcm1hbmNlIG9mIHJlbmRlcmluZyBieSBjYWNoaW5nIGV4cGVuc2l2ZSBET00gbWVhc3VyZW1lbnQgYnV0IHRoaXNcbiAgICogY2FjaGUgY2FuIGJlIHBvaXNvbmVkIGluIGNhc2UgdGhlIGFuY2hvciBub2RlIGlzIGluIGEgd3Jvbmcgc3RhdGUgLS0gbmFtZWx5XG4gICAqIGBkaXNwbGF5OiBub25lYCB3aGVyZSBhbGwgZGltZW5zaW9ucyBhcmUgMC5cbiAgICovXG4gIHByaXZhdGUgbWVhc3VyZUJCb3hBbmRNYXliZUludmFsaWRhdGVMYXlvdXQoKSB7XG4gICAgaWYgKHRoaXMuX2xhc3REcmF3QkJveCkge1xuICAgICAgY29uc3Qge3dpZHRoOiBwcmV2V2lkdGh9ID0gdGhpcy5fbGFzdERyYXdCQm94O1xuICAgICAgY29uc3Qge3dpZHRofSA9IHRoaXMudGFyZ2V0U1ZHLm5vZGUoKS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgICAgIGlmIChwcmV2V2lkdGggPT0gMCAmJiBwcmV2V2lkdGggPCB3aWR0aCkgdGhpcy5vdXRlci5pbnZhbGlkYXRlQ2FjaGUoKTtcbiAgICB9XG4gICAgdGhpcy5fbGFzdERyYXdCQm94ID0gdGhpcy50YXJnZXRTVkcubm9kZSgpLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuICB9XG5cbiAgcHVibGljIGRlc3Ryb3koKSB7XG4gICAgLy8gRGVzdHJveWluZyBvdXRlciBkZXN0cm95cyBhbGwgc3ViY29tcG9uZW50cyByZWN1cnNpdmVseS5cbiAgICB3aW5kb3cuY2FuY2VsQW5pbWF0aW9uRnJhbWUodGhpcy5fcmVkcmF3UmFmKTtcbiAgICB3aW5kb3cuY2FuY2VsQW5pbWF0aW9uRnJhbWUodGhpcy5faW52YWxpZGF0ZUxheW91dFJhZik7XG4gICAgaWYgKHRoaXMub3V0ZXIpIHRoaXMub3V0ZXIuZGVzdHJveSgpO1xuICB9XG5cbiAgcHVibGljIG9uQW5jaG9yKGZuOiAoKSA9PiB2b2lkKSB7XG4gICAgaWYgKHRoaXMub3V0ZXIpIHRoaXMub3V0ZXIub25BbmNob3IoZm4pO1xuICB9XG59XG5cbn0gIC8vIG5hbWVzcGFjZSB2el9saW5lX2NoYXJ0MlxuIl19