declare namespace vz_line_chart2 {
    const DEFAULT_TOOLTIP_COLUMNS: ({
        title: string;
        evaluate: (d: vz_chart_helpers.Point) => any;
    } | {
        title: string;
        evaluate(d: vz_chart_helpers.Point, statusObject: LineChartStatus): string;
    })[];
}
