declare namespace tf_globals {
    function setUseHash(shouldUseHash: boolean): void;
    function useHash(): boolean;
    function setFakeHash(h: string): void;
    function getFakeHash(): string;
    function getEnableDataSelector(): boolean;
}
