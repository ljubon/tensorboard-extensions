var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
/* Copyright 2018 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
var tf_backend;
(function (tf_backend) {
    var Mode;
    (function (Mode) {
        Mode[Mode["DB"] = 0] = "DB";
        Mode[Mode["LOGDIR"] = 1] = "LOGDIR";
    })(Mode = tf_backend.Mode || (tf_backend.Mode = {}));
    var EnvironmentStore = /** @class */ (function (_super) {
        __extends(EnvironmentStore, _super);
        function EnvironmentStore() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        EnvironmentStore.prototype.load = function () {
            var _this = this;
            var url = tf_backend.getRouter().environment();
            return this.requestManager.request(url).then(function (result) {
                var environment = {
                    dataLocation: result.data_location,
                    mode: result.mode == 'db' ? Mode.DB : Mode.LOGDIR,
                    windowTitle: result.window_title,
                };
                if (_.isEqual(_this.environment, environment))
                    return;
                _this.environment = environment;
                _this.emitChange();
            });
        };
        EnvironmentStore.prototype.getDataLocation = function () {
            return this.environment ? this.environment.dataLocation : '';
        };
        EnvironmentStore.prototype.getMode = function () {
            return this.environment ? this.environment.mode : null;
        };
        EnvironmentStore.prototype.getWindowTitle = function () {
            return this.environment ? this.environment.windowTitle : '';
        };
        return EnvironmentStore;
    }(tf_backend.BaseStore));
    tf_backend.EnvironmentStore = EnvironmentStore;
    tf_backend.environmentStore = new EnvironmentStore();
})(tf_backend || (tf_backend = {})); // namespace tf_backend
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZW52aXJvbm1lbnRTdG9yZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImVudmlyb25tZW50U3RvcmUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztBQUFBOzs7Ozs7Ozs7Ozs7O2dGQWFnRjtBQUNoRixJQUFVLFVBQVUsQ0E4Q25CO0FBOUNELFdBQVUsVUFBVTtJQUVwQixJQUFZLElBR1g7SUFIRCxXQUFZLElBQUk7UUFDZCwyQkFBRSxDQUFBO1FBQ0YsbUNBQU0sQ0FBQTtJQUNSLENBQUMsRUFIVyxJQUFJLEdBQUosZUFBSSxLQUFKLGVBQUksUUFHZjtJQVFEO1FBQXNDLG9DQUFTO1FBQS9DOztRQTZCQSxDQUFDO1FBMUJDLCtCQUFJLEdBQUo7WUFBQSxpQkFhQztZQVpDLElBQU0sR0FBRyxHQUFHLFVBQVUsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUNqRCxPQUFPLElBQUksQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFBLE1BQU07Z0JBQ2pELElBQU0sV0FBVyxHQUFHO29CQUNsQixZQUFZLEVBQUUsTUFBTSxDQUFDLGFBQWE7b0JBQ2xDLElBQUksRUFBRSxNQUFNLENBQUMsSUFBSSxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU07b0JBQ2pELFdBQVcsRUFBRSxNQUFNLENBQUMsWUFBWTtpQkFDakMsQ0FBQztnQkFDRixJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSSxDQUFDLFdBQVcsRUFBRSxXQUFXLENBQUM7b0JBQUUsT0FBTztnQkFFckQsS0FBSSxDQUFDLFdBQVcsR0FBRyxXQUFXLENBQUM7Z0JBQy9CLEtBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztZQUNwQixDQUFDLENBQUMsQ0FBQztRQUNMLENBQUM7UUFFTSwwQ0FBZSxHQUF0QjtZQUNFLE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztRQUMvRCxDQUFDO1FBRU0sa0NBQU8sR0FBZDtZQUNFLE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztRQUN6RCxDQUFDO1FBRU0seUNBQWMsR0FBckI7WUFDRSxPQUFPLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7UUFDOUQsQ0FBQztRQUNILHVCQUFDO0lBQUQsQ0FBQyxBQTdCRCxDQUFzQyxXQUFBLFNBQVMsR0E2QjlDO0lBN0JZLDJCQUFnQixtQkE2QjVCLENBQUE7SUFFWSwyQkFBZ0IsR0FBRyxJQUFJLGdCQUFnQixFQUFFLENBQUM7QUFFdkQsQ0FBQyxFQTlDUyxVQUFVLEtBQVYsVUFBVSxRQThDbkIsQ0FBRSx1QkFBdUIiLCJzb3VyY2VzQ29udGVudCI6WyIvKiBDb3B5cmlnaHQgMjAxOCBUaGUgVGVuc29yRmxvdyBBdXRob3JzLiBBbGwgUmlnaHRzIFJlc2VydmVkLlxuXG5MaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UsIFZlcnNpb24gMi4wICh0aGUgXCJMaWNlbnNlXCIpO1xueW91IG1heSBub3QgdXNlIHRoaXMgZmlsZSBleGNlcHQgaW4gY29tcGxpYW5jZSB3aXRoIHRoZSBMaWNlbnNlLlxuWW91IG1heSBvYnRhaW4gYSBjb3B5IG9mIHRoZSBMaWNlbnNlIGF0XG5cbiAgICBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcblxuVW5sZXNzIHJlcXVpcmVkIGJ5IGFwcGxpY2FibGUgbGF3IG9yIGFncmVlZCB0byBpbiB3cml0aW5nLCBzb2Z0d2FyZVxuZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIExpY2Vuc2UgaXMgZGlzdHJpYnV0ZWQgb24gYW4gXCJBUyBJU1wiIEJBU0lTLFxuV0lUSE9VVCBXQVJSQU5USUVTIE9SIENPTkRJVElPTlMgT0YgQU5ZIEtJTkQsIGVpdGhlciBleHByZXNzIG9yIGltcGxpZWQuXG5TZWUgdGhlIExpY2Vuc2UgZm9yIHRoZSBzcGVjaWZpYyBsYW5ndWFnZSBnb3Zlcm5pbmcgcGVybWlzc2lvbnMgYW5kXG5saW1pdGF0aW9ucyB1bmRlciB0aGUgTGljZW5zZS5cbj09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSovXG5uYW1lc3BhY2UgdGZfYmFja2VuZCB7XG5cbmV4cG9ydCBlbnVtIE1vZGUge1xuICBEQixcbiAgTE9HRElSLFxufVxuXG5pbnRlcmZhY2UgRW52aXJvbm1lbnQge1xuICBkYXRhTG9jYXRpb246IHN0cmluZyxcbiAgbW9kZTogTW9kZSxcbiAgd2luZG93VGl0bGU6IHN0cmluZyxcbn1cblxuZXhwb3J0IGNsYXNzIEVudmlyb25tZW50U3RvcmUgZXh0ZW5kcyBCYXNlU3RvcmUge1xuICBwcml2YXRlIGVudmlyb25tZW50OiBFbnZpcm9ubWVudDtcblxuICBsb2FkKCkge1xuICAgIGNvbnN0IHVybCA9IHRmX2JhY2tlbmQuZ2V0Um91dGVyKCkuZW52aXJvbm1lbnQoKTtcbiAgICByZXR1cm4gdGhpcy5yZXF1ZXN0TWFuYWdlci5yZXF1ZXN0KHVybCkudGhlbihyZXN1bHQgPT4ge1xuICAgICAgY29uc3QgZW52aXJvbm1lbnQgPSB7XG4gICAgICAgIGRhdGFMb2NhdGlvbjogcmVzdWx0LmRhdGFfbG9jYXRpb24sXG4gICAgICAgIG1vZGU6IHJlc3VsdC5tb2RlID09ICdkYicgPyBNb2RlLkRCIDogTW9kZS5MT0dESVIsXG4gICAgICAgIHdpbmRvd1RpdGxlOiByZXN1bHQud2luZG93X3RpdGxlLFxuICAgICAgfTtcbiAgICAgIGlmIChfLmlzRXF1YWwodGhpcy5lbnZpcm9ubWVudCwgZW52aXJvbm1lbnQpKSByZXR1cm47XG5cbiAgICAgIHRoaXMuZW52aXJvbm1lbnQgPSBlbnZpcm9ubWVudDtcbiAgICAgIHRoaXMuZW1pdENoYW5nZSgpO1xuICAgIH0pO1xuICB9XG5cbiAgcHVibGljIGdldERhdGFMb2NhdGlvbigpOiBzdHJpbmcge1xuICAgIHJldHVybiB0aGlzLmVudmlyb25tZW50ID8gdGhpcy5lbnZpcm9ubWVudC5kYXRhTG9jYXRpb24gOiAnJztcbiAgfVxuXG4gIHB1YmxpYyBnZXRNb2RlKCk6IE1vZGUge1xuICAgIHJldHVybiB0aGlzLmVudmlyb25tZW50ID8gdGhpcy5lbnZpcm9ubWVudC5tb2RlIDogbnVsbDtcbiAgfVxuXG4gIHB1YmxpYyBnZXRXaW5kb3dUaXRsZSgpOiBzdHJpbmcge1xuICAgIHJldHVybiB0aGlzLmVudmlyb25tZW50ID8gdGhpcy5lbnZpcm9ubWVudC53aW5kb3dUaXRsZSA6ICcnO1xuICB9XG59XG5cbmV4cG9ydCBjb25zdCBlbnZpcm9ubWVudFN0b3JlID0gbmV3IEVudmlyb25tZW50U3RvcmUoKTtcblxufSAgLy8gbmFtZXNwYWNlIHRmX2JhY2tlbmRcbiJdfQ==