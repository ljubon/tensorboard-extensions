declare namespace tf_custom_scalar_dashboard {
    interface CustomScalarResponse {
        regex_valid: boolean;
        tag_to_events: {
            [key: string]: vz_chart_helpers.ScalarDatum[];
        };
    }
    /**
     * A chart encapsulates data on a single chart.
     */
    interface Chart {
        title: string;
        tag: string[];
    }
    /**
     * A category specifies charts within a single collapsible.
     */
    interface Category {
        title: string;
        chart: Chart[];
    }
    /**
     * A layout specifies how the various categories and charts should be laid out
     * within the dashboard.
     */
    interface Layout {
        category: Category[];
    }
    /**
     * A class that represents a data series for a custom scalars chart.
     */
    class DataSeries {
        private run;
        private tag;
        private name;
        private scalarData;
        private symbol;
        constructor(run: string, tag: string, name: string, scalarData: vz_chart_helpers.ScalarDatum[], symbol: vz_chart_helpers.LineChartSymbol);
        getName(): string;
        setData(scalarData: vz_chart_helpers.ScalarDatum[]): void;
        getData(): vz_chart_helpers.ScalarDatum[];
        getRun(): string;
        getTag(): string;
        getSymbol(): vz_chart_helpers.LineChartSymbol;
    }
    function generateDataSeriesName(run: string, tag: string): string;
    /**
     * A color scale that wraps the usual color scale that relies on runs. This
     * particular color scale parses the run from a series name and defers to that
     * former color scale.
     */
    class DataSeriesColorScale {
        private runBasedColorScale;
        constructor(runBasedColorScale: Plottable.Scales.Color);
        /**
         * Obtains the correct color based on the run.
         * @param {string} dataSeries
         * @return {string} The color.
         */
        scale(dataSeries: string): string;
        /**
         * Parses the run name from a data series string. Returns the empty string if
         * parsing fails.
         */
        private parseRunName;
    }
}
