declare module tf.graph {
    /** Delimiter used in node names to denote namespaces. */
    const NAMESPACE_DELIM = "/";
    const ROOT_NAME = "__root__";
    const FUNCTION_LIBRARY_NODE_PREFIX = "__function_library__";
    /** Attribute key used for storing attributes that are too large. */
    const LARGE_ATTRS_KEY = "_too_large_attrs";
    /**
     * Maximum allowed size in bytes, before the attribute is considered large
     * and filtered out of the graph.
     */
    const LIMIT_ATTR_SIZE = 1024;
    const EDGE_KEY_DELIM = "--";
    enum GraphType {
        FULL = 0,
        EMBEDDED = 1,
        META = 2,
        SERIES = 3,
        CORE = 4,
        SHADOW = 5,
        BRIDGE = 6,
        EDGE = 7
    }
    enum NodeType {
        META = 0,
        OP = 1,
        SERIES = 2,
        BRIDGE = 3,
        ELLIPSIS = 4
    }
    /** Indicates if a node is to be included in the main graph when rendered. */
    enum InclusionType {
        INCLUDE = 0,
        EXCLUDE = 1,
        UNSPECIFIED = 2
    }
    /** Indicates if a series is to be grouped in the graph when rendered. */
    enum SeriesGroupingType {
        GROUP = 0,
        UNGROUP = 1
    }
    /**
     * A BaseEdge is the label object (in the graphlib sense) for an edge in the
     * original, full graph produced after parsing. Subsequent graphs, like those
     * which belong to Metanodes, should not use BaseEdge objects, but instead
     * contain Metaedges (which in turn may contain any number of BaseEdges).
     */
    interface BaseEdge extends graphlib.EdgeObject {
        isControlDependency: boolean;
        isReferenceEdge: boolean;
        /** The index of the output tensor of the source node. */
        outputTensorKey: string;
    }
    /**
     * A SlimGraph is inspired by graphlib.Graph, but having only the functionality
     * that we need.
     */
    class SlimGraph {
        nodes: {
            [nodeName: string]: OpNode;
        };
        edges: BaseEdge[];
        constructor();
    }
    interface NormalizedInput {
        name: string;
        /** The index of the output tensor of the source node. */
        outputTensorKey: string;
        isControlDependency: boolean;
    }
    interface BuildParams {
        enableEmbedding: boolean;
        inEmbeddingTypes: string[];
        outEmbeddingTypes: string[];
        refEdges: {
            [inputEdge: string]: boolean;
        };
    }
    /**
     * The most basic information about a node in the hierarchical graph.
     */
    interface Node {
        /** The name of the node, used frequently to look up nodes by name. */
        name: string;
        /** Which type of node this is. */
        type: NodeType;
        /**
         * Whether this node is a type that may contain other nodes. Those types
         * should extend from GroupNode.
         *
         * For an OpNode, isGroupNode will be false, even though it may have
         * embeddings. These embedding Nodes will have their parentNode set to the
         * OpNode. However, embeddings are later rendered as annotations, not as
         * children to be made visible on expansion (like a Metanode or SeriesNode).
         */
        isGroupNode: boolean;
        /**
         * The number of nodes this node represents. For OpNodes, this will be 1, and
         * for GroupNodes it will be a count of the total number of descendents it
         * contains.
         */
        cardinality: number;
        /**
         * The Node which is this Node's parent. This is of type Node and not
         * GroupNode because of embeddings, which will have a parent OpNode.
         */
        parentNode: Node;
        /** Runtime execution stats for this node, if available */
        stats: NodeStats;
        /** If the node is to be included or excluded from the main graph when
         *  rendered. Defaults to UNSPECIFIED, which means that the rendering
         *  algorithm determines if it will be included or not. Then can be set to
         *  INCLUDE or EXCLUDE manually by the user.
         */
        include: InclusionType;
        /**
         * Node attributes specify customizable visual aspects of a node and
         * application-specific metadata associated with a node. The name
         * 'nodeAttributes' is meant to avoid naming-conflicts with the 'attr' in
         * subclasses of Node.
         */
        nodeAttributes: {
            [key: string]: any;
        };
    }
    type TensorShape = number[];
    interface OpNode extends Node {
        op: string;
        device: string;
        attr: {
            key: string;
            value: any;
        }[];
        inputs: NormalizedInput[];
        inEmbeddings: OpNode[];
        outEmbeddings: OpNode[];
        owningSeries: string;
        /**
         * Object mapping output channel string to tensor shapes. The output channel
         * is a string rather than a number because within TensorFlow functions, an
         * output may be a cross between an output variable and a number (combined
         * with a colon) such as "foo:2" rather than just a number alone.
         *
         * Each tensor shape is an array of numbers, or null. Details:
         * - null means unknown rank, and therefore entire shape is unknown.
         * - [4, 2, 1] means rank-3 tensor of size 4x2x1.
         * - [] means a scalar (rank-0 tensor).
         * - [1] means rank-1 tensor of size 1 (not the same as scalar).
         * - [5, -1, 3] means rank-3 tensor of shape is 5x?x3. The size
         *       of the middle dimension is unknown (encoded as -1).
         */
        outputShapes: {
            [key: string]: TensorShape;
        };
        xlaCluster: string;
        compatible: boolean;
        functionInputIndex: number;
        functionOutputIndex: number;
    }
    interface BridgeNode extends Node {
        /**
         * Whether this bridge node represents edges coming into its parent node.
         */
        inbound: boolean;
    }
    /**
     * A node that is used when there are more than the maximum number of allowed
     * annotations hanging off of a node.  This node represents an ellipsis
     * annotation, indicating a number of additional annotations.
     */
    interface EllipsisNode extends Node {
        /**
         * The number of nodes this ellipsis represents.
         */
        numMoreNodes: number;
        /**
         * Sets the number of nodes this ellipsis represents and changes the node
         * name accordingly.
         */
        setNumMoreNodes(numNodes: number): any;
    }
    interface GroupNode extends Node {
        /**
         * The metagraph contains nodes and metaedges between the immediate children
         * of this group. The node label objects may be other GroupNodes (like
         * SeriesNodes and Metanodes) or individual OpNodes. All edge label objects
         * are Metaedges, each of which contains references to the original
         * BaseEdge(s) from which it was created.
         */
        metagraph: graphlib.Graph<GroupNode | OpNode, Metaedge>;
        /**
         * The bridgegraph contains only edges which link immediate children of this
         * group with nodes outside of the metagraph. As in the metagraph, all edge
         * label objects are Metaedges which contain references to the original
         * BaseEdge(s) that contribute to it.
         *
         * For a Metaedge in the bridgegraph, its external endpoint will be the same
         * as the metagraph edge from which it came. This is most easily explained
         * by example.
         *
         * Consider an original graph that contains a BaseEdge A/B/C->Z/Y/X.
         *
         *     +-------+    (BaseEdge)     +-------+
         *     | A/B/C |>----------------->| Z/Y/X |
         *     +-------+                   +-------+
         *
         * When we construct the Root's metagraph, it will contain nodes for A and Z,
         * and a Metaedge A->Z. The A->Z Metaedge will contain the original BaseEdge
         * A/B/C->Z/Y/X in its baseEdgeGraph. The Root's bridgegraph will always be
         * empty.
         *
         *     +---+    (Root.metagraph edge)    +---+
         *     | A |>--------------------------->| Z |
         *     +---+                             +---+
         *
         * Now consider the Metanode A. Its metagraph will contain a Metanode for A/B
         * and no edges. A's bridgegraph will have one Metaedge from A/B->Z, which
         * was derived from the Root's Metaedge A->Z. That Metaedge will contain the
         * original BaseEdge in its baseEdgeGraph.
         *
         *     +---------+
         *     | A       |
         *     |  +---+  |   (A.bridgegraph edge)    +---+
         *     |  | B |>---------------------------->| Z |
         *     |  +---+  |                           +---+
         *     +---------+
         *
         * Finally, consider the Metanode A/B. Its metagraph will contain a Metanode
         * for A/B/C and again no edges. A/B's bridgegraph will have one Metaedge
         * from A/B/C->Z, which was derived from A's bridgegraph Metaedge A/B->Z.
         * As before, the A/B/C->Z Metaedge will contain the original BaseEdge in its
         * baseEdgeGraph.
         *
         *     +---------------+
         *     | A             |
         *     |  +---------+  |
         *     |  | B       |  |
         *     |  |  +---+  |  |   (A/B.bridgegraph edge)      +---+
         *     |  |  | C |>----------------------------------->| Z |
         *     |  |  +---+  |  |                               +---+
         *     |  +---------+  |
         *     +---------------+
         *
         * Likewise, under the Metanode Z and Z/Y, to compute the bridgegraph, we'll
         * end up with Metaedges A->Z/Y and A->Z/Y/X respectively. So the original
         * BaseEdge A/B/C->Z/Y/X becomes four different Metaedges in four different
         * bridgegraphs:
         *
         *   + A/B->Z in GroupNode A's bridgegraph,
         *   + A/B/C->Z in GroupNode A/B's bridgegraph,
         *   + A->Z/Y in GroupNode Z's bridgegraph, and
         *   + A->Z/Y/X in GroupNode Z/Y's bridgegraph.
         *
         * Considering any BaseEdge then, if N is the number of path segments in the
         * source and M is the number of path segments in the destination, then the
         * total number of bridgegraph edges you could create would be (N-1)(M-1).
         *
         * For this reason, it is computationally expensive to generate all the
         * bridgegraphs for all the Metanodes, and instead they should be computed
         * on demand as needed.
         */
        bridgegraph: graphlib.Graph<GroupNode | OpNode, Metaedge>;
        /**
         * Stores how many times each device name appears in its children
         * op nodes. Used to color group nodes by devices.
         */
        deviceHistogram: {
            [device: string]: number;
        };
        /**
         * Stores how many times each XLA cluster name appears in its children
         * op nodes. Used to color group nodes by XLA clusters.
         */
        xlaClusterHistogram: {
            [device: string]: number;
        };
        /**
         * Stores how many ops in sub-graph were compatible and how many are
         * incompatible.
         */
        compatibilityHistogram: {
            compatible: number;
            incompatible: number;
        };
        /**
         * Flag indicating whether this GroupNode's metagraph contains any edges that
         * are not control edges. Used to quickly determine how to draw a collapsed
         * series (vertically or horizontally).
         */
        hasNonControlEdges: boolean;
    }
    interface Metanode extends GroupNode {
        depth: number;
        templateId: string;
        opHistogram: {
            [op: string]: number;
        };
        associatedFunction: string;
        getFirstChild(): GroupNode | OpNode;
        getRootOp(): OpNode;
        /** Return name of all leaves inside a metanode. */
        leaves(): string[];
    }
    interface SeriesNode extends GroupNode {
        hasLoop: boolean;
        prefix: string;
        suffix: string;
        clusterId: number;
        ids: number[];
        parent: string;
    }
    class EllipsisNodeImpl implements EllipsisNode {
        name: string;
        numMoreNodes: number;
        stats: NodeStats;
        type: NodeType;
        isGroupNode: boolean;
        cardinality: number;
        parentNode: Node;
        include: InclusionType;
        nodeAttributes: {
            [key: string]: any;
        };
        /**
         * Constructs a new ellipsis annotation node.
         *
         * @param numNodes The number of additional annotations this node represents.
         */
        constructor(numNodes: number);
        setNumMoreNodes(numNodes: number): void;
    }
    /**
     * A label object for nodes in the full graph and leaf nodes in the render
     * graph.
     */
    class OpNodeImpl implements OpNode {
        name: string;
        op: string;
        device: string;
        stats: NodeStats;
        attr: {
            key: string;
            value: any;
        }[];
        inputs: NormalizedInput[];
        type: NodeType;
        isGroupNode: boolean;
        cardinality: number;
        inEmbeddings: OpNode[];
        outEmbeddings: OpNode[];
        parentNode: Node;
        include: InclusionType;
        owningSeries: string;
        outputShapes: {
            [key: string]: TensorShape;
        };
        nodeAttributes: {
            [key: string]: any;
        };
        xlaCluster: string;
        compatible: boolean;
        functionInputIndex: number;
        functionOutputIndex: number;
        /**
         * Constructs a new Op node.
         *
         * @param rawNode The raw node.
         */
        constructor(rawNode: tf.graph.proto.NodeDef);
    }
    function createMetanode(name: string, opt?: {}): Metanode;
    /**
     * Joins the information from the stats file (memory, compute time) with the
     * graph information.
     */
    function joinStatsInfoWithGraph(graph: SlimGraph, stats: tf.graph.proto.StepStats, devicesForStats?: {
        [device: string]: boolean;
    }): void;
    /**
     * Execution stats for the node.
     */
    class NodeStats {
        constructor(outputSize: number[][]);
        /**
         * Add the start and end time for a particular kernel execution of this op.
         * Ops can have multiple kernel executions within the same session run.
         */
        addExecutionTime(startTime: number, endTime: number): void;
        /**
         * Add the bytes allocated for a particular kernel execution of this op.
         * Ops can have multiple kernel executions within the same session run.
         */
        addBytesAllocation(totalBytes: number): void;
        /**
         * Absolute start time for the very first kernel execution of this op.
         */
        startTime: number;
        /**
         * Absolute end time for the very last kernel execution of this op.
         */
        endTime: number;
        /**
         * Total number of bytes used for the node. Sum of all children
         * if it is a Group node.
         */
        totalBytes: number;
        /**
         * The shape of each output tensors, if there are any.
         * Empty if it is a Group node.
         */
        outputSize: number[][];
        /**
         * Combines the specified stats with the current stats.
         * Modifies the current object. This method is used to
         * compute aggregate stats for group nodes.
         */
        combine(stats: NodeStats): void;
        /**
         * Total number of compute time in microseconds used for the node.
         * Sum of all children if it is a Group node. Null if it is unknown.
         * This method can not be scaffolded under a getter attribute because
         * ECMAScript 5 does not support getter attributes.
         */
        getTotalMicros(): number;
    }
    class MetanodeImpl implements Metanode {
        name: string;
        stats: NodeStats;
        type: NodeType;
        depth: number;
        isGroupNode: boolean;
        cardinality: number;
        metagraph: graphlib.Graph<GroupNode | OpNode, Metaedge>;
        bridgegraph: graphlib.Graph<GroupNode | OpNode, Metaedge>;
        templateId: string;
        opHistogram: {
            [op: string]: number;
        };
        deviceHistogram: {
            [op: string]: number;
        };
        xlaClusterHistogram: {
            [op: string]: number;
        };
        compatibilityHistogram: {
            compatible: number;
            incompatible: number;
        };
        parentNode: Node;
        hasNonControlEdges: boolean;
        include: InclusionType;
        nodeAttributes: {
            [key: string]: any;
        };
        associatedFunction: string;
        /** A label object for meta-nodes in the graph hierarchy */
        constructor(name: string, opt?: {});
        getFirstChild(): GroupNode | OpNode;
        /**
         * Returns the op node associated with the metanode.
         * For example, if the metanode is 'sgd', the associated
         * op node is sgd/(sgd).
         */
        getRootOp(): OpNode;
        /**
         * Return an array of the names of all the leaves (non-GroupNodes) inside
         * this metanode. This performs a breadth-first search of the tree, so
         * immediate child leaves will appear earlier in the output array than
         * descendant leaves.
         */
        leaves(): string[];
    }
    interface Metaedge extends graphlib.EdgeObject {
        /**
         * Stores the original BaseEdges represented by this Metaedge.
         */
        baseEdgeList: BaseEdge[];
        /**
         * Whether this edge represents a relationship that is inbound (or outbound)
         * to the object which contains this information. For example, in a Metanode's
         * bridgegraph, each edge connects an immediate child to something outside
         * the Metanode. If the destination of the edge is inside the Metanode, then
         * its inbound property should be true. If the destination is outside the
         * Metanode, then its inbound property should be false.
         *
         * The property is optional because not all edges can be described as
         * inbound/outbound. For example, in a Metanode's metagraph, all of the edges
         * connect immediate children of the Metanode. None should have an inbound
         * property, or they should be null/undefined.
         */
        inbound?: boolean;
        /**
         * Number of regular edges (not control dependency edges).
         */
        numRegularEdges: number;
        /**
         * Number of control dependency edges.
         */
        numControlEdges: number;
        /**
         * Number of reference edges, which is an edge to an operation
         * that takes a reference to its input and changes its value.
         */
        numRefEdges: number;
        /**
         * Total size (number of units) of all the tensors flowing through this edge.
         */
        totalSize: number;
        addBaseEdge(edge: BaseEdge, h: hierarchy.Hierarchy): void;
    }
    function createMetaedge(v: string, w: string): Metaedge;
    /**
     * A label object for edges between metanodes of subgraphs in the render graph.
     */
    class MetaedgeImpl implements Metaedge {
        v: string;
        w: string;
        baseEdgeList: BaseEdge[];
        inbound: boolean;
        numRegularEdges: number;
        numControlEdges: number;
        numRefEdges: number;
        totalSize: number;
        constructor(v: string, w: string);
        addBaseEdge(edge: BaseEdge, h: hierarchy.Hierarchy): void;
        private static computeSizeOfEdge;
    }
    function createSeriesNode(prefix: string, suffix: string, parent: string, clusterId: number, name: string, graphOptions: graphlib.GraphOptions): SeriesNode;
    function getSeriesNodeName(prefix: string, suffix: string, parent: string, startId?: number, endId?: number): string;
    function build(graphDef: tf.graph.proto.GraphDef, params: BuildParams, tracker: ProgressTracker): Promise<SlimGraph | void>;
    /**
     * Create a new graphlib.Graph() instance with default parameters
     */
    function createGraph<N, E>(name: string, type: any, opt?: graphlib.GraphOptions): graphlib.Graph<N, E>;
    /**
     * Returns a strict node name (name => name/(name)) to avoid conflicts
     * where the node name is also a namespace.
     */
    function getStrictName(name: string): string;
    /**
     * Returns if the degree sequence of the two graphs is the same.
     */
    function hasSimilarDegreeSequence(graph1: graphlib.Graph<any, any>, graph2: graphlib.Graph<any, any>): boolean;
    /**
     * Returns the hierarchical path of the current node, based on the node's name.
     * For example, if the name is 'a/b/c', the returned path is
     * ['a', 'a/b', 'a/b/c'].
     */
    function getHierarchicalPath(name: string, seriesNames?: {
        [name: string]: string;
    }): string[];
    /**
     * Returns the string for the node inclusion toggle button, dependant
     * on the provided current InclusionType.
     */
    function getIncludeNodeButtonString(include: InclusionType): "Add to main graph" | "Remove from main graph";
    /**
     * Returns the string for the series node grouping toggle button, dependant
     * on the provided current SeriesGroupingType.
     */
    function getGroupSeriesNodeButtonString(group: SeriesGroupingType): "Ungroup this series of nodes" | "Group this series of nodes";
    /**
     * Toggle the node series grouping option in the provided map, setting it
     * to ungroup if the series is not already in the map.
     */
    function toggleNodeSeriesGroup(map: {
        [name: string]: tf.graph.SeriesGroupingType;
    }, name: string): void;
}
