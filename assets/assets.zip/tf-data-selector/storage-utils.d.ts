declare namespace tf_data_selector {
    function decodeIdArray(str: string): Array<number>;
    function encodeIdArray(arr: Array<number>): string;
    function encodeId(id: number): string;
    const NO_EXPERIMENT_ID: any;
    const STORAGE_ALL_VALUE = "$all";
    const STORAGE_NONE_VALUE = "$none";
    const getIdInitializer: (key: string, options: tf_storage.AutoStorageOptions<number[]>) => Function, getIdObserver: (key: string, options: tf_storage.AutoStorageOptions<number[]>) => Function, setId: (key: string, value: number[], option?: tf_storage.SetterOptions<number[]>) => void;
}
