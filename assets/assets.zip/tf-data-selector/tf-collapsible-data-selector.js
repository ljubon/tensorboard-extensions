/* Copyright 2018 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the 'License');
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an 'AS IS' BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
var tf_data_selector;
(function (tf_data_selector) {
    var Mode;
    (function (Mode) {
        Mode[Mode["SIMPLE"] = 0] = "SIMPLE";
        Mode[Mode["ADVANCED"] = 1] = "ADVANCED";
    })(Mode || (Mode = {}));
    Polymer({
        is: 'tf-collapsible-data-selector',
        properties: {
            _simpleSelection: {
                type: Object,
                value: function () { return ({}); },
            },
            _advancedSelection: {
                type: Object,
                value: function () { return ({}); },
            },
            selection: {
                type: Object,
                computed: '_computeSelection(_simpleSelection, _advancedSelection, _mode)',
                notify: true,
            },
            activePlugins: Array,
            opened: {
                type: Boolean,
                reflectToAttribute: true,
                value: true,
            },
            _mode: {
                type: Number,
                value: Mode.SIMPLE,
            },
        },
        _computeSelection: function () {
            if (this._mode == Mode.SIMPLE)
                return this._simpleSelection;
            return this._advancedSelection;
        },
        _toggleOpened: function () {
            this.opened = !this.opened;
        },
        _getExperimentStyle: function (experiment) {
            if (!experiment)
                return '';
            var color = tf_color_scale.experimentsColorScale(experiment.name);
            return "background-color: " + color + ";";
        },
        _isSimpleMode: function (mode) {
            return mode == Mode.SIMPLE;
        },
        _toggleMode: function () {
            var curMode = this._mode;
            var nextMode = curMode == Mode.SIMPLE ? Mode.ADVANCED : Mode.SIMPLE;
            this._mode = nextMode;
        },
    });
})(tf_data_selector || (tf_data_selector = {})); // namespace tf_data_selector
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGYtY29sbGFwc2libGUtZGF0YS1zZWxlY3Rvci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbInRmLWNvbGxhcHNpYmxlLWRhdGEtc2VsZWN0b3IudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7Ozs7Ozs7Z0ZBYWdGO0FBQ2hGLElBQVUsZ0JBQWdCLENBb0V6QjtBQXBFRCxXQUFVLGdCQUFnQjtJQUUxQixJQUFLLElBR0o7SUFIRCxXQUFLLElBQUk7UUFDUCxtQ0FBTSxDQUFBO1FBQ04sdUNBQVEsQ0FBQTtJQUNWLENBQUMsRUFISSxJQUFJLEtBQUosSUFBSSxRQUdSO0lBRUQsT0FBTyxDQUFDO1FBQ04sRUFBRSxFQUFFLDhCQUE4QjtRQUNsQyxVQUFVLEVBQUU7WUFDVixnQkFBZ0IsRUFBRTtnQkFDaEIsSUFBSSxFQUFFLE1BQU07Z0JBQ1osS0FBSyxFQUFFLGNBQU0sT0FBQSxDQUFDLEVBQUUsQ0FBQyxFQUFKLENBQUk7YUFDbEI7WUFFRCxrQkFBa0IsRUFBRTtnQkFDbEIsSUFBSSxFQUFFLE1BQU07Z0JBQ1osS0FBSyxFQUFFLGNBQU0sT0FBQSxDQUFDLEVBQUUsQ0FBQyxFQUFKLENBQUk7YUFDbEI7WUFFRCxTQUFTLEVBQUU7Z0JBQ1QsSUFBSSxFQUFFLE1BQU07Z0JBQ1osUUFBUSxFQUFFLGdFQUFnRTtnQkFDMUUsTUFBTSxFQUFFLElBQUk7YUFDYjtZQUVELGFBQWEsRUFBRSxLQUFLO1lBRXBCLE1BQU0sRUFBRTtnQkFDTixJQUFJLEVBQUUsT0FBTztnQkFDYixrQkFBa0IsRUFBRSxJQUFJO2dCQUN4QixLQUFLLEVBQUUsSUFBSTthQUNaO1lBRUQsS0FBSyxFQUFFO2dCQUNMLElBQUksRUFBRSxNQUFNO2dCQUNaLEtBQUssRUFBRSxJQUFJLENBQUMsTUFBTTthQUNuQjtTQUNGO1FBRUQsaUJBQWlCO1lBQ2YsSUFBSSxJQUFJLENBQUMsS0FBSyxJQUFJLElBQUksQ0FBQyxNQUFNO2dCQUFFLE9BQU8sSUFBSSxDQUFDLGdCQUFnQixDQUFDO1lBQzVELE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDO1FBQ2pDLENBQUM7UUFFRCxhQUFhO1lBQ1gsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUM7UUFDN0IsQ0FBQztRQUVELG1CQUFtQixZQUFDLFVBQVU7WUFDNUIsSUFBSSxDQUFDLFVBQVU7Z0JBQUUsT0FBTyxFQUFFLENBQUM7WUFFM0IsSUFBTSxLQUFLLEdBQUcsY0FBYyxDQUFDLHFCQUFxQixDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUNwRSxPQUFPLHVCQUFxQixLQUFLLE1BQUcsQ0FBQztRQUN2QyxDQUFDO1FBRUQsYUFBYSxZQUFDLElBQUk7WUFDaEIsT0FBTyxJQUFJLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQztRQUM3QixDQUFDO1FBRUQsV0FBVztZQUNULElBQU0sT0FBTyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7WUFDM0IsSUFBTSxRQUFRLEdBQUcsT0FBTyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUM7WUFDdEUsSUFBSSxDQUFDLEtBQUssR0FBRyxRQUFRLENBQUM7UUFDeEIsQ0FBQztLQUVGLENBQUMsQ0FBQztBQUVILENBQUMsRUFwRVMsZ0JBQWdCLEtBQWhCLGdCQUFnQixRQW9FekIsQ0FBRSw2QkFBNkIiLCJzb3VyY2VzQ29udGVudCI6WyIvKiBDb3B5cmlnaHQgMjAxOCBUaGUgVGVuc29yRmxvdyBBdXRob3JzLiBBbGwgUmlnaHRzIFJlc2VydmVkLlxuXG5MaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UsIFZlcnNpb24gMi4wICh0aGUgJ0xpY2Vuc2UnKTtcbnlvdSBtYXkgbm90IHVzZSB0aGlzIGZpbGUgZXhjZXB0IGluIGNvbXBsaWFuY2Ugd2l0aCB0aGUgTGljZW5zZS5cbllvdSBtYXkgb2J0YWluIGEgY29weSBvZiB0aGUgTGljZW5zZSBhdFxuXG4gICAgaHR0cDovL3d3dy5hcGFjaGUub3JnL2xpY2Vuc2VzL0xJQ0VOU0UtMi4wXG5cblVubGVzcyByZXF1aXJlZCBieSBhcHBsaWNhYmxlIGxhdyBvciBhZ3JlZWQgdG8gaW4gd3JpdGluZywgc29mdHdhcmVcbmRpc3RyaWJ1dGVkIHVuZGVyIHRoZSBMaWNlbnNlIGlzIGRpc3RyaWJ1dGVkIG9uIGFuICdBUyBJUycgQkFTSVMsXG5XSVRIT1VUIFdBUlJBTlRJRVMgT1IgQ09ORElUSU9OUyBPRiBBTlkgS0lORCwgZWl0aGVyIGV4cHJlc3Mgb3IgaW1wbGllZC5cblNlZSB0aGUgTGljZW5zZSBmb3IgdGhlIHNwZWNpZmljIGxhbmd1YWdlIGdvdmVybmluZyBwZXJtaXNzaW9ucyBhbmRcbmxpbWl0YXRpb25zIHVuZGVyIHRoZSBMaWNlbnNlLlxuPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09Ki9cbm5hbWVzcGFjZSB0Zl9kYXRhX3NlbGVjdG9yIHtcblxuZW51bSBNb2RlIHtcbiAgU0lNUExFLFxuICBBRFZBTkNFRCxcbn1cblxuUG9seW1lcih7XG4gIGlzOiAndGYtY29sbGFwc2libGUtZGF0YS1zZWxlY3RvcicsXG4gIHByb3BlcnRpZXM6IHtcbiAgICBfc2ltcGxlU2VsZWN0aW9uOiB7XG4gICAgICB0eXBlOiBPYmplY3QsXG4gICAgICB2YWx1ZTogKCkgPT4gKHt9KSxcbiAgICB9LFxuXG4gICAgX2FkdmFuY2VkU2VsZWN0aW9uOiB7XG4gICAgICB0eXBlOiBPYmplY3QsXG4gICAgICB2YWx1ZTogKCkgPT4gKHt9KSxcbiAgICB9LFxuXG4gICAgc2VsZWN0aW9uOiB7XG4gICAgICB0eXBlOiBPYmplY3QsXG4gICAgICBjb21wdXRlZDogJ19jb21wdXRlU2VsZWN0aW9uKF9zaW1wbGVTZWxlY3Rpb24sIF9hZHZhbmNlZFNlbGVjdGlvbiwgX21vZGUpJyxcbiAgICAgIG5vdGlmeTogdHJ1ZSxcbiAgICB9LFxuXG4gICAgYWN0aXZlUGx1Z2luczogQXJyYXksXG5cbiAgICBvcGVuZWQ6IHtcbiAgICAgIHR5cGU6IEJvb2xlYW4sXG4gICAgICByZWZsZWN0VG9BdHRyaWJ1dGU6IHRydWUsXG4gICAgICB2YWx1ZTogdHJ1ZSxcbiAgICB9LFxuXG4gICAgX21vZGU6IHtcbiAgICAgIHR5cGU6IE51bWJlcixcbiAgICAgIHZhbHVlOiBNb2RlLlNJTVBMRSxcbiAgICB9LFxuICB9LFxuXG4gIF9jb21wdXRlU2VsZWN0aW9uKCkge1xuICAgIGlmICh0aGlzLl9tb2RlID09IE1vZGUuU0lNUExFKSByZXR1cm4gdGhpcy5fc2ltcGxlU2VsZWN0aW9uO1xuICAgIHJldHVybiB0aGlzLl9hZHZhbmNlZFNlbGVjdGlvbjtcbiAgfSxcblxuICBfdG9nZ2xlT3BlbmVkKCkge1xuICAgIHRoaXMub3BlbmVkID0gIXRoaXMub3BlbmVkO1xuICB9LFxuXG4gIF9nZXRFeHBlcmltZW50U3R5bGUoZXhwZXJpbWVudCkge1xuICAgIGlmICghZXhwZXJpbWVudCkgcmV0dXJuICcnO1xuXG4gICAgY29uc3QgY29sb3IgPSB0Zl9jb2xvcl9zY2FsZS5leHBlcmltZW50c0NvbG9yU2NhbGUoZXhwZXJpbWVudC5uYW1lKTtcbiAgICByZXR1cm4gYGJhY2tncm91bmQtY29sb3I6ICR7Y29sb3J9O2A7XG4gIH0sXG5cbiAgX2lzU2ltcGxlTW9kZShtb2RlKSB7XG4gICAgcmV0dXJuIG1vZGUgPT0gTW9kZS5TSU1QTEU7XG4gIH0sXG5cbiAgX3RvZ2dsZU1vZGUoKSB7XG4gICAgY29uc3QgY3VyTW9kZSA9IHRoaXMuX21vZGU7XG4gICAgY29uc3QgbmV4dE1vZGUgPSBjdXJNb2RlID09IE1vZGUuU0lNUExFID8gTW9kZS5BRFZBTkNFRCA6IE1vZGUuU0lNUExFO1xuICAgIHRoaXMuX21vZGUgPSBuZXh0TW9kZTtcbiAgfSxcblxufSk7XG5cbn0gIC8vIG5hbWVzcGFjZSB0Zl9kYXRhX3NlbGVjdG9yXG4iXX0=