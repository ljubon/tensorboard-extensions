/* Copyright 2015 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
var vz_chart_helpers;
(function (vz_chart_helpers) {
    /**
     * A list of symbols that line charts can cycle through per data series.
     */
    vz_chart_helpers.SYMBOLS_LIST = [
        {
            character: '\u25FC',
            method: Plottable.SymbolFactories.square,
        },
        {
            character: '\u25c6',
            method: Plottable.SymbolFactories.diamond,
        },
        {
            character: '\u25B2',
            method: Plottable.SymbolFactories.triangle,
        },
        {
            character: '\u2605',
            method: Plottable.SymbolFactories.star,
        },
        {
            character: '\u271a',
            method: Plottable.SymbolFactories.cross,
        },
    ];
    /** X axis choices for TensorBoard charts. */
    var XType;
    (function (XType) {
        /** Linear scale using the "step" property of the datum. */
        XType["STEP"] = "step";
        /** Temporal scale using the "wall_time" property of the datum. */
        XType["RELATIVE"] = "relative";
        /**
         * Temporal scale using the "relative" property of the datum if it is present
         * or calculating from "wall_time" if it isn't.
         */
        XType["WALL_TIME"] = "wall_time";
    })(XType = vz_chart_helpers.XType || (vz_chart_helpers.XType = {}));
    vz_chart_helpers.Y_TOOLTIP_FORMATTER_PRECISION = 4;
    vz_chart_helpers.STEP_FORMATTER_PRECISION = 4;
    vz_chart_helpers.Y_AXIS_FORMATTER_PRECISION = 3;
    vz_chart_helpers.TOOLTIP_Y_PIXEL_OFFSET = 20;
    vz_chart_helpers.TOOLTIP_CIRCLE_SIZE = 4;
    vz_chart_helpers.NAN_SYMBOL_SIZE = 6;
    /* Create a formatter function that will switch between exponential and
     * regular display depending on the scale of the number being formatted,
     * and show `digits` significant digits.
     */
    function multiscaleFormatter(digits) {
        return function (v) {
            var absv = Math.abs(v);
            if (absv < 1E-15) {
                // Sometimes zero-like values get an annoying representation
                absv = 0;
            }
            var f;
            if (absv >= 1E4) {
                f = d3.format('.' + digits + 'e');
            }
            else if (absv > 0 && absv < 0.01) {
                f = d3.format('.' + digits + 'e');
            }
            else {
                f = d3.format('.' + digits + 'g');
            }
            return f(v);
        };
    }
    vz_chart_helpers.multiscaleFormatter = multiscaleFormatter;
    /* Compute an appropriate domain given an array of all the values that are
     * going to be displayed. If ignoreOutliers is true, it will ignore the
     * lowest 10% and highest 10% of the data when computing a domain.
     * It has n log n performance when ignoreOutliers is true, as it needs to
     * sort the data.
     */
    function computeDomain(values, ignoreOutliers) {
        // Don't include infinities and NaNs in the domain computation.
        values = values.filter(function (z) { return isFinite(z); });
        if (values.length === 0) {
            return [-0.1, 1.1];
        }
        var a;
        var b;
        if (ignoreOutliers) {
            var sorted = _.sortBy(values);
            a = d3.quantile(sorted, 0.05);
            b = d3.quantile(sorted, 0.95);
        }
        else {
            a = d3.min(values);
            b = d3.max(values);
        }
        var padding;
        var span = b - a;
        if (span === 0) {
            // If b===a, we would create an empty range. We instead select the range
            // [0, 2*a] if a > 0, or [-2*a, 0] if a < 0, plus a little bit of
            // extra padding on the top and bottom of the plot.
            padding = Math.abs(a) * 1.1 + 1.1;
        }
        else {
            padding = span * 0.2;
        }
        var lower;
        if (a >= 0 && a < span) {
            // We include the intercept (y = 0) if doing so less than doubles the span
            // of the y-axis. (We actually select a lower bound that's slightly less
            // than 0 so that 0.00 will clearly be written on the lower edge of the
            // chart. The label on the lowest tick is often filtered out.)
            lower = -0.1 * b;
        }
        else {
            lower = a - padding;
        }
        var domain = [lower, b + padding];
        domain = d3.scaleLinear().domain(domain).nice().domain();
        return domain;
    }
    vz_chart_helpers.computeDomain = computeDomain;
    function accessorize(key) {
        // tslint:disable-next-line:no-any be quiet tsc
        return function (d, index, dataset) { return d[key]; };
    }
    vz_chart_helpers.accessorize = accessorize;
    vz_chart_helpers.stepFormatter = Plottable.Formatters.siSuffix(vz_chart_helpers.STEP_FORMATTER_PRECISION);
    function stepX() {
        var scale = new Plottable.Scales.Linear();
        scale.tickGenerator(Plottable.Scales.TickGenerators.integerTickGenerator());
        var axis = new Plottable.Axes.Numeric(scale, 'bottom');
        axis.formatter(vz_chart_helpers.stepFormatter);
        return {
            scale: scale,
            axis: axis,
            accessor: function (d) { return d.step; },
        };
    }
    vz_chart_helpers.stepX = stepX;
    vz_chart_helpers.timeFormatter = Plottable.Formatters.time('%a %b %e, %H:%M:%S');
    function wallX() {
        var scale = new Plottable.Scales.Time();
        return {
            scale: scale,
            axis: new Plottable.Axes.Time(scale, 'bottom'),
            accessor: function (d) { return d.wall_time; },
        };
    }
    vz_chart_helpers.wallX = wallX;
    vz_chart_helpers.relativeAccessor = 
    // tslint:disable-next-line:no-any be quiet tsc
    function (d, index, dataset) {
        // We may be rendering the final-point datum for scatterplot.
        // If so, we will have already provided the 'relative' property
        if (d.relative != null) {
            return d.relative;
        }
        var data = dataset.data();
        // I can't imagine how this function would be called when the data is
        // empty (after all, it iterates over the data), but lets guard just
        // to be safe.
        var first = data.length > 0 ? +data[0].wall_time : 0;
        return (+d.wall_time - first) / (60 * 60 * 1000); // ms to hours
    };
    vz_chart_helpers.relativeFormatter = function (n) {
        // we will always show 2 units of precision, e.g days and hours, or
        // minutes and seconds, but not hours and minutes and seconds
        var ret = '';
        var days = Math.floor(n / 24);
        n -= (days * 24);
        if (days) {
            ret += days + 'd ';
        }
        var hours = Math.floor(n);
        n -= hours;
        n *= 60;
        if (hours || days) {
            ret += hours + 'h ';
        }
        var minutes = Math.floor(n);
        n -= minutes;
        n *= 60;
        if (minutes || hours || days) {
            ret += minutes + 'm ';
        }
        var seconds = Math.floor(n);
        return ret + seconds + 's';
    };
    function relativeX() {
        var scale = new Plottable.Scales.Linear();
        return {
            scale: scale,
            axis: new Plottable.Axes.Numeric(scale, 'bottom'),
            accessor: vz_chart_helpers.relativeAccessor,
        };
    }
    vz_chart_helpers.relativeX = relativeX;
    function getXComponents(xType) {
        switch (xType) {
            case XType.STEP:
                return stepX();
            case XType.WALL_TIME:
                return wallX();
            case XType.RELATIVE:
                return relativeX();
            default:
                throw new Error('invalid xType: ' + xType);
        }
    }
    vz_chart_helpers.getXComponents = getXComponents;
})(vz_chart_helpers || (vz_chart_helpers = {})); // namespace vz_chart_helpers
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidnotY2hhcnQtaGVscGVycy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbInZ6LWNoYXJ0LWhlbHBlcnMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7Ozs7Ozs7Z0ZBYWdGO0FBQ2hGLElBQVUsZ0JBQWdCLENBMFF6QjtBQTFRRCxXQUFVLGdCQUFnQjtJQXdCMUI7O09BRUc7SUFDVSw2QkFBWSxHQUFzQjtRQUM3QztZQUNFLFNBQVMsRUFBRSxRQUFRO1lBQ25CLE1BQU0sRUFBRSxTQUFTLENBQUMsZUFBZSxDQUFDLE1BQU07U0FDekM7UUFDRDtZQUNFLFNBQVMsRUFBRSxRQUFRO1lBQ25CLE1BQU0sRUFBRSxTQUFTLENBQUMsZUFBZSxDQUFDLE9BQU87U0FDMUM7UUFDRDtZQUNFLFNBQVMsRUFBRSxRQUFRO1lBQ25CLE1BQU0sRUFBRSxTQUFTLENBQUMsZUFBZSxDQUFDLFFBQVE7U0FDM0M7UUFDRDtZQUNFLFNBQVMsRUFBRSxRQUFRO1lBQ25CLE1BQU0sRUFBRSxTQUFTLENBQUMsZUFBZSxDQUFDLElBQUk7U0FDdkM7UUFDRDtZQUNFLFNBQVMsRUFBRSxRQUFRO1lBQ25CLE1BQU0sRUFBRSxTQUFTLENBQUMsZUFBZSxDQUFDLEtBQUs7U0FDeEM7S0FDRixDQUFDO0lBRUYsNkNBQTZDO0lBQzdDLElBQVksS0FhWDtJQWJELFdBQVksS0FBSztRQUVmLDJEQUEyRDtRQUMzRCxzQkFBYSxDQUFBO1FBRWIsa0VBQWtFO1FBQ2xFLDhCQUFxQixDQUFBO1FBRXJCOzs7V0FHRztRQUNILGdDQUF1QixDQUFBO0lBQ3pCLENBQUMsRUFiVyxLQUFLLEdBQUwsc0JBQUssS0FBTCxzQkFBSyxRQWFoQjtJQUlVLDhDQUE2QixHQUFHLENBQUMsQ0FBQztJQUNsQyx5Q0FBd0IsR0FBRyxDQUFDLENBQUM7SUFDN0IsMkNBQTBCLEdBQUcsQ0FBQyxDQUFDO0lBQy9CLHVDQUFzQixHQUFHLEVBQUUsQ0FBQztJQUM1QixvQ0FBbUIsR0FBRyxDQUFDLENBQUM7SUFDeEIsZ0NBQWUsR0FBRyxDQUFDLENBQUM7SUFtQi9COzs7T0FHRztJQUNILDZCQUFvQyxNQUFjO1FBQ2hELE9BQU8sVUFBQyxDQUFTO1lBQ2YsSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUN2QixJQUFJLElBQUksR0FBRyxLQUFLLEVBQUU7Z0JBQ2hCLDREQUE0RDtnQkFDNUQsSUFBSSxHQUFHLENBQUMsQ0FBQzthQUNWO1lBQ0QsSUFBSSxDQUF3QixDQUFDO1lBQzdCLElBQUksSUFBSSxJQUFJLEdBQUcsRUFBRTtnQkFDZixDQUFDLEdBQUcsRUFBRSxDQUFDLE1BQU0sQ0FBQyxHQUFHLEdBQUcsTUFBTSxHQUFHLEdBQUcsQ0FBQyxDQUFDO2FBQ25DO2lCQUFNLElBQUksSUFBSSxHQUFHLENBQUMsSUFBSSxJQUFJLEdBQUcsSUFBSSxFQUFFO2dCQUNsQyxDQUFDLEdBQUcsRUFBRSxDQUFDLE1BQU0sQ0FBQyxHQUFHLEdBQUcsTUFBTSxHQUFHLEdBQUcsQ0FBQyxDQUFDO2FBQ25DO2lCQUFNO2dCQUNMLENBQUMsR0FBRyxFQUFFLENBQUMsTUFBTSxDQUFDLEdBQUcsR0FBRyxNQUFNLEdBQUcsR0FBRyxDQUFDLENBQUM7YUFDbkM7WUFDRCxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUNkLENBQUMsQ0FBQztJQUNKLENBQUM7SUFqQmUsb0NBQW1CLHNCQWlCbEMsQ0FBQTtJQUVEOzs7OztPQUtHO0lBQ0gsdUJBQThCLE1BQWdCLEVBQUUsY0FBdUI7UUFDckUsK0RBQStEO1FBQy9ELE1BQU0sR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLFVBQUEsQ0FBQyxJQUFJLE9BQUEsUUFBUSxDQUFDLENBQUMsQ0FBQyxFQUFYLENBQVcsQ0FBQyxDQUFDO1FBRXpDLElBQUksTUFBTSxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7WUFDdkIsT0FBTyxDQUFDLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1NBQ3BCO1FBQ0QsSUFBSSxDQUFTLENBQUM7UUFDZCxJQUFJLENBQVMsQ0FBQztRQUNkLElBQUksY0FBYyxFQUFFO1lBQ2xCLElBQUksTUFBTSxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDOUIsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxRQUFRLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxDQUFDO1lBQzlCLENBQUMsR0FBRyxFQUFFLENBQUMsUUFBUSxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsQ0FBQztTQUMvQjthQUFNO1lBQ0wsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDbkIsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUM7U0FDcEI7UUFFRCxJQUFJLE9BQWUsQ0FBQztRQUNwQixJQUFJLElBQUksR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQ2pCLElBQUksSUFBSSxLQUFLLENBQUMsRUFBRTtZQUNkLHdFQUF3RTtZQUN4RSxpRUFBaUU7WUFDakUsbURBQW1EO1lBQ25ELE9BQU8sR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsR0FBRyxHQUFHLENBQUM7U0FDbkM7YUFBTTtZQUNMLE9BQU8sR0FBRyxJQUFJLEdBQUcsR0FBRyxDQUFDO1NBQ3RCO1FBRUQsSUFBSSxLQUFhLENBQUM7UUFDbEIsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxJQUFJLEVBQUU7WUFDdEIsMEVBQTBFO1lBQzFFLHdFQUF3RTtZQUN4RSx1RUFBdUU7WUFDdkUsOERBQThEO1lBQzlELEtBQUssR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUM7U0FDbEI7YUFBTTtZQUNMLEtBQUssR0FBRyxDQUFDLEdBQUcsT0FBTyxDQUFDO1NBQ3JCO1FBR0QsSUFBSSxNQUFNLEdBQUcsQ0FBQyxLQUFLLEVBQUUsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxDQUFDO1FBQ2xDLE1BQU0sR0FBRyxFQUFFLENBQUMsV0FBVyxFQUFFLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBQ3pELE9BQU8sTUFBTSxDQUFDO0lBQ2hCLENBQUM7SUE1Q2UsOEJBQWEsZ0JBNEM1QixDQUFBO0lBRUQscUJBQTRCLEdBQVc7UUFDckMsK0NBQStDO1FBQy9DLE9BQU8sVUFBQyxDQUFNLEVBQUUsS0FBYSxFQUFFLE9BQTBCLElBQUssT0FBQSxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQU4sQ0FBTSxDQUFDO0lBQ3ZFLENBQUM7SUFIZSw0QkFBVyxjQUcxQixDQUFBO0lBVVUsOEJBQWEsR0FDcEIsU0FBUyxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsaUJBQUEsd0JBQXdCLENBQUMsQ0FBQztJQUM1RDtRQUNFLElBQUksS0FBSyxHQUFHLElBQUksU0FBUyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUMxQyxLQUFLLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLG9CQUFvQixFQUFFLENBQUMsQ0FBQztRQUM1RSxJQUFJLElBQUksR0FBRyxJQUFJLFNBQVMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSxRQUFRLENBQUMsQ0FBQztRQUN2RCxJQUFJLENBQUMsU0FBUyxDQUFDLGlCQUFBLGFBQWEsQ0FBQyxDQUFDO1FBQzlCLE9BQU87WUFDTCxLQUFLLEVBQUUsS0FBSztZQUNaLElBQUksRUFBRSxJQUFJO1lBQ1YsUUFBUSxFQUFFLFVBQUMsQ0FBUSxJQUFLLE9BQUEsQ0FBQyxDQUFDLElBQUksRUFBTixDQUFNO1NBQy9CLENBQUM7SUFDSixDQUFDO0lBVmUsc0JBQUssUUFVcEIsQ0FBQTtJQUVVLDhCQUFhLEdBQUcsU0FBUyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsb0JBQW9CLENBQUMsQ0FBQztJQUUzRTtRQUNFLElBQUksS0FBSyxHQUFHLElBQUksU0FBUyxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsQ0FBQztRQUN4QyxPQUFPO1lBQ0wsS0FBSyxFQUFFLEtBQUs7WUFDWixJQUFJLEVBQUUsSUFBSSxTQUFTLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsUUFBUSxDQUFDO1lBQzlDLFFBQVEsRUFBRSxVQUFDLENBQVEsSUFBSyxPQUFBLENBQUMsQ0FBQyxTQUFTLEVBQVgsQ0FBVztTQUNwQyxDQUFDO0lBQ0osQ0FBQztJQVBlLHNCQUFLLFFBT3BCLENBQUE7SUFDVSxpQ0FBZ0I7SUFDdkIsK0NBQStDO0lBQy9DLFVBQUMsQ0FBTSxFQUFFLEtBQWEsRUFBRSxPQUEwQjtRQUNoRCw2REFBNkQ7UUFDN0QsK0RBQStEO1FBQy9ELElBQUksQ0FBQyxDQUFDLFFBQVEsSUFBSSxJQUFJLEVBQUU7WUFDdEIsT0FBTyxDQUFDLENBQUMsUUFBUSxDQUFDO1NBQ25CO1FBQ0QsSUFBSSxJQUFJLEdBQUcsT0FBTyxDQUFDLElBQUksRUFBRSxDQUFDO1FBQzFCLHFFQUFxRTtRQUNyRSxvRUFBb0U7UUFDcEUsY0FBYztRQUNkLElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUNyRCxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxHQUFHLEtBQUssQ0FBQyxHQUFHLENBQUMsRUFBRSxHQUFHLEVBQUUsR0FBRyxJQUFJLENBQUMsQ0FBQyxDQUFFLGNBQWM7SUFDbkUsQ0FBQyxDQUFDO0lBRUssa0NBQWlCLEdBQUcsVUFBQyxDQUFTO1FBQ3ZDLG1FQUFtRTtRQUNuRSw2REFBNkQ7UUFDN0QsSUFBSSxHQUFHLEdBQUcsRUFBRSxDQUFDO1FBQ2IsSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUM7UUFDOUIsQ0FBQyxJQUFJLENBQUMsSUFBSSxHQUFHLEVBQUUsQ0FBQyxDQUFDO1FBQ2pCLElBQUksSUFBSSxFQUFFO1lBQ1IsR0FBRyxJQUFJLElBQUksR0FBRyxJQUFJLENBQUM7U0FDcEI7UUFDRCxJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQzFCLENBQUMsSUFBSSxLQUFLLENBQUM7UUFDWCxDQUFDLElBQUksRUFBRSxDQUFDO1FBQ1IsSUFBSSxLQUFLLElBQUksSUFBSSxFQUFFO1lBQ2pCLEdBQUcsSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDO1NBQ3JCO1FBQ0QsSUFBSSxPQUFPLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUM1QixDQUFDLElBQUksT0FBTyxDQUFDO1FBQ2IsQ0FBQyxJQUFJLEVBQUUsQ0FBQztRQUNSLElBQUksT0FBTyxJQUFJLEtBQUssSUFBSSxJQUFJLEVBQUU7WUFDNUIsR0FBRyxJQUFJLE9BQU8sR0FBRyxJQUFJLENBQUM7U0FDdkI7UUFDRCxJQUFJLE9BQU8sR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQzVCLE9BQU8sR0FBRyxHQUFHLE9BQU8sR0FBRyxHQUFHLENBQUM7SUFDN0IsQ0FBQyxDQUFDO0lBQ0Y7UUFDRSxJQUFJLEtBQUssR0FBRyxJQUFJLFNBQVMsQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDMUMsT0FBTztZQUNMLEtBQUssRUFBRSxLQUFLO1lBQ1osSUFBSSxFQUFFLElBQUksU0FBUyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLFFBQVEsQ0FBQztZQUNqRCxRQUFRLEVBQUUsaUJBQUEsZ0JBQWdCO1NBQzNCLENBQUM7SUFDSixDQUFDO0lBUGUsMEJBQVMsWUFPeEIsQ0FBQTtJQUVELHdCQUErQixLQUFhO1FBQzFDLFFBQVEsS0FBSyxFQUFFO1lBQ2IsS0FBSyxLQUFLLENBQUMsSUFBSTtnQkFDYixPQUFPLEtBQUssRUFBRSxDQUFDO1lBQ2pCLEtBQUssS0FBSyxDQUFDLFNBQVM7Z0JBQ2xCLE9BQU8sS0FBSyxFQUFFLENBQUM7WUFDakIsS0FBSyxLQUFLLENBQUMsUUFBUTtnQkFDakIsT0FBTyxTQUFTLEVBQUUsQ0FBQztZQUNyQjtnQkFDRSxNQUFNLElBQUksS0FBSyxDQUFDLGlCQUFpQixHQUFHLEtBQUssQ0FBQyxDQUFDO1NBQzlDO0lBQ0gsQ0FBQztJQVhlLCtCQUFjLGlCQVc3QixDQUFBO0FBRUQsQ0FBQyxFQTFRUyxnQkFBZ0IsS0FBaEIsZ0JBQWdCLFFBMFF6QixDQUFFLDZCQUE2QiIsInNvdXJjZXNDb250ZW50IjpbIi8qIENvcHlyaWdodCAyMDE1IFRoZSBUZW5zb3JGbG93IEF1dGhvcnMuIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG5cbkxpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSBcIkxpY2Vuc2VcIik7XG55b3UgbWF5IG5vdCB1c2UgdGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlIHdpdGggdGhlIExpY2Vuc2UuXG5Zb3UgbWF5IG9idGFpbiBhIGNvcHkgb2YgdGhlIExpY2Vuc2UgYXRcblxuICAgIGh0dHA6Ly93d3cuYXBhY2hlLm9yZy9saWNlbnNlcy9MSUNFTlNFLTIuMFxuXG5Vbmxlc3MgcmVxdWlyZWQgYnkgYXBwbGljYWJsZSBsYXcgb3IgYWdyZWVkIHRvIGluIHdyaXRpbmcsIHNvZnR3YXJlXG5kaXN0cmlidXRlZCB1bmRlciB0aGUgTGljZW5zZSBpcyBkaXN0cmlidXRlZCBvbiBhbiBcIkFTIElTXCIgQkFTSVMsXG5XSVRIT1VUIFdBUlJBTlRJRVMgT1IgQ09ORElUSU9OUyBPRiBBTlkgS0lORCwgZWl0aGVyIGV4cHJlc3Mgb3IgaW1wbGllZC5cblNlZSB0aGUgTGljZW5zZSBmb3IgdGhlIHNwZWNpZmljIGxhbmd1YWdlIGdvdmVybmluZyBwZXJtaXNzaW9ucyBhbmRcbmxpbWl0YXRpb25zIHVuZGVyIHRoZSBMaWNlbnNlLlxuPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09Ki9cbm5hbWVzcGFjZSB2el9jaGFydF9oZWxwZXJzIHtcblxuZXhwb3J0IGludGVyZmFjZSBEYXR1bSB7XG4gIHdhbGxfdGltZTogRGF0ZTtcbiAgc3RlcDogbnVtYmVyO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIFNjYWxhciB7XG4gIHNjYWxhcjogbnVtYmVyO1xuICBzbW9vdGhlZDogbnVtYmVyO1xufVxuXG5leHBvcnQgdHlwZSBTY2FsYXJEYXR1bSA9IERhdHVtICYgU2NhbGFyO1xuXG5leHBvcnQgdHlwZSBEYXRhRm4gPSAocnVuOiBzdHJpbmcsIHRhZzogc3RyaW5nKSA9PiBQcm9taXNlPEFycmF5PERhdHVtPj47XG5cbmV4cG9ydCBpbnRlcmZhY2UgTGluZUNoYXJ0U3ltYm9sIHtcbiAgLy8gQSBzaW5nbGUgdW5pY29kZSBjaGFyYWN0ZXIgc3RyaW5nIHJlcHJlc2VudGluZyB0aGUgc3ltYm9sLiBNYXliZSBhIGRpYW1vbmRcbiAgLy8gdW5pY29kZSBjaGFyYWN0ZXIgZm9yIGluc3RhbmNlLlxuICBjaGFyYWN0ZXI6IHN0cmluZztcbiAgLy8gQSBzcGVjaWFsIG1ldGhvZCB1c2VkIGJ5IFBsb3R0YWJsZSB0byBkcmF3IHRoZSBzeW1ib2wgaW4gdGhlIGxpbmUgY2hhcnQuXG4gIG1ldGhvZDogKCgpID0+IFBsb3R0YWJsZS5TeW1ib2xGYWN0b3JpZXMuU3ltYm9sRmFjdG9yeSk7XG59XG5cbi8qKlxuICogQSBsaXN0IG9mIHN5bWJvbHMgdGhhdCBsaW5lIGNoYXJ0cyBjYW4gY3ljbGUgdGhyb3VnaCBwZXIgZGF0YSBzZXJpZXMuXG4gKi9cbmV4cG9ydCBjb25zdCBTWU1CT0xTX0xJU1Q6IExpbmVDaGFydFN5bWJvbFtdID0gW1xuICB7XG4gICAgY2hhcmFjdGVyOiAnXFx1MjVGQycsXG4gICAgbWV0aG9kOiBQbG90dGFibGUuU3ltYm9sRmFjdG9yaWVzLnNxdWFyZSxcbiAgfSxcbiAge1xuICAgIGNoYXJhY3RlcjogJ1xcdTI1YzYnLFxuICAgIG1ldGhvZDogUGxvdHRhYmxlLlN5bWJvbEZhY3Rvcmllcy5kaWFtb25kLFxuICB9LFxuICB7XG4gICAgY2hhcmFjdGVyOiAnXFx1MjVCMicsXG4gICAgbWV0aG9kOiBQbG90dGFibGUuU3ltYm9sRmFjdG9yaWVzLnRyaWFuZ2xlLFxuICB9LFxuICB7XG4gICAgY2hhcmFjdGVyOiAnXFx1MjYwNScsXG4gICAgbWV0aG9kOiBQbG90dGFibGUuU3ltYm9sRmFjdG9yaWVzLnN0YXIsXG4gIH0sXG4gIHtcbiAgICBjaGFyYWN0ZXI6ICdcXHUyNzFhJyxcbiAgICBtZXRob2Q6IFBsb3R0YWJsZS5TeW1ib2xGYWN0b3JpZXMuY3Jvc3MsXG4gIH0sXG5dO1xuXG4vKiogWCBheGlzIGNob2ljZXMgZm9yIFRlbnNvckJvYXJkIGNoYXJ0cy4gKi9cbmV4cG9ydCBlbnVtIFhUeXBlIHtcblxuICAvKiogTGluZWFyIHNjYWxlIHVzaW5nIHRoZSBcInN0ZXBcIiBwcm9wZXJ0eSBvZiB0aGUgZGF0dW0uICovXG4gIFNURVAgPSAnc3RlcCcsXG5cbiAgLyoqIFRlbXBvcmFsIHNjYWxlIHVzaW5nIHRoZSBcIndhbGxfdGltZVwiIHByb3BlcnR5IG9mIHRoZSBkYXR1bS4gKi9cbiAgUkVMQVRJVkUgPSAncmVsYXRpdmUnLFxuXG4gIC8qKlxuICAgKiBUZW1wb3JhbCBzY2FsZSB1c2luZyB0aGUgXCJyZWxhdGl2ZVwiIHByb3BlcnR5IG9mIHRoZSBkYXR1bSBpZiBpdCBpcyBwcmVzZW50XG4gICAqIG9yIGNhbGN1bGF0aW5nIGZyb20gXCJ3YWxsX3RpbWVcIiBpZiBpdCBpc24ndC5cbiAgICovXG4gIFdBTExfVElNRSA9ICd3YWxsX3RpbWUnLFxufVxuXG5leHBvcnQgdHlwZSBTeW1ib2xGbiA9IChzZXJpZXM6IHN0cmluZykgPT4gUGxvdHRhYmxlLlN5bWJvbEZhY3Rvcnk7XG5cbmV4cG9ydCBsZXQgWV9UT09MVElQX0ZPUk1BVFRFUl9QUkVDSVNJT04gPSA0O1xuZXhwb3J0IGxldCBTVEVQX0ZPUk1BVFRFUl9QUkVDSVNJT04gPSA0O1xuZXhwb3J0IGxldCBZX0FYSVNfRk9STUFUVEVSX1BSRUNJU0lPTiA9IDM7XG5leHBvcnQgbGV0IFRPT0xUSVBfWV9QSVhFTF9PRkZTRVQgPSAyMDtcbmV4cG9ydCBsZXQgVE9PTFRJUF9DSVJDTEVfU0laRSA9IDQ7XG5leHBvcnQgbGV0IE5BTl9TWU1CT0xfU0laRSA9IDY7XG5cbmV4cG9ydCBpbnRlcmZhY2UgUG9pbnQge1xuICB4OiBudW1iZXI7ICAvLyBwaXhlbCBzcGFjZVxuICB5OiBudW1iZXI7ICAvLyBwaXhlbCBzcGFjZVxuICBkYXR1bTogU2NhbGFyRGF0dW07XG4gIGRhdGFzZXQ6IFBsb3R0YWJsZS5EYXRhc2V0O1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIFRvb2x0aXBDb2x1bW5TdGF0ZSB7XG4gIHNtb290aGluZ0VuYWJsZWQ6IGJvb2xlYW47XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgVG9vbHRpcENvbHVtbiB7XG4gIHRpdGxlOiBzdHJpbmc7XG4gIHN0YXRpYzogYm9vbGVhbjtcbiAgZXZhbHVhdGU6ICgocDogUG9pbnQsIHN0YXR1cz86IFRvb2x0aXBDb2x1bW5TdGF0ZSkgPT4gc3RyaW5nKTtcbn1cblxuLyogQ3JlYXRlIGEgZm9ybWF0dGVyIGZ1bmN0aW9uIHRoYXQgd2lsbCBzd2l0Y2ggYmV0d2VlbiBleHBvbmVudGlhbCBhbmRcbiAqIHJlZ3VsYXIgZGlzcGxheSBkZXBlbmRpbmcgb24gdGhlIHNjYWxlIG9mIHRoZSBudW1iZXIgYmVpbmcgZm9ybWF0dGVkLFxuICogYW5kIHNob3cgYGRpZ2l0c2Agc2lnbmlmaWNhbnQgZGlnaXRzLlxuICovXG5leHBvcnQgZnVuY3Rpb24gbXVsdGlzY2FsZUZvcm1hdHRlcihkaWdpdHM6IG51bWJlcik6ICgodjogbnVtYmVyKSA9PiBzdHJpbmcpIHtcbiAgcmV0dXJuICh2OiBudW1iZXIpID0+IHtcbiAgICBsZXQgYWJzdiA9IE1hdGguYWJzKHYpO1xuICAgIGlmIChhYnN2IDwgMUUtMTUpIHtcbiAgICAgIC8vIFNvbWV0aW1lcyB6ZXJvLWxpa2UgdmFsdWVzIGdldCBhbiBhbm5veWluZyByZXByZXNlbnRhdGlvblxuICAgICAgYWJzdiA9IDA7XG4gICAgfVxuICAgIGxldCBmOiAoeDogbnVtYmVyKSA9PiBzdHJpbmc7XG4gICAgaWYgKGFic3YgPj0gMUU0KSB7XG4gICAgICBmID0gZDMuZm9ybWF0KCcuJyArIGRpZ2l0cyArICdlJyk7XG4gICAgfSBlbHNlIGlmIChhYnN2ID4gMCAmJiBhYnN2IDwgMC4wMSkge1xuICAgICAgZiA9IGQzLmZvcm1hdCgnLicgKyBkaWdpdHMgKyAnZScpO1xuICAgIH0gZWxzZSB7XG4gICAgICBmID0gZDMuZm9ybWF0KCcuJyArIGRpZ2l0cyArICdnJyk7XG4gICAgfVxuICAgIHJldHVybiBmKHYpO1xuICB9O1xufVxuXG4vKiBDb21wdXRlIGFuIGFwcHJvcHJpYXRlIGRvbWFpbiBnaXZlbiBhbiBhcnJheSBvZiBhbGwgdGhlIHZhbHVlcyB0aGF0IGFyZVxuICogZ29pbmcgdG8gYmUgZGlzcGxheWVkLiBJZiBpZ25vcmVPdXRsaWVycyBpcyB0cnVlLCBpdCB3aWxsIGlnbm9yZSB0aGVcbiAqIGxvd2VzdCAxMCUgYW5kIGhpZ2hlc3QgMTAlIG9mIHRoZSBkYXRhIHdoZW4gY29tcHV0aW5nIGEgZG9tYWluLlxuICogSXQgaGFzIG4gbG9nIG4gcGVyZm9ybWFuY2Ugd2hlbiBpZ25vcmVPdXRsaWVycyBpcyB0cnVlLCBhcyBpdCBuZWVkcyB0b1xuICogc29ydCB0aGUgZGF0YS5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGNvbXB1dGVEb21haW4odmFsdWVzOiBudW1iZXJbXSwgaWdub3JlT3V0bGllcnM6IGJvb2xlYW4pIHtcbiAgLy8gRG9uJ3QgaW5jbHVkZSBpbmZpbml0aWVzIGFuZCBOYU5zIGluIHRoZSBkb21haW4gY29tcHV0YXRpb24uXG4gIHZhbHVlcyA9IHZhbHVlcy5maWx0ZXIoeiA9PiBpc0Zpbml0ZSh6KSk7XG5cbiAgaWYgKHZhbHVlcy5sZW5ndGggPT09IDApIHtcbiAgICByZXR1cm4gWy0wLjEsIDEuMV07XG4gIH1cbiAgbGV0IGE6IG51bWJlcjtcbiAgbGV0IGI6IG51bWJlcjtcbiAgaWYgKGlnbm9yZU91dGxpZXJzKSB7XG4gICAgbGV0IHNvcnRlZCA9IF8uc29ydEJ5KHZhbHVlcyk7XG4gICAgYSA9IGQzLnF1YW50aWxlKHNvcnRlZCwgMC4wNSk7XG4gICAgYiA9IGQzLnF1YW50aWxlKHNvcnRlZCwgMC45NSk7XG4gIH0gZWxzZSB7XG4gICAgYSA9IGQzLm1pbih2YWx1ZXMpO1xuICAgIGIgPSBkMy5tYXgodmFsdWVzKTtcbiAgfVxuXG4gIGxldCBwYWRkaW5nOiBudW1iZXI7XG4gIGxldCBzcGFuID0gYiAtIGE7XG4gIGlmIChzcGFuID09PSAwKSB7XG4gICAgLy8gSWYgYj09PWEsIHdlIHdvdWxkIGNyZWF0ZSBhbiBlbXB0eSByYW5nZS4gV2UgaW5zdGVhZCBzZWxlY3QgdGhlIHJhbmdlXG4gICAgLy8gWzAsIDIqYV0gaWYgYSA+IDAsIG9yIFstMiphLCAwXSBpZiBhIDwgMCwgcGx1cyBhIGxpdHRsZSBiaXQgb2ZcbiAgICAvLyBleHRyYSBwYWRkaW5nIG9uIHRoZSB0b3AgYW5kIGJvdHRvbSBvZiB0aGUgcGxvdC5cbiAgICBwYWRkaW5nID0gTWF0aC5hYnMoYSkgKiAxLjEgKyAxLjE7XG4gIH0gZWxzZSB7XG4gICAgcGFkZGluZyA9IHNwYW4gKiAwLjI7XG4gIH1cblxuICBsZXQgbG93ZXI6IG51bWJlcjtcbiAgaWYgKGEgPj0gMCAmJiBhIDwgc3Bhbikge1xuICAgIC8vIFdlIGluY2x1ZGUgdGhlIGludGVyY2VwdCAoeSA9IDApIGlmIGRvaW5nIHNvIGxlc3MgdGhhbiBkb3VibGVzIHRoZSBzcGFuXG4gICAgLy8gb2YgdGhlIHktYXhpcy4gKFdlIGFjdHVhbGx5IHNlbGVjdCBhIGxvd2VyIGJvdW5kIHRoYXQncyBzbGlnaHRseSBsZXNzXG4gICAgLy8gdGhhbiAwIHNvIHRoYXQgMC4wMCB3aWxsIGNsZWFybHkgYmUgd3JpdHRlbiBvbiB0aGUgbG93ZXIgZWRnZSBvZiB0aGVcbiAgICAvLyBjaGFydC4gVGhlIGxhYmVsIG9uIHRoZSBsb3dlc3QgdGljayBpcyBvZnRlbiBmaWx0ZXJlZCBvdXQuKVxuICAgIGxvd2VyID0gLTAuMSAqIGI7XG4gIH0gZWxzZSB7XG4gICAgbG93ZXIgPSBhIC0gcGFkZGluZztcbiAgfVxuXG5cbiAgbGV0IGRvbWFpbiA9IFtsb3dlciwgYiArIHBhZGRpbmddO1xuICBkb21haW4gPSBkMy5zY2FsZUxpbmVhcigpLmRvbWFpbihkb21haW4pLm5pY2UoKS5kb21haW4oKTtcbiAgcmV0dXJuIGRvbWFpbjtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGFjY2Vzc29yaXplKGtleTogc3RyaW5nKTogUGxvdHRhYmxlLklBY2Nlc3NvcjxudW1iZXI+IHtcbiAgLy8gdHNsaW50OmRpc2FibGUtbmV4dC1saW5lOm5vLWFueSBiZSBxdWlldCB0c2NcbiAgcmV0dXJuIChkOiBhbnksIGluZGV4OiBudW1iZXIsIGRhdGFzZXQ6IFBsb3R0YWJsZS5EYXRhc2V0KSA9PiBkW2tleV07XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgWENvbXBvbmVudHMge1xuICAvKiB0c2xpbnQ6ZGlzYWJsZSAqL1xuICBzY2FsZTogUGxvdHRhYmxlLlNjYWxlcy5MaW5lYXJ8UGxvdHRhYmxlLlNjYWxlcy5UaW1lLFxuICAgICAgYXhpczogUGxvdHRhYmxlLkF4ZXMuTnVtZXJpY3xQbG90dGFibGUuQXhlcy5UaW1lLFxuICAgICAgYWNjZXNzb3I6IFBsb3R0YWJsZS5JQWNjZXNzb3I8bnVtYmVyfERhdGU+LFxuICAvKiB0c2xpbnQ6ZW5hYmxlICovXG59XG5cbmV4cG9ydCBsZXQgc3RlcEZvcm1hdHRlciA9XG4gICAgUGxvdHRhYmxlLkZvcm1hdHRlcnMuc2lTdWZmaXgoU1RFUF9GT1JNQVRURVJfUFJFQ0lTSU9OKTtcbmV4cG9ydCBmdW5jdGlvbiBzdGVwWCgpOiBYQ29tcG9uZW50cyB7XG4gIGxldCBzY2FsZSA9IG5ldyBQbG90dGFibGUuU2NhbGVzLkxpbmVhcigpO1xuICBzY2FsZS50aWNrR2VuZXJhdG9yKFBsb3R0YWJsZS5TY2FsZXMuVGlja0dlbmVyYXRvcnMuaW50ZWdlclRpY2tHZW5lcmF0b3IoKSk7XG4gIGxldCBheGlzID0gbmV3IFBsb3R0YWJsZS5BeGVzLk51bWVyaWMoc2NhbGUsICdib3R0b20nKTtcbiAgYXhpcy5mb3JtYXR0ZXIoc3RlcEZvcm1hdHRlcik7XG4gIHJldHVybiB7XG4gICAgc2NhbGU6IHNjYWxlLFxuICAgIGF4aXM6IGF4aXMsXG4gICAgYWNjZXNzb3I6IChkOiBEYXR1bSkgPT4gZC5zdGVwLFxuICB9O1xufVxuXG5leHBvcnQgbGV0IHRpbWVGb3JtYXR0ZXIgPSBQbG90dGFibGUuRm9ybWF0dGVycy50aW1lKCclYSAlYiAlZSwgJUg6JU06JVMnKTtcblxuZXhwb3J0IGZ1bmN0aW9uIHdhbGxYKCk6IFhDb21wb25lbnRzIHtcbiAgbGV0IHNjYWxlID0gbmV3IFBsb3R0YWJsZS5TY2FsZXMuVGltZSgpO1xuICByZXR1cm4ge1xuICAgIHNjYWxlOiBzY2FsZSxcbiAgICBheGlzOiBuZXcgUGxvdHRhYmxlLkF4ZXMuVGltZShzY2FsZSwgJ2JvdHRvbScpLFxuICAgIGFjY2Vzc29yOiAoZDogRGF0dW0pID0+IGQud2FsbF90aW1lLFxuICB9O1xufVxuZXhwb3J0IGxldCByZWxhdGl2ZUFjY2Vzc29yID1cbiAgICAvLyB0c2xpbnQ6ZGlzYWJsZS1uZXh0LWxpbmU6bm8tYW55IGJlIHF1aWV0IHRzY1xuICAgIChkOiBhbnksIGluZGV4OiBudW1iZXIsIGRhdGFzZXQ6IFBsb3R0YWJsZS5EYXRhc2V0KSA9PiB7XG4gICAgICAvLyBXZSBtYXkgYmUgcmVuZGVyaW5nIHRoZSBmaW5hbC1wb2ludCBkYXR1bSBmb3Igc2NhdHRlcnBsb3QuXG4gICAgICAvLyBJZiBzbywgd2Ugd2lsbCBoYXZlIGFscmVhZHkgcHJvdmlkZWQgdGhlICdyZWxhdGl2ZScgcHJvcGVydHlcbiAgICAgIGlmIChkLnJlbGF0aXZlICE9IG51bGwpIHtcbiAgICAgICAgcmV0dXJuIGQucmVsYXRpdmU7XG4gICAgICB9XG4gICAgICBsZXQgZGF0YSA9IGRhdGFzZXQuZGF0YSgpO1xuICAgICAgLy8gSSBjYW4ndCBpbWFnaW5lIGhvdyB0aGlzIGZ1bmN0aW9uIHdvdWxkIGJlIGNhbGxlZCB3aGVuIHRoZSBkYXRhIGlzXG4gICAgICAvLyBlbXB0eSAoYWZ0ZXIgYWxsLCBpdCBpdGVyYXRlcyBvdmVyIHRoZSBkYXRhKSwgYnV0IGxldHMgZ3VhcmQganVzdFxuICAgICAgLy8gdG8gYmUgc2FmZS5cbiAgICAgIGxldCBmaXJzdCA9IGRhdGEubGVuZ3RoID4gMCA/ICtkYXRhWzBdLndhbGxfdGltZSA6IDA7XG4gICAgICByZXR1cm4gKCtkLndhbGxfdGltZSAtIGZpcnN0KSAvICg2MCAqIDYwICogMTAwMCk7ICAvLyBtcyB0byBob3Vyc1xuICAgIH07XG5cbmV4cG9ydCBsZXQgcmVsYXRpdmVGb3JtYXR0ZXIgPSAobjogbnVtYmVyKSA9PiB7XG4gIC8vIHdlIHdpbGwgYWx3YXlzIHNob3cgMiB1bml0cyBvZiBwcmVjaXNpb24sIGUuZyBkYXlzIGFuZCBob3Vycywgb3JcbiAgLy8gbWludXRlcyBhbmQgc2Vjb25kcywgYnV0IG5vdCBob3VycyBhbmQgbWludXRlcyBhbmQgc2Vjb25kc1xuICBsZXQgcmV0ID0gJyc7XG4gIGxldCBkYXlzID0gTWF0aC5mbG9vcihuIC8gMjQpO1xuICBuIC09IChkYXlzICogMjQpO1xuICBpZiAoZGF5cykge1xuICAgIHJldCArPSBkYXlzICsgJ2QgJztcbiAgfVxuICBsZXQgaG91cnMgPSBNYXRoLmZsb29yKG4pO1xuICBuIC09IGhvdXJzO1xuICBuICo9IDYwO1xuICBpZiAoaG91cnMgfHwgZGF5cykge1xuICAgIHJldCArPSBob3VycyArICdoICc7XG4gIH1cbiAgbGV0IG1pbnV0ZXMgPSBNYXRoLmZsb29yKG4pO1xuICBuIC09IG1pbnV0ZXM7XG4gIG4gKj0gNjA7XG4gIGlmIChtaW51dGVzIHx8IGhvdXJzIHx8IGRheXMpIHtcbiAgICByZXQgKz0gbWludXRlcyArICdtICc7XG4gIH1cbiAgbGV0IHNlY29uZHMgPSBNYXRoLmZsb29yKG4pO1xuICByZXR1cm4gcmV0ICsgc2Vjb25kcyArICdzJztcbn07XG5leHBvcnQgZnVuY3Rpb24gcmVsYXRpdmVYKCk6IFhDb21wb25lbnRzIHtcbiAgbGV0IHNjYWxlID0gbmV3IFBsb3R0YWJsZS5TY2FsZXMuTGluZWFyKCk7XG4gIHJldHVybiB7XG4gICAgc2NhbGU6IHNjYWxlLFxuICAgIGF4aXM6IG5ldyBQbG90dGFibGUuQXhlcy5OdW1lcmljKHNjYWxlLCAnYm90dG9tJyksXG4gICAgYWNjZXNzb3I6IHJlbGF0aXZlQWNjZXNzb3IsXG4gIH07XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBnZXRYQ29tcG9uZW50cyh4VHlwZTogc3RyaW5nKTogWENvbXBvbmVudHMge1xuICBzd2l0Y2ggKHhUeXBlKSB7XG4gICAgY2FzZSBYVHlwZS5TVEVQOlxuICAgICAgcmV0dXJuIHN0ZXBYKCk7XG4gICAgY2FzZSBYVHlwZS5XQUxMX1RJTUU6XG4gICAgICByZXR1cm4gd2FsbFgoKTtcbiAgICBjYXNlIFhUeXBlLlJFTEFUSVZFOlxuICAgICAgcmV0dXJuIHJlbGF0aXZlWCgpO1xuICAgIGRlZmF1bHQ6XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ2ludmFsaWQgeFR5cGU6ICcgKyB4VHlwZSk7XG4gIH1cbn1cblxufSAgLy8gbmFtZXNwYWNlIHZ6X2NoYXJ0X2hlbHBlcnNcbiJdfQ==