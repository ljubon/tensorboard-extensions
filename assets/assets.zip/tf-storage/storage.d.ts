declare namespace tf_storage {
    /**
     * A keyword that users cannot use, since TensorBoard uses this to store info
     * about the active tab.
     */
    const TAB = "__tab__";
    /**
     * The name of the property for users to set on a Polymer component
     * in order for its stored properties to be stored in the URI unambiguously.
     * (No need to set this if you want multiple instances of the component to
     * share URI state)
     *
     * Example:
     * <my-component disambiguator="0"></my-component>
     *
     * The disambiguator should be set to any unique value so that multiple
     * instances of the component can store properties in URI storage.
     *
     * Because it's hard to dereference this variable in HTML property bindings,
     * it is NOT safe to change the disambiguator string without find+replace
     * across the codebase.
     */
    const DISAMBIGUATOR = "disambiguator";
    const getString: (key: string, option?: StorageOptions<any>) => any, setString: (key: string, value: any, option?: SetterOptions<any>) => void, getStringInitializer: (key: string, options: AutoStorageOptions<any>) => Function, getStringObserver: (key: string, options: AutoStorageOptions<any>) => Function, disposeStringBinding: () => void;
    const getBoolean: (key: string, option?: StorageOptions<boolean>) => boolean, setBoolean: (key: string, value: boolean, option?: SetterOptions<boolean>) => void, getBooleanInitializer: (key: string, options: AutoStorageOptions<boolean>) => Function, getBooleanObserver: (key: string, options: AutoStorageOptions<boolean>) => Function, disposeBooleanBinding: () => void;
    const getNumber: (key: string, option?: StorageOptions<number>) => number, setNumber: (key: string, value: number, option?: SetterOptions<number>) => void, getNumberInitializer: (key: string, options: AutoStorageOptions<number>) => Function, getNumberObserver: (key: string, options: AutoStorageOptions<number>) => Function, disposeNumberBinding: () => void;
    const getObject: (key: string, option?: StorageOptions<any>) => any, setObject: (key: string, value: any, option?: SetterOptions<any>) => void, getObjectInitializer: (key: string, options: AutoStorageOptions<any>) => Function, getObjectObserver: (key: string, options: AutoStorageOptions<any>) => Function, disposeObjectBinding: () => void;
    interface StorageOptions<T> {
        defaultValue?: T;
        useLocalStorage?: boolean;
    }
    interface AutoStorageOptions<T> extends StorageOptions<T> {
        polymerProperty?: string;
    }
    interface SetterOptions<T> extends StorageOptions<T> {
        defaultValue?: T;
        useLocalStorage?: boolean;
        useLocationReplace?: boolean;
    }
    function makeBindings<T>(fromString: (string: any) => T, toString: (T: any) => string): {
        get: (key: string, option?: StorageOptions<T>) => T;
        set: (key: string, value: T, option?: SetterOptions<T>) => void;
        getInitializer: (key: string, options: AutoStorageOptions<T>) => Function;
        getObserver: (key: string, options: AutoStorageOptions<T>) => Function;
        disposeBinding: () => void;
    };
}
