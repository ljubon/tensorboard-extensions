/* Copyright 2017 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
var tf_utils;
(function (tf_utils) {
    /**
     * Given many occurrences of tag info for a particular tag across
     * multiple runs, create a representative info object. This is useful
     * for plugins that display just one visualization per tag, instead of
     * one per run--tag combination: each run--tag combination can have its
     * own display name or description, so there is a dimension mismatch. We
     * reconcile this as follows:
     *
     *   - We only show a display name if all runs agree. Otherwise, or if
     *     there are no runs, we use the provided `defaultDisplayName`.
     *
     *   - If all runs agree on a description, we use it. Otherwise,
     *     we concatenate all descriptions, annotating which ones
     *     came from which run, and display them in a list.
     *
     * NOTE: Per TensorBoard convention, we assume that the provided
     * `description`s have sanitized HTML and are safe to render into the
     * DOM, while the `displayName` may be an arbitrary string. The output
     * of this function respects this convention as well.
     */
    function aggregateTagInfo(runToTagInfo, defaultDisplayName) {
        var unanimousDisplayName = undefined;
        var descriptionToRuns = {};
        Object.keys(runToTagInfo).forEach(function (run) {
            var info = runToTagInfo[run];
            if (unanimousDisplayName === undefined) {
                unanimousDisplayName = info.displayName;
            }
            if (unanimousDisplayName !== info.displayName) {
                unanimousDisplayName = null;
            }
            if (descriptionToRuns[info.description] === undefined) {
                descriptionToRuns[info.description] = [];
            }
            descriptionToRuns[info.description].push(run);
        });
        var displayName = unanimousDisplayName != null ?
            unanimousDisplayName :
            defaultDisplayName;
        var description = (function () {
            var descriptions = Object.keys(descriptionToRuns);
            if (descriptions.length === 0) {
                return '';
            }
            else if (descriptions.length === 1) {
                return descriptions[0];
            }
            else {
                var items = descriptions.map(function (description) {
                    var runs = descriptionToRuns[description].map(function (run) {
                        // We're splicing potentially unsafe display names into
                        // sanitized descriptions, so we need to sanitize them.
                        var safeRun = run
                            .replace(/</g, '&lt;')
                            .replace(/>/g, '&gt;') // for symmetry :-)
                            .replace(/&/g, '&amp;');
                        return "<code>" + safeRun + "</code>";
                    });
                    var joined = runs.length > 2 ?
                        (runs.slice(0, runs.length - 1).join(', ')
                            + ', and ' + runs[runs.length - 1]) :
                        runs.join(' and ');
                    var runNoun = ngettext(runs.length, 'run', 'runs');
                    return "<li><p>For " + runNoun + " " + joined + ":</p>" + description + "</li>";
                });
                var prefix = '<p><strong>Multiple descriptions:</strong></p>';
                return prefix + "<ul>" + items.join('') + "</ul>";
            }
        })();
        return { displayName: displayName, description: description };
    }
    tf_utils.aggregateTagInfo = aggregateTagInfo;
    function ngettext(k, enSingular, enPlural) {
        // Potential extension point for proper i18n infrastructure, if we
        // ever implement it.
        return k === 1 ? enSingular : enPlural;
    }
})(tf_utils || (tf_utils = {})); // namespace tf_utils
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidXRpbHMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJ1dGlscy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7Ozs7Ozs7OztnRkFhZ0Y7QUFDaEYsSUFBVSxRQUFRLENBd0ZqQjtBQXhGRCxXQUFVLFFBQVE7SUFVbEI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7T0FtQkc7SUFDSCwwQkFDSSxZQUFzQyxFQUFFLGtCQUEwQjtRQUNwRSxJQUFJLG9CQUFvQixHQUE4QixTQUFTLENBQUM7UUFDaEUsSUFBTSxpQkFBaUIsR0FBc0MsRUFBRSxDQUFDO1FBQ2hFLE1BQU0sQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsT0FBTyxDQUFDLFVBQUEsR0FBRztZQUNuQyxJQUFNLElBQUksR0FBRyxZQUFZLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDL0IsSUFBSSxvQkFBb0IsS0FBSyxTQUFTLEVBQUU7Z0JBQ3RDLG9CQUFvQixHQUFHLElBQUksQ0FBQyxXQUFXLENBQUM7YUFDekM7WUFDRCxJQUFJLG9CQUFvQixLQUFLLElBQUksQ0FBQyxXQUFXLEVBQUU7Z0JBQzdDLG9CQUFvQixHQUFHLElBQUksQ0FBQzthQUM3QjtZQUNELElBQUksaUJBQWlCLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLFNBQVMsRUFBRTtnQkFDckQsaUJBQWlCLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLEVBQUUsQ0FBQzthQUMxQztZQUNELGlCQUFpQixDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDaEQsQ0FBQyxDQUFDLENBQUM7UUFDSCxJQUFNLFdBQVcsR0FDZixvQkFBb0IsSUFBSSxJQUFJLENBQUMsQ0FBQztZQUM5QixvQkFBb0IsQ0FBQyxDQUFDO1lBQ3RCLGtCQUFrQixDQUFDO1FBQ3JCLElBQU0sV0FBVyxHQUFHLENBQUM7WUFDbkIsSUFBTSxZQUFZLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO1lBQ3BELElBQUksWUFBWSxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7Z0JBQzdCLE9BQU8sRUFBRSxDQUFDO2FBQ1g7aUJBQU0sSUFBSSxZQUFZLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtnQkFDcEMsT0FBTyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFDeEI7aUJBQU07Z0JBQ0wsSUFBTSxLQUFLLEdBQUcsWUFBWSxDQUFDLEdBQUcsQ0FBQyxVQUFBLFdBQVc7b0JBQ3hDLElBQU0sSUFBSSxHQUFHLGlCQUFpQixDQUFDLFdBQVcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxVQUFBLEdBQUc7d0JBQ2pELHVEQUF1RDt3QkFDdkQsdURBQXVEO3dCQUN2RCxJQUFNLE9BQU8sR0FBRyxHQUFHOzZCQUNoQixPQUFPLENBQUMsSUFBSSxFQUFFLE1BQU0sQ0FBQzs2QkFDckIsT0FBTyxDQUFDLElBQUksRUFBRSxNQUFNLENBQUMsQ0FBRSxtQkFBbUI7NkJBQzFDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLENBQUM7d0JBQzFCLE9BQU8sV0FBUyxPQUFPLFlBQVMsQ0FBQztvQkFDbkMsQ0FBQyxDQUFDLENBQUM7b0JBQ0gsSUFBTSxNQUFNLEdBQUcsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQzt3QkFDOUIsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7OEJBQ3RDLFFBQVEsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQ3ZDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7b0JBQ3JCLElBQU0sT0FBTyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLEtBQUssRUFBRSxNQUFNLENBQUMsQ0FBQztvQkFDckQsT0FBTyxnQkFBYyxPQUFPLFNBQUksTUFBTSxhQUFRLFdBQVcsVUFBTyxDQUFDO2dCQUNuRSxDQUFDLENBQUMsQ0FBQztnQkFDSCxJQUFNLE1BQU0sR0FBRyxnREFBZ0QsQ0FBQztnQkFDaEUsT0FBVSxNQUFNLFlBQU8sS0FBSyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsVUFBTyxDQUFDO2FBQzlDO1FBQ0gsQ0FBQyxDQUFDLEVBQUUsQ0FBQztRQUNMLE9BQU8sRUFBQyxXQUFXLGFBQUEsRUFBRSxXQUFXLGFBQUEsRUFBQyxDQUFDO0lBQ3BDLENBQUM7SUFsRGUseUJBQWdCLG1CQWtEL0IsQ0FBQTtJQUVELGtCQUFrQixDQUFTLEVBQUUsVUFBa0IsRUFBRSxRQUFnQjtRQUMvRCxrRUFBa0U7UUFDbEUscUJBQXFCO1FBQ3JCLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUM7SUFDekMsQ0FBQztBQUVELENBQUMsRUF4RlMsUUFBUSxLQUFSLFFBQVEsUUF3RmpCLENBQUUscUJBQXFCIiwic291cmNlc0NvbnRlbnQiOlsiLyogQ29weXJpZ2h0IDIwMTcgVGhlIFRlbnNvckZsb3cgQXV0aG9ycy4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cblxuTGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlLCBWZXJzaW9uIDIuMCAodGhlIFwiTGljZW5zZVwiKTtcbnlvdSBtYXkgbm90IHVzZSB0aGlzIGZpbGUgZXhjZXB0IGluIGNvbXBsaWFuY2Ugd2l0aCB0aGUgTGljZW5zZS5cbllvdSBtYXkgb2J0YWluIGEgY29weSBvZiB0aGUgTGljZW5zZSBhdFxuXG4gICAgaHR0cDovL3d3dy5hcGFjaGUub3JnL2xpY2Vuc2VzL0xJQ0VOU0UtMi4wXG5cblVubGVzcyByZXF1aXJlZCBieSBhcHBsaWNhYmxlIGxhdyBvciBhZ3JlZWQgdG8gaW4gd3JpdGluZywgc29mdHdhcmVcbmRpc3RyaWJ1dGVkIHVuZGVyIHRoZSBMaWNlbnNlIGlzIGRpc3RyaWJ1dGVkIG9uIGFuIFwiQVMgSVNcIiBCQVNJUyxcbldJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWSBLSU5ELCBlaXRoZXIgZXhwcmVzcyBvciBpbXBsaWVkLlxuU2VlIHRoZSBMaWNlbnNlIGZvciB0aGUgc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nIHBlcm1pc3Npb25zIGFuZFxubGltaXRhdGlvbnMgdW5kZXIgdGhlIExpY2Vuc2UuXG49PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0qL1xubmFtZXNwYWNlIHRmX3V0aWxzIHtcblxuLypcbiAqIE1pc2NlbGxhbmVvdXMgdXRpbGl0aWVzIHRoYXQgbWF5IGJlIHVzZWZ1bCB0byBwbHVnaW4gZnJvbnRlbmRzLlxuICovXG5leHBvcnQgaW50ZXJmYWNlIFRhZ0luZm8ge1xuICAgIGRpc3BsYXlOYW1lOiBzdHJpbmc7XG4gICAgZGVzY3JpcHRpb246IHN0cmluZztcbn1cblxuLyoqXG4gKiBHaXZlbiBtYW55IG9jY3VycmVuY2VzIG9mIHRhZyBpbmZvIGZvciBhIHBhcnRpY3VsYXIgdGFnIGFjcm9zc1xuICogbXVsdGlwbGUgcnVucywgY3JlYXRlIGEgcmVwcmVzZW50YXRpdmUgaW5mbyBvYmplY3QuIFRoaXMgaXMgdXNlZnVsXG4gKiBmb3IgcGx1Z2lucyB0aGF0IGRpc3BsYXkganVzdCBvbmUgdmlzdWFsaXphdGlvbiBwZXIgdGFnLCBpbnN0ZWFkIG9mXG4gKiBvbmUgcGVyIHJ1bi0tdGFnIGNvbWJpbmF0aW9uOiBlYWNoIHJ1bi0tdGFnIGNvbWJpbmF0aW9uIGNhbiBoYXZlIGl0c1xuICogb3duIGRpc3BsYXkgbmFtZSBvciBkZXNjcmlwdGlvbiwgc28gdGhlcmUgaXMgYSBkaW1lbnNpb24gbWlzbWF0Y2guIFdlXG4gKiByZWNvbmNpbGUgdGhpcyBhcyBmb2xsb3dzOlxuICpcbiAqICAgLSBXZSBvbmx5IHNob3cgYSBkaXNwbGF5IG5hbWUgaWYgYWxsIHJ1bnMgYWdyZWUuIE90aGVyd2lzZSwgb3IgaWZcbiAqICAgICB0aGVyZSBhcmUgbm8gcnVucywgd2UgdXNlIHRoZSBwcm92aWRlZCBgZGVmYXVsdERpc3BsYXlOYW1lYC5cbiAqXG4gKiAgIC0gSWYgYWxsIHJ1bnMgYWdyZWUgb24gYSBkZXNjcmlwdGlvbiwgd2UgdXNlIGl0LiBPdGhlcndpc2UsXG4gKiAgICAgd2UgY29uY2F0ZW5hdGUgYWxsIGRlc2NyaXB0aW9ucywgYW5ub3RhdGluZyB3aGljaCBvbmVzXG4gKiAgICAgY2FtZSBmcm9tIHdoaWNoIHJ1biwgYW5kIGRpc3BsYXkgdGhlbSBpbiBhIGxpc3QuXG4gKlxuICogTk9URTogUGVyIFRlbnNvckJvYXJkIGNvbnZlbnRpb24sIHdlIGFzc3VtZSB0aGF0IHRoZSBwcm92aWRlZFxuICogYGRlc2NyaXB0aW9uYHMgaGF2ZSBzYW5pdGl6ZWQgSFRNTCBhbmQgYXJlIHNhZmUgdG8gcmVuZGVyIGludG8gdGhlXG4gKiBET00sIHdoaWxlIHRoZSBgZGlzcGxheU5hbWVgIG1heSBiZSBhbiBhcmJpdHJhcnkgc3RyaW5nLiBUaGUgb3V0cHV0XG4gKiBvZiB0aGlzIGZ1bmN0aW9uIHJlc3BlY3RzIHRoaXMgY29udmVudGlvbiBhcyB3ZWxsLlxuICovXG5leHBvcnQgZnVuY3Rpb24gYWdncmVnYXRlVGFnSW5mbyhcbiAgICBydW5Ub1RhZ0luZm86IHtbcnVuOiBzdHJpbmddOiBUYWdJbmZvfSwgZGVmYXVsdERpc3BsYXlOYW1lOiBzdHJpbmcpOiBUYWdJbmZvIHtcbiAgbGV0IHVuYW5pbW91c0Rpc3BsYXlOYW1lOiBzdHJpbmcgfCBudWxsIHwgdW5kZWZpbmVkID0gdW5kZWZpbmVkO1xuICBjb25zdCBkZXNjcmlwdGlvblRvUnVuczoge1tkZXNjcmlwdGlvbjogc3RyaW5nXTogc3RyaW5nW119ID0ge307XG4gIE9iamVjdC5rZXlzKHJ1blRvVGFnSW5mbykuZm9yRWFjaChydW4gPT4ge1xuICAgIGNvbnN0IGluZm8gPSBydW5Ub1RhZ0luZm9bcnVuXTtcbiAgICBpZiAodW5hbmltb3VzRGlzcGxheU5hbWUgPT09IHVuZGVmaW5lZCkge1xuICAgICAgdW5hbmltb3VzRGlzcGxheU5hbWUgPSBpbmZvLmRpc3BsYXlOYW1lO1xuICAgIH1cbiAgICBpZiAodW5hbmltb3VzRGlzcGxheU5hbWUgIT09IGluZm8uZGlzcGxheU5hbWUpIHtcbiAgICAgIHVuYW5pbW91c0Rpc3BsYXlOYW1lID0gbnVsbDtcbiAgICB9XG4gICAgaWYgKGRlc2NyaXB0aW9uVG9SdW5zW2luZm8uZGVzY3JpcHRpb25dID09PSB1bmRlZmluZWQpIHtcbiAgICAgIGRlc2NyaXB0aW9uVG9SdW5zW2luZm8uZGVzY3JpcHRpb25dID0gW107XG4gICAgfVxuICAgIGRlc2NyaXB0aW9uVG9SdW5zW2luZm8uZGVzY3JpcHRpb25dLnB1c2gocnVuKTtcbiAgfSk7XG4gIGNvbnN0IGRpc3BsYXlOYW1lID1cbiAgICB1bmFuaW1vdXNEaXNwbGF5TmFtZSAhPSBudWxsID9cbiAgICB1bmFuaW1vdXNEaXNwbGF5TmFtZSA6XG4gICAgZGVmYXVsdERpc3BsYXlOYW1lO1xuICBjb25zdCBkZXNjcmlwdGlvbiA9ICgoKSA9PiB7XG4gICAgY29uc3QgZGVzY3JpcHRpb25zID0gT2JqZWN0LmtleXMoZGVzY3JpcHRpb25Ub1J1bnMpO1xuICAgIGlmIChkZXNjcmlwdGlvbnMubGVuZ3RoID09PSAwKSB7XG4gICAgICByZXR1cm4gJyc7XG4gICAgfSBlbHNlIGlmIChkZXNjcmlwdGlvbnMubGVuZ3RoID09PSAxKSB7XG4gICAgICByZXR1cm4gZGVzY3JpcHRpb25zWzBdO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25zdCBpdGVtcyA9IGRlc2NyaXB0aW9ucy5tYXAoZGVzY3JpcHRpb24gPT4ge1xuICAgICAgICBjb25zdCBydW5zID0gZGVzY3JpcHRpb25Ub1J1bnNbZGVzY3JpcHRpb25dLm1hcChydW4gPT4ge1xuICAgICAgICAgIC8vIFdlJ3JlIHNwbGljaW5nIHBvdGVudGlhbGx5IHVuc2FmZSBkaXNwbGF5IG5hbWVzIGludG9cbiAgICAgICAgICAvLyBzYW5pdGl6ZWQgZGVzY3JpcHRpb25zLCBzbyB3ZSBuZWVkIHRvIHNhbml0aXplIHRoZW0uXG4gICAgICAgICAgY29uc3Qgc2FmZVJ1biA9IHJ1blxuICAgICAgICAgICAgLnJlcGxhY2UoLzwvZywgJyZsdDsnKVxuICAgICAgICAgICAgLnJlcGxhY2UoLz4vZywgJyZndDsnKSAgLy8gZm9yIHN5bW1ldHJ5IDotKVxuICAgICAgICAgICAgLnJlcGxhY2UoLyYvZywgJyZhbXA7Jyk7XG4gICAgICAgICAgcmV0dXJuIGA8Y29kZT4ke3NhZmVSdW59PC9jb2RlPmA7XG4gICAgICAgIH0pO1xuICAgICAgICBjb25zdCBqb2luZWQgPSBydW5zLmxlbmd0aCA+IDIgP1xuICAgICAgICAgIChydW5zLnNsaWNlKDAsIHJ1bnMubGVuZ3RoIC0gMSkuam9pbignLCAnKVxuICAgICAgICAgICAgKyAnLCBhbmQgJyArIHJ1bnNbcnVucy5sZW5ndGggLSAxXSkgOlxuICAgICAgICAgIHJ1bnMuam9pbignIGFuZCAnKTtcbiAgICAgICAgY29uc3QgcnVuTm91biA9IG5nZXR0ZXh0KHJ1bnMubGVuZ3RoLCAncnVuJywgJ3J1bnMnKTtcbiAgICAgICAgcmV0dXJuIGA8bGk+PHA+Rm9yICR7cnVuTm91bn0gJHtqb2luZWR9OjwvcD4ke2Rlc2NyaXB0aW9ufTwvbGk+YDtcbiAgICAgIH0pO1xuICAgICAgY29uc3QgcHJlZml4ID0gJzxwPjxzdHJvbmc+TXVsdGlwbGUgZGVzY3JpcHRpb25zOjwvc3Ryb25nPjwvcD4nO1xuICAgICAgcmV0dXJuIGAke3ByZWZpeH08dWw+JHtpdGVtcy5qb2luKCcnKX08L3VsPmA7XG4gICAgfVxuICB9KSgpO1xuICByZXR1cm4ge2Rpc3BsYXlOYW1lLCBkZXNjcmlwdGlvbn07XG59XG5cbmZ1bmN0aW9uIG5nZXR0ZXh0KGs6IG51bWJlciwgZW5TaW5ndWxhcjogc3RyaW5nLCBlblBsdXJhbDogc3RyaW5nKTogc3RyaW5nIHtcbiAgLy8gUG90ZW50aWFsIGV4dGVuc2lvbiBwb2ludCBmb3IgcHJvcGVyIGkxOG4gaW5mcmFzdHJ1Y3R1cmUsIGlmIHdlXG4gIC8vIGV2ZXIgaW1wbGVtZW50IGl0LlxuICByZXR1cm4gayA9PT0gMSA/IGVuU2luZ3VsYXIgOiBlblBsdXJhbDtcbn1cblxufSAgLy8gbmFtZXNwYWNlIHRmX3V0aWxzXG4iXX0=