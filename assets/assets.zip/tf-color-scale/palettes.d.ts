declare namespace tf_color_scale {
    const palettes: {
        googleStandard: string[];
        googleCool: string[];
        googleWarm: string[];
        googleColorBlindAssist: string[];
        tensorboardColorBlindAssist: string[];
        colorBlindAssist1: string[];
        colorBlindAssist2: string[];
        colorBlindAssist3: string[];
        colorBlindAssist4: string[];
        colorBlindAssist5: string[];
        mldash: string[];
    };
    const standard: string[];
}
