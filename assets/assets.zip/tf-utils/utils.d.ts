declare namespace tf_utils {
    interface TagInfo {
        displayName: string;
        description: string;
    }
    /**
     * Given many occurrences of tag info for a particular tag across
     * multiple runs, create a representative info object. This is useful
     * for plugins that display just one visualization per tag, instead of
     * one per run--tag combination: each run--tag combination can have its
     * own display name or description, so there is a dimension mismatch. We
     * reconcile this as follows:
     *
     *   - We only show a display name if all runs agree. Otherwise, or if
     *     there are no runs, we use the provided `defaultDisplayName`.
     *
     *   - If all runs agree on a description, we use it. Otherwise,
     *     we concatenate all descriptions, annotating which ones
     *     came from which run, and display them in a list.
     *
     * NOTE: Per TensorBoard convention, we assume that the provided
     * `description`s have sanitized HTML and are safe to render into the
     * DOM, while the `displayName` may be an arbitrary string. The output
     * of this function respects this convention as well.
     */
    function aggregateTagInfo(runToTagInfo: {
        [run: string]: TagInfo;
    }, defaultDisplayName: string): TagInfo;
}
