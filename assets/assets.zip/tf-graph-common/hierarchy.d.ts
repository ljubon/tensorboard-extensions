/**
 * Package for the Graph Hierarchy for TensorFlow graph.
 */
declare module tf.graph.hierarchy {
    /**
     * Class used as output for getPredecessors and getSuccessors methods
     */
    interface Edges {
        control: Metaedge[];
        regular: Metaedge[];
    }
    /**
     * Class used to store data on library functions. This specifically stores data
     * on the library function, not individual calls to those functions.
     */
    interface LibraryFunctionData {
        node: Metanode;
        usages: Node[];
    }
    interface Hierarchy {
        root: Metanode;
        libraryFunctions: {
            [key: string]: LibraryFunctionData;
        };
        templates: {
            [templateId: string]: string[];
        };
        /** List of all device names */
        devices: string[];
        /** List of all XLA cluster names */
        xlaClusters: string[];
        /** True if at least one tensor in the graph has shape information */
        hasShapeInfo: boolean;
        /** The maximum size across all meta edges. Used for scaling thickness. */
        maxMetaEdgeSize: number;
        graphOptions: graphlib.GraphOptions;
        getNodeMap(): {
            [nodeName: string]: GroupNode | OpNode;
        };
        node(name: string): GroupNode | OpNode;
        setNode(name: string, node: GroupNode | OpNode): void;
        getBridgegraph(nodeName: string): graphlib.Graph<GroupNode | OpNode, Metaedge>;
        getPredecessors(nodeName: string): Edges;
        getSuccessors(nodeName: string): Edges;
        getTopologicalOrdering(nodeName: string): {
            [childName: string]: number;
        };
        getTemplateIndex(): (string: any) => number;
    }
    interface HierarchyParams {
        verifyTemplate: boolean;
        seriesNodeMinSize: number;
        seriesMap: {
            [name: string]: tf.graph.SeriesGroupingType;
        };
        rankDirection: string;
        useGeneralizedSeriesPatterns: boolean;
    }
    /**
     * @param graph The raw graph.
     * @param params Parameters used when building a hierarchy.
     */
    function build(graph: tf.graph.SlimGraph, params: HierarchyParams, tracker: ProgressTracker): Promise<Hierarchy | void>;
    function joinAndAggregateStats(h: Hierarchy, stats: tf.graph.proto.StepStats): void;
    function getIncompatibleOps(hierarchy: Hierarchy, hierarchyParams: HierarchyParams): (OpNode | GroupNode)[];
}
