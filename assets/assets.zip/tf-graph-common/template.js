/* Copyright 2015 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the 'License');
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an 'AS IS' BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
var tf;
(function (tf) {
    var graph;
    (function (graph_1) {
        var template;
        (function (template) {
            /**
             * Detect repeating patterns of subgraphs.
             * Assign templateId to each subgraph if it belongs to a template.
             * Returns clusters of similar subgraphs .
             *
             * @param graph
             * @param verifyTemplate whether to run the template verification algorithm
             * @return a dict (template id => Array of node names)
             */
            function detect(h, verifyTemplate) {
                // In any particular subgraph, there are either
                // - leaf nodes (which do not have subgraph)
                // - metanode nodes - some of them have only one member (singular metanode)
                //                    and some have multiple members (non-singular metanode)
                // First, generate a nearest neighbor hash of metanode nodes.
                var nnGroups = clusterSimilarSubgraphs(h);
                // For each metanode, compare its subgraph (starting from shallower groups)
                // and assign template id.
                var templates = groupTemplateAndAssignId(nnGroups, verifyTemplate);
                // Sort the templates by minimum level in the graph at which they appear,
                // as this leads to optimal setting of the colors of each template for
                // maximum differentiation.
                return Object.keys(templates)
                    .sort(function (key) { return templates[key].level; })
                    .reduce(function (obj, key) {
                    obj[key] = templates[key];
                    return obj;
                }, {});
            }
            template.detect = detect;
            ;
            /**
             * @return Unique string for a metanode based on depth, |V|, |E| and
             * op type histogram.
             */
            function getSignature(metanode) {
                // depth=<number> |V|=<number> |E|=<number>
                var props = _.map({
                    'depth': metanode.depth,
                    '|V|': metanode.metagraph.nodes().length,
                    '|E|': metanode.metagraph.edges().length
                }, function (v, k) { return k + '=' + v; })
                    .join(' ');
                // optype1=count1,optype2=count2
                var ops = _.map(metanode.opHistogram, function (count, op) {
                    return op + '=' + count;
                }).join(',');
                return props + ' [ops] ' + ops;
            }
            /**
             * Generate a nearest neighbor hash of metanodes
             * based on depth, |V|, |E|, and opHistogram of their subgraph
             * (excluding leaf nodes and singular metanodes).
             * @param graph The graph
             * @return Array of pairs of [signature,
             *   Object with min level of the template and an Array of tf.graph.Group]
             *   sort by ascending order of minimum depth at which metanode appears.
             */
            function clusterSimilarSubgraphs(h) {
                /** a dict from metanode.signature() => Array of tf.graph.Groups */
                var hashDict = _(h.getNodeMap()).reduce(function (hash, node, name) {
                    if (node.type !== graph_1.NodeType.META) {
                        return hash;
                    }
                    var levelOfMetaNode = name.split('/').length - 1;
                    var signature = getSignature(node);
                    var templateInfo = hash[signature] ||
                        { nodes: [], level: levelOfMetaNode };
                    hash[signature] = templateInfo;
                    templateInfo.nodes.push(node);
                    if (templateInfo.level > levelOfMetaNode) {
                        templateInfo.level = levelOfMetaNode;
                    }
                    return hash;
                }, {});
                return Object.keys(hashDict)
                    .map(function (key) { return [key, hashDict[key]]; })
                    .filter(function (_a) {
                    var _ = _a[0], subGraph = _a[1];
                    var nodes = subGraph.nodes;
                    if (nodes.length > 1) {
                        // There is more than 1 node with this template. It is worth assigning
                        // a unique color to this template.
                        return true;
                    }
                    // If there is only 1 node with this template, only make a template for
                    // it if it represents a function. In that case, the graph explorer may
                    // add more nodes with the template later.
                    var node = nodes[0];
                    return node.type === graph_1.NodeType.META &&
                        node.associatedFunction;
                })
                    .sort(function (_a) {
                    var _ = _a[0], subGraph = _a[1];
                    // sort by depth
                    // (all members in the same nnGroup has equal depth)
                    return subGraph.nodes[0].depth;
                });
            }
            function groupTemplateAndAssignId(nnGroups, verifyTemplate) {
                // For each metanode, compare its subgraph (starting from shallower groups)
                // and assign template id.
                var result = {};
                return _.reduce(nnGroups, function (templates, nnGroupPair) {
                    var signature = nnGroupPair[0], nnGroup = nnGroupPair[1].nodes, clusters = [];
                    nnGroup.forEach(function (metanode) {
                        // check with each existing cluster
                        for (var i = 0; i < clusters.length; i++) {
                            var similar = !verifyTemplate ||
                                isSimilarSubgraph(clusters[i].metanode.metagraph, metanode.metagraph);
                            // if similar, just add this metanode to the cluster
                            if (similar) {
                                // get template from the first one
                                metanode.templateId = clusters[i].metanode.templateId;
                                clusters[i].members.push(metanode.name);
                                return;
                            }
                        }
                        // otherwise create a new cluster with id 'signature [count] '
                        metanode.templateId = signature + '[' + clusters.length + ']';
                        clusters.push({
                            metanode: metanode,
                            members: [metanode.name]
                        });
                    });
                    clusters.forEach(function (c) {
                        templates[c.metanode.templateId] = {
                            level: nnGroupPair[1].level,
                            nodes: c.members
                        };
                    });
                    return templates;
                }, result);
            }
            function sortNodes(names, graph, prefix) {
                return _.sortBy(names, [
                    function (name) { return graph.node(name).op; },
                    function (name) { return graph.node(name).templateId; },
                    function (name) { return graph.neighbors(name).length; },
                    function (name) { return graph.predecessors(name).length; },
                    function (name) { return graph.successors(name).length; },
                    function (name) { return name.substr(prefix.length); },
                ]);
            }
            function isSimilarSubgraph(g1, g2) {
                if (!tf.graph.hasSimilarDegreeSequence(g1, g2)) {
                    return false;
                }
                // if we want to skip, just return true here.
                // return true;
                // Verify sequence by running DFS
                var g1prefix = g1.graph().name;
                var g2prefix = g2.graph().name;
                var visited1 = {};
                var visited2 = {};
                var stack = [];
                /**
                 * push sources or successors into the stack
                 * if the visiting pattern has been similar.
                 */
                function stackPushIfNotDifferent(n1, n2) {
                    var sub1 = n1.substr(g1prefix.length), sub2 = n2.substr(g2prefix.length);
                    /* tslint:disable */
                    if (visited1[sub1] ^ visited2[sub2]) {
                        console.warn('different visit pattern', '[' + g1prefix + ']', sub1, '[' + g2prefix + ']', sub2);
                        return true;
                    }
                    /* tslint:enable */
                    if (!visited1[sub1]) { // implied && !visited2[sub2]
                        visited1[sub1] = visited2[sub2] = true;
                        stack.push({ n1: n1, n2: n2 });
                    }
                    return false;
                }
                // check if have same # of sources then sort and push
                var sources1 = g1.sources();
                var sources2 = g2.sources();
                if (sources1.length !== sources2.length) {
                    /* tslint:disable */
                    console.log('different source length');
                    /* tslint:enable */
                    return false;
                }
                sources1 = sortNodes(sources1, g1, g1prefix);
                sources2 = sortNodes(sources2, g2, g2prefix);
                for (var i = 0; i < sources1.length; i++) {
                    var different = stackPushIfNotDifferent(sources1[i], sources2[i]);
                    if (different) {
                        return false;
                    }
                }
                while (stack.length > 0) {
                    var cur = stack.pop();
                    // check node
                    var similar = isSimilarNode(g1.node(cur.n1), g2.node(cur.n2));
                    if (!similar) {
                        return false;
                    }
                    // check if have same # of successors then sort and push
                    var succ1 = g1.successors(cur.n1), succ2 = g2.successors(cur.n2);
                    if (succ1.length !== succ2.length) {
                        /* tslint:disable */
                        console.log('# of successors mismatch', succ1, succ2);
                        /* tslint:enable */
                        return false;
                    }
                    succ1 = sortNodes(succ1, g1, g1prefix);
                    succ2 = sortNodes(succ2, g2, g2prefix);
                    for (var j = 0; j < succ1.length; j++) {
                        var different = stackPushIfNotDifferent(succ1[j], succ2[j]);
                        if (different) {
                            return false;
                        }
                    }
                }
                return true;
            }
            /**
             * Returns if two nodes have identical structure.
             */
            function isSimilarNode(n1, n2) {
                if (n1.type === graph_1.NodeType.META) {
                    // compare metanode
                    var metanode1 = n1;
                    var metanode2 = n2;
                    return metanode1.templateId && metanode2.templateId &&
                        metanode1.templateId === metanode2.templateId;
                }
                else if (n1.type === graph_1.NodeType.OP && n2.type === graph_1.NodeType.OP) {
                    // compare leaf node
                    return n1.op === n2.op;
                }
                else if (n1.type === graph_1.NodeType.SERIES && n2.type === graph_1.NodeType.SERIES) {
                    // compare series node sizes and operations
                    // (only need to check one op as all op nodes are identical in series)
                    var sn1 = n1;
                    var sn2 = n2;
                    var seriesnode1Count = sn1.metagraph.nodeCount();
                    return (seriesnode1Count === sn2.metagraph.nodeCount() &&
                        (seriesnode1Count === 0 ||
                            (sn1.metagraph.node(sn1.metagraph.nodes()[0]).op ===
                                sn2.metagraph.node(sn2.metagraph.nodes()[0]).op)));
                }
                return false;
            }
        })(template = graph_1.template || (graph_1.template = {}));
    })(graph = tf.graph || (tf.graph = {}));
})(tf || (tf = {}));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGVtcGxhdGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJ0ZW1wbGF0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7Ozs7Ozs7OztnRkFhZ0Y7QUFDaEYsSUFBTyxFQUFFLENBNFJSO0FBNVJELFdBQU8sRUFBRTtJQUFDLElBQUEsS0FBSyxDQTRSZDtJQTVSUyxXQUFBLE9BQUs7UUFBQyxJQUFBLFFBQVEsQ0E0UnZCO1FBNVJlLFdBQUEsUUFBUTtZQUV4Qjs7Ozs7Ozs7ZUFRRztZQUNILGdCQUF1QixDQUFDLEVBQUUsY0FBYztnQkFDdEMsK0NBQStDO2dCQUMvQyw0Q0FBNEM7Z0JBQzVDLDJFQUEyRTtnQkFDM0UsNEVBQTRFO2dCQUU1RSw2REFBNkQ7Z0JBQzdELElBQUksUUFBUSxHQUFHLHVCQUF1QixDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUUxQywyRUFBMkU7Z0JBQzNFLDBCQUEwQjtnQkFDMUIsSUFBSSxTQUFTLEdBQUcsd0JBQXdCLENBQUMsUUFBUSxFQUFFLGNBQWMsQ0FBQyxDQUFDO2dCQUVuRSx5RUFBeUU7Z0JBQ3pFLHNFQUFzRTtnQkFDdEUsMkJBQTJCO2dCQUMzQixPQUF5QyxNQUFNLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQztxQkFDMUQsSUFBSSxDQUFDLFVBQUEsR0FBRyxJQUFJLE9BQUEsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssRUFBcEIsQ0FBb0IsQ0FBQztxQkFDakMsTUFBTSxDQUFDLFVBQUMsR0FBRyxFQUFFLEdBQUc7b0JBQ2YsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQztvQkFDMUIsT0FBTyxHQUFHLENBQUM7Z0JBQ2IsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO1lBQ2IsQ0FBQztZQXRCZSxlQUFNLFNBc0JyQixDQUFBO1lBQUEsQ0FBQztZQUVGOzs7ZUFHRztZQUNILHNCQUFzQixRQUFRO2dCQUM1QiwyQ0FBMkM7Z0JBQzNDLElBQUksS0FBSyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQ0E7b0JBQ0UsT0FBTyxFQUFFLFFBQVEsQ0FBQyxLQUFLO29CQUN2QixLQUFLLEVBQUUsUUFBUSxDQUFDLFNBQVMsQ0FBQyxLQUFLLEVBQUUsQ0FBQyxNQUFNO29CQUN4QyxLQUFLLEVBQUUsUUFBUSxDQUFDLFNBQVMsQ0FBQyxLQUFLLEVBQUUsQ0FBQyxNQUFNO2lCQUN6QyxFQUNELFVBQVMsQ0FBQyxFQUFFLENBQUMsSUFBSSxPQUFPLENBQUMsR0FBRyxHQUFHLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO3FCQUN2QyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBRTNCLGdDQUFnQztnQkFDaEMsSUFBSSxHQUFHLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsV0FBVyxFQUFFLFVBQVMsS0FBSyxFQUFFLEVBQUU7b0JBQzNDLE9BQU8sRUFBRSxHQUFHLEdBQUcsR0FBRyxLQUFLLENBQUM7Z0JBQzFCLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFFeEIsT0FBTyxLQUFLLEdBQUcsU0FBUyxHQUFHLEdBQUcsQ0FBQztZQUNqQyxDQUFDO1lBRUQ7Ozs7Ozs7O2VBUUc7WUFDSCxpQ0FBaUMsQ0FBc0I7Z0JBQ3JELG1FQUFtRTtnQkFDbkUsSUFBSSxRQUFRLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FDbkMsVUFBQyxJQUFJLEVBQUUsSUFBcUIsRUFBRSxJQUFJO29CQUNwQyxJQUFJLElBQUksQ0FBQyxJQUFJLEtBQUssUUFBQSxRQUFRLENBQUMsSUFBSSxFQUFFO3dCQUMvQixPQUFPLElBQUksQ0FBQztxQkFDYjtvQkFDRCxJQUFJLGVBQWUsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7b0JBQ2pELElBQUksU0FBUyxHQUFHLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQztvQkFDbkMsSUFBSSxZQUFZLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQzt3QkFDaEMsRUFBQyxLQUFLLEVBQUUsRUFBRSxFQUFFLEtBQUssRUFBRSxlQUFlLEVBQUMsQ0FBQztvQkFDdEMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLFlBQVksQ0FBQztvQkFDL0IsWUFBWSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7b0JBQzlCLElBQUksWUFBWSxDQUFDLEtBQUssR0FBRyxlQUFlLEVBQUU7d0JBQ3hDLFlBQVksQ0FBQyxLQUFLLEdBQUcsZUFBZSxDQUFDO3FCQUN0QztvQkFDRCxPQUFPLElBQUksQ0FBQztnQkFDZCxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7Z0JBRVAsT0FBTyxNQUFNLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQztxQkFDdkIsR0FBRyxDQUFDLFVBQUEsR0FBRyxJQUFJLE9BQUEsQ0FBQyxHQUFHLEVBQUUsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQXBCLENBQW9CLENBQUM7cUJBQ2hDLE1BQU0sQ0FBQyxVQUFDLEVBQWE7d0JBQVosU0FBQyxFQUFFLGdCQUFRO29CQUNaLElBQUEsc0JBQUssQ0FBYTtvQkFDekIsSUFBSSxLQUFLLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTt3QkFDcEIsc0VBQXNFO3dCQUN0RSxtQ0FBbUM7d0JBQ25DLE9BQU8sSUFBSSxDQUFDO3FCQUNiO29CQUVELHVFQUF1RTtvQkFDdkUsdUVBQXVFO29CQUN2RSwwQ0FBMEM7b0JBQzFDLElBQU0sSUFBSSxHQUFHLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDdEIsT0FBTyxJQUFJLENBQUMsSUFBSSxLQUFLLFFBQUEsUUFBUSxDQUFDLElBQUk7d0JBQzdCLElBQWlCLENBQUMsa0JBQWtCLENBQUM7Z0JBQzVDLENBQUMsQ0FBQztxQkFDRCxJQUFJLENBQUMsVUFBQyxFQUFhO3dCQUFaLFNBQUMsRUFBRSxnQkFBUTtvQkFDakIsZ0JBQWdCO29CQUNoQixvREFBb0Q7b0JBQ3BELE9BQU8sUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7Z0JBQ2pDLENBQUMsQ0FBQyxDQUFDO1lBQ1QsQ0FBQztZQUVELGtDQUFrQyxRQUFRLEVBQUUsY0FBYztnQkFDeEQsMkVBQTJFO2dCQUMzRSwwQkFBMEI7Z0JBQzFCLElBQUksTUFBTSxHQUE2RCxFQUFFLENBQUM7Z0JBQzFFLE9BQU8sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxRQUFRLEVBQUUsVUFBUyxTQUFTLEVBQUUsV0FBVztvQkFDdkQsSUFBSSxTQUFTLEdBQUcsV0FBVyxDQUFDLENBQUMsQ0FBQyxFQUM1QixPQUFPLEdBQUcsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssRUFDOUIsUUFBUSxHQUFHLEVBQUUsQ0FBQztvQkFFaEIsT0FBTyxDQUFDLE9BQU8sQ0FBQyxVQUFTLFFBQVE7d0JBQy9CLG1DQUFtQzt3QkFDbkMsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFFBQVEsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7NEJBQ3hDLElBQUksT0FBTyxHQUFHLENBQUMsY0FBYztnQ0FDZixpQkFBaUIsQ0FDZixRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLFNBQVMsRUFDOUIsUUFBUSxDQUFDLFNBQVMsQ0FDbkIsQ0FBQzs0QkFDaEIsb0RBQW9EOzRCQUNwRCxJQUFJLE9BQU8sRUFBRTtnQ0FDWCxrQ0FBa0M7Z0NBQ2xDLFFBQVEsQ0FBQyxVQUFVLEdBQUcsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUM7Z0NBQ3RELFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQztnQ0FDeEMsT0FBTzs2QkFDUjt5QkFDRjt3QkFDRCw4REFBOEQ7d0JBQzlELFFBQVEsQ0FBQyxVQUFVLEdBQUcsU0FBUyxHQUFHLEdBQUcsR0FBRyxRQUFRLENBQUMsTUFBTSxHQUFHLEdBQUcsQ0FBQzt3QkFDOUQsUUFBUSxDQUFDLElBQUksQ0FBQzs0QkFDWixRQUFRLEVBQUUsUUFBUTs0QkFDbEIsT0FBTyxFQUFFLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQzt5QkFDekIsQ0FBQyxDQUFDO29CQUNMLENBQUMsQ0FBQyxDQUFDO29CQUVILFFBQVEsQ0FBQyxPQUFPLENBQUMsVUFBUyxDQUFDO3dCQUN6QixTQUFTLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsR0FBRzs0QkFDakMsS0FBSyxFQUFFLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLOzRCQUMzQixLQUFLLEVBQUUsQ0FBQyxDQUFDLE9BQU87eUJBQ2pCLENBQUM7b0JBQ0osQ0FBQyxDQUFDLENBQUM7b0JBQ0gsT0FBTyxTQUFTLENBQUM7Z0JBQ25CLENBQUMsRUFBRSxNQUFNLENBQUMsQ0FBQztZQUNiLENBQUM7WUFFRCxtQkFBbUIsS0FBZSxFQUM5QixLQUFnRCxFQUFFLE1BQWM7Z0JBQ2xFLE9BQU8sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQ2pCO29CQUNFLFVBQUMsSUFBSSxJQUFLLE9BQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQVksQ0FBQyxFQUFFLEVBQS9CLENBQStCO29CQUN6QyxVQUFDLElBQUksSUFBSyxPQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFjLENBQUMsVUFBVSxFQUF6QyxDQUF5QztvQkFDbkQsVUFBQyxJQUFJLElBQUssT0FBQSxLQUFLLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sRUFBNUIsQ0FBNEI7b0JBQ3RDLFVBQUMsSUFBSSxJQUFLLE9BQUEsS0FBSyxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLEVBQS9CLENBQStCO29CQUN6QyxVQUFDLElBQUksSUFBSyxPQUFBLEtBQUssQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxFQUE3QixDQUE2QjtvQkFDdkMsVUFBQyxJQUFJLElBQUssT0FBQSxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBMUIsQ0FBMEI7aUJBQ3ZDLENBQUMsQ0FBQztZQUNQLENBQUM7WUFFRCwyQkFBMkIsRUFBNEIsRUFDbkQsRUFBNEI7Z0JBQzlCLElBQUksQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLHdCQUF3QixDQUFDLEVBQUUsRUFBRSxFQUFFLENBQUMsRUFBRTtvQkFDNUMsT0FBTyxLQUFLLENBQUM7aUJBQ2hCO2dCQUVELDZDQUE2QztnQkFDN0MsZUFBZTtnQkFFZixpQ0FBaUM7Z0JBQ2pDLElBQUksUUFBUSxHQUFHLEVBQUUsQ0FBQyxLQUFLLEVBQUUsQ0FBQyxJQUFJLENBQUM7Z0JBQy9CLElBQUksUUFBUSxHQUFHLEVBQUUsQ0FBQyxLQUFLLEVBQUUsQ0FBQyxJQUFJLENBQUM7Z0JBRS9CLElBQUksUUFBUSxHQUFHLEVBQUUsQ0FBQztnQkFDbEIsSUFBSSxRQUFRLEdBQUcsRUFBRSxDQUFDO2dCQUNsQixJQUFJLEtBQUssR0FBRyxFQUFFLENBQUM7Z0JBRWY7OzttQkFHRztnQkFDSCxpQ0FBaUMsRUFBRSxFQUFFLEVBQUU7b0JBQ3JDLElBQUksSUFBSSxHQUFHLEVBQUUsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxFQUNuQyxJQUFJLEdBQUcsRUFBRSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUM7b0JBRXBDLG9CQUFvQjtvQkFDcEIsSUFBSSxRQUFRLENBQUMsSUFBSSxDQUFDLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxFQUFFO3dCQUNuQyxPQUFPLENBQUMsSUFBSSxDQUNSLHlCQUF5QixFQUFFLEdBQUcsR0FBRyxRQUFRLEdBQUcsR0FBRyxFQUFFLElBQUksRUFDckQsR0FBRyxHQUFHLFFBQVEsR0FBRyxHQUFHLEVBQUUsSUFBSSxDQUFDLENBQUM7d0JBQ2hDLE9BQU8sSUFBSSxDQUFDO3FCQUNiO29CQUNELG1CQUFtQjtvQkFDbkIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsRUFBRSxFQUFFLDZCQUE2Qjt3QkFDbEQsUUFBUSxDQUFDLElBQUksQ0FBQyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsR0FBRyxJQUFJLENBQUM7d0JBQ3ZDLEtBQUssQ0FBQyxJQUFJLENBQUMsRUFBQyxFQUFFLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLEVBQUMsQ0FBQyxDQUFDO3FCQUM5QjtvQkFFRCxPQUFPLEtBQUssQ0FBQztnQkFDZixDQUFDO2dCQUVELHFEQUFxRDtnQkFDckQsSUFBSSxRQUFRLEdBQUcsRUFBRSxDQUFDLE9BQU8sRUFBRSxDQUFDO2dCQUM1QixJQUFJLFFBQVEsR0FBRyxFQUFFLENBQUMsT0FBTyxFQUFFLENBQUM7Z0JBQzVCLElBQUksUUFBUSxDQUFDLE1BQU0sS0FBSyxRQUFRLENBQUMsTUFBTSxFQUFFO29CQUN2QyxvQkFBb0I7b0JBQ3BCLE9BQU8sQ0FBQyxHQUFHLENBQUMseUJBQXlCLENBQUMsQ0FBQztvQkFDdkMsbUJBQW1CO29CQUNuQixPQUFPLEtBQUssQ0FBQztpQkFDZDtnQkFDRCxRQUFRLEdBQUcsU0FBUyxDQUFDLFFBQVEsRUFBRSxFQUFFLEVBQUUsUUFBUSxDQUFDLENBQUM7Z0JBQzdDLFFBQVEsR0FBRyxTQUFTLENBQUMsUUFBUSxFQUFFLEVBQUUsRUFBRSxRQUFRLENBQUMsQ0FBQztnQkFFN0MsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFFBQVEsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7b0JBQ3hDLElBQUksU0FBUyxHQUFHLHVCQUF1QixDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsRUFBRSxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDbEUsSUFBSSxTQUFTLEVBQUU7d0JBQ1gsT0FBTyxLQUFLLENBQUM7cUJBQ2hCO2lCQUNGO2dCQUVELE9BQU8sS0FBSyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7b0JBQ3ZCLElBQUksR0FBRyxHQUFHLEtBQUssQ0FBQyxHQUFHLEVBQUUsQ0FBQztvQkFFdEIsYUFBYTtvQkFDYixJQUFJLE9BQU8sR0FBRyxhQUFhLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztvQkFDOUQsSUFBSSxDQUFDLE9BQU8sRUFBRTt3QkFDVixPQUFPLEtBQUssQ0FBQztxQkFDaEI7b0JBRUQsd0RBQXdEO29CQUN4RCxJQUFJLEtBQUssR0FBRyxFQUFFLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsRUFBRSxLQUFLLEdBQUcsRUFBRSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUM7b0JBQ2pFLElBQUksS0FBSyxDQUFDLE1BQU0sS0FBSyxLQUFLLENBQUMsTUFBTSxFQUFFO3dCQUNqQyxvQkFBb0I7d0JBQ3BCLE9BQU8sQ0FBQyxHQUFHLENBQUMsMEJBQTBCLEVBQUUsS0FBSyxFQUFFLEtBQUssQ0FBQyxDQUFDO3dCQUN0RCxtQkFBbUI7d0JBQ25CLE9BQU8sS0FBSyxDQUFDO3FCQUNkO29CQUNELEtBQUssR0FBRyxTQUFTLENBQUMsS0FBSyxFQUFFLEVBQUUsRUFBRSxRQUFRLENBQUMsQ0FBQztvQkFDdkMsS0FBSyxHQUFHLFNBQVMsQ0FBQyxLQUFLLEVBQUUsRUFBRSxFQUFFLFFBQVEsQ0FBQyxDQUFDO29CQUV2QyxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTt3QkFDckMsSUFBSSxTQUFTLEdBQUcsdUJBQXVCLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUM1RCxJQUFJLFNBQVMsRUFBRTs0QkFDWCxPQUFPLEtBQUssQ0FBQzt5QkFDaEI7cUJBQ0Y7aUJBQ0Y7Z0JBRUQsT0FBTyxJQUFJLENBQUM7WUFDZCxDQUFDO1lBRUQ7O2VBRUc7WUFDSCx1QkFBdUIsRUFBOEIsRUFDakQsRUFBOEI7Z0JBQ2hDLElBQUksRUFBRSxDQUFDLElBQUksS0FBSyxRQUFBLFFBQVEsQ0FBQyxJQUFJLEVBQUU7b0JBQzdCLG1CQUFtQjtvQkFDbkIsSUFBSSxTQUFTLEdBQWMsRUFBRSxDQUFDO29CQUM5QixJQUFJLFNBQVMsR0FBYyxFQUFFLENBQUM7b0JBQzlCLE9BQU8sU0FBUyxDQUFDLFVBQVUsSUFBSSxTQUFTLENBQUMsVUFBVTt3QkFDL0MsU0FBUyxDQUFDLFVBQVUsS0FBSyxTQUFTLENBQUMsVUFBVSxDQUFDO2lCQUNuRDtxQkFBTSxJQUFJLEVBQUUsQ0FBQyxJQUFJLEtBQUssUUFBQSxRQUFRLENBQUMsRUFBRSxJQUFJLEVBQUUsQ0FBQyxJQUFJLEtBQUssUUFBQSxRQUFRLENBQUMsRUFBRSxFQUFFO29CQUM3RCxvQkFBb0I7b0JBQ3BCLE9BQWdCLEVBQUcsQ0FBQyxFQUFFLEtBQWMsRUFBRyxDQUFDLEVBQUUsQ0FBQztpQkFDNUM7cUJBQU0sSUFBSSxFQUFFLENBQUMsSUFBSSxLQUFLLFFBQUEsUUFBUSxDQUFDLE1BQU0sSUFBSSxFQUFFLENBQUMsSUFBSSxLQUFLLFFBQUEsUUFBUSxDQUFDLE1BQU0sRUFBRTtvQkFDckUsMkNBQTJDO29CQUMzQyxzRUFBc0U7b0JBQ3RFLElBQUksR0FBRyxHQUFnQixFQUFFLENBQUM7b0JBQzFCLElBQUksR0FBRyxHQUFnQixFQUFFLENBQUM7b0JBQzFCLElBQUksZ0JBQWdCLEdBQUcsR0FBRyxDQUFDLFNBQVMsQ0FBQyxTQUFTLEVBQUUsQ0FBQztvQkFDakQsT0FBTyxDQUFDLGdCQUFnQixLQUFLLEdBQUcsQ0FBQyxTQUFTLENBQUMsU0FBUyxFQUFFO3dCQUNwRCxDQUFDLGdCQUFnQixLQUFLLENBQUM7NEJBQ3ZCLENBQVUsR0FBRyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxLQUFLLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBRSxDQUFDLEVBQUU7Z0NBQzdDLEdBQUcsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7aUJBQ3BFO2dCQUNELE9BQU8sS0FBSyxDQUFDO1lBQ2YsQ0FBQztRQUNELENBQUMsRUE1UmUsUUFBUSxHQUFSLGdCQUFRLEtBQVIsZ0JBQVEsUUE0UnZCO0lBQUQsQ0FBQyxFQTVSUyxLQUFLLEdBQUwsUUFBSyxLQUFMLFFBQUssUUE0UmQ7QUFBRCxDQUFDLEVBNVJNLEVBQUUsS0FBRixFQUFFLFFBNFJSIiwic291cmNlc0NvbnRlbnQiOlsiLyogQ29weXJpZ2h0IDIwMTUgVGhlIFRlbnNvckZsb3cgQXV0aG9ycy4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cblxuTGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlLCBWZXJzaW9uIDIuMCAodGhlICdMaWNlbnNlJyk7XG55b3UgbWF5IG5vdCB1c2UgdGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlIHdpdGggdGhlIExpY2Vuc2UuXG5Zb3UgbWF5IG9idGFpbiBhIGNvcHkgb2YgdGhlIExpY2Vuc2UgYXRcblxuICAgIGh0dHA6Ly93d3cuYXBhY2hlLm9yZy9saWNlbnNlcy9MSUNFTlNFLTIuMFxuXG5Vbmxlc3MgcmVxdWlyZWQgYnkgYXBwbGljYWJsZSBsYXcgb3IgYWdyZWVkIHRvIGluIHdyaXRpbmcsIHNvZnR3YXJlXG5kaXN0cmlidXRlZCB1bmRlciB0aGUgTGljZW5zZSBpcyBkaXN0cmlidXRlZCBvbiBhbiAnQVMgSVMnIEJBU0lTLFxuV0lUSE9VVCBXQVJSQU5USUVTIE9SIENPTkRJVElPTlMgT0YgQU5ZIEtJTkQsIGVpdGhlciBleHByZXNzIG9yIGltcGxpZWQuXG5TZWUgdGhlIExpY2Vuc2UgZm9yIHRoZSBzcGVjaWZpYyBsYW5ndWFnZSBnb3Zlcm5pbmcgcGVybWlzc2lvbnMgYW5kXG5saW1pdGF0aW9ucyB1bmRlciB0aGUgTGljZW5zZS5cbj09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSovXG5tb2R1bGUgdGYuZ3JhcGgudGVtcGxhdGUge1xuXG4vKipcbiAqIERldGVjdCByZXBlYXRpbmcgcGF0dGVybnMgb2Ygc3ViZ3JhcGhzLlxuICogQXNzaWduIHRlbXBsYXRlSWQgdG8gZWFjaCBzdWJncmFwaCBpZiBpdCBiZWxvbmdzIHRvIGEgdGVtcGxhdGUuXG4gKiBSZXR1cm5zIGNsdXN0ZXJzIG9mIHNpbWlsYXIgc3ViZ3JhcGhzIC5cbiAqXG4gKiBAcGFyYW0gZ3JhcGhcbiAqIEBwYXJhbSB2ZXJpZnlUZW1wbGF0ZSB3aGV0aGVyIHRvIHJ1biB0aGUgdGVtcGxhdGUgdmVyaWZpY2F0aW9uIGFsZ29yaXRobVxuICogQHJldHVybiBhIGRpY3QgKHRlbXBsYXRlIGlkID0+IEFycmF5IG9mIG5vZGUgbmFtZXMpXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBkZXRlY3QoaCwgdmVyaWZ5VGVtcGxhdGUpOiB7W3RlbXBsYXRlSWQ6IHN0cmluZ106IHN0cmluZ1tdfSB7XG4gIC8vIEluIGFueSBwYXJ0aWN1bGFyIHN1YmdyYXBoLCB0aGVyZSBhcmUgZWl0aGVyXG4gIC8vIC0gbGVhZiBub2RlcyAod2hpY2ggZG8gbm90IGhhdmUgc3ViZ3JhcGgpXG4gIC8vIC0gbWV0YW5vZGUgbm9kZXMgLSBzb21lIG9mIHRoZW0gaGF2ZSBvbmx5IG9uZSBtZW1iZXIgKHNpbmd1bGFyIG1ldGFub2RlKVxuICAvLyAgICAgICAgICAgICAgICAgICAgYW5kIHNvbWUgaGF2ZSBtdWx0aXBsZSBtZW1iZXJzIChub24tc2luZ3VsYXIgbWV0YW5vZGUpXG5cbiAgLy8gRmlyc3QsIGdlbmVyYXRlIGEgbmVhcmVzdCBuZWlnaGJvciBoYXNoIG9mIG1ldGFub2RlIG5vZGVzLlxuICBsZXQgbm5Hcm91cHMgPSBjbHVzdGVyU2ltaWxhclN1YmdyYXBocyhoKTtcblxuICAvLyBGb3IgZWFjaCBtZXRhbm9kZSwgY29tcGFyZSBpdHMgc3ViZ3JhcGggKHN0YXJ0aW5nIGZyb20gc2hhbGxvd2VyIGdyb3VwcylcbiAgLy8gYW5kIGFzc2lnbiB0ZW1wbGF0ZSBpZC5cbiAgbGV0IHRlbXBsYXRlcyA9IGdyb3VwVGVtcGxhdGVBbmRBc3NpZ25JZChubkdyb3VwcywgdmVyaWZ5VGVtcGxhdGUpO1xuXG4gIC8vIFNvcnQgdGhlIHRlbXBsYXRlcyBieSBtaW5pbXVtIGxldmVsIGluIHRoZSBncmFwaCBhdCB3aGljaCB0aGV5IGFwcGVhcixcbiAgLy8gYXMgdGhpcyBsZWFkcyB0byBvcHRpbWFsIHNldHRpbmcgb2YgdGhlIGNvbG9ycyBvZiBlYWNoIHRlbXBsYXRlIGZvclxuICAvLyBtYXhpbXVtIGRpZmZlcmVudGlhdGlvbi5cbiAgcmV0dXJuIDx7W3RlbXBsYXRlSWQ6IHN0cmluZ106IHN0cmluZ1tdfT5PYmplY3Qua2V5cyh0ZW1wbGF0ZXMpXG4gICAgICAuc29ydChrZXkgPT4gdGVtcGxhdGVzW2tleV0ubGV2ZWwpXG4gICAgICAucmVkdWNlKChvYmosIGtleSkgPT4ge1xuICAgICAgICBvYmpba2V5XSA9IHRlbXBsYXRlc1trZXldO1xuICAgICAgICByZXR1cm4gb2JqO1xuICAgICAgfSwge30pO1xufTtcblxuLyoqXG4gKiBAcmV0dXJuIFVuaXF1ZSBzdHJpbmcgZm9yIGEgbWV0YW5vZGUgYmFzZWQgb24gZGVwdGgsIHxWfCwgfEV8IGFuZFxuICogb3AgdHlwZSBoaXN0b2dyYW0uXG4gKi9cbmZ1bmN0aW9uIGdldFNpZ25hdHVyZShtZXRhbm9kZSkge1xuICAvLyBkZXB0aD08bnVtYmVyPiB8Vnw9PG51bWJlcj4gfEV8PTxudW1iZXI+XG4gIGxldCBwcm9wcyA9IF8ubWFwKFxuICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICdkZXB0aCc6IG1ldGFub2RlLmRlcHRoLFxuICAgICAgICAgICAgICAgICAgICAgJ3xWfCc6IG1ldGFub2RlLm1ldGFncmFwaC5ub2RlcygpLmxlbmd0aCxcbiAgICAgICAgICAgICAgICAgICAgICd8RXwnOiBtZXRhbm9kZS5tZXRhZ3JhcGguZWRnZXMoKS5sZW5ndGhcbiAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgIGZ1bmN0aW9uKHYsIGspIHsgcmV0dXJuIGsgKyAnPScgKyB2OyB9KVxuICAgICAgICAgICAgICAgICAgLmpvaW4oJyAnKTtcblxuICAvLyBvcHR5cGUxPWNvdW50MSxvcHR5cGUyPWNvdW50MlxuICBsZXQgb3BzID0gXy5tYXAobWV0YW5vZGUub3BIaXN0b2dyYW0sIGZ1bmN0aW9uKGNvdW50LCBvcCkge1xuICAgICAgICAgICAgICAgcmV0dXJuIG9wICsgJz0nICsgY291bnQ7XG4gICAgICAgICAgICAgfSkuam9pbignLCcpO1xuXG4gIHJldHVybiBwcm9wcyArICcgW29wc10gJyArIG9wcztcbn1cblxuLyoqXG4gKiBHZW5lcmF0ZSBhIG5lYXJlc3QgbmVpZ2hib3IgaGFzaCBvZiBtZXRhbm9kZXNcbiAqIGJhc2VkIG9uIGRlcHRoLCB8VnwsIHxFfCwgYW5kIG9wSGlzdG9ncmFtIG9mIHRoZWlyIHN1YmdyYXBoXG4gKiAoZXhjbHVkaW5nIGxlYWYgbm9kZXMgYW5kIHNpbmd1bGFyIG1ldGFub2RlcykuXG4gKiBAcGFyYW0gZ3JhcGggVGhlIGdyYXBoXG4gKiBAcmV0dXJuIEFycmF5IG9mIHBhaXJzIG9mIFtzaWduYXR1cmUsXG4gKiAgIE9iamVjdCB3aXRoIG1pbiBsZXZlbCBvZiB0aGUgdGVtcGxhdGUgYW5kIGFuIEFycmF5IG9mIHRmLmdyYXBoLkdyb3VwXVxuICogICBzb3J0IGJ5IGFzY2VuZGluZyBvcmRlciBvZiBtaW5pbXVtIGRlcHRoIGF0IHdoaWNoIG1ldGFub2RlIGFwcGVhcnMuXG4gKi9cbmZ1bmN0aW9uIGNsdXN0ZXJTaW1pbGFyU3ViZ3JhcGhzKGg6IGhpZXJhcmNoeS5IaWVyYXJjaHkpIHtcbiAgLyoqIGEgZGljdCBmcm9tIG1ldGFub2RlLnNpZ25hdHVyZSgpID0+IEFycmF5IG9mIHRmLmdyYXBoLkdyb3VwcyAqL1xuICBsZXQgaGFzaERpY3QgPSBfKGguZ2V0Tm9kZU1hcCgpKS5yZWR1Y2UoXG4gICAgICAoaGFzaCwgbm9kZTogT3BOb2RlfE1ldGFub2RlLCBuYW1lKSA9PiB7XG4gICAgaWYgKG5vZGUudHlwZSAhPT0gTm9kZVR5cGUuTUVUQSkge1xuICAgICAgcmV0dXJuIGhhc2g7XG4gICAgfVxuICAgIGxldCBsZXZlbE9mTWV0YU5vZGUgPSBuYW1lLnNwbGl0KCcvJykubGVuZ3RoIC0gMTtcbiAgICBsZXQgc2lnbmF0dXJlID0gZ2V0U2lnbmF0dXJlKG5vZGUpO1xuICAgIGxldCB0ZW1wbGF0ZUluZm8gPSBoYXNoW3NpZ25hdHVyZV0gfHxcbiAgICAgIHtub2RlczogW10sIGxldmVsOiBsZXZlbE9mTWV0YU5vZGV9O1xuICAgIGhhc2hbc2lnbmF0dXJlXSA9IHRlbXBsYXRlSW5mbztcbiAgICB0ZW1wbGF0ZUluZm8ubm9kZXMucHVzaChub2RlKTtcbiAgICBpZiAodGVtcGxhdGVJbmZvLmxldmVsID4gbGV2ZWxPZk1ldGFOb2RlKSB7XG4gICAgICB0ZW1wbGF0ZUluZm8ubGV2ZWwgPSBsZXZlbE9mTWV0YU5vZGU7XG4gICAgfVxuICAgIHJldHVybiBoYXNoO1xuICB9LCB7fSk7XG5cbiAgcmV0dXJuIE9iamVjdC5rZXlzKGhhc2hEaWN0KVxuICAgICAgLm1hcChrZXkgPT4gW2tleSwgaGFzaERpY3Rba2V5XV0pXG4gICAgICAuZmlsdGVyKChbXywgc3ViR3JhcGhdKSA9PiB7XG4gICAgICAgIGNvbnN0IHtub2Rlc30gPSBzdWJHcmFwaDtcbiAgICAgICAgaWYgKG5vZGVzLmxlbmd0aCA+IDEpIHtcbiAgICAgICAgICAvLyBUaGVyZSBpcyBtb3JlIHRoYW4gMSBub2RlIHdpdGggdGhpcyB0ZW1wbGF0ZS4gSXQgaXMgd29ydGggYXNzaWduaW5nXG4gICAgICAgICAgLy8gYSB1bmlxdWUgY29sb3IgdG8gdGhpcyB0ZW1wbGF0ZS5cbiAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIElmIHRoZXJlIGlzIG9ubHkgMSBub2RlIHdpdGggdGhpcyB0ZW1wbGF0ZSwgb25seSBtYWtlIGEgdGVtcGxhdGUgZm9yXG4gICAgICAgIC8vIGl0IGlmIGl0IHJlcHJlc2VudHMgYSBmdW5jdGlvbi4gSW4gdGhhdCBjYXNlLCB0aGUgZ3JhcGggZXhwbG9yZXIgbWF5XG4gICAgICAgIC8vIGFkZCBtb3JlIG5vZGVzIHdpdGggdGhlIHRlbXBsYXRlIGxhdGVyLlxuICAgICAgICBjb25zdCBub2RlID0gbm9kZXNbMF07XG4gICAgICAgIHJldHVybiBub2RlLnR5cGUgPT09IE5vZGVUeXBlLk1FVEEgJiZcbiAgICAgICAgICAgIChub2RlIGFzIE1ldGFub2RlKS5hc3NvY2lhdGVkRnVuY3Rpb247XG4gICAgICB9KVxuICAgICAgLnNvcnQoKFtfLCBzdWJHcmFwaF0pID0+IHtcbiAgICAgICAgLy8gc29ydCBieSBkZXB0aFxuICAgICAgICAvLyAoYWxsIG1lbWJlcnMgaW4gdGhlIHNhbWUgbm5Hcm91cCBoYXMgZXF1YWwgZGVwdGgpXG4gICAgICAgIHJldHVybiBzdWJHcmFwaC5ub2Rlc1swXS5kZXB0aDtcbiAgICAgIH0pO1xufVxuXG5mdW5jdGlvbiBncm91cFRlbXBsYXRlQW5kQXNzaWduSWQobm5Hcm91cHMsIHZlcmlmeVRlbXBsYXRlKSB7XG4gIC8vIEZvciBlYWNoIG1ldGFub2RlLCBjb21wYXJlIGl0cyBzdWJncmFwaCAoc3RhcnRpbmcgZnJvbSBzaGFsbG93ZXIgZ3JvdXBzKVxuICAvLyBhbmQgYXNzaWduIHRlbXBsYXRlIGlkLlxuICBsZXQgcmVzdWx0OiB7W3RlbXBsYXRlSWQ6IHN0cmluZ106IHtsZXZlbDogbnVtYmVyLCBub2Rlczogc3RyaW5nW119fSA9IHt9O1xuICByZXR1cm4gXy5yZWR1Y2Uobm5Hcm91cHMsIGZ1bmN0aW9uKHRlbXBsYXRlcywgbm5Hcm91cFBhaXIpIHtcbiAgICBsZXQgc2lnbmF0dXJlID0gbm5Hcm91cFBhaXJbMF0sXG4gICAgICBubkdyb3VwID0gbm5Hcm91cFBhaXJbMV0ubm9kZXMsXG4gICAgICBjbHVzdGVycyA9IFtdO1xuXG4gICAgbm5Hcm91cC5mb3JFYWNoKGZ1bmN0aW9uKG1ldGFub2RlKSB7XG4gICAgICAvLyBjaGVjayB3aXRoIGVhY2ggZXhpc3RpbmcgY2x1c3RlclxuICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBjbHVzdGVycy5sZW5ndGg7IGkrKykge1xuICAgICAgICBsZXQgc2ltaWxhciA9ICF2ZXJpZnlUZW1wbGF0ZSB8fFxuICAgICAgICAgICAgICAgICAgICAgIGlzU2ltaWxhclN1YmdyYXBoKFxuICAgICAgICAgICAgICAgICAgICAgICAgY2x1c3RlcnNbaV0ubWV0YW5vZGUubWV0YWdyYXBoLFxuICAgICAgICAgICAgICAgICAgICAgICAgbWV0YW5vZGUubWV0YWdyYXBoXG4gICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgLy8gaWYgc2ltaWxhciwganVzdCBhZGQgdGhpcyBtZXRhbm9kZSB0byB0aGUgY2x1c3RlclxuICAgICAgICBpZiAoc2ltaWxhcikge1xuICAgICAgICAgIC8vIGdldCB0ZW1wbGF0ZSBmcm9tIHRoZSBmaXJzdCBvbmVcbiAgICAgICAgICBtZXRhbm9kZS50ZW1wbGF0ZUlkID0gY2x1c3RlcnNbaV0ubWV0YW5vZGUudGVtcGxhdGVJZDtcbiAgICAgICAgICBjbHVzdGVyc1tpXS5tZW1iZXJzLnB1c2gobWV0YW5vZGUubmFtZSk7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICAvLyBvdGhlcndpc2UgY3JlYXRlIGEgbmV3IGNsdXN0ZXIgd2l0aCBpZCAnc2lnbmF0dXJlIFtjb3VudF0gJ1xuICAgICAgbWV0YW5vZGUudGVtcGxhdGVJZCA9IHNpZ25hdHVyZSArICdbJyArIGNsdXN0ZXJzLmxlbmd0aCArICddJztcbiAgICAgIGNsdXN0ZXJzLnB1c2goe1xuICAgICAgICBtZXRhbm9kZTogbWV0YW5vZGUsXG4gICAgICAgIG1lbWJlcnM6IFttZXRhbm9kZS5uYW1lXVxuICAgICAgfSk7XG4gICAgfSk7XG5cbiAgICBjbHVzdGVycy5mb3JFYWNoKGZ1bmN0aW9uKGMpIHtcbiAgICAgIHRlbXBsYXRlc1tjLm1ldGFub2RlLnRlbXBsYXRlSWRdID0ge1xuICAgICAgICBsZXZlbDogbm5Hcm91cFBhaXJbMV0ubGV2ZWwsXG4gICAgICAgIG5vZGVzOiBjLm1lbWJlcnNcbiAgICAgIH07XG4gICAgfSk7XG4gICAgcmV0dXJuIHRlbXBsYXRlcztcbiAgfSwgcmVzdWx0KTtcbn1cblxuZnVuY3Rpb24gc29ydE5vZGVzKG5hbWVzOiBzdHJpbmdbXSxcbiAgICBncmFwaDogZ3JhcGhsaWIuR3JhcGg8TWV0YW5vZGV8T3BOb2RlLCBNZXRhZWRnZT4sIHByZWZpeDogc3RyaW5nKSB7XG4gIHJldHVybiBfLnNvcnRCeShuYW1lcyxcbiAgICAgIFtcbiAgICAgICAgKG5hbWUpID0+IChncmFwaC5ub2RlKG5hbWUpIGFzIE9wTm9kZSkub3AsXG4gICAgICAgIChuYW1lKSA9PiAoZ3JhcGgubm9kZShuYW1lKSBhcyBNZXRhbm9kZSkudGVtcGxhdGVJZCxcbiAgICAgICAgKG5hbWUpID0+IGdyYXBoLm5laWdoYm9ycyhuYW1lKS5sZW5ndGgsXG4gICAgICAgIChuYW1lKSA9PiBncmFwaC5wcmVkZWNlc3NvcnMobmFtZSkubGVuZ3RoLFxuICAgICAgICAobmFtZSkgPT4gZ3JhcGguc3VjY2Vzc29ycyhuYW1lKS5sZW5ndGgsXG4gICAgICAgIChuYW1lKSA9PiBuYW1lLnN1YnN0cihwcmVmaXgubGVuZ3RoKSxcbiAgICBdKTtcbn1cblxuZnVuY3Rpb24gaXNTaW1pbGFyU3ViZ3JhcGgoZzE6IGdyYXBobGliLkdyYXBoPGFueSwgYW55PixcbiAgICBnMjogZ3JhcGhsaWIuR3JhcGg8YW55LCBhbnk+KSB7XG4gIGlmICghdGYuZ3JhcGguaGFzU2ltaWxhckRlZ3JlZVNlcXVlbmNlKGcxLCBnMikpIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgfVxuXG4gIC8vIGlmIHdlIHdhbnQgdG8gc2tpcCwganVzdCByZXR1cm4gdHJ1ZSBoZXJlLlxuICAvLyByZXR1cm4gdHJ1ZTtcblxuICAvLyBWZXJpZnkgc2VxdWVuY2UgYnkgcnVubmluZyBERlNcbiAgbGV0IGcxcHJlZml4ID0gZzEuZ3JhcGgoKS5uYW1lO1xuICBsZXQgZzJwcmVmaXggPSBnMi5ncmFwaCgpLm5hbWU7XG5cbiAgbGV0IHZpc2l0ZWQxID0ge307XG4gIGxldCB2aXNpdGVkMiA9IHt9O1xuICBsZXQgc3RhY2sgPSBbXTtcblxuICAvKipcbiAgICogcHVzaCBzb3VyY2VzIG9yIHN1Y2Nlc3NvcnMgaW50byB0aGUgc3RhY2tcbiAgICogaWYgdGhlIHZpc2l0aW5nIHBhdHRlcm4gaGFzIGJlZW4gc2ltaWxhci5cbiAgICovXG4gIGZ1bmN0aW9uIHN0YWNrUHVzaElmTm90RGlmZmVyZW50KG4xLCBuMikge1xuICAgIGxldCBzdWIxID0gbjEuc3Vic3RyKGcxcHJlZml4Lmxlbmd0aCksXG4gICAgICBzdWIyID0gbjIuc3Vic3RyKGcycHJlZml4Lmxlbmd0aCk7XG5cbiAgICAvKiB0c2xpbnQ6ZGlzYWJsZSAqL1xuICAgIGlmICh2aXNpdGVkMVtzdWIxXSBeIHZpc2l0ZWQyW3N1YjJdKSB7XG4gICAgICBjb25zb2xlLndhcm4oXG4gICAgICAgICAgJ2RpZmZlcmVudCB2aXNpdCBwYXR0ZXJuJywgJ1snICsgZzFwcmVmaXggKyAnXScsIHN1YjEsXG4gICAgICAgICAgJ1snICsgZzJwcmVmaXggKyAnXScsIHN1YjIpO1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIC8qIHRzbGludDplbmFibGUgKi9cbiAgICBpZiAoIXZpc2l0ZWQxW3N1YjFdKSB7IC8vIGltcGxpZWQgJiYgIXZpc2l0ZWQyW3N1YjJdXG4gICAgICB2aXNpdGVkMVtzdWIxXSA9IHZpc2l0ZWQyW3N1YjJdID0gdHJ1ZTtcbiAgICAgIHN0YWNrLnB1c2goe24xOiBuMSwgbjI6IG4yfSk7XG4gICAgfVxuXG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG5cbiAgLy8gY2hlY2sgaWYgaGF2ZSBzYW1lICMgb2Ygc291cmNlcyB0aGVuIHNvcnQgYW5kIHB1c2hcbiAgbGV0IHNvdXJjZXMxID0gZzEuc291cmNlcygpO1xuICBsZXQgc291cmNlczIgPSBnMi5zb3VyY2VzKCk7XG4gIGlmIChzb3VyY2VzMS5sZW5ndGggIT09IHNvdXJjZXMyLmxlbmd0aCkge1xuICAgIC8qIHRzbGludDpkaXNhYmxlICovXG4gICAgY29uc29sZS5sb2coJ2RpZmZlcmVudCBzb3VyY2UgbGVuZ3RoJyk7XG4gICAgLyogdHNsaW50OmVuYWJsZSAqL1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBzb3VyY2VzMSA9IHNvcnROb2Rlcyhzb3VyY2VzMSwgZzEsIGcxcHJlZml4KTtcbiAgc291cmNlczIgPSBzb3J0Tm9kZXMoc291cmNlczIsIGcyLCBnMnByZWZpeCk7XG5cbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBzb3VyY2VzMS5sZW5ndGg7IGkrKykge1xuICAgIGxldCBkaWZmZXJlbnQgPSBzdGFja1B1c2hJZk5vdERpZmZlcmVudChzb3VyY2VzMVtpXSwgc291cmNlczJbaV0pO1xuICAgIGlmIChkaWZmZXJlbnQpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgfVxuXG4gIHdoaWxlIChzdGFjay5sZW5ndGggPiAwKSB7XG4gICAgbGV0IGN1ciA9IHN0YWNrLnBvcCgpO1xuXG4gICAgLy8gY2hlY2sgbm9kZVxuICAgIGxldCBzaW1pbGFyID0gaXNTaW1pbGFyTm9kZShnMS5ub2RlKGN1ci5uMSksIGcyLm5vZGUoY3VyLm4yKSk7XG4gICAgaWYgKCFzaW1pbGFyKSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG5cbiAgICAvLyBjaGVjayBpZiBoYXZlIHNhbWUgIyBvZiBzdWNjZXNzb3JzIHRoZW4gc29ydCBhbmQgcHVzaFxuICAgIGxldCBzdWNjMSA9IGcxLnN1Y2Nlc3NvcnMoY3VyLm4xKSwgc3VjYzIgPSBnMi5zdWNjZXNzb3JzKGN1ci5uMik7XG4gICAgaWYgKHN1Y2MxLmxlbmd0aCAhPT0gc3VjYzIubGVuZ3RoKSB7XG4gICAgICAvKiB0c2xpbnQ6ZGlzYWJsZSAqL1xuICAgICAgY29uc29sZS5sb2coJyMgb2Ygc3VjY2Vzc29ycyBtaXNtYXRjaCcsIHN1Y2MxLCBzdWNjMik7XG4gICAgICAvKiB0c2xpbnQ6ZW5hYmxlICovXG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIHN1Y2MxID0gc29ydE5vZGVzKHN1Y2MxLCBnMSwgZzFwcmVmaXgpO1xuICAgIHN1Y2MyID0gc29ydE5vZGVzKHN1Y2MyLCBnMiwgZzJwcmVmaXgpO1xuXG4gICAgZm9yIChsZXQgaiA9IDA7IGogPCBzdWNjMS5sZW5ndGg7IGorKykge1xuICAgICAgbGV0IGRpZmZlcmVudCA9IHN0YWNrUHVzaElmTm90RGlmZmVyZW50KHN1Y2MxW2pdLCBzdWNjMltqXSk7XG4gICAgICBpZiAoZGlmZmVyZW50KSB7XG4gICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIHJldHVybiB0cnVlO1xufVxuXG4vKipcbiAqIFJldHVybnMgaWYgdHdvIG5vZGVzIGhhdmUgaWRlbnRpY2FsIHN0cnVjdHVyZS5cbiAqL1xuZnVuY3Rpb24gaXNTaW1pbGFyTm9kZShuMTogT3BOb2RlfE1ldGFub2RlfFNlcmllc05vZGUsXG4gICAgbjI6IE9wTm9kZXxNZXRhbm9kZXxTZXJpZXNOb2RlKTogYm9vbGVhbiB7XG4gIGlmIChuMS50eXBlID09PSBOb2RlVHlwZS5NRVRBKSB7XG4gICAgLy8gY29tcGFyZSBtZXRhbm9kZVxuICAgIGxldCBtZXRhbm9kZTEgPSA8TWV0YW5vZGU+IG4xO1xuICAgIGxldCBtZXRhbm9kZTIgPSA8TWV0YW5vZGU+IG4yO1xuICAgIHJldHVybiBtZXRhbm9kZTEudGVtcGxhdGVJZCAmJiBtZXRhbm9kZTIudGVtcGxhdGVJZCAmJlxuICAgICAgICBtZXRhbm9kZTEudGVtcGxhdGVJZCA9PT0gbWV0YW5vZGUyLnRlbXBsYXRlSWQ7XG4gIH0gZWxzZSBpZiAobjEudHlwZSA9PT0gTm9kZVR5cGUuT1AgJiYgbjIudHlwZSA9PT0gTm9kZVR5cGUuT1ApIHtcbiAgICAvLyBjb21wYXJlIGxlYWYgbm9kZVxuICAgIHJldHVybiAoPE9wTm9kZT5uMSkub3AgPT09ICg8T3BOb2RlPm4yKS5vcDtcbiAgfSBlbHNlIGlmIChuMS50eXBlID09PSBOb2RlVHlwZS5TRVJJRVMgJiYgbjIudHlwZSA9PT0gTm9kZVR5cGUuU0VSSUVTKSB7XG4gICAgLy8gY29tcGFyZSBzZXJpZXMgbm9kZSBzaXplcyBhbmQgb3BlcmF0aW9uc1xuICAgIC8vIChvbmx5IG5lZWQgdG8gY2hlY2sgb25lIG9wIGFzIGFsbCBvcCBub2RlcyBhcmUgaWRlbnRpY2FsIGluIHNlcmllcylcbiAgICBsZXQgc24xID0gPFNlcmllc05vZGU+IG4xO1xuICAgIGxldCBzbjIgPSA8U2VyaWVzTm9kZT4gbjI7XG4gICAgbGV0IHNlcmllc25vZGUxQ291bnQgPSBzbjEubWV0YWdyYXBoLm5vZGVDb3VudCgpO1xuICAgIHJldHVybiAoc2VyaWVzbm9kZTFDb3VudCA9PT0gc24yLm1ldGFncmFwaC5ub2RlQ291bnQoKSAmJlxuICAgICAgKHNlcmllc25vZGUxQ291bnQgPT09IDAgfHxcbiAgICAgICgoPE9wTm9kZT5zbjEubWV0YWdyYXBoLm5vZGUoc24xLm1ldGFncmFwaC5ub2RlcygpWzBdKSkub3AgPT09XG4gICAgICAgICAgKDxPcE5vZGU+c24yLm1ldGFncmFwaC5ub2RlKHNuMi5tZXRhZ3JhcGgubm9kZXMoKVswXSkpLm9wKSkpO1xuICB9XG4gIHJldHVybiBmYWxzZTtcbn1cbn1cbiJdfQ==