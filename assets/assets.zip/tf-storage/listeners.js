/* Copyright 2018 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
var tf_storage;
(function (tf_storage) {
    // TODO(stephanwlee): Combine this with tf_backend.ListenKey and put it in a
    // sensible place.
    // A unique reference to a listener for an easier dereferencing.
    var ListenKey = /** @class */ (function () {
        function ListenKey(listener) {
            this.listener = listener;
        }
        return ListenKey;
    }());
    tf_storage.ListenKey = ListenKey;
    var hashListeners = new Set();
    var storageListeners = new Set();
    window.addEventListener('hashchange', function () {
        hashListeners.forEach(function (listenKey) { return listenKey.listener(); });
    });
    // [1]: The event only triggers when another tab edits the storage. Changing a
    // value in current browser tab will NOT trigger below event.
    window.addEventListener('storage', function () {
        storageListeners.forEach(function (listenKey) { return listenKey.listener(); });
    });
    function addHashListener(fn) {
        var key = new ListenKey(fn);
        hashListeners.add(key);
        return key;
    }
    tf_storage.addHashListener = addHashListener;
    function addStorageListener(fn) {
        var key = new ListenKey(fn);
        storageListeners.add(key);
        return key;
    }
    tf_storage.addStorageListener = addStorageListener;
    function fireStorageChanged() {
        storageListeners.forEach(function (listenKey) { return listenKey.listener(); });
    }
    tf_storage.fireStorageChanged = fireStorageChanged;
    function removeHashListenerByKey(key) {
        hashListeners.delete(key);
    }
    tf_storage.removeHashListenerByKey = removeHashListenerByKey;
    function removeStorageListenerByKey(key) {
        storageListeners.delete(key);
    }
    tf_storage.removeStorageListenerByKey = removeStorageListenerByKey;
})(tf_storage || (tf_storage = {})); // namespace tf_storage
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibGlzdGVuZXJzLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsibGlzdGVuZXJzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7Ozs7Ozs7Ozs7O2dGQWFnRjtBQUNoRixJQUFVLFVBQVUsQ0FpRG5CO0FBakRELFdBQVUsVUFBVTtJQUVwQiw0RUFBNEU7SUFDNUUsa0JBQWtCO0lBQ2xCLGdFQUFnRTtJQUNoRTtRQUVFLG1CQUFZLFFBQWtCO1lBQzVCLElBQUksQ0FBQyxRQUFRLEdBQUcsUUFBUSxDQUFDO1FBQzNCLENBQUM7UUFDSCxnQkFBQztJQUFELENBQUMsQUFMRCxJQUtDO0lBTFksb0JBQVMsWUFLckIsQ0FBQTtJQUVELElBQU0sYUFBYSxHQUFHLElBQUksR0FBRyxFQUFhLENBQUM7SUFDM0MsSUFBTSxnQkFBZ0IsR0FBRyxJQUFJLEdBQUcsRUFBYSxDQUFDO0lBRTlDLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxZQUFZLEVBQUU7UUFDcEMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxVQUFBLFNBQVMsSUFBSSxPQUFBLFNBQVMsQ0FBQyxRQUFRLEVBQUUsRUFBcEIsQ0FBb0IsQ0FBQyxDQUFDO0lBQzNELENBQUMsQ0FBQyxDQUFDO0lBRUgsOEVBQThFO0lBQzlFLDZEQUE2RDtJQUM3RCxNQUFNLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxFQUFFO1FBQ2pDLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxVQUFBLFNBQVMsSUFBSSxPQUFBLFNBQVMsQ0FBQyxRQUFRLEVBQUUsRUFBcEIsQ0FBb0IsQ0FBQyxDQUFDO0lBQzlELENBQUMsQ0FBQyxDQUFDO0lBRUgseUJBQWdDLEVBQVk7UUFDMUMsSUFBTSxHQUFHLEdBQUcsSUFBSSxTQUFTLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDOUIsYUFBYSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUN2QixPQUFPLEdBQUcsQ0FBQztJQUNiLENBQUM7SUFKZSwwQkFBZSxrQkFJOUIsQ0FBQTtJQUVELDRCQUFtQyxFQUFZO1FBQzdDLElBQU0sR0FBRyxHQUFHLElBQUksU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQzlCLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUMxQixPQUFPLEdBQUcsQ0FBQztJQUNiLENBQUM7SUFKZSw2QkFBa0IscUJBSWpDLENBQUE7SUFFRDtRQUNFLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxVQUFBLFNBQVMsSUFBSSxPQUFBLFNBQVMsQ0FBQyxRQUFRLEVBQUUsRUFBcEIsQ0FBb0IsQ0FBQyxDQUFDO0lBQzlELENBQUM7SUFGZSw2QkFBa0IscUJBRWpDLENBQUE7SUFFRCxpQ0FBd0MsR0FBYztRQUNwRCxhQUFhLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0lBQzVCLENBQUM7SUFGZSxrQ0FBdUIsMEJBRXRDLENBQUE7SUFFRCxvQ0FBMkMsR0FBYztRQUN2RCxnQkFBZ0IsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDL0IsQ0FBQztJQUZlLHFDQUEwQiw2QkFFekMsQ0FBQTtBQUVELENBQUMsRUFqRFMsVUFBVSxLQUFWLFVBQVUsUUFpRG5CLENBQUUsdUJBQXVCIiwic291cmNlc0NvbnRlbnQiOlsiLyogQ29weXJpZ2h0IDIwMTggVGhlIFRlbnNvckZsb3cgQXV0aG9ycy4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cblxuTGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlLCBWZXJzaW9uIDIuMCAodGhlIFwiTGljZW5zZVwiKTtcbnlvdSBtYXkgbm90IHVzZSB0aGlzIGZpbGUgZXhjZXB0IGluIGNvbXBsaWFuY2Ugd2l0aCB0aGUgTGljZW5zZS5cbllvdSBtYXkgb2J0YWluIGEgY29weSBvZiB0aGUgTGljZW5zZSBhdFxuXG4gICAgaHR0cDovL3d3dy5hcGFjaGUub3JnL2xpY2Vuc2VzL0xJQ0VOU0UtMi4wXG5cblVubGVzcyByZXF1aXJlZCBieSBhcHBsaWNhYmxlIGxhdyBvciBhZ3JlZWQgdG8gaW4gd3JpdGluZywgc29mdHdhcmVcbmRpc3RyaWJ1dGVkIHVuZGVyIHRoZSBMaWNlbnNlIGlzIGRpc3RyaWJ1dGVkIG9uIGFuIFwiQVMgSVNcIiBCQVNJUyxcbldJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWSBLSU5ELCBlaXRoZXIgZXhwcmVzcyBvciBpbXBsaWVkLlxuU2VlIHRoZSBMaWNlbnNlIGZvciB0aGUgc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nIHBlcm1pc3Npb25zIGFuZFxubGltaXRhdGlvbnMgdW5kZXIgdGhlIExpY2Vuc2UuXG49PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0qL1xubmFtZXNwYWNlIHRmX3N0b3JhZ2Uge1xuXG4vLyBUT0RPKHN0ZXBoYW53bGVlKTogQ29tYmluZSB0aGlzIHdpdGggdGZfYmFja2VuZC5MaXN0ZW5LZXkgYW5kIHB1dCBpdCBpbiBhXG4vLyBzZW5zaWJsZSBwbGFjZS5cbi8vIEEgdW5pcXVlIHJlZmVyZW5jZSB0byBhIGxpc3RlbmVyIGZvciBhbiBlYXNpZXIgZGVyZWZlcmVuY2luZy5cbmV4cG9ydCBjbGFzcyBMaXN0ZW5LZXkge1xuICBwdWJsaWMgcmVhZG9ubHkgbGlzdGVuZXI6IEZ1bmN0aW9uO1xuICBjb25zdHJ1Y3RvcihsaXN0ZW5lcjogRnVuY3Rpb24pIHtcbiAgICB0aGlzLmxpc3RlbmVyID0gbGlzdGVuZXI7XG4gIH1cbn1cblxuY29uc3QgaGFzaExpc3RlbmVycyA9IG5ldyBTZXQ8TGlzdGVuS2V5PigpO1xuY29uc3Qgc3RvcmFnZUxpc3RlbmVycyA9IG5ldyBTZXQ8TGlzdGVuS2V5PigpO1xuXG53aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcignaGFzaGNoYW5nZScsICgpID0+IHtcbiAgaGFzaExpc3RlbmVycy5mb3JFYWNoKGxpc3RlbktleSA9PiBsaXN0ZW5LZXkubGlzdGVuZXIoKSk7XG59KTtcblxuLy8gWzFdOiBUaGUgZXZlbnQgb25seSB0cmlnZ2VycyB3aGVuIGFub3RoZXIgdGFiIGVkaXRzIHRoZSBzdG9yYWdlLiBDaGFuZ2luZyBhXG4vLyB2YWx1ZSBpbiBjdXJyZW50IGJyb3dzZXIgdGFiIHdpbGwgTk9UIHRyaWdnZXIgYmVsb3cgZXZlbnQuXG53aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcignc3RvcmFnZScsICgpID0+IHtcbiAgc3RvcmFnZUxpc3RlbmVycy5mb3JFYWNoKGxpc3RlbktleSA9PiBsaXN0ZW5LZXkubGlzdGVuZXIoKSk7XG59KTtcblxuZXhwb3J0IGZ1bmN0aW9uIGFkZEhhc2hMaXN0ZW5lcihmbjogRnVuY3Rpb24pOiBMaXN0ZW5LZXkge1xuICBjb25zdCBrZXkgPSBuZXcgTGlzdGVuS2V5KGZuKTtcbiAgaGFzaExpc3RlbmVycy5hZGQoa2V5KTtcbiAgcmV0dXJuIGtleTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGFkZFN0b3JhZ2VMaXN0ZW5lcihmbjogRnVuY3Rpb24pOiBMaXN0ZW5LZXkge1xuICBjb25zdCBrZXkgPSBuZXcgTGlzdGVuS2V5KGZuKTtcbiAgc3RvcmFnZUxpc3RlbmVycy5hZGQoa2V5KTtcbiAgcmV0dXJuIGtleTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGZpcmVTdG9yYWdlQ2hhbmdlZCgpIHtcbiAgc3RvcmFnZUxpc3RlbmVycy5mb3JFYWNoKGxpc3RlbktleSA9PiBsaXN0ZW5LZXkubGlzdGVuZXIoKSk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiByZW1vdmVIYXNoTGlzdGVuZXJCeUtleShrZXk6IExpc3RlbktleSkge1xuICBoYXNoTGlzdGVuZXJzLmRlbGV0ZShrZXkpO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gcmVtb3ZlU3RvcmFnZUxpc3RlbmVyQnlLZXkoa2V5OiBMaXN0ZW5LZXkpIHtcbiAgc3RvcmFnZUxpc3RlbmVycy5kZWxldGUoa2V5KTtcbn1cblxufSAgLy8gbmFtZXNwYWNlIHRmX3N0b3JhZ2VcbiJdfQ==