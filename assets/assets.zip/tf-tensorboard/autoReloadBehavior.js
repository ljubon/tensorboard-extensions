/* Copyright 2015 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
var tf_tensorboard;
(function (tf_tensorboard) {
    tf_tensorboard.AUTORELOAD_LOCALSTORAGE_KEY = 'TF.TensorBoard.autoReloadEnabled';
    var getAutoReloadFromLocalStorage = function () {
        var val = window.localStorage.getItem(tf_tensorboard.AUTORELOAD_LOCALSTORAGE_KEY);
        return val === 'true' || val == null; // defaults to true
    };
    function forceDisableAutoReload() {
        return new URLSearchParams(window.location.search).has('_DisableAutoReload');
    }
    /**
     * @polymerBehavior
     */
    tf_tensorboard.AutoReloadBehavior = {
        properties: {
            autoReloadEnabled: {
                type: Boolean,
                observer: '_autoReloadObserver',
                value: getAutoReloadFromLocalStorage,
            },
            _autoReloadId: {
                type: Number,
            },
            autoReloadIntervalSecs: {
                type: Number,
                value: 30,
            },
        },
        detached: function () {
            window.clearTimeout(this._autoReloadId);
        },
        _autoReloadObserver: function (autoReload) {
            var _this = this;
            window.localStorage.setItem(tf_tensorboard.AUTORELOAD_LOCALSTORAGE_KEY, autoReload);
            if (autoReload && !forceDisableAutoReload()) {
                this._autoReloadId = window.setTimeout(function () { return _this._doAutoReload(); }, this.autoReloadIntervalSecs * 1000);
            }
            else {
                window.clearTimeout(this._autoReloadId);
            }
        },
        _doAutoReload: function () {
            var _this = this;
            if (this.reload == null) {
                throw new Error('AutoReloadBehavior requires a reload method');
            }
            this.reload();
            this._autoReloadId = window.setTimeout(function () { return _this._doAutoReload(); }, this.autoReloadIntervalSecs * 1000);
        }
    };
})(tf_tensorboard || (tf_tensorboard = {})); // namespace tf_tensorboard
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXV0b1JlbG9hZEJlaGF2aW9yLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiYXV0b1JlbG9hZEJlaGF2aW9yLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7Ozs7Ozs7Ozs7O2dGQWFnRjtBQUNoRixJQUFVLGNBQWMsQ0FxRHZCO0FBckRELFdBQVUsY0FBYztJQUViLDBDQUEyQixHQUFHLGtDQUFrQyxDQUFDO0lBRTVFLElBQUksNkJBQTZCLEdBQWtCO1FBQ2pELElBQUksR0FBRyxHQUFHLE1BQU0sQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLGVBQUEsMkJBQTJCLENBQUMsQ0FBQztRQUNuRSxPQUFPLEdBQUcsS0FBSyxNQUFNLElBQUksR0FBRyxJQUFJLElBQUksQ0FBQyxDQUFFLG1CQUFtQjtJQUM1RCxDQUFDLENBQUM7SUFFRjtRQUNFLE9BQU8sSUFBSSxlQUFlLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMsb0JBQW9CLENBQUMsQ0FBQztJQUMvRSxDQUFDO0lBRUQ7O09BRUc7SUFDUSxpQ0FBa0IsR0FBRztRQUM5QixVQUFVLEVBQUU7WUFDVixpQkFBaUIsRUFBRTtnQkFDakIsSUFBSSxFQUFFLE9BQU87Z0JBQ2IsUUFBUSxFQUFFLHFCQUFxQjtnQkFDL0IsS0FBSyxFQUFFLDZCQUE2QjthQUNyQztZQUNELGFBQWEsRUFBRTtnQkFDYixJQUFJLEVBQUUsTUFBTTthQUNiO1lBQ0Qsc0JBQXNCLEVBQUU7Z0JBQ3RCLElBQUksRUFBRSxNQUFNO2dCQUNaLEtBQUssRUFBRSxFQUFFO2FBQ1Y7U0FDRjtRQUNELFFBQVEsRUFBRTtZQUNSLE1BQU0sQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDO1FBQzFDLENBQUM7UUFDRCxtQkFBbUIsRUFBRSxVQUFTLFVBQVU7WUFBbkIsaUJBUXBCO1lBUEMsTUFBTSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsZUFBQSwyQkFBMkIsRUFBRSxVQUFVLENBQUMsQ0FBQztZQUNyRSxJQUFJLFVBQVUsSUFBSSxDQUFDLHNCQUFzQixFQUFFLEVBQUU7Z0JBQzNDLElBQUksQ0FBQyxhQUFhLEdBQUcsTUFBTSxDQUFDLFVBQVUsQ0FDbEMsY0FBTSxPQUFBLEtBQUksQ0FBQyxhQUFhLEVBQUUsRUFBcEIsQ0FBb0IsRUFBRSxJQUFJLENBQUMsc0JBQXNCLEdBQUcsSUFBSSxDQUFDLENBQUM7YUFDckU7aUJBQU07Z0JBQ0wsTUFBTSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUM7YUFDekM7UUFDSCxDQUFDO1FBQ0QsYUFBYSxFQUFFO1lBQUEsaUJBT2Q7WUFOQyxJQUFJLElBQUksQ0FBQyxNQUFNLElBQUksSUFBSSxFQUFFO2dCQUN2QixNQUFNLElBQUksS0FBSyxDQUFDLDZDQUE2QyxDQUFDLENBQUM7YUFDaEU7WUFDRCxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7WUFDZCxJQUFJLENBQUMsYUFBYSxHQUFHLE1BQU0sQ0FBQyxVQUFVLENBQ2xDLGNBQU0sT0FBQSxLQUFJLENBQUMsYUFBYSxFQUFFLEVBQXBCLENBQW9CLEVBQUUsSUFBSSxDQUFDLHNCQUFzQixHQUFHLElBQUksQ0FBQyxDQUFDO1FBQ3RFLENBQUM7S0FDRixDQUFDO0FBRUYsQ0FBQyxFQXJEUyxjQUFjLEtBQWQsY0FBYyxRQXFEdkIsQ0FBRSwyQkFBMkIiLCJzb3VyY2VzQ29udGVudCI6WyIvKiBDb3B5cmlnaHQgMjAxNSBUaGUgVGVuc29yRmxvdyBBdXRob3JzLiBBbGwgUmlnaHRzIFJlc2VydmVkLlxuXG5MaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UsIFZlcnNpb24gMi4wICh0aGUgXCJMaWNlbnNlXCIpO1xueW91IG1heSBub3QgdXNlIHRoaXMgZmlsZSBleGNlcHQgaW4gY29tcGxpYW5jZSB3aXRoIHRoZSBMaWNlbnNlLlxuWW91IG1heSBvYnRhaW4gYSBjb3B5IG9mIHRoZSBMaWNlbnNlIGF0XG5cbiAgICBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcblxuVW5sZXNzIHJlcXVpcmVkIGJ5IGFwcGxpY2FibGUgbGF3IG9yIGFncmVlZCB0byBpbiB3cml0aW5nLCBzb2Z0d2FyZVxuZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIExpY2Vuc2UgaXMgZGlzdHJpYnV0ZWQgb24gYW4gXCJBUyBJU1wiIEJBU0lTLFxuV0lUSE9VVCBXQVJSQU5USUVTIE9SIENPTkRJVElPTlMgT0YgQU5ZIEtJTkQsIGVpdGhlciBleHByZXNzIG9yIGltcGxpZWQuXG5TZWUgdGhlIExpY2Vuc2UgZm9yIHRoZSBzcGVjaWZpYyBsYW5ndWFnZSBnb3Zlcm5pbmcgcGVybWlzc2lvbnMgYW5kXG5saW1pdGF0aW9ucyB1bmRlciB0aGUgTGljZW5zZS5cbj09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSovXG5uYW1lc3BhY2UgdGZfdGVuc29yYm9hcmQge1xuXG5leHBvcnQgdmFyIEFVVE9SRUxPQURfTE9DQUxTVE9SQUdFX0tFWSA9ICdURi5UZW5zb3JCb2FyZC5hdXRvUmVsb2FkRW5hYmxlZCc7XG5cbnZhciBnZXRBdXRvUmVsb2FkRnJvbUxvY2FsU3RvcmFnZTogKCkgPT4gYm9vbGVhbiA9ICgpID0+IHtcbiAgdmFyIHZhbCA9IHdpbmRvdy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbShBVVRPUkVMT0FEX0xPQ0FMU1RPUkFHRV9LRVkpO1xuICByZXR1cm4gdmFsID09PSAndHJ1ZScgfHwgdmFsID09IG51bGw7ICAvLyBkZWZhdWx0cyB0byB0cnVlXG59O1xuXG5mdW5jdGlvbiBmb3JjZURpc2FibGVBdXRvUmVsb2FkKCk6IGJvb2xlYW4ge1xuICByZXR1cm4gbmV3IFVSTFNlYXJjaFBhcmFtcyh3aW5kb3cubG9jYXRpb24uc2VhcmNoKS5oYXMoJ19EaXNhYmxlQXV0b1JlbG9hZCcpO1xufVxuXG4vKipcbiAqIEBwb2x5bWVyQmVoYXZpb3JcbiAqL1xuZXhwb3J0IHZhciBBdXRvUmVsb2FkQmVoYXZpb3IgPSB7XG4gIHByb3BlcnRpZXM6IHtcbiAgICBhdXRvUmVsb2FkRW5hYmxlZDoge1xuICAgICAgdHlwZTogQm9vbGVhbixcbiAgICAgIG9ic2VydmVyOiAnX2F1dG9SZWxvYWRPYnNlcnZlcicsXG4gICAgICB2YWx1ZTogZ2V0QXV0b1JlbG9hZEZyb21Mb2NhbFN0b3JhZ2UsXG4gICAgfSxcbiAgICBfYXV0b1JlbG9hZElkOiB7XG4gICAgICB0eXBlOiBOdW1iZXIsXG4gICAgfSxcbiAgICBhdXRvUmVsb2FkSW50ZXJ2YWxTZWNzOiB7XG4gICAgICB0eXBlOiBOdW1iZXIsXG4gICAgICB2YWx1ZTogMzAsXG4gICAgfSxcbiAgfSxcbiAgZGV0YWNoZWQ6IGZ1bmN0aW9uKCkge1xuICAgIHdpbmRvdy5jbGVhclRpbWVvdXQodGhpcy5fYXV0b1JlbG9hZElkKTtcbiAgfSxcbiAgX2F1dG9SZWxvYWRPYnNlcnZlcjogZnVuY3Rpb24oYXV0b1JlbG9hZCkge1xuICAgIHdpbmRvdy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbShBVVRPUkVMT0FEX0xPQ0FMU1RPUkFHRV9LRVksIGF1dG9SZWxvYWQpO1xuICAgIGlmIChhdXRvUmVsb2FkICYmICFmb3JjZURpc2FibGVBdXRvUmVsb2FkKCkpIHtcbiAgICAgIHRoaXMuX2F1dG9SZWxvYWRJZCA9IHdpbmRvdy5zZXRUaW1lb3V0KFxuICAgICAgICAgICgpID0+IHRoaXMuX2RvQXV0b1JlbG9hZCgpLCB0aGlzLmF1dG9SZWxvYWRJbnRlcnZhbFNlY3MgKiAxMDAwKTtcbiAgICB9IGVsc2Uge1xuICAgICAgd2luZG93LmNsZWFyVGltZW91dCh0aGlzLl9hdXRvUmVsb2FkSWQpO1xuICAgIH1cbiAgfSxcbiAgX2RvQXV0b1JlbG9hZDogZnVuY3Rpb24oKSB7XG4gICAgaWYgKHRoaXMucmVsb2FkID09IG51bGwpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignQXV0b1JlbG9hZEJlaGF2aW9yIHJlcXVpcmVzIGEgcmVsb2FkIG1ldGhvZCcpO1xuICAgIH1cbiAgICB0aGlzLnJlbG9hZCgpO1xuICAgIHRoaXMuX2F1dG9SZWxvYWRJZCA9IHdpbmRvdy5zZXRUaW1lb3V0KFxuICAgICAgICAoKSA9PiB0aGlzLl9kb0F1dG9SZWxvYWQoKSwgdGhpcy5hdXRvUmVsb2FkSW50ZXJ2YWxTZWNzICogMTAwMCk7XG4gIH1cbn07XG5cbn0gIC8vIG5hbWVzcGFjZSB0Zl90ZW5zb3Jib2FyZFxuIl19