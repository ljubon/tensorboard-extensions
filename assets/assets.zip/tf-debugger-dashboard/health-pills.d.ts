declare namespace tf_debugger_dashboard {
    /**
     * Check if a health pill meets the given condition.
     *
     * Any condition value that involves numerical comparison require a value
     *   in the `refValue` argument (see below).
     * @param healthPill The health pill.
     * @param refValue Threshold required by some of the condition values. If not
     *   provided for such conditions, an Error will be thrown.
     * @return Whether the condition is met.
     * @throws Error on in valid condition values or missing refValue for conditions
     *   that requires it.
     */
    type TensorConditionPredicate = (healthPill: number[], refValue?: number) => boolean;
    interface TensorCondition {
        description: string;
        predicate: TensorConditionPredicate;
    }
    /**
     * Convert human-readable description of a tensor-value condition to its key.
     * @param description Human-readable description.
     * @returns The key, if exists. Else, `null`.
     */
    function tensorConditionDescription2Key(description: string): string;
    /**
     * Test a health pill against a tensor-value condition.
     * @param key Key for the tensor-value condition, see `tensorConditions` for
     *   details.
     * @param healthPill The health pill.
     * @param refValue The reference value required by some of the tensor-value
     *   conditions, e.g., `MEAN_LT`.
     * @returns Whether the tensor condition specified by `key` (and potentially
     *   also `revValue` for some `key` values) is satisfied by `healthPill`.
     */
    function checkHealthPillAgainstTensorConditionKey(key: string, healthPill: number[], refValue?: number): boolean;
}
