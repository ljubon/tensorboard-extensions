var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
/* Copyright 2018 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the 'License');
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an 'AS IS' BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
var vz_line_chart2;
(function (vz_line_chart2) {
    var State;
    (function (State) {
        State[State["NONE"] = 0] = "NONE";
        State[State["DRAG_ZOOMING"] = 1] = "DRAG_ZOOMING";
        State[State["PANNING"] = 2] = "PANNING";
    })(State || (State = {}));
    var PanZoomDragLayer = /** @class */ (function (_super) {
        __extends(PanZoomDragLayer, _super);
        /**
         * A Plottable component/layer with a complex interaction for the line chart.
         * When not pressing alt-key, it behaves like DragZoomLayer -- dragging a
         * region zooms the area under the gray box and double clicking resets the
         * zoom. When pressing alt-key, it lets user pan around while having mousedown
         * on the chart and let user zoom-in/out of cursor when scroll.
         */
        function PanZoomDragLayer(xScale, yScale, unzoomMethod) {
            var _this = _super.call(this) || this;
            _this.state = State.NONE;
            _this.panStartCallback = new Plottable.Utils.CallbackSet();
            _this.panEndCallback = new Plottable.Utils.CallbackSet();
            _this.panZoom = new Plottable.Interactions.PanZoom(xScale, yScale);
            _this.panZoom.dragInteraction().mouseFilter(function (event) {
                return PanZoomDragLayer.isPanKey(event) && event.button === 0;
            });
            _this.panZoom.attachTo(_this);
            _this.dragZoomLayer = new vz_line_chart.DragZoomLayer(xScale, yScale, unzoomMethod);
            _this.dragZoomLayer.dragInteraction().mouseFilter(function (event) {
                return !PanZoomDragLayer.isPanKey(event) && event.button === 0;
            });
            _this.append(_this.dragZoomLayer);
            _this.onAnchor(function () {
                _this.panZoom.attachTo(_this);
            });
            _this.onDetach(function () {
                _this.panZoom.detachFrom(_this);
            });
            _this.panZoom.dragInteraction().onDragStart(function () {
                if (_this.state == State.NONE)
                    _this.setState(State.PANNING);
            });
            _this.panZoom.dragInteraction().onDragEnd(function () {
                if (_this.state == State.PANNING)
                    _this.setState(State.NONE);
            });
            _this.dragZoomLayer.dragInteraction().onDragStart(function () {
                if (_this.state == State.NONE)
                    _this.setState(State.DRAG_ZOOMING);
            });
            _this.dragZoomLayer.dragInteraction().onDragEnd(function () {
                if (_this.state == State.DRAG_ZOOMING)
                    _this.setState(State.NONE);
            });
            return _this;
        }
        PanZoomDragLayer.isPanKey = function (event) {
            return Boolean(event.shiftKey);
        };
        PanZoomDragLayer.prototype.setState = function (nextState) {
            if (this.state == nextState)
                return;
            var prevState = this.state;
            this.state = nextState;
            this.root().removeClass(this.stateClassName(prevState));
            this.root().addClass(this.stateClassName(nextState));
            if (prevState == State.PANNING) {
                this.panEndCallback.callCallbacks();
            }
            if (nextState == State.PANNING) {
                this.panStartCallback.callCallbacks();
            }
        };
        PanZoomDragLayer.prototype.stateClassName = function (state) {
            switch (state) {
                case State.PANNING:
                    return 'panning';
                case State.DRAG_ZOOMING:
                    return 'drag-zooming';
                case State.NONE:
                default:
                    return '';
            }
        };
        PanZoomDragLayer.prototype.onPanStart = function (cb) {
            this.panStartCallback.add(cb);
        };
        PanZoomDragLayer.prototype.onPanEnd = function (cb) {
            this.panEndCallback.add(cb);
        };
        PanZoomDragLayer.prototype.onScrollZoom = function (cb) {
            this.panZoom.onZoomEnd(cb);
        };
        PanZoomDragLayer.prototype.onDragZoomStart = function (cb) {
            this.dragZoomLayer.interactionStart(cb);
        };
        PanZoomDragLayer.prototype.onDragZoomEnd = function (cb) {
            this.dragZoomLayer.interactionEnd(cb);
        };
        return PanZoomDragLayer;
    }(Plottable.Components.Group));
    vz_line_chart2.PanZoomDragLayer = PanZoomDragLayer;
})(vz_line_chart2 || (vz_line_chart2 = {})); // namespace vz_line_chart
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGFuWm9vbURyYWdMYXllci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbInBhblpvb21EcmFnTGF5ZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztBQUFBOzs7Ozs7Ozs7Ozs7O2dGQWFnRjtBQUNoRixJQUFVLGNBQWMsQ0FzSHZCO0FBdEhELFdBQVUsY0FBYztJQUV4QixJQUFLLEtBSUo7SUFKRCxXQUFLLEtBQUs7UUFDUixpQ0FBSSxDQUFBO1FBQ0osaURBQVksQ0FBQTtRQUNaLHVDQUFPLENBQUE7SUFDVCxDQUFDLEVBSkksS0FBSyxLQUFMLEtBQUssUUFJVDtJQUlEO1FBQXNDLG9DQUEwQjtRQU85RDs7Ozs7O1dBTUc7UUFDSCwwQkFDSSxNQUErRCxFQUMvRCxNQUErRCxFQUMvRCxZQUFzQjtZQUgxQixZQUlFLGlCQUFPLFNBb0NSO1lBbkRPLFdBQUssR0FBVSxLQUFLLENBQUMsSUFBSSxDQUFDO1lBQzFCLHNCQUFnQixHQUFHLElBQUksU0FBUyxDQUFDLEtBQUssQ0FBQyxXQUFXLEVBQWUsQ0FBQztZQUNsRSxvQkFBYyxHQUFHLElBQUksU0FBUyxDQUFDLEtBQUssQ0FBQyxXQUFXLEVBQWUsQ0FBQztZQWV0RSxLQUFJLENBQUMsT0FBTyxHQUFHLElBQUksU0FBUyxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFLE1BQU0sQ0FBQyxDQUFDO1lBQ2xFLEtBQUksQ0FBQyxPQUFPLENBQUMsZUFBZSxFQUFFLENBQUMsV0FBVyxDQUFDLFVBQUMsS0FBaUI7Z0JBQzNELE9BQU8sZ0JBQWdCLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxJQUFJLEtBQUssQ0FBQyxNQUFNLEtBQUssQ0FBQyxDQUFDO1lBQ2hFLENBQUMsQ0FBQyxDQUFDO1lBQ0gsS0FBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsS0FBSSxDQUFDLENBQUM7WUFFNUIsS0FBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLGFBQWEsQ0FBQyxhQUFhLENBQ2hELE1BQU0sRUFDTixNQUFNLEVBQ04sWUFBWSxDQUFDLENBQUM7WUFDbEIsS0FBSSxDQUFDLGFBQWEsQ0FBQyxlQUFlLEVBQUUsQ0FBQyxXQUFXLENBQUMsVUFBQyxLQUFpQjtnQkFDakUsT0FBTyxDQUFDLGdCQUFnQixDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsSUFBSSxLQUFLLENBQUMsTUFBTSxLQUFLLENBQUMsQ0FBQztZQUNqRSxDQUFDLENBQUMsQ0FBQztZQUNILEtBQUksQ0FBQyxNQUFNLENBQUMsS0FBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDO1lBRWhDLEtBQUksQ0FBQyxRQUFRLENBQUM7Z0JBQ1osS0FBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsS0FBSSxDQUFDLENBQUM7WUFDOUIsQ0FBQyxDQUFDLENBQUM7WUFDSCxLQUFJLENBQUMsUUFBUSxDQUFDO2dCQUNaLEtBQUksQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLEtBQUksQ0FBQyxDQUFDO1lBQ2hDLENBQUMsQ0FBQyxDQUFDO1lBRUgsS0FBSSxDQUFDLE9BQU8sQ0FBQyxlQUFlLEVBQUUsQ0FBQyxXQUFXLENBQUM7Z0JBQ3pDLElBQUksS0FBSSxDQUFDLEtBQUssSUFBSSxLQUFLLENBQUMsSUFBSTtvQkFBRSxLQUFJLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUM3RCxDQUFDLENBQUMsQ0FBQztZQUNILEtBQUksQ0FBQyxPQUFPLENBQUMsZUFBZSxFQUFFLENBQUMsU0FBUyxDQUFDO2dCQUN2QyxJQUFJLEtBQUksQ0FBQyxLQUFLLElBQUksS0FBSyxDQUFDLE9BQU87b0JBQUUsS0FBSSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDN0QsQ0FBQyxDQUFDLENBQUM7WUFDSCxLQUFJLENBQUMsYUFBYSxDQUFDLGVBQWUsRUFBRSxDQUFDLFdBQVcsQ0FBQztnQkFDL0MsSUFBSSxLQUFJLENBQUMsS0FBSyxJQUFJLEtBQUssQ0FBQyxJQUFJO29CQUFFLEtBQUksQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDO1lBQ2xFLENBQUMsQ0FBQyxDQUFDO1lBQ0gsS0FBSSxDQUFDLGFBQWEsQ0FBQyxlQUFlLEVBQUUsQ0FBQyxTQUFTLENBQUM7Z0JBQzdDLElBQUksS0FBSSxDQUFDLEtBQUssSUFBSSxLQUFLLENBQUMsWUFBWTtvQkFBRSxLQUFJLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUNsRSxDQUFDLENBQUMsQ0FBQzs7UUFDTCxDQUFDO1FBRU0seUJBQVEsR0FBZixVQUFnQixLQUFpQjtZQUMvQixPQUFPLE9BQU8sQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDakMsQ0FBQztRQUVELG1DQUFRLEdBQVIsVUFBUyxTQUFnQjtZQUN2QixJQUFJLElBQUksQ0FBQyxLQUFLLElBQUksU0FBUztnQkFBRSxPQUFPO1lBQ3BDLElBQU0sU0FBUyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7WUFDN0IsSUFBSSxDQUFDLEtBQUssR0FBRyxTQUFTLENBQUM7WUFDdkIsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUM7WUFDeEQsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUM7WUFDckQsSUFBSSxTQUFTLElBQUksS0FBSyxDQUFDLE9BQU8sRUFBRTtnQkFDOUIsSUFBSSxDQUFDLGNBQWMsQ0FBQyxhQUFhLEVBQUUsQ0FBQzthQUNyQztZQUNELElBQUksU0FBUyxJQUFJLEtBQUssQ0FBQyxPQUFPLEVBQUU7Z0JBQzlCLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxhQUFhLEVBQUUsQ0FBQzthQUN2QztRQUNILENBQUM7UUFFRCx5Q0FBYyxHQUFkLFVBQWUsS0FBWTtZQUN6QixRQUFRLEtBQUssRUFBRTtnQkFDYixLQUFLLEtBQUssQ0FBQyxPQUFPO29CQUNoQixPQUFPLFNBQVMsQ0FBQztnQkFDbkIsS0FBSyxLQUFLLENBQUMsWUFBWTtvQkFDckIsT0FBTyxjQUFjLENBQUM7Z0JBQ3hCLEtBQUssS0FBSyxDQUFDLElBQUksQ0FBQztnQkFDaEI7b0JBQ0UsT0FBTyxFQUFFLENBQUM7YUFDYjtRQUNILENBQUM7UUFFRCxxQ0FBVSxHQUFWLFVBQVcsRUFBZTtZQUN4QixJQUFJLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQ2hDLENBQUM7UUFFRCxtQ0FBUSxHQUFSLFVBQVMsRUFBZTtZQUN0QixJQUFJLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUM5QixDQUFDO1FBRUQsdUNBQVksR0FBWixVQUFhLEVBQUU7WUFDYixJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUM3QixDQUFDO1FBRUQsMENBQWUsR0FBZixVQUFnQixFQUFFO1lBQ2hCLElBQUksQ0FBQyxhQUFhLENBQUMsZ0JBQWdCLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDMUMsQ0FBQztRQUVELHdDQUFhLEdBQWIsVUFBYyxFQUFFO1lBQ2QsSUFBSSxDQUFDLGFBQWEsQ0FBQyxjQUFjLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDeEMsQ0FBQztRQUVILHVCQUFDO0lBQUQsQ0FBQyxBQTFHRCxDQUFzQyxTQUFTLENBQUMsVUFBVSxDQUFDLEtBQUssR0EwRy9EO0lBMUdZLCtCQUFnQixtQkEwRzVCLENBQUE7QUFFRCxDQUFDLEVBdEhTLGNBQWMsS0FBZCxjQUFjLFFBc0h2QixDQUFFLDBCQUEwQiIsInNvdXJjZXNDb250ZW50IjpbIi8qIENvcHlyaWdodCAyMDE4IFRoZSBUZW5zb3JGbG93IEF1dGhvcnMuIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG5cbkxpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSAnTGljZW5zZScpO1xueW91IG1heSBub3QgdXNlIHRoaXMgZmlsZSBleGNlcHQgaW4gY29tcGxpYW5jZSB3aXRoIHRoZSBMaWNlbnNlLlxuWW91IG1heSBvYnRhaW4gYSBjb3B5IG9mIHRoZSBMaWNlbnNlIGF0XG5cbiAgICBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcblxuVW5sZXNzIHJlcXVpcmVkIGJ5IGFwcGxpY2FibGUgbGF3IG9yIGFncmVlZCB0byBpbiB3cml0aW5nLCBzb2Z0d2FyZVxuZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIExpY2Vuc2UgaXMgZGlzdHJpYnV0ZWQgb24gYW4gJ0FTIElTJyBCQVNJUyxcbldJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWSBLSU5ELCBlaXRoZXIgZXhwcmVzcyBvciBpbXBsaWVkLlxuU2VlIHRoZSBMaWNlbnNlIGZvciB0aGUgc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nIHBlcm1pc3Npb25zIGFuZFxubGltaXRhdGlvbnMgdW5kZXIgdGhlIExpY2Vuc2UuXG49PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0qL1xubmFtZXNwYWNlIHZ6X2xpbmVfY2hhcnQyIHtcblxuZW51bSBTdGF0ZSB7XG4gIE5PTkUsXG4gIERSQUdfWk9PTUlORyxcbiAgUEFOTklORyxcbn1cblxuZXhwb3J0IHR5cGUgUGFuQ2FsbGJhY2sgPSAoKSA9PiB2b2lkO1xuXG5leHBvcnQgY2xhc3MgUGFuWm9vbURyYWdMYXllciBleHRlbmRzIFBsb3R0YWJsZS5Db21wb25lbnRzLkdyb3VwIHtcbiAgcHJpdmF0ZSBwYW5ab29tOiBQbG90dGFibGUuSW50ZXJhY3Rpb25zLlBhblpvb207XG4gIHByaXZhdGUgZHJhZ1pvb21MYXllcjogdnpfbGluZV9jaGFydC5EcmFnWm9vbUxheWVyO1xuICBwcml2YXRlIHN0YXRlOiBTdGF0ZSA9IFN0YXRlLk5PTkU7XG4gIHByaXZhdGUgcGFuU3RhcnRDYWxsYmFjayA9IG5ldyBQbG90dGFibGUuVXRpbHMuQ2FsbGJhY2tTZXQ8UGFuQ2FsbGJhY2s+KCk7XG4gIHByaXZhdGUgcGFuRW5kQ2FsbGJhY2sgPSBuZXcgUGxvdHRhYmxlLlV0aWxzLkNhbGxiYWNrU2V0PFBhbkNhbGxiYWNrPigpO1xuXG4gIC8qKlxuICAgKiBBIFBsb3R0YWJsZSBjb21wb25lbnQvbGF5ZXIgd2l0aCBhIGNvbXBsZXggaW50ZXJhY3Rpb24gZm9yIHRoZSBsaW5lIGNoYXJ0LlxuICAgKiBXaGVuIG5vdCBwcmVzc2luZyBhbHQta2V5LCBpdCBiZWhhdmVzIGxpa2UgRHJhZ1pvb21MYXllciAtLSBkcmFnZ2luZyBhXG4gICAqIHJlZ2lvbiB6b29tcyB0aGUgYXJlYSB1bmRlciB0aGUgZ3JheSBib3ggYW5kIGRvdWJsZSBjbGlja2luZyByZXNldHMgdGhlXG4gICAqIHpvb20uIFdoZW4gcHJlc3NpbmcgYWx0LWtleSwgaXQgbGV0cyB1c2VyIHBhbiBhcm91bmQgd2hpbGUgaGF2aW5nIG1vdXNlZG93blxuICAgKiBvbiB0aGUgY2hhcnQgYW5kIGxldCB1c2VyIHpvb20taW4vb3V0IG9mIGN1cnNvciB3aGVuIHNjcm9sbC5cbiAgICovXG4gIGNvbnN0cnVjdG9yKFxuICAgICAgeFNjYWxlOiBQbG90dGFibGUuUXVhbnRpdGF0aXZlU2NhbGU8bnVtYmVyfHt2YWx1ZU9mKCk6IG51bWJlcn0+LFxuICAgICAgeVNjYWxlOiBQbG90dGFibGUuUXVhbnRpdGF0aXZlU2NhbGU8bnVtYmVyfHt2YWx1ZU9mKCk6IG51bWJlcn0+LFxuICAgICAgdW56b29tTWV0aG9kOiBGdW5jdGlvbikge1xuICAgIHN1cGVyKCk7XG5cbiAgICB0aGlzLnBhblpvb20gPSBuZXcgUGxvdHRhYmxlLkludGVyYWN0aW9ucy5QYW5ab29tKHhTY2FsZSwgeVNjYWxlKTtcbiAgICB0aGlzLnBhblpvb20uZHJhZ0ludGVyYWN0aW9uKCkubW91c2VGaWx0ZXIoKGV2ZW50OiBNb3VzZUV2ZW50KSA9PiB7XG4gICAgICByZXR1cm4gUGFuWm9vbURyYWdMYXllci5pc1BhbktleShldmVudCkgJiYgZXZlbnQuYnV0dG9uID09PSAwO1xuICAgIH0pO1xuICAgIHRoaXMucGFuWm9vbS5hdHRhY2hUbyh0aGlzKTtcblxuICAgIHRoaXMuZHJhZ1pvb21MYXllciA9IG5ldyB2el9saW5lX2NoYXJ0LkRyYWdab29tTGF5ZXIoXG4gICAgICAgIHhTY2FsZSxcbiAgICAgICAgeVNjYWxlLFxuICAgICAgICB1bnpvb21NZXRob2QpO1xuICAgIHRoaXMuZHJhZ1pvb21MYXllci5kcmFnSW50ZXJhY3Rpb24oKS5tb3VzZUZpbHRlcigoZXZlbnQ6IE1vdXNlRXZlbnQpID0+IHtcbiAgICAgIHJldHVybiAhUGFuWm9vbURyYWdMYXllci5pc1BhbktleShldmVudCkgJiYgZXZlbnQuYnV0dG9uID09PSAwO1xuICAgIH0pO1xuICAgIHRoaXMuYXBwZW5kKHRoaXMuZHJhZ1pvb21MYXllcik7XG5cbiAgICB0aGlzLm9uQW5jaG9yKCgpID0+IHtcbiAgICAgIHRoaXMucGFuWm9vbS5hdHRhY2hUbyh0aGlzKTtcbiAgICB9KTtcbiAgICB0aGlzLm9uRGV0YWNoKCgpID0+IHtcbiAgICAgIHRoaXMucGFuWm9vbS5kZXRhY2hGcm9tKHRoaXMpO1xuICAgIH0pO1xuXG4gICAgdGhpcy5wYW5ab29tLmRyYWdJbnRlcmFjdGlvbigpLm9uRHJhZ1N0YXJ0KCgpID0+IHtcbiAgICAgIGlmICh0aGlzLnN0YXRlID09IFN0YXRlLk5PTkUpIHRoaXMuc2V0U3RhdGUoU3RhdGUuUEFOTklORyk7XG4gICAgfSk7XG4gICAgdGhpcy5wYW5ab29tLmRyYWdJbnRlcmFjdGlvbigpLm9uRHJhZ0VuZCgoKSA9PiB7XG4gICAgICBpZiAodGhpcy5zdGF0ZSA9PSBTdGF0ZS5QQU5OSU5HKSB0aGlzLnNldFN0YXRlKFN0YXRlLk5PTkUpO1xuICAgIH0pO1xuICAgIHRoaXMuZHJhZ1pvb21MYXllci5kcmFnSW50ZXJhY3Rpb24oKS5vbkRyYWdTdGFydCgoKSA9PiB7XG4gICAgICBpZiAodGhpcy5zdGF0ZSA9PSBTdGF0ZS5OT05FKSB0aGlzLnNldFN0YXRlKFN0YXRlLkRSQUdfWk9PTUlORyk7XG4gICAgfSk7XG4gICAgdGhpcy5kcmFnWm9vbUxheWVyLmRyYWdJbnRlcmFjdGlvbigpLm9uRHJhZ0VuZCgoKSA9PiB7XG4gICAgICBpZiAodGhpcy5zdGF0ZSA9PSBTdGF0ZS5EUkFHX1pPT01JTkcpIHRoaXMuc2V0U3RhdGUoU3RhdGUuTk9ORSk7XG4gICAgfSk7XG4gIH1cblxuICBzdGF0aWMgaXNQYW5LZXkoZXZlbnQ6IE1vdXNlRXZlbnQpOiBib29sZWFuIHtcbiAgICByZXR1cm4gQm9vbGVhbihldmVudC5zaGlmdEtleSk7XG4gIH1cblxuICBzZXRTdGF0ZShuZXh0U3RhdGU6IFN0YXRlKTogdm9pZCB7XG4gICAgaWYgKHRoaXMuc3RhdGUgPT0gbmV4dFN0YXRlKSByZXR1cm47XG4gICAgY29uc3QgcHJldlN0YXRlID0gdGhpcy5zdGF0ZTtcbiAgICB0aGlzLnN0YXRlID0gbmV4dFN0YXRlO1xuICAgIHRoaXMucm9vdCgpLnJlbW92ZUNsYXNzKHRoaXMuc3RhdGVDbGFzc05hbWUocHJldlN0YXRlKSk7XG4gICAgdGhpcy5yb290KCkuYWRkQ2xhc3ModGhpcy5zdGF0ZUNsYXNzTmFtZShuZXh0U3RhdGUpKTtcbiAgICBpZiAocHJldlN0YXRlID09IFN0YXRlLlBBTk5JTkcpIHtcbiAgICAgIHRoaXMucGFuRW5kQ2FsbGJhY2suY2FsbENhbGxiYWNrcygpO1xuICAgIH1cbiAgICBpZiAobmV4dFN0YXRlID09IFN0YXRlLlBBTk5JTkcpIHtcbiAgICAgIHRoaXMucGFuU3RhcnRDYWxsYmFjay5jYWxsQ2FsbGJhY2tzKCk7XG4gICAgfVxuICB9XG5cbiAgc3RhdGVDbGFzc05hbWUoc3RhdGU6IFN0YXRlKTogc3RyaW5nIHtcbiAgICBzd2l0Y2ggKHN0YXRlKSB7XG4gICAgICBjYXNlIFN0YXRlLlBBTk5JTkc6XG4gICAgICAgIHJldHVybiAncGFubmluZyc7XG4gICAgICBjYXNlIFN0YXRlLkRSQUdfWk9PTUlORzpcbiAgICAgICAgcmV0dXJuICdkcmFnLXpvb21pbmcnO1xuICAgICAgY2FzZSBTdGF0ZS5OT05FOlxuICAgICAgZGVmYXVsdDpcbiAgICAgICAgcmV0dXJuICcnO1xuICAgIH1cbiAgfVxuXG4gIG9uUGFuU3RhcnQoY2I6IFBhbkNhbGxiYWNrKSB7XG4gICAgdGhpcy5wYW5TdGFydENhbGxiYWNrLmFkZChjYik7XG4gIH1cblxuICBvblBhbkVuZChjYjogUGFuQ2FsbGJhY2spIHtcbiAgICB0aGlzLnBhbkVuZENhbGxiYWNrLmFkZChjYik7XG4gIH1cblxuICBvblNjcm9sbFpvb20oY2IpIHtcbiAgICB0aGlzLnBhblpvb20ub25ab29tRW5kKGNiKTtcbiAgfVxuXG4gIG9uRHJhZ1pvb21TdGFydChjYikge1xuICAgIHRoaXMuZHJhZ1pvb21MYXllci5pbnRlcmFjdGlvblN0YXJ0KGNiKTtcbiAgfVxuXG4gIG9uRHJhZ1pvb21FbmQoY2IpIHtcbiAgICB0aGlzLmRyYWdab29tTGF5ZXIuaW50ZXJhY3Rpb25FbmQoY2IpO1xuICB9XG5cbn1cblxufSAgLy8gbmFtZXNwYWNlIHZ6X2xpbmVfY2hhcnRcbiJdfQ==