/* Copyright 2015 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the 'License');
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an 'AS IS' BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
var tf;
(function (tf) {
    var graph;
    (function (graph_1) {
        var layout;
        (function (layout) {
            /** Set of parameters that define the look and feel of the graph. */
            layout.PARAMS = {
                animation: {
                    /** Default duration for graph animations in ms. */
                    duration: 250
                },
                graph: {
                    /** Graph parameter for metanode. */
                    meta: {
                        /**
                         * Dagre's nodesep param - number of pixels that
                         * separate nodes horizontally in the layout.
                         *
                         * See https://github.com/cpettitt/dagre/wiki#configuring-the-layout
                         */
                        nodeSep: 5,
                        /**
                         * Dagre's ranksep param - number of pixels
                         * between each rank in the layout.
                         *
                         * See https://github.com/cpettitt/dagre/wiki#configuring-the-layout
                         */
                        rankSep: 25,
                        /**
                         * Dagre's edgesep param - number of pixels that separate
                         * edges horizontally in the layout.
                         */
                        edgeSep: 5,
                    },
                    /** Graph parameter for metanode. */
                    series: {
                        /**
                         * Dagre's nodesep param - number of pixels that
                         * separate nodes horizontally in the layout.
                         *
                         * See https://github.com/cpettitt/dagre/wiki#configuring-the-layout
                         */
                        nodeSep: 5,
                        /**
                         * Dagre's ranksep param - number of pixels
                         * between each rank in the layout.
                         *
                         * See https://github.com/cpettitt/dagre/wiki#configuring-the-layout
                         */
                        rankSep: 25,
                        /**
                         * Dagre's edgesep param - number of pixels that separate
                         * edges horizontally in the layout.
                         */
                        edgeSep: 5
                    },
                    /**
                     * Padding is used to correctly position the graph SVG inside of its parent
                     * element. The padding amounts are applied using an SVG transform of X and
                     * Y coordinates.
                     */
                    padding: { paddingTop: 40, paddingLeft: 20 }
                },
                subscene: {
                    meta: {
                        paddingTop: 10,
                        paddingBottom: 10,
                        paddingLeft: 10,
                        paddingRight: 10,
                        /**
                         * Used to leave room for the label on top of the highest node in
                         * the core graph.
                         */
                        labelHeight: 20,
                        /** X-space between each extracted node and the core graph. */
                        extractXOffset: 15,
                        /** Y-space between each extracted node. */
                        extractYOffset: 20,
                    },
                    series: {
                        paddingTop: 10,
                        paddingBottom: 10,
                        paddingLeft: 10,
                        paddingRight: 10,
                        labelHeight: 10
                    }
                },
                nodeSize: {
                    /** Size of meta nodes. */
                    meta: {
                        radius: 5,
                        width: 60,
                        maxLabelWidth: 52,
                        /** A scale for the node's height based on number of nodes inside */
                        // Hack - set this as an any type to avoid issues in exporting a type
                        // from an external module.
                        height: d3.scaleLinear().domain([1, 200]).range([15, 60]).clamp(true),
                        /** The radius of the circle denoting the expand button. */
                        expandButtonRadius: 3
                    },
                    /** Size of op nodes. */
                    op: {
                        width: 15,
                        height: 6,
                        radius: 3,
                        labelOffset: -8,
                        maxLabelWidth: 30
                    },
                    /** Size of series nodes. */
                    series: {
                        expanded: {
                            // For expanded series nodes, width and height will be
                            // computed to account for the subscene.
                            radius: 10,
                            labelOffset: 0,
                        },
                        vertical: {
                            // When unexpanded, series whose underlying metagraphs contain
                            // one or more non-control edges will show as a vertical stack
                            // of ellipses.
                            width: 16,
                            height: 13,
                            labelOffset: -13,
                        },
                        horizontal: {
                            // When unexpanded, series whose underlying metagraphs contain
                            // no non-control edges will show as a horizontal stack of
                            // ellipses.
                            width: 24,
                            height: 8,
                            radius: 10,
                            labelOffset: -10,
                        },
                    },
                    /** Size of bridge nodes. */
                    bridge: {
                        // NOTE: bridge nodes will normally be invisible, but they must
                        // take up some space so that the layout step leaves room for
                        // their edges.
                        width: 20,
                        height: 20,
                        radius: 2,
                        labelOffset: 0
                    }
                },
                shortcutSize: {
                    /** Size of shortcuts for op nodes */
                    op: { width: 10, height: 4 },
                    /** Size of shortcuts for meta nodes */
                    meta: { width: 12, height: 4, radius: 1 },
                    /** Size of shortcuts for series nodes */
                    series: {
                        width: 14,
                        height: 4,
                    }
                },
                annotations: {
                    /** Maximum possible width of the bounding box for in annotations */
                    inboxWidth: 50,
                    /** Maximum possible width of the bounding box for out annotations */
                    outboxWidth: 50,
                    /** X-space between the shape and each annotation-node. */
                    xOffset: 10,
                    /** Y-space between each annotation-node. */
                    yOffset: 3,
                    /** X-space between each annotation-node and its label. */
                    labelOffset: 2,
                    /** Defines the max width for annotation label */
                    maxLabelWidth: 120
                },
                constant: { size: { width: 4, height: 4 } },
                series: {
                    /** Maximum number of repeated item for unexpanded series node. */
                    maxStackCount: 3,
                    /**
                     * Positioning offset ratio for collapsed stack
                     * of parallel series (series without edges between its members).
                     */
                    parallelStackOffsetRatio: 0.2,
                    /**
                     * Positioning offset ratio for collapsed stack
                     * of tower series (series with edges between its members).
                     */
                    towerStackOffsetRatio: 0.5
                },
                minimap: {
                    /** The maximum width/height the minimap can have. */
                    size: 150
                }
            };
            /**
             * The minimum width we confer upon the auxiliary nodes section if functions
             * also appear. Without enforcing this minimum, metanodes in the function
             * library section could jut into the auxiliary nodes section because the
             * title "Auxiliary Nodes" is longer than the width of the auxiliary nodes
             * section itself.
             */
            layout.MIN_AUX_WIDTH = 140;
            /** Calculate layout for a scene of a group node. */
            function layoutScene(renderNodeInfo) {
                // Update layout, size, and annotations of its children nodes and edges.
                if (renderNodeInfo.node.isGroupNode) {
                    layoutChildren(renderNodeInfo);
                }
                // Update position of its children nodes and edges
                if (renderNodeInfo.node.type === graph_1.NodeType.META) {
                    layoutMetanode(renderNodeInfo);
                }
                else if (renderNodeInfo.node.type === graph_1.NodeType.SERIES) {
                    layoutSeriesNode(renderNodeInfo);
                }
            }
            layout.layoutScene = layoutScene;
            ;
            /**
             * Updates the total width of an unexpanded node which includes the size of its
             * in and out annotations.
             */
            function updateTotalWidthOfNode(renderInfo) {
                renderInfo.inboxWidth = renderInfo.inAnnotations.list.length > 0 ?
                    layout.PARAMS.annotations.inboxWidth : 0;
                renderInfo.outboxWidth = renderInfo.outAnnotations.list.length > 0 ?
                    layout.PARAMS.annotations.outboxWidth : 0;
                // Assign the width of the core box (the main shape of the node).
                renderInfo.coreBox.width = renderInfo.width;
                renderInfo.coreBox.height = renderInfo.height;
                // TODO: Account for font width rather than using a magic number.
                var labelLength = renderInfo.displayName.length;
                var charWidth = 3; // 3 pixels per character.
                // Compute the total width of the node.
                renderInfo.width = Math.max(renderInfo.coreBox.width +
                    renderInfo.inboxWidth + renderInfo.outboxWidth, labelLength * charWidth);
            }
            /**
             * Update layout, size, and annotations of its children nodes and edges.
             */
            function layoutChildren(renderNodeInfo) {
                var children = renderNodeInfo.coreGraph.nodes().map(function (n) {
                    return renderNodeInfo.coreGraph.node(n);
                }).concat(renderNodeInfo.isolatedInExtract, renderNodeInfo.isolatedOutExtract, renderNodeInfo.libraryFunctionsExtract);
                _.each(children, function (childNodeInfo) {
                    // Set size of each child
                    switch (childNodeInfo.node.type) {
                        case graph_1.NodeType.OP:
                            _.extend(childNodeInfo, layout.PARAMS.nodeSize.op);
                            break;
                        case graph_1.NodeType.BRIDGE:
                            _.extend(childNodeInfo, layout.PARAMS.nodeSize.bridge);
                            break;
                        case graph_1.NodeType.META:
                            if (!childNodeInfo.expanded) {
                                // Set fixed width and scalable height based on cardinality
                                _.extend(childNodeInfo, layout.PARAMS.nodeSize.meta);
                                childNodeInfo.height =
                                    layout.PARAMS.nodeSize.meta.height(childNodeInfo.node.cardinality);
                            }
                            else {
                                var childGroupNodeInfo = childNodeInfo;
                                layoutScene(childGroupNodeInfo); // Recursively layout its subscene.
                            }
                            break;
                        case graph_1.NodeType.SERIES:
                            if (childNodeInfo.expanded) {
                                _.extend(childNodeInfo, layout.PARAMS.nodeSize.series.expanded);
                                var childGroupNodeInfo = childNodeInfo;
                                layoutScene(childGroupNodeInfo); // Recursively layout its subscene.
                            }
                            else {
                                var childGroupNodeInfo = childNodeInfo;
                                var seriesParams = childGroupNodeInfo.node.hasNonControlEdges ?
                                    layout.PARAMS.nodeSize.series.vertical :
                                    layout.PARAMS.nodeSize.series.horizontal;
                                _.extend(childNodeInfo, seriesParams);
                            }
                            break;
                        default:
                            throw Error('Unrecognized node type: ' + childNodeInfo.node.type);
                    }
                    // Compute total width of un-expanded nodes. Width of expanded nodes
                    // has already been computed.
                    if (!childNodeInfo.expanded) {
                        updateTotalWidthOfNode(childNodeInfo);
                    }
                    // Layout each child's annotations
                    layoutAnnotation(childNodeInfo);
                });
            }
            /**
             * Calculate layout for a graph using dagre
             * @param graph the graph to be laid out
             * @param params layout parameters
             * @return width and height of the core graph
             */
            function dagreLayout(graph, params) {
                _.extend(graph.graph(), {
                    nodesep: params.nodeSep,
                    ranksep: params.rankSep,
                    edgesep: params.edgeSep
                });
                var bridgeNodeNames = [];
                var nonBridgeNodeNames = [];
                // Split out nodes into bridge and non-bridge nodes, and calculate the total
                // width we should use for bridge nodes.
                _.each(graph.nodes(), function (nodeName) {
                    var nodeInfo = graph.node(nodeName);
                    if (nodeInfo.node.type === graph_1.NodeType.BRIDGE) {
                        bridgeNodeNames.push(nodeName);
                    }
                    else {
                        nonBridgeNodeNames.push(nodeName);
                    }
                });
                // If there are no non-bridge nodes, then the graph has zero size.
                if (!nonBridgeNodeNames.length) {
                    return {
                        width: 0,
                        height: 0,
                    };
                }
                dagre.layout(graph);
                // Calculate the true bounding box of the graph by iterating over nodes and
                // edges rather than accepting dagre's word for it. In particular, we should
                // ignore the extra-wide bridge nodes and bridge edges, and allow for
                // annotation boxes and labels.
                var minX = Infinity;
                var minY = Infinity;
                var maxX = -Infinity;
                var maxY = -Infinity;
                _.each(nonBridgeNodeNames, function (nodeName) {
                    var nodeInfo = graph.node(nodeName);
                    var w = 0.5 * nodeInfo.width;
                    var x1 = nodeInfo.x - w;
                    var x2 = nodeInfo.x + w;
                    minX = x1 < minX ? x1 : minX;
                    maxX = x2 > maxX ? x2 : maxX;
                    // TODO: Account for the height of labels above op nodes here.
                    var h = 0.5 * nodeInfo.height;
                    var y1 = nodeInfo.y - h;
                    var y2 = nodeInfo.y + h;
                    minY = y1 < minY ? y1 : minY;
                    maxY = y2 > maxY ? y2 : maxY;
                });
                _.each(graph.edges(), function (edgeObj) {
                    var edgeInfo = graph.edge(edgeObj);
                    if (edgeInfo.structural) {
                        return; // Skip structural edges from min/max calculations.
                    }
                    // Since the node size passed to dagre includes the in and out
                    // annotations, the endpoints of the edge produced by dagre may not
                    // point to the actual node shape (rectangle, ellipse). We correct the
                    // end-points by finding the intersection of a line between the
                    // next-to-last (next-to-first) point and the destination (source)
                    // rectangle.
                    var sourceNode = graph.node(edgeInfo.metaedge.v);
                    var destNode = graph.node(edgeInfo.metaedge.w);
                    // Straight 3-points edges are special case, since they are curved after
                    // our default correction. To keep them straight, we remove the mid point
                    // and correct the first and the last point to be the center of the
                    // source and destination node respectively.
                    if (edgeInfo.points.length === 3 && isStraightLine(edgeInfo.points)) {
                        if (sourceNode != null) {
                            var cxSource = sourceNode.expanded ?
                                sourceNode.x : computeCXPositionOfNodeShape(sourceNode);
                            edgeInfo.points[0].x = cxSource;
                        }
                        if (destNode != null) {
                            var cxDest = destNode.expanded ?
                                destNode.x : computeCXPositionOfNodeShape(destNode);
                            edgeInfo.points[2].x = cxDest;
                        }
                        // Remove the middle point so the edge doesn't curve.
                        edgeInfo.points = [edgeInfo.points[0], edgeInfo.points[1]];
                    }
                    // Correct the destination endpoint of the edge.
                    var nextToLastPoint = edgeInfo.points[edgeInfo.points.length - 2];
                    // The destination node might be null if this is a bridge edge.
                    if (destNode != null) {
                        edgeInfo.points[edgeInfo.points.length - 1] =
                            intersectPointAndNode(nextToLastPoint, destNode);
                    }
                    // Correct the source endpoint of the edge.
                    var secondPoint = edgeInfo.points[1];
                    // The source might be null if this is a bridge edge.
                    if (sourceNode != null) {
                        edgeInfo.points[0] = intersectPointAndNode(secondPoint, sourceNode);
                    }
                    _.each(edgeInfo.points, function (point) {
                        minX = point.x < minX ? point.x : minX;
                        maxX = point.x > maxX ? point.x : maxX;
                        minY = point.y < minY ? point.y : minY;
                        maxY = point.y > maxY ? point.y : maxY;
                    });
                });
                // Shift all nodes and edge points to account for the left-padding amount,
                // and the invisible bridge nodes.
                _.each(graph.nodes(), function (nodeName) {
                    var nodeInfo = graph.node(nodeName);
                    nodeInfo.x -= minX;
                    nodeInfo.y -= minY;
                });
                _.each(graph.edges(), function (edgeObj) {
                    _.each(graph.edge(edgeObj).points, function (point) {
                        point.x -= minX;
                        point.y -= minY;
                    });
                });
                return {
                    width: maxX - minX,
                    height: maxY - minY
                };
            }
            /** Layout a metanode. Only called for an expanded node. */
            function layoutMetanode(renderNodeInfo) {
                // First, copy params specific to meta nodes onto this render info object.
                var params = layout.PARAMS.subscene.meta;
                _.extend(renderNodeInfo, params);
                // Invoke dagre.layout() on the core graph and record the bounding box
                // dimensions.
                _.extend(renderNodeInfo.coreBox, dagreLayout(renderNodeInfo.coreGraph, layout.PARAMS.graph.meta));
                // Calculate the position of nodes in isolatedInExtract relative to the
                // top-left corner of inExtractBox (the bounding box for all inExtract nodes)
                // and calculate the size of the inExtractBox.
                var maxInExtractWidth = renderNodeInfo.isolatedInExtract.length ?
                    _.max(renderNodeInfo.isolatedInExtract, function (renderNode) { return renderNode.width; }).width : null;
                renderNodeInfo.inExtractBox.width = maxInExtractWidth != null ?
                    maxInExtractWidth : 0;
                renderNodeInfo.inExtractBox.height =
                    _.reduce(renderNodeInfo.isolatedInExtract, function (height, child, i) {
                        var yOffset = i > 0 ? params.extractYOffset : 0;
                        // use width/height here to avoid overlaps between extracts
                        child.x = 0;
                        child.y = height + yOffset + child.height / 2;
                        return height + yOffset + child.height;
                    }, 0);
                // Calculate the position of nodes in isolatedOutExtract relative to the
                // top-left corner of outExtractBox (the bounding box for all outExtract
                // nodes) and calculate the size of the outExtractBox.
                var maxOutExtractWidth = renderNodeInfo.isolatedOutExtract.length ?
                    _.max(renderNodeInfo.isolatedOutExtract, function (renderNode) { return renderNode.width; }).width : null;
                renderNodeInfo.outExtractBox.width = maxOutExtractWidth != null ?
                    maxOutExtractWidth : 0;
                renderNodeInfo.outExtractBox.height =
                    _.reduce(renderNodeInfo.isolatedOutExtract, function (height, child, i) {
                        var yOffset = i > 0 ? params.extractYOffset : 0;
                        // use width/height here to avoid overlaps between extracts
                        child.x = 0;
                        child.y = height + yOffset + child.height / 2;
                        return height + yOffset + child.height;
                    }, 0);
                // Calculate the position of nodes in libraryFunctionsExtract relative to the
                // top-left corner of libraryFunctionsBox (the bounding box for all library
                // function nodes) and calculate the size of the libraryFunctionsBox.
                var maxLibraryFunctionsWidth = renderNodeInfo.libraryFunctionsExtract.length ?
                    _.max(renderNodeInfo.libraryFunctionsExtract, function (renderNode) { return renderNode.width; }).width : null;
                renderNodeInfo.libraryFunctionsBox.width = maxLibraryFunctionsWidth != null ?
                    maxLibraryFunctionsWidth : 0;
                renderNodeInfo.libraryFunctionsBox.height =
                    _.reduce(renderNodeInfo.libraryFunctionsExtract, function (height, child, i) {
                        var yOffset = i > 0 ? params.extractYOffset : 0;
                        // use width/height here to avoid overlaps between extracts
                        child.x = 0;
                        child.y = height + yOffset + child.height / 2;
                        return height + yOffset + child.height;
                    }, 0);
                // Compute the total padding between the core graph, in-extract and
                // out-extract boxes.
                var numParts = 0;
                if (renderNodeInfo.isolatedInExtract.length > 0) {
                    numParts++;
                }
                if (renderNodeInfo.isolatedOutExtract.length > 0) {
                    numParts++;
                }
                if (renderNodeInfo.libraryFunctionsExtract.length > 0) {
                    numParts++;
                }
                if (renderNodeInfo.coreGraph.nodeCount() > 0) {
                    numParts++;
                }
                var offset = layout.PARAMS.subscene.meta.extractXOffset;
                var padding = numParts <= 1 ? 0 : (numParts * offset);
                // Add the in-extract and out-extract width to the core box width. Do not let
                // the auxiliary width be too small, lest it be smaller than the title.
                var auxWidth = Math.max(layout.MIN_AUX_WIDTH, renderNodeInfo.inExtractBox.width + renderNodeInfo.outExtractBox.width);
                renderNodeInfo.coreBox.width += auxWidth + padding +
                    renderNodeInfo.libraryFunctionsBox.width + padding;
                renderNodeInfo.coreBox.height =
                    params.labelHeight +
                        Math.max(renderNodeInfo.inExtractBox.height, renderNodeInfo.coreBox.height, renderNodeInfo.libraryFunctionsBox.height, renderNodeInfo.outExtractBox.height);
                // Determine the whole metanode's width (from left to right).
                renderNodeInfo.width = renderNodeInfo.coreBox.width +
                    params.paddingLeft + params.paddingRight;
                // Determine the whole metanode's height (from top to bottom).
                renderNodeInfo.height =
                    renderNodeInfo.paddingTop +
                        renderNodeInfo.coreBox.height +
                        renderNodeInfo.paddingBottom;
            }
            /**
             * Calculate layout for series node's core graph. Only called for an expanded
             * series.
             */
            function layoutSeriesNode(node) {
                var graph = node.coreGraph;
                var params = layout.PARAMS.subscene.series;
                _.extend(node, params);
                // Layout the core.
                _.extend(node.coreBox, dagreLayout(node.coreGraph, layout.PARAMS.graph.series));
                _.each(graph.nodes(), function (nodeName) {
                    graph.node(nodeName).excluded = false;
                });
                // Series do not have in/outExtractBox so no need to include them here.
                node.width = node.coreBox.width + params.paddingLeft + params.paddingRight;
                node.height = node.coreBox.height + params.paddingTop + params.paddingBottom;
            }
            /**
             * Calculate layout for annotations of a given node.
             * This will modify positions of the given node and its annotations.
             *
             * @see tf.graph.render.Node and tf.graph.render.Annotation
             * for description of each property of each render node.
             *
             */
            function layoutAnnotation(renderNodeInfo) {
                // If the render node is an expanded metanode, then its annotations will not
                // be visible and we should skip the annotation calculations.
                if (renderNodeInfo.expanded) {
                    return;
                }
                var inAnnotations = renderNodeInfo.inAnnotations.list;
                var outAnnotations = renderNodeInfo.outAnnotations.list;
                // Calculate size for in-annotations
                _.each(inAnnotations, function (a) { return sizeAnnotation(a); });
                // Calculate size for out-annotations
                _.each(outAnnotations, function (a) { return sizeAnnotation(a); });
                var params = layout.PARAMS.annotations;
                // Calculate annotation node position (a.dx, a.dy)
                // and total height for in-annotations
                // After this chunk of code:
                // inboxHeight = sum of annotation heights+ (annotation.length - 1 * yOffset)
                var inboxHeight = _.reduce(inAnnotations, function (height, a, i) {
                    var yOffset = i > 0 ? params.yOffset : 0;
                    a.dx = -(renderNodeInfo.coreBox.width + a.width) / 2 - params.xOffset;
                    a.dy = height + yOffset + a.height / 2;
                    return height + yOffset + a.height;
                }, 0);
                _.each(inAnnotations, function (a) {
                    a.dy -= inboxHeight / 2;
                    a.labelOffset = params.labelOffset;
                });
                // Calculate annotation node position (a.dx, a.dy)
                // and total height for out-annotations
                // After this chunk of code:
                // outboxHeight = sum of annotation heights +
                //                (annotation.length - 1 * yOffset)
                var outboxHeight = _.reduce(outAnnotations, function (height, a, i) {
                    var yOffset = i > 0 ? params.yOffset : 0;
                    a.dx = (renderNodeInfo.coreBox.width + a.width) / 2 + params.xOffset;
                    a.dy = height + yOffset + a.height / 2;
                    return height + yOffset + a.height;
                }, 0);
                _.each(outAnnotations, function (a) {
                    // adjust by (half of ) the total height
                    // so dy is relative to the host node's center.
                    a.dy -= outboxHeight / 2;
                    a.labelOffset = params.labelOffset;
                });
                // Creating scales for touch point between the in-annotation edges
                // and their hosts.
                var inTouchHeight = Math.min(renderNodeInfo.height / 2 - renderNodeInfo.radius, inboxHeight / 2);
                inTouchHeight = inTouchHeight < 0 ? 0 : inTouchHeight;
                var inY = d3.scaleLinear()
                    .domain([0, inAnnotations.length - 1])
                    .range([-inTouchHeight, inTouchHeight]);
                // Calculate annotation edge position
                _.each(inAnnotations, function (a, i) {
                    a.points = [
                        // The annotation node end
                        {
                            dx: a.dx + a.width / 2,
                            dy: a.dy
                        },
                        // The host node end
                        {
                            dx: -renderNodeInfo.coreBox.width / 2,
                            // only use scale if there are more than one,
                            // otherwise center it vertically
                            dy: inAnnotations.length > 1 ? inY(i) : 0
                        }
                    ];
                });
                // Creating scales for touch point between the out-annotation edges
                // and their hosts.
                var outTouchHeight = Math.min(renderNodeInfo.height / 2 - renderNodeInfo.radius, outboxHeight / 2);
                outTouchHeight = outTouchHeight < 0 ? 0 : outTouchHeight;
                var outY = d3.scaleLinear()
                    .domain([0, outAnnotations.length - 1])
                    .range([-outTouchHeight, outTouchHeight]);
                _.each(outAnnotations, function (a, i) {
                    // Add point from the border of the annotation node
                    a.points = [
                        // The host node end
                        {
                            dx: renderNodeInfo.coreBox.width / 2,
                            // only use scale if there are more than one,
                            // otherwise center it vertically
                            dy: outAnnotations.length > 1 ? outY(i) : 0
                        },
                        // The annotation node end
                        {
                            dx: a.dx - a.width / 2,
                            dy: a.dy
                        }
                    ];
                });
                renderNodeInfo.height =
                    Math.max(renderNodeInfo.height, inboxHeight, outboxHeight);
            }
            /**
             * Set size of an annotation node.
             */
            function sizeAnnotation(a) {
                switch (a.annotationType) {
                    case graph_1.render.AnnotationType.CONSTANT:
                        _.extend(a, layout.PARAMS.constant.size);
                        break;
                    case graph_1.render.AnnotationType.SHORTCUT:
                        if (a.node.type === graph_1.NodeType.OP) {
                            _.extend(a, layout.PARAMS.shortcutSize.op);
                        }
                        else if (a.node.type === graph_1.NodeType.META) {
                            _.extend(a, layout.PARAMS.shortcutSize.meta);
                        }
                        else if (a.node.type === graph_1.NodeType.SERIES) {
                            _.extend(a, layout.PARAMS.shortcutSize.series);
                        }
                        else {
                            throw Error('Invalid node type: ' + a.node.type);
                        }
                        break;
                    case graph_1.render.AnnotationType.SUMMARY:
                        _.extend(a, layout.PARAMS.constant.size);
                        break;
                }
            }
            /**
             * Determines the center position of the node's shape. The position depends
             * on if the node has in and out-annotations.
             */
            function computeCXPositionOfNodeShape(renderInfo) {
                if (renderInfo.expanded) {
                    return renderInfo.x;
                }
                var dx = renderInfo.inAnnotations.list.length ? renderInfo.inboxWidth : 0;
                return renderInfo.x - renderInfo.width / 2 + dx +
                    renderInfo.coreBox.width / 2;
            }
            layout.computeCXPositionOfNodeShape = computeCXPositionOfNodeShape;
            /** Returns the angle (in degrees) between two points. */
            function angleBetweenTwoPoints(a, b) {
                var dx = b.x - a.x;
                var dy = b.y - a.y;
                return 180 * Math.atan(dy / dx) / Math.PI;
            }
            /**
             * Returns if a line going through the specified points is a straight line.
             */
            function isStraightLine(points) {
                var angle = angleBetweenTwoPoints(points[0], points[1]);
                for (var i = 1; i < points.length - 1; i++) {
                    var newAngle = angleBetweenTwoPoints(points[i], points[i + 1]);
                    // Have a tolerance of 1 degree.
                    if (Math.abs(newAngle - angle) > 1) {
                        return false;
                    }
                    angle = newAngle;
                }
                return true;
            }
            /**
             * Returns the intersection of a line between the provided point
             * and the provided rectangle.
             */
            function intersectPointAndNode(point, node) {
                // cx and cy are the center of the rectangle.
                var cx = node.expanded ?
                    node.x : computeCXPositionOfNodeShape(node);
                var cy = node.y;
                // Calculate the slope
                var dx = point.x - cx;
                var dy = point.y - cy;
                var w = node.expanded ? node.width : node.coreBox.width;
                var h = node.expanded ? node.height : node.coreBox.height;
                var deltaX, deltaY;
                if (Math.abs(dy) * w / 2 > Math.abs(dx) * h / 2) {
                    // The intersection is above or below the rectangle.
                    if (dy < 0) {
                        h = -h;
                    }
                    deltaX = dy === 0 ? 0 : h / 2 * dx / dy;
                    deltaY = h / 2;
                }
                else {
                    // The intersection is left or right of the rectangle.
                    if (dx < 0) {
                        w = -w;
                    }
                    deltaX = w / 2;
                    deltaY = dx === 0 ? 0 : w / 2 * dy / dx;
                }
                return { x: cx + deltaX, y: cy + deltaY };
            }
        })(layout = graph_1.layout || (graph_1.layout = {}));
    })(graph = tf.graph || (tf.graph = {}));
})(tf || (tf = {})); // close module
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibGF5b3V0LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsibGF5b3V0LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7Ozs7Ozs7Ozs7O2dGQWFnRjtBQUNoRixJQUFPLEVBQUUsQ0FveEJSO0FBcHhCRCxXQUFPLEVBQUU7SUFBQyxJQUFBLEtBQUssQ0FveEJkO0lBcHhCUyxXQUFBLE9BQUs7UUFBQyxJQUFBLE1BQU0sQ0FveEJyQjtRQXB4QmUsV0FBQSxNQUFNO1lBRXRCLG9FQUFvRTtZQUN2RCxhQUFNLEdBQUc7Z0JBQ3BCLFNBQVMsRUFBRTtvQkFDVCxtREFBbUQ7b0JBQ25ELFFBQVEsRUFBRSxHQUFHO2lCQUNkO2dCQUNELEtBQUssRUFBRTtvQkFDTCxvQ0FBb0M7b0JBQ3BDLElBQUksRUFBRTt3QkFDSjs7Ozs7MkJBS0c7d0JBQ0gsT0FBTyxFQUFFLENBQUM7d0JBQ1Y7Ozs7OzJCQUtHO3dCQUNILE9BQU8sRUFBRSxFQUFFO3dCQUNYOzs7MkJBR0c7d0JBQ0gsT0FBTyxFQUFFLENBQUM7cUJBQ1g7b0JBQ0Qsb0NBQW9DO29CQUNwQyxNQUFNLEVBQUU7d0JBQ047Ozs7OzJCQUtHO3dCQUNILE9BQU8sRUFBRSxDQUFDO3dCQUNWOzs7OzsyQkFLRzt3QkFDSCxPQUFPLEVBQUUsRUFBRTt3QkFDWDs7OzJCQUdHO3dCQUNILE9BQU8sRUFBRSxDQUFDO3FCQUNYO29CQUNEOzs7O3VCQUlHO29CQUNILE9BQU8sRUFBRSxFQUFDLFVBQVUsRUFBRSxFQUFFLEVBQUUsV0FBVyxFQUFFLEVBQUUsRUFBQztpQkFDM0M7Z0JBQ0QsUUFBUSxFQUFFO29CQUNSLElBQUksRUFBRTt3QkFDSixVQUFVLEVBQUUsRUFBRTt3QkFDZCxhQUFhLEVBQUUsRUFBRTt3QkFDakIsV0FBVyxFQUFFLEVBQUU7d0JBQ2YsWUFBWSxFQUFFLEVBQUU7d0JBQ2hCOzs7MkJBR0c7d0JBQ0gsV0FBVyxFQUFFLEVBQUU7d0JBQ2YsOERBQThEO3dCQUM5RCxjQUFjLEVBQUUsRUFBRTt3QkFDbEIsMkNBQTJDO3dCQUMzQyxjQUFjLEVBQUUsRUFBRTtxQkFDbkI7b0JBQ0QsTUFBTSxFQUFFO3dCQUNOLFVBQVUsRUFBRSxFQUFFO3dCQUNkLGFBQWEsRUFBRSxFQUFFO3dCQUNqQixXQUFXLEVBQUUsRUFBRTt3QkFDZixZQUFZLEVBQUUsRUFBRTt3QkFDaEIsV0FBVyxFQUFFLEVBQUU7cUJBQ2hCO2lCQUNGO2dCQUNELFFBQVEsRUFBRTtvQkFDUiwwQkFBMEI7b0JBQzFCLElBQUksRUFBRTt3QkFDSixNQUFNLEVBQUUsQ0FBQzt3QkFDVCxLQUFLLEVBQUUsRUFBRTt3QkFDVCxhQUFhLEVBQUUsRUFBRTt3QkFDakIsb0VBQW9FO3dCQUNwRSxxRUFBcUU7d0JBQ3JFLDJCQUEyQjt3QkFDM0IsTUFBTSxFQUFHLEVBQVUsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDO3dCQUM5RSwyREFBMkQ7d0JBQzNELGtCQUFrQixFQUFFLENBQUM7cUJBQ3RCO29CQUNELHdCQUF3QjtvQkFDeEIsRUFBRSxFQUFFO3dCQUNGLEtBQUssRUFBRSxFQUFFO3dCQUNULE1BQU0sRUFBRSxDQUFDO3dCQUNULE1BQU0sRUFBRSxDQUFDO3dCQUNULFdBQVcsRUFBRSxDQUFDLENBQUM7d0JBQ2YsYUFBYSxFQUFFLEVBQUU7cUJBQ2xCO29CQUNELDRCQUE0QjtvQkFDNUIsTUFBTSxFQUFFO3dCQUNOLFFBQVEsRUFBRTs0QkFDUixzREFBc0Q7NEJBQ3RELHdDQUF3Qzs0QkFDeEMsTUFBTSxFQUFFLEVBQUU7NEJBQ1YsV0FBVyxFQUFFLENBQUM7eUJBQ2Y7d0JBQ0QsUUFBUSxFQUFFOzRCQUNSLDhEQUE4RDs0QkFDOUQsOERBQThEOzRCQUM5RCxlQUFlOzRCQUNmLEtBQUssRUFBRSxFQUFFOzRCQUNULE1BQU0sRUFBRSxFQUFFOzRCQUNWLFdBQVcsRUFBRSxDQUFDLEVBQUU7eUJBQ2pCO3dCQUNELFVBQVUsRUFBRTs0QkFDViw4REFBOEQ7NEJBQzlELDBEQUEwRDs0QkFDMUQsWUFBWTs0QkFDWixLQUFLLEVBQUUsRUFBRTs0QkFDVCxNQUFNLEVBQUUsQ0FBQzs0QkFDVCxNQUFNLEVBQUUsRUFBRTs0QkFDVixXQUFXLEVBQUUsQ0FBQyxFQUFFO3lCQUNqQjtxQkFDRjtvQkFDRCw0QkFBNEI7b0JBQzVCLE1BQU0sRUFBRTt3QkFDTiwrREFBK0Q7d0JBQy9ELDZEQUE2RDt3QkFDN0QsZUFBZTt3QkFDZixLQUFLLEVBQUUsRUFBRTt3QkFDVCxNQUFNLEVBQUUsRUFBRTt3QkFDVixNQUFNLEVBQUUsQ0FBQzt3QkFDVCxXQUFXLEVBQUUsQ0FBQztxQkFDZjtpQkFDRjtnQkFDRCxZQUFZLEVBQUU7b0JBQ1oscUNBQXFDO29CQUNyQyxFQUFFLEVBQUUsRUFBQyxLQUFLLEVBQUUsRUFBRSxFQUFFLE1BQU0sRUFBRSxDQUFDLEVBQUM7b0JBQzFCLHVDQUF1QztvQkFDdkMsSUFBSSxFQUFFLEVBQUMsS0FBSyxFQUFFLEVBQUUsRUFBRSxNQUFNLEVBQUUsQ0FBQyxFQUFFLE1BQU0sRUFBRSxDQUFDLEVBQUM7b0JBQ3ZDLHlDQUF5QztvQkFDekMsTUFBTSxFQUFFO3dCQUNOLEtBQUssRUFBRSxFQUFFO3dCQUNULE1BQU0sRUFBRSxDQUFDO3FCQUNWO2lCQUNGO2dCQUNELFdBQVcsRUFBRTtvQkFDWCxvRUFBb0U7b0JBQ3BFLFVBQVUsRUFBRSxFQUFFO29CQUNkLHFFQUFxRTtvQkFDckUsV0FBVyxFQUFFLEVBQUU7b0JBQ2YsMERBQTBEO29CQUMxRCxPQUFPLEVBQUUsRUFBRTtvQkFDWCw0Q0FBNEM7b0JBQzVDLE9BQU8sRUFBRSxDQUFDO29CQUNWLDBEQUEwRDtvQkFDMUQsV0FBVyxFQUFFLENBQUM7b0JBQ2QsaURBQWlEO29CQUNqRCxhQUFhLEVBQUUsR0FBRztpQkFDbkI7Z0JBQ0QsUUFBUSxFQUFFLEVBQUMsSUFBSSxFQUFFLEVBQUMsS0FBSyxFQUFFLENBQUMsRUFBRSxNQUFNLEVBQUUsQ0FBQyxFQUFDLEVBQUM7Z0JBQ3ZDLE1BQU0sRUFBRTtvQkFDTixrRUFBa0U7b0JBQ2xFLGFBQWEsRUFBRSxDQUFDO29CQUNoQjs7O3VCQUdHO29CQUNILHdCQUF3QixFQUFFLEdBQUc7b0JBQzdCOzs7dUJBR0c7b0JBQ0gscUJBQXFCLEVBQUUsR0FBRztpQkFDM0I7Z0JBQ0QsT0FBTyxFQUFFO29CQUNQLHFEQUFxRDtvQkFDckQsSUFBSSxFQUFFLEdBQUc7aUJBQ1Y7YUFDRixDQUFDO1lBRUY7Ozs7OztlQU1HO1lBQ1Usb0JBQWEsR0FBRyxHQUFHLENBQUM7WUFFakMsb0RBQW9EO1lBQ3BELHFCQUE0QixjQUEwQztnQkFDcEUsd0VBQXdFO2dCQUN4RSxJQUFJLGNBQWMsQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFO29CQUNuQyxjQUFjLENBQUMsY0FBYyxDQUFDLENBQUM7aUJBQ2hDO2dCQUVELGtEQUFrRDtnQkFDbEQsSUFBSSxjQUFjLENBQUMsSUFBSSxDQUFDLElBQUksS0FBSyxRQUFBLFFBQVEsQ0FBQyxJQUFJLEVBQUU7b0JBQzlDLGNBQWMsQ0FBQyxjQUFjLENBQUMsQ0FBQztpQkFDaEM7cUJBQU0sSUFBSSxjQUFjLENBQUMsSUFBSSxDQUFDLElBQUksS0FBSyxRQUFBLFFBQVEsQ0FBQyxNQUFNLEVBQUU7b0JBQ3ZELGdCQUFnQixDQUFDLGNBQWMsQ0FBQyxDQUFDO2lCQUNsQztZQUNILENBQUM7WUFaZSxrQkFBVyxjQVkxQixDQUFBO1lBQUEsQ0FBQztZQUVGOzs7ZUFHRztZQUNILGdDQUFnQyxVQUFpQztnQkFDL0QsVUFBVSxDQUFDLFVBQVUsR0FBRyxVQUFVLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUM7b0JBQzlELE9BQUEsTUFBTSxDQUFDLFdBQVcsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDdEMsVUFBVSxDQUFDLFdBQVcsR0FBRyxVQUFVLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUM7b0JBQ2hFLE9BQUEsTUFBTSxDQUFDLFdBQVcsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDdkMsaUVBQWlFO2dCQUNqRSxVQUFVLENBQUMsT0FBTyxDQUFDLEtBQUssR0FBRyxVQUFVLENBQUMsS0FBSyxDQUFDO2dCQUM1QyxVQUFVLENBQUMsT0FBTyxDQUFDLE1BQU0sR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDO2dCQUM5QyxpRUFBaUU7Z0JBQ2pFLElBQUksV0FBVyxHQUFHLFVBQVUsQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDO2dCQUNoRCxJQUFJLFNBQVMsR0FBRyxDQUFDLENBQUMsQ0FBQywwQkFBMEI7Z0JBQzdDLHVDQUF1QztnQkFDdkMsVUFBVSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsS0FBSztvQkFDaEQsVUFBVSxDQUFDLFVBQVUsR0FBRyxVQUFVLENBQUMsV0FBVyxFQUM5QyxXQUFXLEdBQUcsU0FBUyxDQUFDLENBQUM7WUFFL0IsQ0FBQztZQUVEOztlQUVHO1lBQ0gsd0JBQXdCLGNBQTBDO2dCQUNoRSxJQUFJLFFBQVEsR0FBRyxjQUFjLENBQUMsU0FBUyxDQUFDLEtBQUssRUFBRSxDQUFDLEdBQUcsQ0FBQyxVQUFBLENBQUM7b0JBQ25ELE9BQU8sY0FBYyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQzFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsaUJBQWlCLEVBQ2hDLGNBQWMsQ0FBQyxrQkFBa0IsRUFDakMsY0FBYyxDQUFDLHVCQUF1QixDQUFDLENBQUM7Z0JBRWxELENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLFVBQUEsYUFBYTtvQkFDNUIseUJBQXlCO29CQUN6QixRQUFRLGFBQWEsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFO3dCQUMvQixLQUFLLFFBQUEsUUFBUSxDQUFDLEVBQUU7NEJBQ2QsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxhQUFhLEVBQUUsT0FBQSxNQUFNLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxDQUFDOzRCQUM1QyxNQUFNO3dCQUNSLEtBQUssUUFBQSxRQUFRLENBQUMsTUFBTTs0QkFDbEIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxhQUFhLEVBQUUsT0FBQSxNQUFNLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDOzRCQUNoRCxNQUFNO3dCQUNSLEtBQUssUUFBQSxRQUFRLENBQUMsSUFBSTs0QkFDaEIsSUFBSSxDQUFDLGFBQWEsQ0FBQyxRQUFRLEVBQUU7Z0NBQzNCLDJEQUEyRDtnQ0FDM0QsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxhQUFhLEVBQUUsT0FBQSxNQUFNLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDO2dDQUM5QyxhQUFhLENBQUMsTUFBTTtvQ0FDaEIsT0FBQSxNQUFNLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQzs2QkFDakU7aUNBQU07Z0NBQ0wsSUFBSSxrQkFBa0IsR0FDUSxhQUFhLENBQUM7Z0NBQzVDLFdBQVcsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsbUNBQW1DOzZCQUNyRTs0QkFDRCxNQUFNO3dCQUNSLEtBQUssUUFBQSxRQUFRLENBQUMsTUFBTTs0QkFDbEIsSUFBSSxhQUFhLENBQUMsUUFBUSxFQUFFO2dDQUMxQixDQUFDLENBQUMsTUFBTSxDQUFDLGFBQWEsRUFBRSxPQUFBLE1BQU0sQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDO2dDQUN6RCxJQUFJLGtCQUFrQixHQUNRLGFBQWEsQ0FBQztnQ0FDNUMsV0FBVyxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxtQ0FBbUM7NkJBQ3JFO2lDQUFNO2dDQUNMLElBQUksa0JBQWtCLEdBQ1EsYUFBYSxDQUFDO2dDQUM1QyxJQUFJLFlBQVksR0FDZCxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsQ0FBQztvQ0FDMUMsT0FBQSxNQUFNLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQztvQ0FDakMsT0FBQSxNQUFNLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUM7Z0NBQ3RDLENBQUMsQ0FBQyxNQUFNLENBQUMsYUFBYSxFQUFFLFlBQVksQ0FBQyxDQUFDOzZCQUN2Qzs0QkFDRCxNQUFNO3dCQUNSOzRCQUNFLE1BQU0sS0FBSyxDQUFDLDBCQUEwQixHQUFHLGFBQWEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7cUJBQ3JFO29CQUNELG9FQUFvRTtvQkFDcEUsNkJBQTZCO29CQUM3QixJQUFJLENBQUMsYUFBYSxDQUFDLFFBQVEsRUFBRTt3QkFDM0Isc0JBQXNCLENBQUMsYUFBYSxDQUFDLENBQUM7cUJBQ3ZDO29CQUNELGtDQUFrQztvQkFDbEMsZ0JBQWdCLENBQUMsYUFBYSxDQUFDLENBQUM7Z0JBQ2xDLENBQUMsQ0FBQyxDQUFDO1lBQ0wsQ0FBQztZQUVEOzs7OztlQUtHO1lBQ0gscUJBQ0ksS0FBdUUsRUFDdkUsTUFBTTtnQkFDUixDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxLQUFLLEVBQUUsRUFBRTtvQkFDdEIsT0FBTyxFQUFFLE1BQU0sQ0FBQyxPQUFPO29CQUN2QixPQUFPLEVBQUUsTUFBTSxDQUFDLE9BQU87b0JBQ3ZCLE9BQU8sRUFBRSxNQUFNLENBQUMsT0FBTztpQkFDeEIsQ0FBQyxDQUFDO2dCQUNILElBQUksZUFBZSxHQUFHLEVBQUUsQ0FBQztnQkFDekIsSUFBSSxrQkFBa0IsR0FBRyxFQUFFLENBQUM7Z0JBRTVCLDRFQUE0RTtnQkFDNUUsd0NBQXdDO2dCQUN4QyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLEVBQUUsRUFBRSxVQUFBLFFBQVE7b0JBQzVCLElBQUksUUFBUSxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7b0JBQ3BDLElBQUksUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLEtBQUssUUFBQSxRQUFRLENBQUMsTUFBTSxFQUFFO3dCQUMxQyxlQUFlLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO3FCQUNoQzt5QkFBTTt3QkFDTCxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7cUJBQ25DO2dCQUNILENBQUMsQ0FBQyxDQUFDO2dCQUVILGtFQUFrRTtnQkFDbEUsSUFBSSxDQUFDLGtCQUFrQixDQUFDLE1BQU0sRUFBRTtvQkFDOUIsT0FBTzt3QkFDTCxLQUFLLEVBQUUsQ0FBQzt3QkFDUixNQUFNLEVBQUUsQ0FBQztxQkFDVixDQUFDO2lCQUNIO2dCQUNELEtBQUssQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBRXBCLDJFQUEyRTtnQkFDM0UsNEVBQTRFO2dCQUM1RSxxRUFBcUU7Z0JBQ3JFLCtCQUErQjtnQkFDL0IsSUFBSSxJQUFJLEdBQUcsUUFBUSxDQUFDO2dCQUNwQixJQUFJLElBQUksR0FBRyxRQUFRLENBQUM7Z0JBQ3BCLElBQUksSUFBSSxHQUFHLENBQUMsUUFBUSxDQUFDO2dCQUNyQixJQUFJLElBQUksR0FBRyxDQUFDLFFBQVEsQ0FBQztnQkFDckIsQ0FBQyxDQUFDLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxVQUFBLFFBQVE7b0JBQ2pDLElBQUksUUFBUSxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7b0JBQ3BDLElBQUksQ0FBQyxHQUFHLEdBQUcsR0FBRyxRQUFRLENBQUMsS0FBSyxDQUFDO29CQUM3QixJQUFJLEVBQUUsR0FBRyxRQUFRLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztvQkFDeEIsSUFBSSxFQUFFLEdBQUcsUUFBUSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7b0JBQ3hCLElBQUksR0FBRyxFQUFFLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztvQkFDN0IsSUFBSSxHQUFHLEVBQUUsR0FBRyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO29CQUM3Qiw4REFBOEQ7b0JBQzlELElBQUksQ0FBQyxHQUFHLEdBQUcsR0FBRyxRQUFRLENBQUMsTUFBTSxDQUFDO29CQUM5QixJQUFJLEVBQUUsR0FBRyxRQUFRLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztvQkFDeEIsSUFBSSxFQUFFLEdBQUcsUUFBUSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7b0JBQ3hCLElBQUksR0FBRyxFQUFFLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztvQkFDN0IsSUFBSSxHQUFHLEVBQUUsR0FBRyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO2dCQUMvQixDQUFDLENBQUMsQ0FBQztnQkFDSCxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLEVBQUUsRUFBRSxVQUFBLE9BQU87b0JBQzNCLElBQUksUUFBUSxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7b0JBQ25DLElBQUksUUFBUSxDQUFDLFVBQVUsRUFBRTt3QkFDdkIsT0FBTyxDQUFDLG1EQUFtRDtxQkFDNUQ7b0JBRUQsOERBQThEO29CQUM5RCxtRUFBbUU7b0JBQ25FLHNFQUFzRTtvQkFDdEUsK0RBQStEO29CQUMvRCxrRUFBa0U7b0JBQ2xFLGFBQWE7b0JBQ2IsSUFBSSxVQUFVLEdBQUcsS0FBSyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUNqRCxJQUFJLFFBQVEsR0FBRyxLQUFLLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBRS9DLHdFQUF3RTtvQkFDeEUseUVBQXlFO29CQUN6RSxtRUFBbUU7b0JBQ25FLDRDQUE0QztvQkFDNUMsSUFBSSxRQUFRLENBQUMsTUFBTSxDQUFDLE1BQU0sS0FBSyxDQUFDLElBQUksY0FBYyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsRUFBRTt3QkFDbkUsSUFBSSxVQUFVLElBQUksSUFBSSxFQUFFOzRCQUN0QixJQUFJLFFBQVEsR0FBRyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUM7Z0NBQ2hDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLDRCQUE0QixDQUFDLFVBQVUsQ0FBQyxDQUFDOzRCQUM1RCxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxRQUFRLENBQUM7eUJBQ2pDO3dCQUNELElBQUksUUFBUSxJQUFJLElBQUksRUFBRTs0QkFDcEIsSUFBSSxNQUFNLEdBQUcsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDO2dDQUM1QixRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyw0QkFBNEIsQ0FBQyxRQUFRLENBQUMsQ0FBQzs0QkFDeEQsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsTUFBTSxDQUFDO3lCQUMvQjt3QkFDRCxxREFBcUQ7d0JBQ3JELFFBQVEsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztxQkFDNUQ7b0JBQ0QsZ0RBQWdEO29CQUNoRCxJQUFJLGVBQWUsR0FBRyxRQUFRLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDO29CQUNsRSwrREFBK0Q7b0JBQy9ELElBQUksUUFBUSxJQUFJLElBQUksRUFBRTt3QkFDcEIsUUFBUSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7NEJBQ3ZDLHFCQUFxQixDQUFDLGVBQWUsRUFBRSxRQUFRLENBQUMsQ0FBQztxQkFDdEQ7b0JBQ0QsMkNBQTJDO29CQUMzQyxJQUFJLFdBQVcsR0FBRyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUNyQyxxREFBcUQ7b0JBQ3JELElBQUksVUFBVSxJQUFJLElBQUksRUFBRTt3QkFDdEIsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsR0FBRyxxQkFBcUIsQ0FBQyxXQUFXLEVBQUUsVUFBVSxDQUFDLENBQUM7cUJBQ3JFO29CQUVELENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sRUFBRSxVQUFDLEtBQW1CO3dCQUN4QyxJQUFJLEdBQUcsS0FBSyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQzt3QkFDdkMsSUFBSSxHQUFHLEtBQUssQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7d0JBQ3ZDLElBQUksR0FBRyxLQUFLLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO3dCQUN2QyxJQUFJLEdBQUcsS0FBSyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztvQkFDekMsQ0FBQyxDQUFDLENBQUM7Z0JBQ1AsQ0FBQyxDQUFDLENBQUM7Z0JBRUgsMEVBQTBFO2dCQUMxRSxrQ0FBa0M7Z0JBQ2xDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssRUFBRSxFQUFFLFVBQUEsUUFBUTtvQkFDNUIsSUFBSSxRQUFRLEdBQUcsS0FBSyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztvQkFDcEMsUUFBUSxDQUFDLENBQUMsSUFBSSxJQUFJLENBQUM7b0JBQ25CLFFBQVEsQ0FBQyxDQUFDLElBQUksSUFBSSxDQUFDO2dCQUNyQixDQUFDLENBQUMsQ0FBQztnQkFDSCxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLEVBQUUsRUFBRSxVQUFBLE9BQU87b0JBQzNCLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxNQUFNLEVBQUUsVUFBQyxLQUFtQjt3QkFDbkQsS0FBSyxDQUFDLENBQUMsSUFBSSxJQUFJLENBQUM7d0JBQ2hCLEtBQUssQ0FBQyxDQUFDLElBQUksSUFBSSxDQUFDO29CQUNsQixDQUFDLENBQUMsQ0FBQztnQkFDUCxDQUFDLENBQUMsQ0FBQztnQkFFSCxPQUFPO29CQUNMLEtBQUssRUFBRSxJQUFJLEdBQUcsSUFBSTtvQkFDbEIsTUFBTSxFQUFFLElBQUksR0FBRyxJQUFJO2lCQUNwQixDQUFDO1lBQ0osQ0FBQztZQUVELDJEQUEyRDtZQUMzRCx3QkFBd0IsY0FBMEM7Z0JBQ2hFLDBFQUEwRTtnQkFDMUUsSUFBSSxNQUFNLEdBQUcsT0FBQSxNQUFNLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQztnQkFDbEMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxjQUFjLEVBQUUsTUFBTSxDQUFDLENBQUM7Z0JBQ2pDLHNFQUFzRTtnQkFDdEUsY0FBYztnQkFDZCxDQUFDLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxPQUFPLEVBQzNCLFdBQVcsQ0FBQyxjQUFjLENBQUMsU0FBUyxFQUFFLE9BQUEsTUFBTSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO2dCQUU5RCx1RUFBdUU7Z0JBQ3ZFLDZFQUE2RTtnQkFDN0UsOENBQThDO2dCQUM5QyxJQUFJLGlCQUFpQixHQUFHLGNBQWMsQ0FBQyxpQkFBaUIsQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDN0QsQ0FBQyxDQUFDLEdBQUcsQ0FDRCxjQUFjLENBQUMsaUJBQWlCLEVBQ2hDLFVBQUEsVUFBVSxJQUFJLE9BQUEsVUFBVSxDQUFDLEtBQUssRUFBaEIsQ0FBZ0IsQ0FDakMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztnQkFDbkIsY0FBYyxDQUFDLFlBQVksQ0FBQyxLQUFLLEdBQUcsaUJBQWlCLElBQUksSUFBSSxDQUFDLENBQUM7b0JBQzNELGlCQUFpQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBRTFCLGNBQWMsQ0FBQyxZQUFZLENBQUMsTUFBTTtvQkFDaEMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsaUJBQWlCLEVBQUUsVUFBQyxNQUFNLEVBQUUsS0FBSyxFQUFFLENBQUM7d0JBQzFELElBQUksT0FBTyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDaEQsMkRBQTJEO3dCQUMzRCxLQUFLLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQzt3QkFDWixLQUFLLENBQUMsQ0FBQyxHQUFHLE1BQU0sR0FBRyxPQUFPLEdBQUcsS0FBSyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7d0JBQzlDLE9BQU8sTUFBTSxHQUFHLE9BQU8sR0FBRyxLQUFLLENBQUMsTUFBTSxDQUFDO29CQUN6QyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7Z0JBRVIsd0VBQXdFO2dCQUN4RSx3RUFBd0U7Z0JBQ3hFLHNEQUFzRDtnQkFDdEQsSUFBSSxrQkFBa0IsR0FBRyxjQUFjLENBQUMsa0JBQWtCLENBQUMsTUFBTSxDQUFDLENBQUM7b0JBQy9ELENBQUMsQ0FBQyxHQUFHLENBQ0QsY0FBYyxDQUFDLGtCQUFrQixFQUNqQyxVQUFBLFVBQVUsSUFBSSxPQUFBLFVBQVUsQ0FBQyxLQUFLLEVBQWhCLENBQWdCLENBQ2pDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7Z0JBQ25CLGNBQWMsQ0FBQyxhQUFhLENBQUMsS0FBSyxHQUFHLGtCQUFrQixJQUFJLElBQUksQ0FBQyxDQUFDO29CQUM3RCxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUUzQixjQUFjLENBQUMsYUFBYSxDQUFDLE1BQU07b0JBQ2pDLENBQUMsQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLGtCQUFrQixFQUFFLFVBQUMsTUFBTSxFQUFFLEtBQUssRUFBRSxDQUFDO3dCQUMzRCxJQUFJLE9BQU8sR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQ2hELDJEQUEyRDt3QkFDM0QsS0FBSyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7d0JBQ1osS0FBSyxDQUFDLENBQUMsR0FBRyxNQUFNLEdBQUcsT0FBTyxHQUFHLEtBQUssQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO3dCQUM5QyxPQUFPLE1BQU0sR0FBRyxPQUFPLEdBQUcsS0FBSyxDQUFDLE1BQU0sQ0FBQztvQkFDekMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO2dCQUVSLDZFQUE2RTtnQkFDN0UsMkVBQTJFO2dCQUMzRSxxRUFBcUU7Z0JBQ3JFLElBQUksd0JBQXdCLEdBQUcsY0FBYyxDQUFDLHVCQUF1QixDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUMxRSxDQUFDLENBQUMsR0FBRyxDQUNELGNBQWMsQ0FBQyx1QkFBdUIsRUFDdEMsVUFBQSxVQUFVLElBQUksT0FBQSxVQUFVLENBQUMsS0FBSyxFQUFoQixDQUFnQixDQUNqQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO2dCQUNuQixjQUFjLENBQUMsbUJBQW1CLENBQUMsS0FBSyxHQUFHLHdCQUF3QixJQUFJLElBQUksQ0FBQyxDQUFDO29CQUN6RSx3QkFBd0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUVqQyxjQUFjLENBQUMsbUJBQW1CLENBQUMsTUFBTTtvQkFDdkMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsdUJBQXVCLEVBQUUsVUFBQyxNQUFNLEVBQUUsS0FBSyxFQUFFLENBQUM7d0JBQ2hFLElBQUksT0FBTyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDaEQsMkRBQTJEO3dCQUMzRCxLQUFLLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQzt3QkFDWixLQUFLLENBQUMsQ0FBQyxHQUFHLE1BQU0sR0FBRyxPQUFPLEdBQUcsS0FBSyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7d0JBQzlDLE9BQU8sTUFBTSxHQUFHLE9BQU8sR0FBRyxLQUFLLENBQUMsTUFBTSxDQUFDO29CQUN6QyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7Z0JBRVIsbUVBQW1FO2dCQUNuRSxxQkFBcUI7Z0JBQ3JCLElBQUksUUFBUSxHQUFHLENBQUMsQ0FBQztnQkFDakIsSUFBSSxjQUFjLENBQUMsaUJBQWlCLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtvQkFDL0MsUUFBUSxFQUFFLENBQUM7aUJBQ1o7Z0JBQ0QsSUFBSSxjQUFjLENBQUMsa0JBQWtCLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtvQkFDaEQsUUFBUSxFQUFFLENBQUM7aUJBQ1o7Z0JBQ0QsSUFBSSxjQUFjLENBQUMsdUJBQXVCLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtvQkFDckQsUUFBUSxFQUFFLENBQUM7aUJBQ1o7Z0JBQ0QsSUFBSSxjQUFjLENBQUMsU0FBUyxDQUFDLFNBQVMsRUFBRSxHQUFHLENBQUMsRUFBRTtvQkFDNUMsUUFBUSxFQUFFLENBQUM7aUJBQ1o7Z0JBQ0QsSUFBSSxNQUFNLEdBQUcsT0FBQSxNQUFNLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUM7Z0JBQ2pELElBQUksT0FBTyxHQUFHLFFBQVEsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLEdBQUcsTUFBTSxDQUFDLENBQUM7Z0JBRXRELDZFQUE2RTtnQkFDN0UsdUVBQXVFO2dCQUN2RSxJQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUNyQixPQUFBLGFBQWEsRUFDYixjQUFjLENBQUMsWUFBWSxDQUFDLEtBQUssR0FBRyxjQUFjLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUM1RSxjQUFjLENBQUMsT0FBTyxDQUFDLEtBQUssSUFBSSxRQUFRLEdBQUcsT0FBTztvQkFDOUMsY0FBYyxDQUFDLG1CQUFtQixDQUFDLEtBQUssR0FBRyxPQUFPLENBQUM7Z0JBQ3ZELGNBQWMsQ0FBQyxPQUFPLENBQUMsTUFBTTtvQkFDM0IsTUFBTSxDQUFDLFdBQVc7d0JBQ2xCLElBQUksQ0FBQyxHQUFHLENBQ04sY0FBYyxDQUFDLFlBQVksQ0FBQyxNQUFNLEVBQ2xDLGNBQWMsQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUM3QixjQUFjLENBQUMsbUJBQW1CLENBQUMsTUFBTSxFQUN6QyxjQUFjLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FDdEMsQ0FBQztnQkFDRiw2REFBNkQ7Z0JBQzdELGNBQWMsQ0FBQyxLQUFLLEdBQUcsY0FBYyxDQUFDLE9BQU8sQ0FBQyxLQUFLO29CQUMvQyxNQUFNLENBQUMsV0FBVyxHQUFHLE1BQU0sQ0FBQyxZQUFZLENBQUM7Z0JBRTdDLDhEQUE4RDtnQkFDOUQsY0FBYyxDQUFDLE1BQU07b0JBQ2pCLGNBQWMsQ0FBQyxVQUFVO3dCQUN6QixjQUFjLENBQUMsT0FBTyxDQUFDLE1BQU07d0JBQzdCLGNBQWMsQ0FBQyxhQUFhLENBQUM7WUFDbkMsQ0FBQztZQUVEOzs7ZUFHRztZQUNILDBCQUEwQixJQUFnQztnQkFDeEQsSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQztnQkFFM0IsSUFBSSxNQUFNLEdBQUcsT0FBQSxNQUFNLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQztnQkFDcEMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsTUFBTSxDQUFDLENBQUM7Z0JBRXZCLG1CQUFtQjtnQkFDbkIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLFdBQVcsQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLE9BQUEsTUFBTSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO2dCQUV6RSxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLEVBQUUsRUFBRSxVQUFBLFFBQVE7b0JBQzVCLEtBQUssQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQztnQkFDeEMsQ0FBQyxDQUFDLENBQUM7Z0JBRUgsdUVBQXVFO2dCQUN2RSxJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxHQUFHLE1BQU0sQ0FBQyxXQUFXLEdBQUcsTUFBTSxDQUFDLFlBQVksQ0FBQztnQkFDM0UsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUMsVUFBVSxHQUFHLE1BQU0sQ0FBQyxhQUFhLENBQUM7WUFDL0UsQ0FBQztZQUVEOzs7Ozs7O2VBT0c7WUFDSCwwQkFBMEIsY0FBcUM7Z0JBQzdELDRFQUE0RTtnQkFDNUUsNkRBQTZEO2dCQUM3RCxJQUFJLGNBQWMsQ0FBQyxRQUFRLEVBQUU7b0JBQzNCLE9BQU87aUJBQ1I7Z0JBRUQsSUFBSSxhQUFhLEdBQUcsY0FBYyxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUM7Z0JBQ3RELElBQUksY0FBYyxHQUFHLGNBQWMsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDO2dCQUV4RCxvQ0FBb0M7Z0JBQ3BDLENBQUMsQ0FBQyxJQUFJLENBQUMsYUFBYSxFQUFFLFVBQUEsQ0FBQyxJQUFJLE9BQUEsY0FBYyxDQUFDLENBQUMsQ0FBQyxFQUFqQixDQUFpQixDQUFDLENBQUM7Z0JBRTlDLHFDQUFxQztnQkFDckMsQ0FBQyxDQUFDLElBQUksQ0FBQyxjQUFjLEVBQUUsVUFBQSxDQUFDLElBQUksT0FBQSxjQUFjLENBQUMsQ0FBQyxDQUFDLEVBQWpCLENBQWlCLENBQUMsQ0FBQztnQkFFL0MsSUFBSSxNQUFNLEdBQUcsT0FBQSxNQUFNLENBQUMsV0FBVyxDQUFDO2dCQUVoQyxrREFBa0Q7Z0JBQ2xELHNDQUFzQztnQkFDdEMsNEJBQTRCO2dCQUM1Qiw2RUFBNkU7Z0JBQzdFLElBQUksV0FBVyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsYUFBYSxFQUNwQyxVQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsQ0FBQztvQkFDWCxJQUFJLE9BQU8sR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQ3pDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEdBQUcsTUFBTSxDQUFDLE9BQU8sQ0FBQztvQkFDdEUsQ0FBQyxDQUFDLEVBQUUsR0FBRyxNQUFNLEdBQUcsT0FBTyxHQUFHLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO29CQUN2QyxPQUFPLE1BQU0sR0FBRyxPQUFPLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQztnQkFDckMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO2dCQUVWLENBQUMsQ0FBQyxJQUFJLENBQUMsYUFBYSxFQUFFLFVBQUEsQ0FBQztvQkFDckIsQ0FBQyxDQUFDLEVBQUUsSUFBSSxXQUFXLEdBQUcsQ0FBQyxDQUFDO29CQUV4QixDQUFDLENBQUMsV0FBVyxHQUFHLE1BQU0sQ0FBQyxXQUFXLENBQUM7Z0JBQ3JDLENBQUMsQ0FBQyxDQUFDO2dCQUVILGtEQUFrRDtnQkFDbEQsdUNBQXVDO2dCQUN2Qyw0QkFBNEI7Z0JBQzVCLDZDQUE2QztnQkFDN0MsbURBQW1EO2dCQUNuRCxJQUFJLFlBQVksR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLGNBQWMsRUFDdEMsVUFBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLENBQUM7b0JBQ1gsSUFBSSxPQUFPLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUN6QyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsR0FBRyxNQUFNLENBQUMsT0FBTyxDQUFDO29CQUNyRSxDQUFDLENBQUMsRUFBRSxHQUFHLE1BQU0sR0FBRyxPQUFPLEdBQUcsQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7b0JBQ3ZDLE9BQU8sTUFBTSxHQUFHLE9BQU8sR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDO2dCQUNyQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7Z0JBRVYsQ0FBQyxDQUFDLElBQUksQ0FBQyxjQUFjLEVBQUUsVUFBQSxDQUFDO29CQUN0Qix3Q0FBd0M7b0JBQ3hDLCtDQUErQztvQkFDL0MsQ0FBQyxDQUFDLEVBQUUsSUFBSSxZQUFZLEdBQUcsQ0FBQyxDQUFDO29CQUV6QixDQUFDLENBQUMsV0FBVyxHQUFHLE1BQU0sQ0FBQyxXQUFXLENBQUM7Z0JBQ3JDLENBQUMsQ0FBQyxDQUFDO2dCQUVILGtFQUFrRTtnQkFDbEUsbUJBQW1CO2dCQUVuQixJQUFJLGFBQWEsR0FDYixJQUFJLENBQUMsR0FBRyxDQUFDLGNBQWMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxHQUFHLGNBQWMsQ0FBQyxNQUFNLEVBQ3RELFdBQVcsR0FBRyxDQUFDLENBQUMsQ0FBQztnQkFDekIsYUFBYSxHQUFHLGFBQWEsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDO2dCQUV0RCxJQUFJLEdBQUcsR0FBRyxFQUFFLENBQUMsV0FBVyxFQUFFO3FCQUN2QixNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsYUFBYSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQztxQkFDckMsS0FBSyxDQUFDLENBQUMsQ0FBQyxhQUFhLEVBQUUsYUFBYSxDQUFDLENBQUMsQ0FBQztnQkFFMUMscUNBQXFDO2dCQUNyQyxDQUFDLENBQUMsSUFBSSxDQUFDLGFBQWEsRUFBRSxVQUFDLENBQUMsRUFBRSxDQUFDO29CQUN6QixDQUFDLENBQUMsTUFBTSxHQUFHO3dCQUNULDBCQUEwQjt3QkFDMUI7NEJBQ0UsRUFBRSxFQUFFLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLEtBQUssR0FBRyxDQUFDOzRCQUN0QixFQUFFLEVBQUUsQ0FBQyxDQUFDLEVBQUU7eUJBQ1Q7d0JBRUQsb0JBQW9CO3dCQUNwQjs0QkFDRSxFQUFFLEVBQUUsQ0FBRSxjQUFjLENBQUMsT0FBTyxDQUFDLEtBQUssR0FBRyxDQUFDOzRCQUN0Qyw2Q0FBNkM7NEJBQzdDLGlDQUFpQzs0QkFDakMsRUFBRSxFQUFFLGFBQWEsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7eUJBQzFDO3FCQUNGLENBQUM7Z0JBQ0osQ0FBQyxDQUFDLENBQUM7Z0JBRUgsbUVBQW1FO2dCQUNuRSxtQkFBbUI7Z0JBQ25CLElBQUksY0FBYyxHQUNkLElBQUksQ0FBQyxHQUFHLENBQUMsY0FBYyxDQUFDLE1BQU0sR0FBRyxDQUFDLEdBQUcsY0FBYyxDQUFDLE1BQU0sRUFDdEQsWUFBWSxHQUFHLENBQUMsQ0FBQyxDQUFDO2dCQUMxQixjQUFjLEdBQUcsY0FBYyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUM7Z0JBQ3pELElBQUksSUFBSSxHQUFHLEVBQUUsQ0FBQyxXQUFXLEVBQUU7cUJBQ3hCLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxjQUFjLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDO3FCQUN0QyxLQUFLLENBQUMsQ0FBQyxDQUFDLGNBQWMsRUFBRSxjQUFjLENBQUMsQ0FBQyxDQUFDO2dCQUU1QyxDQUFDLENBQUMsSUFBSSxDQUFDLGNBQWMsRUFBRSxVQUFDLENBQUMsRUFBRSxDQUFDO29CQUMxQixtREFBbUQ7b0JBQ25ELENBQUMsQ0FBQyxNQUFNLEdBQUc7d0JBQ1Qsb0JBQW9CO3dCQUNwQjs0QkFDRSxFQUFFLEVBQUUsY0FBYyxDQUFDLE9BQU8sQ0FBQyxLQUFLLEdBQUcsQ0FBQzs0QkFDcEMsNkNBQTZDOzRCQUM3QyxpQ0FBaUM7NEJBQ2pDLEVBQUUsRUFBRSxjQUFjLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO3lCQUM1Qzt3QkFDRCwwQkFBMEI7d0JBQzFCOzRCQUNFLEVBQUUsRUFBRSxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQyxLQUFLLEdBQUcsQ0FBQzs0QkFDdEIsRUFBRSxFQUFFLENBQUMsQ0FBQyxFQUFFO3lCQUNUO3FCQUNGLENBQUM7Z0JBQ0osQ0FBQyxDQUFDLENBQUM7Z0JBRUgsY0FBYyxDQUFDLE1BQU07b0JBQ2pCLElBQUksQ0FBQyxHQUFHLENBQUMsY0FBYyxDQUFDLE1BQU0sRUFBRSxXQUFXLEVBQUUsWUFBWSxDQUFDLENBQUM7WUFDakUsQ0FBQztZQUVEOztlQUVHO1lBQ0gsd0JBQXdCLENBQW9CO2dCQUMxQyxRQUFRLENBQUMsQ0FBQyxjQUFjLEVBQUU7b0JBQ3hCLEtBQUssUUFBQSxNQUFNLENBQUMsY0FBYyxDQUFDLFFBQVE7d0JBQ2pDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLE9BQUEsTUFBTSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQzt3QkFDbEMsTUFBTTtvQkFDUixLQUFLLFFBQUEsTUFBTSxDQUFDLGNBQWMsQ0FBQyxRQUFRO3dCQUNqQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxLQUFLLFFBQUEsUUFBUSxDQUFDLEVBQUUsRUFBRTs0QkFDL0IsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsT0FBQSxNQUFNLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxDQUFDO3lCQUNyQzs2QkFBTSxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxLQUFLLFFBQUEsUUFBUSxDQUFDLElBQUksRUFBRTs0QkFDeEMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsT0FBQSxNQUFNLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDO3lCQUN2Qzs2QkFBTSxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxLQUFLLFFBQUEsUUFBUSxDQUFDLE1BQU0sRUFBRTs0QkFDMUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsT0FBQSxNQUFNLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxDQUFDO3lCQUN6Qzs2QkFBTTs0QkFDTCxNQUFNLEtBQUssQ0FBQyxxQkFBcUIsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO3lCQUNsRDt3QkFDRCxNQUFNO29CQUNSLEtBQUssUUFBQSxNQUFNLENBQUMsY0FBYyxDQUFDLE9BQU87d0JBQ2hDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLE9BQUEsTUFBTSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQzt3QkFDbEMsTUFBTTtpQkFDVDtZQUNILENBQUM7WUFFRDs7O2VBR0c7WUFDSCxzQ0FBNkMsVUFBaUM7Z0JBRTVFLElBQUksVUFBVSxDQUFDLFFBQVEsRUFBRTtvQkFDdkIsT0FBTyxVQUFVLENBQUMsQ0FBQyxDQUFDO2lCQUNyQjtnQkFDRCxJQUFJLEVBQUUsR0FBRyxVQUFVLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDMUUsT0FBTyxVQUFVLENBQUMsQ0FBQyxHQUFHLFVBQVUsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxHQUFHLEVBQUU7b0JBQzNDLFVBQVUsQ0FBQyxPQUFPLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQztZQUNuQyxDQUFDO1lBUmUsbUNBQTRCLCtCQVEzQyxDQUFBO1lBRUQseURBQXlEO1lBQ3pELCtCQUErQixDQUFlLEVBQUUsQ0FBZTtnQkFDN0QsSUFBSSxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNuQixJQUFJLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ25CLE9BQU8sR0FBRyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRSxHQUFHLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxFQUFFLENBQUM7WUFDNUMsQ0FBQztZQUVEOztlQUVHO1lBQ0gsd0JBQXdCLE1BQXNCO2dCQUM1QyxJQUFJLEtBQUssR0FBRyxxQkFBcUIsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ3hELEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxNQUFNLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRTtvQkFDMUMsSUFBSSxRQUFRLEdBQUcscUJBQXFCLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDL0QsZ0NBQWdDO29CQUNoQyxJQUFJLElBQUksQ0FBQyxHQUFHLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQyxHQUFHLENBQUMsRUFBRTt3QkFDbEMsT0FBTyxLQUFLLENBQUM7cUJBQ2Q7b0JBQ0QsS0FBSyxHQUFHLFFBQVEsQ0FBQztpQkFDbEI7Z0JBQ0QsT0FBTyxJQUFJLENBQUM7WUFDZCxDQUFDO1lBRUQ7OztlQUdHO1lBQ0gsK0JBQ0ksS0FBbUIsRUFBRSxJQUEyQjtnQkFDbEQsNkNBQTZDO2dCQUM3QyxJQUFJLEVBQUUsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7b0JBQ3JCLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLDRCQUE0QixDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUMvQyxJQUFJLEVBQUUsR0FBRyxJQUFJLENBQUMsQ0FBQyxDQUFDO2dCQUNoQixzQkFBc0I7Z0JBQ3RCLElBQUksRUFBRSxHQUFHLEtBQUssQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDO2dCQUN0QixJQUFJLEVBQUUsR0FBRyxLQUFLLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQztnQkFDdEIsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0JBQ3hELElBQUksQ0FBQyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDO2dCQUMxRCxJQUFJLE1BQU0sRUFBRSxNQUFNLENBQUM7Z0JBQ25CLElBQUksSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFJLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsRUFBRTtvQkFDaEQsb0RBQW9EO29CQUNwRCxJQUFJLEVBQUUsR0FBRyxDQUFDLEVBQUU7d0JBQ1YsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO3FCQUNSO29CQUNELE1BQU0sR0FBRyxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsQ0FBQztvQkFDeEMsTUFBTSxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7aUJBQ2hCO3FCQUFNO29CQUNMLHNEQUFzRDtvQkFDdEQsSUFBSSxFQUFFLEdBQUcsQ0FBQyxFQUFFO3dCQUNWLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztxQkFDUjtvQkFDRCxNQUFNLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztvQkFDZixNQUFNLEdBQUcsRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLENBQUM7aUJBQ3pDO2dCQUNELE9BQU8sRUFBQyxDQUFDLEVBQUUsRUFBRSxHQUFHLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRSxHQUFHLE1BQU0sRUFBQyxDQUFDO1lBQzFDLENBQUM7UUFFRCxDQUFDLEVBcHhCZSxNQUFNLEdBQU4sY0FBTSxLQUFOLGNBQU0sUUFveEJyQjtJQUFELENBQUMsRUFweEJTLEtBQUssR0FBTCxRQUFLLEtBQUwsUUFBSyxRQW94QmQ7QUFBRCxDQUFDLEVBcHhCTSxFQUFFLEtBQUYsRUFBRSxRQW94QlIsQ0FBQyxlQUFlIiwic291cmNlc0NvbnRlbnQiOlsiLyogQ29weXJpZ2h0IDIwMTUgVGhlIFRlbnNvckZsb3cgQXV0aG9ycy4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cblxuTGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlLCBWZXJzaW9uIDIuMCAodGhlICdMaWNlbnNlJyk7XG55b3UgbWF5IG5vdCB1c2UgdGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlIHdpdGggdGhlIExpY2Vuc2UuXG5Zb3UgbWF5IG9idGFpbiBhIGNvcHkgb2YgdGhlIExpY2Vuc2UgYXRcblxuICAgIGh0dHA6Ly93d3cuYXBhY2hlLm9yZy9saWNlbnNlcy9MSUNFTlNFLTIuMFxuXG5Vbmxlc3MgcmVxdWlyZWQgYnkgYXBwbGljYWJsZSBsYXcgb3IgYWdyZWVkIHRvIGluIHdyaXRpbmcsIHNvZnR3YXJlXG5kaXN0cmlidXRlZCB1bmRlciB0aGUgTGljZW5zZSBpcyBkaXN0cmlidXRlZCBvbiBhbiAnQVMgSVMnIEJBU0lTLFxuV0lUSE9VVCBXQVJSQU5USUVTIE9SIENPTkRJVElPTlMgT0YgQU5ZIEtJTkQsIGVpdGhlciBleHByZXNzIG9yIGltcGxpZWQuXG5TZWUgdGhlIExpY2Vuc2UgZm9yIHRoZSBzcGVjaWZpYyBsYW5ndWFnZSBnb3Zlcm5pbmcgcGVybWlzc2lvbnMgYW5kXG5saW1pdGF0aW9ucyB1bmRlciB0aGUgTGljZW5zZS5cbj09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSovXG5tb2R1bGUgdGYuZ3JhcGgubGF5b3V0IHtcblxuLyoqIFNldCBvZiBwYXJhbWV0ZXJzIHRoYXQgZGVmaW5lIHRoZSBsb29rIGFuZCBmZWVsIG9mIHRoZSBncmFwaC4gKi9cbmV4cG9ydCBjb25zdCBQQVJBTVMgPSB7XG4gIGFuaW1hdGlvbjoge1xuICAgIC8qKiBEZWZhdWx0IGR1cmF0aW9uIGZvciBncmFwaCBhbmltYXRpb25zIGluIG1zLiAqL1xuICAgIGR1cmF0aW9uOiAyNTBcbiAgfSxcbiAgZ3JhcGg6IHtcbiAgICAvKiogR3JhcGggcGFyYW1ldGVyIGZvciBtZXRhbm9kZS4gKi9cbiAgICBtZXRhOiB7XG4gICAgICAvKipcbiAgICAgICAqIERhZ3JlJ3Mgbm9kZXNlcCBwYXJhbSAtIG51bWJlciBvZiBwaXhlbHMgdGhhdFxuICAgICAgICogc2VwYXJhdGUgbm9kZXMgaG9yaXpvbnRhbGx5IGluIHRoZSBsYXlvdXQuXG4gICAgICAgKlxuICAgICAgICogU2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9jcGV0dGl0dC9kYWdyZS93aWtpI2NvbmZpZ3VyaW5nLXRoZS1sYXlvdXRcbiAgICAgICAqL1xuICAgICAgbm9kZVNlcDogNSxcbiAgICAgIC8qKlxuICAgICAgICogRGFncmUncyByYW5rc2VwIHBhcmFtIC0gbnVtYmVyIG9mIHBpeGVsc1xuICAgICAgICogYmV0d2VlbiBlYWNoIHJhbmsgaW4gdGhlIGxheW91dC5cbiAgICAgICAqXG4gICAgICAgKiBTZWUgaHR0cHM6Ly9naXRodWIuY29tL2NwZXR0aXR0L2RhZ3JlL3dpa2kjY29uZmlndXJpbmctdGhlLWxheW91dFxuICAgICAgICovXG4gICAgICByYW5rU2VwOiAyNSxcbiAgICAgIC8qKlxuICAgICAgICogRGFncmUncyBlZGdlc2VwIHBhcmFtIC0gbnVtYmVyIG9mIHBpeGVscyB0aGF0IHNlcGFyYXRlXG4gICAgICAgKiBlZGdlcyBob3Jpem9udGFsbHkgaW4gdGhlIGxheW91dC5cbiAgICAgICAqL1xuICAgICAgZWRnZVNlcDogNSxcbiAgICB9LFxuICAgIC8qKiBHcmFwaCBwYXJhbWV0ZXIgZm9yIG1ldGFub2RlLiAqL1xuICAgIHNlcmllczoge1xuICAgICAgLyoqXG4gICAgICAgKiBEYWdyZSdzIG5vZGVzZXAgcGFyYW0gLSBudW1iZXIgb2YgcGl4ZWxzIHRoYXRcbiAgICAgICAqIHNlcGFyYXRlIG5vZGVzIGhvcml6b250YWxseSBpbiB0aGUgbGF5b3V0LlxuICAgICAgICpcbiAgICAgICAqIFNlZSBodHRwczovL2dpdGh1Yi5jb20vY3BldHRpdHQvZGFncmUvd2lraSNjb25maWd1cmluZy10aGUtbGF5b3V0XG4gICAgICAgKi9cbiAgICAgIG5vZGVTZXA6IDUsXG4gICAgICAvKipcbiAgICAgICAqIERhZ3JlJ3MgcmFua3NlcCBwYXJhbSAtIG51bWJlciBvZiBwaXhlbHNcbiAgICAgICAqIGJldHdlZW4gZWFjaCByYW5rIGluIHRoZSBsYXlvdXQuXG4gICAgICAgKlxuICAgICAgICogU2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9jcGV0dGl0dC9kYWdyZS93aWtpI2NvbmZpZ3VyaW5nLXRoZS1sYXlvdXRcbiAgICAgICAqL1xuICAgICAgcmFua1NlcDogMjUsXG4gICAgICAvKipcbiAgICAgICAqIERhZ3JlJ3MgZWRnZXNlcCBwYXJhbSAtIG51bWJlciBvZiBwaXhlbHMgdGhhdCBzZXBhcmF0ZVxuICAgICAgICogZWRnZXMgaG9yaXpvbnRhbGx5IGluIHRoZSBsYXlvdXQuXG4gICAgICAgKi9cbiAgICAgIGVkZ2VTZXA6IDVcbiAgICB9LFxuICAgIC8qKlxuICAgICAqIFBhZGRpbmcgaXMgdXNlZCB0byBjb3JyZWN0bHkgcG9zaXRpb24gdGhlIGdyYXBoIFNWRyBpbnNpZGUgb2YgaXRzIHBhcmVudFxuICAgICAqIGVsZW1lbnQuIFRoZSBwYWRkaW5nIGFtb3VudHMgYXJlIGFwcGxpZWQgdXNpbmcgYW4gU1ZHIHRyYW5zZm9ybSBvZiBYIGFuZFxuICAgICAqIFkgY29vcmRpbmF0ZXMuXG4gICAgICovXG4gICAgcGFkZGluZzoge3BhZGRpbmdUb3A6IDQwLCBwYWRkaW5nTGVmdDogMjB9XG4gIH0sXG4gIHN1YnNjZW5lOiB7XG4gICAgbWV0YToge1xuICAgICAgcGFkZGluZ1RvcDogMTAsXG4gICAgICBwYWRkaW5nQm90dG9tOiAxMCxcbiAgICAgIHBhZGRpbmdMZWZ0OiAxMCxcbiAgICAgIHBhZGRpbmdSaWdodDogMTAsXG4gICAgICAvKipcbiAgICAgICAqIFVzZWQgdG8gbGVhdmUgcm9vbSBmb3IgdGhlIGxhYmVsIG9uIHRvcCBvZiB0aGUgaGlnaGVzdCBub2RlIGluXG4gICAgICAgKiB0aGUgY29yZSBncmFwaC5cbiAgICAgICAqL1xuICAgICAgbGFiZWxIZWlnaHQ6IDIwLFxuICAgICAgLyoqIFgtc3BhY2UgYmV0d2VlbiBlYWNoIGV4dHJhY3RlZCBub2RlIGFuZCB0aGUgY29yZSBncmFwaC4gKi9cbiAgICAgIGV4dHJhY3RYT2Zmc2V0OiAxNSxcbiAgICAgIC8qKiBZLXNwYWNlIGJldHdlZW4gZWFjaCBleHRyYWN0ZWQgbm9kZS4gKi9cbiAgICAgIGV4dHJhY3RZT2Zmc2V0OiAyMCxcbiAgICB9LFxuICAgIHNlcmllczoge1xuICAgICAgcGFkZGluZ1RvcDogMTAsXG4gICAgICBwYWRkaW5nQm90dG9tOiAxMCxcbiAgICAgIHBhZGRpbmdMZWZ0OiAxMCxcbiAgICAgIHBhZGRpbmdSaWdodDogMTAsXG4gICAgICBsYWJlbEhlaWdodDogMTBcbiAgICB9XG4gIH0sXG4gIG5vZGVTaXplOiB7XG4gICAgLyoqIFNpemUgb2YgbWV0YSBub2Rlcy4gKi9cbiAgICBtZXRhOiB7XG4gICAgICByYWRpdXM6IDUsXG4gICAgICB3aWR0aDogNjAsXG4gICAgICBtYXhMYWJlbFdpZHRoOiA1MixcbiAgICAgIC8qKiBBIHNjYWxlIGZvciB0aGUgbm9kZSdzIGhlaWdodCBiYXNlZCBvbiBudW1iZXIgb2Ygbm9kZXMgaW5zaWRlICovXG4gICAgICAvLyBIYWNrIC0gc2V0IHRoaXMgYXMgYW4gYW55IHR5cGUgdG8gYXZvaWQgaXNzdWVzIGluIGV4cG9ydGluZyBhIHR5cGVcbiAgICAgIC8vIGZyb20gYW4gZXh0ZXJuYWwgbW9kdWxlLlxuICAgICAgaGVpZ2h0OiAoZDMgYXMgYW55KS5zY2FsZUxpbmVhcigpLmRvbWFpbihbMSwgMjAwXSkucmFuZ2UoWzE1LCA2MF0pLmNsYW1wKHRydWUpLFxuICAgICAgLyoqIFRoZSByYWRpdXMgb2YgdGhlIGNpcmNsZSBkZW5vdGluZyB0aGUgZXhwYW5kIGJ1dHRvbi4gKi9cbiAgICAgIGV4cGFuZEJ1dHRvblJhZGl1czogM1xuICAgIH0sXG4gICAgLyoqIFNpemUgb2Ygb3Agbm9kZXMuICovXG4gICAgb3A6IHtcbiAgICAgIHdpZHRoOiAxNSxcbiAgICAgIGhlaWdodDogNixcbiAgICAgIHJhZGl1czogMywgIC8vIGZvciBtYWtpbmcgYW5ub3RhdGlvbiB0b3VjaGluZyBlbGxpcHNlXG4gICAgICBsYWJlbE9mZnNldDogLTgsXG4gICAgICBtYXhMYWJlbFdpZHRoOiAzMFxuICAgIH0sXG4gICAgLyoqIFNpemUgb2Ygc2VyaWVzIG5vZGVzLiAqL1xuICAgIHNlcmllczoge1xuICAgICAgZXhwYW5kZWQ6IHtcbiAgICAgICAgLy8gRm9yIGV4cGFuZGVkIHNlcmllcyBub2Rlcywgd2lkdGggYW5kIGhlaWdodCB3aWxsIGJlXG4gICAgICAgIC8vIGNvbXB1dGVkIHRvIGFjY291bnQgZm9yIHRoZSBzdWJzY2VuZS5cbiAgICAgICAgcmFkaXVzOiAxMCxcbiAgICAgICAgbGFiZWxPZmZzZXQ6IDAsXG4gICAgICB9LFxuICAgICAgdmVydGljYWw6IHtcbiAgICAgICAgLy8gV2hlbiB1bmV4cGFuZGVkLCBzZXJpZXMgd2hvc2UgdW5kZXJseWluZyBtZXRhZ3JhcGhzIGNvbnRhaW5cbiAgICAgICAgLy8gb25lIG9yIG1vcmUgbm9uLWNvbnRyb2wgZWRnZXMgd2lsbCBzaG93IGFzIGEgdmVydGljYWwgc3RhY2tcbiAgICAgICAgLy8gb2YgZWxsaXBzZXMuXG4gICAgICAgIHdpZHRoOiAxNixcbiAgICAgICAgaGVpZ2h0OiAxMyxcbiAgICAgICAgbGFiZWxPZmZzZXQ6IC0xMyxcbiAgICAgIH0sXG4gICAgICBob3Jpem9udGFsOiB7XG4gICAgICAgIC8vIFdoZW4gdW5leHBhbmRlZCwgc2VyaWVzIHdob3NlIHVuZGVybHlpbmcgbWV0YWdyYXBocyBjb250YWluXG4gICAgICAgIC8vIG5vIG5vbi1jb250cm9sIGVkZ2VzIHdpbGwgc2hvdyBhcyBhIGhvcml6b250YWwgc3RhY2sgb2ZcbiAgICAgICAgLy8gZWxsaXBzZXMuXG4gICAgICAgIHdpZHRoOiAyNCxcbiAgICAgICAgaGVpZ2h0OiA4LFxuICAgICAgICByYWRpdXM6IDEwLCAgLy8gRm9yY2VzIGFubm90YXRpb25zIHRvIGNlbnRlciBsaW5lLlxuICAgICAgICBsYWJlbE9mZnNldDogLTEwLFxuICAgICAgfSxcbiAgICB9LFxuICAgIC8qKiBTaXplIG9mIGJyaWRnZSBub2Rlcy4gKi9cbiAgICBicmlkZ2U6IHtcbiAgICAgIC8vIE5PVEU6IGJyaWRnZSBub2RlcyB3aWxsIG5vcm1hbGx5IGJlIGludmlzaWJsZSwgYnV0IHRoZXkgbXVzdFxuICAgICAgLy8gdGFrZSB1cCBzb21lIHNwYWNlIHNvIHRoYXQgdGhlIGxheW91dCBzdGVwIGxlYXZlcyByb29tIGZvclxuICAgICAgLy8gdGhlaXIgZWRnZXMuXG4gICAgICB3aWR0aDogMjAsXG4gICAgICBoZWlnaHQ6IDIwLFxuICAgICAgcmFkaXVzOiAyLFxuICAgICAgbGFiZWxPZmZzZXQ6IDBcbiAgICB9XG4gIH0sXG4gIHNob3J0Y3V0U2l6ZToge1xuICAgIC8qKiBTaXplIG9mIHNob3J0Y3V0cyBmb3Igb3Agbm9kZXMgKi9cbiAgICBvcDoge3dpZHRoOiAxMCwgaGVpZ2h0OiA0fSxcbiAgICAvKiogU2l6ZSBvZiBzaG9ydGN1dHMgZm9yIG1ldGEgbm9kZXMgKi9cbiAgICBtZXRhOiB7d2lkdGg6IDEyLCBoZWlnaHQ6IDQsIHJhZGl1czogMX0sXG4gICAgLyoqIFNpemUgb2Ygc2hvcnRjdXRzIGZvciBzZXJpZXMgbm9kZXMgKi9cbiAgICBzZXJpZXM6IHtcbiAgICAgIHdpZHRoOiAxNCxcbiAgICAgIGhlaWdodDogNCxcbiAgICB9XG4gIH0sXG4gIGFubm90YXRpb25zOiB7XG4gICAgLyoqIE1heGltdW0gcG9zc2libGUgd2lkdGggb2YgdGhlIGJvdW5kaW5nIGJveCBmb3IgaW4gYW5ub3RhdGlvbnMgKi9cbiAgICBpbmJveFdpZHRoOiA1MCxcbiAgICAvKiogTWF4aW11bSBwb3NzaWJsZSB3aWR0aCBvZiB0aGUgYm91bmRpbmcgYm94IGZvciBvdXQgYW5ub3RhdGlvbnMgKi9cbiAgICBvdXRib3hXaWR0aDogNTAsXG4gICAgLyoqIFgtc3BhY2UgYmV0d2VlbiB0aGUgc2hhcGUgYW5kIGVhY2ggYW5ub3RhdGlvbi1ub2RlLiAqL1xuICAgIHhPZmZzZXQ6IDEwLFxuICAgIC8qKiBZLXNwYWNlIGJldHdlZW4gZWFjaCBhbm5vdGF0aW9uLW5vZGUuICovXG4gICAgeU9mZnNldDogMyxcbiAgICAvKiogWC1zcGFjZSBiZXR3ZWVuIGVhY2ggYW5ub3RhdGlvbi1ub2RlIGFuZCBpdHMgbGFiZWwuICovXG4gICAgbGFiZWxPZmZzZXQ6IDIsXG4gICAgLyoqIERlZmluZXMgdGhlIG1heCB3aWR0aCBmb3IgYW5ub3RhdGlvbiBsYWJlbCAqL1xuICAgIG1heExhYmVsV2lkdGg6IDEyMFxuICB9LFxuICBjb25zdGFudDoge3NpemU6IHt3aWR0aDogNCwgaGVpZ2h0OiA0fX0sXG4gIHNlcmllczoge1xuICAgIC8qKiBNYXhpbXVtIG51bWJlciBvZiByZXBlYXRlZCBpdGVtIGZvciB1bmV4cGFuZGVkIHNlcmllcyBub2RlLiAqL1xuICAgIG1heFN0YWNrQ291bnQ6IDMsXG4gICAgLyoqXG4gICAgICogUG9zaXRpb25pbmcgb2Zmc2V0IHJhdGlvIGZvciBjb2xsYXBzZWQgc3RhY2tcbiAgICAgKiBvZiBwYXJhbGxlbCBzZXJpZXMgKHNlcmllcyB3aXRob3V0IGVkZ2VzIGJldHdlZW4gaXRzIG1lbWJlcnMpLlxuICAgICAqL1xuICAgIHBhcmFsbGVsU3RhY2tPZmZzZXRSYXRpbzogMC4yLFxuICAgIC8qKlxuICAgICAqIFBvc2l0aW9uaW5nIG9mZnNldCByYXRpbyBmb3IgY29sbGFwc2VkIHN0YWNrXG4gICAgICogb2YgdG93ZXIgc2VyaWVzIChzZXJpZXMgd2l0aCBlZGdlcyBiZXR3ZWVuIGl0cyBtZW1iZXJzKS5cbiAgICAgKi9cbiAgICB0b3dlclN0YWNrT2Zmc2V0UmF0aW86IDAuNVxuICB9LFxuICBtaW5pbWFwOiB7XG4gICAgLyoqIFRoZSBtYXhpbXVtIHdpZHRoL2hlaWdodCB0aGUgbWluaW1hcCBjYW4gaGF2ZS4gKi9cbiAgICBzaXplOiAxNTBcbiAgfVxufTtcblxuLyoqXG4gKiBUaGUgbWluaW11bSB3aWR0aCB3ZSBjb25mZXIgdXBvbiB0aGUgYXV4aWxpYXJ5IG5vZGVzIHNlY3Rpb24gaWYgZnVuY3Rpb25zXG4gKiBhbHNvIGFwcGVhci4gV2l0aG91dCBlbmZvcmNpbmcgdGhpcyBtaW5pbXVtLCBtZXRhbm9kZXMgaW4gdGhlIGZ1bmN0aW9uXG4gKiBsaWJyYXJ5IHNlY3Rpb24gY291bGQganV0IGludG8gdGhlIGF1eGlsaWFyeSBub2RlcyBzZWN0aW9uIGJlY2F1c2UgdGhlXG4gKiB0aXRsZSBcIkF1eGlsaWFyeSBOb2Rlc1wiIGlzIGxvbmdlciB0aGFuIHRoZSB3aWR0aCBvZiB0aGUgYXV4aWxpYXJ5IG5vZGVzXG4gKiBzZWN0aW9uIGl0c2VsZi5cbiAqL1xuZXhwb3J0IGNvbnN0IE1JTl9BVVhfV0lEVEggPSAxNDA7XG5cbi8qKiBDYWxjdWxhdGUgbGF5b3V0IGZvciBhIHNjZW5lIG9mIGEgZ3JvdXAgbm9kZS4gKi9cbmV4cG9ydCBmdW5jdGlvbiBsYXlvdXRTY2VuZShyZW5kZXJOb2RlSW5mbzogcmVuZGVyLlJlbmRlckdyb3VwTm9kZUluZm8pOiB2b2lkIHtcbiAgLy8gVXBkYXRlIGxheW91dCwgc2l6ZSwgYW5kIGFubm90YXRpb25zIG9mIGl0cyBjaGlsZHJlbiBub2RlcyBhbmQgZWRnZXMuXG4gIGlmIChyZW5kZXJOb2RlSW5mby5ub2RlLmlzR3JvdXBOb2RlKSB7XG4gICAgbGF5b3V0Q2hpbGRyZW4ocmVuZGVyTm9kZUluZm8pO1xuICB9XG5cbiAgLy8gVXBkYXRlIHBvc2l0aW9uIG9mIGl0cyBjaGlsZHJlbiBub2RlcyBhbmQgZWRnZXNcbiAgaWYgKHJlbmRlck5vZGVJbmZvLm5vZGUudHlwZSA9PT0gTm9kZVR5cGUuTUVUQSkge1xuICAgIGxheW91dE1ldGFub2RlKHJlbmRlck5vZGVJbmZvKTtcbiAgfSBlbHNlIGlmIChyZW5kZXJOb2RlSW5mby5ub2RlLnR5cGUgPT09IE5vZGVUeXBlLlNFUklFUykge1xuICAgIGxheW91dFNlcmllc05vZGUocmVuZGVyTm9kZUluZm8pO1xuICB9XG59O1xuXG4vKipcbiAqIFVwZGF0ZXMgdGhlIHRvdGFsIHdpZHRoIG9mIGFuIHVuZXhwYW5kZWQgbm9kZSB3aGljaCBpbmNsdWRlcyB0aGUgc2l6ZSBvZiBpdHNcbiAqIGluIGFuZCBvdXQgYW5ub3RhdGlvbnMuXG4gKi9cbmZ1bmN0aW9uIHVwZGF0ZVRvdGFsV2lkdGhPZk5vZGUocmVuZGVySW5mbzogcmVuZGVyLlJlbmRlck5vZGVJbmZvKTogdm9pZCB7XG4gIHJlbmRlckluZm8uaW5ib3hXaWR0aCA9IHJlbmRlckluZm8uaW5Bbm5vdGF0aW9ucy5saXN0Lmxlbmd0aCA+IDAgP1xuICAgICAgUEFSQU1TLmFubm90YXRpb25zLmluYm94V2lkdGggOiAwO1xuICByZW5kZXJJbmZvLm91dGJveFdpZHRoID0gcmVuZGVySW5mby5vdXRBbm5vdGF0aW9ucy5saXN0Lmxlbmd0aCA+IDAgP1xuICAgICAgUEFSQU1TLmFubm90YXRpb25zLm91dGJveFdpZHRoIDogMDtcbiAgLy8gQXNzaWduIHRoZSB3aWR0aCBvZiB0aGUgY29yZSBib3ggKHRoZSBtYWluIHNoYXBlIG9mIHRoZSBub2RlKS5cbiAgcmVuZGVySW5mby5jb3JlQm94LndpZHRoID0gcmVuZGVySW5mby53aWR0aDtcbiAgcmVuZGVySW5mby5jb3JlQm94LmhlaWdodCA9IHJlbmRlckluZm8uaGVpZ2h0O1xuICAvLyBUT0RPOiBBY2NvdW50IGZvciBmb250IHdpZHRoIHJhdGhlciB0aGFuIHVzaW5nIGEgbWFnaWMgbnVtYmVyLlxuICBsZXQgbGFiZWxMZW5ndGggPSByZW5kZXJJbmZvLmRpc3BsYXlOYW1lLmxlbmd0aDtcbiAgbGV0IGNoYXJXaWR0aCA9IDM7IC8vIDMgcGl4ZWxzIHBlciBjaGFyYWN0ZXIuXG4gIC8vIENvbXB1dGUgdGhlIHRvdGFsIHdpZHRoIG9mIHRoZSBub2RlLlxuICByZW5kZXJJbmZvLndpZHRoID0gTWF0aC5tYXgocmVuZGVySW5mby5jb3JlQm94LndpZHRoICtcbiAgICAgIHJlbmRlckluZm8uaW5ib3hXaWR0aCArIHJlbmRlckluZm8ub3V0Ym94V2lkdGgsXG4gICAgICBsYWJlbExlbmd0aCAqIGNoYXJXaWR0aCk7XG5cbn1cblxuLyoqXG4gKiBVcGRhdGUgbGF5b3V0LCBzaXplLCBhbmQgYW5ub3RhdGlvbnMgb2YgaXRzIGNoaWxkcmVuIG5vZGVzIGFuZCBlZGdlcy5cbiAqL1xuZnVuY3Rpb24gbGF5b3V0Q2hpbGRyZW4ocmVuZGVyTm9kZUluZm86IHJlbmRlci5SZW5kZXJHcm91cE5vZGVJbmZvKTogdm9pZCB7XG4gIGxldCBjaGlsZHJlbiA9IHJlbmRlck5vZGVJbmZvLmNvcmVHcmFwaC5ub2RlcygpLm1hcChuID0+IHtcbiAgICByZXR1cm4gcmVuZGVyTm9kZUluZm8uY29yZUdyYXBoLm5vZGUobik7XG4gIH0pLmNvbmNhdChyZW5kZXJOb2RlSW5mby5pc29sYXRlZEluRXh0cmFjdCxcbiAgICAgICAgICAgIHJlbmRlck5vZGVJbmZvLmlzb2xhdGVkT3V0RXh0cmFjdCxcbiAgICAgICAgICAgIHJlbmRlck5vZGVJbmZvLmxpYnJhcnlGdW5jdGlvbnNFeHRyYWN0KTtcblxuICBfLmVhY2goY2hpbGRyZW4sIGNoaWxkTm9kZUluZm8gPT4ge1xuICAgIC8vIFNldCBzaXplIG9mIGVhY2ggY2hpbGRcbiAgICBzd2l0Y2ggKGNoaWxkTm9kZUluZm8ubm9kZS50eXBlKSB7XG4gICAgICBjYXNlIE5vZGVUeXBlLk9QOlxuICAgICAgICBfLmV4dGVuZChjaGlsZE5vZGVJbmZvLCBQQVJBTVMubm9kZVNpemUub3ApO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgTm9kZVR5cGUuQlJJREdFOlxuICAgICAgICBfLmV4dGVuZChjaGlsZE5vZGVJbmZvLCBQQVJBTVMubm9kZVNpemUuYnJpZGdlKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlIE5vZGVUeXBlLk1FVEE6XG4gICAgICAgIGlmICghY2hpbGROb2RlSW5mby5leHBhbmRlZCkge1xuICAgICAgICAgIC8vIFNldCBmaXhlZCB3aWR0aCBhbmQgc2NhbGFibGUgaGVpZ2h0IGJhc2VkIG9uIGNhcmRpbmFsaXR5XG4gICAgICAgICAgXy5leHRlbmQoY2hpbGROb2RlSW5mbywgUEFSQU1TLm5vZGVTaXplLm1ldGEpO1xuICAgICAgICAgIGNoaWxkTm9kZUluZm8uaGVpZ2h0ID1cbiAgICAgICAgICAgICAgUEFSQU1TLm5vZGVTaXplLm1ldGEuaGVpZ2h0KGNoaWxkTm9kZUluZm8ubm9kZS5jYXJkaW5hbGl0eSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgbGV0IGNoaWxkR3JvdXBOb2RlSW5mbyA9XG4gICAgICAgICAgICA8cmVuZGVyLlJlbmRlckdyb3VwTm9kZUluZm8+Y2hpbGROb2RlSW5mbztcbiAgICAgICAgICBsYXlvdXRTY2VuZShjaGlsZEdyb3VwTm9kZUluZm8pOyAvLyBSZWN1cnNpdmVseSBsYXlvdXQgaXRzIHN1YnNjZW5lLlxuICAgICAgICB9XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSBOb2RlVHlwZS5TRVJJRVM6XG4gICAgICAgIGlmIChjaGlsZE5vZGVJbmZvLmV4cGFuZGVkKSB7XG4gICAgICAgICAgXy5leHRlbmQoY2hpbGROb2RlSW5mbywgUEFSQU1TLm5vZGVTaXplLnNlcmllcy5leHBhbmRlZCk7XG4gICAgICAgICAgbGV0IGNoaWxkR3JvdXBOb2RlSW5mbyA9XG4gICAgICAgICAgICA8cmVuZGVyLlJlbmRlckdyb3VwTm9kZUluZm8+Y2hpbGROb2RlSW5mbztcbiAgICAgICAgICBsYXlvdXRTY2VuZShjaGlsZEdyb3VwTm9kZUluZm8pOyAvLyBSZWN1cnNpdmVseSBsYXlvdXQgaXRzIHN1YnNjZW5lLlxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGxldCBjaGlsZEdyb3VwTm9kZUluZm8gPVxuICAgICAgICAgICAgPHJlbmRlci5SZW5kZXJHcm91cE5vZGVJbmZvPmNoaWxkTm9kZUluZm87XG4gICAgICAgICAgbGV0IHNlcmllc1BhcmFtcyA9XG4gICAgICAgICAgICBjaGlsZEdyb3VwTm9kZUluZm8ubm9kZS5oYXNOb25Db250cm9sRWRnZXMgP1xuICAgICAgICAgICAgICBQQVJBTVMubm9kZVNpemUuc2VyaWVzLnZlcnRpY2FsIDpcbiAgICAgICAgICAgICAgUEFSQU1TLm5vZGVTaXplLnNlcmllcy5ob3Jpem9udGFsO1xuICAgICAgICAgIF8uZXh0ZW5kKGNoaWxkTm9kZUluZm8sIHNlcmllc1BhcmFtcyk7XG4gICAgICAgIH1cbiAgICAgICAgYnJlYWs7XG4gICAgICBkZWZhdWx0OlxuICAgICAgICB0aHJvdyBFcnJvcignVW5yZWNvZ25pemVkIG5vZGUgdHlwZTogJyArIGNoaWxkTm9kZUluZm8ubm9kZS50eXBlKTtcbiAgICB9XG4gICAgLy8gQ29tcHV0ZSB0b3RhbCB3aWR0aCBvZiB1bi1leHBhbmRlZCBub2Rlcy4gV2lkdGggb2YgZXhwYW5kZWQgbm9kZXNcbiAgICAvLyBoYXMgYWxyZWFkeSBiZWVuIGNvbXB1dGVkLlxuICAgIGlmICghY2hpbGROb2RlSW5mby5leHBhbmRlZCkge1xuICAgICAgdXBkYXRlVG90YWxXaWR0aE9mTm9kZShjaGlsZE5vZGVJbmZvKTtcbiAgICB9XG4gICAgLy8gTGF5b3V0IGVhY2ggY2hpbGQncyBhbm5vdGF0aW9uc1xuICAgIGxheW91dEFubm90YXRpb24oY2hpbGROb2RlSW5mbyk7XG4gIH0pO1xufVxuXG4vKipcbiAqIENhbGN1bGF0ZSBsYXlvdXQgZm9yIGEgZ3JhcGggdXNpbmcgZGFncmVcbiAqIEBwYXJhbSBncmFwaCB0aGUgZ3JhcGggdG8gYmUgbGFpZCBvdXRcbiAqIEBwYXJhbSBwYXJhbXMgbGF5b3V0IHBhcmFtZXRlcnNcbiAqIEByZXR1cm4gd2lkdGggYW5kIGhlaWdodCBvZiB0aGUgY29yZSBncmFwaFxuICovXG5mdW5jdGlvbiBkYWdyZUxheW91dChcbiAgICBncmFwaDogZ3JhcGhsaWIuR3JhcGg8cmVuZGVyLlJlbmRlck5vZGVJbmZvLCByZW5kZXIuUmVuZGVyTWV0YWVkZ2VJbmZvPixcbiAgICBwYXJhbXMpOiB7aGVpZ2h0OiBudW1iZXIsIHdpZHRoOiBudW1iZXJ9IHtcbiAgXy5leHRlbmQoZ3JhcGguZ3JhcGgoKSwge1xuICAgIG5vZGVzZXA6IHBhcmFtcy5ub2RlU2VwLFxuICAgIHJhbmtzZXA6IHBhcmFtcy5yYW5rU2VwLFxuICAgIGVkZ2VzZXA6IHBhcmFtcy5lZGdlU2VwXG4gIH0pO1xuICBsZXQgYnJpZGdlTm9kZU5hbWVzID0gW107XG4gIGxldCBub25CcmlkZ2VOb2RlTmFtZXMgPSBbXTtcblxuICAvLyBTcGxpdCBvdXQgbm9kZXMgaW50byBicmlkZ2UgYW5kIG5vbi1icmlkZ2Ugbm9kZXMsIGFuZCBjYWxjdWxhdGUgdGhlIHRvdGFsXG4gIC8vIHdpZHRoIHdlIHNob3VsZCB1c2UgZm9yIGJyaWRnZSBub2Rlcy5cbiAgXy5lYWNoKGdyYXBoLm5vZGVzKCksIG5vZGVOYW1lID0+IHtcbiAgICBsZXQgbm9kZUluZm8gPSBncmFwaC5ub2RlKG5vZGVOYW1lKTtcbiAgICBpZiAobm9kZUluZm8ubm9kZS50eXBlID09PSBOb2RlVHlwZS5CUklER0UpIHtcbiAgICAgIGJyaWRnZU5vZGVOYW1lcy5wdXNoKG5vZGVOYW1lKTtcbiAgICB9IGVsc2Uge1xuICAgICAgbm9uQnJpZGdlTm9kZU5hbWVzLnB1c2gobm9kZU5hbWUpO1xuICAgIH1cbiAgfSk7XG5cbiAgLy8gSWYgdGhlcmUgYXJlIG5vIG5vbi1icmlkZ2Ugbm9kZXMsIHRoZW4gdGhlIGdyYXBoIGhhcyB6ZXJvIHNpemUuXG4gIGlmICghbm9uQnJpZGdlTm9kZU5hbWVzLmxlbmd0aCkge1xuICAgIHJldHVybiB7XG4gICAgICB3aWR0aDogMCxcbiAgICAgIGhlaWdodDogMCxcbiAgICB9O1xuICB9XG4gIGRhZ3JlLmxheW91dChncmFwaCk7XG5cbiAgLy8gQ2FsY3VsYXRlIHRoZSB0cnVlIGJvdW5kaW5nIGJveCBvZiB0aGUgZ3JhcGggYnkgaXRlcmF0aW5nIG92ZXIgbm9kZXMgYW5kXG4gIC8vIGVkZ2VzIHJhdGhlciB0aGFuIGFjY2VwdGluZyBkYWdyZSdzIHdvcmQgZm9yIGl0LiBJbiBwYXJ0aWN1bGFyLCB3ZSBzaG91bGRcbiAgLy8gaWdub3JlIHRoZSBleHRyYS13aWRlIGJyaWRnZSBub2RlcyBhbmQgYnJpZGdlIGVkZ2VzLCBhbmQgYWxsb3cgZm9yXG4gIC8vIGFubm90YXRpb24gYm94ZXMgYW5kIGxhYmVscy5cbiAgbGV0IG1pblggPSBJbmZpbml0eTtcbiAgbGV0IG1pblkgPSBJbmZpbml0eTtcbiAgbGV0IG1heFggPSAtSW5maW5pdHk7XG4gIGxldCBtYXhZID0gLUluZmluaXR5O1xuICBfLmVhY2gobm9uQnJpZGdlTm9kZU5hbWVzLCBub2RlTmFtZSA9PiB7XG4gICAgbGV0IG5vZGVJbmZvID0gZ3JhcGgubm9kZShub2RlTmFtZSk7XG4gICAgbGV0IHcgPSAwLjUgKiBub2RlSW5mby53aWR0aDtcbiAgICBsZXQgeDEgPSBub2RlSW5mby54IC0gdztcbiAgICBsZXQgeDIgPSBub2RlSW5mby54ICsgdztcbiAgICBtaW5YID0geDEgPCBtaW5YID8geDEgOiBtaW5YO1xuICAgIG1heFggPSB4MiA+IG1heFggPyB4MiA6IG1heFg7XG4gICAgLy8gVE9ETzogQWNjb3VudCBmb3IgdGhlIGhlaWdodCBvZiBsYWJlbHMgYWJvdmUgb3Agbm9kZXMgaGVyZS5cbiAgICBsZXQgaCA9IDAuNSAqIG5vZGVJbmZvLmhlaWdodDtcbiAgICBsZXQgeTEgPSBub2RlSW5mby55IC0gaDtcbiAgICBsZXQgeTIgPSBub2RlSW5mby55ICsgaDtcbiAgICBtaW5ZID0geTEgPCBtaW5ZID8geTEgOiBtaW5ZO1xuICAgIG1heFkgPSB5MiA+IG1heFkgPyB5MiA6IG1heFk7XG4gIH0pO1xuICBfLmVhY2goZ3JhcGguZWRnZXMoKSwgZWRnZU9iaiA9PiB7XG4gICAgbGV0IGVkZ2VJbmZvID0gZ3JhcGguZWRnZShlZGdlT2JqKTtcbiAgICBpZiAoZWRnZUluZm8uc3RydWN0dXJhbCkge1xuICAgICAgcmV0dXJuOyAvLyBTa2lwIHN0cnVjdHVyYWwgZWRnZXMgZnJvbSBtaW4vbWF4IGNhbGN1bGF0aW9ucy5cbiAgICB9XG5cbiAgICAvLyBTaW5jZSB0aGUgbm9kZSBzaXplIHBhc3NlZCB0byBkYWdyZSBpbmNsdWRlcyB0aGUgaW4gYW5kIG91dFxuICAgIC8vIGFubm90YXRpb25zLCB0aGUgZW5kcG9pbnRzIG9mIHRoZSBlZGdlIHByb2R1Y2VkIGJ5IGRhZ3JlIG1heSBub3RcbiAgICAvLyBwb2ludCB0byB0aGUgYWN0dWFsIG5vZGUgc2hhcGUgKHJlY3RhbmdsZSwgZWxsaXBzZSkuIFdlIGNvcnJlY3QgdGhlXG4gICAgLy8gZW5kLXBvaW50cyBieSBmaW5kaW5nIHRoZSBpbnRlcnNlY3Rpb24gb2YgYSBsaW5lIGJldHdlZW4gdGhlXG4gICAgLy8gbmV4dC10by1sYXN0IChuZXh0LXRvLWZpcnN0KSBwb2ludCBhbmQgdGhlIGRlc3RpbmF0aW9uIChzb3VyY2UpXG4gICAgLy8gcmVjdGFuZ2xlLlxuICAgIGxldCBzb3VyY2VOb2RlID0gZ3JhcGgubm9kZShlZGdlSW5mby5tZXRhZWRnZS52KTtcbiAgICBsZXQgZGVzdE5vZGUgPSBncmFwaC5ub2RlKGVkZ2VJbmZvLm1ldGFlZGdlLncpO1xuXG4gICAgLy8gU3RyYWlnaHQgMy1wb2ludHMgZWRnZXMgYXJlIHNwZWNpYWwgY2FzZSwgc2luY2UgdGhleSBhcmUgY3VydmVkIGFmdGVyXG4gICAgLy8gb3VyIGRlZmF1bHQgY29ycmVjdGlvbi4gVG8ga2VlcCB0aGVtIHN0cmFpZ2h0LCB3ZSByZW1vdmUgdGhlIG1pZCBwb2ludFxuICAgIC8vIGFuZCBjb3JyZWN0IHRoZSBmaXJzdCBhbmQgdGhlIGxhc3QgcG9pbnQgdG8gYmUgdGhlIGNlbnRlciBvZiB0aGVcbiAgICAvLyBzb3VyY2UgYW5kIGRlc3RpbmF0aW9uIG5vZGUgcmVzcGVjdGl2ZWx5LlxuICAgIGlmIChlZGdlSW5mby5wb2ludHMubGVuZ3RoID09PSAzICYmIGlzU3RyYWlnaHRMaW5lKGVkZ2VJbmZvLnBvaW50cykpIHtcbiAgICAgIGlmIChzb3VyY2VOb2RlICE9IG51bGwpIHtcbiAgICAgICAgbGV0IGN4U291cmNlID0gc291cmNlTm9kZS5leHBhbmRlZCA/XG4gICAgICAgICAgICBzb3VyY2VOb2RlLnggOiBjb21wdXRlQ1hQb3NpdGlvbk9mTm9kZVNoYXBlKHNvdXJjZU5vZGUpO1xuICAgICAgICBlZGdlSW5mby5wb2ludHNbMF0ueCA9IGN4U291cmNlO1xuICAgICAgfVxuICAgICAgaWYgKGRlc3ROb2RlICE9IG51bGwpIHtcbiAgICAgICAgbGV0IGN4RGVzdCA9IGRlc3ROb2RlLmV4cGFuZGVkID9cbiAgICAgICAgICAgIGRlc3ROb2RlLnggOiBjb21wdXRlQ1hQb3NpdGlvbk9mTm9kZVNoYXBlKGRlc3ROb2RlKTtcbiAgICAgICAgZWRnZUluZm8ucG9pbnRzWzJdLnggPSBjeERlc3Q7XG4gICAgICB9XG4gICAgICAvLyBSZW1vdmUgdGhlIG1pZGRsZSBwb2ludCBzbyB0aGUgZWRnZSBkb2Vzbid0IGN1cnZlLlxuICAgICAgZWRnZUluZm8ucG9pbnRzID0gW2VkZ2VJbmZvLnBvaW50c1swXSwgZWRnZUluZm8ucG9pbnRzWzFdXTtcbiAgICB9XG4gICAgLy8gQ29ycmVjdCB0aGUgZGVzdGluYXRpb24gZW5kcG9pbnQgb2YgdGhlIGVkZ2UuXG4gICAgbGV0IG5leHRUb0xhc3RQb2ludCA9IGVkZ2VJbmZvLnBvaW50c1tlZGdlSW5mby5wb2ludHMubGVuZ3RoIC0gMl07XG4gICAgLy8gVGhlIGRlc3RpbmF0aW9uIG5vZGUgbWlnaHQgYmUgbnVsbCBpZiB0aGlzIGlzIGEgYnJpZGdlIGVkZ2UuXG4gICAgaWYgKGRlc3ROb2RlICE9IG51bGwpIHtcbiAgICAgIGVkZ2VJbmZvLnBvaW50c1tlZGdlSW5mby5wb2ludHMubGVuZ3RoIC0gMV0gPVxuICAgICAgICAgIGludGVyc2VjdFBvaW50QW5kTm9kZShuZXh0VG9MYXN0UG9pbnQsIGRlc3ROb2RlKTtcbiAgICB9XG4gICAgLy8gQ29ycmVjdCB0aGUgc291cmNlIGVuZHBvaW50IG9mIHRoZSBlZGdlLlxuICAgIGxldCBzZWNvbmRQb2ludCA9IGVkZ2VJbmZvLnBvaW50c1sxXTtcbiAgICAvLyBUaGUgc291cmNlIG1pZ2h0IGJlIG51bGwgaWYgdGhpcyBpcyBhIGJyaWRnZSBlZGdlLlxuICAgIGlmIChzb3VyY2VOb2RlICE9IG51bGwpIHtcbiAgICAgIGVkZ2VJbmZvLnBvaW50c1swXSA9IGludGVyc2VjdFBvaW50QW5kTm9kZShzZWNvbmRQb2ludCwgc291cmNlTm9kZSk7XG4gICAgfVxuXG4gICAgXy5lYWNoKGVkZ2VJbmZvLnBvaW50cywgKHBvaW50OiByZW5kZXIuUG9pbnQpID0+IHtcbiAgICAgICAgbWluWCA9IHBvaW50LnggPCBtaW5YID8gcG9pbnQueCA6IG1pblg7XG4gICAgICAgIG1heFggPSBwb2ludC54ID4gbWF4WCA/IHBvaW50LnggOiBtYXhYO1xuICAgICAgICBtaW5ZID0gcG9pbnQueSA8IG1pblkgPyBwb2ludC55IDogbWluWTtcbiAgICAgICAgbWF4WSA9IHBvaW50LnkgPiBtYXhZID8gcG9pbnQueSA6IG1heFk7XG4gICAgICB9KTtcbiAgfSk7XG5cbiAgLy8gU2hpZnQgYWxsIG5vZGVzIGFuZCBlZGdlIHBvaW50cyB0byBhY2NvdW50IGZvciB0aGUgbGVmdC1wYWRkaW5nIGFtb3VudCxcbiAgLy8gYW5kIHRoZSBpbnZpc2libGUgYnJpZGdlIG5vZGVzLlxuICBfLmVhY2goZ3JhcGgubm9kZXMoKSwgbm9kZU5hbWUgPT4ge1xuICAgIGxldCBub2RlSW5mbyA9IGdyYXBoLm5vZGUobm9kZU5hbWUpO1xuICAgIG5vZGVJbmZvLnggLT0gbWluWDtcbiAgICBub2RlSW5mby55IC09IG1pblk7XG4gIH0pO1xuICBfLmVhY2goZ3JhcGguZWRnZXMoKSwgZWRnZU9iaiA9PiB7XG4gICAgXy5lYWNoKGdyYXBoLmVkZ2UoZWRnZU9iaikucG9pbnRzLCAocG9pbnQ6IHJlbmRlci5Qb2ludCkgPT4ge1xuICAgICAgICBwb2ludC54IC09IG1pblg7XG4gICAgICAgIHBvaW50LnkgLT0gbWluWTtcbiAgICAgIH0pO1xuICB9KTtcblxuICByZXR1cm4ge1xuICAgIHdpZHRoOiBtYXhYIC0gbWluWCxcbiAgICBoZWlnaHQ6IG1heFkgLSBtaW5ZXG4gIH07XG59XG5cbi8qKiBMYXlvdXQgYSBtZXRhbm9kZS4gT25seSBjYWxsZWQgZm9yIGFuIGV4cGFuZGVkIG5vZGUuICovXG5mdW5jdGlvbiBsYXlvdXRNZXRhbm9kZShyZW5kZXJOb2RlSW5mbzogcmVuZGVyLlJlbmRlckdyb3VwTm9kZUluZm8pOiB2b2lkIHtcbiAgLy8gRmlyc3QsIGNvcHkgcGFyYW1zIHNwZWNpZmljIHRvIG1ldGEgbm9kZXMgb250byB0aGlzIHJlbmRlciBpbmZvIG9iamVjdC5cbiAgbGV0IHBhcmFtcyA9IFBBUkFNUy5zdWJzY2VuZS5tZXRhO1xuICBfLmV4dGVuZChyZW5kZXJOb2RlSW5mbywgcGFyYW1zKTtcbiAgLy8gSW52b2tlIGRhZ3JlLmxheW91dCgpIG9uIHRoZSBjb3JlIGdyYXBoIGFuZCByZWNvcmQgdGhlIGJvdW5kaW5nIGJveFxuICAvLyBkaW1lbnNpb25zLlxuICBfLmV4dGVuZChyZW5kZXJOb2RlSW5mby5jb3JlQm94LFxuICAgICAgZGFncmVMYXlvdXQocmVuZGVyTm9kZUluZm8uY29yZUdyYXBoLCBQQVJBTVMuZ3JhcGgubWV0YSkpO1xuXG4gIC8vIENhbGN1bGF0ZSB0aGUgcG9zaXRpb24gb2Ygbm9kZXMgaW4gaXNvbGF0ZWRJbkV4dHJhY3QgcmVsYXRpdmUgdG8gdGhlXG4gIC8vIHRvcC1sZWZ0IGNvcm5lciBvZiBpbkV4dHJhY3RCb3ggKHRoZSBib3VuZGluZyBib3ggZm9yIGFsbCBpbkV4dHJhY3Qgbm9kZXMpXG4gIC8vIGFuZCBjYWxjdWxhdGUgdGhlIHNpemUgb2YgdGhlIGluRXh0cmFjdEJveC5cbiAgbGV0IG1heEluRXh0cmFjdFdpZHRoID0gcmVuZGVyTm9kZUluZm8uaXNvbGF0ZWRJbkV4dHJhY3QubGVuZ3RoID9cbiAgICAgIF8ubWF4KFxuICAgICAgICAgIHJlbmRlck5vZGVJbmZvLmlzb2xhdGVkSW5FeHRyYWN0LFxuICAgICAgICAgIHJlbmRlck5vZGUgPT4gcmVuZGVyTm9kZS53aWR0aCxcbiAgICAgICkud2lkdGggOiBudWxsO1xuICByZW5kZXJOb2RlSW5mby5pbkV4dHJhY3RCb3gud2lkdGggPSBtYXhJbkV4dHJhY3RXaWR0aCAhPSBudWxsID9cbiAgICAgIG1heEluRXh0cmFjdFdpZHRoIDogMDtcblxuICByZW5kZXJOb2RlSW5mby5pbkV4dHJhY3RCb3guaGVpZ2h0ID1cbiAgICBfLnJlZHVjZShyZW5kZXJOb2RlSW5mby5pc29sYXRlZEluRXh0cmFjdCwgKGhlaWdodCwgY2hpbGQsIGkpID0+IHtcbiAgICAgIGxldCB5T2Zmc2V0ID0gaSA+IDAgPyBwYXJhbXMuZXh0cmFjdFlPZmZzZXQgOiAwO1xuICAgICAgLy8gdXNlIHdpZHRoL2hlaWdodCBoZXJlIHRvIGF2b2lkIG92ZXJsYXBzIGJldHdlZW4gZXh0cmFjdHNcbiAgICAgIGNoaWxkLnggPSAwO1xuICAgICAgY2hpbGQueSA9IGhlaWdodCArIHlPZmZzZXQgKyBjaGlsZC5oZWlnaHQgLyAyO1xuICAgICAgcmV0dXJuIGhlaWdodCArIHlPZmZzZXQgKyBjaGlsZC5oZWlnaHQ7XG4gICAgfSwgMCk7XG5cbiAgLy8gQ2FsY3VsYXRlIHRoZSBwb3NpdGlvbiBvZiBub2RlcyBpbiBpc29sYXRlZE91dEV4dHJhY3QgcmVsYXRpdmUgdG8gdGhlXG4gIC8vIHRvcC1sZWZ0IGNvcm5lciBvZiBvdXRFeHRyYWN0Qm94ICh0aGUgYm91bmRpbmcgYm94IGZvciBhbGwgb3V0RXh0cmFjdFxuICAvLyBub2RlcykgYW5kIGNhbGN1bGF0ZSB0aGUgc2l6ZSBvZiB0aGUgb3V0RXh0cmFjdEJveC5cbiAgbGV0IG1heE91dEV4dHJhY3RXaWR0aCA9IHJlbmRlck5vZGVJbmZvLmlzb2xhdGVkT3V0RXh0cmFjdC5sZW5ndGggP1xuICAgICAgXy5tYXgoXG4gICAgICAgICAgcmVuZGVyTm9kZUluZm8uaXNvbGF0ZWRPdXRFeHRyYWN0LFxuICAgICAgICAgIHJlbmRlck5vZGUgPT4gcmVuZGVyTm9kZS53aWR0aCxcbiAgICAgICkud2lkdGggOiBudWxsO1xuICByZW5kZXJOb2RlSW5mby5vdXRFeHRyYWN0Qm94LndpZHRoID0gbWF4T3V0RXh0cmFjdFdpZHRoICE9IG51bGwgP1xuICAgICAgbWF4T3V0RXh0cmFjdFdpZHRoIDogMDtcblxuICByZW5kZXJOb2RlSW5mby5vdXRFeHRyYWN0Qm94LmhlaWdodCA9XG4gICAgXy5yZWR1Y2UocmVuZGVyTm9kZUluZm8uaXNvbGF0ZWRPdXRFeHRyYWN0LCAoaGVpZ2h0LCBjaGlsZCwgaSkgPT4ge1xuICAgICAgbGV0IHlPZmZzZXQgPSBpID4gMCA/IHBhcmFtcy5leHRyYWN0WU9mZnNldCA6IDA7XG4gICAgICAvLyB1c2Ugd2lkdGgvaGVpZ2h0IGhlcmUgdG8gYXZvaWQgb3ZlcmxhcHMgYmV0d2VlbiBleHRyYWN0c1xuICAgICAgY2hpbGQueCA9IDA7XG4gICAgICBjaGlsZC55ID0gaGVpZ2h0ICsgeU9mZnNldCArIGNoaWxkLmhlaWdodCAvIDI7XG4gICAgICByZXR1cm4gaGVpZ2h0ICsgeU9mZnNldCArIGNoaWxkLmhlaWdodDtcbiAgICB9LCAwKTtcblxuICAvLyBDYWxjdWxhdGUgdGhlIHBvc2l0aW9uIG9mIG5vZGVzIGluIGxpYnJhcnlGdW5jdGlvbnNFeHRyYWN0IHJlbGF0aXZlIHRvIHRoZVxuICAvLyB0b3AtbGVmdCBjb3JuZXIgb2YgbGlicmFyeUZ1bmN0aW9uc0JveCAodGhlIGJvdW5kaW5nIGJveCBmb3IgYWxsIGxpYnJhcnlcbiAgLy8gZnVuY3Rpb24gbm9kZXMpIGFuZCBjYWxjdWxhdGUgdGhlIHNpemUgb2YgdGhlIGxpYnJhcnlGdW5jdGlvbnNCb3guXG4gIGxldCBtYXhMaWJyYXJ5RnVuY3Rpb25zV2lkdGggPSByZW5kZXJOb2RlSW5mby5saWJyYXJ5RnVuY3Rpb25zRXh0cmFjdC5sZW5ndGggP1xuICAgICAgXy5tYXgoXG4gICAgICAgICAgcmVuZGVyTm9kZUluZm8ubGlicmFyeUZ1bmN0aW9uc0V4dHJhY3QsXG4gICAgICAgICAgcmVuZGVyTm9kZSA9PiByZW5kZXJOb2RlLndpZHRoLFxuICAgICAgKS53aWR0aCA6IG51bGw7XG4gIHJlbmRlck5vZGVJbmZvLmxpYnJhcnlGdW5jdGlvbnNCb3gud2lkdGggPSBtYXhMaWJyYXJ5RnVuY3Rpb25zV2lkdGggIT0gbnVsbCA/XG4gICAgICBtYXhMaWJyYXJ5RnVuY3Rpb25zV2lkdGggOiAwO1xuXG4gIHJlbmRlck5vZGVJbmZvLmxpYnJhcnlGdW5jdGlvbnNCb3guaGVpZ2h0ID1cbiAgICBfLnJlZHVjZShyZW5kZXJOb2RlSW5mby5saWJyYXJ5RnVuY3Rpb25zRXh0cmFjdCwgKGhlaWdodCwgY2hpbGQsIGkpID0+IHtcbiAgICAgIGxldCB5T2Zmc2V0ID0gaSA+IDAgPyBwYXJhbXMuZXh0cmFjdFlPZmZzZXQgOiAwO1xuICAgICAgLy8gdXNlIHdpZHRoL2hlaWdodCBoZXJlIHRvIGF2b2lkIG92ZXJsYXBzIGJldHdlZW4gZXh0cmFjdHNcbiAgICAgIGNoaWxkLnggPSAwO1xuICAgICAgY2hpbGQueSA9IGhlaWdodCArIHlPZmZzZXQgKyBjaGlsZC5oZWlnaHQgLyAyO1xuICAgICAgcmV0dXJuIGhlaWdodCArIHlPZmZzZXQgKyBjaGlsZC5oZWlnaHQ7XG4gICAgfSwgMCk7XG5cbiAgLy8gQ29tcHV0ZSB0aGUgdG90YWwgcGFkZGluZyBiZXR3ZWVuIHRoZSBjb3JlIGdyYXBoLCBpbi1leHRyYWN0IGFuZFxuICAvLyBvdXQtZXh0cmFjdCBib3hlcy5cbiAgbGV0IG51bVBhcnRzID0gMDtcbiAgaWYgKHJlbmRlck5vZGVJbmZvLmlzb2xhdGVkSW5FeHRyYWN0Lmxlbmd0aCA+IDApIHtcbiAgICBudW1QYXJ0cysrO1xuICB9XG4gIGlmIChyZW5kZXJOb2RlSW5mby5pc29sYXRlZE91dEV4dHJhY3QubGVuZ3RoID4gMCkge1xuICAgIG51bVBhcnRzKys7XG4gIH1cbiAgaWYgKHJlbmRlck5vZGVJbmZvLmxpYnJhcnlGdW5jdGlvbnNFeHRyYWN0Lmxlbmd0aCA+IDApIHtcbiAgICBudW1QYXJ0cysrO1xuICB9XG4gIGlmIChyZW5kZXJOb2RlSW5mby5jb3JlR3JhcGgubm9kZUNvdW50KCkgPiAwKSB7XG4gICAgbnVtUGFydHMrKztcbiAgfVxuICBsZXQgb2Zmc2V0ID0gUEFSQU1TLnN1YnNjZW5lLm1ldGEuZXh0cmFjdFhPZmZzZXQ7XG4gIGxldCBwYWRkaW5nID0gbnVtUGFydHMgPD0gMSA/IDAgOiAobnVtUGFydHMgKiBvZmZzZXQpO1xuXG4gIC8vIEFkZCB0aGUgaW4tZXh0cmFjdCBhbmQgb3V0LWV4dHJhY3Qgd2lkdGggdG8gdGhlIGNvcmUgYm94IHdpZHRoLiBEbyBub3QgbGV0XG4gIC8vIHRoZSBhdXhpbGlhcnkgd2lkdGggYmUgdG9vIHNtYWxsLCBsZXN0IGl0IGJlIHNtYWxsZXIgdGhhbiB0aGUgdGl0bGUuXG4gIGNvbnN0IGF1eFdpZHRoID0gTWF0aC5tYXgoXG4gICAgICBNSU5fQVVYX1dJRFRILFxuICAgICAgcmVuZGVyTm9kZUluZm8uaW5FeHRyYWN0Qm94LndpZHRoICsgcmVuZGVyTm9kZUluZm8ub3V0RXh0cmFjdEJveC53aWR0aCk7XG4gIHJlbmRlck5vZGVJbmZvLmNvcmVCb3gud2lkdGggKz0gYXV4V2lkdGggKyBwYWRkaW5nICtcbiAgICAgIHJlbmRlck5vZGVJbmZvLmxpYnJhcnlGdW5jdGlvbnNCb3gud2lkdGggKyBwYWRkaW5nO1xuICByZW5kZXJOb2RlSW5mby5jb3JlQm94LmhlaWdodCA9XG4gICAgcGFyYW1zLmxhYmVsSGVpZ2h0ICtcbiAgICBNYXRoLm1heChcbiAgICAgIHJlbmRlck5vZGVJbmZvLmluRXh0cmFjdEJveC5oZWlnaHQsXG4gICAgICByZW5kZXJOb2RlSW5mby5jb3JlQm94LmhlaWdodCxcbiAgICAgIHJlbmRlck5vZGVJbmZvLmxpYnJhcnlGdW5jdGlvbnNCb3guaGVpZ2h0LFxuICAgICAgcmVuZGVyTm9kZUluZm8ub3V0RXh0cmFjdEJveC5oZWlnaHRcbiAgKTtcbiAgLy8gRGV0ZXJtaW5lIHRoZSB3aG9sZSBtZXRhbm9kZSdzIHdpZHRoIChmcm9tIGxlZnQgdG8gcmlnaHQpLlxuICByZW5kZXJOb2RlSW5mby53aWR0aCA9IHJlbmRlck5vZGVJbmZvLmNvcmVCb3gud2lkdGggK1xuICAgICAgcGFyYW1zLnBhZGRpbmdMZWZ0ICsgcGFyYW1zLnBhZGRpbmdSaWdodDtcblxuICAvLyBEZXRlcm1pbmUgdGhlIHdob2xlIG1ldGFub2RlJ3MgaGVpZ2h0IChmcm9tIHRvcCB0byBib3R0b20pLlxuICByZW5kZXJOb2RlSW5mby5oZWlnaHQgPVxuICAgICAgcmVuZGVyTm9kZUluZm8ucGFkZGluZ1RvcCArXG4gICAgICByZW5kZXJOb2RlSW5mby5jb3JlQm94LmhlaWdodCArXG4gICAgICByZW5kZXJOb2RlSW5mby5wYWRkaW5nQm90dG9tO1xufVxuXG4vKipcbiAqIENhbGN1bGF0ZSBsYXlvdXQgZm9yIHNlcmllcyBub2RlJ3MgY29yZSBncmFwaC4gT25seSBjYWxsZWQgZm9yIGFuIGV4cGFuZGVkXG4gKiBzZXJpZXMuXG4gKi9cbmZ1bmN0aW9uIGxheW91dFNlcmllc05vZGUobm9kZTogcmVuZGVyLlJlbmRlckdyb3VwTm9kZUluZm8pOiB2b2lkIHtcbiAgbGV0IGdyYXBoID0gbm9kZS5jb3JlR3JhcGg7XG5cbiAgbGV0IHBhcmFtcyA9IFBBUkFNUy5zdWJzY2VuZS5zZXJpZXM7XG4gIF8uZXh0ZW5kKG5vZGUsIHBhcmFtcyk7XG5cbiAgLy8gTGF5b3V0IHRoZSBjb3JlLlxuICBfLmV4dGVuZChub2RlLmNvcmVCb3gsIGRhZ3JlTGF5b3V0KG5vZGUuY29yZUdyYXBoLCBQQVJBTVMuZ3JhcGguc2VyaWVzKSk7XG5cbiAgXy5lYWNoKGdyYXBoLm5vZGVzKCksIG5vZGVOYW1lID0+IHtcbiAgICBncmFwaC5ub2RlKG5vZGVOYW1lKS5leGNsdWRlZCA9IGZhbHNlO1xuICB9KTtcblxuICAvLyBTZXJpZXMgZG8gbm90IGhhdmUgaW4vb3V0RXh0cmFjdEJveCBzbyBubyBuZWVkIHRvIGluY2x1ZGUgdGhlbSBoZXJlLlxuICBub2RlLndpZHRoID0gbm9kZS5jb3JlQm94LndpZHRoICsgcGFyYW1zLnBhZGRpbmdMZWZ0ICsgcGFyYW1zLnBhZGRpbmdSaWdodDtcbiAgbm9kZS5oZWlnaHQgPSBub2RlLmNvcmVCb3guaGVpZ2h0ICsgcGFyYW1zLnBhZGRpbmdUb3AgKyBwYXJhbXMucGFkZGluZ0JvdHRvbTtcbn1cblxuLyoqXG4gKiBDYWxjdWxhdGUgbGF5b3V0IGZvciBhbm5vdGF0aW9ucyBvZiBhIGdpdmVuIG5vZGUuXG4gKiBUaGlzIHdpbGwgbW9kaWZ5IHBvc2l0aW9ucyBvZiB0aGUgZ2l2ZW4gbm9kZSBhbmQgaXRzIGFubm90YXRpb25zLlxuICpcbiAqIEBzZWUgdGYuZ3JhcGgucmVuZGVyLk5vZGUgYW5kIHRmLmdyYXBoLnJlbmRlci5Bbm5vdGF0aW9uXG4gKiBmb3IgZGVzY3JpcHRpb24gb2YgZWFjaCBwcm9wZXJ0eSBvZiBlYWNoIHJlbmRlciBub2RlLlxuICpcbiAqL1xuZnVuY3Rpb24gbGF5b3V0QW5ub3RhdGlvbihyZW5kZXJOb2RlSW5mbzogcmVuZGVyLlJlbmRlck5vZGVJbmZvKTogdm9pZCB7XG4gIC8vIElmIHRoZSByZW5kZXIgbm9kZSBpcyBhbiBleHBhbmRlZCBtZXRhbm9kZSwgdGhlbiBpdHMgYW5ub3RhdGlvbnMgd2lsbCBub3RcbiAgLy8gYmUgdmlzaWJsZSBhbmQgd2Ugc2hvdWxkIHNraXAgdGhlIGFubm90YXRpb24gY2FsY3VsYXRpb25zLlxuICBpZiAocmVuZGVyTm9kZUluZm8uZXhwYW5kZWQpIHtcbiAgICByZXR1cm47XG4gIH1cblxuICBsZXQgaW5Bbm5vdGF0aW9ucyA9IHJlbmRlck5vZGVJbmZvLmluQW5ub3RhdGlvbnMubGlzdDtcbiAgbGV0IG91dEFubm90YXRpb25zID0gcmVuZGVyTm9kZUluZm8ub3V0QW5ub3RhdGlvbnMubGlzdDtcblxuICAvLyBDYWxjdWxhdGUgc2l6ZSBmb3IgaW4tYW5ub3RhdGlvbnNcbiAgXy5lYWNoKGluQW5ub3RhdGlvbnMsIGEgPT4gc2l6ZUFubm90YXRpb24oYSkpO1xuXG4gIC8vIENhbGN1bGF0ZSBzaXplIGZvciBvdXQtYW5ub3RhdGlvbnNcbiAgXy5lYWNoKG91dEFubm90YXRpb25zLCBhID0+IHNpemVBbm5vdGF0aW9uKGEpKTtcblxuICBsZXQgcGFyYW1zID0gUEFSQU1TLmFubm90YXRpb25zO1xuXG4gIC8vIENhbGN1bGF0ZSBhbm5vdGF0aW9uIG5vZGUgcG9zaXRpb24gKGEuZHgsIGEuZHkpXG4gIC8vIGFuZCB0b3RhbCBoZWlnaHQgZm9yIGluLWFubm90YXRpb25zXG4gIC8vIEFmdGVyIHRoaXMgY2h1bmsgb2YgY29kZTpcbiAgLy8gaW5ib3hIZWlnaHQgPSBzdW0gb2YgYW5ub3RhdGlvbiBoZWlnaHRzKyAoYW5ub3RhdGlvbi5sZW5ndGggLSAxICogeU9mZnNldClcbiAgbGV0IGluYm94SGVpZ2h0ID0gXy5yZWR1Y2UoaW5Bbm5vdGF0aW9ucyxcbiAgICAgIChoZWlnaHQsIGEsIGkpID0+IHtcbiAgICAgICAgbGV0IHlPZmZzZXQgPSBpID4gMCA/IHBhcmFtcy55T2Zmc2V0IDogMDtcbiAgICAgICAgYS5keCA9IC0ocmVuZGVyTm9kZUluZm8uY29yZUJveC53aWR0aCArIGEud2lkdGgpIC8gMiAtIHBhcmFtcy54T2Zmc2V0O1xuICAgICAgICBhLmR5ID0gaGVpZ2h0ICsgeU9mZnNldCArIGEuaGVpZ2h0IC8gMjtcbiAgICAgICAgcmV0dXJuIGhlaWdodCArIHlPZmZzZXQgKyBhLmhlaWdodDtcbiAgICAgIH0sIDApO1xuXG4gIF8uZWFjaChpbkFubm90YXRpb25zLCBhID0+IHtcbiAgICBhLmR5IC09IGluYm94SGVpZ2h0IC8gMjtcblxuICAgIGEubGFiZWxPZmZzZXQgPSBwYXJhbXMubGFiZWxPZmZzZXQ7XG4gIH0pO1xuXG4gIC8vIENhbGN1bGF0ZSBhbm5vdGF0aW9uIG5vZGUgcG9zaXRpb24gKGEuZHgsIGEuZHkpXG4gIC8vIGFuZCB0b3RhbCBoZWlnaHQgZm9yIG91dC1hbm5vdGF0aW9uc1xuICAvLyBBZnRlciB0aGlzIGNodW5rIG9mIGNvZGU6XG4gIC8vIG91dGJveEhlaWdodCA9IHN1bSBvZiBhbm5vdGF0aW9uIGhlaWdodHMgK1xuICAvLyAgICAgICAgICAgICAgICAoYW5ub3RhdGlvbi5sZW5ndGggLSAxICogeU9mZnNldClcbiAgbGV0IG91dGJveEhlaWdodCA9IF8ucmVkdWNlKG91dEFubm90YXRpb25zLFxuICAgICAgKGhlaWdodCwgYSwgaSkgPT4ge1xuICAgICAgICBsZXQgeU9mZnNldCA9IGkgPiAwID8gcGFyYW1zLnlPZmZzZXQgOiAwO1xuICAgICAgICBhLmR4ID0gKHJlbmRlck5vZGVJbmZvLmNvcmVCb3gud2lkdGggKyBhLndpZHRoKSAvIDIgKyBwYXJhbXMueE9mZnNldDtcbiAgICAgICAgYS5keSA9IGhlaWdodCArIHlPZmZzZXQgKyBhLmhlaWdodCAvIDI7XG4gICAgICAgIHJldHVybiBoZWlnaHQgKyB5T2Zmc2V0ICsgYS5oZWlnaHQ7XG4gICAgICB9LCAwKTtcblxuICBfLmVhY2gob3V0QW5ub3RhdGlvbnMsIGEgPT4ge1xuICAgIC8vIGFkanVzdCBieSAoaGFsZiBvZiApIHRoZSB0b3RhbCBoZWlnaHRcbiAgICAvLyBzbyBkeSBpcyByZWxhdGl2ZSB0byB0aGUgaG9zdCBub2RlJ3MgY2VudGVyLlxuICAgIGEuZHkgLT0gb3V0Ym94SGVpZ2h0IC8gMjtcblxuICAgIGEubGFiZWxPZmZzZXQgPSBwYXJhbXMubGFiZWxPZmZzZXQ7XG4gIH0pO1xuXG4gIC8vIENyZWF0aW5nIHNjYWxlcyBmb3IgdG91Y2ggcG9pbnQgYmV0d2VlbiB0aGUgaW4tYW5ub3RhdGlvbiBlZGdlc1xuICAvLyBhbmQgdGhlaXIgaG9zdHMuXG5cbiAgbGV0IGluVG91Y2hIZWlnaHQgPVxuICAgICAgTWF0aC5taW4ocmVuZGVyTm9kZUluZm8uaGVpZ2h0IC8gMiAtIHJlbmRlck5vZGVJbmZvLnJhZGl1cyxcbiAgICAgICAgICBpbmJveEhlaWdodCAvIDIpO1xuICBpblRvdWNoSGVpZ2h0ID0gaW5Ub3VjaEhlaWdodCA8IDAgPyAwIDogaW5Ub3VjaEhlaWdodDtcblxuICBsZXQgaW5ZID0gZDMuc2NhbGVMaW5lYXIoKVxuICAgIC5kb21haW4oWzAsIGluQW5ub3RhdGlvbnMubGVuZ3RoIC0gMV0pXG4gICAgLnJhbmdlKFstaW5Ub3VjaEhlaWdodCwgaW5Ub3VjaEhlaWdodF0pO1xuXG4gIC8vIENhbGN1bGF0ZSBhbm5vdGF0aW9uIGVkZ2UgcG9zaXRpb25cbiAgXy5lYWNoKGluQW5ub3RhdGlvbnMsIChhLCBpKSA9PiB7XG4gICAgYS5wb2ludHMgPSBbXG4gICAgICAvLyBUaGUgYW5ub3RhdGlvbiBub2RlIGVuZFxuICAgICAge1xuICAgICAgICBkeDogYS5keCArIGEud2lkdGggLyAyLFxuICAgICAgICBkeTogYS5keVxuICAgICAgfSxcblxuICAgICAgLy8gVGhlIGhvc3Qgbm9kZSBlbmRcbiAgICAgIHtcbiAgICAgICAgZHg6IC0gcmVuZGVyTm9kZUluZm8uY29yZUJveC53aWR0aCAvIDIsXG4gICAgICAgIC8vIG9ubHkgdXNlIHNjYWxlIGlmIHRoZXJlIGFyZSBtb3JlIHRoYW4gb25lLFxuICAgICAgICAvLyBvdGhlcndpc2UgY2VudGVyIGl0IHZlcnRpY2FsbHlcbiAgICAgICAgZHk6IGluQW5ub3RhdGlvbnMubGVuZ3RoID4gMSA/IGluWShpKSA6IDBcbiAgICAgIH1cbiAgICBdO1xuICB9KTtcblxuICAvLyBDcmVhdGluZyBzY2FsZXMgZm9yIHRvdWNoIHBvaW50IGJldHdlZW4gdGhlIG91dC1hbm5vdGF0aW9uIGVkZ2VzXG4gIC8vIGFuZCB0aGVpciBob3N0cy5cbiAgbGV0IG91dFRvdWNoSGVpZ2h0ID1cbiAgICAgIE1hdGgubWluKHJlbmRlck5vZGVJbmZvLmhlaWdodCAvIDIgLSByZW5kZXJOb2RlSW5mby5yYWRpdXMsXG4gICAgICAgICAgb3V0Ym94SGVpZ2h0IC8gMik7XG4gIG91dFRvdWNoSGVpZ2h0ID0gb3V0VG91Y2hIZWlnaHQgPCAwID8gMCA6IG91dFRvdWNoSGVpZ2h0O1xuICBsZXQgb3V0WSA9IGQzLnNjYWxlTGluZWFyKClcbiAgICAuZG9tYWluKFswLCBvdXRBbm5vdGF0aW9ucy5sZW5ndGggLSAxXSlcbiAgICAucmFuZ2UoWy1vdXRUb3VjaEhlaWdodCwgb3V0VG91Y2hIZWlnaHRdKTtcblxuICBfLmVhY2gob3V0QW5ub3RhdGlvbnMsIChhLCBpKSA9PiB7XG4gICAgLy8gQWRkIHBvaW50IGZyb20gdGhlIGJvcmRlciBvZiB0aGUgYW5ub3RhdGlvbiBub2RlXG4gICAgYS5wb2ludHMgPSBbXG4gICAgICAvLyBUaGUgaG9zdCBub2RlIGVuZFxuICAgICAge1xuICAgICAgICBkeDogcmVuZGVyTm9kZUluZm8uY29yZUJveC53aWR0aCAvIDIsXG4gICAgICAgIC8vIG9ubHkgdXNlIHNjYWxlIGlmIHRoZXJlIGFyZSBtb3JlIHRoYW4gb25lLFxuICAgICAgICAvLyBvdGhlcndpc2UgY2VudGVyIGl0IHZlcnRpY2FsbHlcbiAgICAgICAgZHk6IG91dEFubm90YXRpb25zLmxlbmd0aCA+IDEgPyBvdXRZKGkpIDogMFxuICAgICAgfSxcbiAgICAgIC8vIFRoZSBhbm5vdGF0aW9uIG5vZGUgZW5kXG4gICAgICB7XG4gICAgICAgIGR4OiBhLmR4IC0gYS53aWR0aCAvIDIsXG4gICAgICAgIGR5OiBhLmR5XG4gICAgICB9XG4gICAgXTtcbiAgfSk7XG5cbiAgcmVuZGVyTm9kZUluZm8uaGVpZ2h0ID1cbiAgICAgIE1hdGgubWF4KHJlbmRlck5vZGVJbmZvLmhlaWdodCwgaW5ib3hIZWlnaHQsIG91dGJveEhlaWdodCk7XG59XG5cbi8qKlxuICogU2V0IHNpemUgb2YgYW4gYW5ub3RhdGlvbiBub2RlLlxuICovXG5mdW5jdGlvbiBzaXplQW5ub3RhdGlvbihhOiByZW5kZXIuQW5ub3RhdGlvbik6IHZvaWQge1xuICBzd2l0Y2ggKGEuYW5ub3RhdGlvblR5cGUpIHtcbiAgICBjYXNlIHJlbmRlci5Bbm5vdGF0aW9uVHlwZS5DT05TVEFOVDpcbiAgICAgIF8uZXh0ZW5kKGEsIFBBUkFNUy5jb25zdGFudC5zaXplKTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgcmVuZGVyLkFubm90YXRpb25UeXBlLlNIT1JUQ1VUOlxuICAgICAgaWYgKGEubm9kZS50eXBlID09PSBOb2RlVHlwZS5PUCkge1xuICAgICAgICBfLmV4dGVuZChhLCBQQVJBTVMuc2hvcnRjdXRTaXplLm9wKTtcbiAgICAgIH0gZWxzZSBpZiAoYS5ub2RlLnR5cGUgPT09IE5vZGVUeXBlLk1FVEEpIHtcbiAgICAgICAgXy5leHRlbmQoYSwgUEFSQU1TLnNob3J0Y3V0U2l6ZS5tZXRhKTtcbiAgICAgIH0gZWxzZSBpZiAoYS5ub2RlLnR5cGUgPT09IE5vZGVUeXBlLlNFUklFUykge1xuICAgICAgICBfLmV4dGVuZChhLCBQQVJBTVMuc2hvcnRjdXRTaXplLnNlcmllcyk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aHJvdyBFcnJvcignSW52YWxpZCBub2RlIHR5cGU6ICcgKyBhLm5vZGUudHlwZSk7XG4gICAgICB9XG4gICAgICBicmVhaztcbiAgICBjYXNlIHJlbmRlci5Bbm5vdGF0aW9uVHlwZS5TVU1NQVJZOlxuICAgICAgXy5leHRlbmQoYSwgUEFSQU1TLmNvbnN0YW50LnNpemUpO1xuICAgICAgYnJlYWs7XG4gIH1cbn1cblxuLyoqXG4gKiBEZXRlcm1pbmVzIHRoZSBjZW50ZXIgcG9zaXRpb24gb2YgdGhlIG5vZGUncyBzaGFwZS4gVGhlIHBvc2l0aW9uIGRlcGVuZHNcbiAqIG9uIGlmIHRoZSBub2RlIGhhcyBpbiBhbmQgb3V0LWFubm90YXRpb25zLlxuICovXG5leHBvcnQgZnVuY3Rpb24gY29tcHV0ZUNYUG9zaXRpb25PZk5vZGVTaGFwZShyZW5kZXJJbmZvOiByZW5kZXIuUmVuZGVyTm9kZUluZm8pOlxuICAgIG51bWJlciB7XG4gIGlmIChyZW5kZXJJbmZvLmV4cGFuZGVkKSB7XG4gICAgcmV0dXJuIHJlbmRlckluZm8ueDtcbiAgfVxuICBsZXQgZHggPSByZW5kZXJJbmZvLmluQW5ub3RhdGlvbnMubGlzdC5sZW5ndGggPyByZW5kZXJJbmZvLmluYm94V2lkdGggOiAwO1xuICByZXR1cm4gcmVuZGVySW5mby54IC0gcmVuZGVySW5mby53aWR0aCAvIDIgKyBkeCArXG4gICAgICByZW5kZXJJbmZvLmNvcmVCb3gud2lkdGggLyAyO1xufVxuXG4vKiogUmV0dXJucyB0aGUgYW5nbGUgKGluIGRlZ3JlZXMpIGJldHdlZW4gdHdvIHBvaW50cy4gKi9cbmZ1bmN0aW9uIGFuZ2xlQmV0d2VlblR3b1BvaW50cyhhOiByZW5kZXIuUG9pbnQsIGI6IHJlbmRlci5Qb2ludCk6IG51bWJlciB7XG4gIGxldCBkeCA9IGIueCAtIGEueDtcbiAgbGV0IGR5ID0gYi55IC0gYS55O1xuICByZXR1cm4gMTgwICogTWF0aC5hdGFuKGR5IC8gZHgpIC8gTWF0aC5QSTtcbn1cblxuLyoqXG4gKiBSZXR1cm5zIGlmIGEgbGluZSBnb2luZyB0aHJvdWdoIHRoZSBzcGVjaWZpZWQgcG9pbnRzIGlzIGEgc3RyYWlnaHQgbGluZS5cbiAqL1xuZnVuY3Rpb24gaXNTdHJhaWdodExpbmUocG9pbnRzOiByZW5kZXIuUG9pbnRbXSkge1xuICBsZXQgYW5nbGUgPSBhbmdsZUJldHdlZW5Ud29Qb2ludHMocG9pbnRzWzBdLCBwb2ludHNbMV0pO1xuICBmb3IgKGxldCBpID0gMTsgaSA8IHBvaW50cy5sZW5ndGggLSAxOyBpKyspIHtcbiAgICBsZXQgbmV3QW5nbGUgPSBhbmdsZUJldHdlZW5Ud29Qb2ludHMocG9pbnRzW2ldLCBwb2ludHNbaSArIDFdKTtcbiAgICAvLyBIYXZlIGEgdG9sZXJhbmNlIG9mIDEgZGVncmVlLlxuICAgIGlmIChNYXRoLmFicyhuZXdBbmdsZSAtIGFuZ2xlKSA+IDEpIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgYW5nbGUgPSBuZXdBbmdsZTtcbiAgfVxuICByZXR1cm4gdHJ1ZTtcbn1cblxuLyoqXG4gKiBSZXR1cm5zIHRoZSBpbnRlcnNlY3Rpb24gb2YgYSBsaW5lIGJldHdlZW4gdGhlIHByb3ZpZGVkIHBvaW50XG4gKiBhbmQgdGhlIHByb3ZpZGVkIHJlY3RhbmdsZS5cbiAqL1xuZnVuY3Rpb24gaW50ZXJzZWN0UG9pbnRBbmROb2RlKFxuICAgIHBvaW50OiByZW5kZXIuUG9pbnQsIG5vZGU6IHJlbmRlci5SZW5kZXJOb2RlSW5mbyk6IHJlbmRlci5Qb2ludCB7XG4gIC8vIGN4IGFuZCBjeSBhcmUgdGhlIGNlbnRlciBvZiB0aGUgcmVjdGFuZ2xlLlxuICBsZXQgY3ggPSBub2RlLmV4cGFuZGVkID9cbiAgICAgbm9kZS54IDogY29tcHV0ZUNYUG9zaXRpb25PZk5vZGVTaGFwZShub2RlKTtcbiAgbGV0IGN5ID0gbm9kZS55O1xuICAvLyBDYWxjdWxhdGUgdGhlIHNsb3BlXG4gIGxldCBkeCA9IHBvaW50LnggLSBjeDtcbiAgbGV0IGR5ID0gcG9pbnQueSAtIGN5O1xuICBsZXQgdyA9IG5vZGUuZXhwYW5kZWQgPyBub2RlLndpZHRoIDogbm9kZS5jb3JlQm94LndpZHRoO1xuICBsZXQgaCA9IG5vZGUuZXhwYW5kZWQgPyBub2RlLmhlaWdodCA6IG5vZGUuY29yZUJveC5oZWlnaHQ7XG4gIGxldCBkZWx0YVgsIGRlbHRhWTtcbiAgaWYgKE1hdGguYWJzKGR5KSAqIHcgLyAyICA+IE1hdGguYWJzKGR4KSAqIGggLyAyKSB7XG4gICAgLy8gVGhlIGludGVyc2VjdGlvbiBpcyBhYm92ZSBvciBiZWxvdyB0aGUgcmVjdGFuZ2xlLlxuICAgIGlmIChkeSA8IDApIHtcbiAgICAgIGggPSAtaDtcbiAgICB9XG4gICAgZGVsdGFYID0gZHkgPT09IDAgPyAwIDogaCAvIDIgKiBkeCAvIGR5O1xuICAgIGRlbHRhWSA9IGggLyAyO1xuICB9IGVsc2Uge1xuICAgIC8vIFRoZSBpbnRlcnNlY3Rpb24gaXMgbGVmdCBvciByaWdodCBvZiB0aGUgcmVjdGFuZ2xlLlxuICAgIGlmIChkeCA8IDApIHtcbiAgICAgIHcgPSAtdztcbiAgICB9XG4gICAgZGVsdGFYID0gdyAvIDI7XG4gICAgZGVsdGFZID0gZHggPT09IDAgPyAwIDogdyAvIDIgKiBkeSAvIGR4O1xuICB9XG4gIHJldHVybiB7eDogY3ggKyBkZWx0YVgsIHk6IGN5ICsgZGVsdGFZfTtcbn1cblxufSAvLyBjbG9zZSBtb2R1bGVcbiJdfQ==