/* Copyright 2015 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the 'License');
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an 'AS IS' BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
/**
 * Package for the Graph Hierarchy for TensorFlow graph.
 */
var tf;
(function (tf) {
    var graph;
    (function (graph_1) {
        var hierarchy;
        (function (hierarchy_1) {
            /**
             * Class for the Graph Hierarchy for TensorFlow graph.
             */
            var HierarchyImpl = /** @class */ (function () {
                /**
                 * Constructs a hierarchy.
                 * @param graphOptions Options passed to dagre for creating the graph. Note
                 *   that the `compound` argument will be overriden to true.
                 */
                function HierarchyImpl(graphOptions) {
                    this.hasShapeInfo = false;
                    this.maxMetaEdgeSize = 1;
                    this.graphOptions = graphOptions || {};
                    this.graphOptions.compound = true;
                    this.root = graph_1.createMetanode(graph_1.ROOT_NAME, this.graphOptions);
                    this.libraryFunctions = {};
                    this.templates = null;
                    this.devices = null;
                    this.xlaClusters = null;
                    /**
                     * @type {Object} Dictionary object that maps node name to the node
                     * (could be op-node, metanode, or series-node)
                     */
                    this.index = {};
                    this.index[graph_1.ROOT_NAME] = this.root;
                    this.orderings = {};
                }
                HierarchyImpl.prototype.getNodeMap = function () {
                    return this.index;
                };
                HierarchyImpl.prototype.node = function (name) {
                    return this.index[name];
                };
                HierarchyImpl.prototype.setNode = function (name, node) {
                    this.index[name] = node;
                };
                /**
                 * Given the name of a node in this hierarchy, get its bridgegraph, creating
                 * it on the fly if necessary. If the node is not a GroupNode, then this
                 * method returns null. If the provided name does not map to a node in the
                 * hierarchy, an error will be thrown.
                 */
                HierarchyImpl.prototype.getBridgegraph = function (nodeName) {
                    var _this = this;
                    var node = this.index[nodeName];
                    if (!node) {
                        throw Error('Could not find node in hierarchy: ' + nodeName);
                    }
                    if (!('metagraph' in node)) {
                        return null;
                    }
                    var groupNode = node;
                    if (groupNode.bridgegraph) {
                        return groupNode.bridgegraph;
                    }
                    var bridgegraph = groupNode.bridgegraph =
                        graph_1.createGraph('BRIDGEGRAPH', graph_1.GraphType.BRIDGE, this.graphOptions);
                    if (!node.parentNode || !('metagraph' in node.parentNode)) {
                        return bridgegraph;
                    }
                    var parentNode = node.parentNode;
                    var parentMetagraph = parentNode.metagraph;
                    var parentBridgegraph = this.getBridgegraph(parentNode.name);
                    // For each of the parent node's two Metaedge containing graphs, process
                    // each Metaedge involving this node.
                    _.each([parentMetagraph, parentBridgegraph], function (parentGraph) {
                        parentGraph.edges()
                            .filter(function (e) { return e.v === nodeName || e.w === nodeName; })
                            .forEach(function (parentEdgeObj) {
                            var inbound = parentEdgeObj.w === nodeName;
                            var parentMetaedge = parentGraph.edge(parentEdgeObj);
                            // The parent's Metaedge represents some number of underlying
                            // BaseEdges from the original full graph. For each of those, we need
                            // to determine which immediate child is involved and make sure
                            // there's a Metaedge in the bridgegraph that covers it.
                            _.each(parentMetaedge.baseEdgeList, function (baseEdge) {
                                // Based on the direction, figure out which is the descendant node
                                // and which is the 'other' node (sibling of parent or ancestor).
                                var _a = inbound ?
                                    [baseEdge.w, parentEdgeObj.v] :
                                    [baseEdge.v, parentEdgeObj.w], descendantName = _a[0], otherName = _a[1];
                                // Determine the immediate child containing this descendant node.
                                var childName = _this.getChildName(nodeName, descendantName);
                                // Look for an existing Metaedge in the bridgegraph (or create a
                                // new one) that covers the relationship between child and other.
                                var bridgeEdgeObj = {
                                    v: inbound ? otherName : childName,
                                    w: inbound ? childName : otherName,
                                };
                                var bridgeMetaedge = bridgegraph.edge(bridgeEdgeObj);
                                if (!bridgeMetaedge) {
                                    bridgeMetaedge = graph_1.createMetaedge(bridgeEdgeObj.v, bridgeEdgeObj.w);
                                    bridgeMetaedge.inbound = inbound;
                                    bridgegraph.setEdge(bridgeEdgeObj.v, bridgeEdgeObj.w, bridgeMetaedge);
                                }
                                // Copy the BaseEdge from the parent's Metaedge into this
                                // bridgegraph Metaedge.
                                bridgeMetaedge.addBaseEdge(baseEdge, _this);
                            });
                        });
                    });
                    return bridgegraph;
                };
                /**
                 * Utility function for determining the name of the immediate child under a
                 * node for a given descendant path. If the descendant corresponds to no
                 * immediate child, an error is thrown.
                 */
                HierarchyImpl.prototype.getChildName = function (nodeName, descendantName) {
                    // Walk up the hierarchy from the descendant to find the child.
                    var currentNode = this.index[descendantName];
                    while (currentNode) {
                        if (currentNode.parentNode && currentNode.parentNode.name === nodeName) {
                            return currentNode.name;
                        }
                        currentNode = currentNode.parentNode;
                    }
                    throw Error('Could not find immediate child for descendant: ' + descendantName);
                };
                ;
                /** Given the name of a node, return its incoming metaedges. */
                HierarchyImpl.prototype.getPredecessors = function (nodeName) {
                    var _this = this;
                    var node = this.index[nodeName];
                    if (!node) {
                        throw Error('Could not find node with name: ' + nodeName);
                    }
                    var predecessors = this.getOneWayEdges(node, true);
                    // Add embedded predecessors, such as constants.
                    if (!node.isGroupNode) {
                        _.each(node.inEmbeddings, function (embeddedNode) {
                            _.each(node.inputs, function (input) {
                                if (input.name === embeddedNode.name) {
                                    // Make a new metaedge holding the edge between the
                                    // node and the in-embedding.
                                    var metaedge = new graph_1.MetaedgeImpl(embeddedNode.name, nodeName);
                                    metaedge.addBaseEdge({
                                        isControlDependency: input.isControlDependency,
                                        outputTensorKey: input.outputTensorKey,
                                        isReferenceEdge: false,
                                        v: embeddedNode.name,
                                        w: nodeName
                                    }, _this);
                                    predecessors.regular.push(metaedge);
                                }
                            });
                        });
                    }
                    return predecessors;
                };
                /**
                 * Given the name of a node, return its outgoing metaedges.
                 *
                 * This is the inverse of getPredecessors(). See that method's documentation
                 * for an in-depth example.
                 */
                HierarchyImpl.prototype.getSuccessors = function (nodeName) {
                    var _this = this;
                    var node = this.index[nodeName];
                    if (!node) {
                        throw Error('Could not find node with name: ' + nodeName);
                    }
                    var successors = this.getOneWayEdges(node, false);
                    // Add embedded successors, such as summaries.
                    if (!node.isGroupNode) {
                        _.each(node.outEmbeddings, function (embeddedNode) {
                            _.each(embeddedNode.inputs, function (input) {
                                if (input.name === nodeName) {
                                    // Make a new metaedge holding the edge between the
                                    // node and the out-embedding.
                                    var metaedge = new graph_1.MetaedgeImpl(nodeName, embeddedNode.name);
                                    metaedge.addBaseEdge({
                                        isControlDependency: input.isControlDependency,
                                        outputTensorKey: input.outputTensorKey,
                                        isReferenceEdge: false,
                                        v: nodeName,
                                        w: embeddedNode.name
                                    }, _this);
                                    successors.regular.push(metaedge);
                                }
                            });
                        });
                    }
                    return successors;
                };
                /** Helper method for getPredecessors and getSuccessors */
                HierarchyImpl.prototype.getOneWayEdges = function (node, inEdges) {
                    var edges = { control: [], regular: [] };
                    // A node with no parent cannot have any edges.
                    if (!node.parentNode || !node.parentNode.isGroupNode) {
                        return edges;
                    }
                    var parentNode = node.parentNode;
                    var metagraph = parentNode.metagraph;
                    var bridgegraph = this.getBridgegraph(parentNode.name);
                    findEdgeTargetsInGraph(metagraph, node, inEdges, edges);
                    findEdgeTargetsInGraph(bridgegraph, node, inEdges, edges);
                    return edges;
                };
                /**
                 * For a given GroupNode, get or calculate an object which describes a
                 * topological ordering of child nodes within that GroupNode's metagraph.
                 *
                 * This ordering is used when rendering bridge control edges which are
                 * sometimes backwards relative to the dataflow.
                 *
                 * For example, say we have a graph with two edges A->B and A->C, and we're
                 * interested in the ordering under ROOT. In this case, any of the following
                 * would be legitimate return values:
                 *
                 *  - { 'A': 0, 'B': 1, 'C': 2 } -- most likely
                 *  - { 'A': 0, 'B': 2, 'C': 1 } -- less likely
                 *  - { 'A': 12, 'B': 100, 'C': 99 } -- unlikely, but still OK
                 *
                 * The algorithm does not guarantee that all numbers from 0-N (where N is
                 * the number of nodes) appear exactly once. Rather it guarantees that if
                 * there is a path between two nodes, the earlier one will have a lower
                 * number in the ordering hash.
                 *
                 * When generating the ordering, we ignore control Metaedges (those which
                 * represent only BaseEdges that have isControlDependency set to true).
                 *
                 * If there is no node with the specified name, an error is thrown. If the
                 * node with the specified name is not a group node, null is returned.
                 */
                HierarchyImpl.prototype.getTopologicalOrdering = function (nodeName) {
                    var node = this.index[nodeName];
                    if (!node) {
                        throw Error('Could not find node with name: ' + nodeName);
                    }
                    if (!node.isGroupNode) {
                        return null;
                    }
                    if (nodeName in this.orderings) {
                        return this.orderings[nodeName];
                    }
                    // Mapping of a child node names to lists of their successors.
                    var successors = {};
                    // Set of node names which have appeared as a destination.
                    var destinations = {};
                    var metagraph = node.metagraph;
                    _.each(metagraph.edges(), function (e) {
                        if (!metagraph.edge(e).numRegularEdges) {
                            return; // Skip control edges.
                        }
                        // Keep track of successors and destinations.
                        if (!(e.v in successors)) {
                            successors[e.v] = [];
                        }
                        successors[e.v].push(e.w);
                        destinations[e.w] = true;
                    });
                    // Seed the queue with true sources (those that are not destinations).
                    var queue = _.difference(_.keys(successors), _.keys(destinations));
                    // Produce an ordering by traversing the graph breadth first.
                    var ordering = this.orderings[nodeName] = {};
                    var index = 0;
                    while (queue.length) {
                        var childName = queue.shift();
                        ordering[childName] = index++;
                        _.each(successors[childName], function (succName) { return queue.push(succName); });
                        delete successors[childName]; // Prevent cycles from infinite looping.
                    }
                    return ordering;
                };
                /**
                 * Returns a d3 Ordinal function that can be used to look up the index of
                 * a node based on its template id.
                 */
                HierarchyImpl.prototype.getTemplateIndex = function () {
                    var templateNames = d3.keys(this.templates);
                    var templateIndex = d3.scaleOrdinal()
                        .domain(templateNames)
                        .range(d3.range(0, templateNames.length));
                    return function (templateId) { return templateIndex(templateId); };
                };
                return HierarchyImpl;
            }());
            /**
             * Internal utility function - given a graph (should be either a metagraph or a
             * bridgegraph) and a node which is known to be in that graph, determine
             * the other ends of edges that involve that node in the direction specified
             * by whether it's inbound.
             *
             * For example if you wanted to find the predecessors of a node, you'd call
             * this method for the parent's metagraph and bridgegraph, specifying inbound
             * as true (look at the source of inbound edges to the specified node).
             *
             * Discovered target names are appended to the targets array.
             */
            function findEdgeTargetsInGraph(graph, node, inbound, targets) {
                var edges = inbound ? graph.inEdges(node.name) : graph.outEdges(node.name);
                _.each(edges, function (e) {
                    var metaedge = graph.edge(e);
                    var targetList = metaedge.numRegularEdges ? targets.regular : targets.control;
                    targetList.push(metaedge);
                });
            }
            /**
             * @param graph The raw graph.
             * @param params Parameters used when building a hierarchy.
             */
            function build(graph, params, tracker) {
                var h = new HierarchyImpl({ 'rankdir': params.rankDirection });
                var seriesNames = {};
                return tf.graph.util
                    .runAsyncTask('Adding nodes', 20, function () {
                    // Get all the possible device and XLA cluster names.
                    var deviceNames = {};
                    var xlaClusterNames = {};
                    _.each(graph.nodes, function (node, nodeName) {
                        if (node.device) {
                            deviceNames[node.device] = true;
                        }
                        if (node.xlaCluster) {
                            xlaClusterNames[node.xlaCluster] = true;
                        }
                    });
                    h.devices = _.keys(deviceNames);
                    h.xlaClusters = _.keys(xlaClusterNames);
                    addNodes(h, graph);
                }, tracker)
                    .then(function () {
                    return tf.graph.util.runAsyncTask('Detect series', 20, function () {
                        if (params.seriesNodeMinSize > 0) {
                            groupSeries(h.root, h, seriesNames, params.seriesNodeMinSize, params.seriesMap, params.useGeneralizedSeriesPatterns);
                        }
                    }, tracker);
                })
                    .then(function () {
                    return tf.graph.util.runAsyncTask('Adding edges', 30, function () {
                        addEdges(h, graph, seriesNames);
                    }, tracker);
                })
                    .then(function () {
                    return tf.graph.util.runAsyncTask('Finding similar subgraphs', 30, function () {
                        h.templates = graph_1.template.detect(h, params.verifyTemplate);
                    }, tracker);
                })
                    .then(function () {
                    return h;
                });
            }
            hierarchy_1.build = build;
            ;
            function joinAndAggregateStats(h, stats) {
                // Get all the possible device and XLA cluster names.
                var deviceNames = {};
                var xlaClusterNames = {};
                _.each(h.root.leaves(), function (nodeName) {
                    var leaf = h.node(nodeName);
                    if (leaf.device != null) {
                        deviceNames[leaf.device] = true;
                    }
                    if (leaf.xlaCluster != null) {
                        xlaClusterNames[leaf.xlaCluster] = true;
                    }
                });
                h.devices = _.keys(deviceNames);
                h.xlaClusters = _.keys(xlaClusterNames);
                // Reset stats for each group node.
                _.each(h.getNodeMap(), function (node, nodeName) {
                    if (node.isGroupNode) {
                        node.stats = new graph_1.NodeStats(null);
                        node.deviceHistogram = {};
                    }
                });
                // Bubble-up the stats and device distribution from leaves to parents.
                _.each(h.root.leaves(), function (nodeName) {
                    var leaf = h.node(nodeName);
                    var node = leaf;
                    while (node.parentNode != null) {
                        if (leaf.device != null) {
                            var deviceHistogram = node.parentNode.deviceHistogram;
                            deviceHistogram[leaf.device] = (deviceHistogram[leaf.device] || 0) + 1;
                        }
                        if (leaf.xlaCluster != null) {
                            var xlaClusterHistogram = node.parentNode.xlaClusterHistogram;
                            xlaClusterHistogram[leaf.xlaCluster] =
                                (xlaClusterHistogram[leaf.xlaCluster] || 0) + 1;
                        }
                        if (leaf.stats != null) {
                            node.parentNode.stats.combine(leaf.stats);
                        }
                        node = node.parentNode;
                    }
                });
            }
            hierarchy_1.joinAndAggregateStats = joinAndAggregateStats;
            function getIncompatibleOps(hierarchy, hierarchyParams) {
                var nodes = [];
                var addedSeriesNodes = {};
                _.each(hierarchy.root.leaves(), function (leaf) {
                    var node = hierarchy.node(leaf);
                    if (node.type == graph_1.NodeType.OP) {
                        var opNode = node;
                        if (!opNode.compatible) {
                            if (opNode.owningSeries) {
                                if (hierarchyParams &&
                                    hierarchyParams.seriesMap[opNode.owningSeries]
                                        === tf.graph.SeriesGroupingType.UNGROUP) {
                                    // For un-grouped series node, add each node individually
                                    nodes.push(opNode);
                                }
                                else {
                                    if (!addedSeriesNodes[opNode.owningSeries]) {
                                        var series = hierarchy.node(opNode.owningSeries);
                                        if (series) {
                                            addedSeriesNodes[opNode.owningSeries] = series;
                                            nodes.push(series);
                                        }
                                    }
                                }
                            }
                            else {
                                nodes.push(opNode);
                            }
                        }
                        // Check the embeddings for invalid operations
                        _.each(opNode.inEmbeddings, function (inNode) {
                            if (!inNode.compatible) {
                                nodes.push(inNode);
                            }
                        });
                        _.each(opNode.outEmbeddings, function (outNode) {
                            if (!outNode.compatible) {
                                nodes.push(outNode);
                            }
                        });
                    }
                });
                return nodes;
            }
            hierarchy_1.getIncompatibleOps = getIncompatibleOps;
            /**
             * Creates the metanodes in the hierarchical graph and assigns parent-child
             * relationship between them. Also assigns relationships between library
             * functions and their usages throughout the graph.
             */
            function addNodes(h, graph) {
                // Maps the op of a node to names of nodes that have the op. Used to populate
                // the libraryFunctions field of the hierarchy.
                var opToNode = {};
                _.each(graph.nodes, function (node, nodeName) {
                    var path = graph_1.getHierarchicalPath(node.name);
                    var parent = h.root;
                    parent.depth = Math.max(path.length, parent.depth);
                    // Track which nodes are associated with which ops.
                    if (!opToNode[node.op]) {
                        opToNode[node.op] = [];
                    }
                    opToNode[node.op].push(node);
                    // Create parent metanodes for each depth. For example if the node name
                    // is 'a/b/c', then create metanodes 'a' and 'a/b', where 'a/b' is a child
                    // of a.
                    for (var i = 0; i < path.length; i++) {
                        parent.depth = Math.max(parent.depth, path.length - i);
                        parent.cardinality += node.cardinality;
                        parent.opHistogram[node.op] = (parent.opHistogram[node.op] || 0) + 1;
                        if (node.device != null) {
                            parent.deviceHistogram[node.device] =
                                (parent.deviceHistogram[node.device] || 0) + 1;
                        }
                        if (node.xlaCluster != null) {
                            parent.xlaClusterHistogram[node.xlaCluster] =
                                (parent.xlaClusterHistogram[node.xlaCluster] || 0) + 1;
                        }
                        // Increment parents appropriate compatibility count
                        if (node.compatible) {
                            parent.compatibilityHistogram.compatible =
                                (parent.compatibilityHistogram.compatible || 0) + 1;
                        }
                        else {
                            parent.compatibilityHistogram.incompatible =
                                (parent.compatibilityHistogram.incompatible || 0) + 1;
                        }
                        // Increment capability counts for in and out embeddings
                        _.each(node.inEmbeddings, function (inNode) {
                            if (inNode.compatible) {
                                parent.compatibilityHistogram.compatible =
                                    (parent.compatibilityHistogram.compatible || 0) + 1;
                            }
                            else {
                                parent.compatibilityHistogram.incompatible =
                                    (parent.compatibilityHistogram.incompatible || 0) + 1;
                            }
                        });
                        _.each(node.outEmbeddings, function (outNode) {
                            if (outNode.compatible) {
                                parent.compatibilityHistogram.compatible =
                                    (parent.compatibilityHistogram.compatible || 0) + 1;
                            }
                            else {
                                parent.compatibilityHistogram.incompatible =
                                    (parent.compatibilityHistogram.incompatible || 0) + 1;
                            }
                        });
                        if (i === path.length - 1) {
                            break;
                        }
                        var name_1 = path[i];
                        var child = h.node(name_1);
                        if (!child) {
                            child = graph_1.createMetanode(name_1, h.graphOptions);
                            child.parentNode = parent;
                            h.setNode(name_1, child);
                            parent.metagraph.setNode(name_1, child);
                            if (name_1.indexOf(tf.graph.FUNCTION_LIBRARY_NODE_PREFIX) === 0 &&
                                parent.name === tf.graph.ROOT_NAME) {
                                // This metanode represents a function in the Library. We later copy
                                // its contents to dynamically inject function data into the graph
                                // when the subhierarchy of a metanode is built (upon its expansion).
                                var functionName = name_1.substring(tf.graph.FUNCTION_LIBRARY_NODE_PREFIX.length);
                                // For now, remember the metanode that represents the function with
                                // this name.
                                if (!opToNode[functionName]) {
                                    opToNode[functionName] = [];
                                }
                                h.libraryFunctions[functionName] = {
                                    node: child,
                                    usages: opToNode[functionName],
                                };
                                child.associatedFunction = functionName;
                            }
                        }
                        parent = child;
                    }
                    // Assuming node name is 'a/b/c', assign the OpNode as a child of the
                    // metanode 'a/b'.
                    h.setNode(node.name, node);
                    node.parentNode = parent;
                    parent.metagraph.setNode(node.name, node);
                    // Add each of the in-embeddings and out-embeddings in the hierarchy.
                    _.each(node.inEmbeddings, function (embedding) {
                        h.setNode(embedding.name, embedding);
                        embedding.parentNode = node;
                    });
                    _.each(node.outEmbeddings, function (embedding) {
                        h.setNode(embedding.name, embedding);
                        embedding.parentNode = node;
                    });
                });
            }
            ;
            /**
             * For each metanode in the hierarchical graph, this method adds:
             * the edges in the metagraph. These are edges between nodes
             * that share the same parent.
             */
            function addEdges(h, graph, seriesNames) {
                var nodeIndex = h.getNodeMap();
                // Ancestor paths for the source and destination nodes of an edge. These are
                // reused for each edge rather than allocating new ones. It's about 10% faster
                // than allocating new ones on each pass through the loop.
                var sourcePath = [];
                var destPath = [];
                // Insert the ancestor path for a node into the provided array, including the
                // node itself. Return the index of the last node inserted (always ROOT).
                var getPath = function (node, path) {
                    var i = 0;
                    while (node) {
                        path[i++] = node.name;
                        node = node.parentNode;
                    }
                    return i - 1;
                };
                _.each(graph.edges, function (baseEdge) {
                    // Get the hierarchical paths for the source and destination of the edge.
                    var sourceAncestorIndex = getPath(graph.nodes[baseEdge.v], sourcePath);
                    var destAncestorIndex = getPath(graph.nodes[baseEdge.w], destPath);
                    // If the hierarchical path cannot be found for either endpoint, then we
                    // cannot create the edge. This happens for example when a node has a
                    // control dependency on a summary node, which are embedded.
                    if (sourceAncestorIndex === -1 || destAncestorIndex === -1) {
                        return;
                    }
                    // Find the lowest shared ancestor between source and dest by looking for
                    // the highest nodes that differ between their ancestor paths.
                    while (sourcePath[sourceAncestorIndex] === destPath[destAncestorIndex]) {
                        sourceAncestorIndex--;
                        destAncestorIndex--;
                        if (sourceAncestorIndex < 0 || destAncestorIndex < 0) {
                            // This would only occur if the two nodes were the same (a cycle in the
                            // graph), or if one endpoint was a strict ancestor of the other. The
                            // latter shouldn't happen because we rename nodes which are both
                            // metanodes and op nodes. E.g. 'A/B' becomes 'A/B/(B)'.
                            throw Error('No difference found between ancestor paths.');
                        }
                    }
                    var sharedAncestorNode = nodeIndex[sourcePath[sourceAncestorIndex + 1]];
                    var sourceAncestorName = sourcePath[sourceAncestorIndex];
                    var destAncestorName = destPath[destAncestorIndex];
                    // Find or create the Metaedge which should contain this BaseEdge inside
                    // the shared ancestor.
                    var metaedge = sharedAncestorNode.metagraph.edge(sourceAncestorName, destAncestorName);
                    if (!metaedge) {
                        metaedge = graph_1.createMetaedge(sourceAncestorName, destAncestorName);
                        sharedAncestorNode.metagraph
                            .setEdge(sourceAncestorName, destAncestorName, metaedge);
                    }
                    if (!sharedAncestorNode.hasNonControlEdges &&
                        !baseEdge.isControlDependency) {
                        sharedAncestorNode.hasNonControlEdges = true;
                    }
                    metaedge.addBaseEdge(baseEdge, h);
                });
            }
            ;
            /**
             * Using the hierarchy template information, detect series in the provided
             * metanode.  For each detected series, create a new SeriesNode
             * and remove series members from the metanode's metagraph and move them to
             * the new series node's metagraph.
             *
             * @param metanode
             * @param hierarchy
             * @param seriesNames Map of node names to their series they are contained in.
             *     This should be provided empty and is populated by this method.
             * @param threshold If the series has this many nodes or more, then group them
             *     into a series.
             * @param map Map of series names to their series grouping type, if one has
             *     been set.
             * @param useGeneralizedSeriesPatterns Whether to use find patterns for series
             *     nodes using any parts of names of nodes. If false, only uses patterns
             *     discovered within numeric suffixes of nodes names.
             * @return A dictionary from node name to series node name that contains the
             *     node.
             */
            function groupSeries(metanode, hierarchy, seriesNames, threshold, map, useGeneralizedSeriesPatterns) {
                var metagraph = metanode.metagraph;
                _.each(metagraph.nodes(), function (n) {
                    var child = metagraph.node(n);
                    if (child.type === tf.graph.NodeType.META) {
                        groupSeries(child, hierarchy, seriesNames, threshold, map, useGeneralizedSeriesPatterns);
                    }
                });
                var clusters = clusterNodes(metagraph);
                var detectSeriesMethod = useGeneralizedSeriesPatterns ?
                    detectSeriesAnywhereInNodeName :
                    detectSeriesUsingNumericSuffixes;
                var seriesDict = detectSeriesMethod(clusters, metagraph, hierarchy.graphOptions);
                // Add each series node to the graph and add its grouped children to its own
                // metagraph.
                _.each(seriesDict, function (seriesNode, seriesName) {
                    var nodeMemberNames = seriesNode.metagraph.nodes();
                    _.each(nodeMemberNames, function (n) {
                        var child = metagraph.node(n);
                        if (!child.owningSeries) {
                            child.owningSeries = seriesName;
                        }
                    });
                    // If the series contains less than the threshold number of nodes and
                    // this series has not been adding to the series map, then set this
                    // series to be shown ungrouped in the map.
                    if (nodeMemberNames.length < threshold && !(seriesNode.name in map)) {
                        map[seriesNode.name] = tf.graph.SeriesGroupingType.UNGROUP;
                    }
                    // If the series is in the map as ungrouped then do not group the series.
                    if (seriesNode.name in map
                        && map[seriesNode.name] === tf.graph.SeriesGroupingType.UNGROUP) {
                        return;
                    }
                    hierarchy.setNode(seriesName, seriesNode); // add to the index
                    metagraph.setNode(seriesName, seriesNode);
                    _.each(nodeMemberNames, function (n) {
                        var child = metagraph.node(n);
                        seriesNode.metagraph.setNode(n, child);
                        seriesNode.parentNode = child.parentNode;
                        seriesNode.cardinality++;
                        if (child.device != null) {
                            seriesNode.deviceHistogram[child.device] =
                                (seriesNode.deviceHistogram[child.device] || 0) + 1;
                        }
                        if (child.xlaCluster != null) {
                            seriesNode.xlaClusterHistogram[child.xlaCluster] =
                                (seriesNode.xlaClusterHistogram[child.xlaCluster] || 0) + 1;
                        }
                        // Increment parents appropriate compatibility count
                        if (child.compatible) {
                            seriesNode.compatibilityHistogram.compatible =
                                (seriesNode.compatibilityHistogram.compatible || 0) + 1;
                        }
                        else {
                            seriesNode.compatibilityHistogram.incompatible =
                                (seriesNode.compatibilityHistogram.incompatible || 0) + 1;
                        }
                        // Increment capability counts for in and out embeddings
                        _.each(child.inEmbeddings, function (inNode) {
                            if (inNode.compatible) {
                                seriesNode.compatibilityHistogram.compatible =
                                    (seriesNode.compatibilityHistogram.compatible || 0) + 1;
                            }
                            else {
                                seriesNode.compatibilityHistogram.incompatible =
                                    (seriesNode.compatibilityHistogram.incompatible || 0) + 1;
                            }
                        });
                        _.each(child.outEmbeddings, function (outNode) {
                            if (outNode.compatible) {
                                seriesNode.compatibilityHistogram.compatible =
                                    (seriesNode.compatibilityHistogram.compatible || 0) + 1;
                            }
                            else {
                                seriesNode.compatibilityHistogram.incompatible =
                                    (seriesNode.compatibilityHistogram.incompatible || 0) + 1;
                            }
                        });
                        child.parentNode = seriesNode;
                        seriesNames[n] = seriesName;
                        // Remove now-grouped node from its original parent's metagraph.
                        metagraph.removeNode(n);
                    });
                });
            }
            ;
            /** cluster op-nodes with similar op */
            function clusterNodes(metagraph) {
                var result = {};
                return _.reduce(metagraph.nodes(), function (clusters, n) {
                    var child = metagraph.node(n);
                    if (child.type === graph_1.NodeType.META) {
                        // skip metanodes
                        return clusters;
                    }
                    var template = child.op;
                    if (template) {
                        clusters[template] = clusters[template] || [];
                        clusters[template].push(child.name);
                    }
                    return clusters;
                }, result);
            }
            /**
             * For each cluster of op-nodes based op type, try to detect groupings.
             * Infer series name using by trying to find pattern '<number>' towards the end
             * of node names.
             *
             * @param clusters Dictionary output from clusterNodes().
             * @param metagraph
             * @return A dictionary from series name => seriesNode
             */
            function detectSeriesUsingNumericSuffixes(clusters, metagraph, graphOptions) {
                var seriesDict = {};
                _.each(clusters, function (members, clusterId) {
                    if (members.length <= 1) {
                        return;
                    } // isolated clusters can't make series
                    /** @type {Object}  A dictionary mapping seriesName to seriesInfoArray,
                     * which is an array that contains objects with name, id, prefix, suffix,
                     * and parent properties.
                     */
                    var candidatesDict = {};
                    // Group all nodes that have the same name, with the exception of a
                    // number at the end of the name after an underscore, which is allowed to
                    // vary.
                    _.each(members, function (name) {
                        var isGroup = name.charAt(name.length - 1) === '*';
                        var namepath = name.split('/');
                        var leaf = namepath[namepath.length - 1];
                        var parent = namepath.slice(0, namepath.length - 1).join('/');
                        var matches = leaf.match(/^(\D*)_(\d+)$/);
                        var prefix;
                        var id;
                        var suffix = '';
                        if (matches) { // if found '<number>' in the name, assign id.
                            prefix = matches[1]; // the front non-numeric characters
                            id = matches[2]; // the digits
                        }
                        else { // for node without '_<number>', make them zero-th items.
                            prefix = isGroup ? leaf.substr(0, leaf.length - 1) : leaf;
                            id = 0;
                            suffix = isGroup ? '*' : '';
                        }
                        var seriesName = graph_1.getSeriesNodeName(prefix, suffix, parent);
                        candidatesDict[seriesName] = candidatesDict[seriesName] || [];
                        var seriesNode = graph_1.createSeriesNode(prefix, suffix, parent, +id, name, graphOptions);
                        candidatesDict[seriesName].push(seriesNode);
                    });
                    // In each group of nodes, group nodes in bunches that have monotonically
                    // increasing numbers in their names.  Each of these bunches is a series.
                    _.each(candidatesDict, function (seriesInfoArray, seriesName) {
                        if (seriesInfoArray.length < 2) {
                            return;
                        }
                        seriesInfoArray.sort(function (a, b) {
                            return (+a.clusterId) - (+b.clusterId);
                        });
                        // Loop through the nodes sorted by its detected series number, grouping
                        // all nodes with monotonically-increasing series numbers.
                        var seriesNodes = [seriesInfoArray[0]];
                        for (var index = 1; index < seriesInfoArray.length; index++) {
                            var nextNode = seriesInfoArray[index];
                            if (nextNode.clusterId === seriesNodes[seriesNodes.length - 1].clusterId
                                + 1) {
                                seriesNodes.push(nextNode);
                                continue;
                            }
                            addSeriesToDict(seriesNodes, seriesDict, +clusterId, metagraph, graphOptions);
                            seriesNodes = [nextNode];
                        }
                        addSeriesToDict(seriesNodes, seriesDict, +clusterId, metagraph, graphOptions);
                    });
                });
                return seriesDict;
            }
            /**
             * For each cluster of op-nodes based op type, try to detect groupings.
             * Infer series name using by trying to find a pattern of numbers
             * anywhere within node names.
             *
             * @param clusters Dictionary output from clusterNodes().
             * @param metagraph
             * @return A dictionary from series name => seriesNode
             */
            function detectSeriesAnywhereInNodeName(clusters, metagraph, graphOptions) {
                var seriesDict = {};
                _.each(clusters, function (members, clusterId) {
                    if (members.length <= 1) {
                        return;
                    } // isolated clusters can't make series
                    /**
                     * @type {Object}  A dictionary mapping a series name to a SeriesNode.
                     */
                    var forwardDict = {};
                    /**
                     * @type {Object}  A dictionary mapping member name to an array of series
                     * names this member could potentially be grouped under and the
                     * corresponding ids.
                     */
                    var reverseDict = {};
                    // Group all nodes that have the same name, with the exception of a
                    // number at the end of the name after an underscore, which is allowed to
                    // vary.
                    _.each(members, function (name) {
                        var isGroup = name.charAt(name.length - 1) === '*';
                        var namepath = name.split('/');
                        var leaf = namepath[namepath.length - 1];
                        var parent = namepath.slice(0, namepath.length - 1).join('/');
                        var numRegex = /(\d+)/g;
                        var matches = [];
                        var matchResult;
                        var prefix;
                        var id;
                        var suffix;
                        var seriesName;
                        var matched = 0;
                        // Scan over the entire leaf name and match any possible numbers,
                        // and put the results into corresponding dictionaries.
                        while (matchResult = numRegex.exec(leaf)) {
                            ++matched;
                            prefix = leaf.slice(0, matchResult.index);
                            id = matchResult[0];
                            suffix = leaf.slice(matchResult.index + matchResult[0].length);
                            seriesName = graph_1.getSeriesNodeName(prefix, suffix, parent);
                            forwardDict[seriesName] = forwardDict[seriesName];
                            if (!forwardDict[seriesName]) {
                                forwardDict[seriesName] = graph_1.createSeriesNode(prefix, suffix, parent, +id, name, graphOptions);
                            }
                            forwardDict[seriesName].ids.push(id);
                            reverseDict[name] = reverseDict[name] || [];
                            reverseDict[name].push([seriesName, id]);
                        }
                        if (matched < 1) {
                            prefix = isGroup ? leaf.substr(0, leaf.length - 1) : leaf;
                            id = 0;
                            suffix = isGroup ? '*' : '';
                            seriesName = graph_1.getSeriesNodeName(prefix, suffix, parent);
                            forwardDict[seriesName] = forwardDict[seriesName];
                            if (!forwardDict[seriesName]) {
                                forwardDict[seriesName] = graph_1.createSeriesNode(prefix, suffix, parent, +id, name, graphOptions);
                            }
                            forwardDict[seriesName].ids.push(id);
                            reverseDict[name] = reverseDict[name] || [];
                            reverseDict[name].push([seriesName, id]);
                        }
                    });
                    /** @type {Object}  A dictionary mapping seriesName to seriesInfoArray,
                     * which is an array that contains objects with name, id, prefix, suffix,
                     * and parent properties.
                     */
                    var candidatesDict = {};
                    // For each of the member, put it into the maximum possible series,
                    // and create candidatesDict accordingly.
                    _.each(reverseDict, function (seriesNameIdArray, name) {
                        seriesNameIdArray.sort(function (a, b) {
                            return (forwardDict[b[0]].ids.length) - (forwardDict[a[0]].ids.length);
                        });
                        var seriesName = seriesNameIdArray[0][0];
                        var id = seriesNameIdArray[0][1];
                        candidatesDict[seriesName] = candidatesDict[seriesName] || [];
                        var namepath = name.split('/');
                        var leaf = namepath[namepath.length - 1];
                        var parent = namepath.slice(0, namepath.length - 1).join('/');
                        var seriesNode = graph_1.createSeriesNode(forwardDict[seriesName].prefix, forwardDict[seriesName].suffix, parent, +id, name, graphOptions);
                        candidatesDict[seriesName].push(seriesNode);
                    });
                    // In each group of nodes, group nodes in bunches that have monotonically
                    // increasing numbers in their names.  Each of these bunches is a series.
                    _.each(candidatesDict, function (seriesInfoArray, seriesName) {
                        if (seriesInfoArray.length < 2) {
                            return;
                        }
                        seriesInfoArray.sort(function (a, b) {
                            return (+a.clusterId) - (+b.clusterId);
                        });
                        // Loop through the nodes sorted by its detected series number, grouping
                        // all nodes with monotonically-increasing series numbers.
                        var seriesNodes = [seriesInfoArray[0]];
                        for (var index = 1; index < seriesInfoArray.length; index++) {
                            var nextNode = seriesInfoArray[index];
                            if (nextNode.clusterId === seriesNodes[seriesNodes.length - 1].clusterId
                                + 1) {
                                seriesNodes.push(nextNode);
                                continue;
                            }
                            addSeriesToDict(seriesNodes, seriesDict, +clusterId, metagraph, graphOptions);
                            seriesNodes = [nextNode];
                        }
                        addSeriesToDict(seriesNodes, seriesDict, +clusterId, metagraph, graphOptions);
                    });
                });
                return seriesDict;
            }
            /**
             * Add a series to the provided dictionary mapping series names to series.
             *
             * @param seriesNodes the nodes in the series. Contains
             *     name, id, prefix, suffix and parent properties of the node.
             * @param seriesDict the dictionary of series
             * @param clusterId ID of the template of the nodes of the series
             * @param metagraph
             * @param graphOptions
             */
            function addSeriesToDict(seriesNodes, seriesDict, clusterId, metagraph, graphOptions) {
                if (seriesNodes.length > 1) {
                    var curSeriesName = graph_1.getSeriesNodeName(seriesNodes[0].prefix, seriesNodes[0].suffix, seriesNodes[0].parent, seriesNodes[0].clusterId, seriesNodes[seriesNodes.length - 1].clusterId);
                    var curSeriesNode_1 = graph_1.createSeriesNode(seriesNodes[0].prefix, seriesNodes[0].suffix, seriesNodes[0].parent, clusterId, curSeriesName, graphOptions);
                    _.each(seriesNodes, function (node) {
                        curSeriesNode_1.ids.push(node.clusterId);
                        curSeriesNode_1.metagraph.setNode(node.name, metagraph.node(node.name));
                    });
                    seriesDict[curSeriesName] = curSeriesNode_1;
                }
            }
        })(hierarchy = graph_1.hierarchy || (graph_1.hierarchy = {}));
    })(graph = tf.graph || (tf.graph = {}));
})(tf || (tf = {})); // close module tf.graph.hierarchy
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaGllcmFyY2h5LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiaGllcmFyY2h5LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7Ozs7Ozs7Ozs7O2dGQWFnRjtBQUNoRjs7R0FFRztBQUNILElBQU8sRUFBRSxDQWtuQ1I7QUFsbkNELFdBQU8sRUFBRTtJQUFDLElBQUEsS0FBSyxDQWtuQ2Q7SUFsbkNTLFdBQUEsT0FBSztRQUFDLElBQUEsU0FBUyxDQWtuQ3hCO1FBbG5DZSxXQUFBLFdBQVM7WUE2Q3pCOztlQUVHO1lBQ0g7Z0JBWUU7Ozs7bUJBSUc7Z0JBQ0gsdUJBQVksWUFBbUM7b0JBVi9DLGlCQUFZLEdBQUcsS0FBSyxDQUFDO29CQUNyQixvQkFBZSxHQUFHLENBQUMsQ0FBQztvQkFVbEIsSUFBSSxDQUFDLFlBQVksR0FBRyxZQUFZLElBQUksRUFBRSxDQUFDO29CQUN2QyxJQUFJLENBQUMsWUFBWSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUM7b0JBQ2xDLElBQUksQ0FBQyxJQUFJLEdBQUcsUUFBQSxjQUFjLENBQUMsUUFBQSxTQUFTLEVBQUUsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDO29CQUN6RCxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsRUFBRSxDQUFDO29CQUMzQixJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQztvQkFDdEIsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUM7b0JBQ3BCLElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDO29CQUN4Qjs7O3VCQUdHO29CQUNILElBQUksQ0FBQyxLQUFLLEdBQUcsRUFBRSxDQUFDO29CQUNoQixJQUFJLENBQUMsS0FBSyxDQUFDLFFBQUEsU0FBUyxDQUFDLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQztvQkFDbEMsSUFBSSxDQUFDLFNBQVMsR0FBRyxFQUFFLENBQUM7Z0JBQ3RCLENBQUM7Z0JBRUQsa0NBQVUsR0FBVjtvQkFDRSxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUM7Z0JBQ3BCLENBQUM7Z0JBRUQsNEJBQUksR0FBSixVQUFLLElBQVk7b0JBQ2YsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUMxQixDQUFDO2dCQUVELCtCQUFPLEdBQVAsVUFBUSxJQUFZLEVBQUUsSUFBc0I7b0JBQzFDLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDO2dCQUMxQixDQUFDO2dCQUVEOzs7OzttQkFLRztnQkFDSCxzQ0FBYyxHQUFkLFVBQWUsUUFBZ0I7b0JBQS9CLGlCQXNFQztvQkFyRUMsSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQztvQkFDaEMsSUFBSSxDQUFDLElBQUksRUFBRTt3QkFDVCxNQUFNLEtBQUssQ0FBQyxvQ0FBb0MsR0FBRyxRQUFRLENBQUMsQ0FBQztxQkFDOUQ7b0JBQ0QsSUFBSSxDQUFDLENBQUMsV0FBVyxJQUFJLElBQUksQ0FBQyxFQUFFO3dCQUMxQixPQUFPLElBQUksQ0FBQztxQkFDYjtvQkFDRCxJQUFJLFNBQVMsR0FBZSxJQUFJLENBQUM7b0JBQ2pDLElBQUksU0FBUyxDQUFDLFdBQVcsRUFBRTt3QkFDekIsT0FBTyxTQUFTLENBQUMsV0FBVyxDQUFDO3FCQUM5QjtvQkFDRCxJQUFJLFdBQVcsR0FBRyxTQUFTLENBQUMsV0FBVzt3QkFDbkMsUUFBQSxXQUFXLENBQ1AsYUFBYSxFQUFFLFFBQUEsU0FBUyxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7b0JBQzVELElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxJQUFJLENBQUMsQ0FBQyxXQUFXLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxFQUFFO3dCQUN6RCxPQUFPLFdBQVcsQ0FBQztxQkFDcEI7b0JBRUQsSUFBSSxVQUFVLEdBQWMsSUFBSSxDQUFDLFVBQVUsQ0FBQztvQkFDNUMsSUFBSSxlQUFlLEdBQUcsVUFBVSxDQUFDLFNBQVMsQ0FBQztvQkFDM0MsSUFBSSxpQkFBaUIsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQztvQkFFN0Qsd0VBQXdFO29CQUN4RSxxQ0FBcUM7b0JBQ3JDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxlQUFlLEVBQUUsaUJBQWlCLENBQUMsRUFBRSxVQUFBLFdBQVc7d0JBQ3RELFdBQVcsQ0FBQyxLQUFLLEVBQUU7NkJBQ2hCLE1BQU0sQ0FBQyxVQUFBLENBQUMsSUFBSSxPQUFBLENBQUMsQ0FBQyxDQUFDLEtBQUssUUFBUSxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssUUFBUSxFQUFwQyxDQUFvQyxDQUFDOzZCQUNqRCxPQUFPLENBQUMsVUFBQSxhQUFhOzRCQUNwQixJQUFJLE9BQU8sR0FBRyxhQUFhLENBQUMsQ0FBQyxLQUFLLFFBQVEsQ0FBQzs0QkFDM0MsSUFBSSxjQUFjLEdBQUcsV0FBVyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQzs0QkFFckQsNkRBQTZEOzRCQUM3RCxxRUFBcUU7NEJBQ3JFLCtEQUErRDs0QkFDL0Qsd0RBQXdEOzRCQUN4RCxDQUFDLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxZQUFZLEVBQUUsVUFBQSxRQUFRO2dDQUUxQyxrRUFBa0U7Z0NBQ2xFLGlFQUFpRTtnQ0FDN0QsSUFBQTs7aUVBRzZCLEVBSDVCLHNCQUFjLEVBQUUsaUJBQVMsQ0FHSTtnQ0FFbEMsaUVBQWlFO2dDQUNqRSxJQUFJLFNBQVMsR0FBRyxLQUFJLENBQUMsWUFBWSxDQUFDLFFBQVEsRUFBRSxjQUFjLENBQUMsQ0FBQztnQ0FFNUQsZ0VBQWdFO2dDQUNoRSxpRUFBaUU7Z0NBQ2pFLElBQUksYUFBYSxHQUF5QjtvQ0FDeEMsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxTQUFTO29DQUNsQyxDQUFDLEVBQUUsT0FBTyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLFNBQVM7aUNBQ25DLENBQUM7Z0NBQ0YsSUFBSSxjQUFjLEdBQUcsV0FBVyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQztnQ0FDckQsSUFBSSxDQUFDLGNBQWMsRUFBRTtvQ0FDbkIsY0FBYyxHQUFHLFFBQUEsY0FBYyxDQUFDLGFBQWEsQ0FBQyxDQUFDLEVBQUUsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDO29DQUNsRSxjQUFjLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQztvQ0FDakMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQyxFQUFFLGFBQWEsQ0FBQyxDQUFDLEVBQ2hELGNBQWMsQ0FBQyxDQUFDO2lDQUNyQjtnQ0FFRCx5REFBeUQ7Z0NBQ3pELHdCQUF3QjtnQ0FDeEIsY0FBYyxDQUFDLFdBQVcsQ0FBQyxRQUFRLEVBQUUsS0FBSSxDQUFDLENBQUM7NEJBQzdDLENBQUMsQ0FBQyxDQUFDO3dCQUNMLENBQUMsQ0FBQyxDQUFDO29CQUNQLENBQUMsQ0FBQyxDQUFDO29CQUVILE9BQU8sV0FBVyxDQUFDO2dCQUNyQixDQUFDO2dCQUVEOzs7O21CQUlHO2dCQUNILG9DQUFZLEdBQVosVUFBYSxRQUFnQixFQUFFLGNBQXNCO29CQUNuRCwrREFBK0Q7b0JBQy9ELElBQUksV0FBVyxHQUFTLElBQUksQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLENBQUM7b0JBQ25ELE9BQU8sV0FBVyxFQUFFO3dCQUNsQixJQUFJLFdBQVcsQ0FBQyxVQUFVLElBQUksV0FBVyxDQUFDLFVBQVUsQ0FBQyxJQUFJLEtBQUssUUFBUSxFQUFFOzRCQUN0RSxPQUFPLFdBQVcsQ0FBQyxJQUFJLENBQUM7eUJBQ3pCO3dCQUNELFdBQVcsR0FBRyxXQUFXLENBQUMsVUFBVSxDQUFDO3FCQUN0QztvQkFDRCxNQUFNLEtBQUssQ0FDUCxpREFBaUQsR0FBRyxjQUFjLENBQUMsQ0FBQztnQkFDMUUsQ0FBQztnQkFBQSxDQUFDO2dCQUVGLCtEQUErRDtnQkFDL0QsdUNBQWUsR0FBZixVQUFnQixRQUFnQjtvQkFBaEMsaUJBOEJDO29CQTdCQyxJQUFJLElBQUksR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDO29CQUNoQyxJQUFJLENBQUMsSUFBSSxFQUFFO3dCQUNULE1BQU0sS0FBSyxDQUFDLGlDQUFpQyxHQUFHLFFBQVEsQ0FBQyxDQUFDO3FCQUMzRDtvQkFFRCxJQUFJLFlBQVksR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQztvQkFDbkQsZ0RBQWdEO29CQUNoRCxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBRTt3QkFDckIsQ0FBQyxDQUFDLElBQUksQ0FBVSxJQUFLLENBQUMsWUFBWSxFQUFFLFVBQUEsWUFBWTs0QkFDOUMsQ0FBQyxDQUFDLElBQUksQ0FBVSxJQUFLLENBQUMsTUFBTSxFQUFFLFVBQUEsS0FBSztnQ0FDakMsSUFBSSxLQUFLLENBQUMsSUFBSSxLQUFLLFlBQVksQ0FBQyxJQUFJLEVBQUU7b0NBQ3BDLG1EQUFtRDtvQ0FDbkQsNkJBQTZCO29DQUM3QixJQUFJLFFBQVEsR0FBRyxJQUFJLFFBQUEsWUFBWSxDQUFDLFlBQVksQ0FBQyxJQUFJLEVBQUUsUUFBUSxDQUFDLENBQUM7b0NBQzdELFFBQVEsQ0FBQyxXQUFXLENBQ2hCO3dDQUNFLG1CQUFtQixFQUFFLEtBQUssQ0FBQyxtQkFBbUI7d0NBQzlDLGVBQWUsRUFBRSxLQUFLLENBQUMsZUFBZTt3Q0FDdEMsZUFBZSxFQUFFLEtBQUs7d0NBQ3RCLENBQUMsRUFBRSxZQUFZLENBQUMsSUFBSTt3Q0FDcEIsQ0FBQyxFQUFFLFFBQVE7cUNBQ1osRUFDRCxLQUFJLENBQUMsQ0FBQztvQ0FDVixZQUFZLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztpQ0FDckM7NEJBQ0gsQ0FBQyxDQUFDLENBQUM7d0JBQ0wsQ0FBQyxDQUFDLENBQUM7cUJBQ0o7b0JBQ0QsT0FBTyxZQUFZLENBQUM7Z0JBQ3RCLENBQUM7Z0JBRUQ7Ozs7O21CQUtHO2dCQUNILHFDQUFhLEdBQWIsVUFBYyxRQUFnQjtvQkFBOUIsaUJBK0JDO29CQTlCQyxJQUFJLElBQUksR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDO29CQUNoQyxJQUFJLENBQUMsSUFBSSxFQUFFO3dCQUNULE1BQU0sS0FBSyxDQUFDLGlDQUFpQyxHQUFHLFFBQVEsQ0FBQyxDQUFDO3FCQUMzRDtvQkFFRCxJQUFJLFVBQVUsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLElBQUksRUFBRSxLQUFLLENBQUMsQ0FBQztvQkFFbEQsOENBQThDO29CQUM5QyxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBRTt3QkFDckIsQ0FBQyxDQUFDLElBQUksQ0FBVSxJQUFLLENBQUMsYUFBYSxFQUFFLFVBQUEsWUFBWTs0QkFDL0MsQ0FBQyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsTUFBTSxFQUFFLFVBQUEsS0FBSztnQ0FDL0IsSUFBSSxLQUFLLENBQUMsSUFBSSxLQUFLLFFBQVEsRUFBRTtvQ0FDM0IsbURBQW1EO29DQUNuRCw4QkFBOEI7b0NBQzlCLElBQUksUUFBUSxHQUFHLElBQUksUUFBQSxZQUFZLENBQUMsUUFBUSxFQUFFLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQztvQ0FDN0QsUUFBUSxDQUFDLFdBQVcsQ0FDaEI7d0NBQ0UsbUJBQW1CLEVBQUUsS0FBSyxDQUFDLG1CQUFtQjt3Q0FDOUMsZUFBZSxFQUFFLEtBQUssQ0FBQyxlQUFlO3dDQUN0QyxlQUFlLEVBQUUsS0FBSzt3Q0FDdEIsQ0FBQyxFQUFFLFFBQVE7d0NBQ1gsQ0FBQyxFQUFFLFlBQVksQ0FBQyxJQUFJO3FDQUNyQixFQUNELEtBQUksQ0FBQyxDQUFDO29DQUNWLFVBQVUsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO2lDQUNuQzs0QkFDSCxDQUFDLENBQUMsQ0FBQzt3QkFDTCxDQUFDLENBQUMsQ0FBQztxQkFDSjtvQkFDRCxPQUFPLFVBQVUsQ0FBQztnQkFDcEIsQ0FBQztnQkFFRCwwREFBMEQ7Z0JBQzFELHNDQUFjLEdBQWQsVUFBZSxJQUFzQixFQUFFLE9BQWdCO29CQUNyRCxJQUFJLEtBQUssR0FBVSxFQUFDLE9BQU8sRUFBRSxFQUFFLEVBQUUsT0FBTyxFQUFFLEVBQUUsRUFBQyxDQUFDO29CQUM5QywrQ0FBK0M7b0JBQy9DLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLEVBQUU7d0JBQ3BELE9BQU8sS0FBSyxDQUFDO3FCQUNkO29CQUNELElBQUksVUFBVSxHQUFlLElBQUksQ0FBQyxVQUFVLENBQUM7b0JBQzdDLElBQUksU0FBUyxHQUFHLFVBQVUsQ0FBQyxTQUFTLENBQUM7b0JBQ3JDLElBQUksV0FBVyxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDO29CQUN2RCxzQkFBc0IsQ0FBQyxTQUFTLEVBQUUsSUFBSSxFQUFFLE9BQU8sRUFBRSxLQUFLLENBQUMsQ0FBQztvQkFDeEQsc0JBQXNCLENBQUMsV0FBVyxFQUFFLElBQUksRUFBRSxPQUFPLEVBQUUsS0FBSyxDQUFDLENBQUM7b0JBQzFELE9BQU8sS0FBSyxDQUFDO2dCQUNmLENBQUM7Z0JBRUQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7bUJBeUJHO2dCQUNILDhDQUFzQixHQUF0QixVQUF1QixRQUFnQjtvQkFDckMsSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQztvQkFDaEMsSUFBSSxDQUFDLElBQUksRUFBRTt3QkFDVCxNQUFNLEtBQUssQ0FBQyxpQ0FBaUMsR0FBRyxRQUFRLENBQUMsQ0FBQztxQkFDM0Q7b0JBQ0QsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUU7d0JBQ3JCLE9BQU8sSUFBSSxDQUFDO3FCQUNiO29CQUNELElBQUksUUFBUSxJQUFJLElBQUksQ0FBQyxTQUFTLEVBQUU7d0JBQzlCLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQztxQkFDakM7b0JBRUQsOERBQThEO29CQUM5RCxJQUFJLFVBQVUsR0FBc0MsRUFBRSxDQUFDO29CQUV2RCwwREFBMEQ7b0JBQzFELElBQUksWUFBWSxHQUFxQyxFQUFFLENBQUM7b0JBRXhELElBQUksU0FBUyxHQUFnQixJQUFLLENBQUMsU0FBUyxDQUFDO29CQUM3QyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLEVBQUUsRUFBRSxVQUFDLENBQXNCO3dCQUMvQyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxlQUFlLEVBQUU7NEJBQ3RDLE9BQU8sQ0FBQyxzQkFBc0I7eUJBQy9CO3dCQUVELDZDQUE2Qzt3QkFDN0MsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxVQUFVLENBQUMsRUFBRTs0QkFDeEIsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUM7eUJBQ3RCO3dCQUNELFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDMUIsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUM7b0JBQzNCLENBQUMsQ0FBQyxDQUFDO29CQUVILHNFQUFzRTtvQkFDdEUsSUFBSSxLQUFLLEdBQ1AsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQztvQkFFekQsNkRBQTZEO29CQUM3RCxJQUFJLFFBQVEsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxHQUFHLEVBQUUsQ0FBQztvQkFDN0MsSUFBSSxLQUFLLEdBQUcsQ0FBQyxDQUFDO29CQUNkLE9BQU8sS0FBSyxDQUFDLE1BQU0sRUFBRTt3QkFDbkIsSUFBSSxTQUFTLEdBQUcsS0FBSyxDQUFDLEtBQUssRUFBRSxDQUFDO3dCQUM5QixRQUFRLENBQUMsU0FBUyxDQUFDLEdBQUcsS0FBSyxFQUFFLENBQUM7d0JBQzlCLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxFQUFFLFVBQUEsUUFBUSxJQUFJLE9BQUEsS0FBSyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBcEIsQ0FBb0IsQ0FBQyxDQUFDO3dCQUNoRSxPQUFPLFVBQVUsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLHdDQUF3QztxQkFDdkU7b0JBQ0QsT0FBTyxRQUFRLENBQUM7Z0JBQ2xCLENBQUM7Z0JBRUQ7OzttQkFHRztnQkFDSCx3Q0FBZ0IsR0FBaEI7b0JBQ0UsSUFBSSxhQUFhLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7b0JBQzVDLElBQUksYUFBYSxHQUFHLEVBQUUsQ0FBQyxZQUFZLEVBQUU7eUJBQ2hDLE1BQU0sQ0FBQyxhQUFhLENBQUM7eUJBQ3JCLEtBQUssQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxhQUFhLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztvQkFDOUMsT0FBTyxVQUFDLFVBQWtCLElBQUssT0FBUSxhQUFhLENBQUMsVUFBVSxDQUFDLEVBQWpDLENBQWlDLENBQUM7Z0JBQ25FLENBQUM7Z0JBQ0gsb0JBQUM7WUFBRCxDQUFDLEFBMVRELElBMFRDO1lBRUQ7Ozs7Ozs7Ozs7O2VBV0c7WUFDSCxnQ0FDSSxLQUFpRCxFQUNqRCxJQUFVLEVBQUUsT0FBZ0IsRUFBRSxPQUFjO2dCQUM5QyxJQUFJLEtBQUssR0FBRyxPQUFPLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDM0UsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsVUFBQSxDQUFDO29CQUNiLElBQUksUUFBUSxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQzdCLElBQUksVUFBVSxHQUNWLFFBQVEsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUM7b0JBQ2pFLFVBQVUsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7Z0JBQzVCLENBQUMsQ0FBQyxDQUFDO1lBQ0wsQ0FBQztZQWVEOzs7ZUFHRztZQUNILGVBQXNCLEtBQXlCLEVBQUUsTUFBdUIsRUFDcEUsT0FBd0I7Z0JBQzFCLElBQUksQ0FBQyxHQUFHLElBQUksYUFBYSxDQUFDLEVBQUMsU0FBUyxFQUFFLE1BQU0sQ0FBQyxhQUFhLEVBQUMsQ0FBQyxDQUFDO2dCQUM3RCxJQUFJLFdBQVcsR0FBK0IsRUFBRSxDQUFDO2dCQUNqRCxPQUFPLEVBQUUsQ0FBQyxLQUFLLENBQUMsSUFBSTtxQkFDZixZQUFZLENBQ1QsY0FBYyxFQUFFLEVBQUUsRUFDbEI7b0JBQ0UscURBQXFEO29CQUNyRCxJQUFJLFdBQVcsR0FBRyxFQUFFLENBQUM7b0JBQ3JCLElBQUksZUFBZSxHQUFHLEVBQUUsQ0FBQztvQkFDekIsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxFQUFFLFVBQUMsSUFBSSxFQUFFLFFBQVE7d0JBQ2pDLElBQUksSUFBSSxDQUFDLE1BQU0sRUFBRTs0QkFDZixXQUFXLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLElBQUksQ0FBQzt5QkFDakM7d0JBRUQsSUFBSSxJQUFJLENBQUMsVUFBVSxFQUFFOzRCQUNuQixlQUFlLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLElBQUksQ0FBQzt5QkFDekM7b0JBQ0gsQ0FBQyxDQUFDLENBQUM7b0JBRUgsQ0FBQyxDQUFDLE9BQU8sR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO29CQUNoQyxDQUFDLENBQUMsV0FBVyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUM7b0JBRXhDLFFBQVEsQ0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUM7Z0JBQ3JCLENBQUMsRUFDRCxPQUFPLENBQUM7cUJBQ1gsSUFBSSxDQUFDO29CQUNKLE9BQU8sRUFBRSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLGVBQWUsRUFBRSxFQUFFLEVBQUU7d0JBQ3JELElBQUksTUFBTSxDQUFDLGlCQUFpQixHQUFHLENBQUMsRUFBRTs0QkFDaEMsV0FBVyxDQUNQLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxFQUFFLFdBQVcsRUFBRSxNQUFNLENBQUMsaUJBQWlCLEVBQ2hELE1BQU0sQ0FBQyxTQUFTLEVBQUUsTUFBTSxDQUFDLDRCQUE0QixDQUFDLENBQUM7eUJBQzVEO29CQUNILENBQUMsRUFBRSxPQUFPLENBQUMsQ0FBQztnQkFDZCxDQUFDLENBQUM7cUJBQ0QsSUFBSSxDQUFDO29CQUNKLE9BQU8sRUFBRSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLGNBQWMsRUFBRSxFQUFFLEVBQUU7d0JBQ3BELFFBQVEsQ0FBQyxDQUFDLEVBQUUsS0FBSyxFQUFFLFdBQVcsQ0FBQyxDQUFDO29CQUNsQyxDQUFDLEVBQUUsT0FBTyxDQUFDLENBQUM7Z0JBQ2QsQ0FBQyxDQUFDO3FCQUNELElBQUksQ0FBQztvQkFDSixPQUFPLEVBQUUsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FDN0IsMkJBQTJCLEVBQUUsRUFBRSxFQUFFO3dCQUMvQixDQUFDLENBQUMsU0FBUyxHQUFHLFFBQUEsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsTUFBTSxDQUFDLGNBQWMsQ0FBQyxDQUFDO29CQUMxRCxDQUFDLEVBQUUsT0FBTyxDQUFDLENBQUM7Z0JBQ2xCLENBQUMsQ0FBQztxQkFDRCxJQUFJLENBQUM7b0JBQ0osT0FBTyxDQUFDLENBQUM7Z0JBQ1gsQ0FBQyxDQUFDLENBQUM7WUFDVCxDQUFDO1lBbERlLGlCQUFLLFFBa0RwQixDQUFBO1lBQUEsQ0FBQztZQUVGLCtCQUNJLENBQVksRUFBRSxLQUErQjtnQkFDL0MscURBQXFEO2dCQUNyRCxJQUFJLFdBQVcsR0FBRyxFQUFFLENBQUM7Z0JBQ3JCLElBQUksZUFBZSxHQUFHLEVBQUUsQ0FBQztnQkFDekIsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxFQUFFLFVBQUEsUUFBUTtvQkFDOUIsSUFBSSxJQUFJLEdBQVksQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztvQkFDckMsSUFBSSxJQUFJLENBQUMsTUFBTSxJQUFJLElBQUksRUFBRTt3QkFDdkIsV0FBVyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxJQUFJLENBQUM7cUJBQ2pDO29CQUNELElBQUksSUFBSSxDQUFDLFVBQVUsSUFBSSxJQUFJLEVBQUU7d0JBQzNCLGVBQWUsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsSUFBSSxDQUFDO3FCQUN6QztnQkFDSCxDQUFDLENBQUMsQ0FBQztnQkFDSCxDQUFDLENBQUMsT0FBTyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7Z0JBQ2hDLENBQUMsQ0FBQyxXQUFXLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQztnQkFFeEMsbUNBQW1DO2dCQUNuQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxVQUFVLEVBQUUsRUFBRSxVQUFDLElBQUksRUFBRSxRQUFRO29CQUNwQyxJQUFJLElBQUksQ0FBQyxXQUFXLEVBQUU7d0JBQ3BCLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxRQUFBLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQzt3QkFDckIsSUFBSyxDQUFDLGVBQWUsR0FBRyxFQUFFLENBQUM7cUJBQ3hDO2dCQUNILENBQUMsQ0FBQyxDQUFDO2dCQUVILHNFQUFzRTtnQkFDdEUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxFQUFFLFVBQUEsUUFBUTtvQkFDOUIsSUFBSSxJQUFJLEdBQVksQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztvQkFDckMsSUFBSSxJQUFJLEdBQXNCLElBQUksQ0FBQztvQkFDbkMsT0FBTyxJQUFJLENBQUMsVUFBVSxJQUFJLElBQUksRUFBRTt3QkFDOUIsSUFBSSxJQUFJLENBQUMsTUFBTSxJQUFJLElBQUksRUFBRTs0QkFDdkIsSUFBSSxlQUFlLEdBQWUsSUFBSSxDQUFDLFVBQVcsQ0FBQyxlQUFlLENBQUM7NEJBQ25FLGVBQWUsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQzt5QkFDeEU7d0JBQ0QsSUFBSSxJQUFJLENBQUMsVUFBVSxJQUFJLElBQUksRUFBRTs0QkFDM0IsSUFBSSxtQkFBbUIsR0FDUCxJQUFJLENBQUMsVUFBVyxDQUFDLG1CQUFtQixDQUFDOzRCQUNyRCxtQkFBbUIsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDO2dDQUNoQyxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7eUJBQ3JEO3dCQUNELElBQUksSUFBSSxDQUFDLEtBQUssSUFBSSxJQUFJLEVBQUU7NEJBQ3RCLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7eUJBQzNDO3dCQUNELElBQUksR0FBZSxJQUFJLENBQUMsVUFBVSxDQUFDO3FCQUNwQztnQkFDSCxDQUFDLENBQUMsQ0FBQztZQUNMLENBQUM7WUE5Q2UsaUNBQXFCLHdCQThDcEMsQ0FBQTtZQUVELDRCQUFtQyxTQUFvQixFQUNwQixlQUFnQztnQkFDakUsSUFBSSxLQUFLLEdBQTJCLEVBQUUsQ0FBQztnQkFDdkMsSUFBSSxnQkFBZ0IsR0FBeUMsRUFBRSxDQUFDO2dCQUNoRSxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLEVBQUUsVUFBQSxJQUFJO29CQUNsQyxJQUFJLElBQUksR0FBRyxTQUFTLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO29CQUNoQyxJQUFJLElBQUksQ0FBQyxJQUFJLElBQUksUUFBQSxRQUFRLENBQUMsRUFBRSxFQUFFO3dCQUM1QixJQUFJLE1BQU0sR0FBWSxJQUFJLENBQUM7d0JBRTNCLElBQUksQ0FBQyxNQUFNLENBQUMsVUFBVSxFQUFFOzRCQUN0QixJQUFJLE1BQU0sQ0FBQyxZQUFZLEVBQUU7Z0NBQ3ZCLElBQUksZUFBZTtvQ0FDZixlQUFlLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUM7NENBQzFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsa0JBQWtCLENBQUMsT0FBTyxFQUFFO29DQUMzQyx5REFBeUQ7b0NBQ3pELEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUE7aUNBQ25CO3FDQUFNO29DQUNMLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLEVBQUU7d0NBQzFDLElBQUksTUFBTSxHQUFlLFNBQVMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDO3dDQUM3RCxJQUFJLE1BQU0sRUFBRTs0Q0FDVixnQkFBZ0IsQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLEdBQUcsTUFBTSxDQUFDOzRDQUMvQyxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO3lDQUNwQjtxQ0FDRjtpQ0FDRjs2QkFDRjtpQ0FBTTtnQ0FDTCxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDOzZCQUNwQjt5QkFDRjt3QkFFRCw4Q0FBOEM7d0JBQzlDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksRUFBRSxVQUFDLE1BQU07NEJBQ2pDLElBQUksQ0FBQyxNQUFNLENBQUMsVUFBVSxFQUFFO2dDQUN0QixLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDOzZCQUNwQjt3QkFDSCxDQUFDLENBQUMsQ0FBQzt3QkFFSCxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxhQUFhLEVBQUUsVUFBQyxPQUFPOzRCQUNuQyxJQUFJLENBQUMsT0FBTyxDQUFDLFVBQVUsRUFBRTtnQ0FDdkIsS0FBSyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQzs2QkFDckI7d0JBQ0gsQ0FBQyxDQUFDLENBQUM7cUJBRUo7Z0JBQ0gsQ0FBQyxDQUFDLENBQUM7Z0JBQ0gsT0FBTyxLQUFLLENBQUM7WUFDZixDQUFDO1lBOUNlLDhCQUFrQixxQkE4Q2pDLENBQUE7WUFHRDs7OztlQUlHO1lBQ0gsa0JBQWtCLENBQVksRUFBRSxLQUFnQjtnQkFDOUMsNkVBQTZFO2dCQUM3RSwrQ0FBK0M7Z0JBQy9DLElBQU0sUUFBUSxHQUFHLEVBQUUsQ0FBQztnQkFFcEIsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxFQUFFLFVBQUMsSUFBSSxFQUFFLFFBQVE7b0JBQ2pDLElBQUksSUFBSSxHQUFHLFFBQUEsbUJBQW1CLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO29CQUMxQyxJQUFJLE1BQU0sR0FBYSxDQUFDLENBQUMsSUFBSSxDQUFDO29CQUU5QixNQUFNLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBRW5ELG1EQUFtRDtvQkFDbkQsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEVBQUU7d0JBQ3RCLFFBQVEsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEdBQUcsRUFBRSxDQUFDO3FCQUN4QjtvQkFDRCxRQUFRLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztvQkFFN0IsdUVBQXVFO29CQUN2RSwwRUFBMEU7b0JBQzFFLFFBQVE7b0JBQ1IsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7d0JBQ3BDLE1BQU0sQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUM7d0JBQ3ZELE1BQU0sQ0FBQyxXQUFXLElBQUksSUFBSSxDQUFDLFdBQVcsQ0FBQzt3QkFDdkMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7d0JBQ3JFLElBQUksSUFBSSxDQUFDLE1BQU0sSUFBSSxJQUFJLEVBQUU7NEJBQ3ZCLE1BQU0sQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQztnQ0FDL0IsQ0FBQyxNQUFNLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7eUJBQ3BEO3dCQUNELElBQUksSUFBSSxDQUFDLFVBQVUsSUFBSSxJQUFJLEVBQUU7NEJBQzNCLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDO2dDQUN2QyxDQUFDLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO3lCQUM1RDt3QkFFRCxvREFBb0Q7d0JBQ3BELElBQUksSUFBSSxDQUFDLFVBQVUsRUFBRTs0QkFDbkIsTUFBTSxDQUFDLHNCQUFzQixDQUFDLFVBQVU7Z0NBQ3BDLENBQUMsTUFBTSxDQUFDLHNCQUFzQixDQUFDLFVBQVUsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7eUJBQ3pEOzZCQUFNOzRCQUNMLE1BQU0sQ0FBQyxzQkFBc0IsQ0FBQyxZQUFZO2dDQUN0QyxDQUFDLE1BQU0sQ0FBQyxzQkFBc0IsQ0FBQyxZQUFZLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO3lCQUMzRDt3QkFFRCx3REFBd0Q7d0JBQ3hELENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksRUFBRSxVQUFDLE1BQU07NEJBQy9CLElBQUksTUFBTSxDQUFDLFVBQVUsRUFBRTtnQ0FDckIsTUFBTSxDQUFDLHNCQUFzQixDQUFDLFVBQVU7b0NBQ3BDLENBQUMsTUFBTSxDQUFDLHNCQUFzQixDQUFDLFVBQVUsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7NkJBQ3pEO2lDQUFNO2dDQUNMLE1BQU0sQ0FBQyxzQkFBc0IsQ0FBQyxZQUFZO29DQUN0QyxDQUFDLE1BQU0sQ0FBQyxzQkFBc0IsQ0FBQyxZQUFZLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDOzZCQUMzRDt3QkFDSCxDQUFDLENBQUMsQ0FBQzt3QkFFSCxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxhQUFhLEVBQUUsVUFBQyxPQUFPOzRCQUNqQyxJQUFJLE9BQU8sQ0FBQyxVQUFVLEVBQUU7Z0NBQ3RCLE1BQU0sQ0FBQyxzQkFBc0IsQ0FBQyxVQUFVO29DQUNwQyxDQUFDLE1BQU0sQ0FBQyxzQkFBc0IsQ0FBQyxVQUFVLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDOzZCQUN6RDtpQ0FBTTtnQ0FDTCxNQUFNLENBQUMsc0JBQXNCLENBQUMsWUFBWTtvQ0FDdEMsQ0FBQyxNQUFNLENBQUMsc0JBQXNCLENBQUMsWUFBWSxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQzs2QkFDM0Q7d0JBQ0gsQ0FBQyxDQUFDLENBQUM7d0JBRUgsSUFBSSxDQUFDLEtBQUssSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7NEJBQUUsTUFBTTt5QkFBRTt3QkFDckMsSUFBSSxNQUFJLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUNuQixJQUFJLEtBQUssR0FBYSxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQUksQ0FBQyxDQUFDO3dCQUNuQyxJQUFJLENBQUMsS0FBSyxFQUFFOzRCQUNWLEtBQUssR0FBRyxRQUFBLGNBQWMsQ0FBQyxNQUFJLEVBQUUsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDOzRCQUM3QyxLQUFLLENBQUMsVUFBVSxHQUFHLE1BQU0sQ0FBQzs0QkFDMUIsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxNQUFJLEVBQUUsS0FBSyxDQUFDLENBQUM7NEJBQ3ZCLE1BQU0sQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLE1BQUksRUFBRSxLQUFLLENBQUMsQ0FBQzs0QkFFdEMsSUFBSSxNQUFJLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsNEJBQTRCLENBQUMsS0FBSyxDQUFDO2dDQUN6RCxNQUFNLENBQUMsSUFBSSxLQUFLLEVBQUUsQ0FBQyxLQUFLLENBQUMsU0FBUyxFQUFFO2dDQUN0QyxvRUFBb0U7Z0NBQ3BFLGtFQUFrRTtnQ0FDbEUscUVBQXFFO2dDQUNyRSxJQUFNLFlBQVksR0FBRyxNQUFJLENBQUMsU0FBUyxDQUMvQixFQUFFLENBQUMsS0FBSyxDQUFDLDRCQUE0QixDQUFDLE1BQU0sQ0FBQyxDQUFDO2dDQUVsRCxtRUFBbUU7Z0NBQ25FLGFBQWE7Z0NBQ2IsSUFBSSxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsRUFBRTtvQ0FDM0IsUUFBUSxDQUFDLFlBQVksQ0FBQyxHQUFHLEVBQUUsQ0FBQztpQ0FDN0I7Z0NBQ0QsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLFlBQVksQ0FBQyxHQUFHO29DQUNqQyxJQUFJLEVBQUUsS0FBSztvQ0FDWCxNQUFNLEVBQUUsUUFBUSxDQUFDLFlBQVksQ0FBQztpQ0FDL0IsQ0FBQztnQ0FDRixLQUFLLENBQUMsa0JBQWtCLEdBQUcsWUFBWSxDQUFDOzZCQUN6Qzt5QkFDRjt3QkFDRCxNQUFNLEdBQUcsS0FBSyxDQUFDO3FCQUNoQjtvQkFFRCxxRUFBcUU7b0JBQ3JFLGtCQUFrQjtvQkFDbEIsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDO29CQUMzQixJQUFJLENBQUMsVUFBVSxHQUFHLE1BQU0sQ0FBQztvQkFDekIsTUFBTSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQztvQkFFMUMscUVBQXFFO29CQUNyRSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxZQUFZLEVBQUUsVUFBUyxTQUFTO3dCQUMxQyxDQUFDLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxJQUFJLEVBQUUsU0FBUyxDQUFDLENBQUM7d0JBQ3JDLFNBQVMsQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDO29CQUM5QixDQUFDLENBQUMsQ0FBQztvQkFDSCxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxhQUFhLEVBQUUsVUFBUyxTQUFTO3dCQUMzQyxDQUFDLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxJQUFJLEVBQUUsU0FBUyxDQUFDLENBQUM7d0JBQ3JDLFNBQVMsQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDO29CQUM5QixDQUFDLENBQUMsQ0FBQztnQkFDTCxDQUFDLENBQUMsQ0FBQztZQUNMLENBQUM7WUFBQSxDQUFDO1lBRUY7Ozs7ZUFJRztZQUNILGtCQUFrQixDQUFZLEVBQUUsS0FBZ0IsRUFDNUMsV0FBdUM7Z0JBRXpDLElBQUksU0FBUyxHQUFHLENBQUMsQ0FBQyxVQUFVLEVBQUUsQ0FBQztnQkFFL0IsNEVBQTRFO2dCQUM1RSw4RUFBOEU7Z0JBQzlFLDBEQUEwRDtnQkFDMUQsSUFBSSxVQUFVLEdBQWEsRUFBRSxDQUFDO2dCQUM5QixJQUFJLFFBQVEsR0FBYSxFQUFFLENBQUM7Z0JBRTVCLDZFQUE2RTtnQkFDN0UseUVBQXlFO2dCQUN6RSxJQUFJLE9BQU8sR0FBRyxVQUFDLElBQVUsRUFBRSxJQUFjO29CQUN2QyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7b0JBQ1YsT0FBTyxJQUFJLEVBQUU7d0JBQ1gsSUFBSSxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQzt3QkFDdEIsSUFBSSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUM7cUJBQ3hCO29CQUNELE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDZixDQUFDLENBQUM7Z0JBRUYsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxFQUFFLFVBQUEsUUFBUTtvQkFFMUIseUVBQXlFO29CQUN6RSxJQUFJLG1CQUFtQixHQUFHLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsRUFBRSxVQUFVLENBQUMsQ0FBQztvQkFDdkUsSUFBSSxpQkFBaUIsR0FBRyxPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEVBQUUsUUFBUSxDQUFDLENBQUM7b0JBRW5FLHdFQUF3RTtvQkFDeEUscUVBQXFFO29CQUNyRSw0REFBNEQ7b0JBQzVELElBQUksbUJBQW1CLEtBQUssQ0FBQyxDQUFDLElBQUksaUJBQWlCLEtBQUssQ0FBQyxDQUFDLEVBQUU7d0JBQzFELE9BQU87cUJBQ1I7b0JBRUQseUVBQXlFO29CQUN6RSw4REFBOEQ7b0JBQzlELE9BQU8sVUFBVSxDQUFDLG1CQUFtQixDQUFDLEtBQUssUUFBUSxDQUFDLGlCQUFpQixDQUFDLEVBQUU7d0JBQ3RFLG1CQUFtQixFQUFFLENBQUM7d0JBQ3RCLGlCQUFpQixFQUFFLENBQUM7d0JBQ3BCLElBQUksbUJBQW1CLEdBQUcsQ0FBQyxJQUFJLGlCQUFpQixHQUFHLENBQUMsRUFBRTs0QkFDcEQsdUVBQXVFOzRCQUN2RSxxRUFBcUU7NEJBQ3JFLGlFQUFpRTs0QkFDakUsd0RBQXdEOzRCQUN4RCxNQUFNLEtBQUssQ0FBQyw2Q0FBNkMsQ0FBQyxDQUFDO3lCQUM1RDtxQkFDRjtvQkFFRCxJQUFJLGtCQUFrQixHQUNULFNBQVMsQ0FBQyxVQUFVLENBQUMsbUJBQW1CLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDNUQsSUFBSSxrQkFBa0IsR0FBRyxVQUFVLENBQUMsbUJBQW1CLENBQUMsQ0FBQztvQkFDekQsSUFBSSxnQkFBZ0IsR0FBRyxRQUFRLENBQUMsaUJBQWlCLENBQUMsQ0FBQztvQkFFbkQsd0VBQXdFO29CQUN4RSx1QkFBdUI7b0JBQ3ZCLElBQUksUUFBUSxHQUNWLGtCQUFrQixDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQztvQkFDMUUsSUFBSSxDQUFDLFFBQVEsRUFBRTt3QkFDYixRQUFRLEdBQUcsUUFBQSxjQUFjLENBQUMsa0JBQWtCLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQzt3QkFDaEUsa0JBQWtCLENBQUMsU0FBUzs2QkFDekIsT0FBTyxDQUFDLGtCQUFrQixFQUFFLGdCQUFnQixFQUFFLFFBQVEsQ0FBQyxDQUFDO3FCQUM1RDtvQkFDRCxJQUFJLENBQUMsa0JBQWtCLENBQUMsa0JBQWtCO3dCQUN0QyxDQUFDLFFBQVEsQ0FBQyxtQkFBbUIsRUFBRTt3QkFDakMsa0JBQWtCLENBQUMsa0JBQWtCLEdBQUcsSUFBSSxDQUFDO3FCQUM5QztvQkFDRCxRQUFRLENBQUMsV0FBVyxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUMsQ0FBQztnQkFDcEMsQ0FBQyxDQUFDLENBQUM7WUFDTCxDQUFDO1lBQUEsQ0FBQztZQUVGOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O2VBbUJHO1lBQ0gscUJBQXFCLFFBQWtCLEVBQUUsU0FBb0IsRUFDekQsV0FBdUMsRUFBRSxTQUFpQixFQUMxRCxHQUFvRCxFQUNwRCw0QkFBcUM7Z0JBQ3ZDLElBQUksU0FBUyxHQUFHLFFBQVEsQ0FBQyxTQUFTLENBQUM7Z0JBQ25DLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssRUFBRSxFQUFFLFVBQUEsQ0FBQztvQkFDekIsSUFBSSxLQUFLLEdBQUcsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDOUIsSUFBSSxLQUFLLENBQUMsSUFBSSxLQUFLLEVBQUUsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRTt3QkFDekMsV0FBVyxDQUNHLEtBQUssRUFDZixTQUFTLEVBQ1QsV0FBVyxFQUNYLFNBQVMsRUFDVCxHQUFHLEVBQ0gsNEJBQTRCLENBQUMsQ0FBQztxQkFDbkM7Z0JBQ0gsQ0FBQyxDQUFDLENBQUM7Z0JBRUgsSUFBSSxRQUFRLEdBQUcsWUFBWSxDQUFDLFNBQVMsQ0FBQyxDQUFDO2dCQUV2QyxJQUFNLGtCQUFrQixHQUFHLDRCQUE0QixDQUFBLENBQUM7b0JBQ3BELDhCQUE4QixDQUFDLENBQUM7b0JBQ2hDLGdDQUFnQyxDQUFDO2dCQUNyQyxJQUFJLFVBQVUsR0FBRyxrQkFBa0IsQ0FDL0IsUUFBUSxFQUFFLFNBQVMsRUFBRSxTQUFTLENBQUMsWUFBWSxDQUFDLENBQUM7Z0JBRWpELDRFQUE0RTtnQkFDNUUsYUFBYTtnQkFDYixDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBRSxVQUFTLFVBQXNCLEVBQUUsVUFBa0I7b0JBQ3BFLElBQUksZUFBZSxHQUFHLFVBQVUsQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUFFLENBQUM7b0JBQ25ELENBQUMsQ0FBQyxJQUFJLENBQUMsZUFBZSxFQUFFLFVBQUEsQ0FBQzt3QkFDdkIsSUFBSSxLQUFLLEdBQVcsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDdEMsSUFBSSxDQUFDLEtBQUssQ0FBQyxZQUFZLEVBQUU7NEJBQ3ZCLEtBQUssQ0FBQyxZQUFZLEdBQUcsVUFBVSxDQUFDO3lCQUNqQztvQkFDSCxDQUFDLENBQUMsQ0FBQztvQkFDSCxxRUFBcUU7b0JBQ3JFLG1FQUFtRTtvQkFDbkUsMkNBQTJDO29CQUMzQyxJQUFJLGVBQWUsQ0FBQyxNQUFNLEdBQUcsU0FBUyxJQUFJLENBQUMsQ0FBQyxVQUFVLENBQUMsSUFBSSxJQUFJLEdBQUcsQ0FBQyxFQUFFO3dCQUNuRSxHQUFHLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxLQUFLLENBQUMsa0JBQWtCLENBQUMsT0FBTyxDQUFDO3FCQUM1RDtvQkFDRCx5RUFBeUU7b0JBQ3pFLElBQUksVUFBVSxDQUFDLElBQUksSUFBSSxHQUFHOzJCQUNyQixHQUFHLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQyxLQUFLLENBQUMsa0JBQWtCLENBQUMsT0FBTyxFQUFFO3dCQUNqRSxPQUFPO3FCQUNSO29CQUNELFNBQVMsQ0FBQyxPQUFPLENBQUMsVUFBVSxFQUFFLFVBQVUsQ0FBQyxDQUFDLENBQUMsbUJBQW1CO29CQUM5RCxTQUFTLENBQUMsT0FBTyxDQUFDLFVBQVUsRUFBRSxVQUFVLENBQUMsQ0FBQztvQkFDMUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxlQUFlLEVBQUUsVUFBQSxDQUFDO3dCQUN2QixJQUFJLEtBQUssR0FBWSxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUN2QyxVQUFVLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUM7d0JBQ3ZDLFVBQVUsQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDLFVBQVUsQ0FBQzt3QkFDekMsVUFBVSxDQUFDLFdBQVcsRUFBRSxDQUFDO3dCQUN6QixJQUFJLEtBQUssQ0FBQyxNQUFNLElBQUksSUFBSSxFQUFFOzRCQUN4QixVQUFVLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUM7Z0NBQ3BDLENBQUMsVUFBVSxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO3lCQUN6RDt3QkFDRCxJQUFJLEtBQUssQ0FBQyxVQUFVLElBQUksSUFBSSxFQUFFOzRCQUM1QixVQUFVLENBQUMsbUJBQW1CLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQztnQ0FDNUMsQ0FBQyxVQUFVLENBQUMsbUJBQW1CLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQzt5QkFDakU7d0JBRUQsb0RBQW9EO3dCQUNwRCxJQUFJLEtBQUssQ0FBQyxVQUFVLEVBQUU7NEJBQ3BCLFVBQVUsQ0FBQyxzQkFBc0IsQ0FBQyxVQUFVO2dDQUN4QyxDQUFDLFVBQVUsQ0FBQyxzQkFBc0IsQ0FBQyxVQUFVLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO3lCQUM3RDs2QkFBTTs0QkFDTCxVQUFVLENBQUMsc0JBQXNCLENBQUMsWUFBWTtnQ0FDMUMsQ0FBQyxVQUFVLENBQUMsc0JBQXNCLENBQUMsWUFBWSxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQzt5QkFDL0Q7d0JBRUQsd0RBQXdEO3dCQUN4RCxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxZQUFZLEVBQUUsVUFBQyxNQUFNOzRCQUNoQyxJQUFJLE1BQU0sQ0FBQyxVQUFVLEVBQUU7Z0NBQ3JCLFVBQVUsQ0FBQyxzQkFBc0IsQ0FBQyxVQUFVO29DQUN4QyxDQUFDLFVBQVUsQ0FBQyxzQkFBc0IsQ0FBQyxVQUFVLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDOzZCQUM3RDtpQ0FBTTtnQ0FDTCxVQUFVLENBQUMsc0JBQXNCLENBQUMsWUFBWTtvQ0FDMUMsQ0FBQyxVQUFVLENBQUMsc0JBQXNCLENBQUMsWUFBWSxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQzs2QkFDL0Q7d0JBQ0gsQ0FBQyxDQUFDLENBQUM7d0JBRUgsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsYUFBYSxFQUFFLFVBQUMsT0FBTzs0QkFDbEMsSUFBSSxPQUFPLENBQUMsVUFBVSxFQUFFO2dDQUN0QixVQUFVLENBQUMsc0JBQXNCLENBQUMsVUFBVTtvQ0FDeEMsQ0FBQyxVQUFVLENBQUMsc0JBQXNCLENBQUMsVUFBVSxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQzs2QkFDN0Q7aUNBQU07Z0NBQ0wsVUFBVSxDQUFDLHNCQUFzQixDQUFDLFlBQVk7b0NBQzFDLENBQUMsVUFBVSxDQUFDLHNCQUFzQixDQUFDLFlBQVksSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7NkJBQy9EO3dCQUNILENBQUMsQ0FBQyxDQUFDO3dCQUVILEtBQUssQ0FBQyxVQUFVLEdBQUcsVUFBVSxDQUFDO3dCQUM5QixXQUFXLENBQUMsQ0FBQyxDQUFDLEdBQUcsVUFBVSxDQUFDO3dCQUM1QixnRUFBZ0U7d0JBQ2hFLFNBQVMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQzFCLENBQUMsQ0FBQyxDQUFDO2dCQUNMLENBQUMsQ0FBQyxDQUFDO1lBQ0wsQ0FBQztZQUFBLENBQUM7WUFFRix1Q0FBdUM7WUFDdkMsc0JBQXNCLFNBQXFEO2dCQUV6RSxJQUFJLE1BQU0sR0FBb0MsRUFBRSxDQUFDO2dCQUNqRCxPQUFRLENBQUMsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLEtBQUssRUFBRSxFQUM5QixVQUFDLFFBQXlDLEVBQUUsQ0FBUztvQkFDdkQsSUFBSSxLQUFLLEdBQUcsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDOUIsSUFBSSxLQUFLLENBQUMsSUFBSSxLQUFLLFFBQUEsUUFBUSxDQUFDLElBQUksRUFBRTt3QkFDaEMsaUJBQWlCO3dCQUNqQixPQUFPLFFBQVEsQ0FBQztxQkFDakI7b0JBQ0QsSUFBSSxRQUFRLEdBQVksS0FBTSxDQUFDLEVBQUUsQ0FBQztvQkFDbEMsSUFBSSxRQUFRLEVBQUU7d0JBQ1osUUFBUSxDQUFDLFFBQVEsQ0FBQyxHQUFHLFFBQVEsQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFLENBQUM7d0JBQzlDLFFBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDO3FCQUNyQztvQkFDRCxPQUFPLFFBQVEsQ0FBQztnQkFDbEIsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDO1lBQ2IsQ0FBQztZQUVEOzs7Ozs7OztlQVFHO1lBQ0gsMENBQ0ksUUFBeUMsRUFDekMsU0FBcUQsRUFDckQsWUFBbUM7Z0JBRXJDLElBQUksVUFBVSxHQUF1QyxFQUFFLENBQUM7Z0JBQ3hELENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLFVBQVMsT0FBTyxFQUFFLFNBQWlCO29CQUNsRCxJQUFJLE9BQU8sQ0FBQyxNQUFNLElBQUksQ0FBQyxFQUFFO3dCQUFFLE9BQU87cUJBQUUsQ0FBQyxzQ0FBc0M7b0JBQzNFOzs7dUJBR0c7b0JBQ0gsSUFBSSxjQUFjLEdBQXlDLEVBQUUsQ0FBQztvQkFFOUQsbUVBQW1FO29CQUNuRSx5RUFBeUU7b0JBQ3pFLFFBQVE7b0JBQ1IsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsVUFBUyxJQUFZO3dCQUNuQyxJQUFJLE9BQU8sR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLEtBQUssR0FBRyxDQUFDO3dCQUNuRCxJQUFJLFFBQVEsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO3dCQUMvQixJQUFJLElBQUksR0FBRyxRQUFRLENBQUMsUUFBUSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQzt3QkFDekMsSUFBSSxNQUFNLEdBQUcsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsUUFBUSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7d0JBQzlELElBQUksT0FBTyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsZUFBZSxDQUFDLENBQUM7d0JBRTFDLElBQUksTUFBTSxDQUFDO3dCQUNYLElBQUksRUFBRSxDQUFDO3dCQUNQLElBQUksTUFBTSxHQUFHLEVBQUUsQ0FBQzt3QkFDaEIsSUFBSSxPQUFPLEVBQUUsRUFBVSw4Q0FBOEM7NEJBQ25FLE1BQU0sR0FBRyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxtQ0FBbUM7NEJBQ3hELEVBQUUsR0FBRyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhO3lCQUMvQjs2QkFBTSxFQUFHLHlEQUF5RDs0QkFDakUsTUFBTSxHQUFHLE9BQU8sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDOzRCQUMxRCxFQUFFLEdBQUcsQ0FBQyxDQUFDOzRCQUNQLE1BQU0sR0FBRyxPQUFPLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO3lCQUM3Qjt3QkFDRCxJQUFJLFVBQVUsR0FBRyxRQUFBLGlCQUFpQixDQUFDLE1BQU0sRUFBRSxNQUFNLEVBQUUsTUFBTSxDQUFDLENBQUM7d0JBQzNELGNBQWMsQ0FBQyxVQUFVLENBQUMsR0FBRyxjQUFjLENBQUMsVUFBVSxDQUFDLElBQUksRUFBRSxDQUFDO3dCQUM5RCxJQUFJLFVBQVUsR0FBRyxRQUFBLGdCQUFnQixDQUM3QixNQUFNLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRSxJQUFJLEVBQUUsWUFBWSxDQUFDLENBQUM7d0JBQ3JELGNBQWMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7b0JBQzlDLENBQUMsQ0FBQyxDQUFDO29CQUVILHlFQUF5RTtvQkFDekUseUVBQXlFO29CQUN6RSxDQUFDLENBQUMsSUFBSSxDQUFDLGNBQWMsRUFBRSxVQUFTLGVBQTZCLEVBQUUsVUFBVTt3QkFDdkUsSUFBSSxlQUFlLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTs0QkFDOUIsT0FBTzt5QkFDUjt3QkFDRCxlQUFlLENBQUMsSUFBSSxDQUFDLFVBQVMsQ0FBQyxFQUFFLENBQUM7NEJBQ2hDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDO3dCQUN6QyxDQUFDLENBQUMsQ0FBQzt3QkFFSCx3RUFBd0U7d0JBQ3hFLDBEQUEwRDt3QkFDMUQsSUFBSSxXQUFXLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDdkMsS0FBSyxJQUFJLEtBQUssR0FBRyxDQUFDLEVBQUUsS0FBSyxHQUFHLGVBQWUsQ0FBQyxNQUFNLEVBQUUsS0FBSyxFQUFFLEVBQUU7NEJBQzNELElBQUksUUFBUSxHQUFHLGVBQWUsQ0FBQyxLQUFLLENBQUMsQ0FBQzs0QkFDdEMsSUFBSSxRQUFRLENBQUMsU0FBUyxLQUFLLFdBQVcsQ0FBQyxXQUFXLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLFNBQVM7a0NBQ2xFLENBQUMsRUFBRTtnQ0FDUCxXQUFXLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO2dDQUMzQixTQUFTOzZCQUNWOzRCQUNELGVBQWUsQ0FDWCxXQUFXLEVBQUUsVUFBVSxFQUFFLENBQUMsU0FBUyxFQUFFLFNBQVMsRUFBRSxZQUFZLENBQUMsQ0FBQzs0QkFDbEUsV0FBVyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUM7eUJBQzFCO3dCQUNELGVBQWUsQ0FDWCxXQUFXLEVBQUUsVUFBVSxFQUFFLENBQUMsU0FBUyxFQUFFLFNBQVMsRUFBRSxZQUFZLENBQUMsQ0FBQztvQkFDcEUsQ0FBQyxDQUFDLENBQUM7Z0JBQ0wsQ0FBQyxDQUFDLENBQUM7Z0JBQ0gsT0FBTyxVQUFVLENBQUM7WUFDcEIsQ0FBQztZQUVEOzs7Ozs7OztlQVFHO1lBQ0gsd0NBQ0ksUUFBeUMsRUFDekMsU0FBcUQsRUFDckQsWUFBbUM7Z0JBRXJDLElBQUksVUFBVSxHQUF1QyxFQUFFLENBQUM7Z0JBQ3hELENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLFVBQVMsT0FBTyxFQUFFLFNBQWlCO29CQUNsRCxJQUFJLE9BQU8sQ0FBQyxNQUFNLElBQUksQ0FBQyxFQUFFO3dCQUFFLE9BQU87cUJBQUUsQ0FBQyxzQ0FBc0M7b0JBRTNFOzt1QkFFRztvQkFDSCxJQUFJLFdBQVcsR0FBdUMsRUFBRSxDQUFDO29CQUN6RDs7Ozt1QkFJRztvQkFDSCxJQUFJLFdBQVcsR0FBa0MsRUFBRSxDQUFDO29CQUVwRCxtRUFBbUU7b0JBQ25FLHlFQUF5RTtvQkFDekUsUUFBUTtvQkFDUixDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxVQUFTLElBQVk7d0JBQ25DLElBQUksT0FBTyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsS0FBSyxHQUFHLENBQUM7d0JBQ25ELElBQUksUUFBUSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7d0JBQy9CLElBQUksSUFBSSxHQUFHLFFBQVEsQ0FBQyxRQUFRLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDO3dCQUN6QyxJQUFJLE1BQU0sR0FBRyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxRQUFRLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQzt3QkFFOUQsSUFBTSxRQUFRLEdBQUcsUUFBUSxDQUFDO3dCQUMxQixJQUFJLE9BQU8sR0FBRyxFQUFFLENBQUM7d0JBQ2pCLElBQUksV0FBVyxDQUFDO3dCQUNoQixJQUFJLE1BQU0sQ0FBQzt3QkFDWCxJQUFJLEVBQUUsQ0FBQzt3QkFDUCxJQUFJLE1BQU0sQ0FBQzt3QkFDWCxJQUFJLFVBQVUsQ0FBQzt3QkFDZixJQUFJLE9BQU8sR0FBRyxDQUFDLENBQUM7d0JBQ2hCLGlFQUFpRTt3QkFDakUsdURBQXVEO3dCQUN2RCxPQUFPLFdBQVcsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFOzRCQUN4QyxFQUFFLE9BQU8sQ0FBQzs0QkFDVixNQUFNLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsV0FBVyxDQUFDLEtBQUssQ0FBQyxDQUFDOzRCQUMxQyxFQUFFLEdBQUcsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDOzRCQUNwQixNQUFNLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsS0FBSyxHQUFHLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQzs0QkFDL0QsVUFBVSxHQUFHLFFBQUEsaUJBQWlCLENBQUMsTUFBTSxFQUFFLE1BQU0sRUFBRSxNQUFNLENBQUMsQ0FBQzs0QkFDdkQsV0FBVyxDQUFDLFVBQVUsQ0FBQyxHQUFHLFdBQVcsQ0FBQyxVQUFVLENBQUMsQ0FBQzs0QkFDbEQsSUFBSSxDQUFDLFdBQVcsQ0FBQyxVQUFVLENBQUMsRUFBRTtnQ0FDNUIsV0FBVyxDQUFDLFVBQVUsQ0FBQyxHQUFHLFFBQUEsZ0JBQWdCLENBQ3hDLE1BQU0sRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFLElBQUksRUFBRSxZQUFZLENBQUMsQ0FBQzs2QkFDcEQ7NEJBQ0QsV0FBVyxDQUFDLFVBQVUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUM7NEJBQ3JDLFdBQVcsQ0FBQyxJQUFJLENBQUMsR0FBRyxXQUFXLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDOzRCQUM1QyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsVUFBVSxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUM7eUJBQzFDO3dCQUNELElBQUksT0FBTyxHQUFHLENBQUMsRUFBRTs0QkFDZixNQUFNLEdBQUcsT0FBTyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7NEJBQzFELEVBQUUsR0FBRyxDQUFDLENBQUM7NEJBQ1AsTUFBTSxHQUFHLE9BQU8sQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7NEJBQzVCLFVBQVUsR0FBRyxRQUFBLGlCQUFpQixDQUFDLE1BQU0sRUFBRSxNQUFNLEVBQUUsTUFBTSxDQUFDLENBQUM7NEJBQ3ZELFdBQVcsQ0FBQyxVQUFVLENBQUMsR0FBRyxXQUFXLENBQUMsVUFBVSxDQUFDLENBQUM7NEJBQ2xELElBQUksQ0FBQyxXQUFXLENBQUMsVUFBVSxDQUFDLEVBQUU7Z0NBQzVCLFdBQVcsQ0FBQyxVQUFVLENBQUMsR0FBRyxRQUFBLGdCQUFnQixDQUN4QyxNQUFNLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRSxJQUFJLEVBQUUsWUFBWSxDQUFDLENBQUM7NkJBQ3BEOzRCQUNELFdBQVcsQ0FBQyxVQUFVLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDOzRCQUNyQyxXQUFXLENBQUMsSUFBSSxDQUFDLEdBQUcsV0FBVyxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQzs0QkFDNUMsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLFVBQVUsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDO3lCQUMxQztvQkFDSCxDQUFDLENBQUMsQ0FBQztvQkFDSDs7O3VCQUdHO29CQUNILElBQUksY0FBYyxHQUF5QyxFQUFFLENBQUM7b0JBQzlELG1FQUFtRTtvQkFDbkUseUNBQXlDO29CQUN6QyxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBRSxVQUFVLGlCQUFpQixFQUFFLElBQUk7d0JBQ25ELGlCQUFpQixDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsRUFBRSxDQUFDOzRCQUNqQyxPQUFPLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUM7d0JBQzNFLENBQUMsQ0FBQyxDQUFDO3dCQUNILElBQUksVUFBVSxHQUFHLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUN6QyxJQUFJLEVBQUUsR0FBRyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDakMsY0FBYyxDQUFDLFVBQVUsQ0FBQyxHQUFHLGNBQWMsQ0FBQyxVQUFVLENBQUMsSUFBSSxFQUFFLENBQUM7d0JBQzlELElBQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7d0JBQ2pDLElBQU0sSUFBSSxHQUFHLFFBQVEsQ0FBQyxRQUFRLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDO3dCQUMzQyxJQUFNLE1BQU0sR0FBRyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxRQUFRLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQzt3QkFDaEUsSUFBSSxVQUFVLEdBQUcsUUFBQSxnQkFBZ0IsQ0FDN0IsV0FBVyxDQUFDLFVBQVUsQ0FBQyxDQUFDLE1BQU0sRUFDOUIsV0FBVyxDQUFDLFVBQVUsQ0FBQyxDQUFDLE1BQU0sRUFDOUIsTUFBTSxFQUNOLENBQUMsRUFBRSxFQUNILElBQUksRUFDSixZQUFZLENBQUMsQ0FBQzt3QkFDbEIsY0FBYyxDQUFDLFVBQVUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztvQkFDOUMsQ0FBQyxDQUFDLENBQUM7b0JBRUgseUVBQXlFO29CQUN6RSx5RUFBeUU7b0JBQ3pFLENBQUMsQ0FBQyxJQUFJLENBQUMsY0FBYyxFQUFFLFVBQVMsZUFBNkIsRUFBRSxVQUFVO3dCQUN2RSxJQUFJLGVBQWUsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFOzRCQUM5QixPQUFPO3lCQUNSO3dCQUNELGVBQWUsQ0FBQyxJQUFJLENBQUMsVUFBUyxDQUFDLEVBQUUsQ0FBQzs0QkFDaEMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUM7d0JBQ3pDLENBQUMsQ0FBQyxDQUFDO3dCQUVILHdFQUF3RTt3QkFDeEUsMERBQTBEO3dCQUMxRCxJQUFJLFdBQVcsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUN2QyxLQUFLLElBQUksS0FBSyxHQUFHLENBQUMsRUFBRSxLQUFLLEdBQUcsZUFBZSxDQUFDLE1BQU0sRUFBRSxLQUFLLEVBQUUsRUFBRTs0QkFDM0QsSUFBSSxRQUFRLEdBQUcsZUFBZSxDQUFDLEtBQUssQ0FBQyxDQUFDOzRCQUN0QyxJQUFJLFFBQVEsQ0FBQyxTQUFTLEtBQUssV0FBVyxDQUFDLFdBQVcsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsU0FBUztrQ0FDbEUsQ0FBQyxFQUFFO2dDQUNQLFdBQVcsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7Z0NBQzNCLFNBQVM7NkJBQ1Y7NEJBQ0QsZUFBZSxDQUNYLFdBQVcsRUFBRSxVQUFVLEVBQUUsQ0FBQyxTQUFTLEVBQUUsU0FBUyxFQUFFLFlBQVksQ0FBQyxDQUFDOzRCQUNsRSxXQUFXLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQzt5QkFDMUI7d0JBQ0QsZUFBZSxDQUNYLFdBQVcsRUFBRSxVQUFVLEVBQUUsQ0FBQyxTQUFTLEVBQUUsU0FBUyxFQUFFLFlBQVksQ0FBQyxDQUFDO29CQUNwRSxDQUFDLENBQUMsQ0FBQztnQkFDTCxDQUFDLENBQUMsQ0FBQztnQkFDSCxPQUFPLFVBQVUsQ0FBQztZQUNwQixDQUFDO1lBRUQ7Ozs7Ozs7OztlQVNHO1lBQ0gseUJBQXlCLFdBQXlCLEVBQzlDLFVBQThDLEVBQzlDLFNBQWlCLEVBQ2pCLFNBQXFELEVBQ3JELFlBQW1DO2dCQUNyQyxJQUFJLFdBQVcsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO29CQUMxQixJQUFJLGFBQWEsR0FBRyxRQUFBLGlCQUFpQixDQUNuQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxFQUFFLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLEVBQzVDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLEVBQUUsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsRUFDL0MsV0FBVyxDQUFDLFdBQVcsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUM7b0JBQ2pELElBQUksZUFBYSxHQUFHLFFBQUEsZ0JBQWdCLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sRUFDeEQsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBRSxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFDdkQsYUFBYSxFQUFFLFlBQVksQ0FBQyxDQUFDO29CQUMvQixDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBRSxVQUFTLElBQUk7d0JBQy9CLGVBQWEsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQzt3QkFDdkMsZUFBYSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxTQUFTLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO29CQUN4RSxDQUFDLENBQUMsQ0FBQztvQkFDSCxVQUFVLENBQUMsYUFBYSxDQUFDLEdBQUcsZUFBYSxDQUFDO2lCQUMzQztZQUNILENBQUM7UUFFRCxDQUFDLEVBbG5DZSxTQUFTLEdBQVQsaUJBQVMsS0FBVCxpQkFBUyxRQWtuQ3hCO0lBQUQsQ0FBQyxFQWxuQ1MsS0FBSyxHQUFMLFFBQUssS0FBTCxRQUFLLFFBa25DZDtBQUFELENBQUMsRUFsbkNNLEVBQUUsS0FBRixFQUFFLFFBa25DUixDQUFDLGtDQUFrQyIsInNvdXJjZXNDb250ZW50IjpbIi8qIENvcHlyaWdodCAyMDE1IFRoZSBUZW5zb3JGbG93IEF1dGhvcnMuIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG5cbkxpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSAnTGljZW5zZScpO1xueW91IG1heSBub3QgdXNlIHRoaXMgZmlsZSBleGNlcHQgaW4gY29tcGxpYW5jZSB3aXRoIHRoZSBMaWNlbnNlLlxuWW91IG1heSBvYnRhaW4gYSBjb3B5IG9mIHRoZSBMaWNlbnNlIGF0XG5cbiAgICBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcblxuVW5sZXNzIHJlcXVpcmVkIGJ5IGFwcGxpY2FibGUgbGF3IG9yIGFncmVlZCB0byBpbiB3cml0aW5nLCBzb2Z0d2FyZVxuZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIExpY2Vuc2UgaXMgZGlzdHJpYnV0ZWQgb24gYW4gJ0FTIElTJyBCQVNJUyxcbldJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWSBLSU5ELCBlaXRoZXIgZXhwcmVzcyBvciBpbXBsaWVkLlxuU2VlIHRoZSBMaWNlbnNlIGZvciB0aGUgc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nIHBlcm1pc3Npb25zIGFuZFxubGltaXRhdGlvbnMgdW5kZXIgdGhlIExpY2Vuc2UuXG49PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0qL1xuLyoqXG4gKiBQYWNrYWdlIGZvciB0aGUgR3JhcGggSGllcmFyY2h5IGZvciBUZW5zb3JGbG93IGdyYXBoLlxuICovXG5tb2R1bGUgdGYuZ3JhcGguaGllcmFyY2h5IHtcblxuLyoqXG4gKiBDbGFzcyB1c2VkIGFzIG91dHB1dCBmb3IgZ2V0UHJlZGVjZXNzb3JzIGFuZCBnZXRTdWNjZXNzb3JzIG1ldGhvZHNcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBFZGdlcyB7XG4gIGNvbnRyb2w6IE1ldGFlZGdlW107XG4gIHJlZ3VsYXI6IE1ldGFlZGdlW107XG59XG5cbi8qKlxuICogQ2xhc3MgdXNlZCB0byBzdG9yZSBkYXRhIG9uIGxpYnJhcnkgZnVuY3Rpb25zLiBUaGlzIHNwZWNpZmljYWxseSBzdG9yZXMgZGF0YVxuICogb24gdGhlIGxpYnJhcnkgZnVuY3Rpb24sIG5vdCBpbmRpdmlkdWFsIGNhbGxzIHRvIHRob3NlIGZ1bmN0aW9ucy5cbiAqL1xuZXhwb3J0IGludGVyZmFjZSBMaWJyYXJ5RnVuY3Rpb25EYXRhIHtcbiAgLy8gVGhlIG1ldGFub2RlIHJlcHJlc2VudGluZyB0aGlzIGZ1bmN0aW9uIGluIHRoZSBsaWJyYXJ5IHNjZW5lIGdyb3VwLlxuICBub2RlOiBNZXRhbm9kZTtcblxuICAvLyBBIGxpc3Qgb2Ygbm9kZXMgdGhhdCByZXByZXNlbnQgY2FsbHMgdG8gdGhpcyBsaWJyYXJ5IGZ1bmN0aW9uLlxuICB1c2FnZXM6IE5vZGVbXTtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBIaWVyYXJjaHkge1xuICByb290OiBNZXRhbm9kZTtcbiAgbGlicmFyeUZ1bmN0aW9uczoge1trZXk6IHN0cmluZ106IExpYnJhcnlGdW5jdGlvbkRhdGF9O1xuICB0ZW1wbGF0ZXM6IHtbdGVtcGxhdGVJZDogc3RyaW5nXTogc3RyaW5nW119O1xuICAvKiogTGlzdCBvZiBhbGwgZGV2aWNlIG5hbWVzICovXG4gIGRldmljZXM6IHN0cmluZ1tdO1xuICAvKiogTGlzdCBvZiBhbGwgWExBIGNsdXN0ZXIgbmFtZXMgKi9cbiAgeGxhQ2x1c3RlcnM6IHN0cmluZ1tdO1xuICAvKiogVHJ1ZSBpZiBhdCBsZWFzdCBvbmUgdGVuc29yIGluIHRoZSBncmFwaCBoYXMgc2hhcGUgaW5mb3JtYXRpb24gKi9cbiAgaGFzU2hhcGVJbmZvOiBib29sZWFuO1xuICAvKiogVGhlIG1heGltdW0gc2l6ZSBhY3Jvc3MgYWxsIG1ldGEgZWRnZXMuIFVzZWQgZm9yIHNjYWxpbmcgdGhpY2tuZXNzLiAqL1xuICBtYXhNZXRhRWRnZVNpemU6IG51bWJlcjtcbiAgZ3JhcGhPcHRpb25zOiBncmFwaGxpYi5HcmFwaE9wdGlvbnM7XG4gIGdldE5vZGVNYXAoKToge1tub2RlTmFtZTogc3RyaW5nXTogR3JvdXBOb2RlfE9wTm9kZX07XG4gIG5vZGUobmFtZTogc3RyaW5nKTogR3JvdXBOb2RlfE9wTm9kZTtcbiAgc2V0Tm9kZShuYW1lOiBzdHJpbmcsIG5vZGU6IEdyb3VwTm9kZXxPcE5vZGUpOiB2b2lkO1xuICBnZXRCcmlkZ2VncmFwaChub2RlTmFtZTogc3RyaW5nKTogZ3JhcGhsaWIuR3JhcGg8R3JvdXBOb2RlfE9wTm9kZSwgTWV0YWVkZ2U+O1xuICBnZXRQcmVkZWNlc3NvcnMobm9kZU5hbWU6IHN0cmluZyk6IEVkZ2VzO1xuICBnZXRTdWNjZXNzb3JzKG5vZGVOYW1lOiBzdHJpbmcpOiBFZGdlcztcbiAgZ2V0VG9wb2xvZ2ljYWxPcmRlcmluZyhub2RlTmFtZTogc3RyaW5nKTogeyBbY2hpbGROYW1lOiBzdHJpbmddOiBudW1iZXIgfTtcbiAgZ2V0VGVtcGxhdGVJbmRleCgpOiAoc3RyaW5nKSA9PiBudW1iZXI7XG59XG5cbi8qKlxuICogQ2xhc3MgZm9yIHRoZSBHcmFwaCBIaWVyYXJjaHkgZm9yIFRlbnNvckZsb3cgZ3JhcGguXG4gKi9cbmNsYXNzIEhpZXJhcmNoeUltcGwgaW1wbGVtZW50cyBIaWVyYXJjaHkge1xuICByb290OiBNZXRhbm9kZTtcbiAgbGlicmFyeUZ1bmN0aW9uczoge1trZXk6IHN0cmluZ106IExpYnJhcnlGdW5jdGlvbkRhdGF9O1xuICB0ZW1wbGF0ZXM6IHtbdGVtcGxhdGVJZDogc3RyaW5nXTogc3RyaW5nW119O1xuICBwcml2YXRlIGluZGV4OiB7W25vZGVOYW1lOiBzdHJpbmddOiBHcm91cE5vZGV8T3BOb2RlfTtcbiAgZGV2aWNlczogc3RyaW5nW107XG4gIHhsYUNsdXN0ZXJzOiBzdHJpbmdbXTtcbiAgaGFzU2hhcGVJbmZvID0gZmFsc2U7XG4gIG1heE1ldGFFZGdlU2l6ZSA9IDE7XG4gIG9yZGVyaW5nczogeyBbbm9kZU5hbWU6IHN0cmluZ106IHsgW2NoaWxkTmFtZTogc3RyaW5nXTogbnVtYmVyIH0gfTtcbiAgZ3JhcGhPcHRpb25zOiBncmFwaGxpYi5HcmFwaE9wdGlvbnM7XG5cbiAgLyoqXG4gICAqIENvbnN0cnVjdHMgYSBoaWVyYXJjaHkuXG4gICAqIEBwYXJhbSBncmFwaE9wdGlvbnMgT3B0aW9ucyBwYXNzZWQgdG8gZGFncmUgZm9yIGNyZWF0aW5nIHRoZSBncmFwaC4gTm90ZVxuICAgKiAgIHRoYXQgdGhlIGBjb21wb3VuZGAgYXJndW1lbnQgd2lsbCBiZSBvdmVycmlkZW4gdG8gdHJ1ZS5cbiAgICovXG4gIGNvbnN0cnVjdG9yKGdyYXBoT3B0aW9uczogZ3JhcGhsaWIuR3JhcGhPcHRpb25zKSB7XG4gICAgdGhpcy5ncmFwaE9wdGlvbnMgPSBncmFwaE9wdGlvbnMgfHwge307XG4gICAgdGhpcy5ncmFwaE9wdGlvbnMuY29tcG91bmQgPSB0cnVlO1xuICAgIHRoaXMucm9vdCA9IGNyZWF0ZU1ldGFub2RlKFJPT1RfTkFNRSwgdGhpcy5ncmFwaE9wdGlvbnMpO1xuICAgIHRoaXMubGlicmFyeUZ1bmN0aW9ucyA9IHt9O1xuICAgIHRoaXMudGVtcGxhdGVzID0gbnVsbDtcbiAgICB0aGlzLmRldmljZXMgPSBudWxsO1xuICAgIHRoaXMueGxhQ2x1c3RlcnMgPSBudWxsO1xuICAgIC8qKlxuICAgICAqIEB0eXBlIHtPYmplY3R9IERpY3Rpb25hcnkgb2JqZWN0IHRoYXQgbWFwcyBub2RlIG5hbWUgdG8gdGhlIG5vZGVcbiAgICAgKiAoY291bGQgYmUgb3Atbm9kZSwgbWV0YW5vZGUsIG9yIHNlcmllcy1ub2RlKVxuICAgICAqL1xuICAgIHRoaXMuaW5kZXggPSB7fTtcbiAgICB0aGlzLmluZGV4W1JPT1RfTkFNRV0gPSB0aGlzLnJvb3Q7XG4gICAgdGhpcy5vcmRlcmluZ3MgPSB7fTtcbiAgfVxuXG4gIGdldE5vZGVNYXAoKToge1tub2RlTmFtZTogc3RyaW5nXTogR3JvdXBOb2RlfE9wTm9kZX0ge1xuICAgIHJldHVybiB0aGlzLmluZGV4O1xuICB9XG5cbiAgbm9kZShuYW1lOiBzdHJpbmcpOiBHcm91cE5vZGV8T3BOb2RlIHtcbiAgICByZXR1cm4gdGhpcy5pbmRleFtuYW1lXTtcbiAgfVxuXG4gIHNldE5vZGUobmFtZTogc3RyaW5nLCBub2RlOiBHcm91cE5vZGV8T3BOb2RlKTogdm9pZCB7XG4gICAgdGhpcy5pbmRleFtuYW1lXSA9IG5vZGU7XG4gIH1cblxuICAvKipcbiAgICogR2l2ZW4gdGhlIG5hbWUgb2YgYSBub2RlIGluIHRoaXMgaGllcmFyY2h5LCBnZXQgaXRzIGJyaWRnZWdyYXBoLCBjcmVhdGluZ1xuICAgKiBpdCBvbiB0aGUgZmx5IGlmIG5lY2Vzc2FyeS4gSWYgdGhlIG5vZGUgaXMgbm90IGEgR3JvdXBOb2RlLCB0aGVuIHRoaXNcbiAgICogbWV0aG9kIHJldHVybnMgbnVsbC4gSWYgdGhlIHByb3ZpZGVkIG5hbWUgZG9lcyBub3QgbWFwIHRvIGEgbm9kZSBpbiB0aGVcbiAgICogaGllcmFyY2h5LCBhbiBlcnJvciB3aWxsIGJlIHRocm93bi5cbiAgICovXG4gIGdldEJyaWRnZWdyYXBoKG5vZGVOYW1lOiBzdHJpbmcpOiBncmFwaGxpYi5HcmFwaDxHcm91cE5vZGV8T3BOb2RlLCBNZXRhZWRnZT4ge1xuICAgIGxldCBub2RlID0gdGhpcy5pbmRleFtub2RlTmFtZV07XG4gICAgaWYgKCFub2RlKSB7XG4gICAgICB0aHJvdyBFcnJvcignQ291bGQgbm90IGZpbmQgbm9kZSBpbiBoaWVyYXJjaHk6ICcgKyBub2RlTmFtZSk7XG4gICAgfVxuICAgIGlmICghKCdtZXRhZ3JhcGgnIGluIG5vZGUpKSB7XG4gICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gICAgbGV0IGdyb3VwTm9kZSA9IDxHcm91cE5vZGU+IG5vZGU7XG4gICAgaWYgKGdyb3VwTm9kZS5icmlkZ2VncmFwaCkge1xuICAgICAgcmV0dXJuIGdyb3VwTm9kZS5icmlkZ2VncmFwaDtcbiAgICB9XG4gICAgbGV0IGJyaWRnZWdyYXBoID0gZ3JvdXBOb2RlLmJyaWRnZWdyYXBoID1cbiAgICAgICAgY3JlYXRlR3JhcGg8R3JvdXBOb2RlfE9wTm9kZSwgTWV0YWVkZ2U+KFxuICAgICAgICAgICAgJ0JSSURHRUdSQVBIJywgR3JhcGhUeXBlLkJSSURHRSwgdGhpcy5ncmFwaE9wdGlvbnMpO1xuICAgIGlmICghbm9kZS5wYXJlbnROb2RlIHx8ICEoJ21ldGFncmFwaCcgaW4gbm9kZS5wYXJlbnROb2RlKSkge1xuICAgICAgcmV0dXJuIGJyaWRnZWdyYXBoO1xuICAgIH1cblxuICAgIGxldCBwYXJlbnROb2RlID0gPEdyb3VwTm9kZT5ub2RlLnBhcmVudE5vZGU7XG4gICAgbGV0IHBhcmVudE1ldGFncmFwaCA9IHBhcmVudE5vZGUubWV0YWdyYXBoO1xuICAgIGxldCBwYXJlbnRCcmlkZ2VncmFwaCA9IHRoaXMuZ2V0QnJpZGdlZ3JhcGgocGFyZW50Tm9kZS5uYW1lKTtcblxuICAgIC8vIEZvciBlYWNoIG9mIHRoZSBwYXJlbnQgbm9kZSdzIHR3byBNZXRhZWRnZSBjb250YWluaW5nIGdyYXBocywgcHJvY2Vzc1xuICAgIC8vIGVhY2ggTWV0YWVkZ2UgaW52b2x2aW5nIHRoaXMgbm9kZS5cbiAgICBfLmVhY2goW3BhcmVudE1ldGFncmFwaCwgcGFyZW50QnJpZGdlZ3JhcGhdLCBwYXJlbnRHcmFwaCA9PiB7XG4gICAgICBwYXJlbnRHcmFwaC5lZGdlcygpXG4gICAgICAgIC5maWx0ZXIoZSA9PiBlLnYgPT09IG5vZGVOYW1lIHx8IGUudyA9PT0gbm9kZU5hbWUpXG4gICAgICAgIC5mb3JFYWNoKHBhcmVudEVkZ2VPYmogPT4ge1xuICAgICAgICAgIGxldCBpbmJvdW5kID0gcGFyZW50RWRnZU9iai53ID09PSBub2RlTmFtZTtcbiAgICAgICAgICBsZXQgcGFyZW50TWV0YWVkZ2UgPSBwYXJlbnRHcmFwaC5lZGdlKHBhcmVudEVkZ2VPYmopO1xuXG4gICAgICAgICAgLy8gVGhlIHBhcmVudCdzIE1ldGFlZGdlIHJlcHJlc2VudHMgc29tZSBudW1iZXIgb2YgdW5kZXJseWluZ1xuICAgICAgICAgIC8vIEJhc2VFZGdlcyBmcm9tIHRoZSBvcmlnaW5hbCBmdWxsIGdyYXBoLiBGb3IgZWFjaCBvZiB0aG9zZSwgd2UgbmVlZFxuICAgICAgICAgIC8vIHRvIGRldGVybWluZSB3aGljaCBpbW1lZGlhdGUgY2hpbGQgaXMgaW52b2x2ZWQgYW5kIG1ha2Ugc3VyZVxuICAgICAgICAgIC8vIHRoZXJlJ3MgYSBNZXRhZWRnZSBpbiB0aGUgYnJpZGdlZ3JhcGggdGhhdCBjb3ZlcnMgaXQuXG4gICAgICAgICAgXy5lYWNoKHBhcmVudE1ldGFlZGdlLmJhc2VFZGdlTGlzdCwgYmFzZUVkZ2UgPT4ge1xuXG4gICAgICAgICAgICAvLyBCYXNlZCBvbiB0aGUgZGlyZWN0aW9uLCBmaWd1cmUgb3V0IHdoaWNoIGlzIHRoZSBkZXNjZW5kYW50IG5vZGVcbiAgICAgICAgICAgIC8vIGFuZCB3aGljaCBpcyB0aGUgJ290aGVyJyBub2RlIChzaWJsaW5nIG9mIHBhcmVudCBvciBhbmNlc3RvcikuXG4gICAgICAgICAgICBsZXQgW2Rlc2NlbmRhbnROYW1lLCBvdGhlck5hbWVdID1cbiAgICAgICAgICAgICAgaW5ib3VuZCA/XG4gICAgICAgICAgICAgICAgW2Jhc2VFZGdlLncsIHBhcmVudEVkZ2VPYmoudl0gOlxuICAgICAgICAgICAgICAgIFtiYXNlRWRnZS52LCBwYXJlbnRFZGdlT2JqLnddO1xuXG4gICAgICAgICAgICAvLyBEZXRlcm1pbmUgdGhlIGltbWVkaWF0ZSBjaGlsZCBjb250YWluaW5nIHRoaXMgZGVzY2VuZGFudCBub2RlLlxuICAgICAgICAgICAgbGV0IGNoaWxkTmFtZSA9IHRoaXMuZ2V0Q2hpbGROYW1lKG5vZGVOYW1lLCBkZXNjZW5kYW50TmFtZSk7XG5cbiAgICAgICAgICAgIC8vIExvb2sgZm9yIGFuIGV4aXN0aW5nIE1ldGFlZGdlIGluIHRoZSBicmlkZ2VncmFwaCAob3IgY3JlYXRlIGFcbiAgICAgICAgICAgIC8vIG5ldyBvbmUpIHRoYXQgY292ZXJzIHRoZSByZWxhdGlvbnNoaXAgYmV0d2VlbiBjaGlsZCBhbmQgb3RoZXIuXG4gICAgICAgICAgICBsZXQgYnJpZGdlRWRnZU9iaiA9IDxncmFwaGxpYi5FZGdlT2JqZWN0PiB7XG4gICAgICAgICAgICAgIHY6IGluYm91bmQgPyBvdGhlck5hbWUgOiBjaGlsZE5hbWUsXG4gICAgICAgICAgICAgIHc6IGluYm91bmQgPyBjaGlsZE5hbWUgOiBvdGhlck5hbWUsXG4gICAgICAgICAgICB9O1xuICAgICAgICAgICAgbGV0IGJyaWRnZU1ldGFlZGdlID0gYnJpZGdlZ3JhcGguZWRnZShicmlkZ2VFZGdlT2JqKTtcbiAgICAgICAgICAgIGlmICghYnJpZGdlTWV0YWVkZ2UpIHtcbiAgICAgICAgICAgICAgYnJpZGdlTWV0YWVkZ2UgPSBjcmVhdGVNZXRhZWRnZShicmlkZ2VFZGdlT2JqLnYsIGJyaWRnZUVkZ2VPYmoudyk7XG4gICAgICAgICAgICAgIGJyaWRnZU1ldGFlZGdlLmluYm91bmQgPSBpbmJvdW5kO1xuICAgICAgICAgICAgICBicmlkZ2VncmFwaC5zZXRFZGdlKGJyaWRnZUVkZ2VPYmoudiwgYnJpZGdlRWRnZU9iai53LFxuICAgICAgICAgICAgICAgICAgYnJpZGdlTWV0YWVkZ2UpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAvLyBDb3B5IHRoZSBCYXNlRWRnZSBmcm9tIHRoZSBwYXJlbnQncyBNZXRhZWRnZSBpbnRvIHRoaXNcbiAgICAgICAgICAgIC8vIGJyaWRnZWdyYXBoIE1ldGFlZGdlLlxuICAgICAgICAgICAgYnJpZGdlTWV0YWVkZ2UuYWRkQmFzZUVkZ2UoYmFzZUVkZ2UsIHRoaXMpO1xuICAgICAgICAgIH0pO1xuICAgICAgICB9KTtcbiAgICB9KTtcblxuICAgIHJldHVybiBicmlkZ2VncmFwaDtcbiAgfVxuXG4gIC8qKlxuICAgKiBVdGlsaXR5IGZ1bmN0aW9uIGZvciBkZXRlcm1pbmluZyB0aGUgbmFtZSBvZiB0aGUgaW1tZWRpYXRlIGNoaWxkIHVuZGVyIGFcbiAgICogbm9kZSBmb3IgYSBnaXZlbiBkZXNjZW5kYW50IHBhdGguIElmIHRoZSBkZXNjZW5kYW50IGNvcnJlc3BvbmRzIHRvIG5vXG4gICAqIGltbWVkaWF0ZSBjaGlsZCwgYW4gZXJyb3IgaXMgdGhyb3duLlxuICAgKi9cbiAgZ2V0Q2hpbGROYW1lKG5vZGVOYW1lOiBzdHJpbmcsIGRlc2NlbmRhbnROYW1lOiBzdHJpbmcpOiBzdHJpbmcge1xuICAgIC8vIFdhbGsgdXAgdGhlIGhpZXJhcmNoeSBmcm9tIHRoZSBkZXNjZW5kYW50IHRvIGZpbmQgdGhlIGNoaWxkLlxuICAgIGxldCBjdXJyZW50Tm9kZTogTm9kZSA9IHRoaXMuaW5kZXhbZGVzY2VuZGFudE5hbWVdO1xuICAgIHdoaWxlIChjdXJyZW50Tm9kZSkge1xuICAgICAgaWYgKGN1cnJlbnROb2RlLnBhcmVudE5vZGUgJiYgY3VycmVudE5vZGUucGFyZW50Tm9kZS5uYW1lID09PSBub2RlTmFtZSkge1xuICAgICAgICByZXR1cm4gY3VycmVudE5vZGUubmFtZTtcbiAgICAgIH1cbiAgICAgIGN1cnJlbnROb2RlID0gY3VycmVudE5vZGUucGFyZW50Tm9kZTtcbiAgICB9XG4gICAgdGhyb3cgRXJyb3IoXG4gICAgICAgICdDb3VsZCBub3QgZmluZCBpbW1lZGlhdGUgY2hpbGQgZm9yIGRlc2NlbmRhbnQ6ICcgKyBkZXNjZW5kYW50TmFtZSk7XG4gIH07XG5cbiAgLyoqIEdpdmVuIHRoZSBuYW1lIG9mIGEgbm9kZSwgcmV0dXJuIGl0cyBpbmNvbWluZyBtZXRhZWRnZXMuICovXG4gIGdldFByZWRlY2Vzc29ycyhub2RlTmFtZTogc3RyaW5nKTogRWRnZXMge1xuICAgIGxldCBub2RlID0gdGhpcy5pbmRleFtub2RlTmFtZV07XG4gICAgaWYgKCFub2RlKSB7XG4gICAgICB0aHJvdyBFcnJvcignQ291bGQgbm90IGZpbmQgbm9kZSB3aXRoIG5hbWU6ICcgKyBub2RlTmFtZSk7XG4gICAgfVxuXG4gICAgbGV0IHByZWRlY2Vzc29ycyA9IHRoaXMuZ2V0T25lV2F5RWRnZXMobm9kZSwgdHJ1ZSk7XG4gICAgLy8gQWRkIGVtYmVkZGVkIHByZWRlY2Vzc29ycywgc3VjaCBhcyBjb25zdGFudHMuXG4gICAgaWYgKCFub2RlLmlzR3JvdXBOb2RlKSB7XG4gICAgICBfLmVhY2goKDxPcE5vZGU+bm9kZSkuaW5FbWJlZGRpbmdzLCBlbWJlZGRlZE5vZGUgPT4ge1xuICAgICAgICBfLmVhY2goKDxPcE5vZGU+bm9kZSkuaW5wdXRzLCBpbnB1dCA9PiB7XG4gICAgICAgICAgaWYgKGlucHV0Lm5hbWUgPT09IGVtYmVkZGVkTm9kZS5uYW1lKSB7XG4gICAgICAgICAgICAvLyBNYWtlIGEgbmV3IG1ldGFlZGdlIGhvbGRpbmcgdGhlIGVkZ2UgYmV0d2VlbiB0aGVcbiAgICAgICAgICAgIC8vIG5vZGUgYW5kIHRoZSBpbi1lbWJlZGRpbmcuXG4gICAgICAgICAgICBsZXQgbWV0YWVkZ2UgPSBuZXcgTWV0YWVkZ2VJbXBsKGVtYmVkZGVkTm9kZS5uYW1lLCBub2RlTmFtZSk7XG4gICAgICAgICAgICBtZXRhZWRnZS5hZGRCYXNlRWRnZShcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICBpc0NvbnRyb2xEZXBlbmRlbmN5OiBpbnB1dC5pc0NvbnRyb2xEZXBlbmRlbmN5LFxuICAgICAgICAgICAgICAgICAgb3V0cHV0VGVuc29yS2V5OiBpbnB1dC5vdXRwdXRUZW5zb3JLZXksXG4gICAgICAgICAgICAgICAgICBpc1JlZmVyZW5jZUVkZ2U6IGZhbHNlLFxuICAgICAgICAgICAgICAgICAgdjogZW1iZWRkZWROb2RlLm5hbWUsXG4gICAgICAgICAgICAgICAgICB3OiBub2RlTmFtZVxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgdGhpcyk7XG4gICAgICAgICAgICBwcmVkZWNlc3NvcnMucmVndWxhci5wdXNoKG1ldGFlZGdlKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgfSk7XG4gICAgfVxuICAgIHJldHVybiBwcmVkZWNlc3NvcnM7XG4gIH1cblxuICAvKipcbiAgICogR2l2ZW4gdGhlIG5hbWUgb2YgYSBub2RlLCByZXR1cm4gaXRzIG91dGdvaW5nIG1ldGFlZGdlcy5cbiAgICpcbiAgICogVGhpcyBpcyB0aGUgaW52ZXJzZSBvZiBnZXRQcmVkZWNlc3NvcnMoKS4gU2VlIHRoYXQgbWV0aG9kJ3MgZG9jdW1lbnRhdGlvblxuICAgKiBmb3IgYW4gaW4tZGVwdGggZXhhbXBsZS5cbiAgICovXG4gIGdldFN1Y2Nlc3NvcnMobm9kZU5hbWU6IHN0cmluZyk6IEVkZ2VzIHtcbiAgICBsZXQgbm9kZSA9IHRoaXMuaW5kZXhbbm9kZU5hbWVdO1xuICAgIGlmICghbm9kZSkge1xuICAgICAgdGhyb3cgRXJyb3IoJ0NvdWxkIG5vdCBmaW5kIG5vZGUgd2l0aCBuYW1lOiAnICsgbm9kZU5hbWUpO1xuICAgIH1cblxuICAgIGxldCBzdWNjZXNzb3JzID0gdGhpcy5nZXRPbmVXYXlFZGdlcyhub2RlLCBmYWxzZSk7XG5cbiAgICAvLyBBZGQgZW1iZWRkZWQgc3VjY2Vzc29ycywgc3VjaCBhcyBzdW1tYXJpZXMuXG4gICAgaWYgKCFub2RlLmlzR3JvdXBOb2RlKSB7XG4gICAgICBfLmVhY2goKDxPcE5vZGU+bm9kZSkub3V0RW1iZWRkaW5ncywgZW1iZWRkZWROb2RlID0+IHtcbiAgICAgICAgXy5lYWNoKGVtYmVkZGVkTm9kZS5pbnB1dHMsIGlucHV0ID0+IHtcbiAgICAgICAgICBpZiAoaW5wdXQubmFtZSA9PT0gbm9kZU5hbWUpIHtcbiAgICAgICAgICAgIC8vIE1ha2UgYSBuZXcgbWV0YWVkZ2UgaG9sZGluZyB0aGUgZWRnZSBiZXR3ZWVuIHRoZVxuICAgICAgICAgICAgLy8gbm9kZSBhbmQgdGhlIG91dC1lbWJlZGRpbmcuXG4gICAgICAgICAgICBsZXQgbWV0YWVkZ2UgPSBuZXcgTWV0YWVkZ2VJbXBsKG5vZGVOYW1lLCBlbWJlZGRlZE5vZGUubmFtZSk7XG4gICAgICAgICAgICBtZXRhZWRnZS5hZGRCYXNlRWRnZShcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICBpc0NvbnRyb2xEZXBlbmRlbmN5OiBpbnB1dC5pc0NvbnRyb2xEZXBlbmRlbmN5LFxuICAgICAgICAgICAgICAgICAgb3V0cHV0VGVuc29yS2V5OiBpbnB1dC5vdXRwdXRUZW5zb3JLZXksXG4gICAgICAgICAgICAgICAgICBpc1JlZmVyZW5jZUVkZ2U6IGZhbHNlLFxuICAgICAgICAgICAgICAgICAgdjogbm9kZU5hbWUsXG4gICAgICAgICAgICAgICAgICB3OiBlbWJlZGRlZE5vZGUubmFtZVxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgdGhpcyk7XG4gICAgICAgICAgICBzdWNjZXNzb3JzLnJlZ3VsYXIucHVzaChtZXRhZWRnZSk7XG4gICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgIH0pO1xuICAgIH1cbiAgICByZXR1cm4gc3VjY2Vzc29ycztcbiAgfVxuXG4gIC8qKiBIZWxwZXIgbWV0aG9kIGZvciBnZXRQcmVkZWNlc3NvcnMgYW5kIGdldFN1Y2Nlc3NvcnMgKi9cbiAgZ2V0T25lV2F5RWRnZXMobm9kZTogR3JvdXBOb2RlfE9wTm9kZSwgaW5FZGdlczogYm9vbGVhbikge1xuICAgIGxldCBlZGdlczogRWRnZXMgPSB7Y29udHJvbDogW10sIHJlZ3VsYXI6IFtdfTtcbiAgICAvLyBBIG5vZGUgd2l0aCBubyBwYXJlbnQgY2Fubm90IGhhdmUgYW55IGVkZ2VzLlxuICAgIGlmICghbm9kZS5wYXJlbnROb2RlIHx8ICFub2RlLnBhcmVudE5vZGUuaXNHcm91cE5vZGUpIHtcbiAgICAgIHJldHVybiBlZGdlcztcbiAgICB9XG4gICAgbGV0IHBhcmVudE5vZGUgPSA8R3JvdXBOb2RlPiBub2RlLnBhcmVudE5vZGU7XG4gICAgbGV0IG1ldGFncmFwaCA9IHBhcmVudE5vZGUubWV0YWdyYXBoO1xuICAgIGxldCBicmlkZ2VncmFwaCA9IHRoaXMuZ2V0QnJpZGdlZ3JhcGgocGFyZW50Tm9kZS5uYW1lKTtcbiAgICBmaW5kRWRnZVRhcmdldHNJbkdyYXBoKG1ldGFncmFwaCwgbm9kZSwgaW5FZGdlcywgZWRnZXMpO1xuICAgIGZpbmRFZGdlVGFyZ2V0c0luR3JhcGgoYnJpZGdlZ3JhcGgsIG5vZGUsIGluRWRnZXMsIGVkZ2VzKTtcbiAgICByZXR1cm4gZWRnZXM7XG4gIH1cblxuICAvKipcbiAgICogRm9yIGEgZ2l2ZW4gR3JvdXBOb2RlLCBnZXQgb3IgY2FsY3VsYXRlIGFuIG9iamVjdCB3aGljaCBkZXNjcmliZXMgYVxuICAgKiB0b3BvbG9naWNhbCBvcmRlcmluZyBvZiBjaGlsZCBub2RlcyB3aXRoaW4gdGhhdCBHcm91cE5vZGUncyBtZXRhZ3JhcGguXG4gICAqXG4gICAqIFRoaXMgb3JkZXJpbmcgaXMgdXNlZCB3aGVuIHJlbmRlcmluZyBicmlkZ2UgY29udHJvbCBlZGdlcyB3aGljaCBhcmVcbiAgICogc29tZXRpbWVzIGJhY2t3YXJkcyByZWxhdGl2ZSB0byB0aGUgZGF0YWZsb3cuXG4gICAqXG4gICAqIEZvciBleGFtcGxlLCBzYXkgd2UgaGF2ZSBhIGdyYXBoIHdpdGggdHdvIGVkZ2VzIEEtPkIgYW5kIEEtPkMsIGFuZCB3ZSdyZVxuICAgKiBpbnRlcmVzdGVkIGluIHRoZSBvcmRlcmluZyB1bmRlciBST09ULiBJbiB0aGlzIGNhc2UsIGFueSBvZiB0aGUgZm9sbG93aW5nXG4gICAqIHdvdWxkIGJlIGxlZ2l0aW1hdGUgcmV0dXJuIHZhbHVlczpcbiAgICpcbiAgICogIC0geyAnQSc6IDAsICdCJzogMSwgJ0MnOiAyIH0gLS0gbW9zdCBsaWtlbHlcbiAgICogIC0geyAnQSc6IDAsICdCJzogMiwgJ0MnOiAxIH0gLS0gbGVzcyBsaWtlbHlcbiAgICogIC0geyAnQSc6IDEyLCAnQic6IDEwMCwgJ0MnOiA5OSB9IC0tIHVubGlrZWx5LCBidXQgc3RpbGwgT0tcbiAgICpcbiAgICogVGhlIGFsZ29yaXRobSBkb2VzIG5vdCBndWFyYW50ZWUgdGhhdCBhbGwgbnVtYmVycyBmcm9tIDAtTiAod2hlcmUgTiBpc1xuICAgKiB0aGUgbnVtYmVyIG9mIG5vZGVzKSBhcHBlYXIgZXhhY3RseSBvbmNlLiBSYXRoZXIgaXQgZ3VhcmFudGVlcyB0aGF0IGlmXG4gICAqIHRoZXJlIGlzIGEgcGF0aCBiZXR3ZWVuIHR3byBub2RlcywgdGhlIGVhcmxpZXIgb25lIHdpbGwgaGF2ZSBhIGxvd2VyXG4gICAqIG51bWJlciBpbiB0aGUgb3JkZXJpbmcgaGFzaC5cbiAgICpcbiAgICogV2hlbiBnZW5lcmF0aW5nIHRoZSBvcmRlcmluZywgd2UgaWdub3JlIGNvbnRyb2wgTWV0YWVkZ2VzICh0aG9zZSB3aGljaFxuICAgKiByZXByZXNlbnQgb25seSBCYXNlRWRnZXMgdGhhdCBoYXZlIGlzQ29udHJvbERlcGVuZGVuY3kgc2V0IHRvIHRydWUpLlxuICAgKlxuICAgKiBJZiB0aGVyZSBpcyBubyBub2RlIHdpdGggdGhlIHNwZWNpZmllZCBuYW1lLCBhbiBlcnJvciBpcyB0aHJvd24uIElmIHRoZVxuICAgKiBub2RlIHdpdGggdGhlIHNwZWNpZmllZCBuYW1lIGlzIG5vdCBhIGdyb3VwIG5vZGUsIG51bGwgaXMgcmV0dXJuZWQuXG4gICAqL1xuICBnZXRUb3BvbG9naWNhbE9yZGVyaW5nKG5vZGVOYW1lOiBzdHJpbmcpOiB7IFtjaGlsZE5hbWU6IHN0cmluZ106IG51bWJlciB9IHtcbiAgICBsZXQgbm9kZSA9IHRoaXMuaW5kZXhbbm9kZU5hbWVdO1xuICAgIGlmICghbm9kZSkge1xuICAgICAgdGhyb3cgRXJyb3IoJ0NvdWxkIG5vdCBmaW5kIG5vZGUgd2l0aCBuYW1lOiAnICsgbm9kZU5hbWUpO1xuICAgIH1cbiAgICBpZiAoIW5vZGUuaXNHcm91cE5vZGUpIHtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICBpZiAobm9kZU5hbWUgaW4gdGhpcy5vcmRlcmluZ3MpIHtcbiAgICAgIHJldHVybiB0aGlzLm9yZGVyaW5nc1tub2RlTmFtZV07XG4gICAgfVxuXG4gICAgLy8gTWFwcGluZyBvZiBhIGNoaWxkIG5vZGUgbmFtZXMgdG8gbGlzdHMgb2YgdGhlaXIgc3VjY2Vzc29ycy5cbiAgICBsZXQgc3VjY2Vzc29yczogeyBbY2hpbGROYW1lOiBzdHJpbmddOiBzdHJpbmdbXSB9ID0ge307XG5cbiAgICAvLyBTZXQgb2Ygbm9kZSBuYW1lcyB3aGljaCBoYXZlIGFwcGVhcmVkIGFzIGEgZGVzdGluYXRpb24uXG4gICAgbGV0IGRlc3RpbmF0aW9uczogeyBbY2hpbGROYW1lOiBzdHJpbmddOiBib29sZWFuIH0gPSB7fTtcblxuICAgIGxldCBtZXRhZ3JhcGggPSAoPEdyb3VwTm9kZT4gbm9kZSkubWV0YWdyYXBoO1xuICAgIF8uZWFjaChtZXRhZ3JhcGguZWRnZXMoKSwgKGU6IGdyYXBobGliLkVkZ2VPYmplY3QpID0+IHtcbiAgICAgIGlmICghbWV0YWdyYXBoLmVkZ2UoZSkubnVtUmVndWxhckVkZ2VzKSB7XG4gICAgICAgIHJldHVybjsgLy8gU2tpcCBjb250cm9sIGVkZ2VzLlxuICAgICAgfVxuXG4gICAgICAvLyBLZWVwIHRyYWNrIG9mIHN1Y2Nlc3NvcnMgYW5kIGRlc3RpbmF0aW9ucy5cbiAgICAgIGlmICghKGUudiBpbiBzdWNjZXNzb3JzKSkge1xuICAgICAgICBzdWNjZXNzb3JzW2Uudl0gPSBbXTtcbiAgICAgIH1cbiAgICAgIHN1Y2Nlc3NvcnNbZS52XS5wdXNoKGUudyk7XG4gICAgICBkZXN0aW5hdGlvbnNbZS53XSA9IHRydWU7XG4gICAgfSk7XG5cbiAgICAvLyBTZWVkIHRoZSBxdWV1ZSB3aXRoIHRydWUgc291cmNlcyAodGhvc2UgdGhhdCBhcmUgbm90IGRlc3RpbmF0aW9ucykuXG4gICAgbGV0IHF1ZXVlOiBzdHJpbmdbXSA9XG4gICAgICBfLmRpZmZlcmVuY2UoXy5rZXlzKHN1Y2Nlc3NvcnMpLCBfLmtleXMoZGVzdGluYXRpb25zKSk7XG5cbiAgICAvLyBQcm9kdWNlIGFuIG9yZGVyaW5nIGJ5IHRyYXZlcnNpbmcgdGhlIGdyYXBoIGJyZWFkdGggZmlyc3QuXG4gICAgbGV0IG9yZGVyaW5nID0gdGhpcy5vcmRlcmluZ3Nbbm9kZU5hbWVdID0ge307XG4gICAgbGV0IGluZGV4ID0gMDtcbiAgICB3aGlsZSAocXVldWUubGVuZ3RoKSB7XG4gICAgICBsZXQgY2hpbGROYW1lID0gcXVldWUuc2hpZnQoKTtcbiAgICAgIG9yZGVyaW5nW2NoaWxkTmFtZV0gPSBpbmRleCsrO1xuICAgICAgXy5lYWNoKHN1Y2Nlc3NvcnNbY2hpbGROYW1lXSwgc3VjY05hbWUgPT4gcXVldWUucHVzaChzdWNjTmFtZSkpO1xuICAgICAgZGVsZXRlIHN1Y2Nlc3NvcnNbY2hpbGROYW1lXTsgLy8gUHJldmVudCBjeWNsZXMgZnJvbSBpbmZpbml0ZSBsb29waW5nLlxuICAgIH1cbiAgICByZXR1cm4gb3JkZXJpbmc7XG4gIH1cblxuICAvKipcbiAgICogUmV0dXJucyBhIGQzIE9yZGluYWwgZnVuY3Rpb24gdGhhdCBjYW4gYmUgdXNlZCB0byBsb29rIHVwIHRoZSBpbmRleCBvZlxuICAgKiBhIG5vZGUgYmFzZWQgb24gaXRzIHRlbXBsYXRlIGlkLlxuICAgKi9cbiAgZ2V0VGVtcGxhdGVJbmRleCgpOiAoc3RyaW5nKSA9PiBudW1iZXIge1xuICAgIGxldCB0ZW1wbGF0ZU5hbWVzID0gZDMua2V5cyh0aGlzLnRlbXBsYXRlcyk7XG4gICAgbGV0IHRlbXBsYXRlSW5kZXggPSBkMy5zY2FsZU9yZGluYWwoKVxuICAgICAgICAuZG9tYWluKHRlbXBsYXRlTmFtZXMpXG4gICAgICAgIC5yYW5nZShkMy5yYW5nZSgwLCB0ZW1wbGF0ZU5hbWVzLmxlbmd0aCkpO1xuICAgIHJldHVybiAodGVtcGxhdGVJZDogc3RyaW5nKSA9PiA8bnVtYmVyPnRlbXBsYXRlSW5kZXgodGVtcGxhdGVJZCk7XG4gIH1cbn1cblxuLyoqXG4gKiBJbnRlcm5hbCB1dGlsaXR5IGZ1bmN0aW9uIC0gZ2l2ZW4gYSBncmFwaCAoc2hvdWxkIGJlIGVpdGhlciBhIG1ldGFncmFwaCBvciBhXG4gKiBicmlkZ2VncmFwaCkgYW5kIGEgbm9kZSB3aGljaCBpcyBrbm93biB0byBiZSBpbiB0aGF0IGdyYXBoLCBkZXRlcm1pbmVcbiAqIHRoZSBvdGhlciBlbmRzIG9mIGVkZ2VzIHRoYXQgaW52b2x2ZSB0aGF0IG5vZGUgaW4gdGhlIGRpcmVjdGlvbiBzcGVjaWZpZWRcbiAqIGJ5IHdoZXRoZXIgaXQncyBpbmJvdW5kLlxuICpcbiAqIEZvciBleGFtcGxlIGlmIHlvdSB3YW50ZWQgdG8gZmluZCB0aGUgcHJlZGVjZXNzb3JzIG9mIGEgbm9kZSwgeW91J2QgY2FsbFxuICogdGhpcyBtZXRob2QgZm9yIHRoZSBwYXJlbnQncyBtZXRhZ3JhcGggYW5kIGJyaWRnZWdyYXBoLCBzcGVjaWZ5aW5nIGluYm91bmRcbiAqIGFzIHRydWUgKGxvb2sgYXQgdGhlIHNvdXJjZSBvZiBpbmJvdW5kIGVkZ2VzIHRvIHRoZSBzcGVjaWZpZWQgbm9kZSkuXG4gKlxuICogRGlzY292ZXJlZCB0YXJnZXQgbmFtZXMgYXJlIGFwcGVuZGVkIHRvIHRoZSB0YXJnZXRzIGFycmF5LlxuICovXG5mdW5jdGlvbiBmaW5kRWRnZVRhcmdldHNJbkdyYXBoKFxuICAgIGdyYXBoOiBncmFwaGxpYi5HcmFwaDxHcm91cE5vZGV8T3BOb2RlLCBNZXRhZWRnZT4sXG4gICAgbm9kZTogTm9kZSwgaW5ib3VuZDogYm9vbGVhbiwgdGFyZ2V0czogRWRnZXMpOiB2b2lkIHtcbiAgbGV0IGVkZ2VzID0gaW5ib3VuZCA/IGdyYXBoLmluRWRnZXMobm9kZS5uYW1lKSA6IGdyYXBoLm91dEVkZ2VzKG5vZGUubmFtZSk7XG4gIF8uZWFjaChlZGdlcywgZSA9PiB7XG4gICAgbGV0IG1ldGFlZGdlID0gZ3JhcGguZWRnZShlKTtcbiAgICBsZXQgdGFyZ2V0TGlzdCA9XG4gICAgICAgIG1ldGFlZGdlLm51bVJlZ3VsYXJFZGdlcyA/IHRhcmdldHMucmVndWxhciA6IHRhcmdldHMuY29udHJvbDtcbiAgICB0YXJnZXRMaXN0LnB1c2gobWV0YWVkZ2UpO1xuICB9KTtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBIaWVyYXJjaHlQYXJhbXMge1xuICB2ZXJpZnlUZW1wbGF0ZTogYm9vbGVhbjtcbiAgc2VyaWVzTm9kZU1pblNpemU6IG51bWJlcjtcbiAgc2VyaWVzTWFwOiB7IFtuYW1lOiBzdHJpbmddOiB0Zi5ncmFwaC5TZXJpZXNHcm91cGluZ1R5cGUgfTtcbiAgLy8gVGhpcyBzdHJpbmcgaXMgc3VwcGxpZWQgdG8gZGFncmUgYXMgdGhlICdyYW5rZGlyJyBwcm9wZXJ0eSBmb3IgbGF5aW5nIG91dFxuICAvLyB0aGUgZ3JhcGguIFRCLCBCVCwgTFIsIG9yIFJMLiBUaGUgZGVmYXVsdCBpcyAnQlQnIChib3R0b20gdG8gdG9wKS5cbiAgcmFua0RpcmVjdGlvbjogc3RyaW5nO1xuICAvLyBXaGV0aGVyIHRvIGRldGVjdCBudW1lcmljIHBhdHRlcm5zIGZvciBzZXJpZXMgbm9kZXMgdXNpbmcgZW50aXJlIG5hbWVzIG9mXG4gIC8vIG5vZGVzLiBJZiBmYWxzZSwgb25seSB1c2VzIG51bWVyaWMgc3VmZml4ZXMgdG8gZmluZCBwYXR0ZXJucyB0byBjb2xsYXBzZVxuICAvLyBpbnRvIHNlcmllcyBub2Rlcy5cbiAgdXNlR2VuZXJhbGl6ZWRTZXJpZXNQYXR0ZXJuczogYm9vbGVhbjtcbn1cblxuLyoqXG4gKiBAcGFyYW0gZ3JhcGggVGhlIHJhdyBncmFwaC5cbiAqIEBwYXJhbSBwYXJhbXMgUGFyYW1ldGVycyB1c2VkIHdoZW4gYnVpbGRpbmcgYSBoaWVyYXJjaHkuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBidWlsZChncmFwaDogdGYuZ3JhcGguU2xpbUdyYXBoLCBwYXJhbXM6IEhpZXJhcmNoeVBhcmFtcyxcbiAgICB0cmFja2VyOiBQcm9ncmVzc1RyYWNrZXIpOiBQcm9taXNlPEhpZXJhcmNoeXx2b2lkPiB7XG4gIGxldCBoID0gbmV3IEhpZXJhcmNoeUltcGwoeydyYW5rZGlyJzogcGFyYW1zLnJhbmtEaXJlY3Rpb259KTtcbiAgbGV0IHNlcmllc05hbWVzOiB7IFtuYW1lOiBzdHJpbmddOiBzdHJpbmcgfSA9IHt9O1xuICByZXR1cm4gdGYuZ3JhcGgudXRpbFxuICAgICAgLnJ1bkFzeW5jVGFzayhcbiAgICAgICAgICAnQWRkaW5nIG5vZGVzJywgMjAsXG4gICAgICAgICAgKCkgPT4ge1xuICAgICAgICAgICAgLy8gR2V0IGFsbCB0aGUgcG9zc2libGUgZGV2aWNlIGFuZCBYTEEgY2x1c3RlciBuYW1lcy5cbiAgICAgICAgICAgIGxldCBkZXZpY2VOYW1lcyA9IHt9O1xuICAgICAgICAgICAgbGV0IHhsYUNsdXN0ZXJOYW1lcyA9IHt9O1xuICAgICAgICAgICAgXy5lYWNoKGdyYXBoLm5vZGVzLCAobm9kZSwgbm9kZU5hbWUpID0+IHtcbiAgICAgICAgICAgICAgaWYgKG5vZGUuZGV2aWNlKSB7XG4gICAgICAgICAgICAgICAgZGV2aWNlTmFtZXNbbm9kZS5kZXZpY2VdID0gdHJ1ZTtcbiAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgIGlmIChub2RlLnhsYUNsdXN0ZXIpIHtcbiAgICAgICAgICAgICAgICB4bGFDbHVzdGVyTmFtZXNbbm9kZS54bGFDbHVzdGVyXSA9IHRydWU7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICBoLmRldmljZXMgPSBfLmtleXMoZGV2aWNlTmFtZXMpO1xuICAgICAgICAgICAgaC54bGFDbHVzdGVycyA9IF8ua2V5cyh4bGFDbHVzdGVyTmFtZXMpO1xuXG4gICAgICAgICAgICBhZGROb2RlcyhoLCBncmFwaCk7XG4gICAgICAgICAgfSxcbiAgICAgICAgICB0cmFja2VyKVxuICAgICAgLnRoZW4oKCkgPT4ge1xuICAgICAgICByZXR1cm4gdGYuZ3JhcGgudXRpbC5ydW5Bc3luY1Rhc2soJ0RldGVjdCBzZXJpZXMnLCAyMCwgKCkgPT4ge1xuICAgICAgICAgIGlmIChwYXJhbXMuc2VyaWVzTm9kZU1pblNpemUgPiAwKSB7XG4gICAgICAgICAgICBncm91cFNlcmllcyhcbiAgICAgICAgICAgICAgICBoLnJvb3QsIGgsIHNlcmllc05hbWVzLCBwYXJhbXMuc2VyaWVzTm9kZU1pblNpemUsXG4gICAgICAgICAgICAgICAgcGFyYW1zLnNlcmllc01hcCwgcGFyYW1zLnVzZUdlbmVyYWxpemVkU2VyaWVzUGF0dGVybnMpO1xuICAgICAgICAgIH1cbiAgICAgICAgfSwgdHJhY2tlcik7XG4gICAgICB9KVxuICAgICAgLnRoZW4oKCkgPT4ge1xuICAgICAgICByZXR1cm4gdGYuZ3JhcGgudXRpbC5ydW5Bc3luY1Rhc2soJ0FkZGluZyBlZGdlcycsIDMwLCAoKSA9PiB7XG4gICAgICAgICAgYWRkRWRnZXMoaCwgZ3JhcGgsIHNlcmllc05hbWVzKTtcbiAgICAgICAgfSwgdHJhY2tlcik7XG4gICAgICB9KVxuICAgICAgLnRoZW4oKCkgPT4ge1xuICAgICAgICByZXR1cm4gdGYuZ3JhcGgudXRpbC5ydW5Bc3luY1Rhc2soXG4gICAgICAgICAgICAnRmluZGluZyBzaW1pbGFyIHN1YmdyYXBocycsIDMwLCAoKSA9PiB7XG4gICAgICAgICAgICAgIGgudGVtcGxhdGVzID0gdGVtcGxhdGUuZGV0ZWN0KGgsIHBhcmFtcy52ZXJpZnlUZW1wbGF0ZSk7XG4gICAgICAgICAgICB9LCB0cmFja2VyKTtcbiAgICAgIH0pXG4gICAgICAudGhlbigoKSA9PiB7XG4gICAgICAgIHJldHVybiBoO1xuICAgICAgfSk7XG59O1xuXG5leHBvcnQgZnVuY3Rpb24gam9pbkFuZEFnZ3JlZ2F0ZVN0YXRzKFxuICAgIGg6IEhpZXJhcmNoeSwgc3RhdHM6IHRmLmdyYXBoLnByb3RvLlN0ZXBTdGF0cykge1xuICAvLyBHZXQgYWxsIHRoZSBwb3NzaWJsZSBkZXZpY2UgYW5kIFhMQSBjbHVzdGVyIG5hbWVzLlxuICBsZXQgZGV2aWNlTmFtZXMgPSB7fTtcbiAgbGV0IHhsYUNsdXN0ZXJOYW1lcyA9IHt9O1xuICBfLmVhY2goaC5yb290LmxlYXZlcygpLCBub2RlTmFtZSA9PiB7XG4gICAgbGV0IGxlYWYgPSA8T3BOb2RlPiBoLm5vZGUobm9kZU5hbWUpO1xuICAgIGlmIChsZWFmLmRldmljZSAhPSBudWxsKSB7XG4gICAgICBkZXZpY2VOYW1lc1tsZWFmLmRldmljZV0gPSB0cnVlO1xuICAgIH1cbiAgICBpZiAobGVhZi54bGFDbHVzdGVyICE9IG51bGwpIHtcbiAgICAgIHhsYUNsdXN0ZXJOYW1lc1tsZWFmLnhsYUNsdXN0ZXJdID0gdHJ1ZTtcbiAgICB9XG4gIH0pO1xuICBoLmRldmljZXMgPSBfLmtleXMoZGV2aWNlTmFtZXMpO1xuICBoLnhsYUNsdXN0ZXJzID0gXy5rZXlzKHhsYUNsdXN0ZXJOYW1lcyk7XG5cbiAgLy8gUmVzZXQgc3RhdHMgZm9yIGVhY2ggZ3JvdXAgbm9kZS5cbiAgXy5lYWNoKGguZ2V0Tm9kZU1hcCgpLCAobm9kZSwgbm9kZU5hbWUpID0+IHtcbiAgICBpZiAobm9kZS5pc0dyb3VwTm9kZSkge1xuICAgICAgbm9kZS5zdGF0cyA9IG5ldyBOb2RlU3RhdHMobnVsbCk7XG4gICAgICAoPEdyb3VwTm9kZT5ub2RlKS5kZXZpY2VIaXN0b2dyYW0gPSB7fTtcbiAgICB9XG4gIH0pO1xuXG4gIC8vIEJ1YmJsZS11cCB0aGUgc3RhdHMgYW5kIGRldmljZSBkaXN0cmlidXRpb24gZnJvbSBsZWF2ZXMgdG8gcGFyZW50cy5cbiAgXy5lYWNoKGgucm9vdC5sZWF2ZXMoKSwgbm9kZU5hbWUgPT4ge1xuICAgIGxldCBsZWFmID0gPE9wTm9kZT4gaC5ub2RlKG5vZGVOYW1lKTtcbiAgICBsZXQgbm9kZSA9IDxHcm91cE5vZGV8T3BOb2RlPiBsZWFmO1xuICAgIHdoaWxlIChub2RlLnBhcmVudE5vZGUgIT0gbnVsbCkge1xuICAgICAgaWYgKGxlYWYuZGV2aWNlICE9IG51bGwpIHtcbiAgICAgICAgbGV0IGRldmljZUhpc3RvZ3JhbSA9ICg8R3JvdXBOb2RlPm5vZGUucGFyZW50Tm9kZSkuZGV2aWNlSGlzdG9ncmFtO1xuICAgICAgICBkZXZpY2VIaXN0b2dyYW1bbGVhZi5kZXZpY2VdID0gKGRldmljZUhpc3RvZ3JhbVtsZWFmLmRldmljZV0gfHwgMCkgKyAxO1xuICAgICAgfVxuICAgICAgaWYgKGxlYWYueGxhQ2x1c3RlciAhPSBudWxsKSB7XG4gICAgICAgIGxldCB4bGFDbHVzdGVySGlzdG9ncmFtID1cbiAgICAgICAgICAgICg8R3JvdXBOb2RlPm5vZGUucGFyZW50Tm9kZSkueGxhQ2x1c3Rlckhpc3RvZ3JhbTtcbiAgICAgICAgeGxhQ2x1c3Rlckhpc3RvZ3JhbVtsZWFmLnhsYUNsdXN0ZXJdID1cbiAgICAgICAgICAgICh4bGFDbHVzdGVySGlzdG9ncmFtW2xlYWYueGxhQ2x1c3Rlcl0gfHwgMCkgKyAxO1xuICAgICAgfVxuICAgICAgaWYgKGxlYWYuc3RhdHMgIT0gbnVsbCkge1xuICAgICAgICBub2RlLnBhcmVudE5vZGUuc3RhdHMuY29tYmluZShsZWFmLnN0YXRzKTtcbiAgICAgIH1cbiAgICAgIG5vZGUgPSA8R3JvdXBOb2RlPiBub2RlLnBhcmVudE5vZGU7XG4gICAgfVxuICB9KTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGdldEluY29tcGF0aWJsZU9wcyhoaWVyYXJjaHk6IEhpZXJhcmNoeSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGllcmFyY2h5UGFyYW1zOiBIaWVyYXJjaHlQYXJhbXMpIHtcbiAgbGV0IG5vZGVzOiAoR3JvdXBOb2RlIHwgT3BOb2RlKVtdID0gW107XG4gIGxldCBhZGRlZFNlcmllc05vZGVzOiB7IFtzZXJpZXNOYW1lOiBzdHJpbmddOiBTZXJpZXNOb2RlIH0gPSB7fTtcbiAgXy5lYWNoKGhpZXJhcmNoeS5yb290LmxlYXZlcygpLCBsZWFmID0+IHtcbiAgICBsZXQgbm9kZSA9IGhpZXJhcmNoeS5ub2RlKGxlYWYpO1xuICAgIGlmIChub2RlLnR5cGUgPT0gTm9kZVR5cGUuT1ApIHtcbiAgICAgIGxldCBvcE5vZGUgPSA8T3BOb2RlPiBub2RlO1xuXG4gICAgICBpZiAoIW9wTm9kZS5jb21wYXRpYmxlKSB7XG4gICAgICAgIGlmIChvcE5vZGUub3duaW5nU2VyaWVzKSB7XG4gICAgICAgICAgaWYgKGhpZXJhcmNoeVBhcmFtcyAmJlxuICAgICAgICAgICAgICBoaWVyYXJjaHlQYXJhbXMuc2VyaWVzTWFwW29wTm9kZS5vd25pbmdTZXJpZXNdXG4gICAgICAgICAgICAgID09PSB0Zi5ncmFwaC5TZXJpZXNHcm91cGluZ1R5cGUuVU5HUk9VUCkge1xuICAgICAgICAgICAgLy8gRm9yIHVuLWdyb3VwZWQgc2VyaWVzIG5vZGUsIGFkZCBlYWNoIG5vZGUgaW5kaXZpZHVhbGx5XG4gICAgICAgICAgICBub2Rlcy5wdXNoKG9wTm9kZSlcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgaWYgKCFhZGRlZFNlcmllc05vZGVzW29wTm9kZS5vd25pbmdTZXJpZXNdKSB7XG4gICAgICAgICAgICAgIGxldCBzZXJpZXMgPSA8U2VyaWVzTm9kZT5oaWVyYXJjaHkubm9kZShvcE5vZGUub3duaW5nU2VyaWVzKTtcbiAgICAgICAgICAgICAgaWYgKHNlcmllcykge1xuICAgICAgICAgICAgICAgIGFkZGVkU2VyaWVzTm9kZXNbb3BOb2RlLm93bmluZ1Nlcmllc10gPSBzZXJpZXM7XG4gICAgICAgICAgICAgICAgbm9kZXMucHVzaChzZXJpZXMpO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIG5vZGVzLnB1c2gob3BOb2RlKTtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICAvLyBDaGVjayB0aGUgZW1iZWRkaW5ncyBmb3IgaW52YWxpZCBvcGVyYXRpb25zXG4gICAgICBfLmVhY2gob3BOb2RlLmluRW1iZWRkaW5ncywgKGluTm9kZSkgPT4ge1xuICAgICAgICBpZiAoIWluTm9kZS5jb21wYXRpYmxlKSB7XG4gICAgICAgICAgbm9kZXMucHVzaChpbk5vZGUpO1xuICAgICAgICB9XG4gICAgICB9KTtcblxuICAgICAgXy5lYWNoKG9wTm9kZS5vdXRFbWJlZGRpbmdzLCAob3V0Tm9kZSkgPT4ge1xuICAgICAgICBpZiAoIW91dE5vZGUuY29tcGF0aWJsZSkge1xuICAgICAgICAgIG5vZGVzLnB1c2gob3V0Tm9kZSk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuXG4gICAgfVxuICB9KTtcbiAgcmV0dXJuIG5vZGVzO1xufVxuXG5cbi8qKlxuICogQ3JlYXRlcyB0aGUgbWV0YW5vZGVzIGluIHRoZSBoaWVyYXJjaGljYWwgZ3JhcGggYW5kIGFzc2lnbnMgcGFyZW50LWNoaWxkXG4gKiByZWxhdGlvbnNoaXAgYmV0d2VlbiB0aGVtLiBBbHNvIGFzc2lnbnMgcmVsYXRpb25zaGlwcyBiZXR3ZWVuIGxpYnJhcnlcbiAqIGZ1bmN0aW9ucyBhbmQgdGhlaXIgdXNhZ2VzIHRocm91Z2hvdXQgdGhlIGdyYXBoLlxuICovXG5mdW5jdGlvbiBhZGROb2RlcyhoOiBIaWVyYXJjaHksIGdyYXBoOiBTbGltR3JhcGgpIHtcbiAgLy8gTWFwcyB0aGUgb3Agb2YgYSBub2RlIHRvIG5hbWVzIG9mIG5vZGVzIHRoYXQgaGF2ZSB0aGUgb3AuIFVzZWQgdG8gcG9wdWxhdGVcbiAgLy8gdGhlIGxpYnJhcnlGdW5jdGlvbnMgZmllbGQgb2YgdGhlIGhpZXJhcmNoeS5cbiAgY29uc3Qgb3BUb05vZGUgPSB7fTtcblxuICBfLmVhY2goZ3JhcGgubm9kZXMsIChub2RlLCBub2RlTmFtZSkgPT4ge1xuICAgIGxldCBwYXRoID0gZ2V0SGllcmFyY2hpY2FsUGF0aChub2RlLm5hbWUpO1xuICAgIGxldCBwYXJlbnQ6IE1ldGFub2RlID0gaC5yb290O1xuXG4gICAgcGFyZW50LmRlcHRoID0gTWF0aC5tYXgocGF0aC5sZW5ndGgsIHBhcmVudC5kZXB0aCk7XG5cbiAgICAvLyBUcmFjayB3aGljaCBub2RlcyBhcmUgYXNzb2NpYXRlZCB3aXRoIHdoaWNoIG9wcy5cbiAgICBpZiAoIW9wVG9Ob2RlW25vZGUub3BdKSB7XG4gICAgICBvcFRvTm9kZVtub2RlLm9wXSA9IFtdO1xuICAgIH1cbiAgICBvcFRvTm9kZVtub2RlLm9wXS5wdXNoKG5vZGUpO1xuXG4gICAgLy8gQ3JlYXRlIHBhcmVudCBtZXRhbm9kZXMgZm9yIGVhY2ggZGVwdGguIEZvciBleGFtcGxlIGlmIHRoZSBub2RlIG5hbWVcbiAgICAvLyBpcyAnYS9iL2MnLCB0aGVuIGNyZWF0ZSBtZXRhbm9kZXMgJ2EnIGFuZCAnYS9iJywgd2hlcmUgJ2EvYicgaXMgYSBjaGlsZFxuICAgIC8vIG9mIGEuXG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBwYXRoLmxlbmd0aDsgaSsrKSB7XG4gICAgICBwYXJlbnQuZGVwdGggPSBNYXRoLm1heChwYXJlbnQuZGVwdGgsIHBhdGgubGVuZ3RoIC0gaSk7XG4gICAgICBwYXJlbnQuY2FyZGluYWxpdHkgKz0gbm9kZS5jYXJkaW5hbGl0eTtcbiAgICAgIHBhcmVudC5vcEhpc3RvZ3JhbVtub2RlLm9wXSA9IChwYXJlbnQub3BIaXN0b2dyYW1bbm9kZS5vcF0gfHwgMCkgKyAxO1xuICAgICAgaWYgKG5vZGUuZGV2aWNlICE9IG51bGwpIHtcbiAgICAgICAgcGFyZW50LmRldmljZUhpc3RvZ3JhbVtub2RlLmRldmljZV0gPVxuICAgICAgICAgICAgKHBhcmVudC5kZXZpY2VIaXN0b2dyYW1bbm9kZS5kZXZpY2VdIHx8IDApICsgMTtcbiAgICAgIH1cbiAgICAgIGlmIChub2RlLnhsYUNsdXN0ZXIgIT0gbnVsbCkge1xuICAgICAgICBwYXJlbnQueGxhQ2x1c3Rlckhpc3RvZ3JhbVtub2RlLnhsYUNsdXN0ZXJdID1cbiAgICAgICAgICAgIChwYXJlbnQueGxhQ2x1c3Rlckhpc3RvZ3JhbVtub2RlLnhsYUNsdXN0ZXJdIHx8IDApICsgMTtcbiAgICAgIH1cblxuICAgICAgLy8gSW5jcmVtZW50IHBhcmVudHMgYXBwcm9wcmlhdGUgY29tcGF0aWJpbGl0eSBjb3VudFxuICAgICAgaWYgKG5vZGUuY29tcGF0aWJsZSkge1xuICAgICAgICBwYXJlbnQuY29tcGF0aWJpbGl0eUhpc3RvZ3JhbS5jb21wYXRpYmxlID1cbiAgICAgICAgICAgIChwYXJlbnQuY29tcGF0aWJpbGl0eUhpc3RvZ3JhbS5jb21wYXRpYmxlIHx8IDApICsgMTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHBhcmVudC5jb21wYXRpYmlsaXR5SGlzdG9ncmFtLmluY29tcGF0aWJsZSA9XG4gICAgICAgICAgICAocGFyZW50LmNvbXBhdGliaWxpdHlIaXN0b2dyYW0uaW5jb21wYXRpYmxlIHx8IDApICsgMTtcbiAgICAgIH1cblxuICAgICAgLy8gSW5jcmVtZW50IGNhcGFiaWxpdHkgY291bnRzIGZvciBpbiBhbmQgb3V0IGVtYmVkZGluZ3NcbiAgICAgIF8uZWFjaChub2RlLmluRW1iZWRkaW5ncywgKGluTm9kZSkgPT4ge1xuICAgICAgICBpZiAoaW5Ob2RlLmNvbXBhdGlibGUpIHtcbiAgICAgICAgICBwYXJlbnQuY29tcGF0aWJpbGl0eUhpc3RvZ3JhbS5jb21wYXRpYmxlID1cbiAgICAgICAgICAgICAgKHBhcmVudC5jb21wYXRpYmlsaXR5SGlzdG9ncmFtLmNvbXBhdGlibGUgfHwgMCkgKyAxO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHBhcmVudC5jb21wYXRpYmlsaXR5SGlzdG9ncmFtLmluY29tcGF0aWJsZSA9XG4gICAgICAgICAgICAgIChwYXJlbnQuY29tcGF0aWJpbGl0eUhpc3RvZ3JhbS5pbmNvbXBhdGlibGUgfHwgMCkgKyAxO1xuICAgICAgICB9XG4gICAgICB9KTtcblxuICAgICAgXy5lYWNoKG5vZGUub3V0RW1iZWRkaW5ncywgKG91dE5vZGUpID0+IHtcbiAgICAgICAgaWYgKG91dE5vZGUuY29tcGF0aWJsZSkge1xuICAgICAgICAgIHBhcmVudC5jb21wYXRpYmlsaXR5SGlzdG9ncmFtLmNvbXBhdGlibGUgPVxuICAgICAgICAgICAgICAocGFyZW50LmNvbXBhdGliaWxpdHlIaXN0b2dyYW0uY29tcGF0aWJsZSB8fCAwKSArIDE7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgcGFyZW50LmNvbXBhdGliaWxpdHlIaXN0b2dyYW0uaW5jb21wYXRpYmxlID1cbiAgICAgICAgICAgICAgKHBhcmVudC5jb21wYXRpYmlsaXR5SGlzdG9ncmFtLmluY29tcGF0aWJsZSB8fCAwKSArIDE7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuXG4gICAgICBpZiAoaSA9PT0gcGF0aC5sZW5ndGggLSAxKSB7IGJyZWFrOyB9XG4gICAgICBsZXQgbmFtZSA9IHBhdGhbaV07XG4gICAgICBsZXQgY2hpbGQgPSA8TWV0YW5vZGU+aC5ub2RlKG5hbWUpO1xuICAgICAgaWYgKCFjaGlsZCkge1xuICAgICAgICBjaGlsZCA9IGNyZWF0ZU1ldGFub2RlKG5hbWUsIGguZ3JhcGhPcHRpb25zKTtcbiAgICAgICAgY2hpbGQucGFyZW50Tm9kZSA9IHBhcmVudDtcbiAgICAgICAgaC5zZXROb2RlKG5hbWUsIGNoaWxkKTtcbiAgICAgICAgcGFyZW50Lm1ldGFncmFwaC5zZXROb2RlKG5hbWUsIGNoaWxkKTtcblxuICAgICAgICBpZiAobmFtZS5pbmRleE9mKHRmLmdyYXBoLkZVTkNUSU9OX0xJQlJBUllfTk9ERV9QUkVGSVgpID09PSAwICYmXG4gICAgICAgICAgICBwYXJlbnQubmFtZSA9PT0gdGYuZ3JhcGguUk9PVF9OQU1FKSB7XG4gICAgICAgICAgLy8gVGhpcyBtZXRhbm9kZSByZXByZXNlbnRzIGEgZnVuY3Rpb24gaW4gdGhlIExpYnJhcnkuIFdlIGxhdGVyIGNvcHlcbiAgICAgICAgICAvLyBpdHMgY29udGVudHMgdG8gZHluYW1pY2FsbHkgaW5qZWN0IGZ1bmN0aW9uIGRhdGEgaW50byB0aGUgZ3JhcGhcbiAgICAgICAgICAvLyB3aGVuIHRoZSBzdWJoaWVyYXJjaHkgb2YgYSBtZXRhbm9kZSBpcyBidWlsdCAodXBvbiBpdHMgZXhwYW5zaW9uKS5cbiAgICAgICAgICBjb25zdCBmdW5jdGlvbk5hbWUgPSBuYW1lLnN1YnN0cmluZyhcbiAgICAgICAgICAgICAgdGYuZ3JhcGguRlVOQ1RJT05fTElCUkFSWV9OT0RFX1BSRUZJWC5sZW5ndGgpO1xuXG4gICAgICAgICAgLy8gRm9yIG5vdywgcmVtZW1iZXIgdGhlIG1ldGFub2RlIHRoYXQgcmVwcmVzZW50cyB0aGUgZnVuY3Rpb24gd2l0aFxuICAgICAgICAgIC8vIHRoaXMgbmFtZS5cbiAgICAgICAgICBpZiAoIW9wVG9Ob2RlW2Z1bmN0aW9uTmFtZV0pIHtcbiAgICAgICAgICAgIG9wVG9Ob2RlW2Z1bmN0aW9uTmFtZV0gPSBbXTtcbiAgICAgICAgICB9XG4gICAgICAgICAgaC5saWJyYXJ5RnVuY3Rpb25zW2Z1bmN0aW9uTmFtZV0gPSB7XG4gICAgICAgICAgICBub2RlOiBjaGlsZCxcbiAgICAgICAgICAgIHVzYWdlczogb3BUb05vZGVbZnVuY3Rpb25OYW1lXSxcbiAgICAgICAgICB9O1xuICAgICAgICAgIGNoaWxkLmFzc29jaWF0ZWRGdW5jdGlvbiA9IGZ1bmN0aW9uTmFtZTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcGFyZW50ID0gY2hpbGQ7XG4gICAgfVxuXG4gICAgLy8gQXNzdW1pbmcgbm9kZSBuYW1lIGlzICdhL2IvYycsIGFzc2lnbiB0aGUgT3BOb2RlIGFzIGEgY2hpbGQgb2YgdGhlXG4gICAgLy8gbWV0YW5vZGUgJ2EvYicuXG4gICAgaC5zZXROb2RlKG5vZGUubmFtZSwgbm9kZSk7XG4gICAgbm9kZS5wYXJlbnROb2RlID0gcGFyZW50O1xuICAgIHBhcmVudC5tZXRhZ3JhcGguc2V0Tm9kZShub2RlLm5hbWUsIG5vZGUpO1xuXG4gICAgLy8gQWRkIGVhY2ggb2YgdGhlIGluLWVtYmVkZGluZ3MgYW5kIG91dC1lbWJlZGRpbmdzIGluIHRoZSBoaWVyYXJjaHkuXG4gICAgXy5lYWNoKG5vZGUuaW5FbWJlZGRpbmdzLCBmdW5jdGlvbihlbWJlZGRpbmcpIHtcbiAgICAgIGguc2V0Tm9kZShlbWJlZGRpbmcubmFtZSwgZW1iZWRkaW5nKTtcbiAgICAgIGVtYmVkZGluZy5wYXJlbnROb2RlID0gbm9kZTtcbiAgICB9KTtcbiAgICBfLmVhY2gobm9kZS5vdXRFbWJlZGRpbmdzLCBmdW5jdGlvbihlbWJlZGRpbmcpIHtcbiAgICAgIGguc2V0Tm9kZShlbWJlZGRpbmcubmFtZSwgZW1iZWRkaW5nKTtcbiAgICAgIGVtYmVkZGluZy5wYXJlbnROb2RlID0gbm9kZTtcbiAgICB9KTtcbiAgfSk7XG59O1xuXG4vKipcbiAqIEZvciBlYWNoIG1ldGFub2RlIGluIHRoZSBoaWVyYXJjaGljYWwgZ3JhcGgsIHRoaXMgbWV0aG9kIGFkZHM6XG4gKiB0aGUgZWRnZXMgaW4gdGhlIG1ldGFncmFwaC4gVGhlc2UgYXJlIGVkZ2VzIGJldHdlZW4gbm9kZXNcbiAqIHRoYXQgc2hhcmUgdGhlIHNhbWUgcGFyZW50LlxuICovXG5mdW5jdGlvbiBhZGRFZGdlcyhoOiBIaWVyYXJjaHksIGdyYXBoOiBTbGltR3JhcGgsXG4gICAgc2VyaWVzTmFtZXM6IHsgW25hbWU6IHN0cmluZ106IHN0cmluZyB9KSB7XG5cbiAgbGV0IG5vZGVJbmRleCA9IGguZ2V0Tm9kZU1hcCgpO1xuXG4gIC8vIEFuY2VzdG9yIHBhdGhzIGZvciB0aGUgc291cmNlIGFuZCBkZXN0aW5hdGlvbiBub2RlcyBvZiBhbiBlZGdlLiBUaGVzZSBhcmVcbiAgLy8gcmV1c2VkIGZvciBlYWNoIGVkZ2UgcmF0aGVyIHRoYW4gYWxsb2NhdGluZyBuZXcgb25lcy4gSXQncyBhYm91dCAxMCUgZmFzdGVyXG4gIC8vIHRoYW4gYWxsb2NhdGluZyBuZXcgb25lcyBvbiBlYWNoIHBhc3MgdGhyb3VnaCB0aGUgbG9vcC5cbiAgbGV0IHNvdXJjZVBhdGg6IHN0cmluZ1tdID0gW107XG4gIGxldCBkZXN0UGF0aDogc3RyaW5nW10gPSBbXTtcblxuICAvLyBJbnNlcnQgdGhlIGFuY2VzdG9yIHBhdGggZm9yIGEgbm9kZSBpbnRvIHRoZSBwcm92aWRlZCBhcnJheSwgaW5jbHVkaW5nIHRoZVxuICAvLyBub2RlIGl0c2VsZi4gUmV0dXJuIHRoZSBpbmRleCBvZiB0aGUgbGFzdCBub2RlIGluc2VydGVkIChhbHdheXMgUk9PVCkuXG4gIGxldCBnZXRQYXRoID0gKG5vZGU6IE5vZGUsIHBhdGg6IHN0cmluZ1tdKTogbnVtYmVyID0+IHtcbiAgICBsZXQgaSA9IDA7XG4gICAgd2hpbGUgKG5vZGUpIHtcbiAgICAgIHBhdGhbaSsrXSA9IG5vZGUubmFtZTtcbiAgICAgIG5vZGUgPSBub2RlLnBhcmVudE5vZGU7XG4gICAgfVxuICAgIHJldHVybiBpIC0gMTtcbiAgfTtcblxuICBfLmVhY2goZ3JhcGguZWRnZXMsIGJhc2VFZGdlID0+IHtcblxuICAgIC8vIEdldCB0aGUgaGllcmFyY2hpY2FsIHBhdGhzIGZvciB0aGUgc291cmNlIGFuZCBkZXN0aW5hdGlvbiBvZiB0aGUgZWRnZS5cbiAgICBsZXQgc291cmNlQW5jZXN0b3JJbmRleCA9IGdldFBhdGgoZ3JhcGgubm9kZXNbYmFzZUVkZ2Uudl0sIHNvdXJjZVBhdGgpO1xuICAgIGxldCBkZXN0QW5jZXN0b3JJbmRleCA9IGdldFBhdGgoZ3JhcGgubm9kZXNbYmFzZUVkZ2Uud10sIGRlc3RQYXRoKTtcblxuICAgIC8vIElmIHRoZSBoaWVyYXJjaGljYWwgcGF0aCBjYW5ub3QgYmUgZm91bmQgZm9yIGVpdGhlciBlbmRwb2ludCwgdGhlbiB3ZVxuICAgIC8vIGNhbm5vdCBjcmVhdGUgdGhlIGVkZ2UuIFRoaXMgaGFwcGVucyBmb3IgZXhhbXBsZSB3aGVuIGEgbm9kZSBoYXMgYVxuICAgIC8vIGNvbnRyb2wgZGVwZW5kZW5jeSBvbiBhIHN1bW1hcnkgbm9kZSwgd2hpY2ggYXJlIGVtYmVkZGVkLlxuICAgIGlmIChzb3VyY2VBbmNlc3RvckluZGV4ID09PSAtMSB8fCBkZXN0QW5jZXN0b3JJbmRleCA9PT0gLTEpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICAvLyBGaW5kIHRoZSBsb3dlc3Qgc2hhcmVkIGFuY2VzdG9yIGJldHdlZW4gc291cmNlIGFuZCBkZXN0IGJ5IGxvb2tpbmcgZm9yXG4gICAgLy8gdGhlIGhpZ2hlc3Qgbm9kZXMgdGhhdCBkaWZmZXIgYmV0d2VlbiB0aGVpciBhbmNlc3RvciBwYXRocy5cbiAgICB3aGlsZSAoc291cmNlUGF0aFtzb3VyY2VBbmNlc3RvckluZGV4XSA9PT0gZGVzdFBhdGhbZGVzdEFuY2VzdG9ySW5kZXhdKSB7XG4gICAgICBzb3VyY2VBbmNlc3RvckluZGV4LS07XG4gICAgICBkZXN0QW5jZXN0b3JJbmRleC0tO1xuICAgICAgaWYgKHNvdXJjZUFuY2VzdG9ySW5kZXggPCAwIHx8IGRlc3RBbmNlc3RvckluZGV4IDwgMCkge1xuICAgICAgICAvLyBUaGlzIHdvdWxkIG9ubHkgb2NjdXIgaWYgdGhlIHR3byBub2RlcyB3ZXJlIHRoZSBzYW1lIChhIGN5Y2xlIGluIHRoZVxuICAgICAgICAvLyBncmFwaCksIG9yIGlmIG9uZSBlbmRwb2ludCB3YXMgYSBzdHJpY3QgYW5jZXN0b3Igb2YgdGhlIG90aGVyLiBUaGVcbiAgICAgICAgLy8gbGF0dGVyIHNob3VsZG4ndCBoYXBwZW4gYmVjYXVzZSB3ZSByZW5hbWUgbm9kZXMgd2hpY2ggYXJlIGJvdGhcbiAgICAgICAgLy8gbWV0YW5vZGVzIGFuZCBvcCBub2Rlcy4gRS5nLiAnQS9CJyBiZWNvbWVzICdBL0IvKEIpJy5cbiAgICAgICAgdGhyb3cgRXJyb3IoJ05vIGRpZmZlcmVuY2UgZm91bmQgYmV0d2VlbiBhbmNlc3RvciBwYXRocy4nKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICBsZXQgc2hhcmVkQW5jZXN0b3JOb2RlID1cbiAgICAgIDxHcm91cE5vZGU+bm9kZUluZGV4W3NvdXJjZVBhdGhbc291cmNlQW5jZXN0b3JJbmRleCArIDFdXTtcbiAgICBsZXQgc291cmNlQW5jZXN0b3JOYW1lID0gc291cmNlUGF0aFtzb3VyY2VBbmNlc3RvckluZGV4XTtcbiAgICBsZXQgZGVzdEFuY2VzdG9yTmFtZSA9IGRlc3RQYXRoW2Rlc3RBbmNlc3RvckluZGV4XTtcblxuICAgIC8vIEZpbmQgb3IgY3JlYXRlIHRoZSBNZXRhZWRnZSB3aGljaCBzaG91bGQgY29udGFpbiB0aGlzIEJhc2VFZGdlIGluc2lkZVxuICAgIC8vIHRoZSBzaGFyZWQgYW5jZXN0b3IuXG4gICAgbGV0IG1ldGFlZGdlID1cbiAgICAgIHNoYXJlZEFuY2VzdG9yTm9kZS5tZXRhZ3JhcGguZWRnZShzb3VyY2VBbmNlc3Rvck5hbWUsIGRlc3RBbmNlc3Rvck5hbWUpO1xuICAgIGlmICghbWV0YWVkZ2UpIHtcbiAgICAgIG1ldGFlZGdlID0gY3JlYXRlTWV0YWVkZ2Uoc291cmNlQW5jZXN0b3JOYW1lLCBkZXN0QW5jZXN0b3JOYW1lKTtcbiAgICAgIHNoYXJlZEFuY2VzdG9yTm9kZS5tZXRhZ3JhcGhcbiAgICAgICAgLnNldEVkZ2Uoc291cmNlQW5jZXN0b3JOYW1lLCBkZXN0QW5jZXN0b3JOYW1lLCBtZXRhZWRnZSk7XG4gICAgfVxuICAgIGlmICghc2hhcmVkQW5jZXN0b3JOb2RlLmhhc05vbkNvbnRyb2xFZGdlcyAmJlxuICAgICAgICAhYmFzZUVkZ2UuaXNDb250cm9sRGVwZW5kZW5jeSkge1xuICAgICAgc2hhcmVkQW5jZXN0b3JOb2RlLmhhc05vbkNvbnRyb2xFZGdlcyA9IHRydWU7XG4gICAgfVxuICAgIG1ldGFlZGdlLmFkZEJhc2VFZGdlKGJhc2VFZGdlLCBoKTtcbiAgfSk7XG59O1xuXG4vKipcbiAqIFVzaW5nIHRoZSBoaWVyYXJjaHkgdGVtcGxhdGUgaW5mb3JtYXRpb24sIGRldGVjdCBzZXJpZXMgaW4gdGhlIHByb3ZpZGVkXG4gKiBtZXRhbm9kZS4gIEZvciBlYWNoIGRldGVjdGVkIHNlcmllcywgY3JlYXRlIGEgbmV3IFNlcmllc05vZGVcbiAqIGFuZCByZW1vdmUgc2VyaWVzIG1lbWJlcnMgZnJvbSB0aGUgbWV0YW5vZGUncyBtZXRhZ3JhcGggYW5kIG1vdmUgdGhlbSB0b1xuICogdGhlIG5ldyBzZXJpZXMgbm9kZSdzIG1ldGFncmFwaC5cbiAqXG4gKiBAcGFyYW0gbWV0YW5vZGVcbiAqIEBwYXJhbSBoaWVyYXJjaHlcbiAqIEBwYXJhbSBzZXJpZXNOYW1lcyBNYXAgb2Ygbm9kZSBuYW1lcyB0byB0aGVpciBzZXJpZXMgdGhleSBhcmUgY29udGFpbmVkIGluLlxuICogICAgIFRoaXMgc2hvdWxkIGJlIHByb3ZpZGVkIGVtcHR5IGFuZCBpcyBwb3B1bGF0ZWQgYnkgdGhpcyBtZXRob2QuXG4gKiBAcGFyYW0gdGhyZXNob2xkIElmIHRoZSBzZXJpZXMgaGFzIHRoaXMgbWFueSBub2RlcyBvciBtb3JlLCB0aGVuIGdyb3VwIHRoZW1cbiAqICAgICBpbnRvIGEgc2VyaWVzLlxuICogQHBhcmFtIG1hcCBNYXAgb2Ygc2VyaWVzIG5hbWVzIHRvIHRoZWlyIHNlcmllcyBncm91cGluZyB0eXBlLCBpZiBvbmUgaGFzXG4gKiAgICAgYmVlbiBzZXQuXG4gKiBAcGFyYW0gdXNlR2VuZXJhbGl6ZWRTZXJpZXNQYXR0ZXJucyBXaGV0aGVyIHRvIHVzZSBmaW5kIHBhdHRlcm5zIGZvciBzZXJpZXNcbiAqICAgICBub2RlcyB1c2luZyBhbnkgcGFydHMgb2YgbmFtZXMgb2Ygbm9kZXMuIElmIGZhbHNlLCBvbmx5IHVzZXMgcGF0dGVybnNcbiAqICAgICBkaXNjb3ZlcmVkIHdpdGhpbiBudW1lcmljIHN1ZmZpeGVzIG9mIG5vZGVzIG5hbWVzLlxuICogQHJldHVybiBBIGRpY3Rpb25hcnkgZnJvbSBub2RlIG5hbWUgdG8gc2VyaWVzIG5vZGUgbmFtZSB0aGF0IGNvbnRhaW5zIHRoZVxuICogICAgIG5vZGUuXG4gKi9cbmZ1bmN0aW9uIGdyb3VwU2VyaWVzKG1ldGFub2RlOiBNZXRhbm9kZSwgaGllcmFyY2h5OiBIaWVyYXJjaHksXG4gICAgc2VyaWVzTmFtZXM6IHsgW25hbWU6IHN0cmluZ106IHN0cmluZyB9LCB0aHJlc2hvbGQ6IG51bWJlcixcbiAgICBtYXA6IHsgW25hbWU6IHN0cmluZ106IHRmLmdyYXBoLlNlcmllc0dyb3VwaW5nVHlwZSB9LFxuICAgIHVzZUdlbmVyYWxpemVkU2VyaWVzUGF0dGVybnM6IGJvb2xlYW4pIHtcbiAgbGV0IG1ldGFncmFwaCA9IG1ldGFub2RlLm1ldGFncmFwaDtcbiAgXy5lYWNoKG1ldGFncmFwaC5ub2RlcygpLCBuID0+IHtcbiAgICBsZXQgY2hpbGQgPSBtZXRhZ3JhcGgubm9kZShuKTtcbiAgICBpZiAoY2hpbGQudHlwZSA9PT0gdGYuZ3JhcGguTm9kZVR5cGUuTUVUQSkge1xuICAgICAgZ3JvdXBTZXJpZXMoXG4gICAgICAgICAgPE1ldGFub2RlPmNoaWxkLFxuICAgICAgICAgIGhpZXJhcmNoeSxcbiAgICAgICAgICBzZXJpZXNOYW1lcyxcbiAgICAgICAgICB0aHJlc2hvbGQsXG4gICAgICAgICAgbWFwLFxuICAgICAgICAgIHVzZUdlbmVyYWxpemVkU2VyaWVzUGF0dGVybnMpO1xuICAgIH1cbiAgfSk7XG5cbiAgbGV0IGNsdXN0ZXJzID0gY2x1c3Rlck5vZGVzKG1ldGFncmFwaCk7XG5cbiAgY29uc3QgZGV0ZWN0U2VyaWVzTWV0aG9kID0gdXNlR2VuZXJhbGl6ZWRTZXJpZXNQYXR0ZXJucz9cbiAgICAgIGRldGVjdFNlcmllc0FueXdoZXJlSW5Ob2RlTmFtZSA6XG4gICAgICBkZXRlY3RTZXJpZXNVc2luZ051bWVyaWNTdWZmaXhlcztcbiAgbGV0IHNlcmllc0RpY3QgPSBkZXRlY3RTZXJpZXNNZXRob2QoXG4gICAgICBjbHVzdGVycywgbWV0YWdyYXBoLCBoaWVyYXJjaHkuZ3JhcGhPcHRpb25zKTtcblxuICAvLyBBZGQgZWFjaCBzZXJpZXMgbm9kZSB0byB0aGUgZ3JhcGggYW5kIGFkZCBpdHMgZ3JvdXBlZCBjaGlsZHJlbiB0byBpdHMgb3duXG4gIC8vIG1ldGFncmFwaC5cbiAgXy5lYWNoKHNlcmllc0RpY3QsIGZ1bmN0aW9uKHNlcmllc05vZGU6IFNlcmllc05vZGUsIHNlcmllc05hbWU6IHN0cmluZykge1xuICAgIGxldCBub2RlTWVtYmVyTmFtZXMgPSBzZXJpZXNOb2RlLm1ldGFncmFwaC5ub2RlcygpO1xuICAgIF8uZWFjaChub2RlTWVtYmVyTmFtZXMsIG4gPT4ge1xuICAgICAgbGV0IGNoaWxkID0gPE9wTm9kZT5tZXRhZ3JhcGgubm9kZShuKTtcbiAgICAgIGlmICghY2hpbGQub3duaW5nU2VyaWVzKSB7XG4gICAgICAgIGNoaWxkLm93bmluZ1NlcmllcyA9IHNlcmllc05hbWU7XG4gICAgICB9XG4gICAgfSk7XG4gICAgLy8gSWYgdGhlIHNlcmllcyBjb250YWlucyBsZXNzIHRoYW4gdGhlIHRocmVzaG9sZCBudW1iZXIgb2Ygbm9kZXMgYW5kXG4gICAgLy8gdGhpcyBzZXJpZXMgaGFzIG5vdCBiZWVuIGFkZGluZyB0byB0aGUgc2VyaWVzIG1hcCwgdGhlbiBzZXQgdGhpc1xuICAgIC8vIHNlcmllcyB0byBiZSBzaG93biB1bmdyb3VwZWQgaW4gdGhlIG1hcC5cbiAgICBpZiAobm9kZU1lbWJlck5hbWVzLmxlbmd0aCA8IHRocmVzaG9sZCAmJiAhKHNlcmllc05vZGUubmFtZSBpbiBtYXApKSB7XG4gICAgICBtYXBbc2VyaWVzTm9kZS5uYW1lXSA9IHRmLmdyYXBoLlNlcmllc0dyb3VwaW5nVHlwZS5VTkdST1VQO1xuICAgIH1cbiAgICAvLyBJZiB0aGUgc2VyaWVzIGlzIGluIHRoZSBtYXAgYXMgdW5ncm91cGVkIHRoZW4gZG8gbm90IGdyb3VwIHRoZSBzZXJpZXMuXG4gICAgaWYgKHNlcmllc05vZGUubmFtZSBpbiBtYXBcbiAgICAgICYmIG1hcFtzZXJpZXNOb2RlLm5hbWVdID09PSB0Zi5ncmFwaC5TZXJpZXNHcm91cGluZ1R5cGUuVU5HUk9VUCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBoaWVyYXJjaHkuc2V0Tm9kZShzZXJpZXNOYW1lLCBzZXJpZXNOb2RlKTsgLy8gYWRkIHRvIHRoZSBpbmRleFxuICAgIG1ldGFncmFwaC5zZXROb2RlKHNlcmllc05hbWUsIHNlcmllc05vZGUpO1xuICAgIF8uZWFjaChub2RlTWVtYmVyTmFtZXMsIG4gPT4ge1xuICAgICAgbGV0IGNoaWxkID0gPE9wTm9kZT4gbWV0YWdyYXBoLm5vZGUobik7XG4gICAgICBzZXJpZXNOb2RlLm1ldGFncmFwaC5zZXROb2RlKG4sIGNoaWxkKTtcbiAgICAgIHNlcmllc05vZGUucGFyZW50Tm9kZSA9IGNoaWxkLnBhcmVudE5vZGU7XG4gICAgICBzZXJpZXNOb2RlLmNhcmRpbmFsaXR5Kys7XG4gICAgICBpZiAoY2hpbGQuZGV2aWNlICE9IG51bGwpIHtcbiAgICAgICAgc2VyaWVzTm9kZS5kZXZpY2VIaXN0b2dyYW1bY2hpbGQuZGV2aWNlXSA9XG4gICAgICAgICAgICAoc2VyaWVzTm9kZS5kZXZpY2VIaXN0b2dyYW1bY2hpbGQuZGV2aWNlXSB8fCAwKSArIDE7XG4gICAgICB9XG4gICAgICBpZiAoY2hpbGQueGxhQ2x1c3RlciAhPSBudWxsKSB7XG4gICAgICAgIHNlcmllc05vZGUueGxhQ2x1c3Rlckhpc3RvZ3JhbVtjaGlsZC54bGFDbHVzdGVyXSA9XG4gICAgICAgICAgICAoc2VyaWVzTm9kZS54bGFDbHVzdGVySGlzdG9ncmFtW2NoaWxkLnhsYUNsdXN0ZXJdIHx8IDApICsgMTtcbiAgICAgIH1cblxuICAgICAgLy8gSW5jcmVtZW50IHBhcmVudHMgYXBwcm9wcmlhdGUgY29tcGF0aWJpbGl0eSBjb3VudFxuICAgICAgaWYgKGNoaWxkLmNvbXBhdGlibGUpIHtcbiAgICAgICAgc2VyaWVzTm9kZS5jb21wYXRpYmlsaXR5SGlzdG9ncmFtLmNvbXBhdGlibGUgPVxuICAgICAgICAgICAgKHNlcmllc05vZGUuY29tcGF0aWJpbGl0eUhpc3RvZ3JhbS5jb21wYXRpYmxlIHx8IDApICsgMTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHNlcmllc05vZGUuY29tcGF0aWJpbGl0eUhpc3RvZ3JhbS5pbmNvbXBhdGlibGUgPVxuICAgICAgICAgICAgKHNlcmllc05vZGUuY29tcGF0aWJpbGl0eUhpc3RvZ3JhbS5pbmNvbXBhdGlibGUgfHwgMCkgKyAxO1xuICAgICAgfVxuXG4gICAgICAvLyBJbmNyZW1lbnQgY2FwYWJpbGl0eSBjb3VudHMgZm9yIGluIGFuZCBvdXQgZW1iZWRkaW5nc1xuICAgICAgXy5lYWNoKGNoaWxkLmluRW1iZWRkaW5ncywgKGluTm9kZSkgPT4ge1xuICAgICAgICBpZiAoaW5Ob2RlLmNvbXBhdGlibGUpIHtcbiAgICAgICAgICBzZXJpZXNOb2RlLmNvbXBhdGliaWxpdHlIaXN0b2dyYW0uY29tcGF0aWJsZSA9XG4gICAgICAgICAgICAgIChzZXJpZXNOb2RlLmNvbXBhdGliaWxpdHlIaXN0b2dyYW0uY29tcGF0aWJsZSB8fCAwKSArIDE7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgc2VyaWVzTm9kZS5jb21wYXRpYmlsaXR5SGlzdG9ncmFtLmluY29tcGF0aWJsZSA9XG4gICAgICAgICAgICAgIChzZXJpZXNOb2RlLmNvbXBhdGliaWxpdHlIaXN0b2dyYW0uaW5jb21wYXRpYmxlIHx8IDApICsgMTtcbiAgICAgICAgfVxuICAgICAgfSk7XG5cbiAgICAgIF8uZWFjaChjaGlsZC5vdXRFbWJlZGRpbmdzLCAob3V0Tm9kZSkgPT4ge1xuICAgICAgICBpZiAob3V0Tm9kZS5jb21wYXRpYmxlKSB7XG4gICAgICAgICAgc2VyaWVzTm9kZS5jb21wYXRpYmlsaXR5SGlzdG9ncmFtLmNvbXBhdGlibGUgPVxuICAgICAgICAgICAgICAoc2VyaWVzTm9kZS5jb21wYXRpYmlsaXR5SGlzdG9ncmFtLmNvbXBhdGlibGUgfHwgMCkgKyAxO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHNlcmllc05vZGUuY29tcGF0aWJpbGl0eUhpc3RvZ3JhbS5pbmNvbXBhdGlibGUgPVxuICAgICAgICAgICAgICAoc2VyaWVzTm9kZS5jb21wYXRpYmlsaXR5SGlzdG9ncmFtLmluY29tcGF0aWJsZSB8fCAwKSArIDE7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuXG4gICAgICBjaGlsZC5wYXJlbnROb2RlID0gc2VyaWVzTm9kZTtcbiAgICAgIHNlcmllc05hbWVzW25dID0gc2VyaWVzTmFtZTtcbiAgICAgIC8vIFJlbW92ZSBub3ctZ3JvdXBlZCBub2RlIGZyb20gaXRzIG9yaWdpbmFsIHBhcmVudCdzIG1ldGFncmFwaC5cbiAgICAgIG1ldGFncmFwaC5yZW1vdmVOb2RlKG4pO1xuICAgIH0pO1xuICB9KTtcbn07XG5cbi8qKiBjbHVzdGVyIG9wLW5vZGVzIHdpdGggc2ltaWxhciBvcCAqL1xuZnVuY3Rpb24gY2x1c3Rlck5vZGVzKG1ldGFncmFwaDogZ3JhcGhsaWIuR3JhcGg8R3JvdXBOb2RlfE9wTm9kZSwgTWV0YWVkZ2U+KTpcbiAgICB7W2NsdXN0ZXJJZDogc3RyaW5nXTogc3RyaW5nW119IHtcbiAgbGV0IHJlc3VsdDoge1tjbHVzdGVySWQ6IHN0cmluZ106IHN0cmluZ1tdfSA9IHt9O1xuICByZXR1cm4gIF8ucmVkdWNlKG1ldGFncmFwaC5ub2RlcygpLFxuICAgICAgKGNsdXN0ZXJzOiB7W2NsdXN0ZXJJZDogc3RyaW5nXTogc3RyaW5nW119LCBuOiBzdHJpbmcpID0+IHtcbiAgICBsZXQgY2hpbGQgPSBtZXRhZ3JhcGgubm9kZShuKTtcbiAgICBpZiAoY2hpbGQudHlwZSA9PT0gTm9kZVR5cGUuTUVUQSkge1xuICAgICAgLy8gc2tpcCBtZXRhbm9kZXNcbiAgICAgIHJldHVybiBjbHVzdGVycztcbiAgICB9XG4gICAgbGV0IHRlbXBsYXRlID0gKDxPcE5vZGU+Y2hpbGQpLm9wO1xuICAgIGlmICh0ZW1wbGF0ZSkge1xuICAgICAgY2x1c3RlcnNbdGVtcGxhdGVdID0gY2x1c3RlcnNbdGVtcGxhdGVdIHx8IFtdO1xuICAgICAgY2x1c3RlcnNbdGVtcGxhdGVdLnB1c2goY2hpbGQubmFtZSk7XG4gICAgfVxuICAgIHJldHVybiBjbHVzdGVycztcbiAgfSwgcmVzdWx0KTtcbn1cblxuLyoqXG4gKiBGb3IgZWFjaCBjbHVzdGVyIG9mIG9wLW5vZGVzIGJhc2VkIG9wIHR5cGUsIHRyeSB0byBkZXRlY3QgZ3JvdXBpbmdzLlxuICogSW5mZXIgc2VyaWVzIG5hbWUgdXNpbmcgYnkgdHJ5aW5nIHRvIGZpbmQgcGF0dGVybiAnPG51bWJlcj4nIHRvd2FyZHMgdGhlIGVuZFxuICogb2Ygbm9kZSBuYW1lcy5cbiAqXG4gKiBAcGFyYW0gY2x1c3RlcnMgRGljdGlvbmFyeSBvdXRwdXQgZnJvbSBjbHVzdGVyTm9kZXMoKS5cbiAqIEBwYXJhbSBtZXRhZ3JhcGhcbiAqIEByZXR1cm4gQSBkaWN0aW9uYXJ5IGZyb20gc2VyaWVzIG5hbWUgPT4gc2VyaWVzTm9kZVxuICovXG5mdW5jdGlvbiBkZXRlY3RTZXJpZXNVc2luZ051bWVyaWNTdWZmaXhlcyhcbiAgICBjbHVzdGVyczoge1tjbHVzdGVySWQ6IHN0cmluZ106IHN0cmluZ1tdfSxcbiAgICBtZXRhZ3JhcGg6IGdyYXBobGliLkdyYXBoPEdyb3VwTm9kZXxPcE5vZGUsIE1ldGFlZGdlPixcbiAgICBncmFwaE9wdGlvbnM6IGdyYXBobGliLkdyYXBoT3B0aW9ucyk6XG4gICAgIHtbc2VyaWVzTmFtZTogc3RyaW5nXTogU2VyaWVzTm9kZX0ge1xuICBsZXQgc2VyaWVzRGljdDoge1tzZXJpZXNOYW1lOiBzdHJpbmddOiBTZXJpZXNOb2RlfSA9IHt9O1xuICBfLmVhY2goY2x1c3RlcnMsIGZ1bmN0aW9uKG1lbWJlcnMsIGNsdXN0ZXJJZDogc3RyaW5nKSB7XG4gICAgaWYgKG1lbWJlcnMubGVuZ3RoIDw9IDEpIHsgcmV0dXJuOyB9IC8vIGlzb2xhdGVkIGNsdXN0ZXJzIGNhbid0IG1ha2Ugc2VyaWVzXG4gICAgLyoqIEB0eXBlIHtPYmplY3R9ICBBIGRpY3Rpb25hcnkgbWFwcGluZyBzZXJpZXNOYW1lIHRvIHNlcmllc0luZm9BcnJheSxcbiAgICAgKiB3aGljaCBpcyBhbiBhcnJheSB0aGF0IGNvbnRhaW5zIG9iamVjdHMgd2l0aCBuYW1lLCBpZCwgcHJlZml4LCBzdWZmaXgsXG4gICAgICogYW5kIHBhcmVudCBwcm9wZXJ0aWVzLlxuICAgICAqL1xuICAgIGxldCBjYW5kaWRhdGVzRGljdDoge1tzZXJpZXNOYW1lOiBzdHJpbmddOiBTZXJpZXNOb2RlW119ID0ge307XG5cbiAgICAvLyBHcm91cCBhbGwgbm9kZXMgdGhhdCBoYXZlIHRoZSBzYW1lIG5hbWUsIHdpdGggdGhlIGV4Y2VwdGlvbiBvZiBhXG4gICAgLy8gbnVtYmVyIGF0IHRoZSBlbmQgb2YgdGhlIG5hbWUgYWZ0ZXIgYW4gdW5kZXJzY29yZSwgd2hpY2ggaXMgYWxsb3dlZCB0b1xuICAgIC8vIHZhcnkuXG4gICAgXy5lYWNoKG1lbWJlcnMsIGZ1bmN0aW9uKG5hbWU6IHN0cmluZykge1xuICAgICAgbGV0IGlzR3JvdXAgPSBuYW1lLmNoYXJBdChuYW1lLmxlbmd0aCAtIDEpID09PSAnKic7XG4gICAgICBsZXQgbmFtZXBhdGggPSBuYW1lLnNwbGl0KCcvJyk7XG4gICAgICBsZXQgbGVhZiA9IG5hbWVwYXRoW25hbWVwYXRoLmxlbmd0aCAtIDFdO1xuICAgICAgbGV0IHBhcmVudCA9IG5hbWVwYXRoLnNsaWNlKDAsIG5hbWVwYXRoLmxlbmd0aCAtIDEpLmpvaW4oJy8nKTtcbiAgICAgIGxldCBtYXRjaGVzID0gbGVhZi5tYXRjaCgvXihcXEQqKV8oXFxkKykkLyk7XG5cbiAgICAgIGxldCBwcmVmaXg7XG4gICAgICBsZXQgaWQ7XG4gICAgICBsZXQgc3VmZml4ID0gJyc7XG4gICAgICBpZiAobWF0Y2hlcykgeyAgICAgICAgIC8vIGlmIGZvdW5kICc8bnVtYmVyPicgaW4gdGhlIG5hbWUsIGFzc2lnbiBpZC5cbiAgICAgICAgcHJlZml4ID0gbWF0Y2hlc1sxXTsgLy8gdGhlIGZyb250IG5vbi1udW1lcmljIGNoYXJhY3RlcnNcbiAgICAgICAgaWQgPSBtYXRjaGVzWzJdOyAvLyB0aGUgZGlnaXRzXG4gICAgICB9IGVsc2UgeyAgLy8gZm9yIG5vZGUgd2l0aG91dCAnXzxudW1iZXI+JywgbWFrZSB0aGVtIHplcm8tdGggaXRlbXMuXG4gICAgICAgIHByZWZpeCA9IGlzR3JvdXAgPyBsZWFmLnN1YnN0cigwLCBsZWFmLmxlbmd0aCAtIDEpIDogbGVhZjtcbiAgICAgICAgaWQgPSAwO1xuICAgICAgICBzdWZmaXggPSBpc0dyb3VwID8gJyonIDogJyc7XG4gICAgICB9XG4gICAgICBsZXQgc2VyaWVzTmFtZSA9IGdldFNlcmllc05vZGVOYW1lKHByZWZpeCwgc3VmZml4LCBwYXJlbnQpO1xuICAgICAgY2FuZGlkYXRlc0RpY3Rbc2VyaWVzTmFtZV0gPSBjYW5kaWRhdGVzRGljdFtzZXJpZXNOYW1lXSB8fCBbXTtcbiAgICAgIGxldCBzZXJpZXNOb2RlID0gY3JlYXRlU2VyaWVzTm9kZShcbiAgICAgICAgICBwcmVmaXgsIHN1ZmZpeCwgcGFyZW50LCAraWQsIG5hbWUsIGdyYXBoT3B0aW9ucyk7XG4gICAgICBjYW5kaWRhdGVzRGljdFtzZXJpZXNOYW1lXS5wdXNoKHNlcmllc05vZGUpO1xuICAgIH0pO1xuXG4gICAgLy8gSW4gZWFjaCBncm91cCBvZiBub2RlcywgZ3JvdXAgbm9kZXMgaW4gYnVuY2hlcyB0aGF0IGhhdmUgbW9ub3RvbmljYWxseVxuICAgIC8vIGluY3JlYXNpbmcgbnVtYmVycyBpbiB0aGVpciBuYW1lcy4gIEVhY2ggb2YgdGhlc2UgYnVuY2hlcyBpcyBhIHNlcmllcy5cbiAgICBfLmVhY2goY2FuZGlkYXRlc0RpY3QsIGZ1bmN0aW9uKHNlcmllc0luZm9BcnJheTogU2VyaWVzTm9kZVtdLCBzZXJpZXNOYW1lKSB7XG4gICAgICBpZiAoc2VyaWVzSW5mb0FycmF5Lmxlbmd0aCA8IDIpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgc2VyaWVzSW5mb0FycmF5LnNvcnQoZnVuY3Rpb24oYSwgYikge1xuICAgICAgICByZXR1cm4gKCthLmNsdXN0ZXJJZCkgLSAoK2IuY2x1c3RlcklkKTtcbiAgICAgIH0pO1xuXG4gICAgICAvLyBMb29wIHRocm91Z2ggdGhlIG5vZGVzIHNvcnRlZCBieSBpdHMgZGV0ZWN0ZWQgc2VyaWVzIG51bWJlciwgZ3JvdXBpbmdcbiAgICAgIC8vIGFsbCBub2RlcyB3aXRoIG1vbm90b25pY2FsbHktaW5jcmVhc2luZyBzZXJpZXMgbnVtYmVycy5cbiAgICAgIGxldCBzZXJpZXNOb2RlcyA9IFtzZXJpZXNJbmZvQXJyYXlbMF1dO1xuICAgICAgZm9yIChsZXQgaW5kZXggPSAxOyBpbmRleCA8IHNlcmllc0luZm9BcnJheS5sZW5ndGg7IGluZGV4KyspIHtcbiAgICAgICAgbGV0IG5leHROb2RlID0gc2VyaWVzSW5mb0FycmF5W2luZGV4XTtcbiAgICAgICAgaWYgKG5leHROb2RlLmNsdXN0ZXJJZCA9PT0gc2VyaWVzTm9kZXNbc2VyaWVzTm9kZXMubGVuZ3RoIC0gMV0uY2x1c3RlcklkXG4gICAgICAgICAgICArIDEpIHtcbiAgICAgICAgICBzZXJpZXNOb2Rlcy5wdXNoKG5leHROb2RlKTtcbiAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgfVxuICAgICAgICBhZGRTZXJpZXNUb0RpY3QoXG4gICAgICAgICAgICBzZXJpZXNOb2Rlcywgc2VyaWVzRGljdCwgK2NsdXN0ZXJJZCwgbWV0YWdyYXBoLCBncmFwaE9wdGlvbnMpO1xuICAgICAgICBzZXJpZXNOb2RlcyA9IFtuZXh0Tm9kZV07XG4gICAgICB9XG4gICAgICBhZGRTZXJpZXNUb0RpY3QoXG4gICAgICAgICAgc2VyaWVzTm9kZXMsIHNlcmllc0RpY3QsICtjbHVzdGVySWQsIG1ldGFncmFwaCwgZ3JhcGhPcHRpb25zKTtcbiAgICB9KTtcbiAgfSk7XG4gIHJldHVybiBzZXJpZXNEaWN0O1xufVxuXG4vKipcbiAqIEZvciBlYWNoIGNsdXN0ZXIgb2Ygb3Atbm9kZXMgYmFzZWQgb3AgdHlwZSwgdHJ5IHRvIGRldGVjdCBncm91cGluZ3MuXG4gKiBJbmZlciBzZXJpZXMgbmFtZSB1c2luZyBieSB0cnlpbmcgdG8gZmluZCBhIHBhdHRlcm4gb2YgbnVtYmVyc1xuICogYW55d2hlcmUgd2l0aGluIG5vZGUgbmFtZXMuXG4gKlxuICogQHBhcmFtIGNsdXN0ZXJzIERpY3Rpb25hcnkgb3V0cHV0IGZyb20gY2x1c3Rlck5vZGVzKCkuXG4gKiBAcGFyYW0gbWV0YWdyYXBoXG4gKiBAcmV0dXJuIEEgZGljdGlvbmFyeSBmcm9tIHNlcmllcyBuYW1lID0+IHNlcmllc05vZGVcbiAqL1xuZnVuY3Rpb24gZGV0ZWN0U2VyaWVzQW55d2hlcmVJbk5vZGVOYW1lKFxuICAgIGNsdXN0ZXJzOiB7W2NsdXN0ZXJJZDogc3RyaW5nXTogc3RyaW5nW119LFxuICAgIG1ldGFncmFwaDogZ3JhcGhsaWIuR3JhcGg8R3JvdXBOb2RlfE9wTm9kZSwgTWV0YWVkZ2U+LFxuICAgIGdyYXBoT3B0aW9uczogZ3JhcGhsaWIuR3JhcGhPcHRpb25zKTpcbiAgICAge1tzZXJpZXNOYW1lOiBzdHJpbmddOiBTZXJpZXNOb2RlfSB7XG4gIGxldCBzZXJpZXNEaWN0OiB7W3Nlcmllc05hbWU6IHN0cmluZ106IFNlcmllc05vZGV9ID0ge307XG4gIF8uZWFjaChjbHVzdGVycywgZnVuY3Rpb24obWVtYmVycywgY2x1c3RlcklkOiBzdHJpbmcpIHtcbiAgICBpZiAobWVtYmVycy5sZW5ndGggPD0gMSkgeyByZXR1cm47IH0gLy8gaXNvbGF0ZWQgY2x1c3RlcnMgY2FuJ3QgbWFrZSBzZXJpZXNcblxuICAgIC8qKlxuICAgICAqIEB0eXBlIHtPYmplY3R9ICBBIGRpY3Rpb25hcnkgbWFwcGluZyBhIHNlcmllcyBuYW1lIHRvIGEgU2VyaWVzTm9kZS5cbiAgICAgKi9cbiAgICBsZXQgZm9yd2FyZERpY3Q6IHtbc2VyaWVzTmFtZTogc3RyaW5nXTogU2VyaWVzTm9kZX0gPSB7fTtcbiAgICAvKipcbiAgICAgKiBAdHlwZSB7T2JqZWN0fSAgQSBkaWN0aW9uYXJ5IG1hcHBpbmcgbWVtYmVyIG5hbWUgdG8gYW4gYXJyYXkgb2Ygc2VyaWVzXG4gICAgICogbmFtZXMgdGhpcyBtZW1iZXIgY291bGQgcG90ZW50aWFsbHkgYmUgZ3JvdXBlZCB1bmRlciBhbmQgdGhlXG4gICAgICogY29ycmVzcG9uZGluZyBpZHMuXG4gICAgICovXG4gICAgbGV0IHJldmVyc2VEaWN0OiB7W3Nlcmllc05hbWU6IHN0cmluZ106IGFueVtdfSA9IHt9O1xuXG4gICAgLy8gR3JvdXAgYWxsIG5vZGVzIHRoYXQgaGF2ZSB0aGUgc2FtZSBuYW1lLCB3aXRoIHRoZSBleGNlcHRpb24gb2YgYVxuICAgIC8vIG51bWJlciBhdCB0aGUgZW5kIG9mIHRoZSBuYW1lIGFmdGVyIGFuIHVuZGVyc2NvcmUsIHdoaWNoIGlzIGFsbG93ZWQgdG9cbiAgICAvLyB2YXJ5LlxuICAgIF8uZWFjaChtZW1iZXJzLCBmdW5jdGlvbihuYW1lOiBzdHJpbmcpIHtcbiAgICAgIGxldCBpc0dyb3VwID0gbmFtZS5jaGFyQXQobmFtZS5sZW5ndGggLSAxKSA9PT0gJyonO1xuICAgICAgbGV0IG5hbWVwYXRoID0gbmFtZS5zcGxpdCgnLycpO1xuICAgICAgbGV0IGxlYWYgPSBuYW1lcGF0aFtuYW1lcGF0aC5sZW5ndGggLSAxXTtcbiAgICAgIGxldCBwYXJlbnQgPSBuYW1lcGF0aC5zbGljZSgwLCBuYW1lcGF0aC5sZW5ndGggLSAxKS5qb2luKCcvJyk7XG5cbiAgICAgIGNvbnN0IG51bVJlZ2V4ID0gLyhcXGQrKS9nO1xuICAgICAgbGV0IG1hdGNoZXMgPSBbXTtcbiAgICAgIGxldCBtYXRjaFJlc3VsdDtcbiAgICAgIGxldCBwcmVmaXg7XG4gICAgICBsZXQgaWQ7XG4gICAgICBsZXQgc3VmZml4O1xuICAgICAgbGV0IHNlcmllc05hbWU7XG4gICAgICBsZXQgbWF0Y2hlZCA9IDA7XG4gICAgICAvLyBTY2FuIG92ZXIgdGhlIGVudGlyZSBsZWFmIG5hbWUgYW5kIG1hdGNoIGFueSBwb3NzaWJsZSBudW1iZXJzLFxuICAgICAgLy8gYW5kIHB1dCB0aGUgcmVzdWx0cyBpbnRvIGNvcnJlc3BvbmRpbmcgZGljdGlvbmFyaWVzLlxuICAgICAgd2hpbGUgKG1hdGNoUmVzdWx0ID0gbnVtUmVnZXguZXhlYyhsZWFmKSkge1xuICAgICAgICArK21hdGNoZWQ7XG4gICAgICAgIHByZWZpeCA9IGxlYWYuc2xpY2UoMCwgbWF0Y2hSZXN1bHQuaW5kZXgpO1xuICAgICAgICBpZCA9IG1hdGNoUmVzdWx0WzBdO1xuICAgICAgICBzdWZmaXggPSBsZWFmLnNsaWNlKG1hdGNoUmVzdWx0LmluZGV4ICsgbWF0Y2hSZXN1bHRbMF0ubGVuZ3RoKTtcbiAgICAgICAgc2VyaWVzTmFtZSA9IGdldFNlcmllc05vZGVOYW1lKHByZWZpeCwgc3VmZml4LCBwYXJlbnQpO1xuICAgICAgICBmb3J3YXJkRGljdFtzZXJpZXNOYW1lXSA9IGZvcndhcmREaWN0W3Nlcmllc05hbWVdO1xuICAgICAgICBpZiAoIWZvcndhcmREaWN0W3Nlcmllc05hbWVdKSB7XG4gICAgICAgICAgZm9yd2FyZERpY3Rbc2VyaWVzTmFtZV0gPSBjcmVhdGVTZXJpZXNOb2RlKFxuICAgICAgICAgICAgcHJlZml4LCBzdWZmaXgsIHBhcmVudCwgK2lkLCBuYW1lLCBncmFwaE9wdGlvbnMpO1xuICAgICAgICB9XG4gICAgICAgIGZvcndhcmREaWN0W3Nlcmllc05hbWVdLmlkcy5wdXNoKGlkKTtcbiAgICAgICAgcmV2ZXJzZURpY3RbbmFtZV0gPSByZXZlcnNlRGljdFtuYW1lXSB8fCBbXTtcbiAgICAgICAgcmV2ZXJzZURpY3RbbmFtZV0ucHVzaChbc2VyaWVzTmFtZSwgaWRdKTtcbiAgICAgIH1cbiAgICAgIGlmIChtYXRjaGVkIDwgMSkge1xuICAgICAgICBwcmVmaXggPSBpc0dyb3VwID8gbGVhZi5zdWJzdHIoMCwgbGVhZi5sZW5ndGggLSAxKSA6IGxlYWY7XG4gICAgICAgIGlkID0gMDtcbiAgICAgICAgc3VmZml4ID0gaXNHcm91cCA/ICcqJyA6ICcnO1xuICAgICAgICBzZXJpZXNOYW1lID0gZ2V0U2VyaWVzTm9kZU5hbWUocHJlZml4LCBzdWZmaXgsIHBhcmVudCk7XG4gICAgICAgIGZvcndhcmREaWN0W3Nlcmllc05hbWVdID0gZm9yd2FyZERpY3Rbc2VyaWVzTmFtZV07XG4gICAgICAgIGlmICghZm9yd2FyZERpY3Rbc2VyaWVzTmFtZV0pIHtcbiAgICAgICAgICBmb3J3YXJkRGljdFtzZXJpZXNOYW1lXSA9IGNyZWF0ZVNlcmllc05vZGUoXG4gICAgICAgICAgICBwcmVmaXgsIHN1ZmZpeCwgcGFyZW50LCAraWQsIG5hbWUsIGdyYXBoT3B0aW9ucyk7XG4gICAgICAgIH1cbiAgICAgICAgZm9yd2FyZERpY3Rbc2VyaWVzTmFtZV0uaWRzLnB1c2goaWQpO1xuICAgICAgICByZXZlcnNlRGljdFtuYW1lXSA9IHJldmVyc2VEaWN0W25hbWVdIHx8IFtdO1xuICAgICAgICByZXZlcnNlRGljdFtuYW1lXS5wdXNoKFtzZXJpZXNOYW1lLCBpZF0pO1xuICAgICAgfVxuICAgIH0pO1xuICAgIC8qKiBAdHlwZSB7T2JqZWN0fSAgQSBkaWN0aW9uYXJ5IG1hcHBpbmcgc2VyaWVzTmFtZSB0byBzZXJpZXNJbmZvQXJyYXksXG4gICAgICogd2hpY2ggaXMgYW4gYXJyYXkgdGhhdCBjb250YWlucyBvYmplY3RzIHdpdGggbmFtZSwgaWQsIHByZWZpeCwgc3VmZml4LFxuICAgICAqIGFuZCBwYXJlbnQgcHJvcGVydGllcy5cbiAgICAgKi9cbiAgICB2YXIgY2FuZGlkYXRlc0RpY3Q6IHtbc2VyaWVzTmFtZTogc3RyaW5nXTogU2VyaWVzTm9kZVtdfSA9IHt9O1xuICAgIC8vIEZvciBlYWNoIG9mIHRoZSBtZW1iZXIsIHB1dCBpdCBpbnRvIHRoZSBtYXhpbXVtIHBvc3NpYmxlIHNlcmllcyxcbiAgICAvLyBhbmQgY3JlYXRlIGNhbmRpZGF0ZXNEaWN0IGFjY29yZGluZ2x5LlxuICAgIF8uZWFjaChyZXZlcnNlRGljdCwgZnVuY3Rpb24gKHNlcmllc05hbWVJZEFycmF5LCBuYW1lKSB7XG4gICAgICBzZXJpZXNOYW1lSWRBcnJheS5zb3J0KGZ1bmN0aW9uIChhLCBiKSB7XG4gICAgICAgICAgcmV0dXJuIChmb3J3YXJkRGljdFtiWzBdXS5pZHMubGVuZ3RoKSAtIChmb3J3YXJkRGljdFthWzBdXS5pZHMubGVuZ3RoKTtcbiAgICAgIH0pO1xuICAgICAgdmFyIHNlcmllc05hbWUgPSBzZXJpZXNOYW1lSWRBcnJheVswXVswXTtcbiAgICAgIHZhciBpZCA9IHNlcmllc05hbWVJZEFycmF5WzBdWzFdO1xuICAgICAgY2FuZGlkYXRlc0RpY3Rbc2VyaWVzTmFtZV0gPSBjYW5kaWRhdGVzRGljdFtzZXJpZXNOYW1lXSB8fCBbXTtcbiAgICAgIGNvbnN0IG5hbWVwYXRoID0gbmFtZS5zcGxpdCgnLycpO1xuICAgICAgY29uc3QgbGVhZiA9IG5hbWVwYXRoW25hbWVwYXRoLmxlbmd0aCAtIDFdO1xuICAgICAgY29uc3QgcGFyZW50ID0gbmFtZXBhdGguc2xpY2UoMCwgbmFtZXBhdGgubGVuZ3RoIC0gMSkuam9pbignLycpO1xuICAgICAgdmFyIHNlcmllc05vZGUgPSBjcmVhdGVTZXJpZXNOb2RlKFxuICAgICAgICAgIGZvcndhcmREaWN0W3Nlcmllc05hbWVdLnByZWZpeCxcbiAgICAgICAgICBmb3J3YXJkRGljdFtzZXJpZXNOYW1lXS5zdWZmaXgsXG4gICAgICAgICAgcGFyZW50LFxuICAgICAgICAgICtpZCxcbiAgICAgICAgICBuYW1lLFxuICAgICAgICAgIGdyYXBoT3B0aW9ucyk7XG4gICAgICBjYW5kaWRhdGVzRGljdFtzZXJpZXNOYW1lXS5wdXNoKHNlcmllc05vZGUpO1xuICAgIH0pO1xuXG4gICAgLy8gSW4gZWFjaCBncm91cCBvZiBub2RlcywgZ3JvdXAgbm9kZXMgaW4gYnVuY2hlcyB0aGF0IGhhdmUgbW9ub3RvbmljYWxseVxuICAgIC8vIGluY3JlYXNpbmcgbnVtYmVycyBpbiB0aGVpciBuYW1lcy4gIEVhY2ggb2YgdGhlc2UgYnVuY2hlcyBpcyBhIHNlcmllcy5cbiAgICBfLmVhY2goY2FuZGlkYXRlc0RpY3QsIGZ1bmN0aW9uKHNlcmllc0luZm9BcnJheTogU2VyaWVzTm9kZVtdLCBzZXJpZXNOYW1lKSB7XG4gICAgICBpZiAoc2VyaWVzSW5mb0FycmF5Lmxlbmd0aCA8IDIpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgc2VyaWVzSW5mb0FycmF5LnNvcnQoZnVuY3Rpb24oYSwgYikge1xuICAgICAgICByZXR1cm4gKCthLmNsdXN0ZXJJZCkgLSAoK2IuY2x1c3RlcklkKTtcbiAgICAgIH0pO1xuXG4gICAgICAvLyBMb29wIHRocm91Z2ggdGhlIG5vZGVzIHNvcnRlZCBieSBpdHMgZGV0ZWN0ZWQgc2VyaWVzIG51bWJlciwgZ3JvdXBpbmdcbiAgICAgIC8vIGFsbCBub2RlcyB3aXRoIG1vbm90b25pY2FsbHktaW5jcmVhc2luZyBzZXJpZXMgbnVtYmVycy5cbiAgICAgIGxldCBzZXJpZXNOb2RlcyA9IFtzZXJpZXNJbmZvQXJyYXlbMF1dO1xuICAgICAgZm9yIChsZXQgaW5kZXggPSAxOyBpbmRleCA8IHNlcmllc0luZm9BcnJheS5sZW5ndGg7IGluZGV4KyspIHtcbiAgICAgICAgbGV0IG5leHROb2RlID0gc2VyaWVzSW5mb0FycmF5W2luZGV4XTtcbiAgICAgICAgaWYgKG5leHROb2RlLmNsdXN0ZXJJZCA9PT0gc2VyaWVzTm9kZXNbc2VyaWVzTm9kZXMubGVuZ3RoIC0gMV0uY2x1c3RlcklkXG4gICAgICAgICAgICArIDEpIHtcbiAgICAgICAgICBzZXJpZXNOb2Rlcy5wdXNoKG5leHROb2RlKTtcbiAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgfVxuICAgICAgICBhZGRTZXJpZXNUb0RpY3QoXG4gICAgICAgICAgICBzZXJpZXNOb2Rlcywgc2VyaWVzRGljdCwgK2NsdXN0ZXJJZCwgbWV0YWdyYXBoLCBncmFwaE9wdGlvbnMpO1xuICAgICAgICBzZXJpZXNOb2RlcyA9IFtuZXh0Tm9kZV07XG4gICAgICB9XG4gICAgICBhZGRTZXJpZXNUb0RpY3QoXG4gICAgICAgICAgc2VyaWVzTm9kZXMsIHNlcmllc0RpY3QsICtjbHVzdGVySWQsIG1ldGFncmFwaCwgZ3JhcGhPcHRpb25zKTtcbiAgICB9KTtcbiAgfSk7XG4gIHJldHVybiBzZXJpZXNEaWN0O1xufVxuXG4vKipcbiAqIEFkZCBhIHNlcmllcyB0byB0aGUgcHJvdmlkZWQgZGljdGlvbmFyeSBtYXBwaW5nIHNlcmllcyBuYW1lcyB0byBzZXJpZXMuXG4gKlxuICogQHBhcmFtIHNlcmllc05vZGVzIHRoZSBub2RlcyBpbiB0aGUgc2VyaWVzLiBDb250YWluc1xuICogICAgIG5hbWUsIGlkLCBwcmVmaXgsIHN1ZmZpeCBhbmQgcGFyZW50IHByb3BlcnRpZXMgb2YgdGhlIG5vZGUuXG4gKiBAcGFyYW0gc2VyaWVzRGljdCB0aGUgZGljdGlvbmFyeSBvZiBzZXJpZXNcbiAqIEBwYXJhbSBjbHVzdGVySWQgSUQgb2YgdGhlIHRlbXBsYXRlIG9mIHRoZSBub2RlcyBvZiB0aGUgc2VyaWVzXG4gKiBAcGFyYW0gbWV0YWdyYXBoXG4gKiBAcGFyYW0gZ3JhcGhPcHRpb25zXG4gKi9cbmZ1bmN0aW9uIGFkZFNlcmllc1RvRGljdChzZXJpZXNOb2RlczogU2VyaWVzTm9kZVtdLFxuICAgIHNlcmllc0RpY3Q6IHtbc2VyaWVzTmFtZTogc3RyaW5nXTogU2VyaWVzTm9kZX0sXG4gICAgY2x1c3RlcklkOiBudW1iZXIsXG4gICAgbWV0YWdyYXBoOiBncmFwaGxpYi5HcmFwaDxHcm91cE5vZGV8T3BOb2RlLCBNZXRhZWRnZT4sXG4gICAgZ3JhcGhPcHRpb25zOiBncmFwaGxpYi5HcmFwaE9wdGlvbnMpIHtcbiAgaWYgKHNlcmllc05vZGVzLmxlbmd0aCA+IDEpIHtcbiAgICBsZXQgY3VyU2VyaWVzTmFtZSA9IGdldFNlcmllc05vZGVOYW1lKFxuICAgICAgc2VyaWVzTm9kZXNbMF0ucHJlZml4LCBzZXJpZXNOb2Rlc1swXS5zdWZmaXgsXG4gICAgICBzZXJpZXNOb2Rlc1swXS5wYXJlbnQsIHNlcmllc05vZGVzWzBdLmNsdXN0ZXJJZCxcbiAgICAgIHNlcmllc05vZGVzW3Nlcmllc05vZGVzLmxlbmd0aCAtIDFdLmNsdXN0ZXJJZCk7XG4gICAgbGV0IGN1clNlcmllc05vZGUgPSBjcmVhdGVTZXJpZXNOb2RlKHNlcmllc05vZGVzWzBdLnByZWZpeCxcbiAgICAgIHNlcmllc05vZGVzWzBdLnN1ZmZpeCwgc2VyaWVzTm9kZXNbMF0ucGFyZW50LCBjbHVzdGVySWQsXG4gICAgICBjdXJTZXJpZXNOYW1lLCBncmFwaE9wdGlvbnMpO1xuICAgIF8uZWFjaChzZXJpZXNOb2RlcywgZnVuY3Rpb24obm9kZSkge1xuICAgICAgY3VyU2VyaWVzTm9kZS5pZHMucHVzaChub2RlLmNsdXN0ZXJJZCk7XG4gICAgICBjdXJTZXJpZXNOb2RlLm1ldGFncmFwaC5zZXROb2RlKG5vZGUubmFtZSwgbWV0YWdyYXBoLm5vZGUobm9kZS5uYW1lKSk7XG4gICAgfSk7XG4gICAgc2VyaWVzRGljdFtjdXJTZXJpZXNOYW1lXSA9IGN1clNlcmllc05vZGU7XG4gIH1cbn1cblxufSAvLyBjbG9zZSBtb2R1bGUgdGYuZ3JhcGguaGllcmFyY2h5XG4iXX0=