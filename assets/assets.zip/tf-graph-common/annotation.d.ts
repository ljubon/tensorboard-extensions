declare module tf.graph.scene.annotation {
    /**
     * Populate a given annotation container group
     *
     *     <g class='{in|out}-annotations'></g>
     *
     * with annotation group of the following structure:
     *
     * <g class='annotation'>
     *   <g class='annotation-node'>
     *   <!--
     *   Content here determined by Scene.node.buildGroup.
     *   -->
     *   </g>
     * </g>
     *
     * @param container selection of the container.
     * @param annotationData node.{in|out}Annotations
     * @param d node to build group for.
     * @param sceneElement <tf-graph-scene> polymer element.
     * @return selection of appended objects
     */
    function buildGroup(container: any, annotationData: render.AnnotationList, d: render.RenderNodeInfo, sceneElement: any): any;
}
