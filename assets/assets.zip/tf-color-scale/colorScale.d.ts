declare namespace tf_color_scale {
    class ColorScale {
        private readonly palette;
        private identifiers;
        /**
         * Creates a color scale with optional custom palette.
         * @param {Array<string>} palette The color palette to use, as an
         *   Array of hex strings. Defaults to the standard palette.
         */
        constructor(palette?: string[]);
        /**
         * Set the domain of strings.
         * @param {Array<string>} strings - An array of possible strings to use as the
         *     domain for your scale.
         */
        setDomain(strings: string[]): this;
        /**
         * Use the color scale to transform an element in the domain into a color.
         * @param {string} The input string to map to a color.
         * @return {string} The color corresponding to that input string.
         * @throws Will error if input string is not in the scale's domain.
         */
        getColor(s: string): string;
    }
    const runsColorScale: (runName: string) => string;
    const experimentsColorScale: (runName: string) => string;
}
