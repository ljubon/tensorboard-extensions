/* Copyright 2018 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the 'License');
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an 'AS IS' BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
var tf_data_selector;
(function (tf_data_selector) {
    var Type;
    (function (Type) {
        Type[Type["RUN"] = 1] = "RUN";
        Type[Type["TAG"] = 2] = "TAG";
    })(Type || (Type = {}));
    var MAX_RUNS_TO_ENABLE_BY_DEFAULT = 20;
    Polymer({
        is: 'tf-data-select-row',
        properties: {
            experiment: {
                type: Object,
                value: function () { return ({
                    id: null,
                    name: 'Unknown experiment',
                    startTime: null,
                }); },
            },
            enabled: {
                type: Boolean,
                notify: true,
                value: true,
            },
            checkboxColor: {
                type: String,
                value: '',
            },
            // Required field.
            persistenceId: String,
            noExperiment: {
                type: Boolean,
                value: false,
            },
            shouldColorRuns: {
                type: Boolean,
                value: false,
            },
            _coloring: {
                type: Object,
                computed: '_getColoring(shouldColorRuns)',
            },
            _runs: {
                type: Array,
                value: function () { return []; },
            },
            _runSelectionStateString: { type: String, value: '' },
            // ListItem requires `id` and it is synthesized from name when it is in the
            // `noExperiment` mode.
            _selectedRuns: {
                type: Array,
                value: function () { return []; },
            },
            _tagRegex: {
                type: String,
                value: '',
                observer: '_persistRegex',
            },
            _storageBinding: {
                type: Object,
                value: function () { return null; },
            },
        },
        listeners: {
            'dom-change': '_synchronizeColors',
        },
        observers: [
            '_immutablePropInvarianceViolated(persistenceId.*)',
            '_immutablePropInvarianceViolated(experiment.*)',
            '_synchronizeColors(checkboxColor)',
            '_persistSelectedRuns(_selectedRuns)',
            '_fireChange(_selectedRuns, _tagRegex)',
        ],
        _getPersistenceKey: function (type) {
            var id = this.persistenceId;
            switch (type) {
                case Type.RUN:
                    // Prefix with 'g' to denote a group.
                    return "gr" + id;
                case Type.TAG:
                    return "gt" + id;
            }
        },
        attached: function () {
            var _this = this;
            if (this.persistenceId == null) {
                throw new RangeError('Required `persistenceId` missing');
            }
            this._initFromStorage();
            this._initRunsAndTags()
                .then(function () {
                if (_this._runSelectionStateString)
                    return;
                var val = _this._runs.length <= MAX_RUNS_TO_ENABLE_BY_DEFAULT ?
                    tf_data_selector.STORAGE_ALL_VALUE : tf_data_selector.STORAGE_NONE_VALUE;
                _this._storageBinding.set(_this._getPersistenceKey(Type.RUN), val, { defaultValue: '' });
                _this._runSelectionStateString = val;
            });
        },
        detached: function () {
            this._isDataReady = false;
            if (this._storageBinding)
                this._storageBinding.disposeBinding();
        },
        _initFromStorage: function () {
            if (this._storageBinding)
                this._storageBinding.disposeBinding();
            this._storageBinding = tf_storage.makeBindings(function (x) { return x; }, function (x) { return x; });
            var runInitializer = this._storageBinding.getInitializer(this._getPersistenceKey(Type.RUN), {
                defaultValue: '',
                polymerProperty: '_runSelectionStateString',
            });
            runInitializer.call(this);
            var tagInitializer = this._storageBinding.getInitializer(this._getPersistenceKey(Type.TAG), { defaultValue: '', polymerProperty: '_tagRegex' });
            tagInitializer.call(this);
        },
        _initRunsAndTags: function () {
            var _this = this;
            this._isDataReady = false;
            return this._fetchRunsAndTags()
                .then(function () {
                _this._isDataReady = true;
            });
        },
        _immutablePropInvarianceViolated: function (change) {
            // We allow property to change many times before the component is attached
            // to DOM.
            if (this.isAttached) {
                throw new Error("Invariance Violation: " +
                    ("Expected property '" + change.path + "' not to change."));
            }
        },
        _synchronizeColors: function () {
            var _this = this;
            var cb = this.$$('#checkbox');
            if (!cb)
                return;
            var color = this.checkboxColor;
            cb.customStyle['--paper-checkbox-checked-color'] = color;
            cb.customStyle['--paper-checkbox-checked-ink-color'] = color;
            cb.customStyle['--paper-checkbox-unchecked-color'] = color;
            cb.customStyle['--paper-checkbox-unchecked-ink-color'] = color;
            window.requestAnimationFrame(function () { return _this.updateStyles(); });
        },
        _fetchRunsAndTags: function () {
            var _this = this;
            var requestManager = new tf_backend.RequestManager();
            if (this.noExperiment) {
                var fetchRuns = requestManager.request(tf_backend.getRouter().runs());
                return Promise.all([fetchRuns]).then(function (_a) {
                    var runs = _a[0];
                    _this.set('_runs', Array.from(new Set(runs)).map(function (runName) { return ({
                        id: null,
                        name: runName,
                        startedTime: null,
                    }); }));
                });
            }
            console.assert(this.experiment.id != null, 'Expected an experiment Id');
            var url = tf_backend.getRouter().runsForExperiment(this.experiment.id);
            return requestManager.request(url).then(function (runs) {
                _this.set('_runs', runs);
            });
        },
        _getRunOptions: function (_) {
            var _this = this;
            return this._runs.map(function (run) { return ({
                // /data/runs endpoint does not return ids. In case of logdir data source,
                // runs cannot have an id and, for filtered-checkbox-list, we need to
                // synthesize id from the name.
                id: _this._getSyntheticRunId(run),
                title: run.name,
            }); });
        },
        _persistSelectedRuns: function () {
            if (!this._isDataReady)
                return;
            var value = this._serializeValue(this._runs, this._selectedRuns.map(function (_a) {
                var id = _a.id;
                return id;
            }));
            this._storageBinding.set(this._getPersistenceKey(Type.RUN), value, { defaultValue: '' });
        },
        _getRunsSelectionState: function () {
            var _this = this;
            var allIds = this._runs.map(function (r) { return _this._getSyntheticRunId(r); });
            var ids = this._deserializeValue(allIds, this._runSelectionStateString);
            var prevSelection = new Set(ids);
            var newSelection = {};
            allIds.forEach(function (id) { return newSelection[id] = prevSelection.has(id); });
            return newSelection;
        },
        _persistRegex: function () {
            if (!this._isDataReady)
                return;
            var value = this._tagRegex;
            this._storageBinding.set(this._getPersistenceKey(Type.TAG), value, { defaultValue: '' });
        },
        _fireChange: function (_, __) {
            var _this = this;
            var runMap = new Map(this._runs.map(function (run) { return [_this._getSyntheticRunId(run), run]; }));
            this.fire('selection-changed', {
                runs: this._selectedRuns.map(function (_a) {
                    var id = _a.id;
                    return runMap.get(id);
                })
                    .filter(Boolean)
                    .map(function (run) { return ({
                    id: run.id,
                    name: run.name,
                    startTime: run.startTime,
                    tags: run.tags,
                }); }),
                tagRegex: this._tagRegex,
            });
        },
        _removeRow: function () {
            // Clear persistence when being removed.
            this._storageBinding.set(this._getPersistenceKey(Type.RUN), '', { defaultValue: '' });
            this._storageBinding.set(this._getPersistenceKey(Type.TAG), '', { defaultValue: '' });
            this.fire('remove');
        },
        _serializeValue: function (source, selectedIds) {
            if (selectedIds.length == source.length)
                return tf_data_selector.STORAGE_ALL_VALUE;
            if (selectedIds.length == 0)
                return tf_data_selector.STORAGE_NONE_VALUE;
            return this.noExperiment ?
                JSON.stringify(selectedIds) :
                tf_data_selector.encodeIdArray(selectedIds);
        },
        _deserializeValue: function (allValues, str) {
            if (str == tf_data_selector.STORAGE_ALL_VALUE)
                return allValues;
            if (str == tf_data_selector.STORAGE_NONE_VALUE)
                return [];
            if (!this.noExperiment)
                return tf_data_selector.decodeIdArray(str);
            var parsed = [];
            try {
                parsed = JSON.parse(str);
            }
            catch (e) {
                /* noop */
            }
            return Array.isArray(parsed) ? parsed : [];
        },
        _getColoring: function () {
            return {
                getColor: this.shouldColorRuns ?
                    function (item) { return tf_color_scale.runsColorScale(item.title); } :
                    function () { return ''; },
            };
        },
        _getSyntheticRunId: function (run) {
            return this.noExperiment ? run.name : run.id;
        },
        _fireCheckboxToggled: function () {
            this.fire('checkbox-toggle');
        },
    });
})(tf_data_selector || (tf_data_selector = {})); // namespace tf_data_selector
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGYtZGF0YS1zZWxlY3Qtcm93LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsidGYtZGF0YS1zZWxlY3Qtcm93LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7Ozs7Ozs7Ozs7O2dGQWFnRjtBQUNoRixJQUFVLGdCQUFnQixDQWdTekI7QUFoU0QsV0FBVSxnQkFBZ0I7SUFFMUIsSUFBSyxJQUdKO0lBSEQsV0FBSyxJQUFJO1FBQ1AsNkJBQU8sQ0FBQTtRQUNQLDZCQUFHLENBQUE7SUFDTCxDQUFDLEVBSEksSUFBSSxLQUFKLElBQUksUUFHUjtJQUVELElBQU0sNkJBQTZCLEdBQUcsRUFBRSxDQUFDO0lBRXpDLE9BQU8sQ0FBQztRQUNOLEVBQUUsRUFBRSxvQkFBb0I7UUFDeEIsVUFBVSxFQUFFO1lBQ1YsVUFBVSxFQUFFO2dCQUNWLElBQUksRUFBRSxNQUFNO2dCQUNaLEtBQUssRUFBRSxjQUFNLE9BQUEsQ0FBQztvQkFDWixFQUFFLEVBQUUsSUFBSTtvQkFDUixJQUFJLEVBQUUsb0JBQW9CO29CQUMxQixTQUFTLEVBQUUsSUFBSTtpQkFDaEIsQ0FBQyxFQUpXLENBSVg7YUFDSDtZQUVELE9BQU8sRUFBRTtnQkFDUCxJQUFJLEVBQUUsT0FBTztnQkFDYixNQUFNLEVBQUUsSUFBSTtnQkFDWixLQUFLLEVBQUUsSUFBSTthQUNaO1lBRUQsYUFBYSxFQUFFO2dCQUNiLElBQUksRUFBRSxNQUFNO2dCQUNaLEtBQUssRUFBRSxFQUFFO2FBQ1Y7WUFFRCxrQkFBa0I7WUFDbEIsYUFBYSxFQUFFLE1BQU07WUFFckIsWUFBWSxFQUFFO2dCQUNaLElBQUksRUFBRSxPQUFPO2dCQUNiLEtBQUssRUFBRSxLQUFLO2FBQ2I7WUFFRCxlQUFlLEVBQUU7Z0JBQ2YsSUFBSSxFQUFFLE9BQU87Z0JBQ2IsS0FBSyxFQUFFLEtBQUs7YUFDYjtZQUVELFNBQVMsRUFBRTtnQkFDVCxJQUFJLEVBQUUsTUFBTTtnQkFDWixRQUFRLEVBQUUsK0JBQStCO2FBQzFDO1lBRUQsS0FBSyxFQUFFO2dCQUNMLElBQUksRUFBRSxLQUFLO2dCQUNYLEtBQUssRUFBRSxjQUE2QixPQUFBLEVBQUUsRUFBRixDQUFFO2FBQ3ZDO1lBRUQsd0JBQXdCLEVBQUUsRUFBQyxJQUFJLEVBQUUsTUFBTSxFQUFFLEtBQUssRUFBRSxFQUFFLEVBQUM7WUFFbkQsMkVBQTJFO1lBQzNFLHVCQUF1QjtZQUN2QixhQUFhLEVBQUU7Z0JBQ2IsSUFBSSxFQUFFLEtBQUs7Z0JBQ1gsS0FBSyxFQUFFLGNBQTZELE9BQUEsRUFBRSxFQUFGLENBQUU7YUFDdkU7WUFFRCxTQUFTLEVBQUU7Z0JBQ1QsSUFBSSxFQUFFLE1BQU07Z0JBQ1osS0FBSyxFQUFFLEVBQUU7Z0JBQ1QsUUFBUSxFQUFFLGVBQWU7YUFDMUI7WUFFRCxlQUFlLEVBQUU7Z0JBQ2YsSUFBSSxFQUFFLE1BQU07Z0JBQ1osS0FBSyxFQUFFLGNBQU0sT0FBQSxJQUFJLEVBQUosQ0FBSTthQUNsQjtTQUNGO1FBRUQsU0FBUyxFQUFFO1lBQ1QsWUFBWSxFQUFFLG9CQUFvQjtTQUNuQztRQUVELFNBQVMsRUFBRTtZQUNULG1EQUFtRDtZQUNuRCxnREFBZ0Q7WUFDaEQsbUNBQW1DO1lBQ25DLHFDQUFxQztZQUNyQyx1Q0FBdUM7U0FDeEM7UUFFRCxrQkFBa0IsRUFBbEIsVUFBbUIsSUFBVTtZQUMzQixJQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDO1lBQzlCLFFBQVEsSUFBSSxFQUFFO2dCQUNaLEtBQUssSUFBSSxDQUFDLEdBQUc7b0JBQ1gscUNBQXFDO29CQUNyQyxPQUFPLE9BQUssRUFBSSxDQUFDO2dCQUNuQixLQUFLLElBQUksQ0FBQyxHQUFHO29CQUNYLE9BQU8sT0FBSyxFQUFJLENBQUM7YUFDcEI7UUFDSCxDQUFDO1FBRUQsUUFBUSxFQUFSO1lBQUEsaUJBZUM7WUFkQyxJQUFJLElBQUksQ0FBQyxhQUFhLElBQUksSUFBSSxFQUFFO2dCQUM5QixNQUFNLElBQUksVUFBVSxDQUFDLGtDQUFrQyxDQUFDLENBQUM7YUFDMUQ7WUFFRCxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztZQUN4QixJQUFJLENBQUMsZ0JBQWdCLEVBQUU7aUJBQ2xCLElBQUksQ0FBQztnQkFDSixJQUFJLEtBQUksQ0FBQyx3QkFBd0I7b0JBQUUsT0FBTztnQkFDMUMsSUFBTSxHQUFHLEdBQUcsS0FBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLElBQUksNkJBQTZCLENBQUMsQ0FBQztvQkFDNUQsaUJBQUEsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLGlCQUFBLGtCQUFrQixDQUFDO2dCQUMzQyxLQUFJLENBQUMsZUFBZSxDQUFDLEdBQUcsQ0FBQyxLQUFJLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLEdBQUcsRUFDM0QsRUFBQyxZQUFZLEVBQUUsRUFBRSxFQUFDLENBQUMsQ0FBQztnQkFDeEIsS0FBSSxDQUFDLHdCQUF3QixHQUFHLEdBQUcsQ0FBQztZQUN0QyxDQUFDLENBQUMsQ0FBQztRQUNULENBQUM7UUFFRCxRQUFRLEVBQVI7WUFDRSxJQUFJLENBQUMsWUFBWSxHQUFHLEtBQUssQ0FBQztZQUMxQixJQUFJLElBQUksQ0FBQyxlQUFlO2dCQUFFLElBQUksQ0FBQyxlQUFlLENBQUMsY0FBYyxFQUFFLENBQUM7UUFDbEUsQ0FBQztRQUVELGdCQUFnQjtZQUNkLElBQUksSUFBSSxDQUFDLGVBQWU7Z0JBQUUsSUFBSSxDQUFDLGVBQWUsQ0FBQyxjQUFjLEVBQUUsQ0FBQztZQUNoRSxJQUFJLENBQUMsZUFBZSxHQUFHLFVBQVUsQ0FBQyxZQUFZLENBQUMsVUFBQSxDQUFDLElBQUksT0FBQSxDQUFDLEVBQUQsQ0FBQyxFQUFFLFVBQUEsQ0FBQyxJQUFJLE9BQUEsQ0FBQyxFQUFELENBQUMsQ0FBQyxDQUFDO1lBQy9ELElBQU0sY0FBYyxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsY0FBYyxDQUN0RCxJQUFJLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUNqQztnQkFDRSxZQUFZLEVBQUUsRUFBRTtnQkFDaEIsZUFBZSxFQUFFLDBCQUEwQjthQUM1QyxDQUFDLENBQUM7WUFDUCxjQUFjLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQzFCLElBQU0sY0FBYyxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsY0FBYyxDQUN0RCxJQUFJLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUNqQyxFQUFDLFlBQVksRUFBRSxFQUFFLEVBQUUsZUFBZSxFQUFFLFdBQVcsRUFBQyxDQUFDLENBQUM7WUFDdEQsY0FBYyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUM1QixDQUFDO1FBRUQsZ0JBQWdCLEVBQWhCO1lBQUEsaUJBTUM7WUFMQyxJQUFJLENBQUMsWUFBWSxHQUFHLEtBQUssQ0FBQztZQUMxQixPQUFPLElBQUksQ0FBQyxpQkFBaUIsRUFBRTtpQkFDMUIsSUFBSSxDQUFDO2dCQUNKLEtBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDO1lBQzNCLENBQUMsQ0FBQyxDQUFDO1FBQ1QsQ0FBQztRQUVELGdDQUFnQyxZQUFDLE1BQU07WUFDckMsMEVBQTBFO1lBQzFFLFVBQVU7WUFDVixJQUFJLElBQUksQ0FBQyxVQUFVLEVBQUU7Z0JBQ25CLE1BQU0sSUFBSSxLQUFLLENBQUMsd0JBQXdCO3FCQUNwQyx3QkFBc0IsTUFBTSxDQUFDLElBQUkscUJBQWtCLENBQUEsQ0FBQyxDQUFDO2FBQzFEO1FBQ0gsQ0FBQztRQUVELGtCQUFrQjtZQUFsQixpQkFXQztZQVZDLElBQU0sRUFBRSxHQUFHLElBQUksQ0FBQyxFQUFFLENBQUMsV0FBVyxDQUFDLENBQUM7WUFDaEMsSUFBSSxDQUFDLEVBQUU7Z0JBQUUsT0FBTztZQUVoQixJQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDO1lBQ2pDLEVBQUUsQ0FBQyxXQUFXLENBQUMsZ0NBQWdDLENBQUMsR0FBRyxLQUFLLENBQUM7WUFDekQsRUFBRSxDQUFDLFdBQVcsQ0FBQyxvQ0FBb0MsQ0FBQyxHQUFHLEtBQUssQ0FBQztZQUM3RCxFQUFFLENBQUMsV0FBVyxDQUFDLGtDQUFrQyxDQUFDLEdBQUcsS0FBSyxDQUFDO1lBQzNELEVBQUUsQ0FBQyxXQUFXLENBQUMsc0NBQXNDLENBQUMsR0FBRyxLQUFLLENBQUM7WUFFL0QsTUFBTSxDQUFDLHFCQUFxQixDQUFDLGNBQU0sT0FBQSxLQUFJLENBQUMsWUFBWSxFQUFFLEVBQW5CLENBQW1CLENBQUMsQ0FBQztRQUMxRCxDQUFDO1FBRUQsaUJBQWlCLEVBQWpCO1lBQUEsaUJBbUJDO1lBbEJDLElBQU0sY0FBYyxHQUFHLElBQUksVUFBVSxDQUFDLGNBQWMsRUFBRSxDQUFDO1lBQ3ZELElBQUksSUFBSSxDQUFDLFlBQVksRUFBRTtnQkFDckIsSUFBTSxTQUFTLEdBQUcsY0FBYyxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsU0FBUyxFQUFFLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQztnQkFDeEUsT0FBTyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBQyxFQUFNO3dCQUFMLFlBQUk7b0JBQ3pDLEtBQUksQ0FBQyxHQUFHLENBQUMsT0FBTyxFQUFFLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsVUFBQSxPQUFPLElBQUksT0FBQSxDQUFDO3dCQUMxRCxFQUFFLEVBQUUsSUFBSTt3QkFDUixJQUFJLEVBQUUsT0FBTzt3QkFDYixXQUFXLEVBQUUsSUFBSTtxQkFDbEIsQ0FBQyxFQUp5RCxDQUl6RCxDQUFDLENBQUMsQ0FBQztnQkFDUCxDQUFDLENBQUMsQ0FBQzthQUNKO1lBRUQsT0FBTyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLEVBQUUsSUFBSSxJQUFJLEVBQUUsMkJBQTJCLENBQUMsQ0FBQztZQUV4RSxJQUFNLEdBQUcsR0FBRyxVQUFVLENBQUMsU0FBUyxFQUFFLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQztZQUN6RSxPQUFPLGNBQWMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQUEsSUFBSTtnQkFDMUMsS0FBSSxDQUFDLEdBQUcsQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUM7WUFDMUIsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDO1FBRUQsY0FBYyxFQUFkLFVBQWUsQ0FBQztZQUFoQixpQkFRQztZQVBDLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsVUFBQSxHQUFHLElBQUksT0FBQSxDQUFDO2dCQUM1QiwwRUFBMEU7Z0JBQzFFLHFFQUFxRTtnQkFDckUsK0JBQStCO2dCQUMvQixFQUFFLEVBQUUsS0FBSSxDQUFDLGtCQUFrQixDQUFDLEdBQUcsQ0FBQztnQkFDaEMsS0FBSyxFQUFFLEdBQUcsQ0FBQyxJQUFJO2FBQ2hCLENBQUMsRUFOMkIsQ0FNM0IsQ0FBQyxDQUFDO1FBQ04sQ0FBQztRQUVELG9CQUFvQixFQUFwQjtZQUNFLElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWTtnQkFBRSxPQUFPO1lBQy9CLElBQU0sS0FBSyxHQUFHLElBQUksQ0FBQyxlQUFlLENBQzlCLElBQUksQ0FBQyxLQUFLLEVBQ1YsSUFBSSxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsVUFBQyxFQUFJO29CQUFILFVBQUU7Z0JBQU0sT0FBQSxFQUFFO1lBQUYsQ0FBRSxDQUFDLENBQUMsQ0FBQztZQUMxQyxJQUFJLENBQUMsZUFBZSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLEtBQUssRUFDN0QsRUFBQyxZQUFZLEVBQUUsRUFBRSxFQUFDLENBQUMsQ0FBQztRQUMxQixDQUFDO1FBRUQsc0JBQXNCLEVBQXRCO1lBQUEsaUJBT0M7WUFOQyxJQUFNLE1BQU0sR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxVQUFBLENBQUMsSUFBSSxPQUFBLEtBQUksQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsRUFBMUIsQ0FBMEIsQ0FBQyxDQUFDO1lBQy9ELElBQU0sR0FBRyxHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLHdCQUF3QixDQUFDLENBQUM7WUFDMUUsSUFBTSxhQUFhLEdBQUcsSUFBSSxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDbkMsSUFBTSxZQUFZLEdBQUcsRUFBRSxDQUFDO1lBQ3hCLE1BQU0sQ0FBQyxPQUFPLENBQUMsVUFBQSxFQUFFLElBQUksT0FBQSxZQUFZLENBQUMsRUFBRSxDQUFDLEdBQUcsYUFBYSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsRUFBeEMsQ0FBd0MsQ0FBQyxDQUFDO1lBQy9ELE9BQU8sWUFBWSxDQUFDO1FBQ3RCLENBQUM7UUFFRCxhQUFhLEVBQWI7WUFDRSxJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVk7Z0JBQUUsT0FBTztZQUMvQixJQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDO1lBQzdCLElBQUksQ0FBQyxlQUFlLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsS0FBSyxFQUM3RCxFQUFDLFlBQVksRUFBRSxFQUFFLEVBQUMsQ0FBQyxDQUFDO1FBQzFCLENBQUM7UUFFRCxXQUFXLEVBQVgsVUFBWSxDQUFDLEVBQUUsRUFBRTtZQUFqQixpQkFjQztZQWJDLElBQU0sTUFBTSxHQUFHLElBQUksR0FBRyxDQUNsQixJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxVQUFBLEdBQUcsSUFBSSxPQUFBLENBQUMsS0FBSSxDQUFDLGtCQUFrQixDQUFDLEdBQUcsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFuQyxDQUFtQyxDQUFDLENBQUMsQ0FBQztZQUNoRSxJQUFJLENBQUMsSUFBSSxDQUFDLG1CQUFtQixFQUFFO2dCQUM3QixJQUFJLEVBQUUsSUFBSSxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsVUFBQyxFQUFJO3dCQUFILFVBQUU7b0JBQU0sT0FBQSxNQUFNLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQztnQkFBZCxDQUFjLENBQUM7cUJBQ2pELE1BQU0sQ0FBQyxPQUFPLENBQUM7cUJBQ2YsR0FBRyxDQUFDLFVBQUEsR0FBRyxJQUFJLE9BQUEsQ0FBQztvQkFDWCxFQUFFLEVBQUUsR0FBRyxDQUFDLEVBQUU7b0JBQ1YsSUFBSSxFQUFFLEdBQUcsQ0FBQyxJQUFJO29CQUNkLFNBQVMsRUFBRSxHQUFHLENBQUMsU0FBUztvQkFDeEIsSUFBSSxFQUFFLEdBQUcsQ0FBQyxJQUFJO2lCQUNmLENBQUMsRUFMVSxDQUtWLENBQUM7Z0JBQ1AsUUFBUSxFQUFFLElBQUksQ0FBQyxTQUFTO2FBQ3pCLENBQUMsQ0FBQztRQUNMLENBQUM7UUFFRCxVQUFVLEVBQVY7WUFDRSx3Q0FBd0M7WUFDeEMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxHQUFHLENBQ3BCLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsRUFBRSxFQUFFLEVBQUMsWUFBWSxFQUFFLEVBQUUsRUFBQyxDQUFDLENBQUM7WUFDL0QsSUFBSSxDQUFDLGVBQWUsQ0FBQyxHQUFHLENBQ3BCLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsRUFBRSxFQUFFLEVBQUMsWUFBWSxFQUFFLEVBQUUsRUFBQyxDQUFDLENBQUM7WUFDL0QsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUN0QixDQUFDO1FBRUQsZUFBZSxZQUNYLE1BQTRCLEVBQUUsV0FBaUM7WUFDakUsSUFBSSxXQUFXLENBQUMsTUFBTSxJQUFJLE1BQU0sQ0FBQyxNQUFNO2dCQUFFLE9BQU8saUJBQUEsaUJBQWlCLENBQUM7WUFDbEUsSUFBSSxXQUFXLENBQUMsTUFBTSxJQUFJLENBQUM7Z0JBQUUsT0FBTyxpQkFBQSxrQkFBa0IsQ0FBQztZQUV2RCxPQUFPLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQztnQkFDdEIsSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDO2dCQUM3QixnQkFBZ0IsQ0FBQyxhQUFhLENBQUUsV0FBNkIsQ0FBQyxDQUFDO1FBQ3JFLENBQUM7UUFFRCxpQkFBaUIsWUFBQyxTQUErQixFQUFFLEdBQVc7WUFDNUQsSUFBSSxHQUFHLElBQUksaUJBQUEsaUJBQWlCO2dCQUFFLE9BQU8sU0FBUyxDQUFDO1lBQy9DLElBQUksR0FBRyxJQUFJLGlCQUFBLGtCQUFrQjtnQkFBRSxPQUFPLEVBQUUsQ0FBQztZQUN6QyxJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVk7Z0JBQUUsT0FBTyxnQkFBZ0IsQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDbkUsSUFBSSxNQUFNLEdBQUcsRUFBRSxDQUFDO1lBQ2hCLElBQUk7Z0JBQ0YsTUFBTSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7YUFDMUI7WUFBQyxPQUFPLENBQUMsRUFBRTtnQkFDVixVQUFVO2FBQ1g7WUFDRCxPQUFPLEtBQUssQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO1FBQzdDLENBQUM7UUFFRCxZQUFZO1lBQ1YsT0FBTztnQkFDTCxRQUFRLEVBQUUsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDO29CQUM1QixVQUFDLElBQUksSUFBSyxPQUFBLGNBQWMsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUF6QyxDQUF5QyxDQUFDLENBQUM7b0JBQ3JELGNBQU0sT0FBQSxFQUFFLEVBQUYsQ0FBRTthQUNiLENBQUM7UUFDSixDQUFDO1FBRUQsa0JBQWtCLFlBQUMsR0FBRztZQUNwQixPQUFPLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUM7UUFDL0MsQ0FBQztRQUVELG9CQUFvQjtZQUNsQixJQUFJLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLENBQUM7UUFDL0IsQ0FBQztLQUNGLENBQUMsQ0FBQztBQUVILENBQUMsRUFoU1MsZ0JBQWdCLEtBQWhCLGdCQUFnQixRQWdTekIsQ0FBRSw2QkFBNkIiLCJzb3VyY2VzQ29udGVudCI6WyIvKiBDb3B5cmlnaHQgMjAxOCBUaGUgVGVuc29yRmxvdyBBdXRob3JzLiBBbGwgUmlnaHRzIFJlc2VydmVkLlxuXG5MaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UsIFZlcnNpb24gMi4wICh0aGUgJ0xpY2Vuc2UnKTtcbnlvdSBtYXkgbm90IHVzZSB0aGlzIGZpbGUgZXhjZXB0IGluIGNvbXBsaWFuY2Ugd2l0aCB0aGUgTGljZW5zZS5cbllvdSBtYXkgb2J0YWluIGEgY29weSBvZiB0aGUgTGljZW5zZSBhdFxuXG4gICAgaHR0cDovL3d3dy5hcGFjaGUub3JnL2xpY2Vuc2VzL0xJQ0VOU0UtMi4wXG5cblVubGVzcyByZXF1aXJlZCBieSBhcHBsaWNhYmxlIGxhdyBvciBhZ3JlZWQgdG8gaW4gd3JpdGluZywgc29mdHdhcmVcbmRpc3RyaWJ1dGVkIHVuZGVyIHRoZSBMaWNlbnNlIGlzIGRpc3RyaWJ1dGVkIG9uIGFuICdBUyBJUycgQkFTSVMsXG5XSVRIT1VUIFdBUlJBTlRJRVMgT1IgQ09ORElUSU9OUyBPRiBBTlkgS0lORCwgZWl0aGVyIGV4cHJlc3Mgb3IgaW1wbGllZC5cblNlZSB0aGUgTGljZW5zZSBmb3IgdGhlIHNwZWNpZmljIGxhbmd1YWdlIGdvdmVybmluZyBwZXJtaXNzaW9ucyBhbmRcbmxpbWl0YXRpb25zIHVuZGVyIHRoZSBMaWNlbnNlLlxuPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09Ki9cbm5hbWVzcGFjZSB0Zl9kYXRhX3NlbGVjdG9yIHtcblxuZW51bSBUeXBlIHtcbiAgUlVOID0gMSxcbiAgVEFHLFxufVxuXG5jb25zdCBNQVhfUlVOU19UT19FTkFCTEVfQllfREVGQVVMVCA9IDIwO1xuXG5Qb2x5bWVyKHtcbiAgaXM6ICd0Zi1kYXRhLXNlbGVjdC1yb3cnLFxuICBwcm9wZXJ0aWVzOiB7XG4gICAgZXhwZXJpbWVudDoge1xuICAgICAgdHlwZTogT2JqZWN0LFxuICAgICAgdmFsdWU6ICgpID0+ICh7XG4gICAgICAgIGlkOiBudWxsLFxuICAgICAgICBuYW1lOiAnVW5rbm93biBleHBlcmltZW50JyxcbiAgICAgICAgc3RhcnRUaW1lOiBudWxsLFxuICAgICAgfSksXG4gICAgfSxcblxuICAgIGVuYWJsZWQ6IHtcbiAgICAgIHR5cGU6IEJvb2xlYW4sXG4gICAgICBub3RpZnk6IHRydWUsXG4gICAgICB2YWx1ZTogdHJ1ZSxcbiAgICB9LFxuXG4gICAgY2hlY2tib3hDb2xvcjoge1xuICAgICAgdHlwZTogU3RyaW5nLFxuICAgICAgdmFsdWU6ICcnLFxuICAgIH0sXG5cbiAgICAvLyBSZXF1aXJlZCBmaWVsZC5cbiAgICBwZXJzaXN0ZW5jZUlkOiBTdHJpbmcsXG5cbiAgICBub0V4cGVyaW1lbnQ6IHtcbiAgICAgIHR5cGU6IEJvb2xlYW4sXG4gICAgICB2YWx1ZTogZmFsc2UsXG4gICAgfSxcblxuICAgIHNob3VsZENvbG9yUnVuczoge1xuICAgICAgdHlwZTogQm9vbGVhbixcbiAgICAgIHZhbHVlOiBmYWxzZSxcbiAgICB9LFxuXG4gICAgX2NvbG9yaW5nOiB7XG4gICAgICB0eXBlOiBPYmplY3QsXG4gICAgICBjb21wdXRlZDogJ19nZXRDb2xvcmluZyhzaG91bGRDb2xvclJ1bnMpJyxcbiAgICB9LFxuXG4gICAgX3J1bnM6IHtcbiAgICAgIHR5cGU6IEFycmF5LFxuICAgICAgdmFsdWU6ICgpOiBBcnJheTx0Zl9iYWNrZW5kLlJ1bj4gPT4gW10sXG4gICAgfSxcblxuICAgIF9ydW5TZWxlY3Rpb25TdGF0ZVN0cmluZzoge3R5cGU6IFN0cmluZywgdmFsdWU6ICcnfSxcblxuICAgIC8vIExpc3RJdGVtIHJlcXVpcmVzIGBpZGAgYW5kIGl0IGlzIHN5bnRoZXNpemVkIGZyb20gbmFtZSB3aGVuIGl0IGlzIGluIHRoZVxuICAgIC8vIGBub0V4cGVyaW1lbnRgIG1vZGUuXG4gICAgX3NlbGVjdGVkUnVuczoge1xuICAgICAgdHlwZTogQXJyYXksXG4gICAgICB2YWx1ZTogKCk6IEFycmF5PHRmX2Rhc2hib2FyZF9jb21tb24uRmlsdGVyYWJsZUNoZWNrYm94TGlzdEl0ZW0+ID0+IFtdLFxuICAgIH0sXG5cbiAgICBfdGFnUmVnZXg6IHtcbiAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgIHZhbHVlOiAnJyxcbiAgICAgIG9ic2VydmVyOiAnX3BlcnNpc3RSZWdleCcsXG4gICAgfSxcblxuICAgIF9zdG9yYWdlQmluZGluZzoge1xuICAgICAgdHlwZTogT2JqZWN0LFxuICAgICAgdmFsdWU6ICgpID0+IG51bGwsXG4gICAgfSxcbiAgfSxcblxuICBsaXN0ZW5lcnM6IHtcbiAgICAnZG9tLWNoYW5nZSc6ICdfc3luY2hyb25pemVDb2xvcnMnLFxuICB9LFxuXG4gIG9ic2VydmVyczogW1xuICAgICdfaW1tdXRhYmxlUHJvcEludmFyaWFuY2VWaW9sYXRlZChwZXJzaXN0ZW5jZUlkLiopJyxcbiAgICAnX2ltbXV0YWJsZVByb3BJbnZhcmlhbmNlVmlvbGF0ZWQoZXhwZXJpbWVudC4qKScsXG4gICAgJ19zeW5jaHJvbml6ZUNvbG9ycyhjaGVja2JveENvbG9yKScsXG4gICAgJ19wZXJzaXN0U2VsZWN0ZWRSdW5zKF9zZWxlY3RlZFJ1bnMpJyxcbiAgICAnX2ZpcmVDaGFuZ2UoX3NlbGVjdGVkUnVucywgX3RhZ1JlZ2V4KScsXG4gIF0sXG5cbiAgX2dldFBlcnNpc3RlbmNlS2V5KHR5cGU6IFR5cGUpOiBzdHJpbmcge1xuICAgIGNvbnN0IGlkID0gdGhpcy5wZXJzaXN0ZW5jZUlkO1xuICAgIHN3aXRjaCAodHlwZSkge1xuICAgICAgY2FzZSBUeXBlLlJVTjpcbiAgICAgICAgLy8gUHJlZml4IHdpdGggJ2cnIHRvIGRlbm90ZSBhIGdyb3VwLlxuICAgICAgICByZXR1cm4gYGdyJHtpZH1gO1xuICAgICAgY2FzZSBUeXBlLlRBRzpcbiAgICAgICAgcmV0dXJuIGBndCR7aWR9YDtcbiAgICB9XG4gIH0sXG5cbiAgYXR0YWNoZWQoKTogdm9pZCB7XG4gICAgaWYgKHRoaXMucGVyc2lzdGVuY2VJZCA9PSBudWxsKSB7XG4gICAgICB0aHJvdyBuZXcgUmFuZ2VFcnJvcignUmVxdWlyZWQgYHBlcnNpc3RlbmNlSWRgIG1pc3NpbmcnKTtcbiAgICB9XG5cbiAgICB0aGlzLl9pbml0RnJvbVN0b3JhZ2UoKTtcbiAgICB0aGlzLl9pbml0UnVuc0FuZFRhZ3MoKVxuICAgICAgICAudGhlbigoKSA9PiB7XG4gICAgICAgICAgaWYgKHRoaXMuX3J1blNlbGVjdGlvblN0YXRlU3RyaW5nKSByZXR1cm47XG4gICAgICAgICAgY29uc3QgdmFsID0gdGhpcy5fcnVucy5sZW5ndGggPD0gTUFYX1JVTlNfVE9fRU5BQkxFX0JZX0RFRkFVTFQgP1xuICAgICAgICAgICAgICBTVE9SQUdFX0FMTF9WQUxVRSA6IFNUT1JBR0VfTk9ORV9WQUxVRTtcbiAgICAgICAgICB0aGlzLl9zdG9yYWdlQmluZGluZy5zZXQodGhpcy5fZ2V0UGVyc2lzdGVuY2VLZXkoVHlwZS5SVU4pLCB2YWwsXG4gICAgICAgICAgICAgIHtkZWZhdWx0VmFsdWU6ICcnfSk7XG4gICAgICAgICAgdGhpcy5fcnVuU2VsZWN0aW9uU3RhdGVTdHJpbmcgPSB2YWw7XG4gICAgICAgIH0pO1xuICB9LFxuXG4gIGRldGFjaGVkKCk6IHZvaWQge1xuICAgIHRoaXMuX2lzRGF0YVJlYWR5ID0gZmFsc2U7XG4gICAgaWYgKHRoaXMuX3N0b3JhZ2VCaW5kaW5nKSB0aGlzLl9zdG9yYWdlQmluZGluZy5kaXNwb3NlQmluZGluZygpO1xuICB9LFxuXG4gIF9pbml0RnJvbVN0b3JhZ2UoKSB7XG4gICAgaWYgKHRoaXMuX3N0b3JhZ2VCaW5kaW5nKSB0aGlzLl9zdG9yYWdlQmluZGluZy5kaXNwb3NlQmluZGluZygpO1xuICAgIHRoaXMuX3N0b3JhZ2VCaW5kaW5nID0gdGZfc3RvcmFnZS5tYWtlQmluZGluZ3MoeCA9PiB4LCB4ID0+IHgpO1xuICAgIGNvbnN0IHJ1bkluaXRpYWxpemVyID0gdGhpcy5fc3RvcmFnZUJpbmRpbmcuZ2V0SW5pdGlhbGl6ZXIoXG4gICAgICAgIHRoaXMuX2dldFBlcnNpc3RlbmNlS2V5KFR5cGUuUlVOKSxcbiAgICAgICAge1xuICAgICAgICAgIGRlZmF1bHRWYWx1ZTogJycsXG4gICAgICAgICAgcG9seW1lclByb3BlcnR5OiAnX3J1blNlbGVjdGlvblN0YXRlU3RyaW5nJyxcbiAgICAgICAgfSk7XG4gICAgcnVuSW5pdGlhbGl6ZXIuY2FsbCh0aGlzKTtcbiAgICBjb25zdCB0YWdJbml0aWFsaXplciA9IHRoaXMuX3N0b3JhZ2VCaW5kaW5nLmdldEluaXRpYWxpemVyKFxuICAgICAgICB0aGlzLl9nZXRQZXJzaXN0ZW5jZUtleShUeXBlLlRBRyksXG4gICAgICAgIHtkZWZhdWx0VmFsdWU6ICcnLCBwb2x5bWVyUHJvcGVydHk6ICdfdGFnUmVnZXgnfSk7XG4gICAgdGFnSW5pdGlhbGl6ZXIuY2FsbCh0aGlzKTtcbiAgfSxcblxuICBfaW5pdFJ1bnNBbmRUYWdzKCk6IFByb21pc2U8dm9pZD4ge1xuICAgIHRoaXMuX2lzRGF0YVJlYWR5ID0gZmFsc2U7XG4gICAgcmV0dXJuIHRoaXMuX2ZldGNoUnVuc0FuZFRhZ3MoKVxuICAgICAgICAudGhlbigoKSA9PiB7XG4gICAgICAgICAgdGhpcy5faXNEYXRhUmVhZHkgPSB0cnVlO1xuICAgICAgICB9KTtcbiAgfSxcblxuICBfaW1tdXRhYmxlUHJvcEludmFyaWFuY2VWaW9sYXRlZChjaGFuZ2UpIHtcbiAgICAvLyBXZSBhbGxvdyBwcm9wZXJ0eSB0byBjaGFuZ2UgbWFueSB0aW1lcyBiZWZvcmUgdGhlIGNvbXBvbmVudCBpcyBhdHRhY2hlZFxuICAgIC8vIHRvIERPTS5cbiAgICBpZiAodGhpcy5pc0F0dGFjaGVkKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoYEludmFyaWFuY2UgVmlvbGF0aW9uOiBgICtcbiAgICAgICAgICBgRXhwZWN0ZWQgcHJvcGVydHkgJyR7Y2hhbmdlLnBhdGh9JyBub3QgdG8gY2hhbmdlLmApO1xuICAgIH1cbiAgfSxcblxuICBfc3luY2hyb25pemVDb2xvcnMoKSB7XG4gICAgY29uc3QgY2IgPSB0aGlzLiQkKCcjY2hlY2tib3gnKTtcbiAgICBpZiAoIWNiKSByZXR1cm47XG5cbiAgICBjb25zdCBjb2xvciA9IHRoaXMuY2hlY2tib3hDb2xvcjtcbiAgICBjYi5jdXN0b21TdHlsZVsnLS1wYXBlci1jaGVja2JveC1jaGVja2VkLWNvbG9yJ10gPSBjb2xvcjtcbiAgICBjYi5jdXN0b21TdHlsZVsnLS1wYXBlci1jaGVja2JveC1jaGVja2VkLWluay1jb2xvciddID0gY29sb3I7XG4gICAgY2IuY3VzdG9tU3R5bGVbJy0tcGFwZXItY2hlY2tib3gtdW5jaGVja2VkLWNvbG9yJ10gPSBjb2xvcjtcbiAgICBjYi5jdXN0b21TdHlsZVsnLS1wYXBlci1jaGVja2JveC11bmNoZWNrZWQtaW5rLWNvbG9yJ10gPSBjb2xvcjtcblxuICAgIHdpbmRvdy5yZXF1ZXN0QW5pbWF0aW9uRnJhbWUoKCkgPT4gdGhpcy51cGRhdGVTdHlsZXMoKSk7XG4gIH0sXG5cbiAgX2ZldGNoUnVuc0FuZFRhZ3MoKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgY29uc3QgcmVxdWVzdE1hbmFnZXIgPSBuZXcgdGZfYmFja2VuZC5SZXF1ZXN0TWFuYWdlcigpO1xuICAgIGlmICh0aGlzLm5vRXhwZXJpbWVudCkge1xuICAgICAgY29uc3QgZmV0Y2hSdW5zID0gcmVxdWVzdE1hbmFnZXIucmVxdWVzdCh0Zl9iYWNrZW5kLmdldFJvdXRlcigpLnJ1bnMoKSk7XG4gICAgICByZXR1cm4gUHJvbWlzZS5hbGwoW2ZldGNoUnVuc10pLnRoZW4oKFtydW5zXSkgPT4ge1xuICAgICAgICB0aGlzLnNldCgnX3J1bnMnLCBBcnJheS5mcm9tKG5ldyBTZXQocnVucykpLm1hcChydW5OYW1lID0+ICh7XG4gICAgICAgICAgaWQ6IG51bGwsXG4gICAgICAgICAgbmFtZTogcnVuTmFtZSxcbiAgICAgICAgICBzdGFydGVkVGltZTogbnVsbCxcbiAgICAgICAgfSkpKTtcbiAgICAgIH0pO1xuICAgIH1cblxuICAgIGNvbnNvbGUuYXNzZXJ0KHRoaXMuZXhwZXJpbWVudC5pZCAhPSBudWxsLCAnRXhwZWN0ZWQgYW4gZXhwZXJpbWVudCBJZCcpO1xuXG4gICAgY29uc3QgdXJsID0gdGZfYmFja2VuZC5nZXRSb3V0ZXIoKS5ydW5zRm9yRXhwZXJpbWVudCh0aGlzLmV4cGVyaW1lbnQuaWQpO1xuICAgIHJldHVybiByZXF1ZXN0TWFuYWdlci5yZXF1ZXN0KHVybCkudGhlbihydW5zID0+IHtcbiAgICAgIHRoaXMuc2V0KCdfcnVucycsIHJ1bnMpO1xuICAgIH0pO1xuICB9LFxuXG4gIF9nZXRSdW5PcHRpb25zKF8pOiBBcnJheTx0Zl9kYXNoYm9hcmRfY29tbW9uLkZpbHRlcmFibGVDaGVja2JveExpc3RJdGVtPiB7XG4gICAgcmV0dXJuIHRoaXMuX3J1bnMubWFwKHJ1biA9PiAoe1xuICAgICAgLy8gL2RhdGEvcnVucyBlbmRwb2ludCBkb2VzIG5vdCByZXR1cm4gaWRzLiBJbiBjYXNlIG9mIGxvZ2RpciBkYXRhIHNvdXJjZSxcbiAgICAgIC8vIHJ1bnMgY2Fubm90IGhhdmUgYW4gaWQgYW5kLCBmb3IgZmlsdGVyZWQtY2hlY2tib3gtbGlzdCwgd2UgbmVlZCB0b1xuICAgICAgLy8gc3ludGhlc2l6ZSBpZCBmcm9tIHRoZSBuYW1lLlxuICAgICAgaWQ6IHRoaXMuX2dldFN5bnRoZXRpY1J1bklkKHJ1biksXG4gICAgICB0aXRsZTogcnVuLm5hbWUsXG4gICAgfSkpO1xuICB9LFxuXG4gIF9wZXJzaXN0U2VsZWN0ZWRSdW5zKCk6IHZvaWQge1xuICAgIGlmICghdGhpcy5faXNEYXRhUmVhZHkpIHJldHVybjtcbiAgICBjb25zdCB2YWx1ZSA9IHRoaXMuX3NlcmlhbGl6ZVZhbHVlKFxuICAgICAgICB0aGlzLl9ydW5zLFxuICAgICAgICB0aGlzLl9zZWxlY3RlZFJ1bnMubWFwKCh7aWR9KSA9PiBpZCkpO1xuICAgIHRoaXMuX3N0b3JhZ2VCaW5kaW5nLnNldCh0aGlzLl9nZXRQZXJzaXN0ZW5jZUtleShUeXBlLlJVTiksIHZhbHVlLFxuICAgICAgICB7ZGVmYXVsdFZhbHVlOiAnJ30pO1xuICB9LFxuXG4gIF9nZXRSdW5zU2VsZWN0aW9uU3RhdGUoKTogT2JqZWN0IHtcbiAgICBjb25zdCBhbGxJZHMgPSB0aGlzLl9ydW5zLm1hcChyID0+IHRoaXMuX2dldFN5bnRoZXRpY1J1bklkKHIpKTtcbiAgICBjb25zdCBpZHMgPSB0aGlzLl9kZXNlcmlhbGl6ZVZhbHVlKGFsbElkcywgdGhpcy5fcnVuU2VsZWN0aW9uU3RhdGVTdHJpbmcpO1xuICAgIGNvbnN0IHByZXZTZWxlY3Rpb24gPSBuZXcgU2V0KGlkcyk7XG4gICAgY29uc3QgbmV3U2VsZWN0aW9uID0ge307XG4gICAgYWxsSWRzLmZvckVhY2goaWQgPT4gbmV3U2VsZWN0aW9uW2lkXSA9IHByZXZTZWxlY3Rpb24uaGFzKGlkKSk7XG4gICAgcmV0dXJuIG5ld1NlbGVjdGlvbjtcbiAgfSxcblxuICBfcGVyc2lzdFJlZ2V4KCk6IHZvaWQge1xuICAgIGlmICghdGhpcy5faXNEYXRhUmVhZHkpIHJldHVybjtcbiAgICBjb25zdCB2YWx1ZSA9IHRoaXMuX3RhZ1JlZ2V4O1xuICAgIHRoaXMuX3N0b3JhZ2VCaW5kaW5nLnNldCh0aGlzLl9nZXRQZXJzaXN0ZW5jZUtleShUeXBlLlRBRyksIHZhbHVlLFxuICAgICAgICB7ZGVmYXVsdFZhbHVlOiAnJ30pO1xuICB9LFxuXG4gIF9maXJlQ2hhbmdlKF8sIF9fKTogdm9pZCB7XG4gICAgY29uc3QgcnVuTWFwID0gbmV3IE1hcChcbiAgICAgICAgdGhpcy5fcnVucy5tYXAocnVuID0+IFt0aGlzLl9nZXRTeW50aGV0aWNSdW5JZChydW4pLCBydW5dKSk7XG4gICAgdGhpcy5maXJlKCdzZWxlY3Rpb24tY2hhbmdlZCcsIHtcbiAgICAgIHJ1bnM6IHRoaXMuX3NlbGVjdGVkUnVucy5tYXAoKHtpZH0pID0+IHJ1bk1hcC5nZXQoaWQpKVxuICAgICAgICAgIC5maWx0ZXIoQm9vbGVhbilcbiAgICAgICAgICAubWFwKHJ1biA9PiAoe1xuICAgICAgICAgICAgaWQ6IHJ1bi5pZCxcbiAgICAgICAgICAgIG5hbWU6IHJ1bi5uYW1lLFxuICAgICAgICAgICAgc3RhcnRUaW1lOiBydW4uc3RhcnRUaW1lLFxuICAgICAgICAgICAgdGFnczogcnVuLnRhZ3MsXG4gICAgICAgICAgfSkpLFxuICAgICAgdGFnUmVnZXg6IHRoaXMuX3RhZ1JlZ2V4LFxuICAgIH0pO1xuICB9LFxuXG4gIF9yZW1vdmVSb3coKTogdm9pZCB7XG4gICAgLy8gQ2xlYXIgcGVyc2lzdGVuY2Ugd2hlbiBiZWluZyByZW1vdmVkLlxuICAgIHRoaXMuX3N0b3JhZ2VCaW5kaW5nLnNldChcbiAgICAgICAgdGhpcy5fZ2V0UGVyc2lzdGVuY2VLZXkoVHlwZS5SVU4pLCAnJywge2RlZmF1bHRWYWx1ZTogJyd9KTtcbiAgICB0aGlzLl9zdG9yYWdlQmluZGluZy5zZXQoXG4gICAgICAgIHRoaXMuX2dldFBlcnNpc3RlbmNlS2V5KFR5cGUuVEFHKSwgJycsIHtkZWZhdWx0VmFsdWU6ICcnfSk7XG4gICAgdGhpcy5maXJlKCdyZW1vdmUnKTtcbiAgfSxcblxuICBfc2VyaWFsaXplVmFsdWUoXG4gICAgICBzb3VyY2U6IEFycmF5PG51bWJlcnxzdHJpbmc+LCBzZWxlY3RlZElkczogQXJyYXk8bnVtYmVyfHN0cmluZz4pIHtcbiAgICBpZiAoc2VsZWN0ZWRJZHMubGVuZ3RoID09IHNvdXJjZS5sZW5ndGgpIHJldHVybiBTVE9SQUdFX0FMTF9WQUxVRTtcbiAgICBpZiAoc2VsZWN0ZWRJZHMubGVuZ3RoID09IDApIHJldHVybiBTVE9SQUdFX05PTkVfVkFMVUU7XG5cbiAgICByZXR1cm4gdGhpcy5ub0V4cGVyaW1lbnQgP1xuICAgICAgICBKU09OLnN0cmluZ2lmeShzZWxlY3RlZElkcykgOlxuICAgICAgICB0Zl9kYXRhX3NlbGVjdG9yLmVuY29kZUlkQXJyYXkoKHNlbGVjdGVkSWRzIGFzIEFycmF5PG51bWJlcj4pKTtcbiAgfSxcblxuICBfZGVzZXJpYWxpemVWYWx1ZShhbGxWYWx1ZXM6IEFycmF5PG51bWJlcnxzdHJpbmc+LCBzdHI6IHN0cmluZykge1xuICAgIGlmIChzdHIgPT0gU1RPUkFHRV9BTExfVkFMVUUpIHJldHVybiBhbGxWYWx1ZXM7XG4gICAgaWYgKHN0ciA9PSBTVE9SQUdFX05PTkVfVkFMVUUpIHJldHVybiBbXTtcbiAgICBpZiAoIXRoaXMubm9FeHBlcmltZW50KSByZXR1cm4gdGZfZGF0YV9zZWxlY3Rvci5kZWNvZGVJZEFycmF5KHN0cik7XG4gICAgbGV0IHBhcnNlZCA9IFtdO1xuICAgIHRyeSB7XG4gICAgICBwYXJzZWQgPSBKU09OLnBhcnNlKHN0cik7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgLyogbm9vcCAqL1xuICAgIH1cbiAgICByZXR1cm4gQXJyYXkuaXNBcnJheShwYXJzZWQpID8gcGFyc2VkIDogW107XG4gIH0sXG5cbiAgX2dldENvbG9yaW5nKCkge1xuICAgIHJldHVybiB7XG4gICAgICBnZXRDb2xvcjogdGhpcy5zaG91bGRDb2xvclJ1bnMgP1xuICAgICAgICAgIChpdGVtKSA9PiB0Zl9jb2xvcl9zY2FsZS5ydW5zQ29sb3JTY2FsZShpdGVtLnRpdGxlKSA6XG4gICAgICAgICAgKCkgPT4gJycsXG4gICAgfTtcbiAgfSxcblxuICBfZ2V0U3ludGhldGljUnVuSWQocnVuKSB7XG4gICAgcmV0dXJuIHRoaXMubm9FeHBlcmltZW50ID8gcnVuLm5hbWUgOiBydW4uaWQ7XG4gIH0sXG5cbiAgX2ZpcmVDaGVja2JveFRvZ2dsZWQoKSB7XG4gICAgdGhpcy5maXJlKCdjaGVja2JveC10b2dnbGUnKTtcbiAgfSxcbn0pO1xuXG59ICAvLyBuYW1lc3BhY2UgdGZfZGF0YV9zZWxlY3RvclxuIl19