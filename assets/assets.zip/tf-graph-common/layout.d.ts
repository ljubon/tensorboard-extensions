declare module tf.graph.layout {
    /** Set of parameters that define the look and feel of the graph. */
    const PARAMS: {
        animation: {
            /** Default duration for graph animations in ms. */
            duration: number;
        };
        graph: {
            /** Graph parameter for metanode. */
            meta: {
                /**
                 * Dagre's nodesep param - number of pixels that
                 * separate nodes horizontally in the layout.
                 *
                 * See https://github.com/cpettitt/dagre/wiki#configuring-the-layout
                 */
                nodeSep: number;
                /**
                 * Dagre's ranksep param - number of pixels
                 * between each rank in the layout.
                 *
                 * See https://github.com/cpettitt/dagre/wiki#configuring-the-layout
                 */
                rankSep: number;
                /**
                 * Dagre's edgesep param - number of pixels that separate
                 * edges horizontally in the layout.
                 */
                edgeSep: number;
            };
            /** Graph parameter for metanode. */
            series: {
                /**
                 * Dagre's nodesep param - number of pixels that
                 * separate nodes horizontally in the layout.
                 *
                 * See https://github.com/cpettitt/dagre/wiki#configuring-the-layout
                 */
                nodeSep: number;
                /**
                 * Dagre's ranksep param - number of pixels
                 * between each rank in the layout.
                 *
                 * See https://github.com/cpettitt/dagre/wiki#configuring-the-layout
                 */
                rankSep: number;
                /**
                 * Dagre's edgesep param - number of pixels that separate
                 * edges horizontally in the layout.
                 */
                edgeSep: number;
            };
            /**
             * Padding is used to correctly position the graph SVG inside of its parent
             * element. The padding amounts are applied using an SVG transform of X and
             * Y coordinates.
             */
            padding: {
                paddingTop: number;
                paddingLeft: number;
            };
        };
        subscene: {
            meta: {
                paddingTop: number;
                paddingBottom: number;
                paddingLeft: number;
                paddingRight: number;
                /**
                 * Used to leave room for the label on top of the highest node in
                 * the core graph.
                 */
                labelHeight: number;
                /** X-space between each extracted node and the core graph. */
                extractXOffset: number;
                /** Y-space between each extracted node. */
                extractYOffset: number;
            };
            series: {
                paddingTop: number;
                paddingBottom: number;
                paddingLeft: number;
                paddingRight: number;
                labelHeight: number;
            };
        };
        nodeSize: {
            /** Size of meta nodes. */
            meta: {
                radius: number;
                width: number;
                maxLabelWidth: number;
                /** A scale for the node's height based on number of nodes inside */
                height: any;
                /** The radius of the circle denoting the expand button. */
                expandButtonRadius: number;
            };
            /** Size of op nodes. */
            op: {
                width: number;
                height: number;
                radius: number;
                labelOffset: number;
                maxLabelWidth: number;
            };
            /** Size of series nodes. */
            series: {
                expanded: {
                    radius: number;
                    labelOffset: number;
                };
                vertical: {
                    width: number;
                    height: number;
                    labelOffset: number;
                };
                horizontal: {
                    width: number;
                    height: number;
                    radius: number;
                    labelOffset: number;
                };
            };
            /** Size of bridge nodes. */
            bridge: {
                width: number;
                height: number;
                radius: number;
                labelOffset: number;
            };
        };
        shortcutSize: {
            /** Size of shortcuts for op nodes */
            op: {
                width: number;
                height: number;
            };
            /** Size of shortcuts for meta nodes */
            meta: {
                width: number;
                height: number;
                radius: number;
            };
            /** Size of shortcuts for series nodes */
            series: {
                width: number;
                height: number;
            };
        };
        annotations: {
            /** Maximum possible width of the bounding box for in annotations */
            inboxWidth: number;
            /** Maximum possible width of the bounding box for out annotations */
            outboxWidth: number;
            /** X-space between the shape and each annotation-node. */
            xOffset: number;
            /** Y-space between each annotation-node. */
            yOffset: number;
            /** X-space between each annotation-node and its label. */
            labelOffset: number;
            /** Defines the max width for annotation label */
            maxLabelWidth: number;
        };
        constant: {
            size: {
                width: number;
                height: number;
            };
        };
        series: {
            /** Maximum number of repeated item for unexpanded series node. */
            maxStackCount: number;
            /**
             * Positioning offset ratio for collapsed stack
             * of parallel series (series without edges between its members).
             */
            parallelStackOffsetRatio: number;
            /**
             * Positioning offset ratio for collapsed stack
             * of tower series (series with edges between its members).
             */
            towerStackOffsetRatio: number;
        };
        minimap: {
            /** The maximum width/height the minimap can have. */
            size: number;
        };
    };
    /**
     * The minimum width we confer upon the auxiliary nodes section if functions
     * also appear. Without enforcing this minimum, metanodes in the function
     * library section could jut into the auxiliary nodes section because the
     * title "Auxiliary Nodes" is longer than the width of the auxiliary nodes
     * section itself.
     */
    const MIN_AUX_WIDTH = 140;
    /** Calculate layout for a scene of a group node. */
    function layoutScene(renderNodeInfo: render.RenderGroupNodeInfo): void;
    /**
     * Determines the center position of the node's shape. The position depends
     * on if the node has in and out-annotations.
     */
    function computeCXPositionOfNodeShape(renderInfo: render.RenderNodeInfo): number;
}
