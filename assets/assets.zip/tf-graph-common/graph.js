/* Copyright 2015 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the 'License');
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an 'AS IS' BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
var tf;
(function (tf) {
    var graph;
    (function (graph_1) {
        /** Delimiter used in node names to denote namespaces. */
        graph_1.NAMESPACE_DELIM = '/';
        graph_1.ROOT_NAME = '__root__';
        graph_1.FUNCTION_LIBRARY_NODE_PREFIX = '__function_library__';
        /** Attribute key used for storing attributes that are too large. */
        graph_1.LARGE_ATTRS_KEY = '_too_large_attrs';
        /**
         * Maximum allowed size in bytes, before the attribute is considered large
         * and filtered out of the graph.
         */
        graph_1.LIMIT_ATTR_SIZE = 1024;
        // Separator between the source and the destination name of the edge.
        graph_1.EDGE_KEY_DELIM = '--';
        var GraphType;
        (function (GraphType) {
            GraphType[GraphType["FULL"] = 0] = "FULL";
            GraphType[GraphType["EMBEDDED"] = 1] = "EMBEDDED";
            GraphType[GraphType["META"] = 2] = "META";
            GraphType[GraphType["SERIES"] = 3] = "SERIES";
            GraphType[GraphType["CORE"] = 4] = "CORE";
            GraphType[GraphType["SHADOW"] = 5] = "SHADOW";
            GraphType[GraphType["BRIDGE"] = 6] = "BRIDGE";
            GraphType[GraphType["EDGE"] = 7] = "EDGE";
        })(GraphType = graph_1.GraphType || (graph_1.GraphType = {}));
        ;
        var NodeType;
        (function (NodeType) {
            NodeType[NodeType["META"] = 0] = "META";
            NodeType[NodeType["OP"] = 1] = "OP";
            NodeType[NodeType["SERIES"] = 2] = "SERIES";
            NodeType[NodeType["BRIDGE"] = 3] = "BRIDGE";
            NodeType[NodeType["ELLIPSIS"] = 4] = "ELLIPSIS";
        })(NodeType = graph_1.NodeType || (graph_1.NodeType = {}));
        ;
        /** Indicates if a node is to be included in the main graph when rendered. */
        var InclusionType;
        (function (InclusionType) {
            InclusionType[InclusionType["INCLUDE"] = 0] = "INCLUDE";
            InclusionType[InclusionType["EXCLUDE"] = 1] = "EXCLUDE";
            InclusionType[InclusionType["UNSPECIFIED"] = 2] = "UNSPECIFIED";
        })(InclusionType = graph_1.InclusionType || (graph_1.InclusionType = {}));
        ;
        /** Indicates if a series is to be grouped in the graph when rendered. */
        var SeriesGroupingType;
        (function (SeriesGroupingType) {
            SeriesGroupingType[SeriesGroupingType["GROUP"] = 0] = "GROUP";
            SeriesGroupingType[SeriesGroupingType["UNGROUP"] = 1] = "UNGROUP";
        })(SeriesGroupingType = graph_1.SeriesGroupingType || (graph_1.SeriesGroupingType = {}));
        ;
        /** Attribute key reserved for the shapes of the output tensors. */
        var OUTPUT_SHAPES_KEY = '_output_shapes';
        /** Attribute key reserved for the XLA cluster that an op runs on. */
        var _XLA_CLUSTER_KEY = '_XlaCluster';
        /**
         * A SlimGraph is inspired by graphlib.Graph, but having only the functionality
         * that we need.
         */
        var SlimGraph = /** @class */ (function () {
            function SlimGraph() {
                this.nodes = {};
                this.edges = [];
            }
            return SlimGraph;
        }());
        graph_1.SlimGraph = SlimGraph;
        var EllipsisNodeImpl = /** @class */ (function () {
            /**
             * Constructs a new ellipsis annotation node.
             *
             * @param numNodes The number of additional annotations this node represents.
             */
            function EllipsisNodeImpl(numNodes) {
                this.type = NodeType.ELLIPSIS;
                this.isGroupNode = false;
                this.cardinality = 1;
                this.parentNode = null;
                this.stats = null;
                this.setNumMoreNodes(numNodes);
                this.include = InclusionType.UNSPECIFIED;
            }
            EllipsisNodeImpl.prototype.setNumMoreNodes = function (numNodes) {
                this.numMoreNodes = numNodes;
                this.name = '... ' + numNodes + ' more';
            };
            return EllipsisNodeImpl;
        }());
        graph_1.EllipsisNodeImpl = EllipsisNodeImpl;
        ;
        /**
         * A label object for nodes in the full graph and leaf nodes in the render
         * graph.
         */
        var OpNodeImpl = /** @class */ (function () {
            /**
             * Constructs a new Op node.
             *
             * @param rawNode The raw node.
             */
            function OpNodeImpl(rawNode) {
                this.op = rawNode.op;
                this.name = rawNode.name;
                this.device = rawNode.device;
                this.attr = rawNode.attr;
                // An array of normalized inputs that denote the incoming edges to
                // the current node. Each input contains the normalized name of the
                // source node, whether it has a number part and whether it is a
                // control dependency.
                this.inputs = normalizeInputs(rawNode.input);
                this.outputShapes = extractOutputShapes(rawNode.attr);
                this.xlaCluster = extractXlaCluster(rawNode.attr);
                this.compatible = false;
                // additional properties
                this.type = NodeType.OP;
                this.isGroupNode = false;
                this.cardinality = 1;
                this.inEmbeddings = [];
                this.outEmbeddings = [];
                this.parentNode = null;
                this.include = InclusionType.UNSPECIFIED;
                this.owningSeries = null;
            }
            return OpNodeImpl;
        }());
        graph_1.OpNodeImpl = OpNodeImpl;
        ;
        function createMetanode(name, opt) {
            if (opt === void 0) { opt = {}; }
            return new MetanodeImpl(name, opt);
        }
        graph_1.createMetanode = createMetanode;
        /**
         * Joins the information from the stats file (memory, compute time) with the
         * graph information.
         */
        function joinStatsInfoWithGraph(graph, stats, devicesForStats) {
            // Reset stats for each node.
            _.each(graph.nodes, function (node) { node.stats = null; });
            _.each(stats.dev_stats, function (devStats) {
                // Ignore devices that are not selected.
                if (devicesForStats && !devicesForStats[devStats.device]) {
                    return;
                }
                _.each(devStats.node_stats, function (nodeStats) {
                    // Lookup the node in the graph by its original name, e.g. A/B. If not
                    // found, lookup by the rewritten name A/B/(B) in case the name is both
                    // a namespace and a node name.
                    var nodeName = nodeStats.node_name in graph.nodes ?
                        nodeStats.node_name :
                        getStrictName(nodeStats.node_name);
                    // Couldn't find a matching node.
                    if (!(nodeName in graph.nodes)) {
                        return;
                    }
                    // Compute the total bytes used.
                    var totalBytes = 0;
                    if (nodeStats.memory) {
                        _.each(nodeStats.memory, function (alloc) {
                            if (alloc.total_bytes) {
                                if (alloc.total_bytes > 0) {
                                    totalBytes += Number(alloc.total_bytes);
                                }
                                else {
                                    /* tslint:disable */
                                    console.log('ignoring negative memory allocation for ' + nodeName);
                                    /* tslint:enable */
                                }
                            }
                        });
                    }
                    var outputSize = null;
                    if (nodeStats.output) {
                        outputSize = _.map(nodeStats.output, function (output) {
                            return _.map(output.tensor_description.shape.dim, function (dim) { return Number(dim.size); });
                        });
                    }
                    graph.nodes[nodeName].device = devStats.device;
                    if (graph.nodes[nodeName].stats == null) {
                        graph.nodes[nodeName].stats = new NodeStats(outputSize);
                    }
                    graph.nodes[nodeName].stats.addBytesAllocation(totalBytes);
                    if (nodeStats.all_end_rel_micros) {
                        if (nodeStats.all_end_rel_micros > 0) {
                            graph.nodes[nodeName].stats.addExecutionTime(nodeStats.all_start_micros, nodeStats.all_start_micros + nodeStats.all_end_rel_micros);
                        }
                        else {
                            /* tslint:disable */
                            console.log('ignoring negative runtime for ' + nodeName);
                            /* tslint:enable */
                        }
                    }
                });
            });
        }
        graph_1.joinStatsInfoWithGraph = joinStatsInfoWithGraph;
        /**
         * Execution stats for the node.
         */
        var NodeStats = /** @class */ (function () {
            function NodeStats(outputSize) {
                /**
                 * Total number of bytes used for the node. Sum of all children
                 * if it is a Group node.
                 */
                this.totalBytes = 0;
                this.outputSize = outputSize;
            }
            /**
             * Add the start and end time for a particular kernel execution of this op.
             * Ops can have multiple kernel executions within the same session run.
             */
            NodeStats.prototype.addExecutionTime = function (startTime, endTime) {
                if (this.startTime != null) {
                    this.startTime = Math.min(this.startTime, startTime);
                }
                else {
                    this.startTime = startTime;
                }
                if (this.endTime != null) {
                    this.endTime = Math.max(this.endTime, endTime);
                }
                else {
                    this.endTime = endTime;
                }
            };
            /**
             * Add the bytes allocated for a particular kernel execution of this op.
             * Ops can have multiple kernel executions within the same session run.
             */
            NodeStats.prototype.addBytesAllocation = function (totalBytes) {
                if (this.totalBytes != null) {
                    this.totalBytes = Math.max(this.totalBytes, totalBytes);
                }
                else {
                    this.totalBytes = totalBytes;
                }
            };
            /**
             * Combines the specified stats with the current stats.
             * Modifies the current object. This method is used to
             * compute aggregate stats for group nodes.
             */
            NodeStats.prototype.combine = function (stats) {
                if (stats.totalBytes != null) {
                    this.totalBytes += stats.totalBytes;
                }
                if (stats.getTotalMicros() != null) {
                    this.addExecutionTime(stats.startTime, stats.endTime);
                }
            };
            /**
             * Total number of compute time in microseconds used for the node.
             * Sum of all children if it is a Group node. Null if it is unknown.
             * This method can not be scaffolded under a getter attribute because
             * ECMAScript 5 does not support getter attributes.
             */
            NodeStats.prototype.getTotalMicros = function () {
                if (this.startTime == null || this.endTime == null) {
                    return null;
                }
                return this.endTime - this.startTime;
            };
            return NodeStats;
        }());
        graph_1.NodeStats = NodeStats;
        var MetanodeImpl = /** @class */ (function () {
            /** A label object for meta-nodes in the graph hierarchy */
            function MetanodeImpl(name, opt) {
                if (opt === void 0) { opt = {}; }
                this.name = name;
                this.type = NodeType.META;
                /** number of levels under this group */
                this.depth = 1;
                this.isGroupNode = true;
                /** # of leaf nodes (including embedded ones) */
                this.cardinality = 0;
                /** graph contains metanodes, nodes, edges
                 * and metaedges for main items within this metanode
                 */
                this.metagraph =
                    createGraph(name, GraphType.META, opt);
                /** bridgegraph must be constructed lazily-see hierarchy.getBridgegraph() */
                this.bridgegraph = null;
                /**
                 * A dictionary that count ops type of nodes in this metanode
                 * (op type => count).
                 */
                this.opHistogram = {};
                this.deviceHistogram = {};
                this.xlaClusterHistogram = {};
                this.compatibilityHistogram = { compatible: 0, incompatible: 0 };
                /** unique id for a metanode of similar subgraph */
                this.templateId = null;
                /** Metanode which contains this node, if any */
                this.parentNode = null;
                this.hasNonControlEdges = false;
                this.include = InclusionType.UNSPECIFIED;
                this.associatedFunction = '';
            }
            MetanodeImpl.prototype.getFirstChild = function () {
                return this.metagraph.node(this.metagraph.nodes()[0]);
            };
            /**
             * Returns the op node associated with the metanode.
             * For example, if the metanode is 'sgd', the associated
             * op node is sgd/(sgd).
             */
            MetanodeImpl.prototype.getRootOp = function () {
                var nameSplit = this.name.split('/');
                var rootOpName = this.name + '/(' + nameSplit[nameSplit.length - 1] + ')';
                return this.metagraph.node(rootOpName);
            };
            /**
             * Return an array of the names of all the leaves (non-GroupNodes) inside
             * this metanode. This performs a breadth-first search of the tree, so
             * immediate child leaves will appear earlier in the output array than
             * descendant leaves.
             */
            MetanodeImpl.prototype.leaves = function () {
                var leaves = [];
                var queue = [this];
                var metagraph; // Defined here due to a limitation of ES6->5 compilation.
                while (queue.length) {
                    var node = queue.shift();
                    if (node.isGroupNode) {
                        metagraph = node.metagraph;
                        _.each(metagraph.nodes(), function (name) { return queue.push(metagraph.node(name)); });
                    }
                    else {
                        leaves.push(node.name);
                    }
                }
                return leaves;
            };
            return MetanodeImpl;
        }());
        graph_1.MetanodeImpl = MetanodeImpl;
        ;
        function createMetaedge(v, w) {
            return new MetaedgeImpl(v, w);
        }
        graph_1.createMetaedge = createMetaedge;
        /**
         * A label object for edges between metanodes of subgraphs in the render graph.
         */
        var MetaedgeImpl = /** @class */ (function () {
            function MetaedgeImpl(v, w) {
                this.v = v;
                this.w = w;
                this.baseEdgeList = [];
                this.inbound = null;
                this.numRegularEdges = 0;
                this.numControlEdges = 0;
                this.numRefEdges = 0;
                this.totalSize = 0;
            }
            MetaedgeImpl.prototype.addBaseEdge = function (edge, h) {
                this.baseEdgeList.push(edge);
                if (edge.isControlDependency) {
                    this.numControlEdges += 1;
                }
                else {
                    this.numRegularEdges += 1;
                }
                if (edge.isReferenceEdge) {
                    this.numRefEdges += 1;
                }
                // Compute the size of the tensor flowing through this
                // base edge.
                this.totalSize += MetaedgeImpl.computeSizeOfEdge(edge, h);
                h.maxMetaEdgeSize = Math.max(h.maxMetaEdgeSize, this.totalSize);
            };
            MetaedgeImpl.computeSizeOfEdge = function (edge, h) {
                var opNode = h.node(edge.v);
                if (!opNode.outputShapes) {
                    // No shape information. Asssume a single number. This gives
                    // a lower bound for the total size.
                    return 1;
                }
                h.hasShapeInfo = true;
                // Sum the sizes of all output tensors.
                return _(opNode.outputShapes).mapValues(function (shape) {
                    // If the shape is unknown, treat it as 1 when computing
                    // total size. This gives a lower bound for the total size.
                    if (shape == null) {
                        return 1;
                    }
                    // Multiply all shapes to get the total size of the tensor.
                    // E.g. The total size of [4, 2, 1] is 4 * 2 * 1.
                    return _(shape).reduce(function (accumulated, currSize) {
                        // If this particular dimension is unknown, treat
                        // it as 1 when computing total size. This gives a lower bound
                        // for the total size.
                        if (currSize === -1) {
                            currSize = 1;
                        }
                        return accumulated * currSize;
                    }, 1);
                }).sum();
            };
            return MetaedgeImpl;
        }());
        graph_1.MetaedgeImpl = MetaedgeImpl;
        function createSeriesNode(prefix, suffix, parent, clusterId, name, graphOptions) {
            return new SeriesNodeImpl(prefix, suffix, parent, clusterId, name, graphOptions);
        }
        graph_1.createSeriesNode = createSeriesNode;
        function getSeriesNodeName(prefix, suffix, parent, startId, endId) {
            var numRepresentation = (typeof startId !== 'undefined' && typeof endId !== 'undefined') ?
                '[' + startId + '-' + endId + ']' :
                '#';
            var pattern = prefix + numRepresentation + suffix;
            return (parent ? parent + '/' : '') + pattern;
        }
        graph_1.getSeriesNodeName = getSeriesNodeName;
        var SeriesNodeImpl = /** @class */ (function () {
            function SeriesNodeImpl(prefix, suffix, parent, clusterId, name, graphOptions) {
                this.name = name || getSeriesNodeName(prefix, suffix, parent);
                this.type = NodeType.SERIES;
                this.hasLoop = false;
                this.prefix = prefix;
                this.suffix = suffix;
                this.clusterId = clusterId;
                this.ids = [];
                this.parent = parent;
                this.isGroupNode = true;
                this.cardinality = 0;
                this.metagraph = createGraph(name, GraphType.SERIES, graphOptions);
                // bridgegraph must be constructed lazily-see hierarchy.getBridgegraph()
                this.bridgegraph = null;
                this.parentNode = null;
                this.deviceHistogram = {};
                this.xlaClusterHistogram = {};
                this.compatibilityHistogram = { compatible: 0, incompatible: 0 };
                this.hasNonControlEdges = false;
                this.include = InclusionType.UNSPECIFIED;
            }
            return SeriesNodeImpl;
        }());
        /**
         * Extracts the shapes of the output tensors from the attr property in the
         * node proto.
         */
        // tslint:disable-next-line:no-any
        function extractOutputShapes(attr) {
            var result = null;
            // We don't know anything about the output tensors.
            if (!attr) {
                return null;
            }
            for (var i = 0; i < attr.length; i++) {
                var _a = attr[i], key = _a.key, value = _a.value;
                if (key === OUTPUT_SHAPES_KEY) {
                    if (!value.list.shape) {
                        // The OUTPUT_SHAPES_KEY lacks a value. We know nothing about the shape.
                        return null;
                    }
                    // Map all output tensors into array of numbers denoting their shape.
                    var result_1 = value.list.shape.map(function (shape) {
                        if (shape.unknown_rank) {
                            // This output tensor is of unknown rank. We don't know if it is a
                            // scalar, or a tensor, or of what shape it is.
                            return null;
                        }
                        if (shape.dim == null ||
                            (shape.dim.length === 1 && shape.dim[0].size == null)) {
                            // This output tensor is a scalar.
                            return [];
                        }
                        // This output tensor has a known rank. Map each dimension size
                        // into a number.
                        return shape.dim.map(function (dim) {
                            // Size can be -1 if this particular dimension is unknown.
                            return dim.size;
                        });
                    });
                    // Since we already processed it, remove the entry from the attribute
                    // list (saves memory).
                    attr.splice(i, 1);
                    return result_1;
                }
            }
            // We didn't find OUTPUT_SHAPES_KEY in attributes, so we don't know anything
            // about the output tensors.
            return null;
        }
        /**
         * Extracts the XLA Cluster that an op runs on from the attrs of the OpNode.
         * @param attr The attr property.
         * @return A string that is the name of the cluster. Or null if it could not be
         *     determined.
         */
        // tslint:disable-next-line:no-any
        function extractXlaCluster(attr) {
            if (!attr) {
                return null;
            }
            // Find the attribute for XLA cluster if there is one.
            for (var i = 0; i < attr.length; i++) {
                if (attr[i].key === _XLA_CLUSTER_KEY) {
                    return attr[i].value['s'] || null;
                }
            }
            return null;
        }
        /**
         * Normalizes the inputs and extracts associated metadata:
         * 1) Inputs can contain a colon followed by a suffix of characters.
         *    That suffix may be a single number (e.g. inputName:1) or several word
         *    characters separated from a number by a colon (e.g. inputName:foo:1). The
         *    latter case is used to denote inputs and outputs of functions.
         * 2) Control dependency inputs contain caret at the beginning and we
         *    remove this and annotate the edge as a control dependency.
         * @param inputs Array of unnormalized names of input nodes.
         */
        function normalizeInputs(inputs) {
            var normalizedInputs = [];
            _.each(inputs, function (inputName) {
                var isControlDependency = inputName[0] === '^';
                if (isControlDependency) {
                    // The carat merely indicates whether this input is a control dependency.
                    // It should not be part of the name.
                    inputName = inputName.substring(1);
                }
                var name = inputName;
                var outputTensorKey = '0';
                var match = inputName.match(/(.*):(\w+:\d+)$/);
                if (match) {
                    // The output string consists of several characters and a number separated
                    // by a colon.
                    name = match[1];
                    outputTensorKey = match[2];
                }
                else {
                    match = inputName.match(/(.*):(\d+)$/);
                    if (match) {
                        // The output string consists of a single number.
                        name = match[1];
                        outputTensorKey = match[2];
                    }
                }
                if (normalizedInputs.length === 0 ||
                    name !== normalizedInputs[normalizedInputs.length - 1].name) {
                    normalizedInputs.push({
                        name: name,
                        outputTensorKey: outputTensorKey,
                        isControlDependency: isControlDependency,
                    });
                }
            });
            return normalizedInputs;
        }
        function addEdgeToGraph(graph, inputName, outputNode, input, params, index) {
            // Don't allow loops in the graph.
            if (inputName === outputNode.name) {
                return;
            }
            // Check if this op type and input number corresponds to a
            // reference edge using the refEdges dictionary in the params.
            var isRefEdge = params.refEdges[outputNode.op + ' ' + index] === true;
            graph.edges.push({
                v: inputName,
                w: outputNode.name,
                outputTensorKey: input.outputTensorKey,
                isControlDependency: input.isControlDependency,
                isReferenceEdge: isRefEdge
            });
        }
        function build(graphDef, params, tracker) {
            /**
             * A dictionary that maps each in-embedding node name to the node
             * object.
             */
            var inEmbedding = {};
            /**
             * A dictionary that maps each out-embedding node name to the node
             * object.
             */
            var outEmbedding = {};
            /**
             * A dictionary that maps each node name to an array of the node's
             * out-embedding node label objects.
             */
            var outEmbeddings = {};
            var isInEmbeddedPred = getEmbedPredicate(params.inEmbeddingTypes);
            var isOutEmbeddedPred = getEmbedPredicate(params.outEmbeddingTypes);
            var embeddingNodeNames = [];
            var rawNodes = graphDef.node;
            /**
             * A list of all the non-embedding node names which appear in the processed
             * list of raw nodes. Here we pre-allocate enough room for all the rawNodes,
             * even though there will some number of embeddings. The excess array length
             * is spliced off later.
             *
             * Experimentation shows that around 30% of the array will go unused, and
             * even for very large networks that amounts to less than 10k spaces.
             */
            var nodeNames = new Array(rawNodes.length);
            return tf.graph.util
                .runAsyncTask('Normalizing names', 30, function () {
                var opNodes = new Array(rawNodes.length);
                var index = 0;
                var processRawNode = function (rawNode) {
                    var opNode = new OpNodeImpl(rawNode);
                    if (isInEmbeddedPred(opNode)) {
                        embeddingNodeNames.push(opNode.name);
                        inEmbedding[opNode.name] = opNode;
                        return opNode;
                    }
                    if (isOutEmbeddedPred(opNode)) {
                        embeddingNodeNames.push(opNode.name);
                        outEmbedding[opNode.name] = opNode;
                        _.each(opNode.inputs, function (input) {
                            var inputName = input.name;
                            outEmbeddings[inputName] = outEmbeddings[inputName] || [];
                            outEmbeddings[inputName].push(opNode);
                        });
                        return opNode;
                    }
                    // The node is not an embedding, so add it to the names and nodes
                    // lists.
                    opNodes[index] = opNode;
                    nodeNames[index] = opNode.name;
                    index++;
                    return opNode;
                };
                _.each(rawNodes, processRawNode);
                var processFunction = function (func) {
                    // Give the function itself a node.
                    var functionNodeName = graph_1.FUNCTION_LIBRARY_NODE_PREFIX + func.signature.name;
                    // Create an op node for the function. Mark it as part of a
                    // function library.
                    processRawNode({
                        name: functionNodeName,
                        input: [],
                        device: '',
                        op: '',
                        attr: [],
                    });
                    // If the function has inputs, make nodes out of them.
                    if (func.signature.input_arg) {
                        // Makes an OpNode out of either an input_arg of a library
                        // function.
                        var currentInputIndex_1 = 0;
                        var processInput = function (arg) {
                            var opNode = processRawNode({
                                name: functionNodeName + graph_1.NAMESPACE_DELIM + arg.name,
                                input: [],
                                device: '',
                                op: 'input_arg',
                                attr: [{
                                        key: 'T',
                                        value: {
                                            type: arg.type,
                                        },
                                    }],
                            });
                            opNode.functionInputIndex = currentInputIndex_1;
                            currentInputIndex_1++;
                        };
                        // Make nodes for input args of the function. Unfortunately, the
                        // pbtxt configuration language is not rich enough to
                        // differentiate between an array with 1 item vs 1 object
                        // property.
                        if (func.signature.input_arg['name']) {
                            // There is only 1 input arg.
                            processInput(func.signature.input_arg);
                        }
                        else {
                            // There are several input args.
                            _.each(func.signature.input_arg, processInput);
                        }
                    }
                    // Make nodes for output args of the function. Track the names of
                    // output args within the keys of this object. Unlike the
                    // input_args, the output_args are already defined within the
                    // node_defs of the library function.
                    var currentOutputIndex = 0;
                    var outputArgNames = {};
                    // If the function has outputs, make nodes out of them.
                    if (func.signature.output_arg) {
                        var processOutput = function (arg) {
                            outputArgNames[functionNodeName + graph_1.NAMESPACE_DELIM + arg.name] =
                                currentOutputIndex;
                            currentOutputIndex++;
                        };
                        if (func.signature.output_arg['name']) {
                            // There is only 1 output arg.
                            processOutput(func.signature.output_arg);
                        }
                        else {
                            // There are several output args.
                            _.each(func.signature.output_arg, processOutput);
                        }
                    }
                    _.each(func.node_def, function (rawNode) {
                        // Prefix with the name of the function so that the graph
                        // correctly computes the hierarchy (and makes metanodes).
                        rawNode.name = functionNodeName + '/' + rawNode.name;
                        if (typeof rawNode.input === 'string') {
                            rawNode.input = [rawNode.input];
                        }
                        var opNode = processRawNode(rawNode);
                        if (_.isNumber(outputArgNames[rawNode.name])) {
                            // Mark the node as one of the outputs of the function.
                            opNode.functionOutputIndex = outputArgNames[rawNode.name];
                        }
                        _.each(opNode.inputs, function (normalizedInput) {
                            normalizedInput.name =
                                functionNodeName + graph_1.NAMESPACE_DELIM + normalizedInput.name;
                        });
                    });
                };
                if (graphDef.library && graphDef.library.function) {
                    // This graph contains functions.
                    _.each(graphDef.library.function, processFunction);
                }
                opNodes.splice(index);
                nodeNames.splice(index);
                return opNodes;
            }, tracker)
                .then(function (opNodes) {
                // Create the graph data structure from the graphlib library.
                return tf.graph.util.runAsyncTask('Building the data structure', 70, function () {
                    var normalizedNameDict = mapStrictHierarchy(nodeNames, embeddingNodeNames);
                    var graph = new SlimGraph;
                    // Add the nodes to the graph.
                    _.each(opNodes, function (opNode) {
                        var normalizedName = normalizedNameDict[opNode.name] || opNode.name;
                        graph.nodes[normalizedName] = opNode;
                        // Check if the node has out-embeddings. If yes, add them to the
                        // node.
                        if (opNode.name in outEmbeddings) {
                            opNode.outEmbeddings = outEmbeddings[opNode.name];
                            // Normalize the names of the out-embeddings.
                            _.each(opNode.outEmbeddings, function (node) {
                                node.name = normalizedNameDict[node.name] || node.name;
                            });
                        }
                        // Update the name of the node.
                        opNode.name = normalizedName;
                    });
                    // Visit each node's inputs to add the edges to the graph. If the
                    // input
                    // is an in-embedding, then add it to the node's in-embeddings
                    // instead.
                    _.each(opNodes, function (opNode) {
                        _.each(opNode.inputs, function (input, i) {
                            var inputName = input.name;
                            if (inputName in inEmbedding) {
                                var inEmbedNode = inEmbedding[inputName];
                                opNode.inEmbeddings.push(inEmbedNode);
                                // Move the inputs of the in-embedding node into incoming
                                // edges of
                                // the main node. E.g. the control dependency of a constant
                                // node
                                // should be moved to the op node where the constant is
                                // embedded.
                                for (var _i = 0, _a = inEmbedNode.inputs; _i < _a.length; _i++) {
                                    var embedInput = _a[_i];
                                    addEdgeToGraph(graph, normalizedNameDict[embedInput.name] ||
                                        embedInput.name, opNode, embedInput, params, i);
                                }
                            }
                            else if (inputName in outEmbedding) {
                                // Move the inputs of the out-embedding node into inputs of
                                // the main node where the out-embedding points to.
                                var outEmbedNode = outEmbedding[inputName];
                                for (var _b = 0, _c = outEmbedNode.inputs; _b < _c.length; _b++) {
                                    var embedInput = _c[_b];
                                    addEdgeToGraph(graph, normalizedNameDict[embedInput.name] ||
                                        embedInput.name, opNode, input, params, i);
                                }
                            }
                            else {
                                addEdgeToGraph(graph, normalizedNameDict[inputName] || inputName, opNode, input, params, i);
                            }
                        });
                    });
                    // Normalize the names of in-embeddings.
                    _.each(inEmbedding, function (node, name) {
                        node.name = normalizedNameDict[node.name] || node.name;
                    });
                    return graph;
                }, tracker);
            });
        }
        graph_1.build = build;
        ;
        /**
         * Create a new graphlib.Graph() instance with default parameters
         */
        function createGraph(name, type, opt) {
            var graphOptions = opt || {};
            var graph = new graphlib.Graph(graphOptions);
            graph.setGraph({
                name: name,
                rankdir: graphOptions.rankdir || 'BT',
                type: type
            });
            return graph;
        }
        graph_1.createGraph = createGraph;
        ;
        /**
         * Create a predicate for checking whether a node should be embedded based on
         * the specified types.
         */
        function getEmbedPredicate(types) {
            return function (node) {
                // check types
                for (var i = 0; i < types.length; i++) {
                    var regExp = new RegExp(types[i]);
                    if (node.op.match(regExp)) {
                        return true;
                    }
                }
                return false;
            };
        }
        ;
        /**
         * Returns a strict node name (name => name/(name)) to avoid conflicts
         * where the node name is also a namespace.
         */
        function getStrictName(name) {
            var parts = name.split(graph_1.NAMESPACE_DELIM);
            return name + graph_1.NAMESPACE_DELIM + '(' + parts[parts.length - 1] + ')';
        }
        graph_1.getStrictName = getStrictName;
        /**
         * For each op node (embedding or non-embedding), rename it if there is a
         * non-embedding node under its namespace. For example, assume node name 'A'.
         * If there is a non-embedding node under its namespace (e.g. 'A/B'), 'A' will
         * be renamed to 'A/(A)'. Then the namespace 'A' will contain 2 nodes: '(A)'
         * and 'B'. If all the nodes under 'A' are embedding nodes (e.g. constant and
         * summary), keep 'A' as an Op node and don't create a namespace.
         *
         * @param nodeNames An array of regular (non-embedding) node names.
         * @param embeddingNodeNames An array of embedding node names.
         * @return Dictionary object mapping names that need to be renamed to
         *     new names.
         */
        function mapStrictHierarchy(nodeNames, embeddingNodeNames) {
            /** Dictionary that maps the old new to the new name */
            var newNameDictionary = {};
            /** Set used to store all namespaces. */
            var namespaceSet = {};
            // sort the nodes to make prefix check faster
            nodeNames.sort();
            // look for nodes with a prefix a,a/b -> a/(a),a/b
            for (var i = 0; i < nodeNames.length - 1; ++i) {
                var a = nodeNames[i];
                // Get all the parent namespaces of the current node
                // and add them in the namespace set.
                _.each(getHierarchicalPath(a).slice(0, -1), function (ns) {
                    namespaceSet[ns] = true;
                });
                for (var j = i + 1; j < nodeNames.length; ++j) {
                    var b = nodeNames[j];
                    if (_.startsWith(b, a)) {
                        if (b.length > a.length && b.charAt(a.length) === graph_1.NAMESPACE_DELIM) {
                            newNameDictionary[a] = getStrictName(a);
                            break;
                        }
                    }
                    else {
                        break;
                    }
                }
            }
            // Go through all the embedding node names and rename them in case they
            // collide with namespaces.
            _.each(embeddingNodeNames, function (embeddingName) {
                if (embeddingName in namespaceSet) {
                    // Rename to follow strict hierarchy.
                    newNameDictionary[embeddingName] = getStrictName(embeddingName);
                }
            });
            return newNameDictionary;
        }
        ;
        /**
         * Returns a list of the degrees of each node in the graph.
         */
        function degreeSequence(graph) {
            var degrees = graph.nodes().map(function (name) {
                return graph.neighbors(name).length;
            });
            degrees.sort();
            return degrees;
        }
        ;
        /**
         * Returns if the degree sequence of the two graphs is the same.
         */
        function hasSimilarDegreeSequence(graph1, graph2) {
            var dg1 = degreeSequence(graph1);
            var dg2 = degreeSequence(graph2);
            for (var i = 0; i < dg1.length; i++) {
                if (dg1[i] !== dg2[i]) {
                    return false;
                }
            }
            return true;
        }
        graph_1.hasSimilarDegreeSequence = hasSimilarDegreeSequence;
        ;
        /**
         * Returns the hierarchical path of the current node, based on the node's name.
         * For example, if the name is 'a/b/c', the returned path is
         * ['a', 'a/b', 'a/b/c'].
         */
        function getHierarchicalPath(name, seriesNames) {
            var path = [];
            var i = name.indexOf(graph_1.NAMESPACE_DELIM);
            // Push all parent portions of the path.
            while (i >= 0) {
                path.push(name.substring(0, i));
                i = name.indexOf(graph_1.NAMESPACE_DELIM, i + 1);
            }
            // If the node's path is under a series, then add the series node name to the
            // hierarchical path as the parent of the leaf.
            if (seriesNames) {
                var seriesName = seriesNames[name];
                if (seriesName) {
                    path.push(seriesName);
                }
            }
            // Push the leaf of the path.
            path.push(name);
            return path;
        }
        graph_1.getHierarchicalPath = getHierarchicalPath;
        ;
        /**
         * Returns the string for the node inclusion toggle button, dependant
         * on the provided current InclusionType.
         */
        function getIncludeNodeButtonString(include) {
            if (include === tf.graph.InclusionType.EXCLUDE) {
                return 'Add to main graph';
            }
            else {
                return 'Remove from main graph';
            }
        }
        graph_1.getIncludeNodeButtonString = getIncludeNodeButtonString;
        ;
        /**
         * Returns the string for the series node grouping toggle button, dependant
         * on the provided current SeriesGroupingType.
         */
        function getGroupSeriesNodeButtonString(group) {
            if (group === tf.graph.SeriesGroupingType.GROUP) {
                return 'Ungroup this series of nodes';
            }
            else {
                return 'Group this series of nodes';
            }
        }
        graph_1.getGroupSeriesNodeButtonString = getGroupSeriesNodeButtonString;
        ;
        /**
         * Toggle the node series grouping option in the provided map, setting it
         * to ungroup if the series is not already in the map.
         */
        function toggleNodeSeriesGroup(map, name) {
            if (!(name in map) || map[name] === tf.graph.SeriesGroupingType.GROUP) {
                map[name] = tf.graph.SeriesGroupingType.UNGROUP;
            }
            else {
                map[name] = tf.graph.SeriesGroupingType.GROUP;
            }
        }
        graph_1.toggleNodeSeriesGroup = toggleNodeSeriesGroup;
        ;
    })(graph = tf.graph || (tf.graph = {}));
})(tf || (tf = {})); // close module tf.graph
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3JhcGguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJncmFwaC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7Ozs7Ozs7OztnRkFhZ0Y7QUFDaEYsSUFBTyxFQUFFLENBMDVDUjtBQTE1Q0QsV0FBTyxFQUFFO0lBQUMsSUFBQSxLQUFLLENBMDVDZDtJQTE1Q1MsV0FBQSxPQUFLO1FBRWYseURBQXlEO1FBQzVDLHVCQUFlLEdBQUcsR0FBRyxDQUFDO1FBQ3RCLGlCQUFTLEdBQUcsVUFBVSxDQUFDO1FBQ3ZCLG9DQUE0QixHQUFHLHNCQUFzQixDQUFDO1FBRW5FLG9FQUFvRTtRQUN2RCx1QkFBZSxHQUFHLGtCQUFrQixDQUFDO1FBQ2xEOzs7V0FHRztRQUNVLHVCQUFlLEdBQUcsSUFBSSxDQUFDO1FBRXBDLHFFQUFxRTtRQUN4RCxzQkFBYyxHQUFHLElBQUksQ0FBQztRQUVuQyxJQUFZLFNBQ0g7UUFEVCxXQUFZLFNBQVM7WUFBRSx5Q0FBSSxDQUFBO1lBQUUsaURBQVEsQ0FBQTtZQUFFLHlDQUFJLENBQUE7WUFBRSw2Q0FBTSxDQUFBO1lBQUUseUNBQUksQ0FBQTtZQUFFLDZDQUFNLENBQUE7WUFBRSw2Q0FBTSxDQUFBO1lBQ3JFLHlDQUFJLENBQUE7UUFBQSxDQUFDLEVBREcsU0FBUyxHQUFULGlCQUFTLEtBQVQsaUJBQVMsUUFDWjtRQUFBLENBQUM7UUFDVixJQUFZLFFBQTZDO1FBQXpELFdBQVksUUFBUTtZQUFFLHVDQUFJLENBQUE7WUFBRSxtQ0FBRSxDQUFBO1lBQUUsMkNBQU0sQ0FBQTtZQUFFLDJDQUFNLENBQUE7WUFBRSwrQ0FBUSxDQUFBO1FBQUEsQ0FBQyxFQUE3QyxRQUFRLEdBQVIsZ0JBQVEsS0FBUixnQkFBUSxRQUFxQztRQUFBLENBQUM7UUFFMUQsNkVBQTZFO1FBQzdFLElBQVksYUFBNkM7UUFBekQsV0FBWSxhQUFhO1lBQUUsdURBQU8sQ0FBQTtZQUFFLHVEQUFPLENBQUE7WUFBRSwrREFBVyxDQUFBO1FBQUEsQ0FBQyxFQUE3QyxhQUFhLEdBQWIscUJBQWEsS0FBYixxQkFBYSxRQUFnQztRQUFBLENBQUM7UUFFMUQseUVBQXlFO1FBQ3pFLElBQVksa0JBQW1DO1FBQS9DLFdBQVksa0JBQWtCO1lBQUUsNkRBQUssQ0FBQTtZQUFFLGlFQUFPLENBQUE7UUFBQSxDQUFDLEVBQW5DLGtCQUFrQixHQUFsQiwwQkFBa0IsS0FBbEIsMEJBQWtCLFFBQWlCO1FBQUEsQ0FBQztRQUVoRCxtRUFBbUU7UUFDbkUsSUFBTSxpQkFBaUIsR0FBRyxnQkFBZ0IsQ0FBQztRQUUzQyxxRUFBcUU7UUFDckUsSUFBTSxnQkFBZ0IsR0FBRyxhQUFhLENBQUM7UUFldkM7OztXQUdHO1FBQ0g7WUFJRTtnQkFDRSxJQUFJLENBQUMsS0FBSyxHQUFHLEVBQUUsQ0FBQztnQkFDaEIsSUFBSSxDQUFDLEtBQUssR0FBRyxFQUFFLENBQUM7WUFDbEIsQ0FBQztZQUNILGdCQUFDO1FBQUQsQ0FBQyxBQVJELElBUUM7UUFSWSxpQkFBUyxZQVFyQixDQUFBO1FBMlFEO1lBVUU7Ozs7ZUFJRztZQUNILDBCQUFZLFFBQWdCO2dCQUMxQixJQUFJLENBQUMsSUFBSSxHQUFHLFFBQVEsQ0FBQyxRQUFRLENBQUM7Z0JBQzlCLElBQUksQ0FBQyxXQUFXLEdBQUcsS0FBSyxDQUFDO2dCQUN6QixJQUFJLENBQUMsV0FBVyxHQUFHLENBQUMsQ0FBQztnQkFDckIsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUM7Z0JBQ3ZCLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDO2dCQUNsQixJQUFJLENBQUMsZUFBZSxDQUFDLFFBQVEsQ0FBQyxDQUFDO2dCQUMvQixJQUFJLENBQUMsT0FBTyxHQUFHLGFBQWEsQ0FBQyxXQUFXLENBQUM7WUFDM0MsQ0FBQztZQUVELDBDQUFlLEdBQWYsVUFBZ0IsUUFBZ0I7Z0JBQzlCLElBQUksQ0FBQyxZQUFZLEdBQUcsUUFBUSxDQUFDO2dCQUM3QixJQUFJLENBQUMsSUFBSSxHQUFHLE1BQU0sR0FBRyxRQUFRLEdBQUcsT0FBTyxDQUFDO1lBQzFDLENBQUM7WUFDSCx1QkFBQztRQUFELENBQUMsQUE3QkQsSUE2QkM7UUE3Qlksd0JBQWdCLG1CQTZCNUIsQ0FBQTtRQUFBLENBQUM7UUFFRjs7O1dBR0c7UUFDSDtZQTRCRTs7OztlQUlHO1lBQ0gsb0JBQVksT0FBK0I7Z0JBQ3pDLElBQUksQ0FBQyxFQUFFLEdBQUcsT0FBTyxDQUFDLEVBQUUsQ0FBQztnQkFDckIsSUFBSSxDQUFDLElBQUksR0FBRyxPQUFPLENBQUMsSUFBSSxDQUFDO2dCQUN6QixJQUFJLENBQUMsTUFBTSxHQUFHLE9BQU8sQ0FBQyxNQUFNLENBQUM7Z0JBQzdCLElBQUksQ0FBQyxJQUFJLEdBQUcsT0FBTyxDQUFDLElBQUksQ0FBQztnQkFDekIsa0VBQWtFO2dCQUNsRSxtRUFBbUU7Z0JBQ25FLGdFQUFnRTtnQkFDaEUsc0JBQXNCO2dCQUN0QixJQUFJLENBQUMsTUFBTSxHQUFHLGVBQWUsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQzdDLElBQUksQ0FBQyxZQUFZLEdBQUcsbUJBQW1CLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUN0RCxJQUFJLENBQUMsVUFBVSxHQUFHLGlCQUFpQixDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDbEQsSUFBSSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7Z0JBQ3hCLHdCQUF3QjtnQkFDeEIsSUFBSSxDQUFDLElBQUksR0FBRyxRQUFRLENBQUMsRUFBRSxDQUFDO2dCQUN4QixJQUFJLENBQUMsV0FBVyxHQUFHLEtBQUssQ0FBQztnQkFDekIsSUFBSSxDQUFDLFdBQVcsR0FBRyxDQUFDLENBQUM7Z0JBQ3JCLElBQUksQ0FBQyxZQUFZLEdBQUcsRUFBRSxDQUFDO2dCQUN2QixJQUFJLENBQUMsYUFBYSxHQUFHLEVBQUUsQ0FBQztnQkFDeEIsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUM7Z0JBQ3ZCLElBQUksQ0FBQyxPQUFPLEdBQUcsYUFBYSxDQUFDLFdBQVcsQ0FBQztnQkFDekMsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUM7WUFDM0IsQ0FBQztZQUNILGlCQUFDO1FBQUQsQ0FBQyxBQXhERCxJQXdEQztRQXhEWSxrQkFBVSxhQXdEdEIsQ0FBQTtRQUFBLENBQUM7UUFFRix3QkFBK0IsSUFBWSxFQUFFLEdBQVE7WUFBUixvQkFBQSxFQUFBLFFBQVE7WUFDbkQsT0FBTyxJQUFJLFlBQVksQ0FBQyxJQUFJLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDckMsQ0FBQztRQUZlLHNCQUFjLGlCQUU3QixDQUFBO1FBRUQ7OztXQUdHO1FBQ0gsZ0NBQ0ksS0FBZ0IsRUFBRSxLQUErQixFQUNqRCxlQUE2QztZQUMvQyw2QkFBNkI7WUFDN0IsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxFQUFFLFVBQUEsSUFBSSxJQUFNLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFFcEQsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsU0FBUyxFQUFFLFVBQUEsUUFBUTtnQkFDOUIsd0NBQXdDO2dCQUN4QyxJQUFJLGVBQWUsSUFBSSxDQUFDLGVBQWUsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLEVBQUU7b0JBQ3hELE9BQU87aUJBQ1I7Z0JBQ0QsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsVUFBVSxFQUFFLFVBQUEsU0FBUztvQkFDbkMsc0VBQXNFO29CQUN0RSx1RUFBdUU7b0JBQ3ZFLCtCQUErQjtvQkFDL0IsSUFBSSxRQUFRLEdBQUcsU0FBUyxDQUFDLFNBQVMsSUFBSSxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7d0JBQy9DLFNBQVMsQ0FBQyxTQUFTLENBQUMsQ0FBQzt3QkFDckIsYUFBYSxDQUFDLFNBQVMsQ0FBQyxTQUFTLENBQUMsQ0FBQztvQkFFdkMsaUNBQWlDO29CQUNqQyxJQUFJLENBQUMsQ0FBQyxRQUFRLElBQUksS0FBSyxDQUFDLEtBQUssQ0FBQyxFQUFFO3dCQUM5QixPQUFPO3FCQUNSO29CQUVELGdDQUFnQztvQkFDaEMsSUFBSSxVQUFVLEdBQUcsQ0FBQyxDQUFDO29CQUNuQixJQUFJLFNBQVMsQ0FBQyxNQUFNLEVBQUU7d0JBQ3BCLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sRUFBRSxVQUFBLEtBQUs7NEJBQzlCLElBQUksS0FBSyxDQUFDLFdBQVcsRUFBRTtnQ0FDbkIsSUFBSSxLQUFLLENBQUMsV0FBVyxHQUFHLENBQUMsRUFBRTtvQ0FDekIsVUFBVSxJQUFJLE1BQU0sQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUM7aUNBQ3pDO3FDQUFNO29DQUNMLG9CQUFvQjtvQ0FDcEIsT0FBTyxDQUFDLEdBQUcsQ0FDUCwwQ0FBMEMsR0FBRyxRQUFRLENBQUMsQ0FBQztvQ0FDM0QsbUJBQW1CO2lDQUNwQjs2QkFDRjt3QkFDSCxDQUFDLENBQUMsQ0FBQztxQkFDSjtvQkFDRCxJQUFJLFVBQVUsR0FBZSxJQUFJLENBQUM7b0JBQ2xDLElBQUksU0FBUyxDQUFDLE1BQU0sRUFBRTt3QkFDcEIsVUFBVSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLE1BQU0sRUFBRSxVQUFBLE1BQU07NEJBQ3pDLE9BQU8sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsa0JBQWtCLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFDNUMsVUFBQSxHQUFHLElBQUksT0FBQSxNQUFNLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFoQixDQUFnQixDQUFDLENBQUM7d0JBQy9CLENBQUMsQ0FBQyxDQUFDO3FCQUNKO29CQUNELEtBQUssQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsTUFBTSxHQUFHLFFBQVEsQ0FBQyxNQUFNLENBQUM7b0JBQy9DLElBQUksS0FBSyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxLQUFLLElBQUksSUFBSSxFQUFFO3dCQUN2QyxLQUFLLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLEtBQUssR0FBRyxJQUFJLFNBQVMsQ0FBQyxVQUFVLENBQUMsQ0FBQztxQkFDekQ7b0JBQ0QsS0FBSyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxLQUFLLENBQUMsa0JBQWtCLENBQUMsVUFBVSxDQUFDLENBQUM7b0JBQzNELElBQUksU0FBUyxDQUFDLGtCQUFrQixFQUFFO3dCQUNoQyxJQUFJLFNBQVMsQ0FBQyxrQkFBa0IsR0FBRyxDQUFDLEVBQUU7NEJBQ3BDLEtBQUssQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsS0FBSyxDQUFDLGdCQUFnQixDQUN4QyxTQUFTLENBQUMsZ0JBQWdCLEVBQzFCLFNBQVMsQ0FBQyxnQkFBZ0IsR0FBRyxTQUFTLENBQUMsa0JBQWtCLENBQUMsQ0FBQzt5QkFDaEU7NkJBQU07NEJBQ0wsb0JBQW9COzRCQUNwQixPQUFPLENBQUMsR0FBRyxDQUFDLGdDQUFnQyxHQUFHLFFBQVEsQ0FBQyxDQUFDOzRCQUN6RCxtQkFBbUI7eUJBQ3BCO3FCQUNGO2dCQUNILENBQUMsQ0FBQyxDQUFDO1lBQ0wsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDO1FBakVlLDhCQUFzQix5QkFpRXJDLENBQUE7UUFFRDs7V0FFRztRQUNIO1lBQ0UsbUJBQVksVUFBc0I7Z0JBdUNsQzs7O21CQUdHO2dCQUNILGVBQVUsR0FBRyxDQUFDLENBQUM7Z0JBM0N1QixJQUFJLENBQUMsVUFBVSxHQUFHLFVBQVUsQ0FBQztZQUFDLENBQUM7WUFFckU7OztlQUdHO1lBQ0gsb0NBQWdCLEdBQWhCLFVBQWlCLFNBQWlCLEVBQUUsT0FBZTtnQkFDakQsSUFBSSxJQUFJLENBQUMsU0FBUyxJQUFJLElBQUksRUFBRTtvQkFDMUIsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsU0FBUyxDQUFDLENBQUM7aUJBQ3REO3FCQUFNO29CQUNMLElBQUksQ0FBQyxTQUFTLEdBQUcsU0FBUyxDQUFDO2lCQUM1QjtnQkFDRCxJQUFJLElBQUksQ0FBQyxPQUFPLElBQUksSUFBSSxFQUFFO29CQUN4QixJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUMsQ0FBQztpQkFDaEQ7cUJBQU07b0JBQ0wsSUFBSSxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUM7aUJBQ3hCO1lBQ0gsQ0FBQztZQUVEOzs7ZUFHRztZQUNILHNDQUFrQixHQUFsQixVQUFtQixVQUFrQjtnQkFDbkMsSUFBSSxJQUFJLENBQUMsVUFBVSxJQUFJLElBQUksRUFBRTtvQkFDM0IsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUUsVUFBVSxDQUFDLENBQUM7aUJBQ3pEO3FCQUFNO29CQUNMLElBQUksQ0FBQyxVQUFVLEdBQUcsVUFBVSxDQUFDO2lCQUM5QjtZQUNILENBQUM7WUFzQkQ7Ozs7ZUFJRztZQUNILDJCQUFPLEdBQVAsVUFBUSxLQUFnQjtnQkFDdEIsSUFBSSxLQUFLLENBQUMsVUFBVSxJQUFJLElBQUksRUFBRTtvQkFDNUIsSUFBSSxDQUFDLFVBQVUsSUFBSSxLQUFLLENBQUMsVUFBVSxDQUFDO2lCQUNyQztnQkFDRCxJQUFJLEtBQUssQ0FBQyxjQUFjLEVBQUUsSUFBSSxJQUFJLEVBQUU7b0JBQ2xDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFLLENBQUMsU0FBUyxFQUFFLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQztpQkFDdkQ7WUFDSCxDQUFDO1lBRUQ7Ozs7O2VBS0c7WUFDSCxrQ0FBYyxHQUFkO2dCQUNFLElBQUksSUFBSSxDQUFDLFNBQVMsSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLE9BQU8sSUFBSSxJQUFJLEVBQUU7b0JBQ2xELE9BQU8sSUFBSSxDQUFDO2lCQUNiO2dCQUNELE9BQU8sSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDO1lBQ3ZDLENBQUM7WUFDSCxnQkFBQztRQUFELENBQUMsQUE5RUQsSUE4RUM7UUE5RVksaUJBQVMsWUE4RXJCLENBQUE7UUFFRDtZQW9CRSwyREFBMkQ7WUFDM0Qsc0JBQVksSUFBWSxFQUFFLEdBQVE7Z0JBQVIsb0JBQUEsRUFBQSxRQUFRO2dCQUNoQyxJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQztnQkFDakIsSUFBSSxDQUFDLElBQUksR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDO2dCQUMxQix3Q0FBd0M7Z0JBQ3hDLElBQUksQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDO2dCQUNmLElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDO2dCQUN4QixnREFBZ0Q7Z0JBQ2hELElBQUksQ0FBQyxXQUFXLEdBQUcsQ0FBQyxDQUFDO2dCQUNyQjs7bUJBRUc7Z0JBQ0gsSUFBSSxDQUFDLFNBQVM7b0JBQ1osV0FBVyxDQUE2QixJQUFJLEVBQUUsU0FBUyxDQUFDLElBQUksRUFBRSxHQUFHLENBQUMsQ0FBQztnQkFDckUsNEVBQTRFO2dCQUM1RSxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQztnQkFDeEI7OzttQkFHRztnQkFDSCxJQUFJLENBQUMsV0FBVyxHQUFHLEVBQUUsQ0FBQztnQkFDdEIsSUFBSSxDQUFDLGVBQWUsR0FBRyxFQUFFLENBQUM7Z0JBQzFCLElBQUksQ0FBQyxtQkFBbUIsR0FBRyxFQUFFLENBQUM7Z0JBQzlCLElBQUksQ0FBQyxzQkFBc0IsR0FBRyxFQUFDLFVBQVUsRUFBRSxDQUFDLEVBQUUsWUFBWSxFQUFFLENBQUMsRUFBQyxDQUFDO2dCQUMvRCxtREFBbUQ7Z0JBQ25ELElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDO2dCQUN2QixnREFBZ0Q7Z0JBQ2hELElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDO2dCQUN2QixJQUFJLENBQUMsa0JBQWtCLEdBQUcsS0FBSyxDQUFDO2dCQUNoQyxJQUFJLENBQUMsT0FBTyxHQUFHLGFBQWEsQ0FBQyxXQUFXLENBQUM7Z0JBQ3pDLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxFQUFFLENBQUM7WUFDL0IsQ0FBQztZQUVELG9DQUFhLEdBQWI7Z0JBQ0UsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDeEQsQ0FBQztZQUVEOzs7O2VBSUc7WUFDSCxnQ0FBUyxHQUFUO2dCQUNFLElBQUksU0FBUyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUNyQyxJQUFJLFVBQVUsR0FBRyxJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksR0FBRyxTQUFTLENBQUMsU0FBUyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUM7Z0JBQzFFLE9BQWUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7WUFDakQsQ0FBQztZQUVEOzs7OztlQUtHO1lBQ0gsNkJBQU0sR0FBTjtnQkFDRSxJQUFJLE1BQU0sR0FBRyxFQUFFLENBQUM7Z0JBQ2hCLElBQUksS0FBSyxHQUFHLENBQVEsSUFBSSxDQUFDLENBQUM7Z0JBQzFCLElBQUksU0FBUyxDQUFDLENBQUMsMERBQTBEO2dCQUN6RSxPQUFPLEtBQUssQ0FBQyxNQUFNLEVBQUU7b0JBQ25CLElBQUksSUFBSSxHQUFHLEtBQUssQ0FBQyxLQUFLLEVBQUUsQ0FBQztvQkFDekIsSUFBSSxJQUFJLENBQUMsV0FBVyxFQUFFO3dCQUNwQixTQUFTLEdBQWdCLElBQUssQ0FBQyxTQUFTLENBQUM7d0JBQ3pDLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssRUFBRSxFQUFFLFVBQUEsSUFBSSxJQUFJLE9BQUEsS0FBSyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQWhDLENBQWdDLENBQUMsQ0FBQztxQkFDckU7eUJBQU07d0JBQ0wsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7cUJBQ3hCO2lCQUNGO2dCQUNELE9BQU8sTUFBTSxDQUFDO1lBQ2hCLENBQUM7WUFDSCxtQkFBQztRQUFELENBQUMsQUF6RkQsSUF5RkM7UUF6Rlksb0JBQVksZUF5RnhCLENBQUE7UUFBQSxDQUFDO1FBZ0RGLHdCQUErQixDQUFTLEVBQUUsQ0FBUztZQUNqRCxPQUFPLElBQUksWUFBWSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUNoQyxDQUFDO1FBRmUsc0JBQWMsaUJBRTdCLENBQUE7UUFFRDs7V0FFRztRQUNIO1lBVUUsc0JBQVksQ0FBUyxFQUFFLENBQVM7Z0JBQzlCLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUNYLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUNYLElBQUksQ0FBQyxZQUFZLEdBQUcsRUFBRSxDQUFDO2dCQUN2QixJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQztnQkFDcEIsSUFBSSxDQUFDLGVBQWUsR0FBRyxDQUFDLENBQUM7Z0JBQ3pCLElBQUksQ0FBQyxlQUFlLEdBQUcsQ0FBQyxDQUFDO2dCQUN6QixJQUFJLENBQUMsV0FBVyxHQUFHLENBQUMsQ0FBQztnQkFDckIsSUFBSSxDQUFDLFNBQVMsR0FBRyxDQUFDLENBQUM7WUFDckIsQ0FBQztZQUVELGtDQUFXLEdBQVgsVUFBWSxJQUFjLEVBQUUsQ0FBc0I7Z0JBQ2hELElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUM3QixJQUFJLElBQUksQ0FBQyxtQkFBbUIsRUFBRTtvQkFDNUIsSUFBSSxDQUFDLGVBQWUsSUFBSSxDQUFDLENBQUM7aUJBQzNCO3FCQUFNO29CQUNMLElBQUksQ0FBQyxlQUFlLElBQUksQ0FBQyxDQUFDO2lCQUMzQjtnQkFDRCxJQUFJLElBQUksQ0FBQyxlQUFlLEVBQUU7b0JBQ3hCLElBQUksQ0FBQyxXQUFXLElBQUksQ0FBQyxDQUFDO2lCQUN2QjtnQkFDRCxzREFBc0Q7Z0JBQ3RELGFBQWE7Z0JBQ2IsSUFBSSxDQUFDLFNBQVMsSUFBSSxZQUFZLENBQUMsaUJBQWlCLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDO2dCQUMxRCxDQUFDLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLGVBQWUsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7WUFDbEUsQ0FBQztZQUVjLDhCQUFpQixHQUFoQyxVQUFpQyxJQUFjLEVBQUUsQ0FBc0I7Z0JBRXJFLElBQUksTUFBTSxHQUFZLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNyQyxJQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksRUFBRTtvQkFDeEIsNERBQTREO29CQUM1RCxvQ0FBb0M7b0JBQ3BDLE9BQU8sQ0FBQyxDQUFDO2lCQUNWO2dCQUNELENBQUMsQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDO2dCQUV0Qix1Q0FBdUM7Z0JBQ3ZDLE9BQU8sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQyxLQUFlO29CQUN0RCx3REFBd0Q7b0JBQ3hELDJEQUEyRDtvQkFDM0QsSUFBSSxLQUFLLElBQUksSUFBSSxFQUFFO3dCQUNqQixPQUFPLENBQUMsQ0FBQztxQkFDVjtvQkFDRCwyREFBMkQ7b0JBQzNELGlEQUFpRDtvQkFDakQsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsTUFBTSxDQUFDLFVBQUMsV0FBVyxFQUFFLFFBQVE7d0JBQzNDLGlEQUFpRDt3QkFDakQsOERBQThEO3dCQUM5RCxzQkFBc0I7d0JBQ3RCLElBQUksUUFBUSxLQUFLLENBQUMsQ0FBQyxFQUFFOzRCQUNuQixRQUFRLEdBQUcsQ0FBQyxDQUFDO3lCQUNkO3dCQUNELE9BQU8sV0FBVyxHQUFHLFFBQVEsQ0FBQztvQkFDaEMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO2dCQUNSLENBQUMsQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDO1lBQ1gsQ0FBQztZQUNILG1CQUFDO1FBQUQsQ0FBQyxBQW5FRCxJQW1FQztRQW5FWSxvQkFBWSxlQW1FeEIsQ0FBQTtRQUVELDBCQUNJLE1BQWMsRUFDZCxNQUFjLEVBQ2QsTUFBYyxFQUNkLFNBQWlCLEVBQ2pCLElBQVksRUFDWixZQUFtQztZQUNyQyxPQUFPLElBQUksY0FBYyxDQUNyQixNQUFNLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRSxTQUFTLEVBQUUsSUFBSSxFQUFFLFlBQVksQ0FBQyxDQUFDO1FBQzdELENBQUM7UUFUZSx3QkFBZ0IsbUJBUy9CLENBQUE7UUFFRCwyQkFBa0MsTUFBYyxFQUFFLE1BQWMsRUFDNUQsTUFBYyxFQUFFLE9BQWdCLEVBQUUsS0FBYztZQUNsRCxJQUFJLGlCQUFpQixHQUNqQixDQUFDLE9BQU8sT0FBTyxLQUFLLFdBQVcsSUFBSSxPQUFPLEtBQUssS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDO2dCQUNsRSxHQUFHLEdBQUcsT0FBTyxHQUFHLEdBQUcsR0FBRyxLQUFLLEdBQUcsR0FBRyxDQUFDLENBQUM7Z0JBQ25DLEdBQUcsQ0FBQztZQUNSLElBQUksT0FBTyxHQUFHLE1BQU0sR0FBRyxpQkFBaUIsR0FBRyxNQUFNLENBQUM7WUFDbEQsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsTUFBTSxHQUFHLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUcsT0FBTyxDQUFDO1FBQ2hELENBQUM7UUFSZSx5QkFBaUIsb0JBUWhDLENBQUE7UUFFRDtZQXNCRSx3QkFDSSxNQUFjLEVBQ2QsTUFBYyxFQUNkLE1BQWMsRUFDZCxTQUFpQixFQUNqQixJQUFZLEVBQ1osWUFBbUM7Z0JBQ3JDLElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxJQUFJLGlCQUFpQixDQUFDLE1BQU0sRUFBRSxNQUFNLEVBQUUsTUFBTSxDQUFDLENBQUM7Z0JBQzlELElBQUksQ0FBQyxJQUFJLEdBQUcsUUFBUSxDQUFDLE1BQU0sQ0FBQztnQkFDNUIsSUFBSSxDQUFDLE9BQU8sR0FBRyxLQUFLLENBQUM7Z0JBQ3JCLElBQUksQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDO2dCQUNyQixJQUFJLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQztnQkFDckIsSUFBSSxDQUFDLFNBQVMsR0FBRyxTQUFTLENBQUM7Z0JBQzNCLElBQUksQ0FBQyxHQUFHLEdBQUcsRUFBRSxDQUFDO2dCQUNkLElBQUksQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDO2dCQUNyQixJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQztnQkFDeEIsSUFBSSxDQUFDLFdBQVcsR0FBRyxDQUFDLENBQUM7Z0JBQ3JCLElBQUksQ0FBQyxTQUFTLEdBQUcsV0FBVyxDQUN4QixJQUFJLEVBQUUsU0FBUyxDQUFDLE1BQU0sRUFBRSxZQUFZLENBQUMsQ0FBQztnQkFDMUMsd0VBQXdFO2dCQUN4RSxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQztnQkFDeEIsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUM7Z0JBQ3ZCLElBQUksQ0FBQyxlQUFlLEdBQUcsRUFBRSxDQUFDO2dCQUMxQixJQUFJLENBQUMsbUJBQW1CLEdBQUcsRUFBRSxDQUFDO2dCQUM5QixJQUFJLENBQUMsc0JBQXNCLEdBQUcsRUFBQyxVQUFVLEVBQUUsQ0FBQyxFQUFFLFlBQVksRUFBRSxDQUFDLEVBQUMsQ0FBQztnQkFDL0QsSUFBSSxDQUFDLGtCQUFrQixHQUFHLEtBQUssQ0FBQztnQkFDaEMsSUFBSSxDQUFDLE9BQU8sR0FBRyxhQUFhLENBQUMsV0FBVyxDQUFDO1lBQzNDLENBQUM7WUFDSCxxQkFBQztRQUFELENBQUMsQUFsREQsSUFrREM7UUFFRDs7O1dBR0c7UUFDSCxrQ0FBa0M7UUFDbEMsNkJBQTZCLElBQXNDO1lBRWpFLElBQUksTUFBTSxHQUFHLElBQUksQ0FBQztZQUNsQixtREFBbUQ7WUFDbkQsSUFBSSxDQUFDLElBQUksRUFBRTtnQkFDVCxPQUFPLElBQUksQ0FBQzthQUNiO1lBQ0QsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7Z0JBQ2hDLElBQUEsWUFBc0IsRUFBckIsWUFBRyxFQUFFLGdCQUFLLENBQVk7Z0JBQzNCLElBQUksR0FBRyxLQUFLLGlCQUFpQixFQUFFO29CQUM3QixJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUU7d0JBQ3JCLHdFQUF3RTt3QkFDeEUsT0FBTyxJQUFJLENBQUM7cUJBQ2I7b0JBRUQscUVBQXFFO29CQUNyRSxJQUFJLFFBQU0sR0FBRyxLQUFLLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsVUFBQSxLQUFLO3dCQUNyQyxJQUFJLEtBQUssQ0FBQyxZQUFZLEVBQUU7NEJBQ3RCLGtFQUFrRTs0QkFDbEUsK0NBQStDOzRCQUMvQyxPQUFPLElBQUksQ0FBQzt5QkFDYjt3QkFDRCxJQUFJLEtBQUssQ0FBQyxHQUFHLElBQUksSUFBSTs0QkFDakIsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLE1BQU0sS0FBSyxDQUFDLElBQUksS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLElBQUksSUFBSSxDQUFDLEVBQUU7NEJBQ3pELGtDQUFrQzs0QkFDbEMsT0FBTyxFQUFFLENBQUM7eUJBQ1g7d0JBQ0QsK0RBQStEO3dCQUMvRCxpQkFBaUI7d0JBQ2pCLE9BQU8sS0FBSyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsVUFBQSxHQUFHOzRCQUN0QiwwREFBMEQ7NEJBQzFELE9BQU8sR0FBRyxDQUFDLElBQUksQ0FBQzt3QkFDbEIsQ0FBQyxDQUFDLENBQUM7b0JBQ0wsQ0FBQyxDQUFDLENBQUM7b0JBQ0gscUVBQXFFO29CQUNyRSx1QkFBdUI7b0JBQ3ZCLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO29CQUNsQixPQUFPLFFBQU0sQ0FBQztpQkFDZjthQUNGO1lBQ0QsNEVBQTRFO1lBQzVFLDRCQUE0QjtZQUM1QixPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7UUFFRDs7Ozs7V0FLRztRQUNILGtDQUFrQztRQUNsQywyQkFBMkIsSUFBc0M7WUFFL0QsSUFBSSxDQUFDLElBQUksRUFBRTtnQkFDVCxPQUFPLElBQUksQ0FBQzthQUNiO1lBRUQsc0RBQXNEO1lBQ3RELEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO2dCQUNwQyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLEtBQUssZ0JBQWdCLEVBQUU7b0JBQ3BDLE9BQU8sSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsSUFBSSxJQUFJLENBQUM7aUJBQ25DO2FBQ0Y7WUFDRCxPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7UUFFRDs7Ozs7Ozs7O1dBU0c7UUFDSCx5QkFBeUIsTUFBZ0I7WUFDdkMsSUFBSSxnQkFBZ0IsR0FBc0IsRUFBRSxDQUFDO1lBQzdDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLFVBQUEsU0FBUztnQkFDdEIsSUFBSSxtQkFBbUIsR0FBRyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxDQUFDO2dCQUMvQyxJQUFJLG1CQUFtQixFQUFFO29CQUN2Qix5RUFBeUU7b0JBQ3pFLHFDQUFxQztvQkFDckMsU0FBUyxHQUFHLFNBQVMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUM7aUJBQ3BDO2dCQUVELElBQUksSUFBSSxHQUFHLFNBQVMsQ0FBQztnQkFDckIsSUFBSSxlQUFlLEdBQUcsR0FBRyxDQUFDO2dCQUUxQixJQUFJLEtBQUssR0FBRyxTQUFTLENBQUMsS0FBSyxDQUFDLGlCQUFpQixDQUFDLENBQUM7Z0JBQy9DLElBQUksS0FBSyxFQUFFO29CQUNULDBFQUEwRTtvQkFDMUUsY0FBYztvQkFDZCxJQUFJLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUNoQixlQUFlLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO2lCQUM1QjtxQkFBTTtvQkFDTCxLQUFLLEdBQUcsU0FBUyxDQUFDLEtBQUssQ0FBQyxhQUFhLENBQUMsQ0FBQztvQkFDdkMsSUFBSSxLQUFLLEVBQUU7d0JBQ1QsaURBQWlEO3dCQUNqRCxJQUFJLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUNoQixlQUFlLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO3FCQUM1QjtpQkFDRjtnQkFFRCxJQUFJLGdCQUFnQixDQUFDLE1BQU0sS0FBSyxDQUFDO29CQUMvQixJQUFJLEtBQUssZ0JBQWdCLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRTtvQkFDN0QsZ0JBQWdCLENBQUMsSUFBSSxDQUFDO3dCQUNwQixJQUFJLEVBQUUsSUFBSTt3QkFDVixlQUFlLEVBQUUsZUFBZTt3QkFDaEMsbUJBQW1CLEVBQUUsbUJBQW1CO3FCQUN6QyxDQUFDLENBQUM7aUJBQ0o7WUFDSCxDQUFDLENBQUMsQ0FBQztZQUNILE9BQU8sZ0JBQWdCLENBQUM7UUFDMUIsQ0FBQztRQUVELHdCQUNJLEtBQWdCLEVBQUUsU0FBaUIsRUFBRSxVQUFrQixFQUN2RCxLQUFzQixFQUFFLE1BQW1CLEVBQUUsS0FBYTtZQUM1RCxrQ0FBa0M7WUFDbEMsSUFBSSxTQUFTLEtBQUssVUFBVSxDQUFDLElBQUksRUFBRTtnQkFDakMsT0FBTzthQUNSO1lBQ0QsMERBQTBEO1lBQzFELDhEQUE4RDtZQUM5RCxJQUFJLFNBQVMsR0FBRyxNQUFNLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxFQUFFLEdBQUcsR0FBRyxHQUFHLEtBQUssQ0FBQyxLQUFLLElBQUksQ0FBQztZQUN0RSxLQUFLLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQztnQkFDZixDQUFDLEVBQUUsU0FBUztnQkFDWixDQUFDLEVBQUUsVUFBVSxDQUFDLElBQUk7Z0JBQ2xCLGVBQWUsRUFBRSxLQUFLLENBQUMsZUFBZTtnQkFDdEMsbUJBQW1CLEVBQUUsS0FBSyxDQUFDLG1CQUFtQjtnQkFDOUMsZUFBZSxFQUFFLFNBQVM7YUFDM0IsQ0FBQyxDQUFDO1FBQ0wsQ0FBQztRQUVELGVBQ0ksUUFBaUMsRUFBRSxNQUFtQixFQUN0RCxPQUF3QjtZQUMxQjs7O2VBR0c7WUFDSCxJQUFJLFdBQVcsR0FBaUMsRUFBRSxDQUFDO1lBQ25EOzs7ZUFHRztZQUNILElBQUksWUFBWSxHQUFpQyxFQUFFLENBQUM7WUFDcEQ7OztlQUdHO1lBQ0gsSUFBSSxhQUFhLEdBQW9DLEVBQUUsQ0FBQztZQUN4RCxJQUFJLGdCQUFnQixHQUFHLGlCQUFpQixDQUFDLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO1lBQ2xFLElBQUksaUJBQWlCLEdBQUcsaUJBQWlCLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLENBQUM7WUFDcEUsSUFBSSxrQkFBa0IsR0FBYSxFQUFFLENBQUM7WUFDdEMsSUFBSSxRQUFRLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQztZQUM3Qjs7Ozs7Ozs7ZUFRRztZQUNILElBQUksU0FBUyxHQUFHLElBQUksS0FBSyxDQUFTLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUVuRCxPQUFPLEVBQUUsQ0FBQyxLQUFLLENBQUMsSUFBSTtpQkFDZixZQUFZLENBQ1QsbUJBQW1CLEVBQUUsRUFBRSxFQUN2QjtnQkFDRSxJQUFJLE9BQU8sR0FBRyxJQUFJLEtBQUssQ0FBUyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUM7Z0JBQ2pELElBQUksS0FBSyxHQUFHLENBQUMsQ0FBQztnQkFFZCxJQUFNLGNBQWMsR0FBRyxVQUFBLE9BQU87b0JBQzVCLElBQUksTUFBTSxHQUFHLElBQUksVUFBVSxDQUFDLE9BQU8sQ0FBQyxDQUFDO29CQUNyQyxJQUFJLGdCQUFnQixDQUFDLE1BQU0sQ0FBQyxFQUFFO3dCQUM1QixrQkFBa0IsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDO3dCQUNyQyxXQUFXLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxHQUFHLE1BQU0sQ0FBQzt3QkFDbEMsT0FBTyxNQUFNLENBQUM7cUJBQ2Y7b0JBRUQsSUFBSSxpQkFBaUIsQ0FBQyxNQUFNLENBQUMsRUFBRTt3QkFDN0Isa0JBQWtCLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQzt3QkFDckMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsR0FBRyxNQUFNLENBQUM7d0JBQ25DLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxVQUFBLEtBQUs7NEJBQ3pCLElBQUksU0FBUyxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUM7NEJBQzNCLGFBQWEsQ0FBQyxTQUFTLENBQUMsR0FBRyxhQUFhLENBQUMsU0FBUyxDQUFDLElBQUksRUFBRSxDQUFDOzRCQUMxRCxhQUFhLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO3dCQUN4QyxDQUFDLENBQUMsQ0FBQzt3QkFDSCxPQUFPLE1BQU0sQ0FBQztxQkFDZjtvQkFDRCxpRUFBaUU7b0JBQ2pFLFNBQVM7b0JBQ1QsT0FBTyxDQUFDLEtBQUssQ0FBQyxHQUFHLE1BQU0sQ0FBQztvQkFDeEIsU0FBUyxDQUFDLEtBQUssQ0FBQyxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUM7b0JBQy9CLEtBQUssRUFBRSxDQUFDO29CQUNSLE9BQU8sTUFBTSxDQUFDO2dCQUNoQixDQUFDLENBQUM7Z0JBRUYsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsY0FBYyxDQUFDLENBQUM7Z0JBRWpDLElBQU0sZUFBZSxHQUFHLFVBQUMsSUFBZ0M7b0JBQ3ZELG1DQUFtQztvQkFDbkMsSUFBTSxnQkFBZ0IsR0FDbEIsUUFBQSw0QkFBNEIsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQztvQkFDdkQsMkRBQTJEO29CQUMzRCxvQkFBb0I7b0JBQ3BCLGNBQWMsQ0FBQzt3QkFDYixJQUFJLEVBQUUsZ0JBQWdCO3dCQUN0QixLQUFLLEVBQUUsRUFBRTt3QkFDVCxNQUFNLEVBQUUsRUFBRTt3QkFDVixFQUFFLEVBQUUsRUFBRTt3QkFDTixJQUFJLEVBQUUsRUFBRTtxQkFDVCxDQUFDLENBQUM7b0JBRUgsc0RBQXNEO29CQUN0RCxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsU0FBUyxFQUFFO3dCQUM1QiwwREFBMEQ7d0JBQzFELFlBQVk7d0JBQ1osSUFBSSxtQkFBaUIsR0FBRyxDQUFDLENBQUM7d0JBQzFCLElBQU0sWUFBWSxHQUFHLFVBQUMsR0FBRzs0QkFDdkIsSUFBTSxNQUFNLEdBQUcsY0FBYyxDQUFDO2dDQUM1QixJQUFJLEVBQUUsZ0JBQWdCLEdBQUcsUUFBQSxlQUFlLEdBQUcsR0FBRyxDQUFDLElBQUk7Z0NBQ25ELEtBQUssRUFBRSxFQUFFO2dDQUNULE1BQU0sRUFBRSxFQUFFO2dDQUNWLEVBQUUsRUFBRSxXQUFXO2dDQUNmLElBQUksRUFBRSxDQUFDO3dDQUNMLEdBQUcsRUFBRSxHQUFHO3dDQUNSLEtBQUssRUFBRTs0Q0FDTCxJQUFJLEVBQUUsR0FBRyxDQUFDLElBQUk7eUNBQ2Y7cUNBQ0YsQ0FBQzs2QkFDSCxDQUFDLENBQUM7NEJBQ0gsTUFBTSxDQUFDLGtCQUFrQixHQUFHLG1CQUFpQixDQUFDOzRCQUM5QyxtQkFBaUIsRUFBRSxDQUFDO3dCQUN0QixDQUFDLENBQUM7d0JBRUYsZ0VBQWdFO3dCQUNoRSxxREFBcUQ7d0JBQ3JELHlEQUF5RDt3QkFDekQsWUFBWTt3QkFDWixJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxFQUFFOzRCQUNwQyw2QkFBNkI7NEJBQzdCLFlBQVksQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQyxDQUFDO3lCQUN4Qzs2QkFBTTs0QkFDTCxnQ0FBZ0M7NEJBQ2hDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxTQUFTLEVBQUUsWUFBWSxDQUFDLENBQUM7eUJBQ2hEO3FCQUNGO29CQUVELGlFQUFpRTtvQkFDakUseURBQXlEO29CQUN6RCw2REFBNkQ7b0JBQzdELHFDQUFxQztvQkFDckMsSUFBSSxrQkFBa0IsR0FBRyxDQUFDLENBQUM7b0JBQzNCLElBQU0sY0FBYyxHQUFHLEVBQUUsQ0FBQztvQkFFMUIsdURBQXVEO29CQUN2RCxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsVUFBVSxFQUFFO3dCQUM3QixJQUFNLGFBQWEsR0FBRyxVQUFBLEdBQUc7NEJBQ3ZCLGNBQWMsQ0FDVixnQkFBZ0IsR0FBRyxRQUFBLGVBQWUsR0FBRyxHQUFHLENBQUMsSUFBSSxDQUFDO2dDQUMxQyxrQkFBa0IsQ0FBQzs0QkFDM0Isa0JBQWtCLEVBQUUsQ0FBQzt3QkFDdkIsQ0FBQyxDQUFDO3dCQUNGLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLEVBQUU7NEJBQ3JDLDhCQUE4Qjs0QkFDOUIsYUFBYSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUM7eUJBQzFDOzZCQUFNOzRCQUNMLGlDQUFpQzs0QkFDakMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFVBQVUsRUFBRSxhQUFhLENBQUMsQ0FBQzt5QkFDbEQ7cUJBQ0Y7b0JBRUQsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLFVBQUEsT0FBTzt3QkFDM0IseURBQXlEO3dCQUN6RCwwREFBMEQ7d0JBQzFELE9BQU8sQ0FBQyxJQUFJLEdBQUcsZ0JBQWdCLEdBQUcsR0FBRyxHQUFHLE9BQU8sQ0FBQyxJQUFJLENBQUM7d0JBQ3JELElBQUksT0FBTyxPQUFPLENBQUMsS0FBSyxLQUFLLFFBQVEsRUFBRTs0QkFDckMsT0FBTyxDQUFDLEtBQUssR0FBRyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQzt5QkFDakM7d0JBQ0QsSUFBTSxNQUFNLEdBQUcsY0FBYyxDQUFDLE9BQU8sQ0FBQyxDQUFDO3dCQUN2QyxJQUFJLENBQUMsQ0FBQyxRQUFRLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFFOzRCQUM1Qyx1REFBdUQ7NEJBQ3ZELE1BQU0sQ0FBQyxtQkFBbUIsR0FBRyxjQUFjLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO3lCQUMzRDt3QkFFRCxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsVUFBQSxlQUFlOzRCQUNuQyxlQUFlLENBQUMsSUFBSTtnQ0FDaEIsZ0JBQWdCLEdBQUcsUUFBQSxlQUFlLEdBQUcsZUFBZSxDQUFDLElBQUksQ0FBQzt3QkFDaEUsQ0FBQyxDQUFDLENBQUM7b0JBQ0wsQ0FBQyxDQUFDLENBQUM7Z0JBQ0wsQ0FBQyxDQUFDO2dCQUVGLElBQUksUUFBUSxDQUFDLE9BQU8sSUFBSSxRQUFRLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRTtvQkFDakQsaUNBQWlDO29CQUNqQyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsUUFBUSxFQUFFLGVBQWUsQ0FBQyxDQUFDO2lCQUNwRDtnQkFFRCxPQUFPLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUN0QixTQUFTLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUN4QixPQUFPLE9BQU8sQ0FBQztZQUNqQixDQUFDLEVBQ0QsT0FBTyxDQUFDO2lCQUNYLElBQUksQ0FBQyxVQUFDLE9BQU87Z0JBQ1osNkRBQTZEO2dCQUM3RCxPQUFPLEVBQUUsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FDN0IsNkJBQTZCLEVBQUUsRUFBRSxFQUFFO29CQUNqQyxJQUFJLGtCQUFrQixHQUNsQixrQkFBa0IsQ0FBQyxTQUFTLEVBQUUsa0JBQWtCLENBQUMsQ0FBQztvQkFDdEQsSUFBSSxLQUFLLEdBQUcsSUFBSSxTQUFTLENBQUM7b0JBRTFCLDhCQUE4QjtvQkFDOUIsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsVUFBQSxNQUFNO3dCQUNwQixJQUFJLGNBQWMsR0FDZCxrQkFBa0IsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQzt3QkFDbkQsS0FBSyxDQUFDLEtBQUssQ0FBQyxjQUFjLENBQUMsR0FBRyxNQUFNLENBQUM7d0JBQ3JDLGdFQUFnRTt3QkFDaEUsUUFBUTt3QkFDUixJQUFJLE1BQU0sQ0FBQyxJQUFJLElBQUksYUFBYSxFQUFFOzRCQUNoQyxNQUFNLENBQUMsYUFBYSxHQUFHLGFBQWEsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUM7NEJBQ2xELDZDQUE2Qzs0QkFDN0MsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsYUFBYSxFQUFFLFVBQUEsSUFBSTtnQ0FDL0IsSUFBSSxDQUFDLElBQUksR0FBRyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQzs0QkFDekQsQ0FBQyxDQUFDLENBQUM7eUJBQ0o7d0JBQ0QsK0JBQStCO3dCQUMvQixNQUFNLENBQUMsSUFBSSxHQUFHLGNBQWMsQ0FBQztvQkFDL0IsQ0FBQyxDQUFDLENBQUM7b0JBRUgsaUVBQWlFO29CQUNqRSxRQUFRO29CQUNSLDhEQUE4RDtvQkFDOUQsV0FBVztvQkFDWCxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxVQUFBLE1BQU07d0JBQ3BCLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxVQUFDLEtBQUssRUFBRSxDQUFDOzRCQUM3QixJQUFJLFNBQVMsR0FBRyxLQUFLLENBQUMsSUFBSSxDQUFDOzRCQUMzQixJQUFJLFNBQVMsSUFBSSxXQUFXLEVBQUU7Z0NBQzVCLElBQUksV0FBVyxHQUFHLFdBQVcsQ0FBQyxTQUFTLENBQUMsQ0FBQztnQ0FDekMsTUFBTSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7Z0NBQ3RDLHlEQUF5RDtnQ0FDekQsV0FBVztnQ0FDWCwyREFBMkQ7Z0NBQzNELE9BQU87Z0NBQ1AsdURBQXVEO2dDQUN2RCxZQUFZO2dDQUNaLEtBQXVCLFVBQWtCLEVBQWxCLEtBQUEsV0FBVyxDQUFDLE1BQU0sRUFBbEIsY0FBa0IsRUFBbEIsSUFBa0IsRUFBRTtvQ0FBdEMsSUFBSSxVQUFVLFNBQUE7b0NBQ2pCLGNBQWMsQ0FDVixLQUFLLEVBQUUsa0JBQWtCLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQzt3Q0FDdEMsVUFBVSxDQUFDLElBQUksRUFDbkIsTUFBTSxFQUFFLFVBQVUsRUFBRSxNQUFNLEVBQUUsQ0FBQyxDQUFDLENBQUM7aUNBQ3BDOzZCQUNGO2lDQUFNLElBQUksU0FBUyxJQUFJLFlBQVksRUFBRTtnQ0FDcEMsMkRBQTJEO2dDQUMzRCxtREFBbUQ7Z0NBQ25ELElBQUksWUFBWSxHQUFHLFlBQVksQ0FBQyxTQUFTLENBQUMsQ0FBQztnQ0FDM0MsS0FBdUIsVUFBbUIsRUFBbkIsS0FBQSxZQUFZLENBQUMsTUFBTSxFQUFuQixjQUFtQixFQUFuQixJQUFtQixFQUFFO29DQUF2QyxJQUFJLFVBQVUsU0FBQTtvQ0FDakIsY0FBYyxDQUNWLEtBQUssRUFBRSxrQkFBa0IsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDO3dDQUN0QyxVQUFVLENBQUMsSUFBSSxFQUNuQixNQUFNLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBRSxDQUFDLENBQUMsQ0FBQztpQ0FDL0I7NkJBQ0Y7aUNBQU07Z0NBQ0wsY0FBYyxDQUNWLEtBQUssRUFBRSxrQkFBa0IsQ0FBQyxTQUFTLENBQUMsSUFBSSxTQUFTLEVBQ2pELE1BQU0sRUFBRSxLQUFLLEVBQUUsTUFBTSxFQUFFLENBQUMsQ0FBQyxDQUFDOzZCQUMvQjt3QkFDSCxDQUFDLENBQUMsQ0FBQztvQkFDTCxDQUFDLENBQUMsQ0FBQztvQkFFSCx3Q0FBd0M7b0JBQ3hDLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFLFVBQUMsSUFBSSxFQUFFLElBQUk7d0JBQzdCLElBQUksQ0FBQyxJQUFJLEdBQUcsa0JBQWtCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUM7b0JBQ3pELENBQUMsQ0FBQyxDQUFDO29CQUVILE9BQU8sS0FBSyxDQUFDO2dCQUNmLENBQUMsRUFBRSxPQUFPLENBQUMsQ0FBQztZQUNsQixDQUFDLENBQUMsQ0FBQztRQUNULENBQUM7UUFyUGUsYUFBSyxRQXFQcEIsQ0FBQTtRQUFBLENBQUM7UUFFRjs7V0FFRztRQUNILHFCQUNJLElBQVksRUFBRSxJQUFJLEVBQ2xCLEdBQTJCO1lBQzdCLElBQU0sWUFBWSxHQUFHLEdBQUcsSUFBSSxFQUFFLENBQUM7WUFDL0IsSUFBSSxLQUFLLEdBQUcsSUFBSSxRQUFRLENBQUMsS0FBSyxDQUFPLFlBQVksQ0FBQyxDQUFDO1lBQ25ELEtBQUssQ0FBQyxRQUFRLENBQUM7Z0JBQ2IsSUFBSSxFQUFFLElBQUk7Z0JBQ1YsT0FBTyxFQUFFLFlBQVksQ0FBQyxPQUFPLElBQUksSUFBSTtnQkFDckMsSUFBSSxFQUFFLElBQUk7YUFDWCxDQUFDLENBQUM7WUFDSCxPQUFPLEtBQUssQ0FBQztRQUNmLENBQUM7UUFYZSxtQkFBVyxjQVcxQixDQUFBO1FBQUEsQ0FBQztRQUVGOzs7V0FHRztRQUNILDJCQUEyQixLQUFlO1lBQ3hDLE9BQU8sVUFBUyxJQUFZO2dCQUMxQixjQUFjO2dCQUNkLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxLQUFLLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO29CQUNyQyxJQUFJLE1BQU0sR0FBRyxJQUFJLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDbEMsSUFBSSxJQUFJLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsRUFBRTt3QkFBRSxPQUFPLElBQUksQ0FBQztxQkFBRTtpQkFDNUM7Z0JBQ0QsT0FBTyxLQUFLLENBQUM7WUFDZixDQUFDLENBQUM7UUFDSixDQUFDO1FBQUEsQ0FBQztRQUVGOzs7V0FHRztRQUNILHVCQUE4QixJQUFZO1lBQ3hDLElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBQSxlQUFlLENBQUMsQ0FBQztZQUN4QyxPQUFPLElBQUksR0FBRyxRQUFBLGVBQWUsR0FBRyxHQUFHLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDO1FBQ3RFLENBQUM7UUFIZSxxQkFBYSxnQkFHNUIsQ0FBQTtRQUVEOzs7Ozs7Ozs7Ozs7V0FZRztRQUNILDRCQUE0QixTQUFtQixFQUMzQyxrQkFBNEI7WUFDOUIsdURBQXVEO1lBQ3ZELElBQUksaUJBQWlCLEdBQWdDLEVBQUUsQ0FBQztZQUN4RCx3Q0FBd0M7WUFDeEMsSUFBSSxZQUFZLEdBQW1DLEVBQUUsQ0FBQztZQUN0RCw2Q0FBNkM7WUFDN0MsU0FBUyxDQUFDLElBQUksRUFBRSxDQUFDO1lBQ2pCLGtEQUFrRDtZQUNsRCxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsU0FBUyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsRUFBRSxDQUFDLEVBQUU7Z0JBQzdDLElBQUksQ0FBQyxHQUFHLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDckIsb0RBQW9EO2dCQUNwRCxxQ0FBcUM7Z0JBQ3JDLENBQUMsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLFVBQUEsRUFBRTtvQkFDNUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQztnQkFDMUIsQ0FBQyxDQUFDLENBQUM7Z0JBQ0gsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxTQUFTLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxFQUFFO29CQUM3QyxJQUFJLENBQUMsR0FBRyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQ3JCLElBQUksQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUU7d0JBQ3RCLElBQUksQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLFFBQUEsZUFBZSxFQUFFOzRCQUNqRSxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsR0FBRyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUM7NEJBQ3hDLE1BQU07eUJBQ1A7cUJBQ0Y7eUJBQU07d0JBQ0wsTUFBTTtxQkFDUDtpQkFDRjthQUNGO1lBQ0QsdUVBQXVFO1lBQ3ZFLDJCQUEyQjtZQUMzQixDQUFDLENBQUMsSUFBSSxDQUFDLGtCQUFrQixFQUFFLFVBQUEsYUFBYTtnQkFDdEMsSUFBSSxhQUFhLElBQUksWUFBWSxFQUFFO29CQUNqQyxxQ0FBcUM7b0JBQ3JDLGlCQUFpQixDQUFDLGFBQWEsQ0FBQyxHQUFHLGFBQWEsQ0FBQyxhQUFhLENBQUMsQ0FBQztpQkFDakU7WUFDSCxDQUFDLENBQUMsQ0FBQztZQUNILE9BQU8saUJBQWlCLENBQUM7UUFDM0IsQ0FBQztRQUFBLENBQUM7UUFFRjs7V0FFRztRQUNILHdCQUF3QixLQUErQjtZQUNyRCxJQUFJLE9BQU8sR0FBRyxLQUFLLENBQUMsS0FBSyxFQUFFLENBQUMsR0FBRyxDQUFDLFVBQVMsSUFBSTtnQkFDM0MsT0FBTyxLQUFLLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQztZQUN0QyxDQUFDLENBQUMsQ0FBQztZQUNILE9BQU8sQ0FBQyxJQUFJLEVBQUUsQ0FBQztZQUNmLE9BQU8sT0FBTyxDQUFDO1FBQ2pCLENBQUM7UUFBQSxDQUFDO1FBRUY7O1dBRUc7UUFDSCxrQ0FBeUMsTUFBZ0MsRUFDckUsTUFBZ0M7WUFDbEMsSUFBSSxHQUFHLEdBQUcsY0FBYyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQ2pDLElBQUksR0FBRyxHQUFHLGNBQWMsQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUVqQyxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsR0FBRyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtnQkFDbkMsSUFBSSxHQUFHLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFO29CQUNyQixPQUFPLEtBQUssQ0FBQztpQkFDZDthQUNGO1lBQ0QsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO1FBWGUsZ0NBQXdCLDJCQVd2QyxDQUFBO1FBQUEsQ0FBQztRQUVGOzs7O1dBSUc7UUFDSCw2QkFBb0MsSUFBWSxFQUM5QyxXQUF3QztZQUN4QyxJQUFJLElBQUksR0FBYSxFQUFFLENBQUM7WUFDeEIsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFBLGVBQWUsQ0FBQyxDQUFDO1lBQ3RDLHdDQUF3QztZQUN4QyxPQUFPLENBQUMsSUFBSSxDQUFDLEVBQUU7Z0JBQ2IsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNoQyxDQUFDLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFBLGVBQWUsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7YUFDMUM7WUFDRCw2RUFBNkU7WUFDN0UsK0NBQStDO1lBQy9DLElBQUksV0FBVyxFQUFFO2dCQUNmLElBQUksVUFBVSxHQUFHLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDbkMsSUFBSSxVQUFVLEVBQUU7b0JBQ2QsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztpQkFDdkI7YUFDRjtZQUNELDZCQUE2QjtZQUM3QixJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQ2hCLE9BQU8sSUFBSSxDQUFDO1FBQ2QsQ0FBQztRQXBCZSwyQkFBbUIsc0JBb0JsQyxDQUFBO1FBQUEsQ0FBQztRQUVGOzs7V0FHRztRQUNILG9DQUEyQyxPQUFzQjtZQUMvRCxJQUFJLE9BQU8sS0FBSyxFQUFFLENBQUMsS0FBSyxDQUFDLGFBQWEsQ0FBQyxPQUFPLEVBQUU7Z0JBQzlDLE9BQU8sbUJBQW1CLENBQUM7YUFDNUI7aUJBQU07Z0JBQ0wsT0FBTyx3QkFBd0IsQ0FBQzthQUNqQztRQUNILENBQUM7UUFOZSxrQ0FBMEIsNkJBTXpDLENBQUE7UUFBQSxDQUFDO1FBRUY7OztXQUdHO1FBQ0gsd0NBQStDLEtBQXlCO1lBQ3RFLElBQUksS0FBSyxLQUFLLEVBQUUsQ0FBQyxLQUFLLENBQUMsa0JBQWtCLENBQUMsS0FBSyxFQUFFO2dCQUMvQyxPQUFPLDhCQUE4QixDQUFDO2FBQ3ZDO2lCQUFNO2dCQUNMLE9BQU8sNEJBQTRCLENBQUM7YUFDckM7UUFDSCxDQUFDO1FBTmUsc0NBQThCLGlDQU03QyxDQUFBO1FBQUEsQ0FBQztRQUVGOzs7V0FHRztRQUNILCtCQUNFLEdBQW9ELEVBQUUsSUFBWTtZQUNsRSxJQUFJLENBQUMsQ0FBQyxJQUFJLElBQUksR0FBRyxDQUFDLElBQUksR0FBRyxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQyxLQUFLLENBQUMsa0JBQWtCLENBQUMsS0FBSyxFQUFFO2dCQUNyRSxHQUFHLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLEtBQUssQ0FBQyxrQkFBa0IsQ0FBQyxPQUFPLENBQUM7YUFDakQ7aUJBQU07Z0JBQ0wsR0FBRyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxLQUFLLENBQUMsa0JBQWtCLENBQUMsS0FBSyxDQUFDO2FBQy9DO1FBQ0gsQ0FBQztRQVBlLDZCQUFxQix3QkFPcEMsQ0FBQTtRQUFBLENBQUM7SUFFRixDQUFDLEVBMTVDUyxLQUFLLEdBQUwsUUFBSyxLQUFMLFFBQUssUUEwNUNkO0FBQUQsQ0FBQyxFQTE1Q00sRUFBRSxLQUFGLEVBQUUsUUEwNUNSLENBQUMsd0JBQXdCIiwic291cmNlc0NvbnRlbnQiOlsiLyogQ29weXJpZ2h0IDIwMTUgVGhlIFRlbnNvckZsb3cgQXV0aG9ycy4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cblxuTGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlLCBWZXJzaW9uIDIuMCAodGhlICdMaWNlbnNlJyk7XG55b3UgbWF5IG5vdCB1c2UgdGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlIHdpdGggdGhlIExpY2Vuc2UuXG5Zb3UgbWF5IG9idGFpbiBhIGNvcHkgb2YgdGhlIExpY2Vuc2UgYXRcblxuICAgIGh0dHA6Ly93d3cuYXBhY2hlLm9yZy9saWNlbnNlcy9MSUNFTlNFLTIuMFxuXG5Vbmxlc3MgcmVxdWlyZWQgYnkgYXBwbGljYWJsZSBsYXcgb3IgYWdyZWVkIHRvIGluIHdyaXRpbmcsIHNvZnR3YXJlXG5kaXN0cmlidXRlZCB1bmRlciB0aGUgTGljZW5zZSBpcyBkaXN0cmlidXRlZCBvbiBhbiAnQVMgSVMnIEJBU0lTLFxuV0lUSE9VVCBXQVJSQU5USUVTIE9SIENPTkRJVElPTlMgT0YgQU5ZIEtJTkQsIGVpdGhlciBleHByZXNzIG9yIGltcGxpZWQuXG5TZWUgdGhlIExpY2Vuc2UgZm9yIHRoZSBzcGVjaWZpYyBsYW5ndWFnZSBnb3Zlcm5pbmcgcGVybWlzc2lvbnMgYW5kXG5saW1pdGF0aW9ucyB1bmRlciB0aGUgTGljZW5zZS5cbj09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSovXG5tb2R1bGUgdGYuZ3JhcGgge1xuXG4vKiogRGVsaW1pdGVyIHVzZWQgaW4gbm9kZSBuYW1lcyB0byBkZW5vdGUgbmFtZXNwYWNlcy4gKi9cbmV4cG9ydCBjb25zdCBOQU1FU1BBQ0VfREVMSU0gPSAnLyc7XG5leHBvcnQgY29uc3QgUk9PVF9OQU1FID0gJ19fcm9vdF9fJztcbmV4cG9ydCBjb25zdCBGVU5DVElPTl9MSUJSQVJZX05PREVfUFJFRklYID0gJ19fZnVuY3Rpb25fbGlicmFyeV9fJztcblxuLyoqIEF0dHJpYnV0ZSBrZXkgdXNlZCBmb3Igc3RvcmluZyBhdHRyaWJ1dGVzIHRoYXQgYXJlIHRvbyBsYXJnZS4gKi9cbmV4cG9ydCBjb25zdCBMQVJHRV9BVFRSU19LRVkgPSAnX3Rvb19sYXJnZV9hdHRycyc7XG4vKipcbiAqIE1heGltdW0gYWxsb3dlZCBzaXplIGluIGJ5dGVzLCBiZWZvcmUgdGhlIGF0dHJpYnV0ZSBpcyBjb25zaWRlcmVkIGxhcmdlXG4gKiBhbmQgZmlsdGVyZWQgb3V0IG9mIHRoZSBncmFwaC5cbiAqL1xuZXhwb3J0IGNvbnN0IExJTUlUX0FUVFJfU0laRSA9IDEwMjQ7XG5cbi8vIFNlcGFyYXRvciBiZXR3ZWVuIHRoZSBzb3VyY2UgYW5kIHRoZSBkZXN0aW5hdGlvbiBuYW1lIG9mIHRoZSBlZGdlLlxuZXhwb3J0IGNvbnN0IEVER0VfS0VZX0RFTElNID0gJy0tJztcblxuZXhwb3J0IGVudW0gR3JhcGhUeXBlIHtGVUxMLCBFTUJFRERFRCwgTUVUQSwgU0VSSUVTLCBDT1JFLCBTSEFET1csIEJSSURHRSxcbiAgICBFREdFfTtcbmV4cG9ydCBlbnVtIE5vZGVUeXBlIHtNRVRBLCBPUCwgU0VSSUVTLCBCUklER0UsIEVMTElQU0lTfTtcblxuLyoqIEluZGljYXRlcyBpZiBhIG5vZGUgaXMgdG8gYmUgaW5jbHVkZWQgaW4gdGhlIG1haW4gZ3JhcGggd2hlbiByZW5kZXJlZC4gKi9cbmV4cG9ydCBlbnVtIEluY2x1c2lvblR5cGUge0lOQ0xVREUsIEVYQ0xVREUsIFVOU1BFQ0lGSUVEfTtcblxuLyoqIEluZGljYXRlcyBpZiBhIHNlcmllcyBpcyB0byBiZSBncm91cGVkIGluIHRoZSBncmFwaCB3aGVuIHJlbmRlcmVkLiAqL1xuZXhwb3J0IGVudW0gU2VyaWVzR3JvdXBpbmdUeXBlIHtHUk9VUCwgVU5HUk9VUH07XG5cbi8qKiBBdHRyaWJ1dGUga2V5IHJlc2VydmVkIGZvciB0aGUgc2hhcGVzIG9mIHRoZSBvdXRwdXQgdGVuc29ycy4gKi9cbmNvbnN0IE9VVFBVVF9TSEFQRVNfS0VZID0gJ19vdXRwdXRfc2hhcGVzJztcblxuLyoqIEF0dHJpYnV0ZSBrZXkgcmVzZXJ2ZWQgZm9yIHRoZSBYTEEgY2x1c3RlciB0aGF0IGFuIG9wIHJ1bnMgb24uICovXG5jb25zdCBfWExBX0NMVVNURVJfS0VZID0gJ19YbGFDbHVzdGVyJztcblxuLyoqXG4gKiBBIEJhc2VFZGdlIGlzIHRoZSBsYWJlbCBvYmplY3QgKGluIHRoZSBncmFwaGxpYiBzZW5zZSkgZm9yIGFuIGVkZ2UgaW4gdGhlXG4gKiBvcmlnaW5hbCwgZnVsbCBncmFwaCBwcm9kdWNlZCBhZnRlciBwYXJzaW5nLiBTdWJzZXF1ZW50IGdyYXBocywgbGlrZSB0aG9zZVxuICogd2hpY2ggYmVsb25nIHRvIE1ldGFub2Rlcywgc2hvdWxkIG5vdCB1c2UgQmFzZUVkZ2Ugb2JqZWN0cywgYnV0IGluc3RlYWRcbiAqIGNvbnRhaW4gTWV0YWVkZ2VzICh3aGljaCBpbiB0dXJuIG1heSBjb250YWluIGFueSBudW1iZXIgb2YgQmFzZUVkZ2VzKS5cbiAqL1xuZXhwb3J0IGludGVyZmFjZSBCYXNlRWRnZSBleHRlbmRzIGdyYXBobGliLkVkZ2VPYmplY3Qge1xuICBpc0NvbnRyb2xEZXBlbmRlbmN5OiBib29sZWFuO1xuICBpc1JlZmVyZW5jZUVkZ2U6IGJvb2xlYW47XG4gIC8qKiBUaGUgaW5kZXggb2YgdGhlIG91dHB1dCB0ZW5zb3Igb2YgdGhlIHNvdXJjZSBub2RlLiAqL1xuICBvdXRwdXRUZW5zb3JLZXk6IHN0cmluZztcbn1cblxuLyoqXG4gKiBBIFNsaW1HcmFwaCBpcyBpbnNwaXJlZCBieSBncmFwaGxpYi5HcmFwaCwgYnV0IGhhdmluZyBvbmx5IHRoZSBmdW5jdGlvbmFsaXR5XG4gKiB0aGF0IHdlIG5lZWQuXG4gKi9cbmV4cG9ydCBjbGFzcyBTbGltR3JhcGgge1xuICBub2RlczogeyBbbm9kZU5hbWU6IHN0cmluZ106IE9wTm9kZSB9O1xuICBlZGdlczogQmFzZUVkZ2VbXTtcblxuICBjb25zdHJ1Y3RvcigpIHtcbiAgICB0aGlzLm5vZGVzID0ge307XG4gICAgdGhpcy5lZGdlcyA9IFtdO1xuICB9XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgTm9ybWFsaXplZElucHV0IHtcbiAgbmFtZTogc3RyaW5nO1xuICAvKiogVGhlIGluZGV4IG9mIHRoZSBvdXRwdXQgdGVuc29yIG9mIHRoZSBzb3VyY2Ugbm9kZS4gKi9cbiAgb3V0cHV0VGVuc29yS2V5OiBzdHJpbmc7XG4gIGlzQ29udHJvbERlcGVuZGVuY3k6IGJvb2xlYW47XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgQnVpbGRQYXJhbXMge1xuICBlbmFibGVFbWJlZGRpbmc6IGJvb2xlYW47XG4gIGluRW1iZWRkaW5nVHlwZXM6IHN0cmluZ1tdO1xuICBvdXRFbWJlZGRpbmdUeXBlczogc3RyaW5nW107XG4gIHJlZkVkZ2VzOiB7IFtpbnB1dEVkZ2U6IHN0cmluZ106IGJvb2xlYW4gfTtcbn1cblxuLyoqXG4gKiBUaGUgbW9zdCBiYXNpYyBpbmZvcm1hdGlvbiBhYm91dCBhIG5vZGUgaW4gdGhlIGhpZXJhcmNoaWNhbCBncmFwaC5cbiAqL1xuZXhwb3J0IGludGVyZmFjZSBOb2RlIHtcbiAgLyoqIFRoZSBuYW1lIG9mIHRoZSBub2RlLCB1c2VkIGZyZXF1ZW50bHkgdG8gbG9vayB1cCBub2RlcyBieSBuYW1lLiAqL1xuICBuYW1lOiBzdHJpbmc7XG4gIC8qKiBXaGljaCB0eXBlIG9mIG5vZGUgdGhpcyBpcy4gKi9cbiAgdHlwZTogTm9kZVR5cGU7XG4gIC8qKlxuICAgKiBXaGV0aGVyIHRoaXMgbm9kZSBpcyBhIHR5cGUgdGhhdCBtYXkgY29udGFpbiBvdGhlciBub2Rlcy4gVGhvc2UgdHlwZXNcbiAgICogc2hvdWxkIGV4dGVuZCBmcm9tIEdyb3VwTm9kZS5cbiAgICpcbiAgICogRm9yIGFuIE9wTm9kZSwgaXNHcm91cE5vZGUgd2lsbCBiZSBmYWxzZSwgZXZlbiB0aG91Z2ggaXQgbWF5IGhhdmVcbiAgICogZW1iZWRkaW5ncy4gVGhlc2UgZW1iZWRkaW5nIE5vZGVzIHdpbGwgaGF2ZSB0aGVpciBwYXJlbnROb2RlIHNldCB0byB0aGVcbiAgICogT3BOb2RlLiBIb3dldmVyLCBlbWJlZGRpbmdzIGFyZSBsYXRlciByZW5kZXJlZCBhcyBhbm5vdGF0aW9ucywgbm90IGFzXG4gICAqIGNoaWxkcmVuIHRvIGJlIG1hZGUgdmlzaWJsZSBvbiBleHBhbnNpb24gKGxpa2UgYSBNZXRhbm9kZSBvciBTZXJpZXNOb2RlKS5cbiAgICovXG4gIGlzR3JvdXBOb2RlOiBib29sZWFuO1xuICAvKipcbiAgICogVGhlIG51bWJlciBvZiBub2RlcyB0aGlzIG5vZGUgcmVwcmVzZW50cy4gRm9yIE9wTm9kZXMsIHRoaXMgd2lsbCBiZSAxLCBhbmRcbiAgICogZm9yIEdyb3VwTm9kZXMgaXQgd2lsbCBiZSBhIGNvdW50IG9mIHRoZSB0b3RhbCBudW1iZXIgb2YgZGVzY2VuZGVudHMgaXRcbiAgICogY29udGFpbnMuXG4gICAqL1xuICBjYXJkaW5hbGl0eTogbnVtYmVyO1xuICAvKipcbiAgICogVGhlIE5vZGUgd2hpY2ggaXMgdGhpcyBOb2RlJ3MgcGFyZW50LiBUaGlzIGlzIG9mIHR5cGUgTm9kZSBhbmQgbm90XG4gICAqIEdyb3VwTm9kZSBiZWNhdXNlIG9mIGVtYmVkZGluZ3MsIHdoaWNoIHdpbGwgaGF2ZSBhIHBhcmVudCBPcE5vZGUuXG4gICAqL1xuICBwYXJlbnROb2RlOiBOb2RlO1xuICAvKiogUnVudGltZSBleGVjdXRpb24gc3RhdHMgZm9yIHRoaXMgbm9kZSwgaWYgYXZhaWxhYmxlICovXG4gIHN0YXRzOiBOb2RlU3RhdHM7XG4gIC8qKiBJZiB0aGUgbm9kZSBpcyB0byBiZSBpbmNsdWRlZCBvciBleGNsdWRlZCBmcm9tIHRoZSBtYWluIGdyYXBoIHdoZW5cbiAgICogIHJlbmRlcmVkLiBEZWZhdWx0cyB0byBVTlNQRUNJRklFRCwgd2hpY2ggbWVhbnMgdGhhdCB0aGUgcmVuZGVyaW5nXG4gICAqICBhbGdvcml0aG0gZGV0ZXJtaW5lcyBpZiBpdCB3aWxsIGJlIGluY2x1ZGVkIG9yIG5vdC4gVGhlbiBjYW4gYmUgc2V0IHRvXG4gICAqICBJTkNMVURFIG9yIEVYQ0xVREUgbWFudWFsbHkgYnkgdGhlIHVzZXIuXG4gICAqL1xuICBpbmNsdWRlOiBJbmNsdXNpb25UeXBlO1xuICAvKipcbiAgICogTm9kZSBhdHRyaWJ1dGVzIHNwZWNpZnkgY3VzdG9taXphYmxlIHZpc3VhbCBhc3BlY3RzIG9mIGEgbm9kZSBhbmRcbiAgICogYXBwbGljYXRpb24tc3BlY2lmaWMgbWV0YWRhdGEgYXNzb2NpYXRlZCB3aXRoIGEgbm9kZS4gVGhlIG5hbWVcbiAgICogJ25vZGVBdHRyaWJ1dGVzJyBpcyBtZWFudCB0byBhdm9pZCBuYW1pbmctY29uZmxpY3RzIHdpdGggdGhlICdhdHRyJyBpblxuICAgKiBzdWJjbGFzc2VzIG9mIE5vZGUuXG4gICAqL1xuICBub2RlQXR0cmlidXRlczoge1trZXk6IHN0cmluZ106IGFueTt9O1xufVxuXG5leHBvcnQgdHlwZSBUZW5zb3JTaGFwZSA9IG51bWJlcltdO1xuXG5leHBvcnQgaW50ZXJmYWNlIE9wTm9kZSBleHRlbmRzIE5vZGUge1xuICBvcDogc3RyaW5nO1xuICAvLyBUaGUgZGV2aWNlIG9uIHdoaWNoIHRoZSBvcCByYW4uIE51bGwgaWYgaXQgaXMgdW5rbm93bi5cbiAgZGV2aWNlOiBzdHJpbmc7XG4gIGF0dHI6IHtrZXk6IHN0cmluZywgdmFsdWU6IGFueX1bXTtcbiAgaW5wdXRzOiBOb3JtYWxpemVkSW5wdXRbXTtcbiAgaW5FbWJlZGRpbmdzOiBPcE5vZGVbXTtcbiAgb3V0RW1iZWRkaW5nczogT3BOb2RlW107XG4gIC8vIFRoZSBuYW1lIG9mIHRoZSBTZXJpZXNOb2RlIHRoYXQgY2FuIGNvbnRhaW4gdGhpcyBub2RlIGluIGl0cyBzZXJpZXMuXG4gIC8vIElmIHRoZXJlIGlzIG5vIHN1Y2ggbm9kZSwgdGhlbiB0aGlzIGlzIG51bGwuXG4gIG93bmluZ1Nlcmllczogc3RyaW5nO1xuICAvKipcbiAgICogT2JqZWN0IG1hcHBpbmcgb3V0cHV0IGNoYW5uZWwgc3RyaW5nIHRvIHRlbnNvciBzaGFwZXMuIFRoZSBvdXRwdXQgY2hhbm5lbFxuICAgKiBpcyBhIHN0cmluZyByYXRoZXIgdGhhbiBhIG51bWJlciBiZWNhdXNlIHdpdGhpbiBUZW5zb3JGbG93IGZ1bmN0aW9ucywgYW5cbiAgICogb3V0cHV0IG1heSBiZSBhIGNyb3NzIGJldHdlZW4gYW4gb3V0cHV0IHZhcmlhYmxlIGFuZCBhIG51bWJlciAoY29tYmluZWRcbiAgICogd2l0aCBhIGNvbG9uKSBzdWNoIGFzIFwiZm9vOjJcIiByYXRoZXIgdGhhbiBqdXN0IGEgbnVtYmVyIGFsb25lLlxuICAgKlxuICAgKiBFYWNoIHRlbnNvciBzaGFwZSBpcyBhbiBhcnJheSBvZiBudW1iZXJzLCBvciBudWxsLiBEZXRhaWxzOlxuICAgKiAtIG51bGwgbWVhbnMgdW5rbm93biByYW5rLCBhbmQgdGhlcmVmb3JlIGVudGlyZSBzaGFwZSBpcyB1bmtub3duLlxuICAgKiAtIFs0LCAyLCAxXSBtZWFucyByYW5rLTMgdGVuc29yIG9mIHNpemUgNHgyeDEuXG4gICAqIC0gW10gbWVhbnMgYSBzY2FsYXIgKHJhbmstMCB0ZW5zb3IpLlxuICAgKiAtIFsxXSBtZWFucyByYW5rLTEgdGVuc29yIG9mIHNpemUgMSAobm90IHRoZSBzYW1lIGFzIHNjYWxhcikuXG4gICAqIC0gWzUsIC0xLCAzXSBtZWFucyByYW5rLTMgdGVuc29yIG9mIHNoYXBlIGlzIDV4P3gzLiBUaGUgc2l6ZVxuICAgKiAgICAgICBvZiB0aGUgbWlkZGxlIGRpbWVuc2lvbiBpcyB1bmtub3duIChlbmNvZGVkIGFzIC0xKS5cbiAgICovXG4gIG91dHB1dFNoYXBlczoge1trZXk6IHN0cmluZ106IFRlbnNvclNoYXBlO307XG5cbiAgLy8gVGhlIFhMQSBDbHVzdGVyIG9uIHdoaWNoIHRoZSBvcCByYW4uIE51bGwgaWYgaXQgaXMgdW5rbm93bi5cbiAgeGxhQ2x1c3Rlcjogc3RyaW5nO1xuXG4gIC8vIFdoZXRoZXIgb3AgaXMgY29tcGF0aWJsZSB3aXRoIGl0cyBhc3NpZ25lZCBkZXZpY2UuICBDdXJyZW50bHksIGlmIGFuIG9wXG4gIC8vIGlzIG5vdCBzcGVjaWZpZWQgYSBkZXZpY2UsIHRoZSBkZXZpY2UgaXMgZGVmYXVsdGVkIHRvIHRoZSBUUFUuXG4gIC8vIEZ1cnRoZXJtb3JlLCBhbGwgb3BzIGFyZSBjb25zaWRlcmVkIGNvbXBhdGlibGUgZm9yIENQVSBhbmQgR1BVIGRldmljZXMsXG4gIC8vIHdoaWxlIGEgd2hpdGVsaXN0IG9mIGNvbXBhdGlibGUgb3BzIGFyZSBzcGVjaWZpZWQgZm9yIHRoZSBUUFUuXG4gIC8vIFJlZmVyZW5jZTogb3BWYWxpZCBmdW5jIGluIG9wLnRzLlxuICBjb21wYXRpYmxlOiBib29sZWFuO1xuXG4gIC8vIFRoaXMgZmllbGQgaXMgb25seSBkZWZpbmVkIGlmIHRoZSBvcCBub2RlIHJlcHJlc2VudHMgYW4gaW5wdXRfYXJnIHRvIGFcbiAgLy8gbGlicmFyeSBmdW5jdGlvbi4gSXQgaXMgdGhlIGluZGV4IG9mIHRoZSBpbnB1dF9hcmcuXG4gIGZ1bmN0aW9uSW5wdXRJbmRleDogbnVtYmVyO1xuXG4gIC8vIFRoaXMgZmllbGQgaXMgb25seSBkZWZpbmVkIGlmIHRoZSBvcCBub2RlIHJlcHJlc2VudHMgYW4gb3V0cHV0X2FyZyBvZiBhXG4gIC8vIGxpYnJhcnkgZnVuY3Rpb24uIEl0IGlzIHRoZSBpbmRleCBvZiB0aGUgb3V0cHV0X2FyZy5cbiAgZnVuY3Rpb25PdXRwdXRJbmRleDogbnVtYmVyO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIEJyaWRnZU5vZGUgZXh0ZW5kcyBOb2RlIHtcbiAgLyoqXG4gICAqIFdoZXRoZXIgdGhpcyBicmlkZ2Ugbm9kZSByZXByZXNlbnRzIGVkZ2VzIGNvbWluZyBpbnRvIGl0cyBwYXJlbnQgbm9kZS5cbiAgICovXG4gIGluYm91bmQ6IGJvb2xlYW47XG59XG5cbi8qKlxuICogQSBub2RlIHRoYXQgaXMgdXNlZCB3aGVuIHRoZXJlIGFyZSBtb3JlIHRoYW4gdGhlIG1heGltdW0gbnVtYmVyIG9mIGFsbG93ZWRcbiAqIGFubm90YXRpb25zIGhhbmdpbmcgb2ZmIG9mIGEgbm9kZS4gIFRoaXMgbm9kZSByZXByZXNlbnRzIGFuIGVsbGlwc2lzXG4gKiBhbm5vdGF0aW9uLCBpbmRpY2F0aW5nIGEgbnVtYmVyIG9mIGFkZGl0aW9uYWwgYW5ub3RhdGlvbnMuXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgRWxsaXBzaXNOb2RlIGV4dGVuZHMgTm9kZSB7XG4gIC8qKlxuICAgKiBUaGUgbnVtYmVyIG9mIG5vZGVzIHRoaXMgZWxsaXBzaXMgcmVwcmVzZW50cy5cbiAgICovXG4gIG51bU1vcmVOb2RlczogbnVtYmVyO1xuXG4gIC8qKlxuICAgKiBTZXRzIHRoZSBudW1iZXIgb2Ygbm9kZXMgdGhpcyBlbGxpcHNpcyByZXByZXNlbnRzIGFuZCBjaGFuZ2VzIHRoZSBub2RlXG4gICAqIG5hbWUgYWNjb3JkaW5nbHkuXG4gICAqL1xuICBzZXROdW1Nb3JlTm9kZXMobnVtTm9kZXM6IG51bWJlcik7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgR3JvdXBOb2RlIGV4dGVuZHMgTm9kZSB7XG4gIC8qKlxuICAgKiBUaGUgbWV0YWdyYXBoIGNvbnRhaW5zIG5vZGVzIGFuZCBtZXRhZWRnZXMgYmV0d2VlbiB0aGUgaW1tZWRpYXRlIGNoaWxkcmVuXG4gICAqIG9mIHRoaXMgZ3JvdXAuIFRoZSBub2RlIGxhYmVsIG9iamVjdHMgbWF5IGJlIG90aGVyIEdyb3VwTm9kZXMgKGxpa2VcbiAgICogU2VyaWVzTm9kZXMgYW5kIE1ldGFub2Rlcykgb3IgaW5kaXZpZHVhbCBPcE5vZGVzLiBBbGwgZWRnZSBsYWJlbCBvYmplY3RzXG4gICAqIGFyZSBNZXRhZWRnZXMsIGVhY2ggb2Ygd2hpY2ggY29udGFpbnMgcmVmZXJlbmNlcyB0byB0aGUgb3JpZ2luYWxcbiAgICogQmFzZUVkZ2UocykgZnJvbSB3aGljaCBpdCB3YXMgY3JlYXRlZC5cbiAgICovXG4gIG1ldGFncmFwaDogZ3JhcGhsaWIuR3JhcGg8R3JvdXBOb2RlfE9wTm9kZSwgTWV0YWVkZ2U+O1xuXG4gIC8qKlxuICAgKiBUaGUgYnJpZGdlZ3JhcGggY29udGFpbnMgb25seSBlZGdlcyB3aGljaCBsaW5rIGltbWVkaWF0ZSBjaGlsZHJlbiBvZiB0aGlzXG4gICAqIGdyb3VwIHdpdGggbm9kZXMgb3V0c2lkZSBvZiB0aGUgbWV0YWdyYXBoLiBBcyBpbiB0aGUgbWV0YWdyYXBoLCBhbGwgZWRnZVxuICAgKiBsYWJlbCBvYmplY3RzIGFyZSBNZXRhZWRnZXMgd2hpY2ggY29udGFpbiByZWZlcmVuY2VzIHRvIHRoZSBvcmlnaW5hbFxuICAgKiBCYXNlRWRnZShzKSB0aGF0IGNvbnRyaWJ1dGUgdG8gaXQuXG4gICAqXG4gICAqIEZvciBhIE1ldGFlZGdlIGluIHRoZSBicmlkZ2VncmFwaCwgaXRzIGV4dGVybmFsIGVuZHBvaW50IHdpbGwgYmUgdGhlIHNhbWVcbiAgICogYXMgdGhlIG1ldGFncmFwaCBlZGdlIGZyb20gd2hpY2ggaXQgY2FtZS4gVGhpcyBpcyBtb3N0IGVhc2lseSBleHBsYWluZWRcbiAgICogYnkgZXhhbXBsZS5cbiAgICpcbiAgICogQ29uc2lkZXIgYW4gb3JpZ2luYWwgZ3JhcGggdGhhdCBjb250YWlucyBhIEJhc2VFZGdlIEEvQi9DLT5aL1kvWC5cbiAgICpcbiAgICogICAgICstLS0tLS0tKyAgICAoQmFzZUVkZ2UpICAgICArLS0tLS0tLStcbiAgICogICAgIHwgQS9CL0MgfD4tLS0tLS0tLS0tLS0tLS0tLT58IFovWS9YIHxcbiAgICogICAgICstLS0tLS0tKyAgICAgICAgICAgICAgICAgICArLS0tLS0tLStcbiAgICpcbiAgICogV2hlbiB3ZSBjb25zdHJ1Y3QgdGhlIFJvb3QncyBtZXRhZ3JhcGgsIGl0IHdpbGwgY29udGFpbiBub2RlcyBmb3IgQSBhbmQgWixcbiAgICogYW5kIGEgTWV0YWVkZ2UgQS0+Wi4gVGhlIEEtPlogTWV0YWVkZ2Ugd2lsbCBjb250YWluIHRoZSBvcmlnaW5hbCBCYXNlRWRnZVxuICAgKiBBL0IvQy0+Wi9ZL1ggaW4gaXRzIGJhc2VFZGdlR3JhcGguIFRoZSBSb290J3MgYnJpZGdlZ3JhcGggd2lsbCBhbHdheXMgYmVcbiAgICogZW1wdHkuXG4gICAqXG4gICAqICAgICArLS0tKyAgICAoUm9vdC5tZXRhZ3JhcGggZWRnZSkgICAgKy0tLStcbiAgICogICAgIHwgQSB8Pi0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLT58IFogfFxuICAgKiAgICAgKy0tLSsgICAgICAgICAgICAgICAgICAgICAgICAgICAgICstLS0rXG4gICAqXG4gICAqIE5vdyBjb25zaWRlciB0aGUgTWV0YW5vZGUgQS4gSXRzIG1ldGFncmFwaCB3aWxsIGNvbnRhaW4gYSBNZXRhbm9kZSBmb3IgQS9CXG4gICAqIGFuZCBubyBlZGdlcy4gQSdzIGJyaWRnZWdyYXBoIHdpbGwgaGF2ZSBvbmUgTWV0YWVkZ2UgZnJvbSBBL0ItPlosIHdoaWNoXG4gICAqIHdhcyBkZXJpdmVkIGZyb20gdGhlIFJvb3QncyBNZXRhZWRnZSBBLT5aLiBUaGF0IE1ldGFlZGdlIHdpbGwgY29udGFpbiB0aGVcbiAgICogb3JpZ2luYWwgQmFzZUVkZ2UgaW4gaXRzIGJhc2VFZGdlR3JhcGguXG4gICAqXG4gICAqICAgICArLS0tLS0tLS0tK1xuICAgKiAgICAgfCBBICAgICAgIHxcbiAgICogICAgIHwgICstLS0rICB8ICAgKEEuYnJpZGdlZ3JhcGggZWRnZSkgICAgKy0tLStcbiAgICogICAgIHwgIHwgQiB8Pi0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0+fCBaIHxcbiAgICogICAgIHwgICstLS0rICB8ICAgICAgICAgICAgICAgICAgICAgICAgICAgKy0tLStcbiAgICogICAgICstLS0tLS0tLS0rXG4gICAqXG4gICAqIEZpbmFsbHksIGNvbnNpZGVyIHRoZSBNZXRhbm9kZSBBL0IuIEl0cyBtZXRhZ3JhcGggd2lsbCBjb250YWluIGEgTWV0YW5vZGVcbiAgICogZm9yIEEvQi9DIGFuZCBhZ2FpbiBubyBlZGdlcy4gQS9CJ3MgYnJpZGdlZ3JhcGggd2lsbCBoYXZlIG9uZSBNZXRhZWRnZVxuICAgKiBmcm9tIEEvQi9DLT5aLCB3aGljaCB3YXMgZGVyaXZlZCBmcm9tIEEncyBicmlkZ2VncmFwaCBNZXRhZWRnZSBBL0ItPlouXG4gICAqIEFzIGJlZm9yZSwgdGhlIEEvQi9DLT5aIE1ldGFlZGdlIHdpbGwgY29udGFpbiB0aGUgb3JpZ2luYWwgQmFzZUVkZ2UgaW4gaXRzXG4gICAqIGJhc2VFZGdlR3JhcGguXG4gICAqXG4gICAqICAgICArLS0tLS0tLS0tLS0tLS0tK1xuICAgKiAgICAgfCBBICAgICAgICAgICAgIHxcbiAgICogICAgIHwgICstLS0tLS0tLS0rICB8XG4gICAqICAgICB8ICB8IEIgICAgICAgfCAgfFxuICAgKiAgICAgfCAgfCAgKy0tLSsgIHwgIHwgICAoQS9CLmJyaWRnZWdyYXBoIGVkZ2UpICAgICAgKy0tLStcbiAgICogICAgIHwgIHwgIHwgQyB8Pi0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tPnwgWiB8XG4gICAqICAgICB8ICB8ICArLS0tKyAgfCAgfCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICArLS0tK1xuICAgKiAgICAgfCAgKy0tLS0tLS0tLSsgIHxcbiAgICogICAgICstLS0tLS0tLS0tLS0tLS0rXG4gICAqXG4gICAqIExpa2V3aXNlLCB1bmRlciB0aGUgTWV0YW5vZGUgWiBhbmQgWi9ZLCB0byBjb21wdXRlIHRoZSBicmlkZ2VncmFwaCwgd2UnbGxcbiAgICogZW5kIHVwIHdpdGggTWV0YWVkZ2VzIEEtPlovWSBhbmQgQS0+Wi9ZL1ggcmVzcGVjdGl2ZWx5LiBTbyB0aGUgb3JpZ2luYWxcbiAgICogQmFzZUVkZ2UgQS9CL0MtPlovWS9YIGJlY29tZXMgZm91ciBkaWZmZXJlbnQgTWV0YWVkZ2VzIGluIGZvdXIgZGlmZmVyZW50XG4gICAqIGJyaWRnZWdyYXBoczpcbiAgICpcbiAgICogICArIEEvQi0+WiBpbiBHcm91cE5vZGUgQSdzIGJyaWRnZWdyYXBoLFxuICAgKiAgICsgQS9CL0MtPlogaW4gR3JvdXBOb2RlIEEvQidzIGJyaWRnZWdyYXBoLFxuICAgKiAgICsgQS0+Wi9ZIGluIEdyb3VwTm9kZSBaJ3MgYnJpZGdlZ3JhcGgsIGFuZFxuICAgKiAgICsgQS0+Wi9ZL1ggaW4gR3JvdXBOb2RlIFovWSdzIGJyaWRnZWdyYXBoLlxuICAgKlxuICAgKiBDb25zaWRlcmluZyBhbnkgQmFzZUVkZ2UgdGhlbiwgaWYgTiBpcyB0aGUgbnVtYmVyIG9mIHBhdGggc2VnbWVudHMgaW4gdGhlXG4gICAqIHNvdXJjZSBhbmQgTSBpcyB0aGUgbnVtYmVyIG9mIHBhdGggc2VnbWVudHMgaW4gdGhlIGRlc3RpbmF0aW9uLCB0aGVuIHRoZVxuICAgKiB0b3RhbCBudW1iZXIgb2YgYnJpZGdlZ3JhcGggZWRnZXMgeW91IGNvdWxkIGNyZWF0ZSB3b3VsZCBiZSAoTi0xKShNLTEpLlxuICAgKlxuICAgKiBGb3IgdGhpcyByZWFzb24sIGl0IGlzIGNvbXB1dGF0aW9uYWxseSBleHBlbnNpdmUgdG8gZ2VuZXJhdGUgYWxsIHRoZVxuICAgKiBicmlkZ2VncmFwaHMgZm9yIGFsbCB0aGUgTWV0YW5vZGVzLCBhbmQgaW5zdGVhZCB0aGV5IHNob3VsZCBiZSBjb21wdXRlZFxuICAgKiBvbiBkZW1hbmQgYXMgbmVlZGVkLlxuICAgKi9cbiAgYnJpZGdlZ3JhcGg6IGdyYXBobGliLkdyYXBoPEdyb3VwTm9kZXxPcE5vZGUsIE1ldGFlZGdlPjtcblxuICAvKipcbiAgICogU3RvcmVzIGhvdyBtYW55IHRpbWVzIGVhY2ggZGV2aWNlIG5hbWUgYXBwZWFycyBpbiBpdHMgY2hpbGRyZW5cbiAgICogb3Agbm9kZXMuIFVzZWQgdG8gY29sb3IgZ3JvdXAgbm9kZXMgYnkgZGV2aWNlcy5cbiAgICovXG4gIGRldmljZUhpc3RvZ3JhbToge1tkZXZpY2U6IHN0cmluZ106IG51bWJlcn07XG5cbiAgLyoqXG4gICAqIFN0b3JlcyBob3cgbWFueSB0aW1lcyBlYWNoIFhMQSBjbHVzdGVyIG5hbWUgYXBwZWFycyBpbiBpdHMgY2hpbGRyZW5cbiAgICogb3Agbm9kZXMuIFVzZWQgdG8gY29sb3IgZ3JvdXAgbm9kZXMgYnkgWExBIGNsdXN0ZXJzLlxuICAgKi9cbiAgeGxhQ2x1c3Rlckhpc3RvZ3JhbToge1tkZXZpY2U6IHN0cmluZ106IG51bWJlcn07XG5cbiAgLyoqXG4gICAqIFN0b3JlcyBob3cgbWFueSBvcHMgaW4gc3ViLWdyYXBoIHdlcmUgY29tcGF0aWJsZSBhbmQgaG93IG1hbnkgYXJlXG4gICAqIGluY29tcGF0aWJsZS5cbiAgICovXG4gIGNvbXBhdGliaWxpdHlIaXN0b2dyYW06IHtjb21wYXRpYmxlOiBudW1iZXIsIGluY29tcGF0aWJsZTogbnVtYmVyfVxuXG4gIC8qKlxuICAgKiBGbGFnIGluZGljYXRpbmcgd2hldGhlciB0aGlzIEdyb3VwTm9kZSdzIG1ldGFncmFwaCBjb250YWlucyBhbnkgZWRnZXMgdGhhdFxuICAgKiBhcmUgbm90IGNvbnRyb2wgZWRnZXMuIFVzZWQgdG8gcXVpY2tseSBkZXRlcm1pbmUgaG93IHRvIGRyYXcgYSBjb2xsYXBzZWRcbiAgICogc2VyaWVzICh2ZXJ0aWNhbGx5IG9yIGhvcml6b250YWxseSkuXG4gICAqL1xuICBoYXNOb25Db250cm9sRWRnZXM6IGJvb2xlYW47XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgTWV0YW5vZGUgZXh0ZW5kcyBHcm91cE5vZGUge1xuICBkZXB0aDogbnVtYmVyO1xuICB0ZW1wbGF0ZUlkOiBzdHJpbmc7XG4gIG9wSGlzdG9ncmFtOiB7W29wOiBzdHJpbmddOiBudW1iZXJ9O1xuXG4gIC8vIFRoZSBuYW1lIG9mIHRoZSBmdW5jdGlvbiB0aGlzIG1ldGFub2RlIGlzIGFzc29jaWF0ZWQgd2l0aCBpZiBhbnkuXG4gIGFzc29jaWF0ZWRGdW5jdGlvbjogc3RyaW5nO1xuICBcbiAgZ2V0Rmlyc3RDaGlsZCgpOiBHcm91cE5vZGV8T3BOb2RlO1xuICBnZXRSb290T3AoKTogT3BOb2RlO1xuICAvKiogUmV0dXJuIG5hbWUgb2YgYWxsIGxlYXZlcyBpbnNpZGUgYSBtZXRhbm9kZS4gKi9cbiAgbGVhdmVzKCk6IHN0cmluZ1tdO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIFNlcmllc05vZGUgZXh0ZW5kcyBHcm91cE5vZGUge1xuICBoYXNMb29wOiBib29sZWFuO1xuICBwcmVmaXg6IHN0cmluZztcbiAgc3VmZml4OiBzdHJpbmc7XG4gIGNsdXN0ZXJJZDogbnVtYmVyO1xuICBpZHM6IG51bWJlcltdO1xuICBwYXJlbnQ6IHN0cmluZztcbn1cblxuZXhwb3J0IGNsYXNzIEVsbGlwc2lzTm9kZUltcGwgaW1wbGVtZW50cyBFbGxpcHNpc05vZGUge1xuICBuYW1lOiBzdHJpbmc7XG4gIG51bU1vcmVOb2RlczogbnVtYmVyO1xuICBzdGF0czogTm9kZVN0YXRzO1xuICB0eXBlOiBOb2RlVHlwZTtcbiAgaXNHcm91cE5vZGU6IGJvb2xlYW47XG4gIGNhcmRpbmFsaXR5OiBudW1iZXI7XG4gIHBhcmVudE5vZGU6IE5vZGU7XG4gIGluY2x1ZGU6IEluY2x1c2lvblR5cGU7XG4gIG5vZGVBdHRyaWJ1dGVzOiB7W2tleTogc3RyaW5nXTogYW55O307XG4gIC8qKlxuICAgKiBDb25zdHJ1Y3RzIGEgbmV3IGVsbGlwc2lzIGFubm90YXRpb24gbm9kZS5cbiAgICpcbiAgICogQHBhcmFtIG51bU5vZGVzIFRoZSBudW1iZXIgb2YgYWRkaXRpb25hbCBhbm5vdGF0aW9ucyB0aGlzIG5vZGUgcmVwcmVzZW50cy5cbiAgICovXG4gIGNvbnN0cnVjdG9yKG51bU5vZGVzOiBudW1iZXIpIHtcbiAgICB0aGlzLnR5cGUgPSBOb2RlVHlwZS5FTExJUFNJUztcbiAgICB0aGlzLmlzR3JvdXBOb2RlID0gZmFsc2U7XG4gICAgdGhpcy5jYXJkaW5hbGl0eSA9IDE7XG4gICAgdGhpcy5wYXJlbnROb2RlID0gbnVsbDtcbiAgICB0aGlzLnN0YXRzID0gbnVsbDtcbiAgICB0aGlzLnNldE51bU1vcmVOb2RlcyhudW1Ob2Rlcyk7XG4gICAgdGhpcy5pbmNsdWRlID0gSW5jbHVzaW9uVHlwZS5VTlNQRUNJRklFRDtcbiAgfVxuXG4gIHNldE51bU1vcmVOb2RlcyhudW1Ob2RlczogbnVtYmVyKSB7XG4gICAgdGhpcy5udW1Nb3JlTm9kZXMgPSBudW1Ob2RlcztcbiAgICB0aGlzLm5hbWUgPSAnLi4uICcgKyBudW1Ob2RlcyArICcgbW9yZSc7XG4gIH1cbn07XG5cbi8qKlxuICogQSBsYWJlbCBvYmplY3QgZm9yIG5vZGVzIGluIHRoZSBmdWxsIGdyYXBoIGFuZCBsZWFmIG5vZGVzIGluIHRoZSByZW5kZXJcbiAqIGdyYXBoLlxuICovXG5leHBvcnQgY2xhc3MgT3BOb2RlSW1wbCBpbXBsZW1lbnRzIE9wTm9kZSB7XG4gIG5hbWU6IHN0cmluZztcbiAgb3A6IHN0cmluZztcbiAgZGV2aWNlOiBzdHJpbmc7XG4gIHN0YXRzOiBOb2RlU3RhdHM7XG4gIGF0dHI6IHtrZXk6IHN0cmluZywgdmFsdWU6IGFueX1bXTtcbiAgaW5wdXRzOiBOb3JtYWxpemVkSW5wdXRbXTtcbiAgdHlwZTogTm9kZVR5cGU7XG4gIGlzR3JvdXBOb2RlOiBib29sZWFuO1xuICBjYXJkaW5hbGl0eTogbnVtYmVyO1xuICBpbkVtYmVkZGluZ3M6IE9wTm9kZVtdO1xuICBvdXRFbWJlZGRpbmdzOiBPcE5vZGVbXTtcbiAgcGFyZW50Tm9kZTogTm9kZTtcbiAgaW5jbHVkZTogSW5jbHVzaW9uVHlwZTtcbiAgb3duaW5nU2VyaWVzOiBzdHJpbmc7XG4gIG91dHB1dFNoYXBlczoge1trZXk6IHN0cmluZ106IFRlbnNvclNoYXBlO307XG4gIG5vZGVBdHRyaWJ1dGVzOiB7W2tleTogc3RyaW5nXTogYW55O307XG4gIHhsYUNsdXN0ZXI6IHN0cmluZztcbiAgY29tcGF0aWJsZTogYm9vbGVhbjtcblxuICAvLyBUaGlzIGZpZWxkIGlzIG9ubHkgZGVmaW5lZCBpZiB0aGUgb3Agbm9kZSByZXByZXNlbnRzIGFuIGlucHV0X2FyZyB0byBhXG4gIC8vIGxpYnJhcnkgZnVuY3Rpb24uIEl0IGlzIHRoZSBpbmRleCBvZiB0aGUgaW5wdXRfYXJnLlxuICBmdW5jdGlvbklucHV0SW5kZXg6IG51bWJlcjtcbiAgXG4gIC8vIFRoaXMgZmllbGQgaXMgb25seSBkZWZpbmVkIGlmIHRoZSBvcCBub2RlIHJlcHJlc2VudHMgYW4gb3V0cHV0X2FyZyBvZiBhXG4gIC8vIGxpYnJhcnkgZnVuY3Rpb24uIEl0IGlzIHRoZSBpbmRleCBvZiB0aGUgb3V0cHV0X2FyZy5cbiAgZnVuY3Rpb25PdXRwdXRJbmRleDogbnVtYmVyO1xuXG4gIC8qKlxuICAgKiBDb25zdHJ1Y3RzIGEgbmV3IE9wIG5vZGUuXG4gICAqXG4gICAqIEBwYXJhbSByYXdOb2RlIFRoZSByYXcgbm9kZS5cbiAgICovXG4gIGNvbnN0cnVjdG9yKHJhd05vZGU6IHRmLmdyYXBoLnByb3RvLk5vZGVEZWYpIHtcbiAgICB0aGlzLm9wID0gcmF3Tm9kZS5vcDtcbiAgICB0aGlzLm5hbWUgPSByYXdOb2RlLm5hbWU7XG4gICAgdGhpcy5kZXZpY2UgPSByYXdOb2RlLmRldmljZTtcbiAgICB0aGlzLmF0dHIgPSByYXdOb2RlLmF0dHI7XG4gICAgLy8gQW4gYXJyYXkgb2Ygbm9ybWFsaXplZCBpbnB1dHMgdGhhdCBkZW5vdGUgdGhlIGluY29taW5nIGVkZ2VzIHRvXG4gICAgLy8gdGhlIGN1cnJlbnQgbm9kZS4gRWFjaCBpbnB1dCBjb250YWlucyB0aGUgbm9ybWFsaXplZCBuYW1lIG9mIHRoZVxuICAgIC8vIHNvdXJjZSBub2RlLCB3aGV0aGVyIGl0IGhhcyBhIG51bWJlciBwYXJ0IGFuZCB3aGV0aGVyIGl0IGlzIGFcbiAgICAvLyBjb250cm9sIGRlcGVuZGVuY3kuXG4gICAgdGhpcy5pbnB1dHMgPSBub3JtYWxpemVJbnB1dHMocmF3Tm9kZS5pbnB1dCk7XG4gICAgdGhpcy5vdXRwdXRTaGFwZXMgPSBleHRyYWN0T3V0cHV0U2hhcGVzKHJhd05vZGUuYXR0cik7XG4gICAgdGhpcy54bGFDbHVzdGVyID0gZXh0cmFjdFhsYUNsdXN0ZXIocmF3Tm9kZS5hdHRyKTtcbiAgICB0aGlzLmNvbXBhdGlibGUgPSBmYWxzZTtcbiAgICAvLyBhZGRpdGlvbmFsIHByb3BlcnRpZXNcbiAgICB0aGlzLnR5cGUgPSBOb2RlVHlwZS5PUDtcbiAgICB0aGlzLmlzR3JvdXBOb2RlID0gZmFsc2U7XG4gICAgdGhpcy5jYXJkaW5hbGl0eSA9IDE7XG4gICAgdGhpcy5pbkVtYmVkZGluZ3MgPSBbXTtcbiAgICB0aGlzLm91dEVtYmVkZGluZ3MgPSBbXTtcbiAgICB0aGlzLnBhcmVudE5vZGUgPSBudWxsO1xuICAgIHRoaXMuaW5jbHVkZSA9IEluY2x1c2lvblR5cGUuVU5TUEVDSUZJRUQ7XG4gICAgdGhpcy5vd25pbmdTZXJpZXMgPSBudWxsO1xuICB9XG59O1xuXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlTWV0YW5vZGUobmFtZTogc3RyaW5nLCBvcHQgPSB7fSk6IE1ldGFub2RlIHtcbiAgcmV0dXJuIG5ldyBNZXRhbm9kZUltcGwobmFtZSwgb3B0KTtcbn1cblxuLyoqXG4gKiBKb2lucyB0aGUgaW5mb3JtYXRpb24gZnJvbSB0aGUgc3RhdHMgZmlsZSAobWVtb3J5LCBjb21wdXRlIHRpbWUpIHdpdGggdGhlXG4gKiBncmFwaCBpbmZvcm1hdGlvbi5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGpvaW5TdGF0c0luZm9XaXRoR3JhcGgoXG4gICAgZ3JhcGg6IFNsaW1HcmFwaCwgc3RhdHM6IHRmLmdyYXBoLnByb3RvLlN0ZXBTdGF0cyxcbiAgICBkZXZpY2VzRm9yU3RhdHM/OiB7W2RldmljZTogc3RyaW5nXTogYm9vbGVhbn0pOiB2b2lkIHtcbiAgLy8gUmVzZXQgc3RhdHMgZm9yIGVhY2ggbm9kZS5cbiAgXy5lYWNoKGdyYXBoLm5vZGVzLCBub2RlID0+IHsgbm9kZS5zdGF0cyA9IG51bGw7IH0pO1xuXG4gIF8uZWFjaChzdGF0cy5kZXZfc3RhdHMsIGRldlN0YXRzID0+IHtcbiAgICAvLyBJZ25vcmUgZGV2aWNlcyB0aGF0IGFyZSBub3Qgc2VsZWN0ZWQuXG4gICAgaWYgKGRldmljZXNGb3JTdGF0cyAmJiAhZGV2aWNlc0ZvclN0YXRzW2RldlN0YXRzLmRldmljZV0pIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgXy5lYWNoKGRldlN0YXRzLm5vZGVfc3RhdHMsIG5vZGVTdGF0cyA9PiB7XG4gICAgICAvLyBMb29rdXAgdGhlIG5vZGUgaW4gdGhlIGdyYXBoIGJ5IGl0cyBvcmlnaW5hbCBuYW1lLCBlLmcuIEEvQi4gSWYgbm90XG4gICAgICAvLyBmb3VuZCwgbG9va3VwIGJ5IHRoZSByZXdyaXR0ZW4gbmFtZSBBL0IvKEIpIGluIGNhc2UgdGhlIG5hbWUgaXMgYm90aFxuICAgICAgLy8gYSBuYW1lc3BhY2UgYW5kIGEgbm9kZSBuYW1lLlxuICAgICAgbGV0IG5vZGVOYW1lID0gbm9kZVN0YXRzLm5vZGVfbmFtZSBpbiBncmFwaC5ub2RlcyA/XG4gICAgICAgICAgbm9kZVN0YXRzLm5vZGVfbmFtZSA6XG4gICAgICAgICAgZ2V0U3RyaWN0TmFtZShub2RlU3RhdHMubm9kZV9uYW1lKTtcblxuICAgICAgLy8gQ291bGRuJ3QgZmluZCBhIG1hdGNoaW5nIG5vZGUuXG4gICAgICBpZiAoIShub2RlTmFtZSBpbiBncmFwaC5ub2RlcykpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuXG4gICAgICAvLyBDb21wdXRlIHRoZSB0b3RhbCBieXRlcyB1c2VkLlxuICAgICAgbGV0IHRvdGFsQnl0ZXMgPSAwO1xuICAgICAgaWYgKG5vZGVTdGF0cy5tZW1vcnkpIHtcbiAgICAgICAgXy5lYWNoKG5vZGVTdGF0cy5tZW1vcnksIGFsbG9jID0+IHtcbiAgICAgICAgaWYgKGFsbG9jLnRvdGFsX2J5dGVzKSB7XG4gICAgICAgICAgICBpZiAoYWxsb2MudG90YWxfYnl0ZXMgPiAwKSB7XG4gICAgICAgICAgICAgIHRvdGFsQnl0ZXMgKz0gTnVtYmVyKGFsbG9jLnRvdGFsX2J5dGVzKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgIC8qIHRzbGludDpkaXNhYmxlICovXG4gICAgICAgICAgICAgIGNvbnNvbGUubG9nKFxuICAgICAgICAgICAgICAgICAgJ2lnbm9yaW5nIG5lZ2F0aXZlIG1lbW9yeSBhbGxvY2F0aW9uIGZvciAnICsgbm9kZU5hbWUpO1xuICAgICAgICAgICAgICAvKiB0c2xpbnQ6ZW5hYmxlICovXG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICAgIGxldCBvdXRwdXRTaXplOiBudW1iZXJbXVtdID0gbnVsbDtcbiAgICAgIGlmIChub2RlU3RhdHMub3V0cHV0KSB7XG4gICAgICAgIG91dHB1dFNpemUgPSBfLm1hcChub2RlU3RhdHMub3V0cHV0LCBvdXRwdXQgPT4ge1xuICAgICAgICAgIHJldHVybiBfLm1hcChvdXRwdXQudGVuc29yX2Rlc2NyaXB0aW9uLnNoYXBlLmRpbSxcbiAgICAgICAgICAgICAgZGltID0+IE51bWJlcihkaW0uc2l6ZSkpO1xuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICAgIGdyYXBoLm5vZGVzW25vZGVOYW1lXS5kZXZpY2UgPSBkZXZTdGF0cy5kZXZpY2U7XG4gICAgICBpZiAoZ3JhcGgubm9kZXNbbm9kZU5hbWVdLnN0YXRzID09IG51bGwpIHtcbiAgICAgICAgZ3JhcGgubm9kZXNbbm9kZU5hbWVdLnN0YXRzID0gbmV3IE5vZGVTdGF0cyhvdXRwdXRTaXplKTtcbiAgICAgIH1cbiAgICAgIGdyYXBoLm5vZGVzW25vZGVOYW1lXS5zdGF0cy5hZGRCeXRlc0FsbG9jYXRpb24odG90YWxCeXRlcyk7XG4gICAgICBpZiAobm9kZVN0YXRzLmFsbF9lbmRfcmVsX21pY3Jvcykge1xuICAgICAgICBpZiAobm9kZVN0YXRzLmFsbF9lbmRfcmVsX21pY3JvcyA+IDApIHtcbiAgICAgICAgICBncmFwaC5ub2Rlc1tub2RlTmFtZV0uc3RhdHMuYWRkRXhlY3V0aW9uVGltZShcbiAgICAgICAgICAgICAgbm9kZVN0YXRzLmFsbF9zdGFydF9taWNyb3MsXG4gICAgICAgICAgICAgIG5vZGVTdGF0cy5hbGxfc3RhcnRfbWljcm9zICsgbm9kZVN0YXRzLmFsbF9lbmRfcmVsX21pY3Jvcyk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgLyogdHNsaW50OmRpc2FibGUgKi9cbiAgICAgICAgICBjb25zb2xlLmxvZygnaWdub3JpbmcgbmVnYXRpdmUgcnVudGltZSBmb3IgJyArIG5vZGVOYW1lKTtcbiAgICAgICAgICAvKiB0c2xpbnQ6ZW5hYmxlICovXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9KTtcbiAgfSk7XG59XG5cbi8qKlxuICogRXhlY3V0aW9uIHN0YXRzIGZvciB0aGUgbm9kZS5cbiAqL1xuZXhwb3J0IGNsYXNzIE5vZGVTdGF0cyB7XG4gIGNvbnN0cnVjdG9yKG91dHB1dFNpemU6IG51bWJlcltdW10pIHsgdGhpcy5vdXRwdXRTaXplID0gb3V0cHV0U2l6ZTsgfVxuXG4gIC8qKlxuICAgKiBBZGQgdGhlIHN0YXJ0IGFuZCBlbmQgdGltZSBmb3IgYSBwYXJ0aWN1bGFyIGtlcm5lbCBleGVjdXRpb24gb2YgdGhpcyBvcC5cbiAgICogT3BzIGNhbiBoYXZlIG11bHRpcGxlIGtlcm5lbCBleGVjdXRpb25zIHdpdGhpbiB0aGUgc2FtZSBzZXNzaW9uIHJ1bi5cbiAgICovXG4gIGFkZEV4ZWN1dGlvblRpbWUoc3RhcnRUaW1lOiBudW1iZXIsIGVuZFRpbWU6IG51bWJlcikge1xuICAgIGlmICh0aGlzLnN0YXJ0VGltZSAhPSBudWxsKSB7XG4gICAgICB0aGlzLnN0YXJ0VGltZSA9IE1hdGgubWluKHRoaXMuc3RhcnRUaW1lLCBzdGFydFRpbWUpO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLnN0YXJ0VGltZSA9IHN0YXJ0VGltZTtcbiAgICB9XG4gICAgaWYgKHRoaXMuZW5kVGltZSAhPSBudWxsKSB7XG4gICAgICB0aGlzLmVuZFRpbWUgPSBNYXRoLm1heCh0aGlzLmVuZFRpbWUsIGVuZFRpbWUpO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLmVuZFRpbWUgPSBlbmRUaW1lO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBBZGQgdGhlIGJ5dGVzIGFsbG9jYXRlZCBmb3IgYSBwYXJ0aWN1bGFyIGtlcm5lbCBleGVjdXRpb24gb2YgdGhpcyBvcC5cbiAgICogT3BzIGNhbiBoYXZlIG11bHRpcGxlIGtlcm5lbCBleGVjdXRpb25zIHdpdGhpbiB0aGUgc2FtZSBzZXNzaW9uIHJ1bi5cbiAgICovXG4gIGFkZEJ5dGVzQWxsb2NhdGlvbih0b3RhbEJ5dGVzOiBudW1iZXIpIHtcbiAgICBpZiAodGhpcy50b3RhbEJ5dGVzICE9IG51bGwpIHtcbiAgICAgIHRoaXMudG90YWxCeXRlcyA9IE1hdGgubWF4KHRoaXMudG90YWxCeXRlcywgdG90YWxCeXRlcyk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMudG90YWxCeXRlcyA9IHRvdGFsQnl0ZXM7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIEFic29sdXRlIHN0YXJ0IHRpbWUgZm9yIHRoZSB2ZXJ5IGZpcnN0IGtlcm5lbCBleGVjdXRpb24gb2YgdGhpcyBvcC5cbiAgICovXG4gIHN0YXJ0VGltZTogbnVtYmVyO1xuICAvKipcbiAgICogQWJzb2x1dGUgZW5kIHRpbWUgZm9yIHRoZSB2ZXJ5IGxhc3Qga2VybmVsIGV4ZWN1dGlvbiBvZiB0aGlzIG9wLlxuICAgKi9cbiAgZW5kVGltZTogbnVtYmVyO1xuICAvKipcbiAgICogVG90YWwgbnVtYmVyIG9mIGJ5dGVzIHVzZWQgZm9yIHRoZSBub2RlLiBTdW0gb2YgYWxsIGNoaWxkcmVuXG4gICAqIGlmIGl0IGlzIGEgR3JvdXAgbm9kZS5cbiAgICovXG4gIHRvdGFsQnl0ZXMgPSAwO1xuXG4gIC8qKlxuICAgKiBUaGUgc2hhcGUgb2YgZWFjaCBvdXRwdXQgdGVuc29ycywgaWYgdGhlcmUgYXJlIGFueS5cbiAgICogRW1wdHkgaWYgaXQgaXMgYSBHcm91cCBub2RlLlxuICAgKi9cbiAgb3V0cHV0U2l6ZTogbnVtYmVyW11bXTtcblxuICAvKipcbiAgICogQ29tYmluZXMgdGhlIHNwZWNpZmllZCBzdGF0cyB3aXRoIHRoZSBjdXJyZW50IHN0YXRzLlxuICAgKiBNb2RpZmllcyB0aGUgY3VycmVudCBvYmplY3QuIFRoaXMgbWV0aG9kIGlzIHVzZWQgdG9cbiAgICogY29tcHV0ZSBhZ2dyZWdhdGUgc3RhdHMgZm9yIGdyb3VwIG5vZGVzLlxuICAgKi9cbiAgY29tYmluZShzdGF0czogTm9kZVN0YXRzKTogdm9pZCB7XG4gICAgaWYgKHN0YXRzLnRvdGFsQnl0ZXMgIT0gbnVsbCkge1xuICAgICAgdGhpcy50b3RhbEJ5dGVzICs9IHN0YXRzLnRvdGFsQnl0ZXM7XG4gICAgfVxuICAgIGlmIChzdGF0cy5nZXRUb3RhbE1pY3JvcygpICE9IG51bGwpIHtcbiAgICAgIHRoaXMuYWRkRXhlY3V0aW9uVGltZShzdGF0cy5zdGFydFRpbWUsIHN0YXRzLmVuZFRpbWUpO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBUb3RhbCBudW1iZXIgb2YgY29tcHV0ZSB0aW1lIGluIG1pY3Jvc2Vjb25kcyB1c2VkIGZvciB0aGUgbm9kZS5cbiAgICogU3VtIG9mIGFsbCBjaGlsZHJlbiBpZiBpdCBpcyBhIEdyb3VwIG5vZGUuIE51bGwgaWYgaXQgaXMgdW5rbm93bi5cbiAgICogVGhpcyBtZXRob2QgY2FuIG5vdCBiZSBzY2FmZm9sZGVkIHVuZGVyIGEgZ2V0dGVyIGF0dHJpYnV0ZSBiZWNhdXNlXG4gICAqIEVDTUFTY3JpcHQgNSBkb2VzIG5vdCBzdXBwb3J0IGdldHRlciBhdHRyaWJ1dGVzLlxuICAgKi9cbiAgZ2V0VG90YWxNaWNyb3MoKTogbnVtYmVyIHtcbiAgICBpZiAodGhpcy5zdGFydFRpbWUgPT0gbnVsbCB8fCB0aGlzLmVuZFRpbWUgPT0gbnVsbCkge1xuICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLmVuZFRpbWUgLSB0aGlzLnN0YXJ0VGltZTtcbiAgfVxufVxuXG5leHBvcnQgY2xhc3MgTWV0YW5vZGVJbXBsIGltcGxlbWVudHMgTWV0YW5vZGUge1xuICBuYW1lOiBzdHJpbmc7XG4gIHN0YXRzOiBOb2RlU3RhdHM7XG4gIHR5cGU6IE5vZGVUeXBlO1xuICBkZXB0aDogbnVtYmVyO1xuICBpc0dyb3VwTm9kZTogYm9vbGVhbjtcbiAgY2FyZGluYWxpdHk6IG51bWJlcjtcbiAgbWV0YWdyYXBoOiBncmFwaGxpYi5HcmFwaDxHcm91cE5vZGV8T3BOb2RlLCBNZXRhZWRnZT47XG4gIGJyaWRnZWdyYXBoOiBncmFwaGxpYi5HcmFwaDxHcm91cE5vZGV8T3BOb2RlLCBNZXRhZWRnZT47XG4gIHRlbXBsYXRlSWQ6IHN0cmluZztcbiAgb3BIaXN0b2dyYW06IHtbb3A6IHN0cmluZ106IG51bWJlcn07XG4gIGRldmljZUhpc3RvZ3JhbToge1tvcDogc3RyaW5nXTogbnVtYmVyfTtcbiAgeGxhQ2x1c3Rlckhpc3RvZ3JhbToge1tvcDogc3RyaW5nXTogbnVtYmVyfTtcbiAgY29tcGF0aWJpbGl0eUhpc3RvZ3JhbToge2NvbXBhdGlibGU6IG51bWJlciwgaW5jb21wYXRpYmxlOiBudW1iZXJ9O1xuICBwYXJlbnROb2RlOiBOb2RlO1xuICBoYXNOb25Db250cm9sRWRnZXM6IGJvb2xlYW47XG4gIGluY2x1ZGU6IEluY2x1c2lvblR5cGU7XG4gIG5vZGVBdHRyaWJ1dGVzOiB7W2tleTogc3RyaW5nXTogYW55O307XG4gIGFzc29jaWF0ZWRGdW5jdGlvbjogc3RyaW5nO1xuXG4gIC8qKiBBIGxhYmVsIG9iamVjdCBmb3IgbWV0YS1ub2RlcyBpbiB0aGUgZ3JhcGggaGllcmFyY2h5ICovXG4gIGNvbnN0cnVjdG9yKG5hbWU6IHN0cmluZywgb3B0ID0ge30pIHtcbiAgICB0aGlzLm5hbWUgPSBuYW1lO1xuICAgIHRoaXMudHlwZSA9IE5vZGVUeXBlLk1FVEE7XG4gICAgLyoqIG51bWJlciBvZiBsZXZlbHMgdW5kZXIgdGhpcyBncm91cCAqL1xuICAgIHRoaXMuZGVwdGggPSAxO1xuICAgIHRoaXMuaXNHcm91cE5vZGUgPSB0cnVlO1xuICAgIC8qKiAjIG9mIGxlYWYgbm9kZXMgKGluY2x1ZGluZyBlbWJlZGRlZCBvbmVzKSAqL1xuICAgIHRoaXMuY2FyZGluYWxpdHkgPSAwO1xuICAgIC8qKiBncmFwaCBjb250YWlucyBtZXRhbm9kZXMsIG5vZGVzLCBlZGdlc1xuICAgICAqIGFuZCBtZXRhZWRnZXMgZm9yIG1haW4gaXRlbXMgd2l0aGluIHRoaXMgbWV0YW5vZGVcbiAgICAgKi9cbiAgICB0aGlzLm1ldGFncmFwaCA9XG4gICAgICBjcmVhdGVHcmFwaDxHcm91cE5vZGV8T3BOb2RlLCBNZXRhZWRnZT4obmFtZSwgR3JhcGhUeXBlLk1FVEEsIG9wdCk7XG4gICAgLyoqIGJyaWRnZWdyYXBoIG11c3QgYmUgY29uc3RydWN0ZWQgbGF6aWx5LXNlZSBoaWVyYXJjaHkuZ2V0QnJpZGdlZ3JhcGgoKSAqL1xuICAgIHRoaXMuYnJpZGdlZ3JhcGggPSBudWxsO1xuICAgIC8qKlxuICAgICAqIEEgZGljdGlvbmFyeSB0aGF0IGNvdW50IG9wcyB0eXBlIG9mIG5vZGVzIGluIHRoaXMgbWV0YW5vZGVcbiAgICAgKiAob3AgdHlwZSA9PiBjb3VudCkuXG4gICAgICovXG4gICAgdGhpcy5vcEhpc3RvZ3JhbSA9IHt9O1xuICAgIHRoaXMuZGV2aWNlSGlzdG9ncmFtID0ge307XG4gICAgdGhpcy54bGFDbHVzdGVySGlzdG9ncmFtID0ge307XG4gICAgdGhpcy5jb21wYXRpYmlsaXR5SGlzdG9ncmFtID0ge2NvbXBhdGlibGU6IDAsIGluY29tcGF0aWJsZTogMH07XG4gICAgLyoqIHVuaXF1ZSBpZCBmb3IgYSBtZXRhbm9kZSBvZiBzaW1pbGFyIHN1YmdyYXBoICovXG4gICAgdGhpcy50ZW1wbGF0ZUlkID0gbnVsbDtcbiAgICAvKiogTWV0YW5vZGUgd2hpY2ggY29udGFpbnMgdGhpcyBub2RlLCBpZiBhbnkgKi9cbiAgICB0aGlzLnBhcmVudE5vZGUgPSBudWxsO1xuICAgIHRoaXMuaGFzTm9uQ29udHJvbEVkZ2VzID0gZmFsc2U7XG4gICAgdGhpcy5pbmNsdWRlID0gSW5jbHVzaW9uVHlwZS5VTlNQRUNJRklFRDtcbiAgICB0aGlzLmFzc29jaWF0ZWRGdW5jdGlvbiA9ICcnO1xuICB9XG5cbiAgZ2V0Rmlyc3RDaGlsZCgpOiBHcm91cE5vZGV8T3BOb2RlIHtcbiAgICByZXR1cm4gdGhpcy5tZXRhZ3JhcGgubm9kZSh0aGlzLm1ldGFncmFwaC5ub2RlcygpWzBdKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm5zIHRoZSBvcCBub2RlIGFzc29jaWF0ZWQgd2l0aCB0aGUgbWV0YW5vZGUuXG4gICAqIEZvciBleGFtcGxlLCBpZiB0aGUgbWV0YW5vZGUgaXMgJ3NnZCcsIHRoZSBhc3NvY2lhdGVkXG4gICAqIG9wIG5vZGUgaXMgc2dkLyhzZ2QpLlxuICAgKi9cbiAgZ2V0Um9vdE9wKCk6IE9wTm9kZSB7XG4gICAgbGV0IG5hbWVTcGxpdCA9IHRoaXMubmFtZS5zcGxpdCgnLycpO1xuICAgIGxldCByb290T3BOYW1lID0gdGhpcy5uYW1lICsgJy8oJyArIG5hbWVTcGxpdFtuYW1lU3BsaXQubGVuZ3RoIC0gMV0gKyAnKSc7XG4gICAgcmV0dXJuIDxPcE5vZGU+dGhpcy5tZXRhZ3JhcGgubm9kZShyb290T3BOYW1lKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm4gYW4gYXJyYXkgb2YgdGhlIG5hbWVzIG9mIGFsbCB0aGUgbGVhdmVzIChub24tR3JvdXBOb2RlcykgaW5zaWRlXG4gICAqIHRoaXMgbWV0YW5vZGUuIFRoaXMgcGVyZm9ybXMgYSBicmVhZHRoLWZpcnN0IHNlYXJjaCBvZiB0aGUgdHJlZSwgc29cbiAgICogaW1tZWRpYXRlIGNoaWxkIGxlYXZlcyB3aWxsIGFwcGVhciBlYXJsaWVyIGluIHRoZSBvdXRwdXQgYXJyYXkgdGhhblxuICAgKiBkZXNjZW5kYW50IGxlYXZlcy5cbiAgICovXG4gIGxlYXZlcygpOiBzdHJpbmdbXSB7XG4gICAgbGV0IGxlYXZlcyA9IFtdO1xuICAgIGxldCBxdWV1ZSA9IFs8Tm9kZT4gdGhpc107XG4gICAgbGV0IG1ldGFncmFwaDsgLy8gRGVmaW5lZCBoZXJlIGR1ZSB0byBhIGxpbWl0YXRpb24gb2YgRVM2LT41IGNvbXBpbGF0aW9uLlxuICAgIHdoaWxlIChxdWV1ZS5sZW5ndGgpIHtcbiAgICAgIGxldCBub2RlID0gcXVldWUuc2hpZnQoKTtcbiAgICAgIGlmIChub2RlLmlzR3JvdXBOb2RlKSB7XG4gICAgICAgIG1ldGFncmFwaCA9ICg8R3JvdXBOb2RlPiBub2RlKS5tZXRhZ3JhcGg7XG4gICAgICAgIF8uZWFjaChtZXRhZ3JhcGgubm9kZXMoKSwgbmFtZSA9PiBxdWV1ZS5wdXNoKG1ldGFncmFwaC5ub2RlKG5hbWUpKSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBsZWF2ZXMucHVzaChub2RlLm5hbWUpO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gbGVhdmVzO1xuICB9XG59O1xuXG5leHBvcnQgaW50ZXJmYWNlIE1ldGFlZGdlIGV4dGVuZHMgZ3JhcGhsaWIuRWRnZU9iamVjdCB7XG5cbiAgLyoqXG4gICAqIFN0b3JlcyB0aGUgb3JpZ2luYWwgQmFzZUVkZ2VzIHJlcHJlc2VudGVkIGJ5IHRoaXMgTWV0YWVkZ2UuXG4gICAqL1xuICBiYXNlRWRnZUxpc3Q6IEJhc2VFZGdlW107XG5cbiAgLyoqXG4gICAqIFdoZXRoZXIgdGhpcyBlZGdlIHJlcHJlc2VudHMgYSByZWxhdGlvbnNoaXAgdGhhdCBpcyBpbmJvdW5kIChvciBvdXRib3VuZClcbiAgICogdG8gdGhlIG9iamVjdCB3aGljaCBjb250YWlucyB0aGlzIGluZm9ybWF0aW9uLiBGb3IgZXhhbXBsZSwgaW4gYSBNZXRhbm9kZSdzXG4gICAqIGJyaWRnZWdyYXBoLCBlYWNoIGVkZ2UgY29ubmVjdHMgYW4gaW1tZWRpYXRlIGNoaWxkIHRvIHNvbWV0aGluZyBvdXRzaWRlXG4gICAqIHRoZSBNZXRhbm9kZS4gSWYgdGhlIGRlc3RpbmF0aW9uIG9mIHRoZSBlZGdlIGlzIGluc2lkZSB0aGUgTWV0YW5vZGUsIHRoZW5cbiAgICogaXRzIGluYm91bmQgcHJvcGVydHkgc2hvdWxkIGJlIHRydWUuIElmIHRoZSBkZXN0aW5hdGlvbiBpcyBvdXRzaWRlIHRoZVxuICAgKiBNZXRhbm9kZSwgdGhlbiBpdHMgaW5ib3VuZCBwcm9wZXJ0eSBzaG91bGQgYmUgZmFsc2UuXG4gICAqXG4gICAqIFRoZSBwcm9wZXJ0eSBpcyBvcHRpb25hbCBiZWNhdXNlIG5vdCBhbGwgZWRnZXMgY2FuIGJlIGRlc2NyaWJlZCBhc1xuICAgKiBpbmJvdW5kL291dGJvdW5kLiBGb3IgZXhhbXBsZSwgaW4gYSBNZXRhbm9kZSdzIG1ldGFncmFwaCwgYWxsIG9mIHRoZSBlZGdlc1xuICAgKiBjb25uZWN0IGltbWVkaWF0ZSBjaGlsZHJlbiBvZiB0aGUgTWV0YW5vZGUuIE5vbmUgc2hvdWxkIGhhdmUgYW4gaW5ib3VuZFxuICAgKiBwcm9wZXJ0eSwgb3IgdGhleSBzaG91bGQgYmUgbnVsbC91bmRlZmluZWQuXG4gICAqL1xuICBpbmJvdW5kPzogYm9vbGVhbjtcblxuICAvKipcbiAgICogTnVtYmVyIG9mIHJlZ3VsYXIgZWRnZXMgKG5vdCBjb250cm9sIGRlcGVuZGVuY3kgZWRnZXMpLlxuICAgKi9cbiAgbnVtUmVndWxhckVkZ2VzOiBudW1iZXI7XG5cbiAgLyoqXG4gICAqIE51bWJlciBvZiBjb250cm9sIGRlcGVuZGVuY3kgZWRnZXMuXG4gICAqL1xuICBudW1Db250cm9sRWRnZXM6IG51bWJlcjtcblxuICAvKipcbiAgICogTnVtYmVyIG9mIHJlZmVyZW5jZSBlZGdlcywgd2hpY2ggaXMgYW4gZWRnZSB0byBhbiBvcGVyYXRpb25cbiAgICogdGhhdCB0YWtlcyBhIHJlZmVyZW5jZSB0byBpdHMgaW5wdXQgYW5kIGNoYW5nZXMgaXRzIHZhbHVlLlxuICAgKi9cbiAgbnVtUmVmRWRnZXM6IG51bWJlcjtcblxuICAvKipcbiAgICogVG90YWwgc2l6ZSAobnVtYmVyIG9mIHVuaXRzKSBvZiBhbGwgdGhlIHRlbnNvcnMgZmxvd2luZyB0aHJvdWdoIHRoaXMgZWRnZS5cbiAgICovXG4gIHRvdGFsU2l6ZTogbnVtYmVyO1xuXG4gIGFkZEJhc2VFZGdlKGVkZ2U6IEJhc2VFZGdlLCBoOiBoaWVyYXJjaHkuSGllcmFyY2h5KTogdm9pZDtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGNyZWF0ZU1ldGFlZGdlKHY6IHN0cmluZywgdzogc3RyaW5nKTogTWV0YWVkZ2Uge1xuICByZXR1cm4gbmV3IE1ldGFlZGdlSW1wbCh2LCB3KTtcbn1cblxuLyoqXG4gKiBBIGxhYmVsIG9iamVjdCBmb3IgZWRnZXMgYmV0d2VlbiBtZXRhbm9kZXMgb2Ygc3ViZ3JhcGhzIGluIHRoZSByZW5kZXIgZ3JhcGguXG4gKi9cbmV4cG9ydCBjbGFzcyBNZXRhZWRnZUltcGwgaW1wbGVtZW50cyBNZXRhZWRnZSB7XG4gIHY6IHN0cmluZztcbiAgdzogc3RyaW5nO1xuICBiYXNlRWRnZUxpc3Q6IEJhc2VFZGdlW107XG4gIGluYm91bmQ6IGJvb2xlYW47XG4gIG51bVJlZ3VsYXJFZGdlczogbnVtYmVyO1xuICBudW1Db250cm9sRWRnZXM6IG51bWJlcjtcbiAgbnVtUmVmRWRnZXM6IG51bWJlcjtcbiAgdG90YWxTaXplOiBudW1iZXI7XG5cbiAgY29uc3RydWN0b3Iodjogc3RyaW5nLCB3OiBzdHJpbmcpIHtcbiAgICB0aGlzLnYgPSB2O1xuICAgIHRoaXMudyA9IHc7XG4gICAgdGhpcy5iYXNlRWRnZUxpc3QgPSBbXTtcbiAgICB0aGlzLmluYm91bmQgPSBudWxsO1xuICAgIHRoaXMubnVtUmVndWxhckVkZ2VzID0gMDtcbiAgICB0aGlzLm51bUNvbnRyb2xFZGdlcyA9IDA7XG4gICAgdGhpcy5udW1SZWZFZGdlcyA9IDA7XG4gICAgdGhpcy50b3RhbFNpemUgPSAwO1xuICB9XG5cbiAgYWRkQmFzZUVkZ2UoZWRnZTogQmFzZUVkZ2UsIGg6IGhpZXJhcmNoeS5IaWVyYXJjaHkpOiB2b2lkIHtcbiAgICB0aGlzLmJhc2VFZGdlTGlzdC5wdXNoKGVkZ2UpO1xuICAgIGlmIChlZGdlLmlzQ29udHJvbERlcGVuZGVuY3kpIHtcbiAgICAgIHRoaXMubnVtQ29udHJvbEVkZ2VzICs9IDE7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMubnVtUmVndWxhckVkZ2VzICs9IDE7XG4gICAgfVxuICAgIGlmIChlZGdlLmlzUmVmZXJlbmNlRWRnZSkge1xuICAgICAgdGhpcy5udW1SZWZFZGdlcyArPSAxO1xuICAgIH1cbiAgICAvLyBDb21wdXRlIHRoZSBzaXplIG9mIHRoZSB0ZW5zb3IgZmxvd2luZyB0aHJvdWdoIHRoaXNcbiAgICAvLyBiYXNlIGVkZ2UuXG4gICAgdGhpcy50b3RhbFNpemUgKz0gTWV0YWVkZ2VJbXBsLmNvbXB1dGVTaXplT2ZFZGdlKGVkZ2UsIGgpO1xuICAgIGgubWF4TWV0YUVkZ2VTaXplID0gTWF0aC5tYXgoaC5tYXhNZXRhRWRnZVNpemUsIHRoaXMudG90YWxTaXplKTtcbiAgfVxuXG4gIHByaXZhdGUgc3RhdGljIGNvbXB1dGVTaXplT2ZFZGdlKGVkZ2U6IEJhc2VFZGdlLCBoOiBoaWVyYXJjaHkuSGllcmFyY2h5KTpcbiAgICAgIG51bWJlciB7XG4gICAgbGV0IG9wTm9kZSA9IDxPcE5vZGU+IGgubm9kZShlZGdlLnYpO1xuICAgIGlmICghb3BOb2RlLm91dHB1dFNoYXBlcykge1xuICAgICAgLy8gTm8gc2hhcGUgaW5mb3JtYXRpb24uIEFzc3N1bWUgYSBzaW5nbGUgbnVtYmVyLiBUaGlzIGdpdmVzXG4gICAgICAvLyBhIGxvd2VyIGJvdW5kIGZvciB0aGUgdG90YWwgc2l6ZS5cbiAgICAgIHJldHVybiAxO1xuICAgIH1cbiAgICBoLmhhc1NoYXBlSW5mbyA9IHRydWU7XG5cbiAgICAvLyBTdW0gdGhlIHNpemVzIG9mIGFsbCBvdXRwdXQgdGVuc29ycy5cbiAgICByZXR1cm4gXyhvcE5vZGUub3V0cHV0U2hhcGVzKS5tYXBWYWx1ZXMoKHNoYXBlOiBudW1iZXJbXSkgPT4ge1xuICAgICAgLy8gSWYgdGhlIHNoYXBlIGlzIHVua25vd24sIHRyZWF0IGl0IGFzIDEgd2hlbiBjb21wdXRpbmdcbiAgICAgIC8vIHRvdGFsIHNpemUuIFRoaXMgZ2l2ZXMgYSBsb3dlciBib3VuZCBmb3IgdGhlIHRvdGFsIHNpemUuXG4gICAgICBpZiAoc2hhcGUgPT0gbnVsbCkge1xuICAgICAgICByZXR1cm4gMTtcbiAgICAgIH1cbiAgICAgIC8vIE11bHRpcGx5IGFsbCBzaGFwZXMgdG8gZ2V0IHRoZSB0b3RhbCBzaXplIG9mIHRoZSB0ZW5zb3IuXG4gICAgICAvLyBFLmcuIFRoZSB0b3RhbCBzaXplIG9mIFs0LCAyLCAxXSBpcyA0ICogMiAqIDEuXG4gICAgICByZXR1cm4gXyhzaGFwZSkucmVkdWNlKChhY2N1bXVsYXRlZCwgY3VyclNpemUpID0+IHtcbiAgICAgICAgLy8gSWYgdGhpcyBwYXJ0aWN1bGFyIGRpbWVuc2lvbiBpcyB1bmtub3duLCB0cmVhdFxuICAgICAgICAvLyBpdCBhcyAxIHdoZW4gY29tcHV0aW5nIHRvdGFsIHNpemUuIFRoaXMgZ2l2ZXMgYSBsb3dlciBib3VuZFxuICAgICAgICAvLyBmb3IgdGhlIHRvdGFsIHNpemUuXG4gICAgICAgIGlmIChjdXJyU2l6ZSA9PT0gLTEpIHtcbiAgICAgICAgICBjdXJyU2l6ZSA9IDE7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGFjY3VtdWxhdGVkICogY3VyclNpemU7XG4gICAgICB9LCAxKTtcbiAgICB9KS5zdW0oKTtcbiAgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlU2VyaWVzTm9kZShcbiAgICBwcmVmaXg6IHN0cmluZyxcbiAgICBzdWZmaXg6IHN0cmluZyxcbiAgICBwYXJlbnQ6IHN0cmluZyxcbiAgICBjbHVzdGVySWQ6IG51bWJlcixcbiAgICBuYW1lOiBzdHJpbmcsXG4gICAgZ3JhcGhPcHRpb25zOiBncmFwaGxpYi5HcmFwaE9wdGlvbnMpOiBTZXJpZXNOb2RlIHtcbiAgcmV0dXJuIG5ldyBTZXJpZXNOb2RlSW1wbChcbiAgICAgIHByZWZpeCwgc3VmZml4LCBwYXJlbnQsIGNsdXN0ZXJJZCwgbmFtZSwgZ3JhcGhPcHRpb25zKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGdldFNlcmllc05vZGVOYW1lKHByZWZpeDogc3RyaW5nLCBzdWZmaXg6IHN0cmluZyxcbiAgICBwYXJlbnQ6IHN0cmluZywgc3RhcnRJZD86IG51bWJlciwgZW5kSWQ/OiBudW1iZXIpOiBzdHJpbmcge1xuICBsZXQgbnVtUmVwcmVzZW50YXRpb24gPVxuICAgICAgKHR5cGVvZiBzdGFydElkICE9PSAndW5kZWZpbmVkJyAmJiB0eXBlb2YgZW5kSWQgIT09ICd1bmRlZmluZWQnKSA/XG4gICAgICAnWycgKyBzdGFydElkICsgJy0nICsgZW5kSWQgKyAnXScgOlxuICAgICAgJyMnO1xuICBsZXQgcGF0dGVybiA9IHByZWZpeCArIG51bVJlcHJlc2VudGF0aW9uICsgc3VmZml4O1xuICByZXR1cm4gKHBhcmVudCA/IHBhcmVudCArICcvJyA6ICcnKSArIHBhdHRlcm47XG59XG5cbmNsYXNzIFNlcmllc05vZGVJbXBsIGltcGxlbWVudHMgU2VyaWVzTm9kZSB7XG4gIG5hbWU6IHN0cmluZztcbiAgdHlwZTogTm9kZVR5cGU7XG4gIHN0YXRzOiBOb2RlU3RhdHM7XG4gIGhhc0xvb3A6IGJvb2xlYW47XG4gIHByZWZpeDogc3RyaW5nO1xuICBzdWZmaXg6IHN0cmluZztcbiAgY2x1c3RlcklkOiBudW1iZXI7XG4gIGlkczogbnVtYmVyW107XG4gIHBhcmVudDogc3RyaW5nO1xuICBpc0dyb3VwTm9kZTogYm9vbGVhbjtcbiAgY2FyZGluYWxpdHk6IG51bWJlcjtcbiAgbWV0YWdyYXBoOiBncmFwaGxpYi5HcmFwaDxHcm91cE5vZGV8T3BOb2RlLCBNZXRhZWRnZT47XG4gIGJyaWRnZWdyYXBoOiBncmFwaGxpYi5HcmFwaDxHcm91cE5vZGV8T3BOb2RlLCBNZXRhZWRnZT47XG4gIHBhcmVudE5vZGU6IE5vZGU7XG4gIGRldmljZUhpc3RvZ3JhbToge1tvcDogc3RyaW5nXTogbnVtYmVyfTtcbiAgeGxhQ2x1c3Rlckhpc3RvZ3JhbToge1tvcDogc3RyaW5nXTogbnVtYmVyfTtcbiAgY29tcGF0aWJpbGl0eUhpc3RvZ3JhbToge2NvbXBhdGlibGU6IG51bWJlciwgaW5jb21wYXRpYmxlOiBudW1iZXJ9O1xuICBoYXNOb25Db250cm9sRWRnZXM6IGJvb2xlYW47XG4gIGluY2x1ZGU6IEluY2x1c2lvblR5cGU7XG4gIG5vZGVBdHRyaWJ1dGVzOiB7W2tleTogc3RyaW5nXTogYW55O307XG5cbiAgY29uc3RydWN0b3IoXG4gICAgICBwcmVmaXg6IHN0cmluZyxcbiAgICAgIHN1ZmZpeDogc3RyaW5nLFxuICAgICAgcGFyZW50OiBzdHJpbmcsXG4gICAgICBjbHVzdGVySWQ6IG51bWJlcixcbiAgICAgIG5hbWU6IHN0cmluZyxcbiAgICAgIGdyYXBoT3B0aW9uczogZ3JhcGhsaWIuR3JhcGhPcHRpb25zKSB7XG4gICAgdGhpcy5uYW1lID0gbmFtZSB8fCBnZXRTZXJpZXNOb2RlTmFtZShwcmVmaXgsIHN1ZmZpeCwgcGFyZW50KTtcbiAgICB0aGlzLnR5cGUgPSBOb2RlVHlwZS5TRVJJRVM7XG4gICAgdGhpcy5oYXNMb29wID0gZmFsc2U7XG4gICAgdGhpcy5wcmVmaXggPSBwcmVmaXg7XG4gICAgdGhpcy5zdWZmaXggPSBzdWZmaXg7XG4gICAgdGhpcy5jbHVzdGVySWQgPSBjbHVzdGVySWQ7XG4gICAgdGhpcy5pZHMgPSBbXTtcbiAgICB0aGlzLnBhcmVudCA9IHBhcmVudDtcbiAgICB0aGlzLmlzR3JvdXBOb2RlID0gdHJ1ZTtcbiAgICB0aGlzLmNhcmRpbmFsaXR5ID0gMDtcbiAgICB0aGlzLm1ldGFncmFwaCA9IGNyZWF0ZUdyYXBoPE1ldGFub2RlLCBNZXRhZWRnZT4oXG4gICAgICAgIG5hbWUsIEdyYXBoVHlwZS5TRVJJRVMsIGdyYXBoT3B0aW9ucyk7XG4gICAgLy8gYnJpZGdlZ3JhcGggbXVzdCBiZSBjb25zdHJ1Y3RlZCBsYXppbHktc2VlIGhpZXJhcmNoeS5nZXRCcmlkZ2VncmFwaCgpXG4gICAgdGhpcy5icmlkZ2VncmFwaCA9IG51bGw7XG4gICAgdGhpcy5wYXJlbnROb2RlID0gbnVsbDtcbiAgICB0aGlzLmRldmljZUhpc3RvZ3JhbSA9IHt9O1xuICAgIHRoaXMueGxhQ2x1c3Rlckhpc3RvZ3JhbSA9IHt9O1xuICAgIHRoaXMuY29tcGF0aWJpbGl0eUhpc3RvZ3JhbSA9IHtjb21wYXRpYmxlOiAwLCBpbmNvbXBhdGlibGU6IDB9O1xuICAgIHRoaXMuaGFzTm9uQ29udHJvbEVkZ2VzID0gZmFsc2U7XG4gICAgdGhpcy5pbmNsdWRlID0gSW5jbHVzaW9uVHlwZS5VTlNQRUNJRklFRDtcbiAgfVxufVxuXG4vKipcbiAqIEV4dHJhY3RzIHRoZSBzaGFwZXMgb2YgdGhlIG91dHB1dCB0ZW5zb3JzIGZyb20gdGhlIGF0dHIgcHJvcGVydHkgaW4gdGhlXG4gKiBub2RlIHByb3RvLlxuICovXG4vLyB0c2xpbnQ6ZGlzYWJsZS1uZXh0LWxpbmU6bm8tYW55XG5mdW5jdGlvbiBleHRyYWN0T3V0cHV0U2hhcGVzKGF0dHI6IEFycmF5PHtrZXk6IHN0cmluZywgdmFsdWU6IGFueX0+KTpcbiAgICB7W2tleTogc3RyaW5nXTogVGVuc29yU2hhcGU7fSB7XG4gIGxldCByZXN1bHQgPSBudWxsO1xuICAvLyBXZSBkb24ndCBrbm93IGFueXRoaW5nIGFib3V0IHRoZSBvdXRwdXQgdGVuc29ycy5cbiAgaWYgKCFhdHRyKSB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBhdHRyLmxlbmd0aDsgaSsrKSB7XG4gICAgbGV0IHtrZXksIHZhbHVlfSA9IGF0dHJbaV07XG4gICAgaWYgKGtleSA9PT0gT1VUUFVUX1NIQVBFU19LRVkpIHtcbiAgICAgIGlmICghdmFsdWUubGlzdC5zaGFwZSkge1xuICAgICAgICAvLyBUaGUgT1VUUFVUX1NIQVBFU19LRVkgbGFja3MgYSB2YWx1ZS4gV2Uga25vdyBub3RoaW5nIGFib3V0IHRoZSBzaGFwZS5cbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICB9XG5cbiAgICAgIC8vIE1hcCBhbGwgb3V0cHV0IHRlbnNvcnMgaW50byBhcnJheSBvZiBudW1iZXJzIGRlbm90aW5nIHRoZWlyIHNoYXBlLlxuICAgICAgbGV0IHJlc3VsdCA9IHZhbHVlLmxpc3Quc2hhcGUubWFwKHNoYXBlID0+IHtcbiAgICAgICAgaWYgKHNoYXBlLnVua25vd25fcmFuaykge1xuICAgICAgICAgIC8vIFRoaXMgb3V0cHV0IHRlbnNvciBpcyBvZiB1bmtub3duIHJhbmsuIFdlIGRvbid0IGtub3cgaWYgaXQgaXMgYVxuICAgICAgICAgIC8vIHNjYWxhciwgb3IgYSB0ZW5zb3IsIG9yIG9mIHdoYXQgc2hhcGUgaXQgaXMuXG4gICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHNoYXBlLmRpbSA9PSBudWxsIHx8XG4gICAgICAgICAgICAoc2hhcGUuZGltLmxlbmd0aCA9PT0gMSAmJiBzaGFwZS5kaW1bMF0uc2l6ZSA9PSBudWxsKSkge1xuICAgICAgICAgIC8vIFRoaXMgb3V0cHV0IHRlbnNvciBpcyBhIHNjYWxhci5cbiAgICAgICAgICByZXR1cm4gW107XG4gICAgICAgIH1cbiAgICAgICAgLy8gVGhpcyBvdXRwdXQgdGVuc29yIGhhcyBhIGtub3duIHJhbmsuIE1hcCBlYWNoIGRpbWVuc2lvbiBzaXplXG4gICAgICAgIC8vIGludG8gYSBudW1iZXIuXG4gICAgICAgIHJldHVybiBzaGFwZS5kaW0ubWFwKGRpbSA9PiB7XG4gICAgICAgICAgLy8gU2l6ZSBjYW4gYmUgLTEgaWYgdGhpcyBwYXJ0aWN1bGFyIGRpbWVuc2lvbiBpcyB1bmtub3duLlxuICAgICAgICAgIHJldHVybiBkaW0uc2l6ZTtcbiAgICAgICAgfSk7XG4gICAgICB9KTtcbiAgICAgIC8vIFNpbmNlIHdlIGFscmVhZHkgcHJvY2Vzc2VkIGl0LCByZW1vdmUgdGhlIGVudHJ5IGZyb20gdGhlIGF0dHJpYnV0ZVxuICAgICAgLy8gbGlzdCAoc2F2ZXMgbWVtb3J5KS5cbiAgICAgIGF0dHIuc3BsaWNlKGksIDEpO1xuICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9XG4gIH1cbiAgLy8gV2UgZGlkbid0IGZpbmQgT1VUUFVUX1NIQVBFU19LRVkgaW4gYXR0cmlidXRlcywgc28gd2UgZG9uJ3Qga25vdyBhbnl0aGluZ1xuICAvLyBhYm91dCB0aGUgb3V0cHV0IHRlbnNvcnMuXG4gIHJldHVybiBudWxsO1xufVxuXG4vKipcbiAqIEV4dHJhY3RzIHRoZSBYTEEgQ2x1c3RlciB0aGF0IGFuIG9wIHJ1bnMgb24gZnJvbSB0aGUgYXR0cnMgb2YgdGhlIE9wTm9kZS5cbiAqIEBwYXJhbSBhdHRyIFRoZSBhdHRyIHByb3BlcnR5LlxuICogQHJldHVybiBBIHN0cmluZyB0aGF0IGlzIHRoZSBuYW1lIG9mIHRoZSBjbHVzdGVyLiBPciBudWxsIGlmIGl0IGNvdWxkIG5vdCBiZVxuICogICAgIGRldGVybWluZWQuXG4gKi9cbi8vIHRzbGludDpkaXNhYmxlLW5leHQtbGluZTpuby1hbnlcbmZ1bmN0aW9uIGV4dHJhY3RYbGFDbHVzdGVyKGF0dHI6IEFycmF5PHtrZXk6IHN0cmluZywgdmFsdWU6IGFueX0+KTogc3RyaW5nfFxuICAgIG51bGwge1xuICBpZiAoIWF0dHIpIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuXG4gIC8vIEZpbmQgdGhlIGF0dHJpYnV0ZSBmb3IgWExBIGNsdXN0ZXIgaWYgdGhlcmUgaXMgb25lLlxuICBmb3IgKGxldCBpID0gMDsgaSA8IGF0dHIubGVuZ3RoOyBpKyspIHtcbiAgICBpZiAoYXR0cltpXS5rZXkgPT09IF9YTEFfQ0xVU1RFUl9LRVkpIHtcbiAgICAgIHJldHVybiBhdHRyW2ldLnZhbHVlWydzJ10gfHwgbnVsbDtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIG51bGw7XG59XG5cbi8qKlxuICogTm9ybWFsaXplcyB0aGUgaW5wdXRzIGFuZCBleHRyYWN0cyBhc3NvY2lhdGVkIG1ldGFkYXRhOlxuICogMSkgSW5wdXRzIGNhbiBjb250YWluIGEgY29sb24gZm9sbG93ZWQgYnkgYSBzdWZmaXggb2YgY2hhcmFjdGVycy5cbiAqICAgIFRoYXQgc3VmZml4IG1heSBiZSBhIHNpbmdsZSBudW1iZXIgKGUuZy4gaW5wdXROYW1lOjEpIG9yIHNldmVyYWwgd29yZFxuICogICAgY2hhcmFjdGVycyBzZXBhcmF0ZWQgZnJvbSBhIG51bWJlciBieSBhIGNvbG9uIChlLmcuIGlucHV0TmFtZTpmb286MSkuIFRoZVxuICogICAgbGF0dGVyIGNhc2UgaXMgdXNlZCB0byBkZW5vdGUgaW5wdXRzIGFuZCBvdXRwdXRzIG9mIGZ1bmN0aW9ucy5cbiAqIDIpIENvbnRyb2wgZGVwZW5kZW5jeSBpbnB1dHMgY29udGFpbiBjYXJldCBhdCB0aGUgYmVnaW5uaW5nIGFuZCB3ZVxuICogICAgcmVtb3ZlIHRoaXMgYW5kIGFubm90YXRlIHRoZSBlZGdlIGFzIGEgY29udHJvbCBkZXBlbmRlbmN5LlxuICogQHBhcmFtIGlucHV0cyBBcnJheSBvZiB1bm5vcm1hbGl6ZWQgbmFtZXMgb2YgaW5wdXQgbm9kZXMuXG4gKi9cbmZ1bmN0aW9uIG5vcm1hbGl6ZUlucHV0cyhpbnB1dHM6IHN0cmluZ1tdKTogTm9ybWFsaXplZElucHV0W10ge1xuICBsZXQgbm9ybWFsaXplZElucHV0czogTm9ybWFsaXplZElucHV0W10gPSBbXTtcbiAgXy5lYWNoKGlucHV0cywgaW5wdXROYW1lID0+IHtcbiAgICBsZXQgaXNDb250cm9sRGVwZW5kZW5jeSA9IGlucHV0TmFtZVswXSA9PT0gJ14nO1xuICAgIGlmIChpc0NvbnRyb2xEZXBlbmRlbmN5KSB7XG4gICAgICAvLyBUaGUgY2FyYXQgbWVyZWx5IGluZGljYXRlcyB3aGV0aGVyIHRoaXMgaW5wdXQgaXMgYSBjb250cm9sIGRlcGVuZGVuY3kuXG4gICAgICAvLyBJdCBzaG91bGQgbm90IGJlIHBhcnQgb2YgdGhlIG5hbWUuXG4gICAgICBpbnB1dE5hbWUgPSBpbnB1dE5hbWUuc3Vic3RyaW5nKDEpO1xuICAgIH1cblxuICAgIGxldCBuYW1lID0gaW5wdXROYW1lO1xuICAgIGxldCBvdXRwdXRUZW5zb3JLZXkgPSAnMCc7XG5cbiAgICBsZXQgbWF0Y2ggPSBpbnB1dE5hbWUubWF0Y2goLyguKik6KFxcdys6XFxkKykkLyk7XG4gICAgaWYgKG1hdGNoKSB7XG4gICAgICAvLyBUaGUgb3V0cHV0IHN0cmluZyBjb25zaXN0cyBvZiBzZXZlcmFsIGNoYXJhY3RlcnMgYW5kIGEgbnVtYmVyIHNlcGFyYXRlZFxuICAgICAgLy8gYnkgYSBjb2xvbi5cbiAgICAgIG5hbWUgPSBtYXRjaFsxXTtcbiAgICAgIG91dHB1dFRlbnNvcktleSA9IG1hdGNoWzJdO1xuICAgIH0gZWxzZSB7XG4gICAgICBtYXRjaCA9IGlucHV0TmFtZS5tYXRjaCgvKC4qKTooXFxkKykkLyk7XG4gICAgICBpZiAobWF0Y2gpIHtcbiAgICAgICAgLy8gVGhlIG91dHB1dCBzdHJpbmcgY29uc2lzdHMgb2YgYSBzaW5nbGUgbnVtYmVyLlxuICAgICAgICBuYW1lID0gbWF0Y2hbMV07XG4gICAgICAgIG91dHB1dFRlbnNvcktleSA9IG1hdGNoWzJdO1xuICAgICAgfVxuICAgIH1cblxuICAgIGlmIChub3JtYWxpemVkSW5wdXRzLmxlbmd0aCA9PT0gMCB8fFxuICAgICAgbmFtZSAhPT0gbm9ybWFsaXplZElucHV0c1tub3JtYWxpemVkSW5wdXRzLmxlbmd0aCAtIDFdLm5hbWUpIHtcbiAgICAgIG5vcm1hbGl6ZWRJbnB1dHMucHVzaCh7XG4gICAgICAgIG5hbWU6IG5hbWUsXG4gICAgICAgIG91dHB1dFRlbnNvcktleTogb3V0cHV0VGVuc29yS2V5LFxuICAgICAgICBpc0NvbnRyb2xEZXBlbmRlbmN5OiBpc0NvbnRyb2xEZXBlbmRlbmN5LFxuICAgICAgfSk7XG4gICAgfVxuICB9KTtcbiAgcmV0dXJuIG5vcm1hbGl6ZWRJbnB1dHM7XG59XG5cbmZ1bmN0aW9uIGFkZEVkZ2VUb0dyYXBoKFxuICAgIGdyYXBoOiBTbGltR3JhcGgsIGlucHV0TmFtZTogc3RyaW5nLCBvdXRwdXROb2RlOiBPcE5vZGUsXG4gICAgaW5wdXQ6IE5vcm1hbGl6ZWRJbnB1dCwgcGFyYW1zOiBCdWlsZFBhcmFtcywgaW5kZXg6IG51bWJlcikge1xuICAvLyBEb24ndCBhbGxvdyBsb29wcyBpbiB0aGUgZ3JhcGguXG4gIGlmIChpbnB1dE5hbWUgPT09IG91dHB1dE5vZGUubmFtZSkge1xuICAgIHJldHVybjtcbiAgfVxuICAvLyBDaGVjayBpZiB0aGlzIG9wIHR5cGUgYW5kIGlucHV0IG51bWJlciBjb3JyZXNwb25kcyB0byBhXG4gIC8vIHJlZmVyZW5jZSBlZGdlIHVzaW5nIHRoZSByZWZFZGdlcyBkaWN0aW9uYXJ5IGluIHRoZSBwYXJhbXMuXG4gIGxldCBpc1JlZkVkZ2UgPSBwYXJhbXMucmVmRWRnZXNbb3V0cHV0Tm9kZS5vcCArICcgJyArIGluZGV4XSA9PT0gdHJ1ZTtcbiAgZ3JhcGguZWRnZXMucHVzaCh7XG4gICAgdjogaW5wdXROYW1lLFxuICAgIHc6IG91dHB1dE5vZGUubmFtZSxcbiAgICBvdXRwdXRUZW5zb3JLZXk6IGlucHV0Lm91dHB1dFRlbnNvcktleSxcbiAgICBpc0NvbnRyb2xEZXBlbmRlbmN5OiBpbnB1dC5pc0NvbnRyb2xEZXBlbmRlbmN5LFxuICAgIGlzUmVmZXJlbmNlRWRnZTogaXNSZWZFZGdlXG4gIH0pO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gYnVpbGQoXG4gICAgZ3JhcGhEZWY6IHRmLmdyYXBoLnByb3RvLkdyYXBoRGVmLCBwYXJhbXM6IEJ1aWxkUGFyYW1zLFxuICAgIHRyYWNrZXI6IFByb2dyZXNzVHJhY2tlcik6IFByb21pc2U8U2xpbUdyYXBofHZvaWQ+IHtcbiAgLyoqXG4gICAqIEEgZGljdGlvbmFyeSB0aGF0IG1hcHMgZWFjaCBpbi1lbWJlZGRpbmcgbm9kZSBuYW1lIHRvIHRoZSBub2RlXG4gICAqIG9iamVjdC5cbiAgICovXG4gIGxldCBpbkVtYmVkZGluZzoge1tub2RlTmFtZTogc3RyaW5nXTogT3BOb2RlfSA9IHt9O1xuICAvKipcbiAgICogQSBkaWN0aW9uYXJ5IHRoYXQgbWFwcyBlYWNoIG91dC1lbWJlZGRpbmcgbm9kZSBuYW1lIHRvIHRoZSBub2RlXG4gICAqIG9iamVjdC5cbiAgICovXG4gIGxldCBvdXRFbWJlZGRpbmc6IHtbbm9kZU5hbWU6IHN0cmluZ106IE9wTm9kZX0gPSB7fTtcbiAgLyoqXG4gICAqIEEgZGljdGlvbmFyeSB0aGF0IG1hcHMgZWFjaCBub2RlIG5hbWUgdG8gYW4gYXJyYXkgb2YgdGhlIG5vZGUnc1xuICAgKiBvdXQtZW1iZWRkaW5nIG5vZGUgbGFiZWwgb2JqZWN0cy5cbiAgICovXG4gIGxldCBvdXRFbWJlZGRpbmdzOiB7W2lucHV0TmFtZTogc3RyaW5nXTogT3BOb2RlW119ID0ge307XG4gIGxldCBpc0luRW1iZWRkZWRQcmVkID0gZ2V0RW1iZWRQcmVkaWNhdGUocGFyYW1zLmluRW1iZWRkaW5nVHlwZXMpO1xuICBsZXQgaXNPdXRFbWJlZGRlZFByZWQgPSBnZXRFbWJlZFByZWRpY2F0ZShwYXJhbXMub3V0RW1iZWRkaW5nVHlwZXMpO1xuICBsZXQgZW1iZWRkaW5nTm9kZU5hbWVzOiBzdHJpbmdbXSA9IFtdO1xuICBsZXQgcmF3Tm9kZXMgPSBncmFwaERlZi5ub2RlO1xuICAvKipcbiAgICogQSBsaXN0IG9mIGFsbCB0aGUgbm9uLWVtYmVkZGluZyBub2RlIG5hbWVzIHdoaWNoIGFwcGVhciBpbiB0aGUgcHJvY2Vzc2VkXG4gICAqIGxpc3Qgb2YgcmF3IG5vZGVzLiBIZXJlIHdlIHByZS1hbGxvY2F0ZSBlbm91Z2ggcm9vbSBmb3IgYWxsIHRoZSByYXdOb2RlcyxcbiAgICogZXZlbiB0aG91Z2ggdGhlcmUgd2lsbCBzb21lIG51bWJlciBvZiBlbWJlZGRpbmdzLiBUaGUgZXhjZXNzIGFycmF5IGxlbmd0aFxuICAgKiBpcyBzcGxpY2VkIG9mZiBsYXRlci5cbiAgICpcbiAgICogRXhwZXJpbWVudGF0aW9uIHNob3dzIHRoYXQgYXJvdW5kIDMwJSBvZiB0aGUgYXJyYXkgd2lsbCBnbyB1bnVzZWQsIGFuZFxuICAgKiBldmVuIGZvciB2ZXJ5IGxhcmdlIG5ldHdvcmtzIHRoYXQgYW1vdW50cyB0byBsZXNzIHRoYW4gMTBrIHNwYWNlcy5cbiAgICovXG4gIGxldCBub2RlTmFtZXMgPSBuZXcgQXJyYXk8c3RyaW5nPihyYXdOb2Rlcy5sZW5ndGgpO1xuXG4gIHJldHVybiB0Zi5ncmFwaC51dGlsXG4gICAgICAucnVuQXN5bmNUYXNrKFxuICAgICAgICAgICdOb3JtYWxpemluZyBuYW1lcycsIDMwLFxuICAgICAgICAgICgpID0+IHtcbiAgICAgICAgICAgIGxldCBvcE5vZGVzID0gbmV3IEFycmF5PE9wTm9kZT4ocmF3Tm9kZXMubGVuZ3RoKTtcbiAgICAgICAgICAgIGxldCBpbmRleCA9IDA7XG5cbiAgICAgICAgICAgIGNvbnN0IHByb2Nlc3NSYXdOb2RlID0gcmF3Tm9kZSA9PiB7XG4gICAgICAgICAgICAgIGxldCBvcE5vZGUgPSBuZXcgT3BOb2RlSW1wbChyYXdOb2RlKTtcbiAgICAgICAgICAgICAgaWYgKGlzSW5FbWJlZGRlZFByZWQob3BOb2RlKSkge1xuICAgICAgICAgICAgICAgIGVtYmVkZGluZ05vZGVOYW1lcy5wdXNoKG9wTm9kZS5uYW1lKTtcbiAgICAgICAgICAgICAgICBpbkVtYmVkZGluZ1tvcE5vZGUubmFtZV0gPSBvcE5vZGU7XG4gICAgICAgICAgICAgICAgcmV0dXJuIG9wTm9kZTtcbiAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgIGlmIChpc091dEVtYmVkZGVkUHJlZChvcE5vZGUpKSB7XG4gICAgICAgICAgICAgICAgZW1iZWRkaW5nTm9kZU5hbWVzLnB1c2gob3BOb2RlLm5hbWUpO1xuICAgICAgICAgICAgICAgIG91dEVtYmVkZGluZ1tvcE5vZGUubmFtZV0gPSBvcE5vZGU7XG4gICAgICAgICAgICAgICAgXy5lYWNoKG9wTm9kZS5pbnB1dHMsIGlucHV0ID0+IHtcbiAgICAgICAgICAgICAgICAgIGxldCBpbnB1dE5hbWUgPSBpbnB1dC5uYW1lO1xuICAgICAgICAgICAgICAgICAgb3V0RW1iZWRkaW5nc1tpbnB1dE5hbWVdID0gb3V0RW1iZWRkaW5nc1tpbnB1dE5hbWVdIHx8IFtdO1xuICAgICAgICAgICAgICAgICAgb3V0RW1iZWRkaW5nc1tpbnB1dE5hbWVdLnB1c2gob3BOb2RlKTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICByZXR1cm4gb3BOb2RlO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIC8vIFRoZSBub2RlIGlzIG5vdCBhbiBlbWJlZGRpbmcsIHNvIGFkZCBpdCB0byB0aGUgbmFtZXMgYW5kIG5vZGVzXG4gICAgICAgICAgICAgIC8vIGxpc3RzLlxuICAgICAgICAgICAgICBvcE5vZGVzW2luZGV4XSA9IG9wTm9kZTtcbiAgICAgICAgICAgICAgbm9kZU5hbWVzW2luZGV4XSA9IG9wTm9kZS5uYW1lO1xuICAgICAgICAgICAgICBpbmRleCsrO1xuICAgICAgICAgICAgICByZXR1cm4gb3BOb2RlO1xuICAgICAgICAgICAgfTtcblxuICAgICAgICAgICAgXy5lYWNoKHJhd05vZGVzLCBwcm9jZXNzUmF3Tm9kZSk7XG5cbiAgICAgICAgICAgIGNvbnN0IHByb2Nlc3NGdW5jdGlvbiA9IChmdW5jOiB0Zi5ncmFwaC5wcm90by5GdW5jdGlvbkRlZikgPT4ge1xuICAgICAgICAgICAgICAvLyBHaXZlIHRoZSBmdW5jdGlvbiBpdHNlbGYgYSBub2RlLlxuICAgICAgICAgICAgICBjb25zdCBmdW5jdGlvbk5vZGVOYW1lID1cbiAgICAgICAgICAgICAgICAgIEZVTkNUSU9OX0xJQlJBUllfTk9ERV9QUkVGSVggKyBmdW5jLnNpZ25hdHVyZS5uYW1lO1xuICAgICAgICAgICAgICAvLyBDcmVhdGUgYW4gb3Agbm9kZSBmb3IgdGhlIGZ1bmN0aW9uLiBNYXJrIGl0IGFzIHBhcnQgb2YgYVxuICAgICAgICAgICAgICAvLyBmdW5jdGlvbiBsaWJyYXJ5LlxuICAgICAgICAgICAgICBwcm9jZXNzUmF3Tm9kZSh7XG4gICAgICAgICAgICAgICAgbmFtZTogZnVuY3Rpb25Ob2RlTmFtZSxcbiAgICAgICAgICAgICAgICBpbnB1dDogW10sXG4gICAgICAgICAgICAgICAgZGV2aWNlOiAnJyxcbiAgICAgICAgICAgICAgICBvcDogJycsXG4gICAgICAgICAgICAgICAgYXR0cjogW10sXG4gICAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICAgIC8vIElmIHRoZSBmdW5jdGlvbiBoYXMgaW5wdXRzLCBtYWtlIG5vZGVzIG91dCBvZiB0aGVtLlxuICAgICAgICAgICAgICBpZiAoZnVuYy5zaWduYXR1cmUuaW5wdXRfYXJnKSB7XG4gICAgICAgICAgICAgICAgLy8gTWFrZXMgYW4gT3BOb2RlIG91dCBvZiBlaXRoZXIgYW4gaW5wdXRfYXJnIG9mIGEgbGlicmFyeVxuICAgICAgICAgICAgICAgIC8vIGZ1bmN0aW9uLlxuICAgICAgICAgICAgICAgIGxldCBjdXJyZW50SW5wdXRJbmRleCA9IDA7XG4gICAgICAgICAgICAgICAgY29uc3QgcHJvY2Vzc0lucHV0ID0gKGFyZykgPT4ge1xuICAgICAgICAgICAgICAgICAgY29uc3Qgb3BOb2RlID0gcHJvY2Vzc1Jhd05vZGUoe1xuICAgICAgICAgICAgICAgICAgICBuYW1lOiBmdW5jdGlvbk5vZGVOYW1lICsgTkFNRVNQQUNFX0RFTElNICsgYXJnLm5hbWUsXG4gICAgICAgICAgICAgICAgICAgIGlucHV0OiBbXSxcbiAgICAgICAgICAgICAgICAgICAgZGV2aWNlOiAnJyxcbiAgICAgICAgICAgICAgICAgICAgb3A6ICdpbnB1dF9hcmcnLFxuICAgICAgICAgICAgICAgICAgICBhdHRyOiBbe1xuICAgICAgICAgICAgICAgICAgICAgIGtleTogJ1QnLFxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlOiBhcmcudHlwZSxcbiAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICB9XSxcbiAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgb3BOb2RlLmZ1bmN0aW9uSW5wdXRJbmRleCA9IGN1cnJlbnRJbnB1dEluZGV4O1xuICAgICAgICAgICAgICAgICAgY3VycmVudElucHV0SW5kZXgrKztcbiAgICAgICAgICAgICAgICB9O1xuXG4gICAgICAgICAgICAgICAgLy8gTWFrZSBub2RlcyBmb3IgaW5wdXQgYXJncyBvZiB0aGUgZnVuY3Rpb24uIFVuZm9ydHVuYXRlbHksIHRoZVxuICAgICAgICAgICAgICAgIC8vIHBidHh0IGNvbmZpZ3VyYXRpb24gbGFuZ3VhZ2UgaXMgbm90IHJpY2ggZW5vdWdoIHRvXG4gICAgICAgICAgICAgICAgLy8gZGlmZmVyZW50aWF0ZSBiZXR3ZWVuIGFuIGFycmF5IHdpdGggMSBpdGVtIHZzIDEgb2JqZWN0XG4gICAgICAgICAgICAgICAgLy8gcHJvcGVydHkuXG4gICAgICAgICAgICAgICAgaWYgKGZ1bmMuc2lnbmF0dXJlLmlucHV0X2FyZ1snbmFtZSddKSB7XG4gICAgICAgICAgICAgICAgICAvLyBUaGVyZSBpcyBvbmx5IDEgaW5wdXQgYXJnLlxuICAgICAgICAgICAgICAgICAgcHJvY2Vzc0lucHV0KGZ1bmMuc2lnbmF0dXJlLmlucHV0X2FyZyk7XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgIC8vIFRoZXJlIGFyZSBzZXZlcmFsIGlucHV0IGFyZ3MuXG4gICAgICAgICAgICAgICAgICBfLmVhY2goZnVuYy5zaWduYXR1cmUuaW5wdXRfYXJnLCBwcm9jZXNzSW5wdXQpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgIC8vIE1ha2Ugbm9kZXMgZm9yIG91dHB1dCBhcmdzIG9mIHRoZSBmdW5jdGlvbi4gVHJhY2sgdGhlIG5hbWVzIG9mXG4gICAgICAgICAgICAgIC8vIG91dHB1dCBhcmdzIHdpdGhpbiB0aGUga2V5cyBvZiB0aGlzIG9iamVjdC4gVW5saWtlIHRoZVxuICAgICAgICAgICAgICAvLyBpbnB1dF9hcmdzLCB0aGUgb3V0cHV0X2FyZ3MgYXJlIGFscmVhZHkgZGVmaW5lZCB3aXRoaW4gdGhlXG4gICAgICAgICAgICAgIC8vIG5vZGVfZGVmcyBvZiB0aGUgbGlicmFyeSBmdW5jdGlvbi5cbiAgICAgICAgICAgICAgbGV0IGN1cnJlbnRPdXRwdXRJbmRleCA9IDA7XG4gICAgICAgICAgICAgIGNvbnN0IG91dHB1dEFyZ05hbWVzID0ge307XG5cbiAgICAgICAgICAgICAgLy8gSWYgdGhlIGZ1bmN0aW9uIGhhcyBvdXRwdXRzLCBtYWtlIG5vZGVzIG91dCBvZiB0aGVtLlxuICAgICAgICAgICAgICBpZiAoZnVuYy5zaWduYXR1cmUub3V0cHV0X2FyZykge1xuICAgICAgICAgICAgICAgIGNvbnN0IHByb2Nlc3NPdXRwdXQgPSBhcmcgPT4ge1xuICAgICAgICAgICAgICAgICAgb3V0cHV0QXJnTmFtZXNbXG4gICAgICAgICAgICAgICAgICAgICAgZnVuY3Rpb25Ob2RlTmFtZSArIE5BTUVTUEFDRV9ERUxJTSArIGFyZy5uYW1lXSA9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGN1cnJlbnRPdXRwdXRJbmRleDtcbiAgICAgICAgICAgICAgICAgIGN1cnJlbnRPdXRwdXRJbmRleCsrO1xuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgaWYgKGZ1bmMuc2lnbmF0dXJlLm91dHB1dF9hcmdbJ25hbWUnXSkge1xuICAgICAgICAgICAgICAgICAgLy8gVGhlcmUgaXMgb25seSAxIG91dHB1dCBhcmcuXG4gICAgICAgICAgICAgICAgICBwcm9jZXNzT3V0cHV0KGZ1bmMuc2lnbmF0dXJlLm91dHB1dF9hcmcpO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAvLyBUaGVyZSBhcmUgc2V2ZXJhbCBvdXRwdXQgYXJncy5cbiAgICAgICAgICAgICAgICAgIF8uZWFjaChmdW5jLnNpZ25hdHVyZS5vdXRwdXRfYXJnLCBwcm9jZXNzT3V0cHV0KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICBfLmVhY2goZnVuYy5ub2RlX2RlZiwgcmF3Tm9kZSA9PiB7XG4gICAgICAgICAgICAgICAgLy8gUHJlZml4IHdpdGggdGhlIG5hbWUgb2YgdGhlIGZ1bmN0aW9uIHNvIHRoYXQgdGhlIGdyYXBoXG4gICAgICAgICAgICAgICAgLy8gY29ycmVjdGx5IGNvbXB1dGVzIHRoZSBoaWVyYXJjaHkgKGFuZCBtYWtlcyBtZXRhbm9kZXMpLlxuICAgICAgICAgICAgICAgIHJhd05vZGUubmFtZSA9IGZ1bmN0aW9uTm9kZU5hbWUgKyAnLycgKyByYXdOb2RlLm5hbWU7XG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiByYXdOb2RlLmlucHV0ID09PSAnc3RyaW5nJykge1xuICAgICAgICAgICAgICAgICAgcmF3Tm9kZS5pbnB1dCA9IFtyYXdOb2RlLmlucHV0XTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY29uc3Qgb3BOb2RlID0gcHJvY2Vzc1Jhd05vZGUocmF3Tm9kZSk7XG4gICAgICAgICAgICAgICAgaWYgKF8uaXNOdW1iZXIob3V0cHV0QXJnTmFtZXNbcmF3Tm9kZS5uYW1lXSkpIHtcbiAgICAgICAgICAgICAgICAgIC8vIE1hcmsgdGhlIG5vZGUgYXMgb25lIG9mIHRoZSBvdXRwdXRzIG9mIHRoZSBmdW5jdGlvbi5cbiAgICAgICAgICAgICAgICAgIG9wTm9kZS5mdW5jdGlvbk91dHB1dEluZGV4ID0gb3V0cHV0QXJnTmFtZXNbcmF3Tm9kZS5uYW1lXTtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICBfLmVhY2gob3BOb2RlLmlucHV0cywgbm9ybWFsaXplZElucHV0ID0+IHtcbiAgICAgICAgICAgICAgICAgIG5vcm1hbGl6ZWRJbnB1dC5uYW1lID1cbiAgICAgICAgICAgICAgICAgICAgICBmdW5jdGlvbk5vZGVOYW1lICsgTkFNRVNQQUNFX0RFTElNICsgbm9ybWFsaXplZElucHV0Lm5hbWU7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfTtcblxuICAgICAgICAgICAgaWYgKGdyYXBoRGVmLmxpYnJhcnkgJiYgZ3JhcGhEZWYubGlicmFyeS5mdW5jdGlvbikge1xuICAgICAgICAgICAgICAvLyBUaGlzIGdyYXBoIGNvbnRhaW5zIGZ1bmN0aW9ucy5cbiAgICAgICAgICAgICAgXy5lYWNoKGdyYXBoRGVmLmxpYnJhcnkuZnVuY3Rpb24sIHByb2Nlc3NGdW5jdGlvbik7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIG9wTm9kZXMuc3BsaWNlKGluZGV4KTtcbiAgICAgICAgICAgIG5vZGVOYW1lcy5zcGxpY2UoaW5kZXgpO1xuICAgICAgICAgICAgcmV0dXJuIG9wTm9kZXM7XG4gICAgICAgICAgfSxcbiAgICAgICAgICB0cmFja2VyKVxuICAgICAgLnRoZW4oKG9wTm9kZXMpID0+IHtcbiAgICAgICAgLy8gQ3JlYXRlIHRoZSBncmFwaCBkYXRhIHN0cnVjdHVyZSBmcm9tIHRoZSBncmFwaGxpYiBsaWJyYXJ5LlxuICAgICAgICByZXR1cm4gdGYuZ3JhcGgudXRpbC5ydW5Bc3luY1Rhc2soXG4gICAgICAgICAgICAnQnVpbGRpbmcgdGhlIGRhdGEgc3RydWN0dXJlJywgNzAsICgpID0+IHtcbiAgICAgICAgICAgICAgbGV0IG5vcm1hbGl6ZWROYW1lRGljdCA9XG4gICAgICAgICAgICAgICAgICBtYXBTdHJpY3RIaWVyYXJjaHkobm9kZU5hbWVzLCBlbWJlZGRpbmdOb2RlTmFtZXMpO1xuICAgICAgICAgICAgICBsZXQgZ3JhcGggPSBuZXcgU2xpbUdyYXBoO1xuXG4gICAgICAgICAgICAgIC8vIEFkZCB0aGUgbm9kZXMgdG8gdGhlIGdyYXBoLlxuICAgICAgICAgICAgICBfLmVhY2gob3BOb2Rlcywgb3BOb2RlID0+IHtcbiAgICAgICAgICAgICAgICBsZXQgbm9ybWFsaXplZE5hbWUgPVxuICAgICAgICAgICAgICAgICAgICBub3JtYWxpemVkTmFtZURpY3Rbb3BOb2RlLm5hbWVdIHx8IG9wTm9kZS5uYW1lO1xuICAgICAgICAgICAgICAgIGdyYXBoLm5vZGVzW25vcm1hbGl6ZWROYW1lXSA9IG9wTm9kZTtcbiAgICAgICAgICAgICAgICAvLyBDaGVjayBpZiB0aGUgbm9kZSBoYXMgb3V0LWVtYmVkZGluZ3MuIElmIHllcywgYWRkIHRoZW0gdG8gdGhlXG4gICAgICAgICAgICAgICAgLy8gbm9kZS5cbiAgICAgICAgICAgICAgICBpZiAob3BOb2RlLm5hbWUgaW4gb3V0RW1iZWRkaW5ncykge1xuICAgICAgICAgICAgICAgICAgb3BOb2RlLm91dEVtYmVkZGluZ3MgPSBvdXRFbWJlZGRpbmdzW29wTm9kZS5uYW1lXTtcbiAgICAgICAgICAgICAgICAgIC8vIE5vcm1hbGl6ZSB0aGUgbmFtZXMgb2YgdGhlIG91dC1lbWJlZGRpbmdzLlxuICAgICAgICAgICAgICAgICAgXy5lYWNoKG9wTm9kZS5vdXRFbWJlZGRpbmdzLCBub2RlID0+IHtcbiAgICAgICAgICAgICAgICAgICAgbm9kZS5uYW1lID0gbm9ybWFsaXplZE5hbWVEaWN0W25vZGUubmFtZV0gfHwgbm9kZS5uYW1lO1xuICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIC8vIFVwZGF0ZSB0aGUgbmFtZSBvZiB0aGUgbm9kZS5cbiAgICAgICAgICAgICAgICBvcE5vZGUubmFtZSA9IG5vcm1hbGl6ZWROYW1lO1xuICAgICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgICAvLyBWaXNpdCBlYWNoIG5vZGUncyBpbnB1dHMgdG8gYWRkIHRoZSBlZGdlcyB0byB0aGUgZ3JhcGguIElmIHRoZVxuICAgICAgICAgICAgICAvLyBpbnB1dFxuICAgICAgICAgICAgICAvLyBpcyBhbiBpbi1lbWJlZGRpbmcsIHRoZW4gYWRkIGl0IHRvIHRoZSBub2RlJ3MgaW4tZW1iZWRkaW5nc1xuICAgICAgICAgICAgICAvLyBpbnN0ZWFkLlxuICAgICAgICAgICAgICBfLmVhY2gob3BOb2Rlcywgb3BOb2RlID0+IHtcbiAgICAgICAgICAgICAgICBfLmVhY2gob3BOb2RlLmlucHV0cywgKGlucHV0LCBpKSA9PiB7XG4gICAgICAgICAgICAgICAgICBsZXQgaW5wdXROYW1lID0gaW5wdXQubmFtZTtcbiAgICAgICAgICAgICAgICAgIGlmIChpbnB1dE5hbWUgaW4gaW5FbWJlZGRpbmcpIHtcbiAgICAgICAgICAgICAgICAgICAgbGV0IGluRW1iZWROb2RlID0gaW5FbWJlZGRpbmdbaW5wdXROYW1lXTtcbiAgICAgICAgICAgICAgICAgICAgb3BOb2RlLmluRW1iZWRkaW5ncy5wdXNoKGluRW1iZWROb2RlKTtcbiAgICAgICAgICAgICAgICAgICAgLy8gTW92ZSB0aGUgaW5wdXRzIG9mIHRoZSBpbi1lbWJlZGRpbmcgbm9kZSBpbnRvIGluY29taW5nXG4gICAgICAgICAgICAgICAgICAgIC8vIGVkZ2VzIG9mXG4gICAgICAgICAgICAgICAgICAgIC8vIHRoZSBtYWluIG5vZGUuIEUuZy4gdGhlIGNvbnRyb2wgZGVwZW5kZW5jeSBvZiBhIGNvbnN0YW50XG4gICAgICAgICAgICAgICAgICAgIC8vIG5vZGVcbiAgICAgICAgICAgICAgICAgICAgLy8gc2hvdWxkIGJlIG1vdmVkIHRvIHRoZSBvcCBub2RlIHdoZXJlIHRoZSBjb25zdGFudCBpc1xuICAgICAgICAgICAgICAgICAgICAvLyBlbWJlZGRlZC5cbiAgICAgICAgICAgICAgICAgICAgZm9yIChsZXQgZW1iZWRJbnB1dCBvZiBpbkVtYmVkTm9kZS5pbnB1dHMpIHtcbiAgICAgICAgICAgICAgICAgICAgICBhZGRFZGdlVG9HcmFwaChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZ3JhcGgsIG5vcm1hbGl6ZWROYW1lRGljdFtlbWJlZElucHV0Lm5hbWVdIHx8XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbWJlZElucHV0Lm5hbWUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9wTm9kZSwgZW1iZWRJbnB1dCwgcGFyYW1zLCBpKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgfSBlbHNlIGlmIChpbnB1dE5hbWUgaW4gb3V0RW1iZWRkaW5nKSB7XG4gICAgICAgICAgICAgICAgICAgIC8vIE1vdmUgdGhlIGlucHV0cyBvZiB0aGUgb3V0LWVtYmVkZGluZyBub2RlIGludG8gaW5wdXRzIG9mXG4gICAgICAgICAgICAgICAgICAgIC8vIHRoZSBtYWluIG5vZGUgd2hlcmUgdGhlIG91dC1lbWJlZGRpbmcgcG9pbnRzIHRvLlxuICAgICAgICAgICAgICAgICAgICBsZXQgb3V0RW1iZWROb2RlID0gb3V0RW1iZWRkaW5nW2lucHV0TmFtZV07XG4gICAgICAgICAgICAgICAgICAgIGZvciAobGV0IGVtYmVkSW5wdXQgb2Ygb3V0RW1iZWROb2RlLmlucHV0cykge1xuICAgICAgICAgICAgICAgICAgICAgIGFkZEVkZ2VUb0dyYXBoKFxuICAgICAgICAgICAgICAgICAgICAgICAgICBncmFwaCwgbm9ybWFsaXplZE5hbWVEaWN0W2VtYmVkSW5wdXQubmFtZV0gfHxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVtYmVkSW5wdXQubmFtZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb3BOb2RlLCBpbnB1dCwgcGFyYW1zLCBpKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgYWRkRWRnZVRvR3JhcGgoXG4gICAgICAgICAgICAgICAgICAgICAgICBncmFwaCwgbm9ybWFsaXplZE5hbWVEaWN0W2lucHV0TmFtZV0gfHwgaW5wdXROYW1lLFxuICAgICAgICAgICAgICAgICAgICAgICAgb3BOb2RlLCBpbnB1dCwgcGFyYW1zLCBpKTtcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgICAgLy8gTm9ybWFsaXplIHRoZSBuYW1lcyBvZiBpbi1lbWJlZGRpbmdzLlxuICAgICAgICAgICAgICBfLmVhY2goaW5FbWJlZGRpbmcsIChub2RlLCBuYW1lKSA9PiB7XG4gICAgICAgICAgICAgICAgbm9kZS5uYW1lID0gbm9ybWFsaXplZE5hbWVEaWN0W25vZGUubmFtZV0gfHwgbm9kZS5uYW1lO1xuICAgICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgICByZXR1cm4gZ3JhcGg7XG4gICAgICAgICAgICB9LCB0cmFja2VyKTtcbiAgICAgIH0pO1xufTtcblxuLyoqXG4gKiBDcmVhdGUgYSBuZXcgZ3JhcGhsaWIuR3JhcGgoKSBpbnN0YW5jZSB3aXRoIGRlZmF1bHQgcGFyYW1ldGVyc1xuICovXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlR3JhcGg8TiwgRT4oXG4gICAgbmFtZTogc3RyaW5nLCB0eXBlLFxuICAgIG9wdD86IGdyYXBobGliLkdyYXBoT3B0aW9ucyk6IGdyYXBobGliLkdyYXBoPE4sIEU+IHtcbiAgY29uc3QgZ3JhcGhPcHRpb25zID0gb3B0IHx8IHt9O1xuICBsZXQgZ3JhcGggPSBuZXcgZ3JhcGhsaWIuR3JhcGg8TiwgRT4oZ3JhcGhPcHRpb25zKTtcbiAgZ3JhcGguc2V0R3JhcGgoe1xuICAgIG5hbWU6IG5hbWUsXG4gICAgcmFua2RpcjogZ3JhcGhPcHRpb25zLnJhbmtkaXIgfHwgJ0JUJywgIC8vIEJULFRCLExSLFJMXG4gICAgdHlwZTogdHlwZVxuICB9KTtcbiAgcmV0dXJuIGdyYXBoO1xufTtcblxuLyoqXG4gKiBDcmVhdGUgYSBwcmVkaWNhdGUgZm9yIGNoZWNraW5nIHdoZXRoZXIgYSBub2RlIHNob3VsZCBiZSBlbWJlZGRlZCBiYXNlZCBvblxuICogdGhlIHNwZWNpZmllZCB0eXBlcy5cbiAqL1xuZnVuY3Rpb24gZ2V0RW1iZWRQcmVkaWNhdGUodHlwZXM6IHN0cmluZ1tdKSB7XG4gIHJldHVybiBmdW5jdGlvbihub2RlOiBPcE5vZGUpIHtcbiAgICAvLyBjaGVjayB0eXBlc1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdHlwZXMubGVuZ3RoOyBpKyspIHtcbiAgICAgIGxldCByZWdFeHAgPSBuZXcgUmVnRXhwKHR5cGVzW2ldKTtcbiAgICAgIGlmIChub2RlLm9wLm1hdGNoKHJlZ0V4cCkpIHsgcmV0dXJuIHRydWU7IH1cbiAgICB9XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9O1xufTtcblxuLyoqXG4gKiBSZXR1cm5zIGEgc3RyaWN0IG5vZGUgbmFtZSAobmFtZSA9PiBuYW1lLyhuYW1lKSkgdG8gYXZvaWQgY29uZmxpY3RzXG4gKiB3aGVyZSB0aGUgbm9kZSBuYW1lIGlzIGFsc28gYSBuYW1lc3BhY2UuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZXRTdHJpY3ROYW1lKG5hbWU6IHN0cmluZyk6IHN0cmluZyB7XG4gIGxldCBwYXJ0cyA9IG5hbWUuc3BsaXQoTkFNRVNQQUNFX0RFTElNKTtcbiAgcmV0dXJuIG5hbWUgKyBOQU1FU1BBQ0VfREVMSU0gKyAnKCcgKyBwYXJ0c1twYXJ0cy5sZW5ndGggLSAxXSArICcpJztcbn1cblxuLyoqXG4gKiBGb3IgZWFjaCBvcCBub2RlIChlbWJlZGRpbmcgb3Igbm9uLWVtYmVkZGluZyksIHJlbmFtZSBpdCBpZiB0aGVyZSBpcyBhXG4gKiBub24tZW1iZWRkaW5nIG5vZGUgdW5kZXIgaXRzIG5hbWVzcGFjZS4gRm9yIGV4YW1wbGUsIGFzc3VtZSBub2RlIG5hbWUgJ0EnLlxuICogSWYgdGhlcmUgaXMgYSBub24tZW1iZWRkaW5nIG5vZGUgdW5kZXIgaXRzIG5hbWVzcGFjZSAoZS5nLiAnQS9CJyksICdBJyB3aWxsXG4gKiBiZSByZW5hbWVkIHRvICdBLyhBKScuIFRoZW4gdGhlIG5hbWVzcGFjZSAnQScgd2lsbCBjb250YWluIDIgbm9kZXM6ICcoQSknXG4gKiBhbmQgJ0InLiBJZiBhbGwgdGhlIG5vZGVzIHVuZGVyICdBJyBhcmUgZW1iZWRkaW5nIG5vZGVzIChlLmcuIGNvbnN0YW50IGFuZFxuICogc3VtbWFyeSksIGtlZXAgJ0EnIGFzIGFuIE9wIG5vZGUgYW5kIGRvbid0IGNyZWF0ZSBhIG5hbWVzcGFjZS5cbiAqXG4gKiBAcGFyYW0gbm9kZU5hbWVzIEFuIGFycmF5IG9mIHJlZ3VsYXIgKG5vbi1lbWJlZGRpbmcpIG5vZGUgbmFtZXMuXG4gKiBAcGFyYW0gZW1iZWRkaW5nTm9kZU5hbWVzIEFuIGFycmF5IG9mIGVtYmVkZGluZyBub2RlIG5hbWVzLlxuICogQHJldHVybiBEaWN0aW9uYXJ5IG9iamVjdCBtYXBwaW5nIG5hbWVzIHRoYXQgbmVlZCB0byBiZSByZW5hbWVkIHRvXG4gKiAgICAgbmV3IG5hbWVzLlxuICovXG5mdW5jdGlvbiBtYXBTdHJpY3RIaWVyYXJjaHkobm9kZU5hbWVzOiBzdHJpbmdbXSxcbiAgICBlbWJlZGRpbmdOb2RlTmFtZXM6IHN0cmluZ1tdKToge1tvbGROYW1lOiBzdHJpbmddOiBzdHJpbmd9IHtcbiAgLyoqIERpY3Rpb25hcnkgdGhhdCBtYXBzIHRoZSBvbGQgbmV3IHRvIHRoZSBuZXcgbmFtZSAqL1xuICBsZXQgbmV3TmFtZURpY3Rpb25hcnk6IHtbb2xkTmFtZTogc3RyaW5nXTogc3RyaW5nfSA9IHt9O1xuICAvKiogU2V0IHVzZWQgdG8gc3RvcmUgYWxsIG5hbWVzcGFjZXMuICovXG4gIGxldCBuYW1lc3BhY2VTZXQ6IHtbbmFtZXNwYWNlOiBzdHJpbmddOiBib29sZWFufSA9IHt9O1xuICAvLyBzb3J0IHRoZSBub2RlcyB0byBtYWtlIHByZWZpeCBjaGVjayBmYXN0ZXJcbiAgbm9kZU5hbWVzLnNvcnQoKTtcbiAgLy8gbG9vayBmb3Igbm9kZXMgd2l0aCBhIHByZWZpeCBhLGEvYiAtPiBhLyhhKSxhL2JcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBub2RlTmFtZXMubGVuZ3RoIC0gMTsgKytpKSB7XG4gICAgbGV0IGEgPSBub2RlTmFtZXNbaV07XG4gICAgLy8gR2V0IGFsbCB0aGUgcGFyZW50IG5hbWVzcGFjZXMgb2YgdGhlIGN1cnJlbnQgbm9kZVxuICAgIC8vIGFuZCBhZGQgdGhlbSBpbiB0aGUgbmFtZXNwYWNlIHNldC5cbiAgICBfLmVhY2goZ2V0SGllcmFyY2hpY2FsUGF0aChhKS5zbGljZSgwLCAtMSksIG5zID0+IHtcbiAgICAgIG5hbWVzcGFjZVNldFtuc10gPSB0cnVlO1xuICAgIH0pO1xuICAgIGZvciAobGV0IGogPSBpICsgMTsgaiA8IG5vZGVOYW1lcy5sZW5ndGg7ICsraikge1xuICAgICAgbGV0IGIgPSBub2RlTmFtZXNbal07XG4gICAgICBpZiAoXy5zdGFydHNXaXRoKGIsIGEpKSB7XG4gICAgICAgIGlmIChiLmxlbmd0aCA+IGEubGVuZ3RoICYmIGIuY2hhckF0KGEubGVuZ3RoKSA9PT0gTkFNRVNQQUNFX0RFTElNKSB7XG4gICAgICAgICAgbmV3TmFtZURpY3Rpb25hcnlbYV0gPSBnZXRTdHJpY3ROYW1lKGEpO1xuICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBicmVhaztcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgLy8gR28gdGhyb3VnaCBhbGwgdGhlIGVtYmVkZGluZyBub2RlIG5hbWVzIGFuZCByZW5hbWUgdGhlbSBpbiBjYXNlIHRoZXlcbiAgLy8gY29sbGlkZSB3aXRoIG5hbWVzcGFjZXMuXG4gIF8uZWFjaChlbWJlZGRpbmdOb2RlTmFtZXMsIGVtYmVkZGluZ05hbWUgPT4ge1xuICAgIGlmIChlbWJlZGRpbmdOYW1lIGluIG5hbWVzcGFjZVNldCkge1xuICAgICAgLy8gUmVuYW1lIHRvIGZvbGxvdyBzdHJpY3QgaGllcmFyY2h5LlxuICAgICAgbmV3TmFtZURpY3Rpb25hcnlbZW1iZWRkaW5nTmFtZV0gPSBnZXRTdHJpY3ROYW1lKGVtYmVkZGluZ05hbWUpO1xuICAgIH1cbiAgfSk7XG4gIHJldHVybiBuZXdOYW1lRGljdGlvbmFyeTtcbn07XG5cbi8qKlxuICogUmV0dXJucyBhIGxpc3Qgb2YgdGhlIGRlZ3JlZXMgb2YgZWFjaCBub2RlIGluIHRoZSBncmFwaC5cbiAqL1xuZnVuY3Rpb24gZGVncmVlU2VxdWVuY2UoZ3JhcGg6IGdyYXBobGliLkdyYXBoPGFueSwgYW55Pik6IG51bWJlcltdIHtcbiAgbGV0IGRlZ3JlZXMgPSBncmFwaC5ub2RlcygpLm1hcChmdW5jdGlvbihuYW1lKSB7XG4gICAgcmV0dXJuIGdyYXBoLm5laWdoYm9ycyhuYW1lKS5sZW5ndGg7XG4gIH0pO1xuICBkZWdyZWVzLnNvcnQoKTtcbiAgcmV0dXJuIGRlZ3JlZXM7XG59O1xuXG4vKipcbiAqIFJldHVybnMgaWYgdGhlIGRlZ3JlZSBzZXF1ZW5jZSBvZiB0aGUgdHdvIGdyYXBocyBpcyB0aGUgc2FtZS5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGhhc1NpbWlsYXJEZWdyZWVTZXF1ZW5jZShncmFwaDE6IGdyYXBobGliLkdyYXBoPGFueSwgYW55PixcbiAgICBncmFwaDI6IGdyYXBobGliLkdyYXBoPGFueSwgYW55Pik6IGJvb2xlYW4ge1xuICBsZXQgZGcxID0gZGVncmVlU2VxdWVuY2UoZ3JhcGgxKTtcbiAgbGV0IGRnMiA9IGRlZ3JlZVNlcXVlbmNlKGdyYXBoMik7XG5cbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBkZzEubGVuZ3RoOyBpKyspIHtcbiAgICBpZiAoZGcxW2ldICE9PSBkZzJbaV0pIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHRydWU7XG59O1xuXG4vKipcbiAqIFJldHVybnMgdGhlIGhpZXJhcmNoaWNhbCBwYXRoIG9mIHRoZSBjdXJyZW50IG5vZGUsIGJhc2VkIG9uIHRoZSBub2RlJ3MgbmFtZS5cbiAqIEZvciBleGFtcGxlLCBpZiB0aGUgbmFtZSBpcyAnYS9iL2MnLCB0aGUgcmV0dXJuZWQgcGF0aCBpc1xuICogWydhJywgJ2EvYicsICdhL2IvYyddLlxuICovXG5leHBvcnQgZnVuY3Rpb24gZ2V0SGllcmFyY2hpY2FsUGF0aChuYW1lOiBzdHJpbmcsXG4gIHNlcmllc05hbWVzPzogeyBbbmFtZTogc3RyaW5nXTogc3RyaW5nIH0pOiBzdHJpbmdbXSB7XG4gIGxldCBwYXRoOiBzdHJpbmdbXSA9IFtdO1xuICBsZXQgaSA9IG5hbWUuaW5kZXhPZihOQU1FU1BBQ0VfREVMSU0pO1xuICAvLyBQdXNoIGFsbCBwYXJlbnQgcG9ydGlvbnMgb2YgdGhlIHBhdGguXG4gIHdoaWxlIChpID49IDApIHtcbiAgICBwYXRoLnB1c2gobmFtZS5zdWJzdHJpbmcoMCwgaSkpO1xuICAgIGkgPSBuYW1lLmluZGV4T2YoTkFNRVNQQUNFX0RFTElNLCBpICsgMSk7XG4gIH1cbiAgLy8gSWYgdGhlIG5vZGUncyBwYXRoIGlzIHVuZGVyIGEgc2VyaWVzLCB0aGVuIGFkZCB0aGUgc2VyaWVzIG5vZGUgbmFtZSB0byB0aGVcbiAgLy8gaGllcmFyY2hpY2FsIHBhdGggYXMgdGhlIHBhcmVudCBvZiB0aGUgbGVhZi5cbiAgaWYgKHNlcmllc05hbWVzKSB7XG4gICAgbGV0IHNlcmllc05hbWUgPSBzZXJpZXNOYW1lc1tuYW1lXTtcbiAgICBpZiAoc2VyaWVzTmFtZSkge1xuICAgICAgcGF0aC5wdXNoKHNlcmllc05hbWUpO1xuICAgIH1cbiAgfVxuICAvLyBQdXNoIHRoZSBsZWFmIG9mIHRoZSBwYXRoLlxuICBwYXRoLnB1c2gobmFtZSk7XG4gIHJldHVybiBwYXRoO1xufTtcblxuLyoqXG4gKiBSZXR1cm5zIHRoZSBzdHJpbmcgZm9yIHRoZSBub2RlIGluY2x1c2lvbiB0b2dnbGUgYnV0dG9uLCBkZXBlbmRhbnRcbiAqIG9uIHRoZSBwcm92aWRlZCBjdXJyZW50IEluY2x1c2lvblR5cGUuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZXRJbmNsdWRlTm9kZUJ1dHRvblN0cmluZyhpbmNsdWRlOiBJbmNsdXNpb25UeXBlKSB7XG4gIGlmIChpbmNsdWRlID09PSB0Zi5ncmFwaC5JbmNsdXNpb25UeXBlLkVYQ0xVREUpIHtcbiAgICByZXR1cm4gJ0FkZCB0byBtYWluIGdyYXBoJztcbiAgfSBlbHNlIHtcbiAgICByZXR1cm4gJ1JlbW92ZSBmcm9tIG1haW4gZ3JhcGgnO1xuICB9XG59O1xuXG4vKipcbiAqIFJldHVybnMgdGhlIHN0cmluZyBmb3IgdGhlIHNlcmllcyBub2RlIGdyb3VwaW5nIHRvZ2dsZSBidXR0b24sIGRlcGVuZGFudFxuICogb24gdGhlIHByb3ZpZGVkIGN1cnJlbnQgU2VyaWVzR3JvdXBpbmdUeXBlLlxuICovXG5leHBvcnQgZnVuY3Rpb24gZ2V0R3JvdXBTZXJpZXNOb2RlQnV0dG9uU3RyaW5nKGdyb3VwOiBTZXJpZXNHcm91cGluZ1R5cGUpIHtcbiAgaWYgKGdyb3VwID09PSB0Zi5ncmFwaC5TZXJpZXNHcm91cGluZ1R5cGUuR1JPVVApIHtcbiAgICByZXR1cm4gJ1VuZ3JvdXAgdGhpcyBzZXJpZXMgb2Ygbm9kZXMnO1xuICB9IGVsc2Uge1xuICAgIHJldHVybiAnR3JvdXAgdGhpcyBzZXJpZXMgb2Ygbm9kZXMnO1xuICB9XG59O1xuXG4vKipcbiAqIFRvZ2dsZSB0aGUgbm9kZSBzZXJpZXMgZ3JvdXBpbmcgb3B0aW9uIGluIHRoZSBwcm92aWRlZCBtYXAsIHNldHRpbmcgaXRcbiAqIHRvIHVuZ3JvdXAgaWYgdGhlIHNlcmllcyBpcyBub3QgYWxyZWFkeSBpbiB0aGUgbWFwLlxuICovXG5leHBvcnQgZnVuY3Rpb24gdG9nZ2xlTm9kZVNlcmllc0dyb3VwKFxuICBtYXA6IHsgW25hbWU6IHN0cmluZ106IHRmLmdyYXBoLlNlcmllc0dyb3VwaW5nVHlwZSB9LCBuYW1lOiBzdHJpbmcpIHtcbiAgaWYgKCEobmFtZSBpbiBtYXApIHx8IG1hcFtuYW1lXSA9PT0gdGYuZ3JhcGguU2VyaWVzR3JvdXBpbmdUeXBlLkdST1VQKSB7XG4gICAgbWFwW25hbWVdID0gdGYuZ3JhcGguU2VyaWVzR3JvdXBpbmdUeXBlLlVOR1JPVVA7XG4gIH0gZWxzZSB7XG4gICAgbWFwW25hbWVdID0gdGYuZ3JhcGguU2VyaWVzR3JvdXBpbmdUeXBlLkdST1VQO1xuICB9XG59O1xuXG59IC8vIGNsb3NlIG1vZHVsZSB0Zi5ncmFwaFxuIl19