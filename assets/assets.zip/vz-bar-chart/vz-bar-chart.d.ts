declare namespace vz_bar_chart {
    /**
     * Encapsulates information for a single bar to rendered onto the chart.
     */
    interface Bar {
        x: string;
        y: number;
    }
}
