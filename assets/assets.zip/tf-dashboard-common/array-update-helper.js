/* Copyright 2018 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
var tf_dashboard_common;
(function (tf_dashboard_common) {
    /**
     * @polymerBehavior
     */
    tf_dashboard_common.ArrayUpdateHelper = {
        updateArrayProp: function (prop, value, getKey) {
            var orig = this.get(prop);
            var newVal = value;
            if (!Array.isArray(newVal)) {
                throw RangeError("Expected new value to '" + prop + "' to be an array.");
            }
            // In case using ComplexObserver, the method can be invoked before the prop
            // had a chance to initialize properly.
            if (!Array.isArray(orig)) {
                orig = [];
                this.set(prop, orig);
            }
            var lookup = new Set(newVal.map(function (item, i) { return getKey(item, i); }));
            var origInd = 0;
            var newValInd = 0;
            while (origInd < orig.length && newValInd < newVal.length) {
                if (!lookup.has(getKey(orig[origInd], origInd))) {
                    this.splice(prop, origInd, 1);
                    continue;
                }
                else if (getKey(orig[origInd], origInd) ==
                    getKey(newVal[newValInd], newValInd)) {
                    // update the element.
                    // TODO(stephanwlee): We may be able to update the original reference of
                    // the `value` by deep-copying the new value over.
                    this.set(prop + "." + origInd, newVal[newValInd]);
                }
                else {
                    this.splice(prop, origInd, 0, newVal[newValInd]);
                }
                newValInd++;
                origInd++;
            }
            if (origInd < orig.length) {
                this.splice(prop, origInd);
            }
            if (newValInd < newVal.length) {
                this.push.apply(this, [prop].concat(newVal.slice(newValInd)));
            }
        },
    };
})(tf_dashboard_common || (tf_dashboard_common = {})); // namespace tf_dashboard_common
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXJyYXktdXBkYXRlLWhlbHBlci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImFycmF5LXVwZGF0ZS1oZWxwZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7Ozs7Ozs7Z0ZBYWdGO0FBQ2hGLElBQVUsbUJBQW1CLENBcUQ1QjtBQXJERCxXQUFVLG1CQUFtQjtJQUU3Qjs7T0FFRztJQUNVLHFDQUFpQixHQUFHO1FBQy9CLGVBQWUsWUFDWCxJQUFZLEVBQ1osS0FBaUIsRUFDakIsTUFBMEM7WUFDNUMsSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUMxQixJQUFNLE1BQU0sR0FBRyxLQUFLLENBQUM7WUFFckIsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLEVBQUU7Z0JBQzFCLE1BQU0sVUFBVSxDQUFDLDRCQUEwQixJQUFJLHNCQUFtQixDQUFDLENBQUM7YUFDckU7WUFFRCwyRUFBMkU7WUFDM0UsdUNBQXVDO1lBQ3ZDLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxFQUFFO2dCQUN4QixJQUFJLEdBQUcsRUFBRSxDQUFDO2dCQUNWLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDO2FBQ3RCO1lBRUQsSUFBTSxNQUFNLEdBQUcsSUFBSSxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxVQUFDLElBQUksRUFBRSxDQUFDLElBQUssT0FBQSxNQUFNLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxFQUFmLENBQWUsQ0FBQyxDQUFDLENBQUM7WUFFakUsSUFBSSxPQUFPLEdBQUcsQ0FBQyxDQUFDO1lBQ2hCLElBQUksU0FBUyxHQUFHLENBQUMsQ0FBQztZQUNsQixPQUFPLE9BQU8sR0FBRyxJQUFJLENBQUMsTUFBTSxJQUFJLFNBQVMsR0FBRyxNQUFNLENBQUMsTUFBTSxFQUFFO2dCQUN6RCxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxFQUFFLE9BQU8sQ0FBQyxDQUFDLEVBQUU7b0JBQy9DLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFLE9BQU8sRUFBRSxDQUFDLENBQUMsQ0FBQztvQkFDOUIsU0FBUztpQkFDVjtxQkFBTSxJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEVBQUUsT0FBTyxDQUFDO29CQUNyQyxNQUFNLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxFQUFFLFNBQVMsQ0FBQyxFQUFFO29CQUN4QyxzQkFBc0I7b0JBQ3RCLHdFQUF3RTtvQkFDeEUsa0RBQWtEO29CQUNsRCxJQUFJLENBQUMsR0FBRyxDQUFJLElBQUksU0FBSSxPQUFTLEVBQUUsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUM7aUJBQ25EO3FCQUFNO29CQUNMLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFLE9BQU8sRUFBRSxDQUFDLEVBQUUsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUM7aUJBQ2xEO2dCQUNELFNBQVMsRUFBRSxDQUFDO2dCQUNaLE9BQU8sRUFBRSxDQUFDO2FBQ1g7WUFDRCxJQUFJLE9BQU8sR0FBRyxJQUFJLENBQUMsTUFBTSxFQUFFO2dCQUN6QixJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksRUFBRSxPQUFPLENBQUMsQ0FBQzthQUM1QjtZQUNELElBQUksU0FBUyxHQUFHLE1BQU0sQ0FBQyxNQUFNLEVBQUU7Z0JBQzdCLElBQUksQ0FBQyxJQUFJLE9BQVQsSUFBSSxHQUFNLElBQUksU0FBSyxNQUFNLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxHQUFFO2FBQzdDO1FBQ0gsQ0FBQztLQUNGLENBQUM7QUFFRixDQUFDLEVBckRTLG1CQUFtQixLQUFuQixtQkFBbUIsUUFxRDVCLENBQUUsZ0NBQWdDIiwic291cmNlc0NvbnRlbnQiOlsiLyogQ29weXJpZ2h0IDIwMTggVGhlIFRlbnNvckZsb3cgQXV0aG9ycy4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cblxuTGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlLCBWZXJzaW9uIDIuMCAodGhlIFwiTGljZW5zZVwiKTtcbnlvdSBtYXkgbm90IHVzZSB0aGlzIGZpbGUgZXhjZXB0IGluIGNvbXBsaWFuY2Ugd2l0aCB0aGUgTGljZW5zZS5cbllvdSBtYXkgb2J0YWluIGEgY29weSBvZiB0aGUgTGljZW5zZSBhdFxuXG4gICAgaHR0cDovL3d3dy5hcGFjaGUub3JnL2xpY2Vuc2VzL0xJQ0VOU0UtMi4wXG5cblVubGVzcyByZXF1aXJlZCBieSBhcHBsaWNhYmxlIGxhdyBvciBhZ3JlZWQgdG8gaW4gd3JpdGluZywgc29mdHdhcmVcbmRpc3RyaWJ1dGVkIHVuZGVyIHRoZSBMaWNlbnNlIGlzIGRpc3RyaWJ1dGVkIG9uIGFuIFwiQVMgSVNcIiBCQVNJUyxcbldJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWSBLSU5ELCBlaXRoZXIgZXhwcmVzcyBvciBpbXBsaWVkLlxuU2VlIHRoZSBMaWNlbnNlIGZvciB0aGUgc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nIHBlcm1pc3Npb25zIGFuZFxubGltaXRhdGlvbnMgdW5kZXIgdGhlIExpY2Vuc2UuXG49PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0qL1xubmFtZXNwYWNlIHRmX2Rhc2hib2FyZF9jb21tb24ge1xuXG4vKipcbiAqIEBwb2x5bWVyQmVoYXZpb3JcbiAqL1xuZXhwb3J0IGNvbnN0IEFycmF5VXBkYXRlSGVscGVyID0ge1xuICB1cGRhdGVBcnJheVByb3AoXG4gICAgICBwcm9wOiBzdHJpbmcsXG4gICAgICB2YWx1ZTogQXJyYXk8YW55PixcbiAgICAgIGdldEtleTogKGl0ZW06IGFueSwgaW5kOiBudW1iZXIpID0+IHN0cmluZykge1xuICAgIGxldCBvcmlnID0gdGhpcy5nZXQocHJvcCk7XG4gICAgY29uc3QgbmV3VmFsID0gdmFsdWU7XG5cbiAgICBpZiAoIUFycmF5LmlzQXJyYXkobmV3VmFsKSkge1xuICAgICAgdGhyb3cgUmFuZ2VFcnJvcihgRXhwZWN0ZWQgbmV3IHZhbHVlIHRvICcke3Byb3B9JyB0byBiZSBhbiBhcnJheS5gKTtcbiAgICB9XG5cbiAgICAvLyBJbiBjYXNlIHVzaW5nIENvbXBsZXhPYnNlcnZlciwgdGhlIG1ldGhvZCBjYW4gYmUgaW52b2tlZCBiZWZvcmUgdGhlIHByb3BcbiAgICAvLyBoYWQgYSBjaGFuY2UgdG8gaW5pdGlhbGl6ZSBwcm9wZXJseS5cbiAgICBpZiAoIUFycmF5LmlzQXJyYXkob3JpZykpIHtcbiAgICAgIG9yaWcgPSBbXTtcbiAgICAgIHRoaXMuc2V0KHByb3AsIG9yaWcpO1xuICAgIH1cblxuICAgIGNvbnN0IGxvb2t1cCA9IG5ldyBTZXQobmV3VmFsLm1hcCgoaXRlbSwgaSkgPT4gZ2V0S2V5KGl0ZW0sIGkpKSk7XG5cbiAgICBsZXQgb3JpZ0luZCA9IDA7XG4gICAgbGV0IG5ld1ZhbEluZCA9IDA7XG4gICAgd2hpbGUgKG9yaWdJbmQgPCBvcmlnLmxlbmd0aCAmJiBuZXdWYWxJbmQgPCBuZXdWYWwubGVuZ3RoKSB7XG4gICAgICBpZiAoIWxvb2t1cC5oYXMoZ2V0S2V5KG9yaWdbb3JpZ0luZF0sIG9yaWdJbmQpKSkge1xuICAgICAgICB0aGlzLnNwbGljZShwcm9wLCBvcmlnSW5kLCAxKTtcbiAgICAgICAgY29udGludWU7XG4gICAgICB9IGVsc2UgaWYgKGdldEtleShvcmlnW29yaWdJbmRdLCBvcmlnSW5kKSA9PVxuICAgICAgICAgIGdldEtleShuZXdWYWxbbmV3VmFsSW5kXSwgbmV3VmFsSW5kKSkge1xuICAgICAgICAvLyB1cGRhdGUgdGhlIGVsZW1lbnQuXG4gICAgICAgIC8vIFRPRE8oc3RlcGhhbndsZWUpOiBXZSBtYXkgYmUgYWJsZSB0byB1cGRhdGUgdGhlIG9yaWdpbmFsIHJlZmVyZW5jZSBvZlxuICAgICAgICAvLyB0aGUgYHZhbHVlYCBieSBkZWVwLWNvcHlpbmcgdGhlIG5ldyB2YWx1ZSBvdmVyLlxuICAgICAgICB0aGlzLnNldChgJHtwcm9wfS4ke29yaWdJbmR9YCwgbmV3VmFsW25ld1ZhbEluZF0pO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhpcy5zcGxpY2UocHJvcCwgb3JpZ0luZCwgMCwgbmV3VmFsW25ld1ZhbEluZF0pO1xuICAgICAgfVxuICAgICAgbmV3VmFsSW5kKys7XG4gICAgICBvcmlnSW5kKys7XG4gICAgfVxuICAgIGlmIChvcmlnSW5kIDwgb3JpZy5sZW5ndGgpIHtcbiAgICAgIHRoaXMuc3BsaWNlKHByb3AsIG9yaWdJbmQpO1xuICAgIH1cbiAgICBpZiAobmV3VmFsSW5kIDwgbmV3VmFsLmxlbmd0aCkge1xuICAgICAgdGhpcy5wdXNoKHByb3AsIC4uLm5ld1ZhbC5zbGljZShuZXdWYWxJbmQpKTtcbiAgICB9XG4gIH0sXG59O1xuXG59ICAvLyBuYW1lc3BhY2UgdGZfZGFzaGJvYXJkX2NvbW1vblxuIl19