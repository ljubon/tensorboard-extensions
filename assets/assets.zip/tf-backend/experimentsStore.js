var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
/* Copyright 2018 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
var tf_backend;
(function (tf_backend) {
    var ExperimentsStore = /** @class */ (function (_super) {
        __extends(ExperimentsStore, _super);
        function ExperimentsStore() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this._experiments = [];
            return _this;
        }
        ExperimentsStore.prototype.load = function () {
            var _this = this;
            var url = tf_backend.getRouter().experiments();
            return this.requestManager.request(url).then(function (newExperiments) {
                if (!_.isEqual(_this._experiments, newExperiments)) {
                    _this._experiments = newExperiments;
                    _this.emitChange();
                }
            });
        };
        /**
         * Get the current list of experiments. If no data is available, this will be
         * an empty array (i.e., there is no distinction between "no experiment" and
         * "no experiment yet").
         */
        ExperimentsStore.prototype.getExperiments = function () {
            return this._experiments.slice();
        };
        return ExperimentsStore;
    }(tf_backend.BaseStore));
    tf_backend.ExperimentsStore = ExperimentsStore;
    tf_backend.experimentsStore = new ExperimentsStore();
})(tf_backend || (tf_backend = {})); // namespace tf_backend
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZXhwZXJpbWVudHNTdG9yZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImV4cGVyaW1lbnRzU3RvcmUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztBQUFBOzs7Ozs7Ozs7Ozs7O2dGQWFnRjtBQUNoRixJQUFVLFVBQVUsQ0EyQm5CO0FBM0JELFdBQVUsVUFBVTtJQUVwQjtRQUFzQyxvQ0FBUztRQUEvQztZQUFBLHFFQXFCQztZQXBCUyxrQkFBWSxHQUFpQixFQUFFLENBQUM7O1FBb0IxQyxDQUFDO1FBbEJDLCtCQUFJLEdBQUo7WUFBQSxpQkFRQztZQVBDLElBQU0sR0FBRyxHQUFHLFdBQUEsU0FBUyxFQUFFLENBQUMsV0FBVyxFQUFFLENBQUM7WUFDdEMsT0FBTyxJQUFJLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBQSxjQUFjO2dCQUN6RCxJQUFJLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFJLENBQUMsWUFBWSxFQUFFLGNBQWMsQ0FBQyxFQUFFO29CQUNqRCxLQUFJLENBQUMsWUFBWSxHQUFHLGNBQWMsQ0FBQztvQkFDbkMsS0FBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO2lCQUNuQjtZQUNILENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQztRQUVEOzs7O1dBSUc7UUFDSCx5Q0FBYyxHQUFkO1lBQ0UsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLEtBQUssRUFBRSxDQUFDO1FBQ25DLENBQUM7UUFDSCx1QkFBQztJQUFELENBQUMsQUFyQkQsQ0FBc0MsV0FBQSxTQUFTLEdBcUI5QztJQXJCWSwyQkFBZ0IsbUJBcUI1QixDQUFBO0lBRVksMkJBQWdCLEdBQUcsSUFBSSxnQkFBZ0IsRUFBRSxDQUFDO0FBRXZELENBQUMsRUEzQlMsVUFBVSxLQUFWLFVBQVUsUUEyQm5CLENBQUUsdUJBQXVCIiwic291cmNlc0NvbnRlbnQiOlsiLyogQ29weXJpZ2h0IDIwMTggVGhlIFRlbnNvckZsb3cgQXV0aG9ycy4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cblxuTGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlLCBWZXJzaW9uIDIuMCAodGhlIFwiTGljZW5zZVwiKTtcbnlvdSBtYXkgbm90IHVzZSB0aGlzIGZpbGUgZXhjZXB0IGluIGNvbXBsaWFuY2Ugd2l0aCB0aGUgTGljZW5zZS5cbllvdSBtYXkgb2J0YWluIGEgY29weSBvZiB0aGUgTGljZW5zZSBhdFxuXG4gICAgaHR0cDovL3d3dy5hcGFjaGUub3JnL2xpY2Vuc2VzL0xJQ0VOU0UtMi4wXG5cblVubGVzcyByZXF1aXJlZCBieSBhcHBsaWNhYmxlIGxhdyBvciBhZ3JlZWQgdG8gaW4gd3JpdGluZywgc29mdHdhcmVcbmRpc3RyaWJ1dGVkIHVuZGVyIHRoZSBMaWNlbnNlIGlzIGRpc3RyaWJ1dGVkIG9uIGFuIFwiQVMgSVNcIiBCQVNJUyxcbldJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWSBLSU5ELCBlaXRoZXIgZXhwcmVzcyBvciBpbXBsaWVkLlxuU2VlIHRoZSBMaWNlbnNlIGZvciB0aGUgc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nIHBlcm1pc3Npb25zIGFuZFxubGltaXRhdGlvbnMgdW5kZXIgdGhlIExpY2Vuc2UuXG49PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0qL1xubmFtZXNwYWNlIHRmX2JhY2tlbmQge1xuXG5leHBvcnQgY2xhc3MgRXhwZXJpbWVudHNTdG9yZSBleHRlbmRzIEJhc2VTdG9yZSB7XG4gIHByaXZhdGUgX2V4cGVyaW1lbnRzOiBFeHBlcmltZW50W10gPSBbXTtcblxuICBsb2FkKCkge1xuICAgIGNvbnN0IHVybCA9IGdldFJvdXRlcigpLmV4cGVyaW1lbnRzKCk7XG4gICAgcmV0dXJuIHRoaXMucmVxdWVzdE1hbmFnZXIucmVxdWVzdCh1cmwpLnRoZW4obmV3RXhwZXJpbWVudHMgPT4ge1xuICAgICAgaWYgKCFfLmlzRXF1YWwodGhpcy5fZXhwZXJpbWVudHMsIG5ld0V4cGVyaW1lbnRzKSkge1xuICAgICAgICB0aGlzLl9leHBlcmltZW50cyA9IG5ld0V4cGVyaW1lbnRzO1xuICAgICAgICB0aGlzLmVtaXRDaGFuZ2UoKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBHZXQgdGhlIGN1cnJlbnQgbGlzdCBvZiBleHBlcmltZW50cy4gSWYgbm8gZGF0YSBpcyBhdmFpbGFibGUsIHRoaXMgd2lsbCBiZVxuICAgKiBhbiBlbXB0eSBhcnJheSAoaS5lLiwgdGhlcmUgaXMgbm8gZGlzdGluY3Rpb24gYmV0d2VlbiBcIm5vIGV4cGVyaW1lbnRcIiBhbmRcbiAgICogXCJubyBleHBlcmltZW50IHlldFwiKS5cbiAgICovXG4gIGdldEV4cGVyaW1lbnRzKCk6IEV4cGVyaW1lbnRbXSB7XG4gICAgcmV0dXJuIHRoaXMuX2V4cGVyaW1lbnRzLnNsaWNlKCk7XG4gIH1cbn1cblxuZXhwb3J0IGNvbnN0IGV4cGVyaW1lbnRzU3RvcmUgPSBuZXcgRXhwZXJpbWVudHNTdG9yZSgpO1xuXG59ICAvLyBuYW1lc3BhY2UgdGZfYmFja2VuZFxuIl19