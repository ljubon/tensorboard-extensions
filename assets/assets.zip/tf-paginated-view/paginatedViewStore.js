/* Copyright 2017 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
var tf_paginated_view;
(function (tf_paginated_view) {
    var LIMIT_LOCAL_STORAGE_KEY = 'TF.TensorBoard.PaginatedView.limit';
    var DEFAULT_LIMIT = 12; // reasonably small and has lots of factors
    var _limit = null; // cached localStorage value
    var listeners = new Set();
    /**
     * Register a listener (nullary function) to be called when the page
     * limit changes.
     */
    function addLimitListener(listener) {
        listeners.add(listener);
    }
    tf_paginated_view.addLimitListener = addLimitListener;
    /**
     * Remove a listener registered with `addLimitListener`.
     */
    function removeLimitListener(listener) {
        listeners.delete(listener);
    }
    tf_paginated_view.removeLimitListener = removeLimitListener;
    function getLimit() {
        if (_limit == null) {
            _limit = tf_storage.getNumber(LIMIT_LOCAL_STORAGE_KEY, { useLocalStorage: true });
            if (_limit == null || !isFinite(_limit) || _limit <= 0) {
                _limit = DEFAULT_LIMIT;
            }
        }
        return _limit;
    }
    tf_paginated_view.getLimit = getLimit;
    function setLimit(limit) {
        if (limit !== Math.floor(limit)) {
            throw new Error("limit must be an integer, but got: " + limit);
        }
        if (limit <= 0) {
            throw new Error("limit must be positive, but got: " + limit);
        }
        if (limit === _limit) {
            return;
        }
        _limit = limit;
        tf_storage.setNumber(LIMIT_LOCAL_STORAGE_KEY, _limit, { useLocalStorage: true });
        listeners.forEach(function (listener) {
            listener();
        });
    }
    tf_paginated_view.setLimit = setLimit;
})(tf_paginated_view || (tf_paginated_view = {})); // namespace tf_paginated_view
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGFnaW5hdGVkVmlld1N0b3JlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsicGFnaW5hdGVkVmlld1N0b3JlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7Ozs7Ozs7Ozs7O2dGQWFnRjtBQUNoRixJQUFVLGlCQUFpQixDQXVEMUI7QUF2REQsV0FBVSxpQkFBaUI7SUFFM0IsSUFBTSx1QkFBdUIsR0FBRyxvQ0FBb0MsQ0FBQztJQUNyRSxJQUFNLGFBQWEsR0FBRyxFQUFFLENBQUMsQ0FBRSwyQ0FBMkM7SUFFdEUsSUFBSSxNQUFNLEdBQVcsSUFBSSxDQUFDLENBQUUsNEJBQTRCO0lBSXhELElBQU0sU0FBUyxHQUFHLElBQUksR0FBRyxFQUFZLENBQUM7SUFFdEM7OztPQUdHO0lBQ0gsMEJBQWlDLFFBQWtCO1FBQ2pELFNBQVMsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUM7SUFDMUIsQ0FBQztJQUZlLGtDQUFnQixtQkFFL0IsQ0FBQTtJQUVEOztPQUVHO0lBQ0gsNkJBQW9DLFFBQWtCO1FBQ3BELFNBQVMsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUM7SUFDN0IsQ0FBQztJQUZlLHFDQUFtQixzQkFFbEMsQ0FBQTtJQUVEO1FBQ0UsSUFBSSxNQUFNLElBQUksSUFBSSxFQUFFO1lBQ2xCLE1BQU0sR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDLHVCQUF1QixFQUNqRCxFQUFDLGVBQWUsRUFBRSxJQUFJLEVBQUMsQ0FBQyxDQUFDO1lBQzdCLElBQUksTUFBTSxJQUFJLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsSUFBSSxNQUFNLElBQUksQ0FBQyxFQUFFO2dCQUN0RCxNQUFNLEdBQUcsYUFBYSxDQUFDO2FBQ3hCO1NBQ0Y7UUFDRCxPQUFPLE1BQU0sQ0FBQztJQUNoQixDQUFDO0lBVGUsMEJBQVEsV0FTdkIsQ0FBQTtJQUVELGtCQUF5QixLQUFhO1FBQ3BDLElBQUksS0FBSyxLQUFLLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEVBQUU7WUFDL0IsTUFBTSxJQUFJLEtBQUssQ0FBQyx3Q0FBc0MsS0FBTyxDQUFDLENBQUM7U0FDaEU7UUFDRCxJQUFJLEtBQUssSUFBSSxDQUFDLEVBQUU7WUFDZCxNQUFNLElBQUksS0FBSyxDQUFDLHNDQUFvQyxLQUFPLENBQUMsQ0FBQztTQUM5RDtRQUNELElBQUksS0FBSyxLQUFLLE1BQU0sRUFBRTtZQUNwQixPQUFPO1NBQ1I7UUFDRCxNQUFNLEdBQUcsS0FBSyxDQUFDO1FBQ2YsVUFBVSxDQUFDLFNBQVMsQ0FBQyx1QkFBdUIsRUFBRSxNQUFNLEVBQ2hELEVBQUMsZUFBZSxFQUFFLElBQUksRUFBQyxDQUFDLENBQUM7UUFDN0IsU0FBUyxDQUFDLE9BQU8sQ0FBQyxVQUFBLFFBQVE7WUFDeEIsUUFBUSxFQUFFLENBQUM7UUFDYixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFoQmUsMEJBQVEsV0FnQnZCLENBQUE7QUFFRCxDQUFDLEVBdkRTLGlCQUFpQixLQUFqQixpQkFBaUIsUUF1RDFCLENBQUUsOEJBQThCIiwic291cmNlc0NvbnRlbnQiOlsiLyogQ29weXJpZ2h0IDIwMTcgVGhlIFRlbnNvckZsb3cgQXV0aG9ycy4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cblxuTGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlLCBWZXJzaW9uIDIuMCAodGhlIFwiTGljZW5zZVwiKTtcbnlvdSBtYXkgbm90IHVzZSB0aGlzIGZpbGUgZXhjZXB0IGluIGNvbXBsaWFuY2Ugd2l0aCB0aGUgTGljZW5zZS5cbllvdSBtYXkgb2J0YWluIGEgY29weSBvZiB0aGUgTGljZW5zZSBhdFxuXG4gICAgaHR0cDovL3d3dy5hcGFjaGUub3JnL2xpY2Vuc2VzL0xJQ0VOU0UtMi4wXG5cblVubGVzcyByZXF1aXJlZCBieSBhcHBsaWNhYmxlIGxhdyBvciBhZ3JlZWQgdG8gaW4gd3JpdGluZywgc29mdHdhcmVcbmRpc3RyaWJ1dGVkIHVuZGVyIHRoZSBMaWNlbnNlIGlzIGRpc3RyaWJ1dGVkIG9uIGFuIFwiQVMgSVNcIiBCQVNJUyxcbldJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWSBLSU5ELCBlaXRoZXIgZXhwcmVzcyBvciBpbXBsaWVkLlxuU2VlIHRoZSBMaWNlbnNlIGZvciB0aGUgc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nIHBlcm1pc3Npb25zIGFuZFxubGltaXRhdGlvbnMgdW5kZXIgdGhlIExpY2Vuc2UuXG49PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0qL1xubmFtZXNwYWNlIHRmX3BhZ2luYXRlZF92aWV3IHtcblxuY29uc3QgTElNSVRfTE9DQUxfU1RPUkFHRV9LRVkgPSAnVEYuVGVuc29yQm9hcmQuUGFnaW5hdGVkVmlldy5saW1pdCc7XG5jb25zdCBERUZBVUxUX0xJTUlUID0gMTI7ICAvLyByZWFzb25hYmx5IHNtYWxsIGFuZCBoYXMgbG90cyBvZiBmYWN0b3JzXG5cbmxldCBfbGltaXQ6IG51bWJlciA9IG51bGw7ICAvLyBjYWNoZWQgbG9jYWxTdG9yYWdlIHZhbHVlXG5cbmV4cG9ydCB0eXBlIExpc3RlbmVyID0gKCkgPT4gdm9pZDtcblxuY29uc3QgbGlzdGVuZXJzID0gbmV3IFNldDxMaXN0ZW5lcj4oKTtcblxuLyoqXG4gKiBSZWdpc3RlciBhIGxpc3RlbmVyIChudWxsYXJ5IGZ1bmN0aW9uKSB0byBiZSBjYWxsZWQgd2hlbiB0aGUgcGFnZVxuICogbGltaXQgY2hhbmdlcy5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGFkZExpbWl0TGlzdGVuZXIobGlzdGVuZXI6IExpc3RlbmVyKTogdm9pZCB7XG4gIGxpc3RlbmVycy5hZGQobGlzdGVuZXIpO1xufVxuXG4vKipcbiAqIFJlbW92ZSBhIGxpc3RlbmVyIHJlZ2lzdGVyZWQgd2l0aCBgYWRkTGltaXRMaXN0ZW5lcmAuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiByZW1vdmVMaW1pdExpc3RlbmVyKGxpc3RlbmVyOiBMaXN0ZW5lcik6IHZvaWQge1xuICBsaXN0ZW5lcnMuZGVsZXRlKGxpc3RlbmVyKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGdldExpbWl0KCkge1xuICBpZiAoX2xpbWl0ID09IG51bGwpIHtcbiAgICBfbGltaXQgPSB0Zl9zdG9yYWdlLmdldE51bWJlcihMSU1JVF9MT0NBTF9TVE9SQUdFX0tFWSxcbiAgICAgICAge3VzZUxvY2FsU3RvcmFnZTogdHJ1ZX0pO1xuICAgIGlmIChfbGltaXQgPT0gbnVsbCB8fCAhaXNGaW5pdGUoX2xpbWl0KSB8fCBfbGltaXQgPD0gMCkge1xuICAgICAgX2xpbWl0ID0gREVGQVVMVF9MSU1JVDtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIF9saW1pdDtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHNldExpbWl0KGxpbWl0OiBudW1iZXIpIHtcbiAgaWYgKGxpbWl0ICE9PSBNYXRoLmZsb29yKGxpbWl0KSkge1xuICAgIHRocm93IG5ldyBFcnJvcihgbGltaXQgbXVzdCBiZSBhbiBpbnRlZ2VyLCBidXQgZ290OiAke2xpbWl0fWApO1xuICB9XG4gIGlmIChsaW1pdCA8PSAwKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKGBsaW1pdCBtdXN0IGJlIHBvc2l0aXZlLCBidXQgZ290OiAke2xpbWl0fWApO1xuICB9XG4gIGlmIChsaW1pdCA9PT0gX2xpbWl0KSB7XG4gICAgcmV0dXJuO1xuICB9XG4gIF9saW1pdCA9IGxpbWl0O1xuICB0Zl9zdG9yYWdlLnNldE51bWJlcihMSU1JVF9MT0NBTF9TVE9SQUdFX0tFWSwgX2xpbWl0LFxuICAgICAge3VzZUxvY2FsU3RvcmFnZTogdHJ1ZX0pO1xuICBsaXN0ZW5lcnMuZm9yRWFjaChsaXN0ZW5lciA9PiB7XG4gICAgbGlzdGVuZXIoKTtcbiAgfSk7XG59XG5cbn0gIC8vIG5hbWVzcGFjZSB0Zl9wYWdpbmF0ZWRfdmlld1xuIl19