declare module tf {
    /**
     * Mapping from color palette name to color palette, which contains
     * exact colors for multiple states of a single color palette.
     */
    let COLORS: {};
    /**
     * Mapping from op category to color palette name
     * e.g.,  OP_GROUP_COLORS['state_ops'] = 'Google Blue';
     */
    let OP_GROUP_COLORS: {};
}
