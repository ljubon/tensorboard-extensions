/* Copyright 2017 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the 'License');
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an 'AS IS' BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
var tf_debugger_dashboard;
(function (tf_debugger_dashboard) {
    /**
     * A string used to separate parts of a node name. Should be kept consistent
     * with the graph component.
     */
    tf_debugger_dashboard.NODE_NAME_SEPARATOR = '/';
    tf_debugger_dashboard.DEVICE_NAME_PATTERN = /^\/job:[A-Za-z0-9_]+\/replica:[0-9_]+\/task:[0-9]+\/device:[A-Za-z0-9_]+:[0-9]+/;
    // A checkbox is partially checked if it is a checkbox for a non-leaf node and
    // some (but not all) of its children are checked.
    var CheckboxState;
    (function (CheckboxState) {
        CheckboxState[CheckboxState["EMPTY"] = 0] = "EMPTY";
        CheckboxState[CheckboxState["CHECKED"] = 1] = "CHECKED";
        CheckboxState[CheckboxState["PARTIAL"] = 2] = "PARTIAL";
    })(CheckboxState = tf_debugger_dashboard.CheckboxState || (tf_debugger_dashboard.CheckboxState = {}));
    ;
    /**
     * Split a node name, potentially with a device name prefix.
     * @param name: Input node name, potentially with a device name prefix, e.g.,
     *   '/job:localhost/replica:0/task:0/device:CPU:0/Dense/BiasAdd'
     * @return Split items. The device name, if present, will be the first item.
     */
    function splitNodeName(name) {
        var items = [];
        var deviceNameMatches = name.match(tf_debugger_dashboard.DEVICE_NAME_PATTERN);
        var nodeName = name;
        if (deviceNameMatches != null) {
            items.push(deviceNameMatches[0]);
            // Expect there to be a slash after the device name, and skip it.
            if (nodeName[deviceNameMatches[0].length] !== '/') {
                console.error('No slash ("/") after device name in node name:', nodeName);
            }
            nodeName = nodeName.slice(deviceNameMatches[0].length + 1);
        }
        return items.concat(nodeName.split(tf_debugger_dashboard.NODE_NAME_SEPARATOR));
    }
    tf_debugger_dashboard.splitNodeName = splitNodeName;
    /**
     * Get a node name without device name prefix or base-expansion suffix.
     * @param name: The node name, possibly with a device name prefix, e.g.,
     *   '/job:localhost/replica:0/task:0/device:CPU:0/Dense/BiasAdd'
     * @return The node name without any device name prefixes or '/' at the front.
     *   E.g., 'Dense/BiasAdd'
     */
    function getCleanNodeName(name) {
        var cleanName = name;
        var deviceNameMatches = name.match(tf_debugger_dashboard.DEVICE_NAME_PATTERN);
        if (deviceNameMatches != null) {
            if (cleanName.length > deviceNameMatches[0].length &&
                cleanName[deviceNameMatches[0].length] != '/') {
                console.error('No slash ("/") after device name in node name:', name);
            }
            cleanName = cleanName.slice(deviceNameMatches[0].length + 1);
        }
        else {
            if (cleanName[0] === '/') {
                cleanName = cleanName.slice(1);
            }
        }
        // Remove any base-expansion suffix.
        if (cleanName.indexOf(')') === cleanName.length - 1) {
            cleanName = cleanName.slice(0, cleanName.indexOf('/('));
        }
        return cleanName;
    }
    tf_debugger_dashboard.getCleanNodeName = getCleanNodeName;
    /**
     * Sort and base-expand an Array of DebugWatches in place.
     * "Base-expand" means adding a '/(baseName)' suffix to nodes whose names are
     * the name scope of some other node's name.
     * @param debugWatches: An array of `DebugWatch`es to sort and base-expand.
     * @returns Sorted and base-expanded `DebugWatch`es.
     */
    function sortAndBaseExpandDebugWatches(debugWatches) {
        // Sort the debug watches.
        debugWatches.sort(function (watch1, watch2) {
            if (watch1.node_name < watch2.node_name) {
                return -1;
            }
            else if (watch1.node_name > watch2.node_name) {
                return 1;
            }
            else {
                return watch1.output_slot - watch2.output_slot;
            }
        });
        // Find leaf nodes that need to be base-expanded due to their names being a
        // prefix of other nodes.
        for (var i = 0; i < debugWatches.length; ++i) {
            var withSlashSuffix = debugWatches[i].node_name + '/';
            var toBaseExpandLeaf = false;
            for (var j = i + 1; j < debugWatches.length; ++j) {
                if (debugWatches[j].node_name.indexOf(withSlashSuffix) === 0) {
                    toBaseExpandLeaf = true;
                    break;
                }
            }
            if (toBaseExpandLeaf) {
                var items = debugWatches[i].node_name.split('/');
                debugWatches[i].node_name += '/(' + items[items.length - 1] + ')';
            }
        }
    }
    tf_debugger_dashboard.sortAndBaseExpandDebugWatches = sortAndBaseExpandDebugWatches;
    /**
     * Remove any possible base expansion from a node name.
     * @param nodeName: The node name, possibly with base expansion.
     * @returns: Node name with any base expansion removed. If `nodeName` does not
     *   contain any base expansion, the string is returned without modification.
     */
    function removeNodeNameBaseExpansion(nodeName) {
        if (nodeName.endsWith(')')) {
            return nodeName.slice(0, nodeName.lastIndexOf('/('));
        }
        else {
            return nodeName;
        }
    }
    tf_debugger_dashboard.removeNodeNameBaseExpansion = removeNodeNameBaseExpansion;
    function assembleDeviceAndNodeNames(nameItems) {
        var deviceAndNodeNames = [null, null];
        if (nameItems[0].match(tf_debugger_dashboard.DEVICE_NAME_PATTERN)) {
            var deviceName = nameItems[0];
            if (deviceName[deviceName.length - 1] === '/') {
                deviceName = deviceName.slice(0, deviceName.length - 1);
            }
            deviceAndNodeNames[0] = deviceName;
            deviceAndNodeNames[1] = nameItems.slice(1).join('/');
        }
        else {
            deviceAndNodeNames[1] = nameItems.join('/');
        }
        return deviceAndNodeNames;
    }
    tf_debugger_dashboard.assembleDeviceAndNodeNames = assembleDeviceAndNodeNames;
    var DebugWatchFilterMode;
    (function (DebugWatchFilterMode) {
        DebugWatchFilterMode[DebugWatchFilterMode["NodeName"] = 0] = "NodeName";
        DebugWatchFilterMode[DebugWatchFilterMode["OpType"] = 1] = "OpType";
    })(DebugWatchFilterMode = tf_debugger_dashboard.DebugWatchFilterMode || (tf_debugger_dashboard.DebugWatchFilterMode = {}));
    /**
     * Filter debug watches according to given filter mode and filter input.
     * @param debugWatches An array of `DebugWatch` instances.
     * @param filterMode
     * @param filterRegex Filter regular expression, e.g., for
     *   filterMode === 'Op Type': 'Variable.'.
     * @returns An array of `DebugWatch` instances from the input `debugWatches`
     *   that pass the filter.
     */
    function filterDebugWatches(debugWatches, filterMode, filterRegex) {
        if (filterMode === DebugWatchFilterMode.NodeName) {
            return debugWatches.filter(function (debugWatch) { return debugWatch.node_name.match(filterRegex); });
        }
        else if (filterMode === DebugWatchFilterMode.OpType) {
            return debugWatches.filter(function (debugWatch) { return debugWatch.op_type.match(filterRegex); });
        }
    }
    tf_debugger_dashboard.filterDebugWatches = filterDebugWatches;
    var SelectionTreeNode = /** @class */ (function () {
        function SelectionTreeNode(name, debugWatchChange, parent, debugWatch) {
            var _this = this;
            this.debugWatchChange = debugWatchChange;
            this.debugWatch = debugWatch;
            this.name = name;
            this.debugWatch = debugWatch;
            // We start out empty.
            this.checkboxState = CheckboxState.EMPTY;
            this.parent = parent;
            this.children = {};
            this.checkbox = document.createElement('paper-checkbox');
            this.checkbox.addEventListener('change', function () {
                _this._handleChange();
            }, false);
        }
        SelectionTreeNode.prototype._handleChange = function () {
            if (this.avoidPropagation) {
                // Do not propagate.
                if (this.debugWatch) {
                    this.debugWatchChange(this.debugWatch, this.isCheckboxChecked());
                }
                return;
            }
            if (this.debugWatch) {
                // This is a leaf node.
                this.setCheckboxState(this.isCheckboxChecked() ?
                    CheckboxState.CHECKED : CheckboxState.EMPTY, true);
                if (this.isCheckboxChecked()) {
                    // A checkbox just got checked. All nodes above this one are either
                    // partial or complete. Go up the tree and check.
                    this.setNodesAboveToChecked();
                }
                else {
                    // A checkbox got unchecked. All nodes above this are either empty or
                    // partial now.
                    this.setNodesAboveToEmpty();
                }
                // Run the callback.
                this.debugWatchChange(this.debugWatch, this.isCheckboxChecked());
            }
            else {
                // This is a meta node.
                this.setCheckboxState(this.isCheckboxChecked() ?
                    CheckboxState.CHECKED : CheckboxState.EMPTY, true);
                if (this.isCheckboxChecked()) {
                    // Check all the nodes under it.
                    var descendants_1 = _.values(this.children);
                    while (descendants_1.length) {
                        var node = descendants_1.pop();
                        _.forEach(node.children, function (child) { return descendants_1.push(child); });
                        node.setCheckboxState(CheckboxState.CHECKED, true);
                    }
                    // Reconcile nodes above.
                    this.setNodesAboveToChecked();
                }
                else {
                    // Uncheck all the nodes under it.
                    var descendants_2 = _.values(this.children);
                    while (descendants_2.length) {
                        var node = descendants_2.pop();
                        _.forEach(node.children, function (child) { return descendants_2.push(child); });
                        node.setCheckboxState(CheckboxState.EMPTY, true);
                    }
                    // Reconcile nodes above.
                    this.setNodesAboveToEmpty();
                }
            }
        };
        SelectionTreeNode.prototype.isLeaf = function () {
            return !!this.debugWatch;
        };
        SelectionTreeNode.prototype.setToAllCheckedExternally = function () {
            this.setCheckboxState(CheckboxState.CHECKED);
            this._handleChange();
        };
        SelectionTreeNode.prototype.setCheckboxState = function (state, avoidPropagation) {
            this.avoidPropagation = avoidPropagation;
            this.checkboxState = state;
            this.checkbox.classList.toggle('partial-checkbox', state === CheckboxState.PARTIAL);
            if (state === CheckboxState.CHECKED) {
                this.checkbox.setAttribute('checked', 'checked');
            }
            else {
                this.checkbox.removeAttribute('checked');
            }
            this.avoidPropagation = false;
        };
        SelectionTreeNode.prototype.isCheckboxChecked = function () {
            return this.checkbox.hasAttribute('checked');
        };
        SelectionTreeNode.prototype.setNodesAboveToChecked = function () {
            var currentNode = this.parent;
            var partialFound = false;
            while (currentNode) {
                if (partialFound) {
                    // We found a PARTIAL checkbox lower in the tree. Higher up ones
                    // must also be partial (and can't be complete any more).
                    currentNode.setCheckboxState(CheckboxState.PARTIAL, true);
                }
                else {
                    var index = _.findIndex(_.values(currentNode.children), function (child) { return (child.checkboxState !== CheckboxState.CHECKED); });
                    // Either all or only some of the children were checked.
                    partialFound = index !== -1;
                    currentNode.setCheckboxState(partialFound ? CheckboxState.PARTIAL : CheckboxState.CHECKED, true);
                }
                // Move up the tree.
                currentNode = currentNode.parent;
            }
        };
        SelectionTreeNode.prototype.setNodesAboveToEmpty = function () {
            var currentNode = this.parent;
            var partialFound = false;
            while (currentNode) {
                if (partialFound) {
                    // We found a PARTIAL checkbox lower in the tree. Higher up ones
                    // must also be partial (and can't be complete any more).
                    currentNode.setCheckboxState(CheckboxState.PARTIAL, true);
                }
                else {
                    var index = _.findIndex(_.values(currentNode.children), function (child) { return (child.checkboxState !== CheckboxState.EMPTY); });
                    // Either all or only some of the children were empty.
                    partialFound = index !== -1;
                    currentNode.setCheckboxState(partialFound ? CheckboxState.PARTIAL : CheckboxState.EMPTY, true);
                }
                // Move up the tree.
                currentNode = currentNode.parent;
            }
        };
        SelectionTreeNode.prototype.setLevelDom = function (levelDom) {
            this.levelDom = levelDom;
        };
        return SelectionTreeNode;
    }());
    tf_debugger_dashboard.SelectionTreeNode = SelectionTreeNode;
})(tf_debugger_dashboard || (tf_debugger_dashboard = {})); // namespace tf_debugger_dashboard
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VsZWN0aW9uLXRyZWUtbm9kZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbInNlbGVjdGlvbi10cmVlLW5vZGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7Ozs7Ozs7Z0ZBYWdGO0FBQ2hGLElBQVUscUJBQXFCLENBc1Y5QjtBQXRWRCxXQUFVLHFCQUFxQjtJQUUvQjs7O09BR0c7SUFDVSx5Q0FBbUIsR0FBRyxHQUFHLENBQUM7SUFDMUIseUNBQW1CLEdBQzVCLGlGQUFpRixDQUFDO0lBRXRGLDhFQUE4RTtJQUM5RSxrREFBa0Q7SUFDbEQsSUFBWSxhQUF1QztJQUFuRCxXQUFZLGFBQWE7UUFBRSxtREFBSyxDQUFBO1FBQUUsdURBQU8sQ0FBQTtRQUFFLHVEQUFPLENBQUE7SUFBQSxDQUFDLEVBQXZDLGFBQWEsR0FBYixtQ0FBYSxLQUFiLG1DQUFhLFFBQTBCO0lBQUEsQ0FBQztJQWNwRDs7Ozs7T0FLRztJQUNILHVCQUE4QixJQUFZO1FBQ3hDLElBQUksS0FBSyxHQUFHLEVBQUUsQ0FBQztRQUNmLElBQU0saUJBQWlCLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxzQkFBQSxtQkFBbUIsQ0FBQyxDQUFDO1FBQzFELElBQUksUUFBUSxHQUFHLElBQUksQ0FBQztRQUNwQixJQUFJLGlCQUFpQixJQUFJLElBQUksRUFBRTtZQUM3QixLQUFLLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDakMsaUVBQWlFO1lBQ2pFLElBQUksUUFBUSxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLEdBQUcsRUFBRTtnQkFDakQsT0FBTyxDQUFDLEtBQUssQ0FBQyxnREFBZ0QsRUFBRSxRQUFRLENBQUMsQ0FBQzthQUMzRTtZQUNELFFBQVEsR0FBRyxRQUFRLENBQUMsS0FBSyxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQztTQUM1RDtRQUNELE9BQU8sS0FBSyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLHNCQUFBLG1CQUFtQixDQUFDLENBQUMsQ0FBQztJQUMzRCxDQUFDO0lBYmUsbUNBQWEsZ0JBYTVCLENBQUE7SUFFRDs7Ozs7O09BTUc7SUFDSCwwQkFBaUMsSUFBWTtRQUMzQyxJQUFJLFNBQVMsR0FBRyxJQUFJLENBQUM7UUFDckIsSUFBTSxpQkFBaUIsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLHNCQUFBLG1CQUFtQixDQUFDLENBQUM7UUFDMUQsSUFBSSxpQkFBaUIsSUFBSSxJQUFJLEVBQUU7WUFDN0IsSUFBSSxTQUFTLENBQUMsTUFBTSxHQUFHLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU07Z0JBQzlDLFNBQVMsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxHQUFHLEVBQUU7Z0JBQ2pELE9BQU8sQ0FBQyxLQUFLLENBQUMsZ0RBQWdELEVBQUUsSUFBSSxDQUFDLENBQUM7YUFDdkU7WUFDRCxTQUFTLEdBQUcsU0FBUyxDQUFDLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUM7U0FDOUQ7YUFBTTtZQUNMLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsRUFBRTtnQkFDeEIsU0FBUyxHQUFHLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFDaEM7U0FDRjtRQUNELG9DQUFvQztRQUNwQyxJQUFJLFNBQVMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssU0FBUyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7WUFDbkQsU0FBUyxHQUFHLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLFNBQVMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztTQUN6RDtRQUNELE9BQU8sU0FBUyxDQUFDO0lBQ25CLENBQUM7SUFuQmUsc0NBQWdCLG1CQW1CL0IsQ0FBQTtJQUVEOzs7Ozs7T0FNRztJQUNILHVDQUE4QyxZQUEwQjtRQUN0RSwwQkFBMEI7UUFDMUIsWUFBWSxDQUFDLElBQUksQ0FBQyxVQUFDLE1BQU0sRUFBRSxNQUFNO1lBQy9CLElBQUksTUFBTSxDQUFDLFNBQVMsR0FBRyxNQUFNLENBQUMsU0FBUyxFQUFFO2dCQUN2QyxPQUFPLENBQUMsQ0FBQyxDQUFDO2FBQ1g7aUJBQU0sSUFBSSxNQUFNLENBQUMsU0FBUyxHQUFHLE1BQU0sQ0FBQyxTQUFTLEVBQUU7Z0JBQzlDLE9BQU8sQ0FBQyxDQUFDO2FBQ1Y7aUJBQU07Z0JBQ0wsT0FBTyxNQUFNLENBQUMsV0FBVyxHQUFHLE1BQU0sQ0FBQyxXQUFXLENBQUM7YUFDaEQ7UUFDSCxDQUFDLENBQUMsQ0FBQztRQUVILDJFQUEyRTtRQUMzRSx5QkFBeUI7UUFDekIsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFlBQVksQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLEVBQUU7WUFDNUMsSUFBTSxlQUFlLEdBQUcsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsR0FBRyxHQUFHLENBQUM7WUFDeEQsSUFBSSxnQkFBZ0IsR0FBRyxLQUFLLENBQUM7WUFDN0IsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxZQUFZLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxFQUFFO2dCQUNoRCxJQUFJLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsRUFBRTtvQkFDNUQsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDO29CQUN4QixNQUFNO2lCQUNQO2FBQ0Y7WUFDRCxJQUFJLGdCQUFnQixFQUFFO2dCQUNwQixJQUFNLEtBQUssR0FBRyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDbkQsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsSUFBSSxJQUFJLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDO2FBQ25FO1NBQ0Y7SUFDSCxDQUFDO0lBNUJlLG1EQUE2QixnQ0E0QjVDLENBQUE7SUFFRDs7Ozs7T0FLRztJQUNILHFDQUE0QyxRQUFnQjtRQUMxRCxJQUFJLFFBQVEsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLEVBQUU7WUFDMUIsT0FBTyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxRQUFRLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7U0FDdEQ7YUFBTTtZQUNMLE9BQU8sUUFBUSxDQUFDO1NBQ2pCO0lBQ0gsQ0FBQztJQU5lLGlEQUEyQiw4QkFNMUMsQ0FBQTtJQUVELG9DQUEyQyxTQUFtQjtRQUM1RCxJQUFNLGtCQUFrQixHQUFhLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ2xELElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxzQkFBQSxtQkFBbUIsQ0FBQyxFQUFFO1lBQzNDLElBQUksVUFBVSxHQUFHLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUM5QixJQUFJLFVBQVUsQ0FBQyxVQUFVLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxLQUFLLEdBQUcsRUFBRTtnQkFDN0MsVUFBVSxHQUFHLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLFVBQVUsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUM7YUFDekQ7WUFDRCxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsR0FBRyxVQUFVLENBQUM7WUFDbkMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLEdBQUcsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7U0FDdEQ7YUFBTTtZQUNMLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxHQUFHLFNBQVMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7U0FDN0M7UUFDRCxPQUFPLGtCQUFrQixDQUFDO0lBQzVCLENBQUM7SUFiZSxnREFBMEIsNkJBYXpDLENBQUE7SUFFRCxJQUFZLG9CQUdYO0lBSEQsV0FBWSxvQkFBb0I7UUFDOUIsdUVBQVEsQ0FBQTtRQUNSLG1FQUFNLENBQUE7SUFDUixDQUFDLEVBSFcsb0JBQW9CLEdBQXBCLDBDQUFvQixLQUFwQiwwQ0FBb0IsUUFHL0I7SUFFRDs7Ozs7Ozs7T0FRRztJQUNILDRCQUNJLFlBQTBCLEVBQzFCLFVBQWdDLEVBQ2hDLFdBQW1CO1FBQ3JCLElBQUksVUFBVSxLQUFLLG9CQUFvQixDQUFDLFFBQVEsRUFBRTtZQUNoRCxPQUFPLFlBQVksQ0FBQyxNQUFNLENBQ3RCLFVBQUEsVUFBVSxJQUFJLE9BQUEsVUFBVSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLEVBQXZDLENBQXVDLENBQUMsQ0FBQztTQUM1RDthQUFNLElBQUksVUFBVSxLQUFLLG9CQUFvQixDQUFDLE1BQU0sRUFBRTtZQUNyRCxPQUFPLFlBQVksQ0FBQyxNQUFNLENBQ3RCLFVBQUEsVUFBVSxJQUFJLE9BQUEsVUFBVSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLEVBQXJDLENBQXFDLENBQUMsQ0FBQztTQUMxRDtJQUNILENBQUM7SUFYZSx3Q0FBa0IscUJBV2pDLENBQUE7SUFFRDtRQW1CRSwyQkFDSSxJQUFZLEVBQ0gsZ0JBQWtDLEVBQzNDLE1BQTBCLEVBQ2pCLFVBQXVCO1lBSnBDLGlCQWlCQztZQWZZLHFCQUFnQixHQUFoQixnQkFBZ0IsQ0FBa0I7WUFFbEMsZUFBVSxHQUFWLFVBQVUsQ0FBYTtZQUNsQyxJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQztZQUNqQixJQUFJLENBQUMsVUFBVSxHQUFHLFVBQVUsQ0FBQztZQUU3QixzQkFBc0I7WUFDdEIsSUFBSSxDQUFDLGFBQWEsR0FBRyxhQUFhLENBQUMsS0FBSyxDQUFDO1lBQ3pDLElBQUksQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDO1lBQ3JCLElBQUksQ0FBQyxRQUFRLEdBQUcsRUFBRSxDQUFDO1lBRW5CLElBQUksQ0FBQyxRQUFRLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO1lBQ3pELElBQUksQ0FBQyxRQUFRLENBQUMsZ0JBQWdCLENBQUMsUUFBUSxFQUFFO2dCQUN2QyxLQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7WUFDdkIsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDO1FBQ1osQ0FBQztRQUVELHlDQUFhLEdBQWI7WUFDRSxJQUFJLElBQUksQ0FBQyxnQkFBZ0IsRUFBRTtnQkFDekIsb0JBQW9CO2dCQUNwQixJQUFJLElBQUksQ0FBQyxVQUFVLEVBQUU7b0JBQ25CLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFFLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDLENBQUM7aUJBQ2xFO2dCQUNELE9BQU87YUFDUjtZQUVELElBQUksSUFBSSxDQUFDLFVBQVUsRUFBRTtnQkFDbkIsdUJBQXVCO2dCQUN2QixJQUFJLENBQUMsZ0JBQWdCLENBQ2pCLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDLENBQUM7b0JBQ3RCLGFBQWEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxLQUFLLEVBQy9DLElBQUksQ0FBQyxDQUFDO2dCQUNWLElBQUksSUFBSSxDQUFDLGlCQUFpQixFQUFFLEVBQUU7b0JBQzVCLG1FQUFtRTtvQkFDbkUsaURBQWlEO29CQUNqRCxJQUFJLENBQUMsc0JBQXNCLEVBQUUsQ0FBQztpQkFDL0I7cUJBQU07b0JBQ0wscUVBQXFFO29CQUNyRSxlQUFlO29CQUNmLElBQUksQ0FBQyxvQkFBb0IsRUFBRSxDQUFDO2lCQUM3QjtnQkFDRCxvQkFBb0I7Z0JBQ3BCLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFFLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDLENBQUM7YUFDbEU7aUJBQU07Z0JBQ0wsdUJBQXVCO2dCQUN2QixJQUFJLENBQUMsZ0JBQWdCLENBQ2pCLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDLENBQUM7b0JBQ3RCLGFBQWEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxLQUFLLEVBQy9DLElBQUksQ0FBQyxDQUFDO2dCQUNWLElBQUksSUFBSSxDQUFDLGlCQUFpQixFQUFFLEVBQUU7b0JBQzVCLGdDQUFnQztvQkFDaEMsSUFBTSxhQUFXLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUF3QixDQUFDO29CQUNuRSxPQUFPLGFBQVcsQ0FBQyxNQUFNLEVBQUU7d0JBQ3pCLElBQUksSUFBSSxHQUFHLGFBQVcsQ0FBQyxHQUFHLEVBQUUsQ0FBQzt3QkFDN0IsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLFVBQUEsS0FBSyxJQUFJLE9BQUEsYUFBVyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsRUFBdkIsQ0FBdUIsQ0FBQyxDQUFDO3dCQUMzRCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsYUFBYSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsQ0FBQztxQkFDcEQ7b0JBRUQseUJBQXlCO29CQUN6QixJQUFJLENBQUMsc0JBQXNCLEVBQUUsQ0FBQztpQkFDL0I7cUJBQU07b0JBQ0wsa0NBQWtDO29CQUNsQyxJQUFNLGFBQVcsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQXdCLENBQUM7b0JBQ25FLE9BQU8sYUFBVyxDQUFDLE1BQU0sRUFBRTt3QkFDekIsSUFBSSxJQUFJLEdBQUcsYUFBVyxDQUFDLEdBQUcsRUFBRSxDQUFDO3dCQUM3QixDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsVUFBQSxLQUFLLElBQUksT0FBQSxhQUFXLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUF2QixDQUF1QixDQUFDLENBQUM7d0JBQzNELElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxhQUFhLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxDQUFDO3FCQUNsRDtvQkFFRCx5QkFBeUI7b0JBQ3pCLElBQUksQ0FBQyxvQkFBb0IsRUFBRSxDQUFDO2lCQUM3QjthQUNGO1FBQ0gsQ0FBQztRQUVELGtDQUFNLEdBQU47WUFDRSxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDO1FBQzNCLENBQUM7UUFFRCxxREFBeUIsR0FBekI7WUFDRSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQzdDLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUN2QixDQUFDO1FBRUQsNENBQWdCLEdBQWhCLFVBQWlCLEtBQW9CLEVBQUUsZ0JBQTBCO1lBQy9ELElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxnQkFBZ0IsQ0FBQztZQUN6QyxJQUFJLENBQUMsYUFBYSxHQUFHLEtBQUssQ0FBQztZQUUzQixJQUFJLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQzFCLGtCQUFrQixFQUFFLEtBQUssS0FBSyxhQUFhLENBQUMsT0FBTyxDQUFDLENBQUM7WUFFekQsSUFBSSxLQUFLLEtBQUssYUFBYSxDQUFDLE9BQU8sRUFBRTtnQkFDbkMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsU0FBUyxFQUFFLFNBQVMsQ0FBQyxDQUFDO2FBQ2xEO2lCQUFNO2dCQUNMLElBQUksQ0FBQyxRQUFRLENBQUMsZUFBZSxDQUFDLFNBQVMsQ0FBQyxDQUFDO2FBQzFDO1lBRUQsSUFBSSxDQUFDLGdCQUFnQixHQUFHLEtBQUssQ0FBQztRQUNoQyxDQUFDO1FBRU8sNkNBQWlCLEdBQXpCO1lBQ0UsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUMvQyxDQUFDO1FBRUQsa0RBQXNCLEdBQXRCO1lBQ0UsSUFBSSxXQUFXLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQztZQUM5QixJQUFJLFlBQVksR0FBRyxLQUFLLENBQUM7WUFDekIsT0FBTyxXQUFXLEVBQUU7Z0JBQ2xCLElBQUksWUFBWSxFQUFFO29CQUNoQixnRUFBZ0U7b0JBQ2hFLHlEQUF5RDtvQkFDekQsV0FBVyxDQUFDLGdCQUFnQixDQUFDLGFBQWEsQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUM7aUJBQzNEO3FCQUFNO29CQUNMLElBQU0sS0FBSyxHQUFHLENBQUMsQ0FBQyxTQUFTLENBQ3JCLENBQUMsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBd0IsRUFDckQsVUFBQSxLQUFLLElBQUksT0FBQSxDQUFDLEtBQUssQ0FBQyxhQUFhLEtBQUssYUFBYSxDQUFDLE9BQU8sQ0FBQyxFQUEvQyxDQUErQyxDQUFDLENBQUM7b0JBQzlELHdEQUF3RDtvQkFDeEQsWUFBWSxHQUFHLEtBQUssS0FBSyxDQUFDLENBQUMsQ0FBQztvQkFDNUIsV0FBVyxDQUFDLGdCQUFnQixDQUN4QixZQUFZLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUM7aUJBQ3pFO2dCQUNELG9CQUFvQjtnQkFDcEIsV0FBVyxHQUFHLFdBQVcsQ0FBQyxNQUFNLENBQUM7YUFDbEM7UUFDSCxDQUFDO1FBRUQsZ0RBQW9CLEdBQXBCO1lBQ0UsSUFBSSxXQUFXLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQztZQUM5QixJQUFJLFlBQVksR0FBRyxLQUFLLENBQUM7WUFDekIsT0FBTyxXQUFXLEVBQUU7Z0JBQ2xCLElBQUksWUFBWSxFQUFFO29CQUNoQixnRUFBZ0U7b0JBQ2hFLHlEQUF5RDtvQkFDekQsV0FBVyxDQUFDLGdCQUFnQixDQUFDLGFBQWEsQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUM7aUJBQzNEO3FCQUFNO29CQUNMLElBQU0sS0FBSyxHQUFHLENBQUMsQ0FBQyxTQUFTLENBQ3JCLENBQUMsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBd0IsRUFDckQsVUFBQSxLQUFLLElBQUksT0FBQSxDQUFDLEtBQUssQ0FBQyxhQUFhLEtBQUssYUFBYSxDQUFDLEtBQUssQ0FBQyxFQUE3QyxDQUE2QyxDQUFDLENBQUM7b0JBQzVELHNEQUFzRDtvQkFDdEQsWUFBWSxHQUFHLEtBQUssS0FBSyxDQUFDLENBQUMsQ0FBQztvQkFDNUIsV0FBVyxDQUFDLGdCQUFnQixDQUN4QixZQUFZLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxLQUFLLEVBQUUsSUFBSSxDQUFDLENBQUM7aUJBQ3ZFO2dCQUNELG9CQUFvQjtnQkFDcEIsV0FBVyxHQUFHLFdBQVcsQ0FBQyxNQUFNLENBQUM7YUFDbEM7UUFDSCxDQUFDO1FBRUQsdUNBQVcsR0FBWCxVQUFZLFFBQVE7WUFDbEIsSUFBSSxDQUFDLFFBQVEsR0FBRyxRQUFRLENBQUM7UUFDM0IsQ0FBQztRQUNILHdCQUFDO0lBQUQsQ0FBQyxBQTVLRCxJQTRLQztJQTVLWSx1Q0FBaUIsb0JBNEs3QixDQUFBO0FBRUQsQ0FBQyxFQXRWUyxxQkFBcUIsS0FBckIscUJBQXFCLFFBc1Y5QixDQUFFLGtDQUFrQyIsInNvdXJjZXNDb250ZW50IjpbIi8qIENvcHlyaWdodCAyMDE3IFRoZSBUZW5zb3JGbG93IEF1dGhvcnMuIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG5cbkxpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSAnTGljZW5zZScpO1xueW91IG1heSBub3QgdXNlIHRoaXMgZmlsZSBleGNlcHQgaW4gY29tcGxpYW5jZSB3aXRoIHRoZSBMaWNlbnNlLlxuWW91IG1heSBvYnRhaW4gYSBjb3B5IG9mIHRoZSBMaWNlbnNlIGF0XG5cbiAgICBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcblxuVW5sZXNzIHJlcXVpcmVkIGJ5IGFwcGxpY2FibGUgbGF3IG9yIGFncmVlZCB0byBpbiB3cml0aW5nLCBzb2Z0d2FyZVxuZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIExpY2Vuc2UgaXMgZGlzdHJpYnV0ZWQgb24gYW4gJ0FTIElTJyBCQVNJUyxcbldJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWSBLSU5ELCBlaXRoZXIgZXhwcmVzcyBvciBpbXBsaWVkLlxuU2VlIHRoZSBMaWNlbnNlIGZvciB0aGUgc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nIHBlcm1pc3Npb25zIGFuZFxubGltaXRhdGlvbnMgdW5kZXIgdGhlIExpY2Vuc2UuXG49PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0qL1xubmFtZXNwYWNlIHRmX2RlYnVnZ2VyX2Rhc2hib2FyZCB7XG5cbi8qKlxuICogQSBzdHJpbmcgdXNlZCB0byBzZXBhcmF0ZSBwYXJ0cyBvZiBhIG5vZGUgbmFtZS4gU2hvdWxkIGJlIGtlcHQgY29uc2lzdGVudFxuICogd2l0aCB0aGUgZ3JhcGggY29tcG9uZW50LlxuICovXG5leHBvcnQgY29uc3QgTk9ERV9OQU1FX1NFUEFSQVRPUiA9ICcvJztcbmV4cG9ydCBjb25zdCBERVZJQ0VfTkFNRV9QQVRURVJOID1cbiAgICAvXlxcL2pvYjpbQS1aYS16MC05X10rXFwvcmVwbGljYTpbMC05X10rXFwvdGFzazpbMC05XStcXC9kZXZpY2U6W0EtWmEtejAtOV9dKzpbMC05XSsvO1xuXG4vLyBBIGNoZWNrYm94IGlzIHBhcnRpYWxseSBjaGVja2VkIGlmIGl0IGlzIGEgY2hlY2tib3ggZm9yIGEgbm9uLWxlYWYgbm9kZSBhbmRcbi8vIHNvbWUgKGJ1dCBub3QgYWxsKSBvZiBpdHMgY2hpbGRyZW4gYXJlIGNoZWNrZWQuXG5leHBvcnQgZW51bSBDaGVja2JveFN0YXRlIHtFTVBUWSwgQ0hFQ0tFRCwgUEFSVElBTH07XG5cbmV4cG9ydCBpbnRlcmZhY2UgRGVidWdXYXRjaCB7XG4gIG5vZGVfbmFtZTogc3RyaW5nO1xuICBvcF90eXBlOiBzdHJpbmc7XG4gIG91dHB1dF9zbG90OiBudW1iZXI7XG4gIGRlYnVnX29wOiBzdHJpbmc7XG59XG5cbi8qKiBGdW5jdGlvbiB0aGF0IHRha2VzIGFjdGlvbiBiYXNlZCBvbiBpdGVtIGNsaWNrZWQgaW4gdGhlIGNvbnRleHQgbWVudS4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgRGVidWdXYXRjaENoYW5nZSB7XG4gIChkZWJ1Z1dhdGNoOiBEZWJ1Z1dhdGNoLCBjaGVja2VkOiBib29sZWFuKTogdm9pZDtcbn1cblxuLyoqXG4gKiBTcGxpdCBhIG5vZGUgbmFtZSwgcG90ZW50aWFsbHkgd2l0aCBhIGRldmljZSBuYW1lIHByZWZpeC5cbiAqIEBwYXJhbSBuYW1lOiBJbnB1dCBub2RlIG5hbWUsIHBvdGVudGlhbGx5IHdpdGggYSBkZXZpY2UgbmFtZSBwcmVmaXgsIGUuZy4sXG4gKiAgICcvam9iOmxvY2FsaG9zdC9yZXBsaWNhOjAvdGFzazowL2RldmljZTpDUFU6MC9EZW5zZS9CaWFzQWRkJ1xuICogQHJldHVybiBTcGxpdCBpdGVtcy4gVGhlIGRldmljZSBuYW1lLCBpZiBwcmVzZW50LCB3aWxsIGJlIHRoZSBmaXJzdCBpdGVtLlxuICovXG5leHBvcnQgZnVuY3Rpb24gc3BsaXROb2RlTmFtZShuYW1lOiBzdHJpbmcpOiBzdHJpbmdbXSB7XG4gIGxldCBpdGVtcyA9IFtdO1xuICBjb25zdCBkZXZpY2VOYW1lTWF0Y2hlcyA9IG5hbWUubWF0Y2goREVWSUNFX05BTUVfUEFUVEVSTik7XG4gIGxldCBub2RlTmFtZSA9IG5hbWU7XG4gIGlmIChkZXZpY2VOYW1lTWF0Y2hlcyAhPSBudWxsKSB7XG4gICAgaXRlbXMucHVzaChkZXZpY2VOYW1lTWF0Y2hlc1swXSk7XG4gICAgLy8gRXhwZWN0IHRoZXJlIHRvIGJlIGEgc2xhc2ggYWZ0ZXIgdGhlIGRldmljZSBuYW1lLCBhbmQgc2tpcCBpdC5cbiAgICBpZiAobm9kZU5hbWVbZGV2aWNlTmFtZU1hdGNoZXNbMF0ubGVuZ3RoXSAhPT0gJy8nKSB7XG4gICAgICBjb25zb2xlLmVycm9yKCdObyBzbGFzaCAoXCIvXCIpIGFmdGVyIGRldmljZSBuYW1lIGluIG5vZGUgbmFtZTonLCBub2RlTmFtZSk7XG4gICAgfVxuICAgIG5vZGVOYW1lID0gbm9kZU5hbWUuc2xpY2UoZGV2aWNlTmFtZU1hdGNoZXNbMF0ubGVuZ3RoICsgMSk7XG4gIH1cbiAgcmV0dXJuIGl0ZW1zLmNvbmNhdChub2RlTmFtZS5zcGxpdChOT0RFX05BTUVfU0VQQVJBVE9SKSk7XG59XG5cbi8qKlxuICogR2V0IGEgbm9kZSBuYW1lIHdpdGhvdXQgZGV2aWNlIG5hbWUgcHJlZml4IG9yIGJhc2UtZXhwYW5zaW9uIHN1ZmZpeC5cbiAqIEBwYXJhbSBuYW1lOiBUaGUgbm9kZSBuYW1lLCBwb3NzaWJseSB3aXRoIGEgZGV2aWNlIG5hbWUgcHJlZml4LCBlLmcuLFxuICogICAnL2pvYjpsb2NhbGhvc3QvcmVwbGljYTowL3Rhc2s6MC9kZXZpY2U6Q1BVOjAvRGVuc2UvQmlhc0FkZCdcbiAqIEByZXR1cm4gVGhlIG5vZGUgbmFtZSB3aXRob3V0IGFueSBkZXZpY2UgbmFtZSBwcmVmaXhlcyBvciAnLycgYXQgdGhlIGZyb250LlxuICogICBFLmcuLCAnRGVuc2UvQmlhc0FkZCdcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdldENsZWFuTm9kZU5hbWUobmFtZTogc3RyaW5nKTogc3RyaW5nIHtcbiAgbGV0IGNsZWFuTmFtZSA9IG5hbWU7XG4gIGNvbnN0IGRldmljZU5hbWVNYXRjaGVzID0gbmFtZS5tYXRjaChERVZJQ0VfTkFNRV9QQVRURVJOKTtcbiAgaWYgKGRldmljZU5hbWVNYXRjaGVzICE9IG51bGwpIHtcbiAgICBpZiAoY2xlYW5OYW1lLmxlbmd0aCA+IGRldmljZU5hbWVNYXRjaGVzWzBdLmxlbmd0aCAmJlxuICAgICAgICBjbGVhbk5hbWVbZGV2aWNlTmFtZU1hdGNoZXNbMF0ubGVuZ3RoXSAhPSAnLycpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ05vIHNsYXNoIChcIi9cIikgYWZ0ZXIgZGV2aWNlIG5hbWUgaW4gbm9kZSBuYW1lOicsIG5hbWUpO1xuICAgIH1cbiAgICBjbGVhbk5hbWUgPSBjbGVhbk5hbWUuc2xpY2UoZGV2aWNlTmFtZU1hdGNoZXNbMF0ubGVuZ3RoICsgMSk7XG4gIH0gZWxzZSB7XG4gICAgaWYgKGNsZWFuTmFtZVswXSA9PT0gJy8nKSB7XG4gICAgICBjbGVhbk5hbWUgPSBjbGVhbk5hbWUuc2xpY2UoMSk7XG4gICAgfVxuICB9XG4gIC8vIFJlbW92ZSBhbnkgYmFzZS1leHBhbnNpb24gc3VmZml4LlxuICBpZiAoY2xlYW5OYW1lLmluZGV4T2YoJyknKSA9PT0gY2xlYW5OYW1lLmxlbmd0aCAtIDEpIHtcbiAgICBjbGVhbk5hbWUgPSBjbGVhbk5hbWUuc2xpY2UoMCwgY2xlYW5OYW1lLmluZGV4T2YoJy8oJykpO1xuICB9XG4gIHJldHVybiBjbGVhbk5hbWU7XG59XG5cbi8qKlxuICogU29ydCBhbmQgYmFzZS1leHBhbmQgYW4gQXJyYXkgb2YgRGVidWdXYXRjaGVzIGluIHBsYWNlLlxuICogXCJCYXNlLWV4cGFuZFwiIG1lYW5zIGFkZGluZyBhICcvKGJhc2VOYW1lKScgc3VmZml4IHRvIG5vZGVzIHdob3NlIG5hbWVzIGFyZVxuICogdGhlIG5hbWUgc2NvcGUgb2Ygc29tZSBvdGhlciBub2RlJ3MgbmFtZS5cbiAqIEBwYXJhbSBkZWJ1Z1dhdGNoZXM6IEFuIGFycmF5IG9mIGBEZWJ1Z1dhdGNoYGVzIHRvIHNvcnQgYW5kIGJhc2UtZXhwYW5kLlxuICogQHJldHVybnMgU29ydGVkIGFuZCBiYXNlLWV4cGFuZGVkIGBEZWJ1Z1dhdGNoYGVzLlxuICovXG5leHBvcnQgZnVuY3Rpb24gc29ydEFuZEJhc2VFeHBhbmREZWJ1Z1dhdGNoZXMoZGVidWdXYXRjaGVzOiBEZWJ1Z1dhdGNoW10pIHtcbiAgLy8gU29ydCB0aGUgZGVidWcgd2F0Y2hlcy5cbiAgZGVidWdXYXRjaGVzLnNvcnQoKHdhdGNoMSwgd2F0Y2gyKSA9PiB7XG4gICAgaWYgKHdhdGNoMS5ub2RlX25hbWUgPCB3YXRjaDIubm9kZV9uYW1lKSB7XG4gICAgICByZXR1cm4gLTE7XG4gICAgfSBlbHNlIGlmICh3YXRjaDEubm9kZV9uYW1lID4gd2F0Y2gyLm5vZGVfbmFtZSkge1xuICAgICAgcmV0dXJuIDE7XG4gICAgfSBlbHNlIHtcbiAgICAgIHJldHVybiB3YXRjaDEub3V0cHV0X3Nsb3QgLSB3YXRjaDIub3V0cHV0X3Nsb3Q7XG4gICAgfVxuICB9KTtcblxuICAvLyBGaW5kIGxlYWYgbm9kZXMgdGhhdCBuZWVkIHRvIGJlIGJhc2UtZXhwYW5kZWQgZHVlIHRvIHRoZWlyIG5hbWVzIGJlaW5nIGFcbiAgLy8gcHJlZml4IG9mIG90aGVyIG5vZGVzLlxuICBmb3IgKGxldCBpID0gMDsgaSA8IGRlYnVnV2F0Y2hlcy5sZW5ndGg7ICsraSkge1xuICAgIGNvbnN0IHdpdGhTbGFzaFN1ZmZpeCA9IGRlYnVnV2F0Y2hlc1tpXS5ub2RlX25hbWUgKyAnLyc7XG4gICAgbGV0IHRvQmFzZUV4cGFuZExlYWYgPSBmYWxzZTtcbiAgICBmb3IgKGxldCBqID0gaSArIDE7IGogPCBkZWJ1Z1dhdGNoZXMubGVuZ3RoOyArK2opIHtcbiAgICAgIGlmIChkZWJ1Z1dhdGNoZXNbal0ubm9kZV9uYW1lLmluZGV4T2Yod2l0aFNsYXNoU3VmZml4KSA9PT0gMCkge1xuICAgICAgICB0b0Jhc2VFeHBhbmRMZWFmID0gdHJ1ZTtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgfVxuICAgIGlmICh0b0Jhc2VFeHBhbmRMZWFmKSB7XG4gICAgICBjb25zdCBpdGVtcyA9IGRlYnVnV2F0Y2hlc1tpXS5ub2RlX25hbWUuc3BsaXQoJy8nKTtcbiAgICAgIGRlYnVnV2F0Y2hlc1tpXS5ub2RlX25hbWUgKz0gJy8oJyArIGl0ZW1zW2l0ZW1zLmxlbmd0aCAtIDFdICsgJyknO1xuICAgIH1cbiAgfVxufVxuXG4vKipcbiAqIFJlbW92ZSBhbnkgcG9zc2libGUgYmFzZSBleHBhbnNpb24gZnJvbSBhIG5vZGUgbmFtZS5cbiAqIEBwYXJhbSBub2RlTmFtZTogVGhlIG5vZGUgbmFtZSwgcG9zc2libHkgd2l0aCBiYXNlIGV4cGFuc2lvbi5cbiAqIEByZXR1cm5zOiBOb2RlIG5hbWUgd2l0aCBhbnkgYmFzZSBleHBhbnNpb24gcmVtb3ZlZC4gSWYgYG5vZGVOYW1lYCBkb2VzIG5vdFxuICogICBjb250YWluIGFueSBiYXNlIGV4cGFuc2lvbiwgdGhlIHN0cmluZyBpcyByZXR1cm5lZCB3aXRob3V0IG1vZGlmaWNhdGlvbi5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHJlbW92ZU5vZGVOYW1lQmFzZUV4cGFuc2lvbihub2RlTmFtZTogc3RyaW5nKSB7XG4gIGlmIChub2RlTmFtZS5lbmRzV2l0aCgnKScpKSB7XG4gICAgcmV0dXJuIG5vZGVOYW1lLnNsaWNlKDAsIG5vZGVOYW1lLmxhc3RJbmRleE9mKCcvKCcpKTtcbiAgfSBlbHNlIHtcbiAgICByZXR1cm4gbm9kZU5hbWU7XG4gIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGFzc2VtYmxlRGV2aWNlQW5kTm9kZU5hbWVzKG5hbWVJdGVtczogc3RyaW5nW10pOiBzdHJpbmdbXSB7XG4gIGNvbnN0IGRldmljZUFuZE5vZGVOYW1lczogc3RyaW5nW10gPSBbbnVsbCwgbnVsbF07XG4gIGlmIChuYW1lSXRlbXNbMF0ubWF0Y2goREVWSUNFX05BTUVfUEFUVEVSTikpIHtcbiAgICBsZXQgZGV2aWNlTmFtZSA9IG5hbWVJdGVtc1swXTtcbiAgICBpZiAoZGV2aWNlTmFtZVtkZXZpY2VOYW1lLmxlbmd0aCAtIDFdID09PSAnLycpIHtcbiAgICAgIGRldmljZU5hbWUgPSBkZXZpY2VOYW1lLnNsaWNlKDAsIGRldmljZU5hbWUubGVuZ3RoIC0gMSk7XG4gICAgfVxuICAgIGRldmljZUFuZE5vZGVOYW1lc1swXSA9IGRldmljZU5hbWU7XG4gICAgZGV2aWNlQW5kTm9kZU5hbWVzWzFdID0gbmFtZUl0ZW1zLnNsaWNlKDEpLmpvaW4oJy8nKTtcbiAgfSBlbHNlIHtcbiAgICBkZXZpY2VBbmROb2RlTmFtZXNbMV0gPSBuYW1lSXRlbXMuam9pbignLycpO1xuICB9XG4gIHJldHVybiBkZXZpY2VBbmROb2RlTmFtZXM7XG59XG5cbmV4cG9ydCBlbnVtIERlYnVnV2F0Y2hGaWx0ZXJNb2RlIHtcbiAgTm9kZU5hbWUsXG4gIE9wVHlwZSxcbn1cblxuLyoqXG4gKiBGaWx0ZXIgZGVidWcgd2F0Y2hlcyBhY2NvcmRpbmcgdG8gZ2l2ZW4gZmlsdGVyIG1vZGUgYW5kIGZpbHRlciBpbnB1dC5cbiAqIEBwYXJhbSBkZWJ1Z1dhdGNoZXMgQW4gYXJyYXkgb2YgYERlYnVnV2F0Y2hgIGluc3RhbmNlcy5cbiAqIEBwYXJhbSBmaWx0ZXJNb2RlXG4gKiBAcGFyYW0gZmlsdGVyUmVnZXggRmlsdGVyIHJlZ3VsYXIgZXhwcmVzc2lvbiwgZS5nLiwgZm9yXG4gKiAgIGZpbHRlck1vZGUgPT09ICdPcCBUeXBlJzogJ1ZhcmlhYmxlLicuXG4gKiBAcmV0dXJucyBBbiBhcnJheSBvZiBgRGVidWdXYXRjaGAgaW5zdGFuY2VzIGZyb20gdGhlIGlucHV0IGBkZWJ1Z1dhdGNoZXNgXG4gKiAgIHRoYXQgcGFzcyB0aGUgZmlsdGVyLlxuICovXG5leHBvcnQgZnVuY3Rpb24gZmlsdGVyRGVidWdXYXRjaGVzKFxuICAgIGRlYnVnV2F0Y2hlczogRGVidWdXYXRjaFtdLFxuICAgIGZpbHRlck1vZGU6IERlYnVnV2F0Y2hGaWx0ZXJNb2RlLFxuICAgIGZpbHRlclJlZ2V4OiBSZWdFeHApOiBEZWJ1Z1dhdGNoW10ge1xuICBpZiAoZmlsdGVyTW9kZSA9PT0gRGVidWdXYXRjaEZpbHRlck1vZGUuTm9kZU5hbWUpIHtcbiAgICByZXR1cm4gZGVidWdXYXRjaGVzLmZpbHRlcihcbiAgICAgICAgZGVidWdXYXRjaCA9PiBkZWJ1Z1dhdGNoLm5vZGVfbmFtZS5tYXRjaChmaWx0ZXJSZWdleCkpO1xuICB9IGVsc2UgaWYgKGZpbHRlck1vZGUgPT09IERlYnVnV2F0Y2hGaWx0ZXJNb2RlLk9wVHlwZSkge1xuICAgIHJldHVybiBkZWJ1Z1dhdGNoZXMuZmlsdGVyKFxuICAgICAgICBkZWJ1Z1dhdGNoID0+IGRlYnVnV2F0Y2gub3BfdHlwZS5tYXRjaChmaWx0ZXJSZWdleCkpO1xuICB9XG59XG5cbmV4cG9ydCBjbGFzcyBTZWxlY3Rpb25UcmVlTm9kZSB7XG4gIG5hbWU6IHN0cmluZztcbiAgcGFyZW50OiBTZWxlY3Rpb25UcmVlTm9kZTtcblxuICAvLyBNYXBzIGZyb20gdGhlIG5hbWUgYXQgdGhlIGN1cnJlbnQgbGV2ZWwgdG8gdGhlIHRyZWUgbm9kZS5cbiAgY2hpbGRyZW46IHtba2V5OiBzdHJpbmddOiBTZWxlY3Rpb25UcmVlTm9kZX07XG5cbiAgLy8gT25sdCBsZWFmIG5vZGVzIGhhdmUgZGVidWcgd2F0Y2hlcy5cbiAgaXNSb290OiBib29sZWFuO1xuXG4gIGNoZWNrYm94U3RhdGU6IENoZWNrYm94U3RhdGU7XG4gIGNoZWNrYm94OiBFbGVtZW50O1xuICBsZXZlbERvbTogRWxlbWVudDtcblxuICAvLyBJZiB0aGlzIGlzIHNldCwgdG9nZ2xpbmcgdGhlIGNoZWNrYm94IHdvbid0IHByb21wdCBhbmNlc3RvciBvciBjaGlsZHJlblxuICAvLyBub2RlcyB0byB1cGRhdGUuIFVzZWQgZm9yIHVwZGF0aW5nIHZhcmlvdXMgY2hlY2tib3hlcyBzbyB0aGF0IGludmFyaWFudHNcbiAgLy8gYXJlIGhlbGQsIGllLCBpZiBhIG1ldGFub2RlIGlzIGNoZWNrZWQsIGFsbCBub2RlcyB1bmRlciBpdCBhcmUgY2hlY2tlZC5cbiAgcHJpdmF0ZSBhdm9pZFByb3BhZ2F0aW9uOiBib29sZWFuO1xuXG4gIGNvbnN0cnVjdG9yKFxuICAgICAgbmFtZTogc3RyaW5nLFxuICAgICAgcmVhZG9ubHkgZGVidWdXYXRjaENoYW5nZTogRGVidWdXYXRjaENoYW5nZSxcbiAgICAgIHBhcmVudD86IFNlbGVjdGlvblRyZWVOb2RlLFxuICAgICAgcmVhZG9ubHkgZGVidWdXYXRjaD86IERlYnVnV2F0Y2gpIHtcbiAgICB0aGlzLm5hbWUgPSBuYW1lO1xuICAgIHRoaXMuZGVidWdXYXRjaCA9IGRlYnVnV2F0Y2g7XG5cbiAgICAvLyBXZSBzdGFydCBvdXQgZW1wdHkuXG4gICAgdGhpcy5jaGVja2JveFN0YXRlID0gQ2hlY2tib3hTdGF0ZS5FTVBUWTtcbiAgICB0aGlzLnBhcmVudCA9IHBhcmVudDtcbiAgICB0aGlzLmNoaWxkcmVuID0ge307XG5cbiAgICB0aGlzLmNoZWNrYm94ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgncGFwZXItY2hlY2tib3gnKTtcbiAgICB0aGlzLmNoZWNrYm94LmFkZEV2ZW50TGlzdGVuZXIoJ2NoYW5nZScsICgpID0+IHtcbiAgICAgIHRoaXMuX2hhbmRsZUNoYW5nZSgpO1xuICAgIH0sIGZhbHNlKTtcbiAgfVxuXG4gIF9oYW5kbGVDaGFuZ2UoKSB7XG4gICAgaWYgKHRoaXMuYXZvaWRQcm9wYWdhdGlvbikge1xuICAgICAgLy8gRG8gbm90IHByb3BhZ2F0ZS5cbiAgICAgIGlmICh0aGlzLmRlYnVnV2F0Y2gpIHtcbiAgICAgICAgdGhpcy5kZWJ1Z1dhdGNoQ2hhbmdlKHRoaXMuZGVidWdXYXRjaCwgdGhpcy5pc0NoZWNrYm94Q2hlY2tlZCgpKTtcbiAgICAgIH1cbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBpZiAodGhpcy5kZWJ1Z1dhdGNoKSB7XG4gICAgICAvLyBUaGlzIGlzIGEgbGVhZiBub2RlLlxuICAgICAgdGhpcy5zZXRDaGVja2JveFN0YXRlKFxuICAgICAgICAgIHRoaXMuaXNDaGVja2JveENoZWNrZWQoKSA/XG4gICAgICAgICAgICAgIENoZWNrYm94U3RhdGUuQ0hFQ0tFRCA6IENoZWNrYm94U3RhdGUuRU1QVFksXG4gICAgICAgICAgdHJ1ZSk7XG4gICAgICBpZiAodGhpcy5pc0NoZWNrYm94Q2hlY2tlZCgpKSB7XG4gICAgICAgIC8vIEEgY2hlY2tib3gganVzdCBnb3QgY2hlY2tlZC4gQWxsIG5vZGVzIGFib3ZlIHRoaXMgb25lIGFyZSBlaXRoZXJcbiAgICAgICAgLy8gcGFydGlhbCBvciBjb21wbGV0ZS4gR28gdXAgdGhlIHRyZWUgYW5kIGNoZWNrLlxuICAgICAgICB0aGlzLnNldE5vZGVzQWJvdmVUb0NoZWNrZWQoKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIC8vIEEgY2hlY2tib3ggZ290IHVuY2hlY2tlZC4gQWxsIG5vZGVzIGFib3ZlIHRoaXMgYXJlIGVpdGhlciBlbXB0eSBvclxuICAgICAgICAvLyBwYXJ0aWFsIG5vdy5cbiAgICAgICAgdGhpcy5zZXROb2Rlc0Fib3ZlVG9FbXB0eSgpO1xuICAgICAgfVxuICAgICAgLy8gUnVuIHRoZSBjYWxsYmFjay5cbiAgICAgIHRoaXMuZGVidWdXYXRjaENoYW5nZSh0aGlzLmRlYnVnV2F0Y2gsIHRoaXMuaXNDaGVja2JveENoZWNrZWQoKSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIC8vIFRoaXMgaXMgYSBtZXRhIG5vZGUuXG4gICAgICB0aGlzLnNldENoZWNrYm94U3RhdGUoXG4gICAgICAgICAgdGhpcy5pc0NoZWNrYm94Q2hlY2tlZCgpID9cbiAgICAgICAgICAgICAgQ2hlY2tib3hTdGF0ZS5DSEVDS0VEIDogQ2hlY2tib3hTdGF0ZS5FTVBUWSxcbiAgICAgICAgICB0cnVlKTtcbiAgICAgIGlmICh0aGlzLmlzQ2hlY2tib3hDaGVja2VkKCkpIHtcbiAgICAgICAgLy8gQ2hlY2sgYWxsIHRoZSBub2RlcyB1bmRlciBpdC5cbiAgICAgICAgY29uc3QgZGVzY2VuZGFudHMgPSBfLnZhbHVlcyh0aGlzLmNoaWxkcmVuKSBhcyBTZWxlY3Rpb25UcmVlTm9kZVtdO1xuICAgICAgICB3aGlsZSAoZGVzY2VuZGFudHMubGVuZ3RoKSB7XG4gICAgICAgICAgbGV0IG5vZGUgPSBkZXNjZW5kYW50cy5wb3AoKTtcbiAgICAgICAgICBfLmZvckVhY2gobm9kZS5jaGlsZHJlbiwgY2hpbGQgPT4gZGVzY2VuZGFudHMucHVzaChjaGlsZCkpO1xuICAgICAgICAgIG5vZGUuc2V0Q2hlY2tib3hTdGF0ZShDaGVja2JveFN0YXRlLkNIRUNLRUQsIHRydWUpO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gUmVjb25jaWxlIG5vZGVzIGFib3ZlLlxuICAgICAgICB0aGlzLnNldE5vZGVzQWJvdmVUb0NoZWNrZWQoKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIC8vIFVuY2hlY2sgYWxsIHRoZSBub2RlcyB1bmRlciBpdC5cbiAgICAgICAgY29uc3QgZGVzY2VuZGFudHMgPSBfLnZhbHVlcyh0aGlzLmNoaWxkcmVuKSBhcyBTZWxlY3Rpb25UcmVlTm9kZVtdO1xuICAgICAgICB3aGlsZSAoZGVzY2VuZGFudHMubGVuZ3RoKSB7XG4gICAgICAgICAgbGV0IG5vZGUgPSBkZXNjZW5kYW50cy5wb3AoKTtcbiAgICAgICAgICBfLmZvckVhY2gobm9kZS5jaGlsZHJlbiwgY2hpbGQgPT4gZGVzY2VuZGFudHMucHVzaChjaGlsZCkpO1xuICAgICAgICAgIG5vZGUuc2V0Q2hlY2tib3hTdGF0ZShDaGVja2JveFN0YXRlLkVNUFRZLCB0cnVlKTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIFJlY29uY2lsZSBub2RlcyBhYm92ZS5cbiAgICAgICAgdGhpcy5zZXROb2Rlc0Fib3ZlVG9FbXB0eSgpO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIGlzTGVhZigpOiBib29sZWFuIHtcbiAgICByZXR1cm4gISF0aGlzLmRlYnVnV2F0Y2g7XG4gIH1cblxuICBzZXRUb0FsbENoZWNrZWRFeHRlcm5hbGx5KCkge1xuICAgIHRoaXMuc2V0Q2hlY2tib3hTdGF0ZShDaGVja2JveFN0YXRlLkNIRUNLRUQpO1xuICAgIHRoaXMuX2hhbmRsZUNoYW5nZSgpO1xuICB9XG5cbiAgc2V0Q2hlY2tib3hTdGF0ZShzdGF0ZTogQ2hlY2tib3hTdGF0ZSwgYXZvaWRQcm9wYWdhdGlvbj86IGJvb2xlYW4pIHtcbiAgICB0aGlzLmF2b2lkUHJvcGFnYXRpb24gPSBhdm9pZFByb3BhZ2F0aW9uO1xuICAgIHRoaXMuY2hlY2tib3hTdGF0ZSA9IHN0YXRlO1xuXG4gICAgdGhpcy5jaGVja2JveC5jbGFzc0xpc3QudG9nZ2xlKFxuICAgICAgICAncGFydGlhbC1jaGVja2JveCcsIHN0YXRlID09PSBDaGVja2JveFN0YXRlLlBBUlRJQUwpO1xuXG4gICAgaWYgKHN0YXRlID09PSBDaGVja2JveFN0YXRlLkNIRUNLRUQpIHtcbiAgICAgIHRoaXMuY2hlY2tib3guc2V0QXR0cmlidXRlKCdjaGVja2VkJywgJ2NoZWNrZWQnKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5jaGVja2JveC5yZW1vdmVBdHRyaWJ1dGUoJ2NoZWNrZWQnKTtcbiAgICB9XG5cbiAgICB0aGlzLmF2b2lkUHJvcGFnYXRpb24gPSBmYWxzZTtcbiAgfVxuXG4gIHByaXZhdGUgaXNDaGVja2JveENoZWNrZWQoKTogYm9vbGVhbiB7XG4gICAgcmV0dXJuIHRoaXMuY2hlY2tib3guaGFzQXR0cmlidXRlKCdjaGVja2VkJyk7XG4gIH1cblxuICBzZXROb2Rlc0Fib3ZlVG9DaGVja2VkKCkge1xuICAgIGxldCBjdXJyZW50Tm9kZSA9IHRoaXMucGFyZW50O1xuICAgIGxldCBwYXJ0aWFsRm91bmQgPSBmYWxzZTtcbiAgICB3aGlsZSAoY3VycmVudE5vZGUpIHtcbiAgICAgIGlmIChwYXJ0aWFsRm91bmQpIHtcbiAgICAgICAgLy8gV2UgZm91bmQgYSBQQVJUSUFMIGNoZWNrYm94IGxvd2VyIGluIHRoZSB0cmVlLiBIaWdoZXIgdXAgb25lc1xuICAgICAgICAvLyBtdXN0IGFsc28gYmUgcGFydGlhbCAoYW5kIGNhbid0IGJlIGNvbXBsZXRlIGFueSBtb3JlKS5cbiAgICAgICAgY3VycmVudE5vZGUuc2V0Q2hlY2tib3hTdGF0ZShDaGVja2JveFN0YXRlLlBBUlRJQUwsIHRydWUpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY29uc3QgaW5kZXggPSBfLmZpbmRJbmRleChcbiAgICAgICAgICAgIF8udmFsdWVzKGN1cnJlbnROb2RlLmNoaWxkcmVuKSBhcyBTZWxlY3Rpb25UcmVlTm9kZVtdLFxuICAgICAgICAgICAgY2hpbGQgPT4gKGNoaWxkLmNoZWNrYm94U3RhdGUgIT09IENoZWNrYm94U3RhdGUuQ0hFQ0tFRCkpO1xuICAgICAgICAvLyBFaXRoZXIgYWxsIG9yIG9ubHkgc29tZSBvZiB0aGUgY2hpbGRyZW4gd2VyZSBjaGVja2VkLlxuICAgICAgICBwYXJ0aWFsRm91bmQgPSBpbmRleCAhPT0gLTE7XG4gICAgICAgIGN1cnJlbnROb2RlLnNldENoZWNrYm94U3RhdGUoXG4gICAgICAgICAgICBwYXJ0aWFsRm91bmQgPyBDaGVja2JveFN0YXRlLlBBUlRJQUwgOiBDaGVja2JveFN0YXRlLkNIRUNLRUQsIHRydWUpO1xuICAgICAgfVxuICAgICAgLy8gTW92ZSB1cCB0aGUgdHJlZS5cbiAgICAgIGN1cnJlbnROb2RlID0gY3VycmVudE5vZGUucGFyZW50O1xuICAgIH1cbiAgfVxuXG4gIHNldE5vZGVzQWJvdmVUb0VtcHR5KCkge1xuICAgIGxldCBjdXJyZW50Tm9kZSA9IHRoaXMucGFyZW50O1xuICAgIGxldCBwYXJ0aWFsRm91bmQgPSBmYWxzZTtcbiAgICB3aGlsZSAoY3VycmVudE5vZGUpIHtcbiAgICAgIGlmIChwYXJ0aWFsRm91bmQpIHtcbiAgICAgICAgLy8gV2UgZm91bmQgYSBQQVJUSUFMIGNoZWNrYm94IGxvd2VyIGluIHRoZSB0cmVlLiBIaWdoZXIgdXAgb25lc1xuICAgICAgICAvLyBtdXN0IGFsc28gYmUgcGFydGlhbCAoYW5kIGNhbid0IGJlIGNvbXBsZXRlIGFueSBtb3JlKS5cbiAgICAgICAgY3VycmVudE5vZGUuc2V0Q2hlY2tib3hTdGF0ZShDaGVja2JveFN0YXRlLlBBUlRJQUwsIHRydWUpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY29uc3QgaW5kZXggPSBfLmZpbmRJbmRleChcbiAgICAgICAgICAgIF8udmFsdWVzKGN1cnJlbnROb2RlLmNoaWxkcmVuKSBhcyBTZWxlY3Rpb25UcmVlTm9kZVtdLFxuICAgICAgICAgICAgY2hpbGQgPT4gKGNoaWxkLmNoZWNrYm94U3RhdGUgIT09IENoZWNrYm94U3RhdGUuRU1QVFkpKTtcbiAgICAgICAgLy8gRWl0aGVyIGFsbCBvciBvbmx5IHNvbWUgb2YgdGhlIGNoaWxkcmVuIHdlcmUgZW1wdHkuXG4gICAgICAgIHBhcnRpYWxGb3VuZCA9IGluZGV4ICE9PSAtMTtcbiAgICAgICAgY3VycmVudE5vZGUuc2V0Q2hlY2tib3hTdGF0ZShcbiAgICAgICAgICAgIHBhcnRpYWxGb3VuZCA/IENoZWNrYm94U3RhdGUuUEFSVElBTCA6IENoZWNrYm94U3RhdGUuRU1QVFksIHRydWUpO1xuICAgICAgfVxuICAgICAgLy8gTW92ZSB1cCB0aGUgdHJlZS5cbiAgICAgIGN1cnJlbnROb2RlID0gY3VycmVudE5vZGUucGFyZW50O1xuICAgIH1cbiAgfVxuXG4gIHNldExldmVsRG9tKGxldmVsRG9tKSB7XG4gICAgdGhpcy5sZXZlbERvbSA9IGxldmVsRG9tO1xuICB9XG59XG5cbn0gIC8vIG5hbWVzcGFjZSB0Zl9kZWJ1Z2dlcl9kYXNoYm9hcmRcbiJdfQ==