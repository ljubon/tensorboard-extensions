declare namespace tf_tensorboard {
    var AUTORELOAD_LOCALSTORAGE_KEY: string;
    /**
     * @polymerBehavior
     */
    var AutoReloadBehavior: {
        properties: {
            autoReloadEnabled: {
                type: BooleanConstructor;
                observer: string;
                value: () => boolean;
            };
            _autoReloadId: {
                type: NumberConstructor;
            };
            autoReloadIntervalSecs: {
                type: NumberConstructor;
                value: number;
            };
        };
        detached: () => void;
        _autoReloadObserver: (autoReload: any) => void;
        _doAutoReload: () => void;
    };
}
