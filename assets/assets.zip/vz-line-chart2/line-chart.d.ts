declare namespace vz_line_chart2 {
    /**
     * An interface that describes a fill area to visualize. The fill area is
     * visualized with a less intense version of the color for a given series.
     */
    interface FillArea {
        lowerAccessor: Plottable.IAccessor<number>;
        higherAccessor: Plottable.IAccessor<number>;
    }
    type LineChartStatus = {
        smoothingEnabled: boolean;
    };
    type Metadata = {
        name: string;
        meta: any;
    };
    class LineChart {
        private name2datasets;
        private seriesNames;
        private xAccessor;
        private xScale;
        private yScale;
        private gridlines;
        private center;
        private xAxis;
        private yAxis;
        private outer;
        private colorScale;
        private symbolFunction;
        private tooltipColumns;
        private tooltip;
        private tooltipInteraction;
        private tooltipPointsComponent;
        private linePlot;
        private smoothLinePlot;
        private marginAreaPlot?;
        private scatterPlot;
        private nanDisplay;
        private markersScatterPlot;
        private yValueAccessor;
        private smoothedAccessor;
        private lastPointsDataset;
        private fillArea?;
        private datasets;
        private onDatasetChanged;
        private nanDataset;
        private smoothingWeight;
        private smoothingEnabled;
        private tooltipSortingMethod;
        private _ignoreYOutliers;
        private _lastMousePosition;
        private _lastDrawBBox;
        private _redrawRaf;
        private _invalidateLayoutRaf;
        private _defaultXRange;
        private _defaultYRange;
        private _tooltipUpdateAnimationFrame;
        private targetSVG;
        constructor(xComponentsCreationMethod: () => vz_chart_helpers.XComponents, yValueAccessor: Plottable.IAccessor<number>, yScaleType: string, colorScale: Plottable.Scales.Color, tooltip: vz_chart_helper.VzChartTooltip, tooltipColumns: vz_chart_helpers.TooltipColumn[], fillArea: FillArea, defaultXRange?: number[], defaultYRange?: number[], symbolFunction?: vz_chart_helpers.SymbolFn, xAxisFormatter?: (number: any) => string);
        private buildChart;
        private buildPlot;
        /** Updates the chart when a dataset changes. Called every time the data of
         * a dataset changes to update the charts.
         */
        private _onDatasetChanged;
        ignoreYOutliers(ignoreYOutliers: boolean): void;
        /** Constructs special datasets. Each special dataset contains exceptional
         * values from all of the regular datasets, e.g. last points in series, or
         * NaN values. Those points will have a `name` and `relative` property added
         * (since usually those are context in the surrounding dataset).
         */
        private updateSpecialDatasets;
        resetDomain(): void;
        private resetXDomain;
        private resetYDomain;
        private getAccessorsForComputingYRange;
        private getYAxisAccessor;
        private createTooltipInteraction;
        private updateTooltipContent;
        private hideTooltips;
        private setupTooltips;
        private drawTooltips;
        private drawTooltipRow;
        private drawTooltipColumn;
        private findClosestPoint;
        private resmoothDataset;
        private getDataset;
        static getYScaleFromType(yScaleType: string): Plottable.QuantitativeScale<number>;
        /**
         * Update the selected series on the chart.
         */
        setVisibleSeries(names: string[]): void;
        /**
         * Samples a dataset so that it contains no more than _MAX_MARKERS number of
         * data points. This function returns the original dataset if it does not
         * exceed that many points.
         */
        createSampledDatasetForMarkers(original: Plottable.Dataset): Plottable.Dataset;
        /**
         * Sets the data of a series on the chart.
         */
        setSeriesData(name: string, data: vz_chart_helpers.ScalarDatum[]): void;
        /**
         * Sets the metadata of a series on the chart.
         */
        setSeriesMetadata(name: string, meta: any): void;
        smoothingUpdate(weight: number): void;
        smoothingDisable(): void;
        setTooltipSortingMethod(method: string): void;
        renderTo(targetSVG: d3.Selection<any, any, any, any>): void;
        redraw(): void;
        private measureBBoxAndMaybeInvalidateLayoutInRaf;
        /**
         * Measures bounding box of the anchor node and determines whether the layout
         * needs to be re-done with measurement cache invalidated. Plottable improved
         * performance of rendering by caching expensive DOM measurement but this
         * cache can be poisoned in case the anchor node is in a wrong state -- namely
         * `display: none` where all dimensions are 0.
         */
        private measureBBoxAndMaybeInvalidateLayout;
        destroy(): void;
        onAnchor(fn: () => void): void;
    }
}
