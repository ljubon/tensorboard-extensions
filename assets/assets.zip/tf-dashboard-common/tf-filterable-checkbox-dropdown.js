/* Copyright 2018 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the 'License');
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an 'AS IS' BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
var tf_dashboard_common;
(function (tf_dashboard_common) {
    Polymer({
        is: 'tf-filterable-checkbox-dropdown',
        properties: {
            label: { type: String },
            placeholder: { type: String },
            labelFloat: {
                type: Boolean,
                value: false,
            },
            // ====== Pass through properties ======
            useCheckboxColors: {
                type: Boolean,
                value: true,
            },
            coloring: Object,
            // TODO(stephanwlee): Devise a better way for components to react to color
            // scale change. Recoloring on open may not be good enough.
            // The property simply clones the `coloring` to force redraw when dropdown
            // is opened.
            _coloring: {
                type: Object,
                computed: '_computeColoring(_opened, coloring)',
            },
            items: {
                type: Array,
                value: function () { return []; },
            },
            maxItemsToEnableByDefault: Number,
            selectionState: {
                type: Object,
                value: function () { return ({}); },
            },
            selectedItems: {
                type: Array,
                notify: true,
                value: function () { return []; },
            },
            // ====== Others ======
            _opened: {
                type: Boolean,
                value: false,
            },
        },
        // ====================== COMPUTED ======================
        _getValueLabel: function (_) {
            if (this.selectedItems.length == this.items.length) {
                return "All " + this.label + "s";
            }
            else if (!this.selectedItems.length) {
                return '';
            }
            else if (this.selectedItems.length <= 3) {
                var titles = this.selectedItems.map(function (_a) {
                    var title = _a.title;
                    return title;
                });
                var uniqueNames = new Set(titles);
                return Array.from(uniqueNames).join(', ');
            }
            return this.selectedItems.length + " Selected";
        },
        _computeColoring: function () {
            return Object.assign({}, this.coloring);
        },
    });
})(tf_dashboard_common || (tf_dashboard_common = {})); // namespace tf_dashboard_common
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGYtZmlsdGVyYWJsZS1jaGVja2JveC1kcm9wZG93bi5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbInRmLWZpbHRlcmFibGUtY2hlY2tib3gtZHJvcGRvd24udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7Ozs7Ozs7Z0ZBYWdGO0FBQ2hGLElBQVUsbUJBQW1CLENBK0U1QjtBQS9FRCxXQUFVLG1CQUFtQjtJQUU3QixPQUFPLENBQUM7UUFDTixFQUFFLEVBQUUsaUNBQWlDO1FBQ3JDLFVBQVUsRUFBRTtZQUNWLEtBQUssRUFBRSxFQUFDLElBQUksRUFBRSxNQUFNLEVBQUM7WUFFckIsV0FBVyxFQUFFLEVBQUMsSUFBSSxFQUFFLE1BQU0sRUFBQztZQUUzQixVQUFVLEVBQUU7Z0JBQ1YsSUFBSSxFQUFFLE9BQU87Z0JBQ2IsS0FBSyxFQUFFLEtBQUs7YUFDYjtZQUVELHdDQUF3QztZQUV4QyxpQkFBaUIsRUFBRTtnQkFDakIsSUFBSSxFQUFFLE9BQU87Z0JBQ2IsS0FBSyxFQUFFLElBQUk7YUFDWjtZQUVELFFBQVEsRUFBRSxNQUFNO1lBRWhCLDBFQUEwRTtZQUMxRSwyREFBMkQ7WUFDM0QsMEVBQTBFO1lBQzFFLGFBQWE7WUFDYixTQUFTLEVBQUU7Z0JBQ1QsSUFBSSxFQUFFLE1BQU07Z0JBQ1osUUFBUSxFQUFFLHFDQUFxQzthQUNoRDtZQUVELEtBQUssRUFBRTtnQkFDTCxJQUFJLEVBQUUsS0FBSztnQkFDWCxLQUFLLEVBQUUsY0FBTSxPQUFBLEVBQUUsRUFBRixDQUFFO2FBQ2hCO1lBRUQseUJBQXlCLEVBQUUsTUFBTTtZQUVqQyxjQUFjLEVBQUU7Z0JBQ2QsSUFBSSxFQUFFLE1BQU07Z0JBQ1osS0FBSyxFQUFFLGNBQU0sT0FBQSxDQUFDLEVBQUUsQ0FBQyxFQUFKLENBQUk7YUFDbEI7WUFFRCxhQUFhLEVBQUU7Z0JBQ2IsSUFBSSxFQUFFLEtBQUs7Z0JBQ1gsTUFBTSxFQUFFLElBQUk7Z0JBQ1osS0FBSyxFQUFFLGNBQU0sT0FBQSxFQUFFLEVBQUYsQ0FBRTthQUNoQjtZQUVELHVCQUF1QjtZQUV2QixPQUFPLEVBQUU7Z0JBQ1AsSUFBSSxFQUFFLE9BQU87Z0JBQ2IsS0FBSyxFQUFFLEtBQUs7YUFDYjtTQUNGO1FBRUQseURBQXlEO1FBRXpELGNBQWMsWUFBQyxDQUFDO1lBQ2QsSUFBSSxJQUFJLENBQUMsYUFBYSxDQUFDLE1BQU0sSUFBSSxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sRUFBRTtnQkFDbEQsT0FBTyxTQUFPLElBQUksQ0FBQyxLQUFLLE1BQUcsQ0FBQzthQUM3QjtpQkFBTSxJQUFJLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxNQUFNLEVBQUU7Z0JBQ3JDLE9BQU8sRUFBRSxDQUFDO2FBQ1g7aUJBQU0sSUFBSSxJQUFJLENBQUMsYUFBYSxDQUFDLE1BQU0sSUFBSSxDQUFDLEVBQUU7Z0JBQ3pDLElBQU0sTUFBTSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLFVBQUMsRUFBTzt3QkFBTixnQkFBSztvQkFBTSxPQUFBLEtBQUs7Z0JBQUwsQ0FBSyxDQUFDLENBQUM7Z0JBQzFELElBQU0sV0FBVyxHQUFHLElBQUksR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDO2dCQUNwQyxPQUFPLEtBQUssQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQzNDO1lBQ0QsT0FBVSxJQUFJLENBQUMsYUFBYSxDQUFDLE1BQU0sY0FBVyxDQUFDO1FBQ2pELENBQUM7UUFFRCxnQkFBZ0I7WUFDZCxPQUFPLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUMzQyxDQUFDO0tBRUYsQ0FBQyxDQUFDO0FBRUgsQ0FBQyxFQS9FUyxtQkFBbUIsS0FBbkIsbUJBQW1CLFFBK0U1QixDQUFFLGdDQUFnQyIsInNvdXJjZXNDb250ZW50IjpbIi8qIENvcHlyaWdodCAyMDE4IFRoZSBUZW5zb3JGbG93IEF1dGhvcnMuIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG5cbkxpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSAnTGljZW5zZScpO1xueW91IG1heSBub3QgdXNlIHRoaXMgZmlsZSBleGNlcHQgaW4gY29tcGxpYW5jZSB3aXRoIHRoZSBMaWNlbnNlLlxuWW91IG1heSBvYnRhaW4gYSBjb3B5IG9mIHRoZSBMaWNlbnNlIGF0XG5cbiAgICBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcblxuVW5sZXNzIHJlcXVpcmVkIGJ5IGFwcGxpY2FibGUgbGF3IG9yIGFncmVlZCB0byBpbiB3cml0aW5nLCBzb2Z0d2FyZVxuZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIExpY2Vuc2UgaXMgZGlzdHJpYnV0ZWQgb24gYW4gJ0FTIElTJyBCQVNJUyxcbldJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWSBLSU5ELCBlaXRoZXIgZXhwcmVzcyBvciBpbXBsaWVkLlxuU2VlIHRoZSBMaWNlbnNlIGZvciB0aGUgc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nIHBlcm1pc3Npb25zIGFuZFxubGltaXRhdGlvbnMgdW5kZXIgdGhlIExpY2Vuc2UuXG49PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0qL1xubmFtZXNwYWNlIHRmX2Rhc2hib2FyZF9jb21tb24ge1xuXG5Qb2x5bWVyKHtcbiAgaXM6ICd0Zi1maWx0ZXJhYmxlLWNoZWNrYm94LWRyb3Bkb3duJyxcbiAgcHJvcGVydGllczoge1xuICAgIGxhYmVsOiB7dHlwZTogU3RyaW5nfSxcblxuICAgIHBsYWNlaG9sZGVyOiB7dHlwZTogU3RyaW5nfSxcblxuICAgIGxhYmVsRmxvYXQ6IHtcbiAgICAgIHR5cGU6IEJvb2xlYW4sXG4gICAgICB2YWx1ZTogZmFsc2UsXG4gICAgfSxcblxuICAgIC8vID09PT09PSBQYXNzIHRocm91Z2ggcHJvcGVydGllcyA9PT09PT1cblxuICAgIHVzZUNoZWNrYm94Q29sb3JzOiB7XG4gICAgICB0eXBlOiBCb29sZWFuLFxuICAgICAgdmFsdWU6IHRydWUsXG4gICAgfSxcblxuICAgIGNvbG9yaW5nOiBPYmplY3QsXG5cbiAgICAvLyBUT0RPKHN0ZXBoYW53bGVlKTogRGV2aXNlIGEgYmV0dGVyIHdheSBmb3IgY29tcG9uZW50cyB0byByZWFjdCB0byBjb2xvclxuICAgIC8vIHNjYWxlIGNoYW5nZS4gUmVjb2xvcmluZyBvbiBvcGVuIG1heSBub3QgYmUgZ29vZCBlbm91Z2guXG4gICAgLy8gVGhlIHByb3BlcnR5IHNpbXBseSBjbG9uZXMgdGhlIGBjb2xvcmluZ2AgdG8gZm9yY2UgcmVkcmF3IHdoZW4gZHJvcGRvd25cbiAgICAvLyBpcyBvcGVuZWQuXG4gICAgX2NvbG9yaW5nOiB7XG4gICAgICB0eXBlOiBPYmplY3QsXG4gICAgICBjb21wdXRlZDogJ19jb21wdXRlQ29sb3JpbmcoX29wZW5lZCwgY29sb3JpbmcpJyxcbiAgICB9LFxuXG4gICAgaXRlbXM6IHtcbiAgICAgIHR5cGU6IEFycmF5LFxuICAgICAgdmFsdWU6ICgpID0+IFtdLFxuICAgIH0sXG5cbiAgICBtYXhJdGVtc1RvRW5hYmxlQnlEZWZhdWx0OiBOdW1iZXIsXG5cbiAgICBzZWxlY3Rpb25TdGF0ZToge1xuICAgICAgdHlwZTogT2JqZWN0LFxuICAgICAgdmFsdWU6ICgpID0+ICh7fSksXG4gICAgfSxcblxuICAgIHNlbGVjdGVkSXRlbXM6IHtcbiAgICAgIHR5cGU6IEFycmF5LFxuICAgICAgbm90aWZ5OiB0cnVlLFxuICAgICAgdmFsdWU6ICgpID0+IFtdLFxuICAgIH0sXG5cbiAgICAvLyA9PT09PT0gT3RoZXJzID09PT09PVxuXG4gICAgX29wZW5lZDoge1xuICAgICAgdHlwZTogQm9vbGVhbixcbiAgICAgIHZhbHVlOiBmYWxzZSxcbiAgICB9LFxuICB9LFxuXG4gIC8vID09PT09PT09PT09PT09PT09PT09PT0gQ09NUFVURUQgPT09PT09PT09PT09PT09PT09PT09PVxuXG4gIF9nZXRWYWx1ZUxhYmVsKF8pIHtcbiAgICBpZiAodGhpcy5zZWxlY3RlZEl0ZW1zLmxlbmd0aCA9PSB0aGlzLml0ZW1zLmxlbmd0aCkge1xuICAgICAgcmV0dXJuIGBBbGwgJHt0aGlzLmxhYmVsfXNgO1xuICAgIH0gZWxzZSBpZiAoIXRoaXMuc2VsZWN0ZWRJdGVtcy5sZW5ndGgpIHtcbiAgICAgIHJldHVybiAnJztcbiAgICB9IGVsc2UgaWYgKHRoaXMuc2VsZWN0ZWRJdGVtcy5sZW5ndGggPD0gMykge1xuICAgICAgY29uc3QgdGl0bGVzID0gdGhpcy5zZWxlY3RlZEl0ZW1zLm1hcCgoe3RpdGxlfSkgPT4gdGl0bGUpO1xuICAgICAgY29uc3QgdW5pcXVlTmFtZXMgPSBuZXcgU2V0KHRpdGxlcyk7XG4gICAgICByZXR1cm4gQXJyYXkuZnJvbSh1bmlxdWVOYW1lcykuam9pbignLCAnKTtcbiAgICB9XG4gICAgcmV0dXJuIGAke3RoaXMuc2VsZWN0ZWRJdGVtcy5sZW5ndGh9IFNlbGVjdGVkYDtcbiAgfSxcblxuICBfY29tcHV0ZUNvbG9yaW5nKCkge1xuICAgIHJldHVybiBPYmplY3QuYXNzaWduKHt9LCAgdGhpcy5jb2xvcmluZyk7XG4gIH0sXG5cbn0pO1xuXG59ICAvLyBuYW1lc3BhY2UgdGZfZGFzaGJvYXJkX2NvbW1vblxuIl19