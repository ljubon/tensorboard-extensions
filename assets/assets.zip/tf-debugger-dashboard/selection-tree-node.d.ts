declare namespace tf_debugger_dashboard {
    /**
     * A string used to separate parts of a node name. Should be kept consistent
     * with the graph component.
     */
    const NODE_NAME_SEPARATOR = "/";
    const DEVICE_NAME_PATTERN: RegExp;
    enum CheckboxState {
        EMPTY = 0,
        CHECKED = 1,
        PARTIAL = 2
    }
    interface DebugWatch {
        node_name: string;
        op_type: string;
        output_slot: number;
        debug_op: string;
    }
    /** Function that takes action based on item clicked in the context menu. */
    interface DebugWatchChange {
        (debugWatch: DebugWatch, checked: boolean): void;
    }
    /**
     * Split a node name, potentially with a device name prefix.
     * @param name: Input node name, potentially with a device name prefix, e.g.,
     *   '/job:localhost/replica:0/task:0/device:CPU:0/Dense/BiasAdd'
     * @return Split items. The device name, if present, will be the first item.
     */
    function splitNodeName(name: string): string[];
    /**
     * Get a node name without device name prefix or base-expansion suffix.
     * @param name: The node name, possibly with a device name prefix, e.g.,
     *   '/job:localhost/replica:0/task:0/device:CPU:0/Dense/BiasAdd'
     * @return The node name without any device name prefixes or '/' at the front.
     *   E.g., 'Dense/BiasAdd'
     */
    function getCleanNodeName(name: string): string;
    /**
     * Sort and base-expand an Array of DebugWatches in place.
     * "Base-expand" means adding a '/(baseName)' suffix to nodes whose names are
     * the name scope of some other node's name.
     * @param debugWatches: An array of `DebugWatch`es to sort and base-expand.
     * @returns Sorted and base-expanded `DebugWatch`es.
     */
    function sortAndBaseExpandDebugWatches(debugWatches: DebugWatch[]): void;
    /**
     * Remove any possible base expansion from a node name.
     * @param nodeName: The node name, possibly with base expansion.
     * @returns: Node name with any base expansion removed. If `nodeName` does not
     *   contain any base expansion, the string is returned without modification.
     */
    function removeNodeNameBaseExpansion(nodeName: string): string;
    function assembleDeviceAndNodeNames(nameItems: string[]): string[];
    enum DebugWatchFilterMode {
        NodeName = 0,
        OpType = 1
    }
    /**
     * Filter debug watches according to given filter mode and filter input.
     * @param debugWatches An array of `DebugWatch` instances.
     * @param filterMode
     * @param filterRegex Filter regular expression, e.g., for
     *   filterMode === 'Op Type': 'Variable.'.
     * @returns An array of `DebugWatch` instances from the input `debugWatches`
     *   that pass the filter.
     */
    function filterDebugWatches(debugWatches: DebugWatch[], filterMode: DebugWatchFilterMode, filterRegex: RegExp): DebugWatch[];
    class SelectionTreeNode {
        readonly debugWatchChange: DebugWatchChange;
        readonly debugWatch?: DebugWatch;
        name: string;
        parent: SelectionTreeNode;
        children: {
            [key: string]: SelectionTreeNode;
        };
        isRoot: boolean;
        checkboxState: CheckboxState;
        checkbox: Element;
        levelDom: Element;
        private avoidPropagation;
        constructor(name: string, debugWatchChange: DebugWatchChange, parent?: SelectionTreeNode, debugWatch?: DebugWatch);
        _handleChange(): void;
        isLeaf(): boolean;
        setToAllCheckedExternally(): void;
        setCheckboxState(state: CheckboxState, avoidPropagation?: boolean): void;
        private isCheckboxChecked;
        setNodesAboveToChecked(): void;
        setNodesAboveToEmpty(): void;
        setLevelDom(levelDom: any): void;
    }
}
