declare module tf.graph.op {
    /**
     * Whitelist of current Tensorflow ops valid on the TPU
     */
    const WHITELIST: string[];
    /**
     * Returns true if the node's inferred device is not the TPU.
     * Note that this is only a best-effort check.
     */
    function isNotTpuOp(opDevice: string): boolean;
    /**
     * Returns true if OpNode graph object represents a
     * Tensorflow operation that is valid for the TPU.
     */
    function opValid(opNode: OpNode): boolean;
    function checkOpsForCompatibility(graph: SlimGraph): void;
}
