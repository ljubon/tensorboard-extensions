/* Copyright 2015 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
var vz_line_chart2;
(function (vz_line_chart2) {
    var valueFormatter = vz_chart_helpers.multiscaleFormatter(vz_chart_helpers.Y_TOOLTIP_FORMATTER_PRECISION);
    var formatValueOrNaN = function (x) { return isNaN(x) ? 'NaN' : valueFormatter(x); };
    vz_line_chart2.DEFAULT_TOOLTIP_COLUMNS = [
        {
            title: 'Name',
            evaluate: function (d) { return d.dataset.metadata().name; },
        },
        {
            title: 'Smoothed',
            evaluate: function (d, statusObject) {
                var smoothingEnabled = statusObject.smoothingEnabled;
                return formatValueOrNaN(smoothingEnabled ? d.datum.smoothed : d.datum.scalar);
            },
        },
        {
            title: 'Value',
            evaluate: function (d) { return formatValueOrNaN(d.datum.scalar); },
        },
        {
            title: 'Step',
            evaluate: function (d) {
                return vz_chart_helpers.stepFormatter(d.datum.step);
            },
        },
        {
            title: 'Time',
            evaluate: function (d) {
                return vz_chart_helpers.timeFormatter(d.datum.wall_time);
            },
        },
        {
            title: 'Relative',
            evaluate: function (d) {
                return vz_chart_helpers.relativeFormatter(vz_chart_helpers.relativeAccessor(d.datum, -1, d.dataset));
            },
        },
    ];
    Polymer({
        is: 'vz-line-chart2',
        properties: {
            /**
             * Scale that maps series names to colors. The default colors are from
             * d3.schemeCategory10. Use this property to replace the default line
             * colors with colors of your own choice.
             * @type {Plottable.Scales.Color}
             * @required
             */
            colorScale: {
                type: Object,
                value: function () {
                    return new Plottable.Scales.Color().range(d3.schemeCategory10);
                }
            },
            /**
             * A function that takes a data series string and returns a
             * Plottable.SymbolFactory to use for rendering that series. This property
             * implements the vz_chart_helpers.SymbolFn interface.
             */
            symbolFunction: Object,
            /**
             * Whether smoothing is enabled or not. If true, smoothed lines will be
             * plotted in the chart while the unsmoothed lines will be ghosted in
             * the background.
             *
             * The smoothing algorithm is a simple moving average, which, given a
             * point p and a window w, replaces p with a simple average of the
             * points in the [p - floor(w/2), p + floor(w/2)] range.  If there
             * aren't enough points to cover the entire window to the left, the
             * window is reduced to fit exactly the amount of elements available.
             * This means that the smoothed line will be less in and gradually
             * become more smooth until the desired window is reached. However when
             * there aren't enough points on the right, the line stops being
             * rendered at all.
             */
            smoothingEnabled: {
                type: Boolean,
                notify: true,
                value: false,
            },
            /**
             * Weight (between 0.0 and 1.0) of the smoothing. This weight controls
             * the window size, and a weight of 1.0 means using 50% of the entire
             * dataset as the window, while a weight of 0.0 means using a window of
             * 0 (and thus replacing each point with themselves).
             *
             * The growth between 0.0 and 1.0 is not linear though. Because
             * changing the window from 0% to 30% of the dataset smooths the line a
             * lot more than changing the window from 70% to 100%, an exponential
             * function is used instead: http://i.imgur.com/bDrhEZU.png. This
             * function increases the size of the window slowly at the beginning
             * and gradually speeds up the growth, but 0.0 still means a window of
             * 0 and 1.0 still means a window of the dataset's length.
             */
            smoothingWeight: { type: Number, value: 0.6 },
            /**
             * This is a helper field for automatically generating commonly used
             * functions for xComponentsCreationMethod. Valid values are what can
             * be processed by vz_chart_helpers.getXComponents() and include
             * "step", "wall_time", and "relative".
             */
            xType: { type: String, value: '' },
            /**
             * We accept a function for creating an XComponents object instead of such
             * an object itself because the Axis must be made right when we make the
             * LineChart object, lest we use a previously destroyed Axis. See the async
             * logic below that uses this property.
             *
             * Note that this function returns a function because polymer calls the
             * outer function to compute the value. We actually want the value of this
             * property to be the inner function.
             *
             * @type {function(): vz_chart_helpers.XComponents}
             */
            xComponentsCreationMethod: {
                type: Object,
                /* Note: We have to provide a nonsense value for
                 * xComponentsCreationMethod here, because Polymer observers only
                 * trigger after all parameters are set. */
                value: ''
            },
            /**
             * A formatter for values along the X-axis. Optional. Defaults to a
             * reasonable formatter.
             *
             * @type {function(number): string}
             */
            xAxisFormatter: Object,
            /**
             * A method that implements the Plottable.IAccessor<number> interface. Used
             * for accessing the y value from a data point.
             *
             * Note that this function returns a function because polymer calls the
             * outer function to compute the value. We actually want the value of this
             * property to be the inner function.
             */
            yValueAccessor: { type: Object, value: function () { return (function (d) { return d.scalar; }); } },
            /**
             * An array of ChartHelper.TooltipColumn objects. Used to populate the table
             * within the tooltip. The table contains 1 row per run.
             *
             * Note that this function returns a function because polymer calls the
             * outer function to compute the value. We actually want the value of this
             * property to be the inner function.
             *
             */
            tooltipColumns: {
                type: Array,
                value: function () { return vz_line_chart2.DEFAULT_TOOLTIP_COLUMNS; },
            },
            /**
             * An optional FillArea object. If provided, the chart will
             * visualize fill area alongside the primary line for each series. If set,
             * consider setting ignoreYOutliers to false. Otherwise, outlier
             * calculations may deem some margins to be outliers, and some portions of
             * the fill area may not display.
             */
            fillArea: Object,
            /**
             * An optional array of 2 numbers for the min and max of the default range
             * of the Y axis. If not provided, a reasonable range will be generated.
             * This property is a list instead of 2 individual properties to emphasize
             * that both the min and the max must be specified (or neither at all).
             */
            defaultXRange: Array,
            /**
             * An optional array of 2 numbers for the min and max of the default range
             * of the Y axis. If not provided, a reasonable range will be generated.
             * This property is a list instead of 2 individual properties to emphasize
             * that both the min and the max must be specified (or neither at all).
             */
            defaultYRange: Array,
            /**
             * The scale for the y-axis. Allows:
             * - "linear" - linear scale (Plottable.Scales.Linear)
             * - "log" - modified-log scale (Plottable.Scales.ModifiedLog)
             */
            yScaleType: { type: String, value: 'linear' },
            /**
             * Whether to ignore outlier data when computing the yScale domain.
             */
            ignoreYOutliers: {
                type: Boolean,
                value: false,
            },
            /**
             * Change how the tooltip is sorted. Allows:
             * - "default" - Sort the tooltip by input order.
             * - "ascending" - Sort the tooltip by ascending value.
             * - "descending" - Sort the tooltip by descending value.
             * - "nearest" - Sort the tooltip by closest to cursor.
             */
            tooltipSortingMethod: { type: String, value: 'default' },
            /**
             * Changes how the tooltip is positioned. Allows:
             * - "bottom" - Position the tooltip on the bottom of the chart.
             * - "right" - Position the tooltip to the right of the chart.
             * - "auto" - Position the tooltip to the bottom of the chart in most case.
             *            Position the tooltip above the chart if there isn't sufficient
             *            space below.
             */
            tooltipPosition: {
                type: String,
                value: vz_chart_helper.TooltipPosition.BOTTOM,
            },
            _chart: Object,
            _visibleSeriesCache: {
                type: Array,
                value: function () { return []; },
            },
            _seriesDataCache: {
                type: Object,
                value: function () { return ({}); },
            },
            _seriesMetadataCache: {
                type: Object,
                value: function () { return ({}); },
            },
            _makeChartAsyncCallbackId: { type: Number, value: null },
        },
        observers: [
            '_makeChart(xComponentsCreationMethod, xType, yValueAccessor, yScaleType, tooltipColumns, colorScale, isAttached)',
            '_reloadFromCache(_chart)',
            '_smoothingChanged(smoothingEnabled, smoothingWeight, _chart)',
            '_tooltipSortingMethodChanged(tooltipSortingMethod, _chart)',
            '_outliersChanged(ignoreYOutliers, _chart)',
        ],
        ready: function () {
            this.scopeSubtree(this.$.chartdiv, true);
        },
        attached: function () {
            // `capture` ensures that no handler can stop propagation and break the
            // handler. `passive` ensures that browser does not wait renderer thread
            // on JS handler (which can prevent default and impact rendering).
            var option = { capture: true, passive: true };
            this._listen(this, 'mousedown', this._onMouseDown.bind(this), option);
            this._listen(this, 'mouseup', this._onMouseUp.bind(this), option);
            this._listen(window, 'keydown', this._onKeyDown.bind(this), option);
            this._listen(window, 'keyup', this._onKeyUp.bind(this), option);
        },
        detached: function () {
            this.cancelAsync(this._makeChartAsyncCallbackId);
            if (this._chart)
                this._chart.destroy();
            if (this._listeners) {
                this._listeners.forEach(function (_a) {
                    var node = _a.node, eventName = _a.eventName, func = _a.func, option = _a.option;
                    node.removeEventListener(eventName, func, option);
                });
                this._listeners.clear();
            }
        },
        _listen: function (node, eventName, func, option) {
            if (option === void 0) { option = {}; }
            if (!this._listeners)
                this._listeners = new Set();
            this._listeners.add({ node: node, eventName: eventName, func: func, option: option });
            node.addEventListener(eventName, func, option);
        },
        _onKeyDown: function (event) {
            this.toggleClass('pankey', vz_line_chart2.PanZoomDragLayer.isPanKey(event));
        },
        _onKeyUp: function (event) {
            this.toggleClass('pankey', vz_line_chart2.PanZoomDragLayer.isPanKey(event));
        },
        _onMouseDown: function (event) {
            this.toggleClass('mousedown', true);
        },
        _onMouseUp: function (event) {
            this.toggleClass('mousedown', false);
        },
        /**
         * Sets the series that the chart displays. Series with other names will
         * not be displayed.
         *
         * @param {Array<String>} names Array with the names of the series to
         * display.
         */
        setVisibleSeries: function (names) {
            if (_.isEqual(this._visibleSeriesCache, names))
                return;
            this._visibleSeriesCache = names;
            if (this._chart) {
                this._chart.setVisibleSeries(names);
                this.redraw();
            }
        },
        /**
         * Sets the data of one of the series. Note that to display this series
         * its name must be in the setVisibleSeries() array.
         *
         * @param {string} name Name of the series.
         * @param {Array<!vz_chart_helpers.ScalarDatum>} data Data of the series.
         * This is an array of objects with at least the following properties:
         * - step: (Number) - index of the datum.
         * - wall_time: (Date) - Date object with the datum's time.
         * - scalar: (Number) - Value of the datum.
         */
        setSeriesData: function (name, data) {
            this._seriesDataCache[name] = data;
            if (this._chart) {
                this._chart.setSeriesData(name, data);
            }
        },
        /**
         * Sets the metadata of one of the series.
         *
         * @param {string} name Name of the series.
         * @param {*} meta Metadata of the dataset used for later
         */
        setSeriesMetadata: function (name, meta) {
            this._seriesMetadataCache[name] = meta;
            if (this._chart) {
                this._chart.setSeriesMetadata(name, meta);
            }
        },
        /**
         * Reset the chart domain. If the chart has not rendered yet, a call to this
         * method no-ops.
         */
        resetDomain: function () {
            if (this._chart) {
                this._chart.resetDomain();
            }
        },
        /**
         * Re-renders the chart. Useful if e.g. the container size changed.
         */
        redraw: function () {
            if (this._chart) {
                this._chart.redraw();
            }
        },
        /**
         * Creates a chart, and asynchronously renders it. Fires a chart-rendered
         * event after the chart is rendered.
         */
        _makeChart: function (xComponentsCreationMethod, xType, yValueAccessor, yScaleType, tooltipColumns, colorScale) {
            // Find the actual xComponentsCreationMethod.
            if (!xType && !xComponentsCreationMethod) {
                xComponentsCreationMethod = vz_chart_helpers.stepX;
            }
            else if (xType) {
                xComponentsCreationMethod = function () {
                    return vz_chart_helpers.getXComponents(xType);
                };
            }
            if (this._makeChartAsyncCallbackId !== null) {
                this.cancelAsync(this._makeChartAsyncCallbackId);
                this._makeChartAsyncCallbackId = null;
            }
            this._makeChartAsyncCallbackId = this.async(function () {
                var _this = this;
                this._makeChartAsyncCallbackId = null;
                if (!xComponentsCreationMethod ||
                    !this.yValueAccessor ||
                    !this.tooltipColumns) {
                    return;
                }
                // We directly reference properties of `this` because this call is
                // asynchronous, and values may have changed in between the call being
                // initiated and actually being run.
                var chart = new vz_line_chart2.LineChart(xComponentsCreationMethod, this.yValueAccessor, yScaleType, colorScale, this.$.tooltip, this.tooltipColumns, this.fillArea, this.defaultXRange, this.defaultYRange, this.symbolFunction, this.xAxisFormatter);
                var div = d3.select(this.$.chartdiv);
                chart.renderTo(div);
                if (this._chart)
                    this._chart.destroy();
                this._chart = chart;
                this._chart.onAnchor(function () { return _this.fire('chart-attached'); });
            }, 350);
        },
        _reloadFromCache: function () {
            var _this = this;
            if (!this._chart)
                return;
            this._visibleSeriesCache.forEach(function (name) {
                _this._chart.setSeriesData(name, _this._seriesDataCache[name] || []);
            });
            this._visibleSeriesCache
                .filter(function (name) { return _this._seriesMetadataCache[name]; })
                .forEach(function (name) {
                _this._chart.setSeriesMetadata(name, _this._seriesMetadataCache[name]);
            });
            this._chart.setVisibleSeries(this._visibleSeriesCache);
        },
        _smoothingChanged: function () {
            if (!this._chart)
                return;
            if (this.smoothingEnabled) {
                this._chart.smoothingUpdate(this.smoothingWeight);
            }
            else {
                this._chart.smoothingDisable();
            }
        },
        _outliersChanged: function () {
            if (!this._chart)
                return;
            this._chart.ignoreYOutliers(this.ignoreYOutliers);
        },
        _tooltipSortingMethodChanged: function () {
            if (!this._chart)
                return;
            this._chart.setTooltipSortingMethod(this.tooltipSortingMethod);
        },
        getExporter: function () {
            return new vz_line_chart2.LineChartExporter(this.$.chartdiv);
        },
    });
})(vz_line_chart2 || (vz_line_chart2 = {})); // namespace vz_line_chart2
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidnotbGluZS1jaGFydDIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJ2ei1saW5lLWNoYXJ0Mi50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7Ozs7Ozs7OztnRkFhZ0Y7QUFDaEYsSUFBVSxjQUFjLENBc2N2QjtBQXRjRCxXQUFVLGNBQWM7SUFFeEIsSUFBTSxjQUFjLEdBQUcsZ0JBQWdCLENBQUMsbUJBQW1CLENBQ3ZELGdCQUFnQixDQUFDLDZCQUE2QixDQUFDLENBQUM7SUFDcEQsSUFBTSxnQkFBZ0IsR0FBRyxVQUFDLENBQUMsSUFBSyxPQUFBLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLEVBQXBDLENBQW9DLENBQUM7SUFFeEQsc0NBQXVCLEdBQUc7UUFDckM7WUFDRSxLQUFLLEVBQUUsTUFBTTtZQUNiLFFBQVEsRUFBRSxVQUFDLENBQXlCLElBQUssT0FBQSxDQUFDLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxDQUFDLElBQUksRUFBekIsQ0FBeUI7U0FDbkU7UUFDRDtZQUNFLEtBQUssRUFBRSxVQUFVO1lBQ2pCLFFBQVEsWUFBQyxDQUF5QixFQUFFLFlBQTZCO2dCQUN4RCxJQUFBLGdEQUFnQixDQUFpQjtnQkFDeEMsT0FBTyxnQkFBZ0IsQ0FDbkIsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQzVELENBQUM7U0FDRjtRQUNEO1lBQ0UsS0FBSyxFQUFFLE9BQU87WUFDZCxRQUFRLEVBQUUsVUFBQyxDQUF5QixJQUFLLE9BQUEsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsRUFBaEMsQ0FBZ0M7U0FDMUU7UUFDRDtZQUNFLEtBQUssRUFBRSxNQUFNO1lBQ2IsUUFBUSxFQUFFLFVBQUMsQ0FBeUI7Z0JBQ2hDLE9BQUEsZ0JBQWdCLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDO1lBQTVDLENBQTRDO1NBQ2pEO1FBQ0Q7WUFDRSxLQUFLLEVBQUUsTUFBTTtZQUNiLFFBQVEsRUFBRSxVQUFDLENBQXlCO2dCQUNoQyxPQUFBLGdCQUFnQixDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQztZQUFqRCxDQUFpRDtTQUN0RDtRQUNEO1lBQ0UsS0FBSyxFQUFFLFVBQVU7WUFDakIsUUFBUSxFQUFFLFVBQUMsQ0FBeUI7Z0JBQ2hDLE9BQUEsZ0JBQWdCLENBQUMsaUJBQWlCLENBQzlCLGdCQUFnQixDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxLQUFLLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBRDlELENBQzhEO1NBQ25FO0tBQ0YsQ0FBQztJQUVGLE9BQU8sQ0FBQztRQUNOLEVBQUUsRUFBRSxnQkFBZ0I7UUFDcEIsVUFBVSxFQUFFO1lBQ1Y7Ozs7OztlQU1HO1lBQ0gsVUFBVSxFQUFFO2dCQUNWLElBQUksRUFBRSxNQUFNO2dCQUNaLEtBQUssRUFBRTtvQkFDTCxPQUFPLElBQUksU0FBUyxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLGdCQUFnQixDQUFDLENBQUM7Z0JBQ2pFLENBQUM7YUFDRjtZQUVEOzs7O2VBSUc7WUFDSCxjQUFjLEVBQUUsTUFBTTtZQUV0Qjs7Ozs7Ozs7Ozs7Ozs7ZUFjRztZQUNILGdCQUFnQixFQUFFO2dCQUNoQixJQUFJLEVBQUUsT0FBTztnQkFDYixNQUFNLEVBQUUsSUFBSTtnQkFDWixLQUFLLEVBQUUsS0FBSzthQUNiO1lBRUQ7Ozs7Ozs7Ozs7Ozs7ZUFhRztZQUNILGVBQWUsRUFBRSxFQUFDLElBQUksRUFBRSxNQUFNLEVBQUUsS0FBSyxFQUFFLEdBQUcsRUFBQztZQUUzQzs7Ozs7ZUFLRztZQUNILEtBQUssRUFBRSxFQUFDLElBQUksRUFBRSxNQUFNLEVBQUUsS0FBSyxFQUFFLEVBQUUsRUFBQztZQUVoQzs7Ozs7Ozs7Ozs7ZUFXRztZQUNILHlCQUF5QixFQUFFO2dCQUN6QixJQUFJLEVBQUUsTUFBTTtnQkFDWjs7MkRBRTJDO2dCQUMzQyxLQUFLLEVBQUUsRUFBRTthQUNWO1lBRUQ7Ozs7O2VBS0c7WUFDSCxjQUFjLEVBQUUsTUFBTTtZQUV0Qjs7Ozs7OztlQU9HO1lBQ0gsY0FBYyxFQUFFLEVBQUMsSUFBSSxFQUFFLE1BQU0sRUFBRSxLQUFLLEVBQUUsY0FBTSxPQUFBLENBQUMsVUFBQSxDQUFDLElBQUksT0FBQSxDQUFDLENBQUMsTUFBTSxFQUFSLENBQVEsQ0FBQyxFQUFmLENBQWUsRUFBQztZQUU1RDs7Ozs7Ozs7ZUFRRztZQUNILGNBQWMsRUFBRTtnQkFDZCxJQUFJLEVBQUUsS0FBSztnQkFDWCxLQUFLLEVBQUUsY0FBTSxPQUFBLGVBQUEsdUJBQXVCLEVBQXZCLENBQXVCO2FBQ3JDO1lBRUQ7Ozs7OztlQU1HO1lBQ0gsUUFBUSxFQUFFLE1BQU07WUFFaEI7Ozs7O2VBS0c7WUFDSCxhQUFhLEVBQUUsS0FBSztZQUVwQjs7Ozs7ZUFLRztZQUNILGFBQWEsRUFBRSxLQUFLO1lBRXBCOzs7O2VBSUc7WUFDSCxVQUFVLEVBQUUsRUFBQyxJQUFJLEVBQUUsTUFBTSxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUM7WUFFM0M7O2VBRUc7WUFDSCxlQUFlLEVBQUU7Z0JBQ2YsSUFBSSxFQUFFLE9BQU87Z0JBQ2IsS0FBSyxFQUFFLEtBQUs7YUFDYjtZQUVEOzs7Ozs7ZUFNRztZQUNILG9CQUFvQixFQUFFLEVBQUMsSUFBSSxFQUFFLE1BQU0sRUFBRSxLQUFLLEVBQUUsU0FBUyxFQUFDO1lBRXREOzs7Ozs7O2VBT0c7WUFDSCxlQUFlLEVBQUU7Z0JBQ2YsSUFBSSxFQUFFLE1BQU07Z0JBQ1osS0FBSyxFQUFFLGVBQWUsQ0FBQyxlQUFlLENBQUMsTUFBTTthQUM5QztZQUVELE1BQU0sRUFBRSxNQUFNO1lBQ2QsbUJBQW1CLEVBQUU7Z0JBQ25CLElBQUksRUFBRSxLQUFLO2dCQUNYLEtBQUssRUFBRSxjQUFNLE9BQUEsRUFBRSxFQUFGLENBQUU7YUFDaEI7WUFDRCxnQkFBZ0IsRUFBRTtnQkFDaEIsSUFBSSxFQUFFLE1BQU07Z0JBQ1osS0FBSyxFQUFFLGNBQU0sT0FBQSxDQUFDLEVBQUUsQ0FBQyxFQUFKLENBQUk7YUFDbEI7WUFDRCxvQkFBb0IsRUFBRTtnQkFDcEIsSUFBSSxFQUFFLE1BQU07Z0JBQ1osS0FBSyxFQUFFLGNBQU0sT0FBQSxDQUFDLEVBQUUsQ0FBQyxFQUFKLENBQUk7YUFDbEI7WUFDRCx5QkFBeUIsRUFBRSxFQUFDLElBQUksRUFBRSxNQUFNLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBQztTQUN2RDtRQUVELFNBQVMsRUFBRTtZQUNULGtIQUFrSDtZQUNsSCwwQkFBMEI7WUFDMUIsOERBQThEO1lBQzlELDREQUE0RDtZQUM1RCwyQ0FBMkM7U0FDNUM7UUFFRCxLQUFLO1lBQ0gsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsQ0FBQztRQUMzQyxDQUFDO1FBRUQsUUFBUTtZQUNOLHVFQUF1RTtZQUN2RSx3RUFBd0U7WUFDeEUsa0VBQWtFO1lBQ2xFLElBQU0sTUFBTSxHQUFHLEVBQUMsT0FBTyxFQUFFLElBQUksRUFBRSxPQUFPLEVBQUUsSUFBSSxFQUFDLENBQUM7WUFDOUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsV0FBVyxFQUFFLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDO1lBQ3RFLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFLFNBQVMsRUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRSxNQUFNLENBQUMsQ0FBQztZQUNsRSxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsTUFBTSxDQUFDLENBQUM7WUFDcEUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDO1FBQ2xFLENBQUM7UUFFRCxRQUFRO1lBQ04sSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMseUJBQXlCLENBQUMsQ0FBQztZQUNqRCxJQUFJLElBQUksQ0FBQyxNQUFNO2dCQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFLENBQUM7WUFDdkMsSUFBSSxJQUFJLENBQUMsVUFBVSxFQUFFO2dCQUNuQixJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxVQUFDLEVBQStCO3dCQUE5QixjQUFJLEVBQUUsd0JBQVMsRUFBRSxjQUFJLEVBQUUsa0JBQU07b0JBQ3JELElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxTQUFTLEVBQUUsSUFBSSxFQUFFLE1BQU0sQ0FBQyxDQUFDO2dCQUNwRCxDQUFDLENBQUMsQ0FBQztnQkFDSCxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssRUFBRSxDQUFDO2FBQ3pCO1FBQ0gsQ0FBQztRQUVELE9BQU8sWUFBQyxJQUFVLEVBQUUsU0FBaUIsRUFBRSxJQUFxQixFQUFFLE1BQVc7WUFBWCx1QkFBQSxFQUFBLFdBQVc7WUFDdkUsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVO2dCQUFFLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxHQUFHLEVBQUUsQ0FBQztZQUNsRCxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxFQUFDLElBQUksTUFBQSxFQUFFLFNBQVMsV0FBQSxFQUFFLElBQUksTUFBQSxFQUFFLE1BQU0sUUFBQSxFQUFDLENBQUMsQ0FBQztZQUNyRCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxFQUFFLElBQUksRUFBRSxNQUFNLENBQUMsQ0FBQztRQUNqRCxDQUFDO1FBRUQsVUFBVSxZQUFDLEtBQUs7WUFDZCxJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsRUFBRSxlQUFBLGdCQUFnQixDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO1FBQy9ELENBQUM7UUFFRCxRQUFRLFlBQUMsS0FBSztZQUNaLElBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxFQUFFLGVBQUEsZ0JBQWdCLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7UUFDL0QsQ0FBQztRQUVELFlBQVksWUFBQyxLQUFLO1lBQ2hCLElBQUksQ0FBQyxXQUFXLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ3RDLENBQUM7UUFFRCxVQUFVLFlBQUMsS0FBSztZQUNkLElBQUksQ0FBQyxXQUFXLENBQUMsV0FBVyxFQUFFLEtBQUssQ0FBQyxDQUFDO1FBQ3ZDLENBQUM7UUFFRDs7Ozs7O1dBTUc7UUFDSCxnQkFBZ0IsRUFBRSxVQUFTLEtBQUs7WUFDOUIsSUFBSSxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxtQkFBbUIsRUFBRSxLQUFLLENBQUM7Z0JBQUUsT0FBTztZQUN2RCxJQUFJLENBQUMsbUJBQW1CLEdBQUcsS0FBSyxDQUFDO1lBQ2pDLElBQUksSUFBSSxDQUFDLE1BQU0sRUFBRTtnQkFDZixJQUFJLENBQUMsTUFBTSxDQUFDLGdCQUFnQixDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUNwQyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7YUFDZjtRQUNILENBQUM7UUFFRDs7Ozs7Ozs7OztXQVVHO1FBQ0gsYUFBYSxFQUFFLFVBQVMsSUFBSSxFQUFFLElBQUk7WUFDaEMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxHQUFHLElBQUksQ0FBQztZQUNuQyxJQUFJLElBQUksQ0FBQyxNQUFNLEVBQUU7Z0JBQ2YsSUFBSSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDO2FBQ3ZDO1FBQ0gsQ0FBQztRQUVEOzs7OztXQUtHO1FBQ0gsaUJBQWlCLFlBQUMsSUFBWSxFQUFFLElBQVM7WUFDdkMsSUFBSSxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxHQUFHLElBQUksQ0FBQztZQUN2QyxJQUFJLElBQUksQ0FBQyxNQUFNLEVBQUU7Z0JBQ2YsSUFBSSxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLENBQUM7YUFDM0M7UUFDSCxDQUFDO1FBRUQ7OztXQUdHO1FBQ0gsV0FBVyxFQUFFO1lBQ1gsSUFBSSxJQUFJLENBQUMsTUFBTSxFQUFFO2dCQUNmLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxFQUFFLENBQUM7YUFDM0I7UUFDSCxDQUFDO1FBRUQ7O1dBRUc7UUFDSCxNQUFNLEVBQUU7WUFDTixJQUFJLElBQUksQ0FBQyxNQUFNLEVBQUU7Z0JBQ2YsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsQ0FBQzthQUN0QjtRQUNILENBQUM7UUFFRDs7O1dBR0c7UUFDSCxVQUFVLEVBQUUsVUFDUix5QkFBeUIsRUFDekIsS0FBSyxFQUNMLGNBQWMsRUFDZCxVQUFVLEVBQ1YsY0FBYyxFQUNkLFVBQVU7WUFDWiw2Q0FBNkM7WUFDN0MsSUFBSSxDQUFDLEtBQUssSUFBSSxDQUFDLHlCQUF5QixFQUFFO2dCQUN4Qyx5QkFBeUIsR0FBRyxnQkFBZ0IsQ0FBQyxLQUFLLENBQUM7YUFDcEQ7aUJBQU0sSUFBSSxLQUFLLEVBQUU7Z0JBQ2hCLHlCQUF5QixHQUFHO29CQUN4QixPQUFBLGdCQUFnQixDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUM7Z0JBQXRDLENBQXNDLENBQUM7YUFDNUM7WUFFRCxJQUFJLElBQUksQ0FBQyx5QkFBeUIsS0FBSyxJQUFJLEVBQUU7Z0JBQzNDLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLHlCQUF5QixDQUFDLENBQUM7Z0JBQ2pELElBQUksQ0FBQyx5QkFBeUIsR0FBRyxJQUFJLENBQUM7YUFDdkM7WUFFRCxJQUFJLENBQUMseUJBQXlCLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQztnQkFBQSxpQkEyQjNDO2dCQTFCQyxJQUFJLENBQUMseUJBQXlCLEdBQUcsSUFBSSxDQUFDO2dCQUN0QyxJQUFJLENBQUMseUJBQXlCO29CQUMxQixDQUFDLElBQUksQ0FBQyxjQUFjO29CQUNwQixDQUFDLElBQUksQ0FBQyxjQUFjLEVBQUU7b0JBQ3hCLE9BQU87aUJBQ1I7Z0JBQ0Qsa0VBQWtFO2dCQUNsRSxzRUFBc0U7Z0JBQ3RFLG9DQUFvQztnQkFDcEMsSUFBSSxLQUFLLEdBQUcsSUFBSSxlQUFBLFNBQVMsQ0FDckIseUJBQXlCLEVBQ3pCLElBQUksQ0FBQyxjQUFjLEVBQ25CLFVBQVUsRUFDVixVQUFVLEVBQ1YsSUFBSSxDQUFDLENBQUMsQ0FBQyxPQUFPLEVBQ2QsSUFBSSxDQUFDLGNBQWMsRUFDbkIsSUFBSSxDQUFDLFFBQVEsRUFDYixJQUFJLENBQUMsYUFBYSxFQUNsQixJQUFJLENBQUMsYUFBYSxFQUNsQixJQUFJLENBQUMsY0FBYyxFQUNuQixJQUFJLENBQUMsY0FBYyxDQUFDLENBQUM7Z0JBQ3pCLElBQUksR0FBRyxHQUFHLEVBQUUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztnQkFDckMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDcEIsSUFBSSxJQUFJLENBQUMsTUFBTTtvQkFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sRUFBRSxDQUFDO2dCQUN2QyxJQUFJLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQztnQkFDcEIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsY0FBTSxPQUFBLEtBQUksQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsRUFBM0IsQ0FBMkIsQ0FBQyxDQUFDO1lBQzFELENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQztRQUNWLENBQUM7UUFFRCxnQkFBZ0IsRUFBRTtZQUFBLGlCQVdqQjtZQVZDLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTTtnQkFBRSxPQUFPO1lBQ3pCLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxPQUFPLENBQUMsVUFBQSxJQUFJO2dCQUNuQyxLQUFJLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxJQUFJLEVBQUUsS0FBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDO1lBQ3JFLENBQUMsQ0FBQyxDQUFDO1lBQ0gsSUFBSSxDQUFDLG1CQUFtQjtpQkFDbkIsTUFBTSxDQUFDLFVBQUEsSUFBSSxJQUFJLE9BQUEsS0FBSSxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxFQUEvQixDQUErQixDQUFDO2lCQUMvQyxPQUFPLENBQUMsVUFBQSxJQUFJO2dCQUNYLEtBQUksQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsSUFBSSxFQUFFLEtBQUksQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1lBQ3ZFLENBQUMsQ0FBQyxDQUFDO1lBQ1AsSUFBSSxDQUFDLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsQ0FBQztRQUN6RCxDQUFDO1FBRUQsaUJBQWlCLEVBQUU7WUFDakIsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNO2dCQUFFLE9BQU87WUFDekIsSUFBSSxJQUFJLENBQUMsZ0JBQWdCLEVBQUU7Z0JBQ3pCLElBQUksQ0FBQyxNQUFNLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQzthQUNuRDtpQkFBTTtnQkFDTCxJQUFJLENBQUMsTUFBTSxDQUFDLGdCQUFnQixFQUFFLENBQUM7YUFDaEM7UUFDSCxDQUFDO1FBRUQsZ0JBQWdCLEVBQUU7WUFDaEIsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNO2dCQUFFLE9BQU87WUFDekIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDO1FBQ3BELENBQUM7UUFFRCw0QkFBNEIsRUFBRTtZQUM1QixJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU07Z0JBQUUsT0FBTztZQUN6QixJQUFJLENBQUMsTUFBTSxDQUFDLHVCQUF1QixDQUFDLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO1FBQ2pFLENBQUM7UUFFRCxXQUFXO1lBQ1QsT0FBTyxJQUFJLGVBQUEsaUJBQWlCLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUNoRCxDQUFDO0tBRUYsQ0FBQyxDQUFDO0FBRUgsQ0FBQyxFQXRjUyxjQUFjLEtBQWQsY0FBYyxRQXNjdkIsQ0FBRSwyQkFBMkIiLCJzb3VyY2VzQ29udGVudCI6WyIvKiBDb3B5cmlnaHQgMjAxNSBUaGUgVGVuc29yRmxvdyBBdXRob3JzLiBBbGwgUmlnaHRzIFJlc2VydmVkLlxuXG5MaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UsIFZlcnNpb24gMi4wICh0aGUgXCJMaWNlbnNlXCIpO1xueW91IG1heSBub3QgdXNlIHRoaXMgZmlsZSBleGNlcHQgaW4gY29tcGxpYW5jZSB3aXRoIHRoZSBMaWNlbnNlLlxuWW91IG1heSBvYnRhaW4gYSBjb3B5IG9mIHRoZSBMaWNlbnNlIGF0XG5cbiAgICBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcblxuVW5sZXNzIHJlcXVpcmVkIGJ5IGFwcGxpY2FibGUgbGF3IG9yIGFncmVlZCB0byBpbiB3cml0aW5nLCBzb2Z0d2FyZVxuZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIExpY2Vuc2UgaXMgZGlzdHJpYnV0ZWQgb24gYW4gXCJBUyBJU1wiIEJBU0lTLFxuV0lUSE9VVCBXQVJSQU5USUVTIE9SIENPTkRJVElPTlMgT0YgQU5ZIEtJTkQsIGVpdGhlciBleHByZXNzIG9yIGltcGxpZWQuXG5TZWUgdGhlIExpY2Vuc2UgZm9yIHRoZSBzcGVjaWZpYyBsYW5ndWFnZSBnb3Zlcm5pbmcgcGVybWlzc2lvbnMgYW5kXG5saW1pdGF0aW9ucyB1bmRlciB0aGUgTGljZW5zZS5cbj09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSovXG5uYW1lc3BhY2UgdnpfbGluZV9jaGFydDIge1xuXG5jb25zdCB2YWx1ZUZvcm1hdHRlciA9IHZ6X2NoYXJ0X2hlbHBlcnMubXVsdGlzY2FsZUZvcm1hdHRlcihcbiAgICB2el9jaGFydF9oZWxwZXJzLllfVE9PTFRJUF9GT1JNQVRURVJfUFJFQ0lTSU9OKTtcbmNvbnN0IGZvcm1hdFZhbHVlT3JOYU4gPSAoeCkgPT4gaXNOYU4oeCkgPyAnTmFOJyA6IHZhbHVlRm9ybWF0dGVyKHgpO1xuXG5leHBvcnQgY29uc3QgREVGQVVMVF9UT09MVElQX0NPTFVNTlMgPSBbXG4gIHtcbiAgICB0aXRsZTogJ05hbWUnLFxuICAgIGV2YWx1YXRlOiAoZDogdnpfY2hhcnRfaGVscGVycy5Qb2ludCkgPT4gZC5kYXRhc2V0Lm1ldGFkYXRhKCkubmFtZSxcbiAgfSxcbiAge1xuICAgIHRpdGxlOiAnU21vb3RoZWQnLFxuICAgIGV2YWx1YXRlKGQ6IHZ6X2NoYXJ0X2hlbHBlcnMuUG9pbnQsIHN0YXR1c09iamVjdDogTGluZUNoYXJ0U3RhdHVzKSB7XG4gICAgICBjb25zdCB7c21vb3RoaW5nRW5hYmxlZH0gPSBzdGF0dXNPYmplY3Q7XG4gICAgICByZXR1cm4gZm9ybWF0VmFsdWVPck5hTihcbiAgICAgICAgICBzbW9vdGhpbmdFbmFibGVkID8gZC5kYXR1bS5zbW9vdGhlZCA6IGQuZGF0dW0uc2NhbGFyKTtcbiAgICB9LFxuICB9LFxuICB7XG4gICAgdGl0bGU6ICdWYWx1ZScsXG4gICAgZXZhbHVhdGU6IChkOiB2el9jaGFydF9oZWxwZXJzLlBvaW50KSA9PiBmb3JtYXRWYWx1ZU9yTmFOKGQuZGF0dW0uc2NhbGFyKSxcbiAgfSxcbiAge1xuICAgIHRpdGxlOiAnU3RlcCcsXG4gICAgZXZhbHVhdGU6IChkOiB2el9jaGFydF9oZWxwZXJzLlBvaW50KSA9PlxuICAgICAgICB2el9jaGFydF9oZWxwZXJzLnN0ZXBGb3JtYXR0ZXIoZC5kYXR1bS5zdGVwKSxcbiAgfSxcbiAge1xuICAgIHRpdGxlOiAnVGltZScsXG4gICAgZXZhbHVhdGU6IChkOiB2el9jaGFydF9oZWxwZXJzLlBvaW50KSA9PlxuICAgICAgICB2el9jaGFydF9oZWxwZXJzLnRpbWVGb3JtYXR0ZXIoZC5kYXR1bS53YWxsX3RpbWUpLFxuICB9LFxuICB7XG4gICAgdGl0bGU6ICdSZWxhdGl2ZScsXG4gICAgZXZhbHVhdGU6IChkOiB2el9jaGFydF9oZWxwZXJzLlBvaW50KSA9PlxuICAgICAgICB2el9jaGFydF9oZWxwZXJzLnJlbGF0aXZlRm9ybWF0dGVyKFxuICAgICAgICAgICAgdnpfY2hhcnRfaGVscGVycy5yZWxhdGl2ZUFjY2Vzc29yKGQuZGF0dW0sIC0xLCBkLmRhdGFzZXQpKSxcbiAgfSxcbl07XG5cblBvbHltZXIoe1xuICBpczogJ3Z6LWxpbmUtY2hhcnQyJyxcbiAgcHJvcGVydGllczoge1xuICAgIC8qKlxuICAgICAqIFNjYWxlIHRoYXQgbWFwcyBzZXJpZXMgbmFtZXMgdG8gY29sb3JzLiBUaGUgZGVmYXVsdCBjb2xvcnMgYXJlIGZyb21cbiAgICAgKiBkMy5zY2hlbWVDYXRlZ29yeTEwLiBVc2UgdGhpcyBwcm9wZXJ0eSB0byByZXBsYWNlIHRoZSBkZWZhdWx0IGxpbmVcbiAgICAgKiBjb2xvcnMgd2l0aCBjb2xvcnMgb2YgeW91ciBvd24gY2hvaWNlLlxuICAgICAqIEB0eXBlIHtQbG90dGFibGUuU2NhbGVzLkNvbG9yfVxuICAgICAqIEByZXF1aXJlZFxuICAgICAqL1xuICAgIGNvbG9yU2NhbGU6IHtcbiAgICAgIHR5cGU6IE9iamVjdCxcbiAgICAgIHZhbHVlOiBmdW5jdGlvbigpIHtcbiAgICAgICAgcmV0dXJuIG5ldyBQbG90dGFibGUuU2NhbGVzLkNvbG9yKCkucmFuZ2UoZDMuc2NoZW1lQ2F0ZWdvcnkxMCk7XG4gICAgICB9XG4gICAgfSxcblxuICAgIC8qKlxuICAgICAqIEEgZnVuY3Rpb24gdGhhdCB0YWtlcyBhIGRhdGEgc2VyaWVzIHN0cmluZyBhbmQgcmV0dXJucyBhXG4gICAgICogUGxvdHRhYmxlLlN5bWJvbEZhY3RvcnkgdG8gdXNlIGZvciByZW5kZXJpbmcgdGhhdCBzZXJpZXMuIFRoaXMgcHJvcGVydHlcbiAgICAgKiBpbXBsZW1lbnRzIHRoZSB2el9jaGFydF9oZWxwZXJzLlN5bWJvbEZuIGludGVyZmFjZS5cbiAgICAgKi9cbiAgICBzeW1ib2xGdW5jdGlvbjogT2JqZWN0LFxuXG4gICAgLyoqXG4gICAgICogV2hldGhlciBzbW9vdGhpbmcgaXMgZW5hYmxlZCBvciBub3QuIElmIHRydWUsIHNtb290aGVkIGxpbmVzIHdpbGwgYmVcbiAgICAgKiBwbG90dGVkIGluIHRoZSBjaGFydCB3aGlsZSB0aGUgdW5zbW9vdGhlZCBsaW5lcyB3aWxsIGJlIGdob3N0ZWQgaW5cbiAgICAgKiB0aGUgYmFja2dyb3VuZC5cbiAgICAgKlxuICAgICAqIFRoZSBzbW9vdGhpbmcgYWxnb3JpdGhtIGlzIGEgc2ltcGxlIG1vdmluZyBhdmVyYWdlLCB3aGljaCwgZ2l2ZW4gYVxuICAgICAqIHBvaW50IHAgYW5kIGEgd2luZG93IHcsIHJlcGxhY2VzIHAgd2l0aCBhIHNpbXBsZSBhdmVyYWdlIG9mIHRoZVxuICAgICAqIHBvaW50cyBpbiB0aGUgW3AgLSBmbG9vcih3LzIpLCBwICsgZmxvb3Iody8yKV0gcmFuZ2UuICBJZiB0aGVyZVxuICAgICAqIGFyZW4ndCBlbm91Z2ggcG9pbnRzIHRvIGNvdmVyIHRoZSBlbnRpcmUgd2luZG93IHRvIHRoZSBsZWZ0LCB0aGVcbiAgICAgKiB3aW5kb3cgaXMgcmVkdWNlZCB0byBmaXQgZXhhY3RseSB0aGUgYW1vdW50IG9mIGVsZW1lbnRzIGF2YWlsYWJsZS5cbiAgICAgKiBUaGlzIG1lYW5zIHRoYXQgdGhlIHNtb290aGVkIGxpbmUgd2lsbCBiZSBsZXNzIGluIGFuZCBncmFkdWFsbHlcbiAgICAgKiBiZWNvbWUgbW9yZSBzbW9vdGggdW50aWwgdGhlIGRlc2lyZWQgd2luZG93IGlzIHJlYWNoZWQuIEhvd2V2ZXIgd2hlblxuICAgICAqIHRoZXJlIGFyZW4ndCBlbm91Z2ggcG9pbnRzIG9uIHRoZSByaWdodCwgdGhlIGxpbmUgc3RvcHMgYmVpbmdcbiAgICAgKiByZW5kZXJlZCBhdCBhbGwuXG4gICAgICovXG4gICAgc21vb3RoaW5nRW5hYmxlZDoge1xuICAgICAgdHlwZTogQm9vbGVhbixcbiAgICAgIG5vdGlmeTogdHJ1ZSxcbiAgICAgIHZhbHVlOiBmYWxzZSxcbiAgICB9LFxuXG4gICAgLyoqXG4gICAgICogV2VpZ2h0IChiZXR3ZWVuIDAuMCBhbmQgMS4wKSBvZiB0aGUgc21vb3RoaW5nLiBUaGlzIHdlaWdodCBjb250cm9sc1xuICAgICAqIHRoZSB3aW5kb3cgc2l6ZSwgYW5kIGEgd2VpZ2h0IG9mIDEuMCBtZWFucyB1c2luZyA1MCUgb2YgdGhlIGVudGlyZVxuICAgICAqIGRhdGFzZXQgYXMgdGhlIHdpbmRvdywgd2hpbGUgYSB3ZWlnaHQgb2YgMC4wIG1lYW5zIHVzaW5nIGEgd2luZG93IG9mXG4gICAgICogMCAoYW5kIHRodXMgcmVwbGFjaW5nIGVhY2ggcG9pbnQgd2l0aCB0aGVtc2VsdmVzKS5cbiAgICAgKlxuICAgICAqIFRoZSBncm93dGggYmV0d2VlbiAwLjAgYW5kIDEuMCBpcyBub3QgbGluZWFyIHRob3VnaC4gQmVjYXVzZVxuICAgICAqIGNoYW5naW5nIHRoZSB3aW5kb3cgZnJvbSAwJSB0byAzMCUgb2YgdGhlIGRhdGFzZXQgc21vb3RocyB0aGUgbGluZSBhXG4gICAgICogbG90IG1vcmUgdGhhbiBjaGFuZ2luZyB0aGUgd2luZG93IGZyb20gNzAlIHRvIDEwMCUsIGFuIGV4cG9uZW50aWFsXG4gICAgICogZnVuY3Rpb24gaXMgdXNlZCBpbnN0ZWFkOiBodHRwOi8vaS5pbWd1ci5jb20vYkRyaEVaVS5wbmcuIFRoaXNcbiAgICAgKiBmdW5jdGlvbiBpbmNyZWFzZXMgdGhlIHNpemUgb2YgdGhlIHdpbmRvdyBzbG93bHkgYXQgdGhlIGJlZ2lubmluZ1xuICAgICAqIGFuZCBncmFkdWFsbHkgc3BlZWRzIHVwIHRoZSBncm93dGgsIGJ1dCAwLjAgc3RpbGwgbWVhbnMgYSB3aW5kb3cgb2ZcbiAgICAgKiAwIGFuZCAxLjAgc3RpbGwgbWVhbnMgYSB3aW5kb3cgb2YgdGhlIGRhdGFzZXQncyBsZW5ndGguXG4gICAgICovXG4gICAgc21vb3RoaW5nV2VpZ2h0OiB7dHlwZTogTnVtYmVyLCB2YWx1ZTogMC42fSxcblxuICAgIC8qKlxuICAgICAqIFRoaXMgaXMgYSBoZWxwZXIgZmllbGQgZm9yIGF1dG9tYXRpY2FsbHkgZ2VuZXJhdGluZyBjb21tb25seSB1c2VkXG4gICAgICogZnVuY3Rpb25zIGZvciB4Q29tcG9uZW50c0NyZWF0aW9uTWV0aG9kLiBWYWxpZCB2YWx1ZXMgYXJlIHdoYXQgY2FuXG4gICAgICogYmUgcHJvY2Vzc2VkIGJ5IHZ6X2NoYXJ0X2hlbHBlcnMuZ2V0WENvbXBvbmVudHMoKSBhbmQgaW5jbHVkZVxuICAgICAqIFwic3RlcFwiLCBcIndhbGxfdGltZVwiLCBhbmQgXCJyZWxhdGl2ZVwiLlxuICAgICAqL1xuICAgIHhUeXBlOiB7dHlwZTogU3RyaW5nLCB2YWx1ZTogJyd9LFxuXG4gICAgLyoqXG4gICAgICogV2UgYWNjZXB0IGEgZnVuY3Rpb24gZm9yIGNyZWF0aW5nIGFuIFhDb21wb25lbnRzIG9iamVjdCBpbnN0ZWFkIG9mIHN1Y2hcbiAgICAgKiBhbiBvYmplY3QgaXRzZWxmIGJlY2F1c2UgdGhlIEF4aXMgbXVzdCBiZSBtYWRlIHJpZ2h0IHdoZW4gd2UgbWFrZSB0aGVcbiAgICAgKiBMaW5lQ2hhcnQgb2JqZWN0LCBsZXN0IHdlIHVzZSBhIHByZXZpb3VzbHkgZGVzdHJveWVkIEF4aXMuIFNlZSB0aGUgYXN5bmNcbiAgICAgKiBsb2dpYyBiZWxvdyB0aGF0IHVzZXMgdGhpcyBwcm9wZXJ0eS5cbiAgICAgKlxuICAgICAqIE5vdGUgdGhhdCB0aGlzIGZ1bmN0aW9uIHJldHVybnMgYSBmdW5jdGlvbiBiZWNhdXNlIHBvbHltZXIgY2FsbHMgdGhlXG4gICAgICogb3V0ZXIgZnVuY3Rpb24gdG8gY29tcHV0ZSB0aGUgdmFsdWUuIFdlIGFjdHVhbGx5IHdhbnQgdGhlIHZhbHVlIG9mIHRoaXNcbiAgICAgKiBwcm9wZXJ0eSB0byBiZSB0aGUgaW5uZXIgZnVuY3Rpb24uXG4gICAgICpcbiAgICAgKiBAdHlwZSB7ZnVuY3Rpb24oKTogdnpfY2hhcnRfaGVscGVycy5YQ29tcG9uZW50c31cbiAgICAgKi9cbiAgICB4Q29tcG9uZW50c0NyZWF0aW9uTWV0aG9kOiB7XG4gICAgICB0eXBlOiBPYmplY3QsXG4gICAgICAvKiBOb3RlOiBXZSBoYXZlIHRvIHByb3ZpZGUgYSBub25zZW5zZSB2YWx1ZSBmb3JcbiAgICAgICAqIHhDb21wb25lbnRzQ3JlYXRpb25NZXRob2QgaGVyZSwgYmVjYXVzZSBQb2x5bWVyIG9ic2VydmVycyBvbmx5XG4gICAgICAgKiB0cmlnZ2VyIGFmdGVyIGFsbCBwYXJhbWV0ZXJzIGFyZSBzZXQuICovXG4gICAgICB2YWx1ZTogJydcbiAgICB9LFxuXG4gICAgLyoqXG4gICAgICogQSBmb3JtYXR0ZXIgZm9yIHZhbHVlcyBhbG9uZyB0aGUgWC1heGlzLiBPcHRpb25hbC4gRGVmYXVsdHMgdG8gYVxuICAgICAqIHJlYXNvbmFibGUgZm9ybWF0dGVyLlxuICAgICAqXG4gICAgICogQHR5cGUge2Z1bmN0aW9uKG51bWJlcik6IHN0cmluZ31cbiAgICAgKi9cbiAgICB4QXhpc0Zvcm1hdHRlcjogT2JqZWN0LFxuXG4gICAgLyoqXG4gICAgICogQSBtZXRob2QgdGhhdCBpbXBsZW1lbnRzIHRoZSBQbG90dGFibGUuSUFjY2Vzc29yPG51bWJlcj4gaW50ZXJmYWNlLiBVc2VkXG4gICAgICogZm9yIGFjY2Vzc2luZyB0aGUgeSB2YWx1ZSBmcm9tIGEgZGF0YSBwb2ludC5cbiAgICAgKlxuICAgICAqIE5vdGUgdGhhdCB0aGlzIGZ1bmN0aW9uIHJldHVybnMgYSBmdW5jdGlvbiBiZWNhdXNlIHBvbHltZXIgY2FsbHMgdGhlXG4gICAgICogb3V0ZXIgZnVuY3Rpb24gdG8gY29tcHV0ZSB0aGUgdmFsdWUuIFdlIGFjdHVhbGx5IHdhbnQgdGhlIHZhbHVlIG9mIHRoaXNcbiAgICAgKiBwcm9wZXJ0eSB0byBiZSB0aGUgaW5uZXIgZnVuY3Rpb24uXG4gICAgICovXG4gICAgeVZhbHVlQWNjZXNzb3I6IHt0eXBlOiBPYmplY3QsIHZhbHVlOiAoKSA9PiAoZCA9PiBkLnNjYWxhcil9LFxuXG4gICAgLyoqXG4gICAgICogQW4gYXJyYXkgb2YgQ2hhcnRIZWxwZXIuVG9vbHRpcENvbHVtbiBvYmplY3RzLiBVc2VkIHRvIHBvcHVsYXRlIHRoZSB0YWJsZVxuICAgICAqIHdpdGhpbiB0aGUgdG9vbHRpcC4gVGhlIHRhYmxlIGNvbnRhaW5zIDEgcm93IHBlciBydW4uXG4gICAgICpcbiAgICAgKiBOb3RlIHRoYXQgdGhpcyBmdW5jdGlvbiByZXR1cm5zIGEgZnVuY3Rpb24gYmVjYXVzZSBwb2x5bWVyIGNhbGxzIHRoZVxuICAgICAqIG91dGVyIGZ1bmN0aW9uIHRvIGNvbXB1dGUgdGhlIHZhbHVlLiBXZSBhY3R1YWxseSB3YW50IHRoZSB2YWx1ZSBvZiB0aGlzXG4gICAgICogcHJvcGVydHkgdG8gYmUgdGhlIGlubmVyIGZ1bmN0aW9uLlxuICAgICAqXG4gICAgICovXG4gICAgdG9vbHRpcENvbHVtbnM6IHtcbiAgICAgIHR5cGU6IEFycmF5LFxuICAgICAgdmFsdWU6ICgpID0+IERFRkFVTFRfVE9PTFRJUF9DT0xVTU5TLFxuICAgIH0sXG5cbiAgICAvKipcbiAgICAgKiBBbiBvcHRpb25hbCBGaWxsQXJlYSBvYmplY3QuIElmIHByb3ZpZGVkLCB0aGUgY2hhcnQgd2lsbFxuICAgICAqIHZpc3VhbGl6ZSBmaWxsIGFyZWEgYWxvbmdzaWRlIHRoZSBwcmltYXJ5IGxpbmUgZm9yIGVhY2ggc2VyaWVzLiBJZiBzZXQsXG4gICAgICogY29uc2lkZXIgc2V0dGluZyBpZ25vcmVZT3V0bGllcnMgdG8gZmFsc2UuIE90aGVyd2lzZSwgb3V0bGllclxuICAgICAqIGNhbGN1bGF0aW9ucyBtYXkgZGVlbSBzb21lIG1hcmdpbnMgdG8gYmUgb3V0bGllcnMsIGFuZCBzb21lIHBvcnRpb25zIG9mXG4gICAgICogdGhlIGZpbGwgYXJlYSBtYXkgbm90IGRpc3BsYXkuXG4gICAgICovXG4gICAgZmlsbEFyZWE6IE9iamVjdCxcblxuICAgIC8qKlxuICAgICAqIEFuIG9wdGlvbmFsIGFycmF5IG9mIDIgbnVtYmVycyBmb3IgdGhlIG1pbiBhbmQgbWF4IG9mIHRoZSBkZWZhdWx0IHJhbmdlXG4gICAgICogb2YgdGhlIFkgYXhpcy4gSWYgbm90IHByb3ZpZGVkLCBhIHJlYXNvbmFibGUgcmFuZ2Ugd2lsbCBiZSBnZW5lcmF0ZWQuXG4gICAgICogVGhpcyBwcm9wZXJ0eSBpcyBhIGxpc3QgaW5zdGVhZCBvZiAyIGluZGl2aWR1YWwgcHJvcGVydGllcyB0byBlbXBoYXNpemVcbiAgICAgKiB0aGF0IGJvdGggdGhlIG1pbiBhbmQgdGhlIG1heCBtdXN0IGJlIHNwZWNpZmllZCAob3IgbmVpdGhlciBhdCBhbGwpLlxuICAgICAqL1xuICAgIGRlZmF1bHRYUmFuZ2U6IEFycmF5LFxuXG4gICAgLyoqXG4gICAgICogQW4gb3B0aW9uYWwgYXJyYXkgb2YgMiBudW1iZXJzIGZvciB0aGUgbWluIGFuZCBtYXggb2YgdGhlIGRlZmF1bHQgcmFuZ2VcbiAgICAgKiBvZiB0aGUgWSBheGlzLiBJZiBub3QgcHJvdmlkZWQsIGEgcmVhc29uYWJsZSByYW5nZSB3aWxsIGJlIGdlbmVyYXRlZC5cbiAgICAgKiBUaGlzIHByb3BlcnR5IGlzIGEgbGlzdCBpbnN0ZWFkIG9mIDIgaW5kaXZpZHVhbCBwcm9wZXJ0aWVzIHRvIGVtcGhhc2l6ZVxuICAgICAqIHRoYXQgYm90aCB0aGUgbWluIGFuZCB0aGUgbWF4IG11c3QgYmUgc3BlY2lmaWVkIChvciBuZWl0aGVyIGF0IGFsbCkuXG4gICAgICovXG4gICAgZGVmYXVsdFlSYW5nZTogQXJyYXksXG5cbiAgICAvKipcbiAgICAgKiBUaGUgc2NhbGUgZm9yIHRoZSB5LWF4aXMuIEFsbG93czpcbiAgICAgKiAtIFwibGluZWFyXCIgLSBsaW5lYXIgc2NhbGUgKFBsb3R0YWJsZS5TY2FsZXMuTGluZWFyKVxuICAgICAqIC0gXCJsb2dcIiAtIG1vZGlmaWVkLWxvZyBzY2FsZSAoUGxvdHRhYmxlLlNjYWxlcy5Nb2RpZmllZExvZylcbiAgICAgKi9cbiAgICB5U2NhbGVUeXBlOiB7dHlwZTogU3RyaW5nLCB2YWx1ZTogJ2xpbmVhcid9LFxuXG4gICAgLyoqXG4gICAgICogV2hldGhlciB0byBpZ25vcmUgb3V0bGllciBkYXRhIHdoZW4gY29tcHV0aW5nIHRoZSB5U2NhbGUgZG9tYWluLlxuICAgICAqL1xuICAgIGlnbm9yZVlPdXRsaWVyczoge1xuICAgICAgdHlwZTogQm9vbGVhbixcbiAgICAgIHZhbHVlOiBmYWxzZSxcbiAgICB9LFxuXG4gICAgLyoqXG4gICAgICogQ2hhbmdlIGhvdyB0aGUgdG9vbHRpcCBpcyBzb3J0ZWQuIEFsbG93czpcbiAgICAgKiAtIFwiZGVmYXVsdFwiIC0gU29ydCB0aGUgdG9vbHRpcCBieSBpbnB1dCBvcmRlci5cbiAgICAgKiAtIFwiYXNjZW5kaW5nXCIgLSBTb3J0IHRoZSB0b29sdGlwIGJ5IGFzY2VuZGluZyB2YWx1ZS5cbiAgICAgKiAtIFwiZGVzY2VuZGluZ1wiIC0gU29ydCB0aGUgdG9vbHRpcCBieSBkZXNjZW5kaW5nIHZhbHVlLlxuICAgICAqIC0gXCJuZWFyZXN0XCIgLSBTb3J0IHRoZSB0b29sdGlwIGJ5IGNsb3Nlc3QgdG8gY3Vyc29yLlxuICAgICAqL1xuICAgIHRvb2x0aXBTb3J0aW5nTWV0aG9kOiB7dHlwZTogU3RyaW5nLCB2YWx1ZTogJ2RlZmF1bHQnfSxcblxuICAgIC8qKlxuICAgICAqIENoYW5nZXMgaG93IHRoZSB0b29sdGlwIGlzIHBvc2l0aW9uZWQuIEFsbG93czpcbiAgICAgKiAtIFwiYm90dG9tXCIgLSBQb3NpdGlvbiB0aGUgdG9vbHRpcCBvbiB0aGUgYm90dG9tIG9mIHRoZSBjaGFydC5cbiAgICAgKiAtIFwicmlnaHRcIiAtIFBvc2l0aW9uIHRoZSB0b29sdGlwIHRvIHRoZSByaWdodCBvZiB0aGUgY2hhcnQuXG4gICAgICogLSBcImF1dG9cIiAtIFBvc2l0aW9uIHRoZSB0b29sdGlwIHRvIHRoZSBib3R0b20gb2YgdGhlIGNoYXJ0IGluIG1vc3QgY2FzZS5cbiAgICAgKiAgICAgICAgICAgIFBvc2l0aW9uIHRoZSB0b29sdGlwIGFib3ZlIHRoZSBjaGFydCBpZiB0aGVyZSBpc24ndCBzdWZmaWNpZW50XG4gICAgICogICAgICAgICAgICBzcGFjZSBiZWxvdy5cbiAgICAgKi9cbiAgICB0b29sdGlwUG9zaXRpb246IHtcbiAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgIHZhbHVlOiB2el9jaGFydF9oZWxwZXIuVG9vbHRpcFBvc2l0aW9uLkJPVFRPTSxcbiAgICB9LFxuXG4gICAgX2NoYXJ0OiBPYmplY3QsXG4gICAgX3Zpc2libGVTZXJpZXNDYWNoZToge1xuICAgICAgdHlwZTogQXJyYXksXG4gICAgICB2YWx1ZTogKCkgPT4gW10sXG4gICAgfSxcbiAgICBfc2VyaWVzRGF0YUNhY2hlOiB7XG4gICAgICB0eXBlOiBPYmplY3QsXG4gICAgICB2YWx1ZTogKCkgPT4gKHt9KSxcbiAgICB9LFxuICAgIF9zZXJpZXNNZXRhZGF0YUNhY2hlOiB7XG4gICAgICB0eXBlOiBPYmplY3QsXG4gICAgICB2YWx1ZTogKCkgPT4gKHt9KSxcbiAgICB9LFxuICAgIF9tYWtlQ2hhcnRBc3luY0NhbGxiYWNrSWQ6IHt0eXBlOiBOdW1iZXIsIHZhbHVlOiBudWxsfSxcbiAgfSxcblxuICBvYnNlcnZlcnM6IFtcbiAgICAnX21ha2VDaGFydCh4Q29tcG9uZW50c0NyZWF0aW9uTWV0aG9kLCB4VHlwZSwgeVZhbHVlQWNjZXNzb3IsIHlTY2FsZVR5cGUsIHRvb2x0aXBDb2x1bW5zLCBjb2xvclNjYWxlLCBpc0F0dGFjaGVkKScsXG4gICAgJ19yZWxvYWRGcm9tQ2FjaGUoX2NoYXJ0KScsXG4gICAgJ19zbW9vdGhpbmdDaGFuZ2VkKHNtb290aGluZ0VuYWJsZWQsIHNtb290aGluZ1dlaWdodCwgX2NoYXJ0KScsXG4gICAgJ190b29sdGlwU29ydGluZ01ldGhvZENoYW5nZWQodG9vbHRpcFNvcnRpbmdNZXRob2QsIF9jaGFydCknLFxuICAgICdfb3V0bGllcnNDaGFuZ2VkKGlnbm9yZVlPdXRsaWVycywgX2NoYXJ0KScsXG4gIF0sXG5cbiAgcmVhZHkoKSB7XG4gICAgdGhpcy5zY29wZVN1YnRyZWUodGhpcy4kLmNoYXJ0ZGl2LCB0cnVlKTtcbiAgfSxcblxuICBhdHRhY2hlZCgpIHtcbiAgICAvLyBgY2FwdHVyZWAgZW5zdXJlcyB0aGF0IG5vIGhhbmRsZXIgY2FuIHN0b3AgcHJvcGFnYXRpb24gYW5kIGJyZWFrIHRoZVxuICAgIC8vIGhhbmRsZXIuIGBwYXNzaXZlYCBlbnN1cmVzIHRoYXQgYnJvd3NlciBkb2VzIG5vdCB3YWl0IHJlbmRlcmVyIHRocmVhZFxuICAgIC8vIG9uIEpTIGhhbmRsZXIgKHdoaWNoIGNhbiBwcmV2ZW50IGRlZmF1bHQgYW5kIGltcGFjdCByZW5kZXJpbmcpLlxuICAgIGNvbnN0IG9wdGlvbiA9IHtjYXB0dXJlOiB0cnVlLCBwYXNzaXZlOiB0cnVlfTtcbiAgICB0aGlzLl9saXN0ZW4odGhpcywgJ21vdXNlZG93bicsIHRoaXMuX29uTW91c2VEb3duLmJpbmQodGhpcyksIG9wdGlvbik7XG4gICAgdGhpcy5fbGlzdGVuKHRoaXMsICdtb3VzZXVwJywgdGhpcy5fb25Nb3VzZVVwLmJpbmQodGhpcyksIG9wdGlvbik7XG4gICAgdGhpcy5fbGlzdGVuKHdpbmRvdywgJ2tleWRvd24nLCB0aGlzLl9vbktleURvd24uYmluZCh0aGlzKSwgb3B0aW9uKTtcbiAgICB0aGlzLl9saXN0ZW4od2luZG93LCAna2V5dXAnLCB0aGlzLl9vbktleVVwLmJpbmQodGhpcyksIG9wdGlvbik7XG4gIH0sXG5cbiAgZGV0YWNoZWQoKSB7XG4gICAgdGhpcy5jYW5jZWxBc3luYyh0aGlzLl9tYWtlQ2hhcnRBc3luY0NhbGxiYWNrSWQpO1xuICAgIGlmICh0aGlzLl9jaGFydCkgdGhpcy5fY2hhcnQuZGVzdHJveSgpO1xuICAgIGlmICh0aGlzLl9saXN0ZW5lcnMpIHtcbiAgICAgIHRoaXMuX2xpc3RlbmVycy5mb3JFYWNoKCh7bm9kZSwgZXZlbnROYW1lLCBmdW5jLCBvcHRpb259KSA9PiB7XG4gICAgICAgIG5vZGUucmVtb3ZlRXZlbnRMaXN0ZW5lcihldmVudE5hbWUsIGZ1bmMsIG9wdGlvbik7XG4gICAgICB9KTtcbiAgICAgIHRoaXMuX2xpc3RlbmVycy5jbGVhcigpO1xuICAgIH1cbiAgfSxcblxuICBfbGlzdGVuKG5vZGU6IE5vZGUsIGV2ZW50TmFtZTogc3RyaW5nLCBmdW5jOiAoZXZlbnQpID0+IHZvaWQsIG9wdGlvbiA9IHt9KSB7XG4gICAgaWYgKCF0aGlzLl9saXN0ZW5lcnMpIHRoaXMuX2xpc3RlbmVycyA9IG5ldyBTZXQoKTtcbiAgICB0aGlzLl9saXN0ZW5lcnMuYWRkKHtub2RlLCBldmVudE5hbWUsIGZ1bmMsIG9wdGlvbn0pO1xuICAgIG5vZGUuYWRkRXZlbnRMaXN0ZW5lcihldmVudE5hbWUsIGZ1bmMsIG9wdGlvbik7XG4gIH0sXG5cbiAgX29uS2V5RG93bihldmVudCkge1xuICAgIHRoaXMudG9nZ2xlQ2xhc3MoJ3BhbmtleScsIFBhblpvb21EcmFnTGF5ZXIuaXNQYW5LZXkoZXZlbnQpKTtcbiAgfSxcblxuICBfb25LZXlVcChldmVudCkge1xuICAgIHRoaXMudG9nZ2xlQ2xhc3MoJ3BhbmtleScsIFBhblpvb21EcmFnTGF5ZXIuaXNQYW5LZXkoZXZlbnQpKTtcbiAgfSxcblxuICBfb25Nb3VzZURvd24oZXZlbnQpIHtcbiAgICB0aGlzLnRvZ2dsZUNsYXNzKCdtb3VzZWRvd24nLCB0cnVlKTtcbiAgfSxcblxuICBfb25Nb3VzZVVwKGV2ZW50KSB7XG4gICAgdGhpcy50b2dnbGVDbGFzcygnbW91c2Vkb3duJywgZmFsc2UpO1xuICB9LFxuXG4gIC8qKlxuICAgKiBTZXRzIHRoZSBzZXJpZXMgdGhhdCB0aGUgY2hhcnQgZGlzcGxheXMuIFNlcmllcyB3aXRoIG90aGVyIG5hbWVzIHdpbGxcbiAgICogbm90IGJlIGRpc3BsYXllZC5cbiAgICpcbiAgICogQHBhcmFtIHtBcnJheTxTdHJpbmc+fSBuYW1lcyBBcnJheSB3aXRoIHRoZSBuYW1lcyBvZiB0aGUgc2VyaWVzIHRvXG4gICAqIGRpc3BsYXkuXG4gICAqL1xuICBzZXRWaXNpYmxlU2VyaWVzOiBmdW5jdGlvbihuYW1lcykge1xuICAgIGlmIChfLmlzRXF1YWwodGhpcy5fdmlzaWJsZVNlcmllc0NhY2hlLCBuYW1lcykpIHJldHVybjtcbiAgICB0aGlzLl92aXNpYmxlU2VyaWVzQ2FjaGUgPSBuYW1lcztcbiAgICBpZiAodGhpcy5fY2hhcnQpIHtcbiAgICAgIHRoaXMuX2NoYXJ0LnNldFZpc2libGVTZXJpZXMobmFtZXMpO1xuICAgICAgdGhpcy5yZWRyYXcoKTtcbiAgICB9XG4gIH0sXG5cbiAgLyoqXG4gICAqIFNldHMgdGhlIGRhdGEgb2Ygb25lIG9mIHRoZSBzZXJpZXMuIE5vdGUgdGhhdCB0byBkaXNwbGF5IHRoaXMgc2VyaWVzXG4gICAqIGl0cyBuYW1lIG11c3QgYmUgaW4gdGhlIHNldFZpc2libGVTZXJpZXMoKSBhcnJheS5cbiAgICpcbiAgICogQHBhcmFtIHtzdHJpbmd9IG5hbWUgTmFtZSBvZiB0aGUgc2VyaWVzLlxuICAgKiBAcGFyYW0ge0FycmF5PCF2el9jaGFydF9oZWxwZXJzLlNjYWxhckRhdHVtPn0gZGF0YSBEYXRhIG9mIHRoZSBzZXJpZXMuXG4gICAqIFRoaXMgaXMgYW4gYXJyYXkgb2Ygb2JqZWN0cyB3aXRoIGF0IGxlYXN0IHRoZSBmb2xsb3dpbmcgcHJvcGVydGllczpcbiAgICogLSBzdGVwOiAoTnVtYmVyKSAtIGluZGV4IG9mIHRoZSBkYXR1bS5cbiAgICogLSB3YWxsX3RpbWU6IChEYXRlKSAtIERhdGUgb2JqZWN0IHdpdGggdGhlIGRhdHVtJ3MgdGltZS5cbiAgICogLSBzY2FsYXI6IChOdW1iZXIpIC0gVmFsdWUgb2YgdGhlIGRhdHVtLlxuICAgKi9cbiAgc2V0U2VyaWVzRGF0YTogZnVuY3Rpb24obmFtZSwgZGF0YSkge1xuICAgIHRoaXMuX3Nlcmllc0RhdGFDYWNoZVtuYW1lXSA9IGRhdGE7XG4gICAgaWYgKHRoaXMuX2NoYXJ0KSB7XG4gICAgICB0aGlzLl9jaGFydC5zZXRTZXJpZXNEYXRhKG5hbWUsIGRhdGEpO1xuICAgIH1cbiAgfSxcblxuICAvKipcbiAgICogU2V0cyB0aGUgbWV0YWRhdGEgb2Ygb25lIG9mIHRoZSBzZXJpZXMuXG4gICAqXG4gICAqIEBwYXJhbSB7c3RyaW5nfSBuYW1lIE5hbWUgb2YgdGhlIHNlcmllcy5cbiAgICogQHBhcmFtIHsqfSBtZXRhIE1ldGFkYXRhIG9mIHRoZSBkYXRhc2V0IHVzZWQgZm9yIGxhdGVyXG4gICAqL1xuICBzZXRTZXJpZXNNZXRhZGF0YShuYW1lOiBzdHJpbmcsIG1ldGE6IGFueSkge1xuICAgIHRoaXMuX3Nlcmllc01ldGFkYXRhQ2FjaGVbbmFtZV0gPSBtZXRhO1xuICAgIGlmICh0aGlzLl9jaGFydCkge1xuICAgICAgdGhpcy5fY2hhcnQuc2V0U2VyaWVzTWV0YWRhdGEobmFtZSwgbWV0YSk7XG4gICAgfVxuICB9LFxuXG4gIC8qKlxuICAgKiBSZXNldCB0aGUgY2hhcnQgZG9tYWluLiBJZiB0aGUgY2hhcnQgaGFzIG5vdCByZW5kZXJlZCB5ZXQsIGEgY2FsbCB0byB0aGlzXG4gICAqIG1ldGhvZCBuby1vcHMuXG4gICAqL1xuICByZXNldERvbWFpbjogZnVuY3Rpb24oKSB7XG4gICAgaWYgKHRoaXMuX2NoYXJ0KSB7XG4gICAgICB0aGlzLl9jaGFydC5yZXNldERvbWFpbigpO1xuICAgIH1cbiAgfSxcblxuICAvKipcbiAgICogUmUtcmVuZGVycyB0aGUgY2hhcnQuIFVzZWZ1bCBpZiBlLmcuIHRoZSBjb250YWluZXIgc2l6ZSBjaGFuZ2VkLlxuICAgKi9cbiAgcmVkcmF3OiBmdW5jdGlvbigpIHtcbiAgICBpZiAodGhpcy5fY2hhcnQpIHtcbiAgICAgIHRoaXMuX2NoYXJ0LnJlZHJhdygpO1xuICAgIH1cbiAgfSxcblxuICAvKipcbiAgICogQ3JlYXRlcyBhIGNoYXJ0LCBhbmQgYXN5bmNocm9ub3VzbHkgcmVuZGVycyBpdC4gRmlyZXMgYSBjaGFydC1yZW5kZXJlZFxuICAgKiBldmVudCBhZnRlciB0aGUgY2hhcnQgaXMgcmVuZGVyZWQuXG4gICAqL1xuICBfbWFrZUNoYXJ0OiBmdW5jdGlvbihcbiAgICAgIHhDb21wb25lbnRzQ3JlYXRpb25NZXRob2QsXG4gICAgICB4VHlwZSxcbiAgICAgIHlWYWx1ZUFjY2Vzc29yLFxuICAgICAgeVNjYWxlVHlwZSxcbiAgICAgIHRvb2x0aXBDb2x1bW5zLFxuICAgICAgY29sb3JTY2FsZSkge1xuICAgIC8vIEZpbmQgdGhlIGFjdHVhbCB4Q29tcG9uZW50c0NyZWF0aW9uTWV0aG9kLlxuICAgIGlmICgheFR5cGUgJiYgIXhDb21wb25lbnRzQ3JlYXRpb25NZXRob2QpIHtcbiAgICAgIHhDb21wb25lbnRzQ3JlYXRpb25NZXRob2QgPSB2el9jaGFydF9oZWxwZXJzLnN0ZXBYO1xuICAgIH0gZWxzZSBpZiAoeFR5cGUpIHtcbiAgICAgIHhDb21wb25lbnRzQ3JlYXRpb25NZXRob2QgPSAoKSA9PlxuICAgICAgICAgIHZ6X2NoYXJ0X2hlbHBlcnMuZ2V0WENvbXBvbmVudHMoeFR5cGUpO1xuICAgIH1cblxuICAgIGlmICh0aGlzLl9tYWtlQ2hhcnRBc3luY0NhbGxiYWNrSWQgIT09IG51bGwpIHtcbiAgICAgIHRoaXMuY2FuY2VsQXN5bmModGhpcy5fbWFrZUNoYXJ0QXN5bmNDYWxsYmFja0lkKTtcbiAgICAgIHRoaXMuX21ha2VDaGFydEFzeW5jQ2FsbGJhY2tJZCA9IG51bGw7XG4gICAgfVxuXG4gICAgdGhpcy5fbWFrZUNoYXJ0QXN5bmNDYWxsYmFja0lkID0gdGhpcy5hc3luYyhmdW5jdGlvbigpIHtcbiAgICAgIHRoaXMuX21ha2VDaGFydEFzeW5jQ2FsbGJhY2tJZCA9IG51bGw7XG4gICAgICBpZiAoIXhDb21wb25lbnRzQ3JlYXRpb25NZXRob2QgfHxcbiAgICAgICAgICAhdGhpcy55VmFsdWVBY2Nlc3NvciB8fFxuICAgICAgICAgICF0aGlzLnRvb2x0aXBDb2x1bW5zKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIC8vIFdlIGRpcmVjdGx5IHJlZmVyZW5jZSBwcm9wZXJ0aWVzIG9mIGB0aGlzYCBiZWNhdXNlIHRoaXMgY2FsbCBpc1xuICAgICAgLy8gYXN5bmNocm9ub3VzLCBhbmQgdmFsdWVzIG1heSBoYXZlIGNoYW5nZWQgaW4gYmV0d2VlbiB0aGUgY2FsbCBiZWluZ1xuICAgICAgLy8gaW5pdGlhdGVkIGFuZCBhY3R1YWxseSBiZWluZyBydW4uXG4gICAgICB2YXIgY2hhcnQgPSBuZXcgTGluZUNoYXJ0KFxuICAgICAgICAgIHhDb21wb25lbnRzQ3JlYXRpb25NZXRob2QsXG4gICAgICAgICAgdGhpcy55VmFsdWVBY2Nlc3NvcixcbiAgICAgICAgICB5U2NhbGVUeXBlLFxuICAgICAgICAgIGNvbG9yU2NhbGUsXG4gICAgICAgICAgdGhpcy4kLnRvb2x0aXAsXG4gICAgICAgICAgdGhpcy50b29sdGlwQ29sdW1ucyxcbiAgICAgICAgICB0aGlzLmZpbGxBcmVhLFxuICAgICAgICAgIHRoaXMuZGVmYXVsdFhSYW5nZSxcbiAgICAgICAgICB0aGlzLmRlZmF1bHRZUmFuZ2UsXG4gICAgICAgICAgdGhpcy5zeW1ib2xGdW5jdGlvbixcbiAgICAgICAgICB0aGlzLnhBeGlzRm9ybWF0dGVyKTtcbiAgICAgIHZhciBkaXYgPSBkMy5zZWxlY3QodGhpcy4kLmNoYXJ0ZGl2KTtcbiAgICAgIGNoYXJ0LnJlbmRlclRvKGRpdik7XG4gICAgICBpZiAodGhpcy5fY2hhcnQpIHRoaXMuX2NoYXJ0LmRlc3Ryb3koKTtcbiAgICAgIHRoaXMuX2NoYXJ0ID0gY2hhcnQ7XG4gICAgICB0aGlzLl9jaGFydC5vbkFuY2hvcigoKSA9PiB0aGlzLmZpcmUoJ2NoYXJ0LWF0dGFjaGVkJykpO1xuICAgIH0sIDM1MCk7XG4gIH0sXG5cbiAgX3JlbG9hZEZyb21DYWNoZTogZnVuY3Rpb24oKSB7XG4gICAgaWYgKCF0aGlzLl9jaGFydCkgcmV0dXJuO1xuICAgIHRoaXMuX3Zpc2libGVTZXJpZXNDYWNoZS5mb3JFYWNoKG5hbWUgPT4ge1xuICAgICAgdGhpcy5fY2hhcnQuc2V0U2VyaWVzRGF0YShuYW1lLCB0aGlzLl9zZXJpZXNEYXRhQ2FjaGVbbmFtZV0gfHwgW10pO1xuICAgIH0pO1xuICAgIHRoaXMuX3Zpc2libGVTZXJpZXNDYWNoZVxuICAgICAgICAuZmlsdGVyKG5hbWUgPT4gdGhpcy5fc2VyaWVzTWV0YWRhdGFDYWNoZVtuYW1lXSlcbiAgICAgICAgLmZvckVhY2gobmFtZSA9PiB7XG4gICAgICAgICAgdGhpcy5fY2hhcnQuc2V0U2VyaWVzTWV0YWRhdGEobmFtZSwgdGhpcy5fc2VyaWVzTWV0YWRhdGFDYWNoZVtuYW1lXSk7XG4gICAgICAgIH0pO1xuICAgIHRoaXMuX2NoYXJ0LnNldFZpc2libGVTZXJpZXModGhpcy5fdmlzaWJsZVNlcmllc0NhY2hlKTtcbiAgfSxcblxuICBfc21vb3RoaW5nQ2hhbmdlZDogZnVuY3Rpb24oKSB7XG4gICAgaWYgKCF0aGlzLl9jaGFydCkgcmV0dXJuO1xuICAgIGlmICh0aGlzLnNtb290aGluZ0VuYWJsZWQpIHtcbiAgICAgIHRoaXMuX2NoYXJ0LnNtb290aGluZ1VwZGF0ZSh0aGlzLnNtb290aGluZ1dlaWdodCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMuX2NoYXJ0LnNtb290aGluZ0Rpc2FibGUoKTtcbiAgICB9XG4gIH0sXG5cbiAgX291dGxpZXJzQ2hhbmdlZDogZnVuY3Rpb24oKSB7XG4gICAgaWYgKCF0aGlzLl9jaGFydCkgcmV0dXJuO1xuICAgIHRoaXMuX2NoYXJ0Lmlnbm9yZVlPdXRsaWVycyh0aGlzLmlnbm9yZVlPdXRsaWVycyk7XG4gIH0sXG5cbiAgX3Rvb2x0aXBTb3J0aW5nTWV0aG9kQ2hhbmdlZDogZnVuY3Rpb24oKSB7XG4gICAgaWYgKCF0aGlzLl9jaGFydCkgcmV0dXJuO1xuICAgIHRoaXMuX2NoYXJ0LnNldFRvb2x0aXBTb3J0aW5nTWV0aG9kKHRoaXMudG9vbHRpcFNvcnRpbmdNZXRob2QpO1xuICB9LFxuXG4gIGdldEV4cG9ydGVyKCkge1xuICAgIHJldHVybiBuZXcgTGluZUNoYXJ0RXhwb3J0ZXIodGhpcy4kLmNoYXJ0ZGl2KTtcbiAgfSxcblxufSk7XG5cbn0gIC8vIG5hbWVzcGFjZSB2el9saW5lX2NoYXJ0MlxuIl19