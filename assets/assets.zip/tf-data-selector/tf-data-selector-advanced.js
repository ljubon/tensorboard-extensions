/* Copyright 2018 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the 'License');
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an 'AS IS' BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
var tf_data_selector;
(function (tf_data_selector) {
    Polymer({
        is: 'tf-data-selector-advanced',
        properties: {
            _allExperimentsFetched: {
                type: Boolean,
                value: false,
            },
            _allExperiments: {
                type: Array,
                value: function () { return []; },
            },
            // Subset of allExperiments user chose and added.
            _experimentIds: {
                type: Array,
                value: tf_data_selector.getIdInitializer('e', {
                    defaultValue: [],
                    polymerProperty: '_experimentIds',
                }),
            },
            _experiments: {
                type: Array,
                value: function () { return []; },
            },
            _enabledExperimentIds: {
                type: Array,
                value: tf_data_selector.getIdInitializer('ee', {
                    defaultValue: [],
                    polymerProperty: '_enabledExperimentIds',
                }),
            },
            _selections: {
                type: Object,
                value: function () {
                    return new Map();
                },
            },
            activePlugins: {
                type: Array,
                value: function () { return []; },
            },
            // Output property. It has subset of _selections.
            selection: {
                type: Object,
                notify: true,
                computed: '_computeSelection(_enabledExperimentIds.*, _selections.*, activePlugins.*)',
            },
            _canCompareExperiments: {
                type: Boolean,
                value: false
            },
            _shouldColorRuns: {
                type: Boolean,
                computed: '_computeShouldColorRuns(_experiments.*)',
            },
        },
        behaviors: [
            tf_dashboard_common.ArrayUpdateHelper,
        ],
        observers: [
            '_updateExperiments(_allExperiments, _experimentIds)',
            '_pruneSelections(_experimentIds.*)',
            '_pruneExperimentIds(_allExperiments.*)',
            '_pruneEnabledExperiments(_experimentIds.*)',
            '_persistExperimentIds(_experimentIds.*)',
            '_persistEnabledExperiments(_enabledExperimentIds.*)',
        ],
        _persistExperimentIds: tf_data_selector.getIdObserver('e', {
            defaultValue: [],
            polymerProperty: '_experimentIds',
        }),
        _persistEnabledExperiments: tf_data_selector.getIdObserver('ee', {
            defaultValue: [],
            polymerProperty: '_enabledExperimentIds',
        }),
        attached: function () {
            var _this = this;
            this._updateExpKey = tf_backend.experimentsStore.addListener(function () {
                _this._allExperiments = tf_backend.experimentsStore.getExperiments();
                _this._allExperimentsFetched = true;
            });
            this._allExperiments = tf_backend.experimentsStore.getExperiments();
            this._allExperimentsFetched = tf_backend.experimentsStore.initialized;
            this._updateEnvKey = tf_backend.environmentStore.addListener(function () {
                _this._canCompareExperiments = tf_backend.Mode.DB ==
                    tf_backend.environmentStore.getMode();
            });
            this._canCompareExperiments = tf_backend.Mode.DB ==
                tf_backend.environmentStore.getMode();
        },
        detached: function () {
            tf_backend.experimentsStore.removeListenerByKey(this._updateExpKey);
            tf_backend.environmentStore.removeListenerByKey(this._updateEnvKey);
        },
        _getPersistenceId: function (experiment) {
            return tf_data_selector.encodeId(experiment.id);
        },
        _isExperimentEnabled: function (experiment) {
            var enabledExperimentIds = new Set(this._enabledExperimentIds);
            return enabledExperimentIds.has(experiment.id);
        },
        _getExperimentColor: function (experiment) {
            return tf_color_scale.experimentsColorScale(experiment.name);
        },
        _computeShouldColorRuns: function () {
            return this._experiments.length <= 1;
        },
        /**
         * Prunes away an experiment that has been removed from `_experiments` from
         * the selection.
         */
        _pruneSelections: function () {
            if (!this._selections)
                return;
            var experimentIds = new Set(this._experimentIds);
            var newSelections = new Map(this._selections);
            newSelections.forEach(function (_, id) {
                // No experiment selection is still a valid selection. Do not prune.
                if (id == tf_data_selector.NO_EXPERIMENT_ID)
                    return;
                if (!experimentIds.has(id))
                    newSelections.delete(id);
            });
            this._selections = newSelections;
        },
        _pruneExperimentIds: function () {
            if (!this._allExperimentsFetched)
                return;
            var allExpIds = new Set(this._allExperiments.map(function (_a) {
                var id = _a.id;
                return id;
            }));
            this._experimentIds = this._experimentIds.filter(function (id) { return allExpIds.has(id); });
        },
        _pruneEnabledExperiments: function () {
            // When the component never fully loaded the list of experiments, it
            // cannot correctly prune/adjust the enabledExperiments.
            if (!this._allExperimentsFetched)
                return;
            var expIds = new Set(this._experimentIds);
            this._enabledExperimentIds = this._enabledExperimentIds
                .filter(function (id) { return expIds.has(id); });
        },
        _computeSelection: function () {
            var _this = this;
            if (this._canCompareExperiments) {
                var activePluginNames_1 = new Set(this.activePlugins);
                var selections = this._enabledExperimentIds
                    .filter(function (id) { return _this._selections.has(id); })
                    .map(function (id) { return _this._selections.get(id); })
                    .map(function (selection) {
                    var updatedSelection = Object.assign({}, selection);
                    updatedSelection.runs = selection.runs.map(function (run) {
                        return Object.assign({}, run, {
                            tags: run.tags
                                .filter(function (tag) { return activePluginNames_1.has(tag.pluginName); }),
                        });
                    }).filter(function (run) { return run.tags.length; });
                    return updatedSelection;
                });
                // Single selection: one experimentful selection whether it is enabled or
                // not.
                // NOTE: `_selections` can contain not only selections for experiment
                // diffing but also one for no-experiment mode. If it contains one,
                // "remove" the size by one.
                var isSingleSelection = this._selections.size ==
                    1 + Number(this._selections.has(tf_data_selector.NO_EXPERIMENT_ID));
                return {
                    type: isSingleSelection ?
                        tf_data_selector.Type.SINGLE : tf_data_selector.Type.COMPARISON,
                    selections: selections,
                };
            }
            return {
                type: tf_data_selector.Type.WITHOUT_EXPERIMENT,
                selections: [this._selections.get(tf_data_selector.NO_EXPERIMENT_ID)],
            };
        },
        _selectionChanged: function (event) {
            event.stopPropagation();
            if (!this.isAttached || !event.target.isAttached)
                return;
            var _a = event.detail, runs = _a.runs, tagRegex = _a.tagRegex;
            var experiment = event.target.experiment;
            var expId = experiment.id != null ? experiment.id : tf_data_selector.NO_EXPERIMENT_ID;
            // Check if selction change event was triggered from a removed row. Removal
            // triggers change in persistence (clears the value) and this causes
            // property to change which in turn triggers an event. If there is any
            // asynchronity in propagating the change from the row, below condition is
            // truthy.
            if (expId != tf_data_selector.NO_EXPERIMENT_ID && !this._experimentIds.includes(expId)) {
                return;
            }
            var newSelections = new Map(this._selections);
            newSelections.set(expId, { experiment: experiment, runs: runs, tagRegex: tagRegex });
            // Ignore the selection changed event if it makes no tangible difference to
            // the _selections.
            if (_.isEqual(newSelections, this._selections))
                return;
            this._selections = newSelections;
        },
        _updateExperiments: function () {
            var lookup = new Map(this._allExperiments.map(function (e) { return [e.id, e]; }));
            var experiments = this._experimentIds
                .filter(function (id) { return lookup.has(id); })
                .map(function (id) { return lookup.get(id); });
            this.updateArrayProp('_experiments', experiments, function (exp) { return exp.id; });
        },
        _addExperiments: function (event) {
            var addedIds = event.detail.map(function (_a) {
                var id = _a.id;
                return id;
            });
            this._experimentIds = uniqueAdd(this._experimentIds, addedIds);
            // Enable newly added experiments by default
            this._enabledExperimentIds = uniqueAdd(this._enabledExperimentIds, addedIds);
        },
        _removeExperiment: function (event) {
            var removedId = event.target.experiment.id;
            // Changing _experimentIds will remove the id from _enabledExperimentIds.
            this._experimentIds = this._experimentIds.filter(function (id) { return id != removedId; });
        },
        _experimentCheckboxToggled: function (e) {
            var newId = e.target.experiment.id;
            if (e.target.enabled) {
                this._enabledExperimentIds = uniqueAdd(this._enabledExperimentIds, [newId]);
            }
            else {
                this._enabledExperimentIds = this._enabledExperimentIds
                    .filter(function (id) { return id != newId; });
            }
        },
        _getAddComparisonVisible: function () {
            return this._canCompareExperiments &&
                this._allExperiments.length > this._experiments.length;
        },
        _getAddComparisonAlwaysExpanded: function () {
            return this._canCompareExperiments && !this._experiments.length;
        },
    });
    /**
     * Append items to an array without duplicate entries.
     */
    function uniqueAdd(to, items) {
        var toSet = new Set(to);
        items.forEach(function (item) { return toSet.add(item); });
        return Array.from(toSet);
    }
})(tf_data_selector || (tf_data_selector = {})); // namespace tf_data_selector
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGYtZGF0YS1zZWxlY3Rvci1hZHZhbmNlZC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbInRmLWRhdGEtc2VsZWN0b3ItYWR2YW5jZWQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7Ozs7Ozs7Z0ZBYWdGO0FBQ2hGLElBQVUsZ0JBQWdCLENBdVJ6QjtBQXZSRCxXQUFVLGdCQUFnQjtJQUUxQixPQUFPLENBQUM7UUFDTixFQUFFLEVBQUUsMkJBQTJCO1FBQy9CLFVBQVUsRUFBRTtZQUNWLHNCQUFzQixFQUFFO2dCQUN0QixJQUFJLEVBQUUsT0FBTztnQkFDYixLQUFLLEVBQUUsS0FBSzthQUNiO1lBRUQsZUFBZSxFQUFFO2dCQUNmLElBQUksRUFBRSxLQUFLO2dCQUNYLEtBQUssRUFBRSxjQUFvQyxPQUFBLEVBQUUsRUFBRixDQUFFO2FBQzlDO1lBRUQsaURBQWlEO1lBQ2pELGNBQWMsRUFBRTtnQkFDZCxJQUFJLEVBQUUsS0FBSztnQkFDWCxLQUFLLEVBQUUsaUJBQUEsZ0JBQWdCLENBQUMsR0FBRyxFQUFFO29CQUMzQixZQUFZLEVBQUUsRUFBRTtvQkFDaEIsZUFBZSxFQUFFLGdCQUFnQjtpQkFDbEMsQ0FBQzthQUNIO1lBRUQsWUFBWSxFQUFFO2dCQUNaLElBQUksRUFBRSxLQUFLO2dCQUNYLEtBQUssRUFBRSxjQUFvQyxPQUFBLEVBQUUsRUFBRixDQUFFO2FBQzlDO1lBRUQscUJBQXFCLEVBQUU7Z0JBQ3JCLElBQUksRUFBRSxLQUFLO2dCQUNYLEtBQUssRUFBRSxpQkFBQSxnQkFBZ0IsQ0FBQyxJQUFJLEVBQUU7b0JBQzVCLFlBQVksRUFBRSxFQUFFO29CQUNoQixlQUFlLEVBQUUsdUJBQXVCO2lCQUN6QyxDQUFDO2FBQ0g7WUFFRCxXQUFXLEVBQUU7Z0JBQ1gsSUFBSSxFQUFFLE1BQU07Z0JBQ1osS0FBSyxFQUFFO29CQUNMLE9BQU8sSUFBSSxHQUFHLEVBQUUsQ0FBQztnQkFDbkIsQ0FBQzthQUNGO1lBRUQsYUFBYSxFQUFFO2dCQUNiLElBQUksRUFBRSxLQUFLO2dCQUNYLEtBQUssRUFBRSxjQUFnQixPQUFBLEVBQUUsRUFBRixDQUFFO2FBQzFCO1lBRUQsaURBQWlEO1lBQ2pELFNBQVMsRUFBRTtnQkFDVCxJQUFJLEVBQUUsTUFBTTtnQkFDWixNQUFNLEVBQUUsSUFBSTtnQkFDWixRQUFRLEVBQUUsNEVBQTRFO2FBQ3ZGO1lBRUQsc0JBQXNCLEVBQUU7Z0JBQ3RCLElBQUksRUFBRSxPQUFPO2dCQUNiLEtBQUssRUFBRSxLQUFLO2FBQ2I7WUFFRCxnQkFBZ0IsRUFBRTtnQkFDaEIsSUFBSSxFQUFFLE9BQU87Z0JBQ2IsUUFBUSxFQUFFLHlDQUF5QzthQUNwRDtTQUVGO1FBRUQsU0FBUyxFQUFFO1lBQ1QsbUJBQW1CLENBQUMsaUJBQWlCO1NBQ3RDO1FBRUQsU0FBUyxFQUFFO1lBQ1QscURBQXFEO1lBQ3JELG9DQUFvQztZQUNwQyx3Q0FBd0M7WUFDeEMsNENBQTRDO1lBQzVDLHlDQUF5QztZQUN6QyxxREFBcUQ7U0FDdEQ7UUFFRCxxQkFBcUIsRUFBRSxpQkFBQSxhQUFhLENBQUMsR0FBRyxFQUFFO1lBQ3hDLFlBQVksRUFBRSxFQUFFO1lBQ2hCLGVBQWUsRUFBRSxnQkFBZ0I7U0FDbEMsQ0FBQztRQUVGLDBCQUEwQixFQUFFLGlCQUFBLGFBQWEsQ0FBQyxJQUFJLEVBQUU7WUFDOUMsWUFBWSxFQUFFLEVBQUU7WUFDaEIsZUFBZSxFQUFFLHVCQUF1QjtTQUN6QyxDQUFDO1FBRUYsUUFBUTtZQUFSLGlCQWNDO1lBYkMsSUFBSSxDQUFDLGFBQWEsR0FBRyxVQUFVLENBQUMsZ0JBQWdCLENBQUMsV0FBVyxDQUFDO2dCQUMzRCxLQUFJLENBQUMsZUFBZSxHQUFHLFVBQVUsQ0FBQyxnQkFBZ0IsQ0FBQyxjQUFjLEVBQUUsQ0FBQztnQkFDcEUsS0FBSSxDQUFDLHNCQUFzQixHQUFHLElBQUksQ0FBQztZQUNyQyxDQUFDLENBQUMsQ0FBQztZQUNILElBQUksQ0FBQyxlQUFlLEdBQUcsVUFBVSxDQUFDLGdCQUFnQixDQUFDLGNBQWMsRUFBRSxDQUFDO1lBQ3BFLElBQUksQ0FBQyxzQkFBc0IsR0FBRyxVQUFVLENBQUMsZ0JBQWdCLENBQUMsV0FBVyxDQUFDO1lBRXRFLElBQUksQ0FBQyxhQUFhLEdBQUcsVUFBVSxDQUFDLGdCQUFnQixDQUFDLFdBQVcsQ0FBQztnQkFDM0QsS0FBSSxDQUFDLHNCQUFzQixHQUFHLFVBQVUsQ0FBQyxJQUFJLENBQUMsRUFBRTtvQkFDNUMsVUFBVSxDQUFDLGdCQUFnQixDQUFDLE9BQU8sRUFBRSxDQUFDO1lBQzVDLENBQUMsQ0FBQyxDQUFDO1lBQ0gsSUFBSSxDQUFDLHNCQUFzQixHQUFHLFVBQVUsQ0FBQyxJQUFJLENBQUMsRUFBRTtnQkFDNUMsVUFBVSxDQUFDLGdCQUFnQixDQUFDLE9BQU8sRUFBRSxDQUFDO1FBQzVDLENBQUM7UUFFRCxRQUFRO1lBQ04sVUFBVSxDQUFDLGdCQUFnQixDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQztZQUNwRSxVQUFVLENBQUMsZ0JBQWdCLENBQUMsbUJBQW1CLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDO1FBQ3RFLENBQUM7UUFFRCxpQkFBaUIsWUFBQyxVQUFVO1lBQzFCLE9BQU8sZ0JBQWdCLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUNsRCxDQUFDO1FBRUQsb0JBQW9CLFlBQUMsVUFBVTtZQUM3QixJQUFNLG9CQUFvQixHQUFHLElBQUksR0FBRyxDQUFDLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDO1lBQ2pFLE9BQU8sb0JBQW9CLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUNqRCxDQUFDO1FBRUQsbUJBQW1CLEVBQW5CLFVBQW9CLFVBQWlDO1lBQ25ELE9BQU8sY0FBYyxDQUFDLHFCQUFxQixDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUMvRCxDQUFDO1FBRUQsdUJBQXVCO1lBQ3JCLE9BQU8sSUFBSSxDQUFDLFlBQVksQ0FBQyxNQUFNLElBQUksQ0FBQyxDQUFDO1FBQ3ZDLENBQUM7UUFFRDs7O1dBR0c7UUFDSCxnQkFBZ0I7WUFDZCxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVc7Z0JBQUUsT0FBTztZQUM5QixJQUFNLGFBQWEsR0FBRyxJQUFJLEdBQUcsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUM7WUFDbkQsSUFBTSxhQUFhLEdBQUcsSUFBSSxHQUFHLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO1lBQ2hELGFBQWEsQ0FBQyxPQUFPLENBQUMsVUFBQyxDQUFDLEVBQUUsRUFBRTtnQkFDMUIsb0VBQW9FO2dCQUNwRSxJQUFJLEVBQUUsSUFBSSxpQkFBQSxnQkFBZ0I7b0JBQUUsT0FBTztnQkFDbkMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDO29CQUFFLGFBQWEsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUM7WUFDdkQsQ0FBQyxDQUFDLENBQUM7WUFDSCxJQUFJLENBQUMsV0FBVyxHQUFHLGFBQWEsQ0FBQztRQUNuQyxDQUFDO1FBRUQsbUJBQW1CO1lBQ2pCLElBQUksQ0FBQyxJQUFJLENBQUMsc0JBQXNCO2dCQUFFLE9BQU87WUFDekMsSUFBTSxTQUFTLEdBQUcsSUFBSSxHQUFHLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxHQUFHLENBQUMsVUFBQyxFQUFJO29CQUFILFVBQUU7Z0JBQU0sT0FBQSxFQUFFO1lBQUYsQ0FBRSxDQUFDLENBQUMsQ0FBQztZQUNsRSxJQUFJLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLFVBQUEsRUFBRSxJQUFJLE9BQUEsU0FBUyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsRUFBakIsQ0FBaUIsQ0FBQyxDQUFDO1FBQzVFLENBQUM7UUFFRCx3QkFBd0I7WUFDdEIsb0VBQW9FO1lBQ3BFLHdEQUF3RDtZQUN4RCxJQUFJLENBQUMsSUFBSSxDQUFDLHNCQUFzQjtnQkFBRSxPQUFPO1lBQ3pDLElBQU0sTUFBTSxHQUFHLElBQUksR0FBRyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQztZQUM1QyxJQUFJLENBQUMscUJBQXFCLEdBQUcsSUFBSSxDQUFDLHFCQUFxQjtpQkFDbEQsTUFBTSxDQUFDLFVBQUEsRUFBRSxJQUFJLE9BQUEsTUFBTSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsRUFBZCxDQUFjLENBQUMsQ0FBQztRQUNwQyxDQUFDO1FBRUQsaUJBQWlCO1lBQWpCLGlCQWtDQztZQWpDQyxJQUFJLElBQUksQ0FBQyxzQkFBc0IsRUFBRTtnQkFDL0IsSUFBTSxtQkFBaUIsR0FBRyxJQUFJLEdBQUcsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUM7Z0JBQ3RELElBQU0sVUFBVSxHQUFHLElBQUksQ0FBQyxxQkFBcUI7cUJBQ3hDLE1BQU0sQ0FBQyxVQUFBLEVBQUUsSUFBSSxPQUFBLEtBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxFQUF4QixDQUF3QixDQUFDO3FCQUN0QyxHQUFHLENBQUMsVUFBQSxFQUFFLElBQUksT0FBQSxLQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQWMsRUFBckMsQ0FBcUMsQ0FBQztxQkFDaEQsR0FBRyxDQUFDLFVBQUEsU0FBUztvQkFDWixJQUFNLGdCQUFnQixHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLFNBQVMsQ0FBQyxDQUFDO29CQUN0RCxnQkFBZ0IsQ0FBQyxJQUFJLEdBQUcsU0FBUyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsVUFBQSxHQUFHO3dCQUM1QyxPQUFPLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLEdBQUcsRUFBRTs0QkFDNUIsSUFBSSxFQUFFLEdBQUcsQ0FBQyxJQUFJO2lDQUNULE1BQU0sQ0FBQyxVQUFBLEdBQUcsSUFBSSxPQUFBLG1CQUFpQixDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLEVBQXJDLENBQXFDLENBQUM7eUJBQzFELENBQUMsQ0FBQztvQkFDTCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsVUFBQSxHQUFHLElBQUksT0FBQSxHQUFHLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBZixDQUFlLENBQUMsQ0FBQztvQkFDbEMsT0FBTyxnQkFBZ0IsQ0FBQztnQkFDMUIsQ0FBQyxDQUFDLENBQUM7Z0JBRVAseUVBQXlFO2dCQUN6RSxPQUFPO2dCQUNQLHFFQUFxRTtnQkFDckUsbUVBQW1FO2dCQUNuRSw0QkFBNEI7Z0JBQzVCLElBQU0saUJBQWlCLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJO29CQUMzQyxDQUFDLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLGlCQUFBLGdCQUFnQixDQUFDLENBQUMsQ0FBQztnQkFDdkQsT0FBTztvQkFDTCxJQUFJLEVBQUUsaUJBQWlCLENBQUMsQ0FBQzt3QkFDckIsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLFVBQVU7b0JBQ25FLFVBQVUsWUFBQTtpQkFDWCxDQUFDO2FBQ0g7WUFDRCxPQUFPO2dCQUNMLElBQUksRUFBRSxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsa0JBQWtCO2dCQUM5QyxVQUFVLEVBQUUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxpQkFBQSxnQkFBZ0IsQ0FBQyxDQUFDO2FBQ3JELENBQUM7UUFDSixDQUFDO1FBRUQsaUJBQWlCLFlBQUMsS0FBSztZQUNyQixLQUFLLENBQUMsZUFBZSxFQUFFLENBQUM7WUFDeEIsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLFVBQVU7Z0JBQUUsT0FBTztZQUNuRCxJQUFBLGlCQUErQixFQUE5QixjQUFJLEVBQUUsc0JBQVEsQ0FBaUI7WUFDdEMsSUFBTSxVQUFVLEdBQUcsS0FBSyxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUM7WUFDM0MsSUFBTSxLQUFLLEdBQUcsVUFBVSxDQUFDLEVBQUUsSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLGlCQUFBLGdCQUFnQixDQUFDO1lBRXZFLDJFQUEyRTtZQUMzRSxvRUFBb0U7WUFDcEUsc0VBQXNFO1lBQ3RFLDBFQUEwRTtZQUMxRSxVQUFVO1lBQ1YsSUFBSSxLQUFLLElBQUksaUJBQUEsZ0JBQWdCLElBQUksQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsRUFBRTtnQkFDckUsT0FBTzthQUNSO1lBRUQsSUFBTSxhQUFhLEdBQUcsSUFBSSxHQUFHLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO1lBQ2hELGFBQWEsQ0FBQyxHQUFHLENBQUMsS0FBSyxFQUFFLEVBQUMsVUFBVSxZQUFBLEVBQUUsSUFBSSxNQUFBLEVBQUUsUUFBUSxVQUFBLEVBQUMsQ0FBQyxDQUFDO1lBRXZELDJFQUEyRTtZQUMzRSxtQkFBbUI7WUFDbkIsSUFBSSxDQUFDLENBQUMsT0FBTyxDQUFDLGFBQWEsRUFBRSxJQUFJLENBQUMsV0FBVyxDQUFDO2dCQUFFLE9BQU87WUFFdkQsSUFBSSxDQUFDLFdBQVcsR0FBRyxhQUFhLENBQUM7UUFDbkMsQ0FBQztRQUVELGtCQUFrQjtZQUNoQixJQUFNLE1BQU0sR0FBRyxJQUFJLEdBQUcsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLEdBQUcsQ0FBQyxVQUFBLENBQUMsSUFBSSxPQUFBLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsRUFBVCxDQUFTLENBQUMsQ0FBQyxDQUFDO1lBQ2pFLElBQU0sV0FBVyxHQUFHLElBQUksQ0FBQyxjQUFjO2lCQUNsQyxNQUFNLENBQUMsVUFBQSxFQUFFLElBQUksT0FBQSxNQUFNLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxFQUFkLENBQWMsQ0FBQztpQkFDNUIsR0FBRyxDQUFDLFVBQUEsRUFBRSxJQUFJLE9BQUEsTUFBTSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsRUFBZCxDQUFjLENBQUMsQ0FBQztZQUUvQixJQUFJLENBQUMsZUFBZSxDQUFDLGNBQWMsRUFBRSxXQUFXLEVBQUUsVUFBQSxHQUFHLElBQUksT0FBQSxHQUFHLENBQUMsRUFBRSxFQUFOLENBQU0sQ0FBQyxDQUFDO1FBQ25FLENBQUM7UUFFRCxlQUFlLFlBQUMsS0FBSztZQUNuQixJQUFNLFFBQVEsR0FBRyxLQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxVQUFDLEVBQUk7b0JBQUgsVUFBRTtnQkFBTSxPQUFBLEVBQUU7WUFBRixDQUFFLENBQUMsQ0FBQztZQUNoRCxJQUFJLENBQUMsY0FBYyxHQUFHLFNBQVMsQ0FBQyxJQUFJLENBQUMsY0FBYyxFQUFFLFFBQVEsQ0FBQyxDQUFDO1lBRS9ELDRDQUE0QztZQUM1QyxJQUFJLENBQUMscUJBQXFCLEdBQUcsU0FBUyxDQUNsQyxJQUFJLENBQUMscUJBQXFCLEVBQzFCLFFBQVEsQ0FBQyxDQUFDO1FBQ2hCLENBQUM7UUFFRCxpQkFBaUIsWUFBQyxLQUFLO1lBQ3JCLElBQU0sU0FBUyxHQUFHLEtBQUssQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLEVBQUUsQ0FBQztZQUM3Qyx5RUFBeUU7WUFDekUsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxVQUFBLEVBQUUsSUFBSSxPQUFBLEVBQUUsSUFBSSxTQUFTLEVBQWYsQ0FBZSxDQUFDLENBQUM7UUFDMUUsQ0FBQztRQUVELDBCQUEwQixZQUFDLENBQUM7WUFDMUIsSUFBTSxLQUFLLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsRUFBRSxDQUFDO1lBQ3JDLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUU7Z0JBQ3BCLElBQUksQ0FBQyxxQkFBcUIsR0FBRyxTQUFTLENBQ2xDLElBQUksQ0FBQyxxQkFBcUIsRUFDMUIsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO2FBQ2Q7aUJBQU07Z0JBQ0wsSUFBSSxDQUFDLHFCQUFxQixHQUFHLElBQUksQ0FBQyxxQkFBcUI7cUJBQ2xELE1BQU0sQ0FBQyxVQUFBLEVBQUUsSUFBSSxPQUFBLEVBQUUsSUFBSSxLQUFLLEVBQVgsQ0FBVyxDQUFDLENBQUM7YUFDaEM7UUFDSCxDQUFDO1FBRUQsd0JBQXdCO1lBQ3RCLE9BQU8sSUFBSSxDQUFDLHNCQUFzQjtnQkFDOUIsSUFBSSxDQUFDLGVBQWUsQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUM7UUFDN0QsQ0FBQztRQUVELCtCQUErQjtZQUM3QixPQUFPLElBQUksQ0FBQyxzQkFBc0IsSUFBSSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDO1FBQ2xFLENBQUM7S0FFRixDQUFDLENBQUM7SUFFSDs7T0FFRztJQUNILG1CQUFzQixFQUFPLEVBQUUsS0FBVTtRQUN2QyxJQUFNLEtBQUssR0FBRyxJQUFJLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUMxQixLQUFLLENBQUMsT0FBTyxDQUFDLFVBQUEsSUFBSSxJQUFJLE9BQUEsS0FBSyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBZixDQUFlLENBQUMsQ0FBQztRQUN2QyxPQUFPLEtBQUssQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDM0IsQ0FBQztBQUVELENBQUMsRUF2UlMsZ0JBQWdCLEtBQWhCLGdCQUFnQixRQXVSekIsQ0FBRSw2QkFBNkIiLCJzb3VyY2VzQ29udGVudCI6WyIvKiBDb3B5cmlnaHQgMjAxOCBUaGUgVGVuc29yRmxvdyBBdXRob3JzLiBBbGwgUmlnaHRzIFJlc2VydmVkLlxuXG5MaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UsIFZlcnNpb24gMi4wICh0aGUgJ0xpY2Vuc2UnKTtcbnlvdSBtYXkgbm90IHVzZSB0aGlzIGZpbGUgZXhjZXB0IGluIGNvbXBsaWFuY2Ugd2l0aCB0aGUgTGljZW5zZS5cbllvdSBtYXkgb2J0YWluIGEgY29weSBvZiB0aGUgTGljZW5zZSBhdFxuXG4gICAgaHR0cDovL3d3dy5hcGFjaGUub3JnL2xpY2Vuc2VzL0xJQ0VOU0UtMi4wXG5cblVubGVzcyByZXF1aXJlZCBieSBhcHBsaWNhYmxlIGxhdyBvciBhZ3JlZWQgdG8gaW4gd3JpdGluZywgc29mdHdhcmVcbmRpc3RyaWJ1dGVkIHVuZGVyIHRoZSBMaWNlbnNlIGlzIGRpc3RyaWJ1dGVkIG9uIGFuICdBUyBJUycgQkFTSVMsXG5XSVRIT1VUIFdBUlJBTlRJRVMgT1IgQ09ORElUSU9OUyBPRiBBTlkgS0lORCwgZWl0aGVyIGV4cHJlc3Mgb3IgaW1wbGllZC5cblNlZSB0aGUgTGljZW5zZSBmb3IgdGhlIHNwZWNpZmljIGxhbmd1YWdlIGdvdmVybmluZyBwZXJtaXNzaW9ucyBhbmRcbmxpbWl0YXRpb25zIHVuZGVyIHRoZSBMaWNlbnNlLlxuPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09Ki9cbm5hbWVzcGFjZSB0Zl9kYXRhX3NlbGVjdG9yIHtcblxuUG9seW1lcih7XG4gIGlzOiAndGYtZGF0YS1zZWxlY3Rvci1hZHZhbmNlZCcsXG4gIHByb3BlcnRpZXM6IHtcbiAgICBfYWxsRXhwZXJpbWVudHNGZXRjaGVkOiB7XG4gICAgICB0eXBlOiBCb29sZWFuLFxuICAgICAgdmFsdWU6IGZhbHNlLFxuICAgIH0sXG5cbiAgICBfYWxsRXhwZXJpbWVudHM6IHtcbiAgICAgIHR5cGU6IEFycmF5LFxuICAgICAgdmFsdWU6ICgpOiBBcnJheTx0Zl9iYWNrZW5kLkV4cGVyaW1lbnQ+ID0+IFtdLFxuICAgIH0sXG5cbiAgICAvLyBTdWJzZXQgb2YgYWxsRXhwZXJpbWVudHMgdXNlciBjaG9zZSBhbmQgYWRkZWQuXG4gICAgX2V4cGVyaW1lbnRJZHM6IHtcbiAgICAgIHR5cGU6IEFycmF5LFxuICAgICAgdmFsdWU6IGdldElkSW5pdGlhbGl6ZXIoJ2UnLCB7XG4gICAgICAgIGRlZmF1bHRWYWx1ZTogW10sXG4gICAgICAgIHBvbHltZXJQcm9wZXJ0eTogJ19leHBlcmltZW50SWRzJyxcbiAgICAgIH0pLFxuICAgIH0sXG5cbiAgICBfZXhwZXJpbWVudHM6IHtcbiAgICAgIHR5cGU6IEFycmF5LFxuICAgICAgdmFsdWU6ICgpOiBBcnJheTx0Zl9iYWNrZW5kLkV4cGVyaW1lbnQ+ID0+IFtdLFxuICAgIH0sXG5cbiAgICBfZW5hYmxlZEV4cGVyaW1lbnRJZHM6IHtcbiAgICAgIHR5cGU6IEFycmF5LFxuICAgICAgdmFsdWU6IGdldElkSW5pdGlhbGl6ZXIoJ2VlJywge1xuICAgICAgICBkZWZhdWx0VmFsdWU6IFtdLFxuICAgICAgICBwb2x5bWVyUHJvcGVydHk6ICdfZW5hYmxlZEV4cGVyaW1lbnRJZHMnLFxuICAgICAgfSksXG4gICAgfSxcblxuICAgIF9zZWxlY3Rpb25zOiB7XG4gICAgICB0eXBlOiBPYmplY3QsXG4gICAgICB2YWx1ZTogKCk6IE1hcDx0Zl9iYWNrZW5kLkV4cGVyaW1lbnRJZCwgdGZfZGF0YV9zZWxlY3Rvci5TZWxlY3Rpb24+ID0+IHtcbiAgICAgICAgcmV0dXJuIG5ldyBNYXAoKTtcbiAgICAgIH0sXG4gICAgfSxcblxuICAgIGFjdGl2ZVBsdWdpbnM6IHtcbiAgICAgIHR5cGU6IEFycmF5LFxuICAgICAgdmFsdWU6ICgpOiBzdHJpbmdbXSA9PiBbXSxcbiAgICB9LFxuXG4gICAgLy8gT3V0cHV0IHByb3BlcnR5LiBJdCBoYXMgc3Vic2V0IG9mIF9zZWxlY3Rpb25zLlxuICAgIHNlbGVjdGlvbjoge1xuICAgICAgdHlwZTogT2JqZWN0LFxuICAgICAgbm90aWZ5OiB0cnVlLFxuICAgICAgY29tcHV0ZWQ6ICdfY29tcHV0ZVNlbGVjdGlvbihfZW5hYmxlZEV4cGVyaW1lbnRJZHMuKiwgX3NlbGVjdGlvbnMuKiwgYWN0aXZlUGx1Z2lucy4qKScsXG4gICAgfSxcblxuICAgIF9jYW5Db21wYXJlRXhwZXJpbWVudHM6IHtcbiAgICAgIHR5cGU6IEJvb2xlYW4sXG4gICAgICB2YWx1ZTogZmFsc2VcbiAgICB9LFxuXG4gICAgX3Nob3VsZENvbG9yUnVuczoge1xuICAgICAgdHlwZTogQm9vbGVhbixcbiAgICAgIGNvbXB1dGVkOiAnX2NvbXB1dGVTaG91bGRDb2xvclJ1bnMoX2V4cGVyaW1lbnRzLiopJyxcbiAgICB9LFxuXG4gIH0sXG5cbiAgYmVoYXZpb3JzOiBbXG4gICAgdGZfZGFzaGJvYXJkX2NvbW1vbi5BcnJheVVwZGF0ZUhlbHBlcixcbiAgXSxcblxuICBvYnNlcnZlcnM6IFtcbiAgICAnX3VwZGF0ZUV4cGVyaW1lbnRzKF9hbGxFeHBlcmltZW50cywgX2V4cGVyaW1lbnRJZHMpJyxcbiAgICAnX3BydW5lU2VsZWN0aW9ucyhfZXhwZXJpbWVudElkcy4qKScsXG4gICAgJ19wcnVuZUV4cGVyaW1lbnRJZHMoX2FsbEV4cGVyaW1lbnRzLiopJyxcbiAgICAnX3BydW5lRW5hYmxlZEV4cGVyaW1lbnRzKF9leHBlcmltZW50SWRzLiopJyxcbiAgICAnX3BlcnNpc3RFeHBlcmltZW50SWRzKF9leHBlcmltZW50SWRzLiopJyxcbiAgICAnX3BlcnNpc3RFbmFibGVkRXhwZXJpbWVudHMoX2VuYWJsZWRFeHBlcmltZW50SWRzLiopJyxcbiAgXSxcblxuICBfcGVyc2lzdEV4cGVyaW1lbnRJZHM6IGdldElkT2JzZXJ2ZXIoJ2UnLCB7XG4gICAgZGVmYXVsdFZhbHVlOiBbXSxcbiAgICBwb2x5bWVyUHJvcGVydHk6ICdfZXhwZXJpbWVudElkcycsXG4gIH0pLFxuXG4gIF9wZXJzaXN0RW5hYmxlZEV4cGVyaW1lbnRzOiBnZXRJZE9ic2VydmVyKCdlZScsIHtcbiAgICBkZWZhdWx0VmFsdWU6IFtdLFxuICAgIHBvbHltZXJQcm9wZXJ0eTogJ19lbmFibGVkRXhwZXJpbWVudElkcycsXG4gIH0pLFxuXG4gIGF0dGFjaGVkKCkge1xuICAgIHRoaXMuX3VwZGF0ZUV4cEtleSA9IHRmX2JhY2tlbmQuZXhwZXJpbWVudHNTdG9yZS5hZGRMaXN0ZW5lcigoKSA9PiB7XG4gICAgICB0aGlzLl9hbGxFeHBlcmltZW50cyA9IHRmX2JhY2tlbmQuZXhwZXJpbWVudHNTdG9yZS5nZXRFeHBlcmltZW50cygpO1xuICAgICAgdGhpcy5fYWxsRXhwZXJpbWVudHNGZXRjaGVkID0gdHJ1ZTtcbiAgICB9KTtcbiAgICB0aGlzLl9hbGxFeHBlcmltZW50cyA9IHRmX2JhY2tlbmQuZXhwZXJpbWVudHNTdG9yZS5nZXRFeHBlcmltZW50cygpO1xuICAgIHRoaXMuX2FsbEV4cGVyaW1lbnRzRmV0Y2hlZCA9IHRmX2JhY2tlbmQuZXhwZXJpbWVudHNTdG9yZS5pbml0aWFsaXplZDtcblxuICAgIHRoaXMuX3VwZGF0ZUVudktleSA9IHRmX2JhY2tlbmQuZW52aXJvbm1lbnRTdG9yZS5hZGRMaXN0ZW5lcigoKSA9PiB7XG4gICAgICB0aGlzLl9jYW5Db21wYXJlRXhwZXJpbWVudHMgPSB0Zl9iYWNrZW5kLk1vZGUuREIgPT1cbiAgICAgICAgICB0Zl9iYWNrZW5kLmVudmlyb25tZW50U3RvcmUuZ2V0TW9kZSgpO1xuICAgIH0pO1xuICAgIHRoaXMuX2NhbkNvbXBhcmVFeHBlcmltZW50cyA9IHRmX2JhY2tlbmQuTW9kZS5EQiA9PVxuICAgICAgICB0Zl9iYWNrZW5kLmVudmlyb25tZW50U3RvcmUuZ2V0TW9kZSgpO1xuICB9LFxuXG4gIGRldGFjaGVkKCkge1xuICAgIHRmX2JhY2tlbmQuZXhwZXJpbWVudHNTdG9yZS5yZW1vdmVMaXN0ZW5lckJ5S2V5KHRoaXMuX3VwZGF0ZUV4cEtleSk7XG4gICAgdGZfYmFja2VuZC5lbnZpcm9ubWVudFN0b3JlLnJlbW92ZUxpc3RlbmVyQnlLZXkodGhpcy5fdXBkYXRlRW52S2V5KTtcbiAgfSxcblxuICBfZ2V0UGVyc2lzdGVuY2VJZChleHBlcmltZW50KSB7XG4gICAgcmV0dXJuIHRmX2RhdGFfc2VsZWN0b3IuZW5jb2RlSWQoZXhwZXJpbWVudC5pZCk7XG4gIH0sXG5cbiAgX2lzRXhwZXJpbWVudEVuYWJsZWQoZXhwZXJpbWVudCkge1xuICAgIGNvbnN0IGVuYWJsZWRFeHBlcmltZW50SWRzID0gbmV3IFNldCh0aGlzLl9lbmFibGVkRXhwZXJpbWVudElkcyk7XG4gICAgcmV0dXJuIGVuYWJsZWRFeHBlcmltZW50SWRzLmhhcyhleHBlcmltZW50LmlkKTtcbiAgfSxcblxuICBfZ2V0RXhwZXJpbWVudENvbG9yKGV4cGVyaW1lbnQ6IHRmX2JhY2tlbmQuRXhwZXJpbWVudCk6IHN0cmluZyB7XG4gICAgcmV0dXJuIHRmX2NvbG9yX3NjYWxlLmV4cGVyaW1lbnRzQ29sb3JTY2FsZShleHBlcmltZW50Lm5hbWUpO1xuICB9LFxuXG4gIF9jb21wdXRlU2hvdWxkQ29sb3JSdW5zKCkge1xuICAgIHJldHVybiB0aGlzLl9leHBlcmltZW50cy5sZW5ndGggPD0gMTtcbiAgfSxcblxuICAvKipcbiAgICogUHJ1bmVzIGF3YXkgYW4gZXhwZXJpbWVudCB0aGF0IGhhcyBiZWVuIHJlbW92ZWQgZnJvbSBgX2V4cGVyaW1lbnRzYCBmcm9tXG4gICAqIHRoZSBzZWxlY3Rpb24uXG4gICAqL1xuICBfcHJ1bmVTZWxlY3Rpb25zKCkge1xuICAgIGlmICghdGhpcy5fc2VsZWN0aW9ucykgcmV0dXJuO1xuICAgIGNvbnN0IGV4cGVyaW1lbnRJZHMgPSBuZXcgU2V0KHRoaXMuX2V4cGVyaW1lbnRJZHMpO1xuICAgIGNvbnN0IG5ld1NlbGVjdGlvbnMgPSBuZXcgTWFwKHRoaXMuX3NlbGVjdGlvbnMpO1xuICAgIG5ld1NlbGVjdGlvbnMuZm9yRWFjaCgoXywgaWQpID0+IHtcbiAgICAgIC8vIE5vIGV4cGVyaW1lbnQgc2VsZWN0aW9uIGlzIHN0aWxsIGEgdmFsaWQgc2VsZWN0aW9uLiBEbyBub3QgcHJ1bmUuXG4gICAgICBpZiAoaWQgPT0gTk9fRVhQRVJJTUVOVF9JRCkgcmV0dXJuO1xuICAgICAgaWYgKCFleHBlcmltZW50SWRzLmhhcyhpZCkpIG5ld1NlbGVjdGlvbnMuZGVsZXRlKGlkKTtcbiAgICB9KTtcbiAgICB0aGlzLl9zZWxlY3Rpb25zID0gbmV3U2VsZWN0aW9ucztcbiAgfSxcblxuICBfcHJ1bmVFeHBlcmltZW50SWRzKCkge1xuICAgIGlmICghdGhpcy5fYWxsRXhwZXJpbWVudHNGZXRjaGVkKSByZXR1cm47XG4gICAgY29uc3QgYWxsRXhwSWRzID0gbmV3IFNldCh0aGlzLl9hbGxFeHBlcmltZW50cy5tYXAoKHtpZH0pID0+IGlkKSk7XG4gICAgdGhpcy5fZXhwZXJpbWVudElkcyA9IHRoaXMuX2V4cGVyaW1lbnRJZHMuZmlsdGVyKGlkID0+IGFsbEV4cElkcy5oYXMoaWQpKTtcbiAgfSxcblxuICBfcHJ1bmVFbmFibGVkRXhwZXJpbWVudHMoKSB7XG4gICAgLy8gV2hlbiB0aGUgY29tcG9uZW50IG5ldmVyIGZ1bGx5IGxvYWRlZCB0aGUgbGlzdCBvZiBleHBlcmltZW50cywgaXRcbiAgICAvLyBjYW5ub3QgY29ycmVjdGx5IHBydW5lL2FkanVzdCB0aGUgZW5hYmxlZEV4cGVyaW1lbnRzLlxuICAgIGlmICghdGhpcy5fYWxsRXhwZXJpbWVudHNGZXRjaGVkKSByZXR1cm47XG4gICAgY29uc3QgZXhwSWRzID0gbmV3IFNldCh0aGlzLl9leHBlcmltZW50SWRzKTtcbiAgICB0aGlzLl9lbmFibGVkRXhwZXJpbWVudElkcyA9IHRoaXMuX2VuYWJsZWRFeHBlcmltZW50SWRzXG4gICAgICAgIC5maWx0ZXIoaWQgPT4gZXhwSWRzLmhhcyhpZCkpO1xuICB9LFxuXG4gIF9jb21wdXRlU2VsZWN0aW9uKCkge1xuICAgIGlmICh0aGlzLl9jYW5Db21wYXJlRXhwZXJpbWVudHMpIHtcbiAgICAgIGNvbnN0IGFjdGl2ZVBsdWdpbk5hbWVzID0gbmV3IFNldCh0aGlzLmFjdGl2ZVBsdWdpbnMpO1xuICAgICAgY29uc3Qgc2VsZWN0aW9ucyA9IHRoaXMuX2VuYWJsZWRFeHBlcmltZW50SWRzXG4gICAgICAgICAgLmZpbHRlcihpZCA9PiB0aGlzLl9zZWxlY3Rpb25zLmhhcyhpZCkpXG4gICAgICAgICAgLm1hcChpZCA9PiB0aGlzLl9zZWxlY3Rpb25zLmdldChpZCkgYXMgU2VsZWN0aW9uKVxuICAgICAgICAgIC5tYXAoc2VsZWN0aW9uID0+IHtcbiAgICAgICAgICAgIGNvbnN0IHVwZGF0ZWRTZWxlY3Rpb24gPSBPYmplY3QuYXNzaWduKHt9LCBzZWxlY3Rpb24pO1xuICAgICAgICAgICAgdXBkYXRlZFNlbGVjdGlvbi5ydW5zID0gc2VsZWN0aW9uLnJ1bnMubWFwKHJ1biA9PiB7XG4gICAgICAgICAgICAgIHJldHVybiBPYmplY3QuYXNzaWduKHt9LCBydW4sIHtcbiAgICAgICAgICAgICAgICB0YWdzOiBydW4udGFnc1xuICAgICAgICAgICAgICAgICAgICAuZmlsdGVyKHRhZyA9PiBhY3RpdmVQbHVnaW5OYW1lcy5oYXModGFnLnBsdWdpbk5hbWUpKSxcbiAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9KS5maWx0ZXIocnVuID0+IHJ1bi50YWdzLmxlbmd0aCk7XG4gICAgICAgICAgICByZXR1cm4gdXBkYXRlZFNlbGVjdGlvbjtcbiAgICAgICAgICB9KTtcblxuICAgICAgLy8gU2luZ2xlIHNlbGVjdGlvbjogb25lIGV4cGVyaW1lbnRmdWwgc2VsZWN0aW9uIHdoZXRoZXIgaXQgaXMgZW5hYmxlZCBvclxuICAgICAgLy8gbm90LlxuICAgICAgLy8gTk9URTogYF9zZWxlY3Rpb25zYCBjYW4gY29udGFpbiBub3Qgb25seSBzZWxlY3Rpb25zIGZvciBleHBlcmltZW50XG4gICAgICAvLyBkaWZmaW5nIGJ1dCBhbHNvIG9uZSBmb3Igbm8tZXhwZXJpbWVudCBtb2RlLiBJZiBpdCBjb250YWlucyBvbmUsXG4gICAgICAvLyBcInJlbW92ZVwiIHRoZSBzaXplIGJ5IG9uZS5cbiAgICAgIGNvbnN0IGlzU2luZ2xlU2VsZWN0aW9uID0gdGhpcy5fc2VsZWN0aW9ucy5zaXplID09XG4gICAgICAgICAgMSArIE51bWJlcih0aGlzLl9zZWxlY3Rpb25zLmhhcyhOT19FWFBFUklNRU5UX0lEKSk7XG4gICAgICByZXR1cm4ge1xuICAgICAgICB0eXBlOiBpc1NpbmdsZVNlbGVjdGlvbiA/XG4gICAgICAgICAgICB0Zl9kYXRhX3NlbGVjdG9yLlR5cGUuU0lOR0xFIDogdGZfZGF0YV9zZWxlY3Rvci5UeXBlLkNPTVBBUklTT04sXG4gICAgICAgIHNlbGVjdGlvbnMsXG4gICAgICB9O1xuICAgIH1cbiAgICByZXR1cm4ge1xuICAgICAgdHlwZTogdGZfZGF0YV9zZWxlY3Rvci5UeXBlLldJVEhPVVRfRVhQRVJJTUVOVCxcbiAgICAgIHNlbGVjdGlvbnM6IFt0aGlzLl9zZWxlY3Rpb25zLmdldChOT19FWFBFUklNRU5UX0lEKV0sXG4gICAgfTtcbiAgfSxcblxuICBfc2VsZWN0aW9uQ2hhbmdlZChldmVudCkge1xuICAgIGV2ZW50LnN0b3BQcm9wYWdhdGlvbigpO1xuICAgIGlmICghdGhpcy5pc0F0dGFjaGVkIHx8ICFldmVudC50YXJnZXQuaXNBdHRhY2hlZCkgcmV0dXJuO1xuICAgIGNvbnN0IHtydW5zLCB0YWdSZWdleH0gPSBldmVudC5kZXRhaWw7XG4gICAgY29uc3QgZXhwZXJpbWVudCA9IGV2ZW50LnRhcmdldC5leHBlcmltZW50O1xuICAgIGNvbnN0IGV4cElkID0gZXhwZXJpbWVudC5pZCAhPSBudWxsID8gZXhwZXJpbWVudC5pZCA6IE5PX0VYUEVSSU1FTlRfSUQ7XG5cbiAgICAvLyBDaGVjayBpZiBzZWxjdGlvbiBjaGFuZ2UgZXZlbnQgd2FzIHRyaWdnZXJlZCBmcm9tIGEgcmVtb3ZlZCByb3cuIFJlbW92YWxcbiAgICAvLyB0cmlnZ2VycyBjaGFuZ2UgaW4gcGVyc2lzdGVuY2UgKGNsZWFycyB0aGUgdmFsdWUpIGFuZCB0aGlzIGNhdXNlc1xuICAgIC8vIHByb3BlcnR5IHRvIGNoYW5nZSB3aGljaCBpbiB0dXJuIHRyaWdnZXJzIGFuIGV2ZW50LiBJZiB0aGVyZSBpcyBhbnlcbiAgICAvLyBhc3luY2hyb25pdHkgaW4gcHJvcGFnYXRpbmcgdGhlIGNoYW5nZSBmcm9tIHRoZSByb3csIGJlbG93IGNvbmRpdGlvbiBpc1xuICAgIC8vIHRydXRoeS5cbiAgICBpZiAoZXhwSWQgIT0gTk9fRVhQRVJJTUVOVF9JRCAmJiAhdGhpcy5fZXhwZXJpbWVudElkcy5pbmNsdWRlcyhleHBJZCkpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBjb25zdCBuZXdTZWxlY3Rpb25zID0gbmV3IE1hcCh0aGlzLl9zZWxlY3Rpb25zKTtcbiAgICBuZXdTZWxlY3Rpb25zLnNldChleHBJZCwge2V4cGVyaW1lbnQsIHJ1bnMsIHRhZ1JlZ2V4fSk7XG5cbiAgICAvLyBJZ25vcmUgdGhlIHNlbGVjdGlvbiBjaGFuZ2VkIGV2ZW50IGlmIGl0IG1ha2VzIG5vIHRhbmdpYmxlIGRpZmZlcmVuY2UgdG9cbiAgICAvLyB0aGUgX3NlbGVjdGlvbnMuXG4gICAgaWYgKF8uaXNFcXVhbChuZXdTZWxlY3Rpb25zLCB0aGlzLl9zZWxlY3Rpb25zKSkgcmV0dXJuO1xuXG4gICAgdGhpcy5fc2VsZWN0aW9ucyA9IG5ld1NlbGVjdGlvbnM7XG4gIH0sXG5cbiAgX3VwZGF0ZUV4cGVyaW1lbnRzKCkge1xuICAgIGNvbnN0IGxvb2t1cCA9IG5ldyBNYXAodGhpcy5fYWxsRXhwZXJpbWVudHMubWFwKGUgPT4gW2UuaWQsIGVdKSk7XG4gICAgY29uc3QgZXhwZXJpbWVudHMgPSB0aGlzLl9leHBlcmltZW50SWRzXG4gICAgICAgIC5maWx0ZXIoaWQgPT4gbG9va3VwLmhhcyhpZCkpXG4gICAgICAgIC5tYXAoaWQgPT4gbG9va3VwLmdldChpZCkpO1xuXG4gICAgdGhpcy51cGRhdGVBcnJheVByb3AoJ19leHBlcmltZW50cycsIGV4cGVyaW1lbnRzLCBleHAgPT4gZXhwLmlkKTtcbiAgfSxcblxuICBfYWRkRXhwZXJpbWVudHMoZXZlbnQpIHtcbiAgICBjb25zdCBhZGRlZElkcyA9IGV2ZW50LmRldGFpbC5tYXAoKHtpZH0pID0+IGlkKTtcbiAgICB0aGlzLl9leHBlcmltZW50SWRzID0gdW5pcXVlQWRkKHRoaXMuX2V4cGVyaW1lbnRJZHMsIGFkZGVkSWRzKTtcblxuICAgIC8vIEVuYWJsZSBuZXdseSBhZGRlZCBleHBlcmltZW50cyBieSBkZWZhdWx0XG4gICAgdGhpcy5fZW5hYmxlZEV4cGVyaW1lbnRJZHMgPSB1bmlxdWVBZGQoXG4gICAgICAgIHRoaXMuX2VuYWJsZWRFeHBlcmltZW50SWRzLFxuICAgICAgICBhZGRlZElkcyk7XG4gIH0sXG5cbiAgX3JlbW92ZUV4cGVyaW1lbnQoZXZlbnQpIHtcbiAgICBjb25zdCByZW1vdmVkSWQgPSBldmVudC50YXJnZXQuZXhwZXJpbWVudC5pZDtcbiAgICAvLyBDaGFuZ2luZyBfZXhwZXJpbWVudElkcyB3aWxsIHJlbW92ZSB0aGUgaWQgZnJvbSBfZW5hYmxlZEV4cGVyaW1lbnRJZHMuXG4gICAgdGhpcy5fZXhwZXJpbWVudElkcyA9IHRoaXMuX2V4cGVyaW1lbnRJZHMuZmlsdGVyKGlkID0+IGlkICE9IHJlbW92ZWRJZCk7XG4gIH0sXG5cbiAgX2V4cGVyaW1lbnRDaGVja2JveFRvZ2dsZWQoZSkge1xuICAgIGNvbnN0IG5ld0lkID0gZS50YXJnZXQuZXhwZXJpbWVudC5pZDtcbiAgICBpZiAoZS50YXJnZXQuZW5hYmxlZCkge1xuICAgICAgdGhpcy5fZW5hYmxlZEV4cGVyaW1lbnRJZHMgPSB1bmlxdWVBZGQoXG4gICAgICAgICAgdGhpcy5fZW5hYmxlZEV4cGVyaW1lbnRJZHMsXG4gICAgICAgICAgW25ld0lkXSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMuX2VuYWJsZWRFeHBlcmltZW50SWRzID0gdGhpcy5fZW5hYmxlZEV4cGVyaW1lbnRJZHNcbiAgICAgICAgICAuZmlsdGVyKGlkID0+IGlkICE9IG5ld0lkKTtcbiAgICB9XG4gIH0sXG5cbiAgX2dldEFkZENvbXBhcmlzb25WaXNpYmxlKCkge1xuICAgIHJldHVybiB0aGlzLl9jYW5Db21wYXJlRXhwZXJpbWVudHMgJiZcbiAgICAgICAgdGhpcy5fYWxsRXhwZXJpbWVudHMubGVuZ3RoID4gdGhpcy5fZXhwZXJpbWVudHMubGVuZ3RoO1xuICB9LFxuXG4gIF9nZXRBZGRDb21wYXJpc29uQWx3YXlzRXhwYW5kZWQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2NhbkNvbXBhcmVFeHBlcmltZW50cyAmJiAhdGhpcy5fZXhwZXJpbWVudHMubGVuZ3RoO1xuICB9LFxuXG59KTtcblxuLyoqXG4gKiBBcHBlbmQgaXRlbXMgdG8gYW4gYXJyYXkgd2l0aG91dCBkdXBsaWNhdGUgZW50cmllcy5cbiAqL1xuZnVuY3Rpb24gdW5pcXVlQWRkPFQ+KHRvOiBUW10sIGl0ZW1zOiBUW10pOiBUW10ge1xuICBjb25zdCB0b1NldCA9IG5ldyBTZXQodG8pO1xuICBpdGVtcy5mb3JFYWNoKGl0ZW0gPT4gdG9TZXQuYWRkKGl0ZW0pKTtcbiAgcmV0dXJuIEFycmF5LmZyb20odG9TZXQpO1xufVxuXG59ICAvLyBuYW1lc3BhY2UgdGZfZGF0YV9zZWxlY3RvclxuIl19