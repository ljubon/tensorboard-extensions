/* Copyright 2017 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
var tf_card_heading;
(function (tf_card_heading) {
    /**
     * Formats timestamp for the card header.
     * @param {Date} date
     * @return {string}
     */
    function formatDate(date) {
        if (!date) {
            return '';
        }
        // Turn things like "GMT-0700 (PDT)" into just "PDT".
        return date.toString().replace(/GMT-\d+ \(([^)]+)\)/, '$1');
    }
    tf_card_heading.formatDate = formatDate;
    /**
     * Returns CSS color that will contrast against background.
     * @param {?string} background RGB hex color code, e.g. #eee, #eeeeee.
     * @return {string}
     */
    function pickTextColor(background) {
        var rgb = convertHexToRgb(background);
        if (!rgb) {
            return 'inherit';
        }
        // See: http://www.w3.org/TR/AERT#color-contrast
        var brightness = Math.round((rgb[0] * 299 +
            rgb[1] * 587 +
            rgb[2] * 114) / 1000);
        return brightness > 125 ? 'inherit' : '#eee';
    }
    tf_card_heading.pickTextColor = pickTextColor;
    /**
     * Turns a hex string into an RGB array.
     * @param {?string} color RGB hex color code, e.g. #eee, #eeeeee.
     * @return {Array<number>}
     */
    function convertHexToRgb(color) {
        if (!color) {
            return null;
        }
        var m = color.match(/^#([0-9a-f]{1,2})([0-9a-f]{1,2})([0-9a-f]{1,2})$/);
        if (!m) {
            return null;
        }
        if (color.length == 4) {
            for (var i = 1; i <= 3; i++) {
                m[i] = m[i] + m[i];
            }
        }
        return [parseInt(m[1], 16),
            parseInt(m[2], 16),
            parseInt(m[3], 16)];
    }
})(tf_card_heading || (tf_card_heading = {})); // namespace tf_card_heading
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidXRpbC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbInV0aWwudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7Ozs7Ozs7Z0ZBYWdGO0FBQ2hGLElBQVUsZUFBZSxDQXVEeEI7QUF2REQsV0FBVSxlQUFlO0lBRXpCOzs7O09BSUc7SUFDSCxvQkFBMkIsSUFBSTtRQUM3QixJQUFJLENBQUMsSUFBSSxFQUFFO1lBQ1QsT0FBTyxFQUFFLENBQUM7U0FDWDtRQUNELHFEQUFxRDtRQUNyRCxPQUFPLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQyxPQUFPLENBQUMscUJBQXFCLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDOUQsQ0FBQztJQU5lLDBCQUFVLGFBTXpCLENBQUE7SUFFRDs7OztPQUlHO0lBQ0gsdUJBQThCLFVBQVU7UUFDdEMsSUFBTSxHQUFHLEdBQUcsZUFBZSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQ3hDLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDUixPQUFPLFNBQVMsQ0FBQztTQUNsQjtRQUNELGdEQUFnRDtRQUNoRCxJQUFNLFVBQVUsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUc7WUFDWixHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRztZQUNaLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQztRQUNyRCxPQUFPLFVBQVUsR0FBRyxHQUFHLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO0lBQy9DLENBQUM7SUFWZSw2QkFBYSxnQkFVNUIsQ0FBQTtJQUVEOzs7O09BSUc7SUFDSCx5QkFBeUIsS0FBSztRQUM1QixJQUFJLENBQUMsS0FBSyxFQUFFO1lBQ1YsT0FBTyxJQUFJLENBQUM7U0FDYjtRQUNELElBQUksQ0FBQyxHQUFHLEtBQUssQ0FBQyxLQUFLLENBQUMsa0RBQWtELENBQUMsQ0FBQztRQUN4RSxJQUFJLENBQUMsQ0FBQyxFQUFFO1lBQ04sT0FBTyxJQUFJLENBQUM7U0FDYjtRQUNELElBQUksS0FBSyxDQUFDLE1BQU0sSUFBSSxDQUFDLEVBQUU7WUFDckIsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRTtnQkFDM0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFDcEI7U0FDRjtRQUNELE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQztZQUNsQixRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQztZQUNsQixRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUM7SUFDOUIsQ0FBQztBQUVELENBQUMsRUF2RFMsZUFBZSxLQUFmLGVBQWUsUUF1RHhCLENBQUUsNEJBQTRCIiwic291cmNlc0NvbnRlbnQiOlsiLyogQ29weXJpZ2h0IDIwMTcgVGhlIFRlbnNvckZsb3cgQXV0aG9ycy4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cblxuTGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlLCBWZXJzaW9uIDIuMCAodGhlIFwiTGljZW5zZVwiKTtcbnlvdSBtYXkgbm90IHVzZSB0aGlzIGZpbGUgZXhjZXB0IGluIGNvbXBsaWFuY2Ugd2l0aCB0aGUgTGljZW5zZS5cbllvdSBtYXkgb2J0YWluIGEgY29weSBvZiB0aGUgTGljZW5zZSBhdFxuXG5odHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcblxuVW5sZXNzIHJlcXVpcmVkIGJ5IGFwcGxpY2FibGUgbGF3IG9yIGFncmVlZCB0byBpbiB3cml0aW5nLCBzb2Z0d2FyZVxuZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIExpY2Vuc2UgaXMgZGlzdHJpYnV0ZWQgb24gYW4gXCJBUyBJU1wiIEJBU0lTLFxuV0lUSE9VVCBXQVJSQU5USUVTIE9SIENPTkRJVElPTlMgT0YgQU5ZIEtJTkQsIGVpdGhlciBleHByZXNzIG9yIGltcGxpZWQuXG5TZWUgdGhlIExpY2Vuc2UgZm9yIHRoZSBzcGVjaWZpYyBsYW5ndWFnZSBnb3Zlcm5pbmcgcGVybWlzc2lvbnMgYW5kXG5saW1pdGF0aW9ucyB1bmRlciB0aGUgTGljZW5zZS5cbj09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSovXG5uYW1lc3BhY2UgdGZfY2FyZF9oZWFkaW5nIHtcblxuLyoqXG4gKiBGb3JtYXRzIHRpbWVzdGFtcCBmb3IgdGhlIGNhcmQgaGVhZGVyLlxuICogQHBhcmFtIHtEYXRlfSBkYXRlXG4gKiBAcmV0dXJuIHtzdHJpbmd9XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBmb3JtYXREYXRlKGRhdGUpIHtcbiAgaWYgKCFkYXRlKSB7XG4gICAgcmV0dXJuICcnO1xuICB9XG4gIC8vIFR1cm4gdGhpbmdzIGxpa2UgXCJHTVQtMDcwMCAoUERUKVwiIGludG8ganVzdCBcIlBEVFwiLlxuICByZXR1cm4gZGF0ZS50b1N0cmluZygpLnJlcGxhY2UoL0dNVC1cXGQrIFxcKChbXildKylcXCkvLCAnJDEnKTtcbn1cblxuLyoqXG4gKiBSZXR1cm5zIENTUyBjb2xvciB0aGF0IHdpbGwgY29udHJhc3QgYWdhaW5zdCBiYWNrZ3JvdW5kLlxuICogQHBhcmFtIHs/c3RyaW5nfSBiYWNrZ3JvdW5kIFJHQiBoZXggY29sb3IgY29kZSwgZS5nLiAjZWVlLCAjZWVlZWVlLlxuICogQHJldHVybiB7c3RyaW5nfVxuICovXG5leHBvcnQgZnVuY3Rpb24gcGlja1RleHRDb2xvcihiYWNrZ3JvdW5kKSB7XG4gIGNvbnN0IHJnYiA9IGNvbnZlcnRIZXhUb1JnYihiYWNrZ3JvdW5kKTtcbiAgaWYgKCFyZ2IpIHtcbiAgICByZXR1cm4gJ2luaGVyaXQnO1xuICB9XG4gIC8vIFNlZTogaHR0cDovL3d3dy53My5vcmcvVFIvQUVSVCNjb2xvci1jb250cmFzdFxuICBjb25zdCBicmlnaHRuZXNzID0gTWF0aC5yb3VuZCgocmdiWzBdICogMjk5ICtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJnYlsxXSAqIDU4NyArXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZ2JbMl0gKiAxMTQpIC8gMTAwMCk7XG4gIHJldHVybiBicmlnaHRuZXNzID4gMTI1ID8gJ2luaGVyaXQnIDogJyNlZWUnO1xufVxuXG4vKipcbiAqIFR1cm5zIGEgaGV4IHN0cmluZyBpbnRvIGFuIFJHQiBhcnJheS5cbiAqIEBwYXJhbSB7P3N0cmluZ30gY29sb3IgUkdCIGhleCBjb2xvciBjb2RlLCBlLmcuICNlZWUsICNlZWVlZWUuXG4gKiBAcmV0dXJuIHtBcnJheTxudW1iZXI+fVxuICovXG5mdW5jdGlvbiBjb252ZXJ0SGV4VG9SZ2IoY29sb3IpIHtcbiAgaWYgKCFjb2xvcikge1xuICAgIHJldHVybiBudWxsO1xuICB9XG4gIGxldCBtID0gY29sb3IubWF0Y2goL14jKFswLTlhLWZdezEsMn0pKFswLTlhLWZdezEsMn0pKFswLTlhLWZdezEsMn0pJC8pO1xuICBpZiAoIW0pIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuICBpZiAoY29sb3IubGVuZ3RoID09IDQpIHtcbiAgICBmb3IgKHZhciBpID0gMTsgaSA8PSAzOyBpKyspIHtcbiAgICAgIG1baV0gPSBtW2ldICsgbVtpXTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIFtwYXJzZUludChtWzFdLCAxNiksXG4gICAgICAgICAgcGFyc2VJbnQobVsyXSwgMTYpLFxuICAgICAgICAgIHBhcnNlSW50KG1bM10sIDE2KV07XG59XG5cbn0gIC8vIG5hbWVzcGFjZSB0Zl9jYXJkX2hlYWRpbmdcbiJdfQ==