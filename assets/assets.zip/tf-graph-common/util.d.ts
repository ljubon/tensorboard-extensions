/**
 * @fileoverview Utility functions for the tensorflow graph visualizer.
 */
declare module tf.graph.util {
    function time<T>(msg: string, task: () => T): T;
    /**
     * Creates a tracker that sets the progress property of the
     * provided polymer component. The provided component must have
     * a property called 'progress' that is not read-only. The progress
     * property is an object with a numerical 'value' property and a
     * string 'msg' property.
     */
    function getTracker(polymerComponent: any): {
        setMessage: (msg: any) => void;
        updateProgress: (value: any) => void;
        reportError: (msg: string, err: any) => void;
    };
    /**
     * Creates a tracker for a subtask given the parent tracker, the total
     * progress
     * of the subtask and the subtask message. The parent task should pass a
     * subtracker to its subtasks. The subtask reports its own progress which
     * becomes relative to the main task.
     */
    function getSubtaskTracker(parentTracker: ProgressTracker, impactOnTotalProgress: number, subtaskMsg: string): ProgressTracker;
    /**
     * Runs an expensive task and return the result.
     */
    function runTask<T>(msg: string, incProgressValue: number, task: () => T, tracker: ProgressTracker): T;
    /**
     * Runs an expensive task asynchronously and returns a promise of the result.
     */
    function runAsyncTask<T>(msg: string, incProgressValue: number, task: () => T, tracker: ProgressTracker): Promise<T>;
    /**
     * Asynchronously runs an expensive task that returns a promise. Updates the
     * tracker's progress after the promise resolves. Returns a new promise that
     * resolves after the progress is updated.
     */
    function runAsyncPromiseTask<T>(msg: string, incProgressValue: number, task: () => Promise<T>, tracker: ProgressTracker): Promise<T>;
    /**
     * Returns a query selector with escaped special characters that are not
     * allowed in a query selector.
     */
    function escapeQuerySelector(querySelector: string): string;
    const MEMORY_UNITS: ({
        symbol: string;
        numUnits?: undefined;
    } | {
        symbol: string;
        numUnits: number;
    })[];
    const TIME_UNITS: ({
        symbol: string;
        numUnits?: undefined;
    } | {
        symbol: string;
        numUnits: number;
    })[];
    /**
     * Returns the human readable version of the unit.
     * (e.g. 1.35 GB, 23 MB, 34 ms, 6.53 min etc).
     */
    function convertUnitsToHumanReadable(value: any, units: any, unitIndex: any): any;
    function hasDisplayableNodeStats(stats: NodeStats): boolean;
    /**
     * Given a list of strings, it returns a new list of strings with the longest
     * common prefix removed. If the common prefix is one of the strings in the
     * list, it returns the original strings.
     */
    function removeCommonPrefix(strings: string[]): string[];
    /**
     * Given a queryString, aka ?foo=1&bar=2, return the object representation.
     */
    function getQueryParams(queryString: string): {};
    /**
     * Given a timestamp in microseconds, return a human-friendly string denoting
     * how long ago the timestamp was.
     */
    function computeHumanFriendlyTime(timeInMicroseconds: number): string;
}
