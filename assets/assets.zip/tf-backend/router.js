/* Copyright 2015 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the 'License');
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an 'AS IS' BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
var tf_backend;
(function (tf_backend) {
    ;
    /**
     * Create a router for communicating with the TensorBoard backend. You
     * can pass this to `setRouter` to make it the global router.
     *
     * @param dataDir {string} The base prefix for finding data on server.
     * @param demoMode {boolean} Whether to modify urls for filesystem demo usage.
     */
    function createRouter(dataDir, demoMode) {
        if (dataDir === void 0) { dataDir = 'data'; }
        if (demoMode === void 0) { demoMode = false; }
        if (dataDir[dataDir.length - 1] === '/') {
            dataDir = dataDir.slice(0, dataDir.length - 1);
        }
        var createPath = demoMode ? createDemoPath : createProdPath;
        var ext = demoMode ? '.json' : '';
        return {
            environment: function () { return createPath(dataDir, '/environment', ext); },
            experiments: function () { return createPath(dataDir, '/experiments', ext); },
            isDemoMode: function () { return demoMode; },
            pluginRoute: function (pluginName, route, params, demoCustomExt) {
                if (demoCustomExt === void 0) { demoCustomExt = ext; }
                return createPath(demoMode ? dataDir : dataDir + '/plugin', "/" + pluginName + route, demoCustomExt, params);
            },
            pluginsListing: function () { return createPath(dataDir, '/plugins_listing', ext); },
            runs: function () { return createPath(dataDir, '/runs', ext); },
            runsForExperiment: function (id) {
                return createPath(dataDir, '/experiment_runs', ext, createSearchParam({ experiment: String(id) }));
            },
        };
    }
    tf_backend.createRouter = createRouter;
    ;
    var _router = createRouter();
    /**
     * @return {Router} the global router
     */
    function getRouter() {
        return _router;
    }
    tf_backend.getRouter = getRouter;
    /**
     * Set the global router, to be returned by future calls to `getRouter`.
     * You may wish to invoke this if you are running a demo server with a
     * custom path prefix, or if you have customized the TensorBoard backend
     * to use a different path.
     *
     * @param {Router} router the new global router
     */
    function setRouter(router) {
        if (router == null) {
            throw new Error('Router required, but got: ' + router);
        }
        _router = router;
    }
    tf_backend.setRouter = setRouter;
    function createProdPath(pathPrefix, path, ext, params) {
        var url = new URL(window.location.origin + "/" + pathPrefix + path);
        if (params)
            url.search = params.toString();
        return url.pathname + url.search;
    }
    /**
     * Creates a URL for demo.
     * e.g.,
     * > createDemoPath('a', '/b', '.json', {a: 1})
     * < '/a/b_a_1.json'
     */
    function createDemoPath(pathPrefix, path, ext, params) {
        // First, parse the path in a safe manner by constructing a URL. We don't
        // trust the path supplied by consumer.
        var prefixLessUrl = new URL(window.location.origin + "/" + path);
        var normalizedPath = prefixLessUrl.pathname;
        var encodedQueryParam = params ?
            params.toString().replace(/[&=%]/g, '_') : '';
        // Strip leading slashes.
        normalizedPath = normalizedPath.replace(/^\/+/g, '');
        // Convert slashes to underscores.
        normalizedPath = normalizedPath.replace(/\//g, '_');
        // Add query parameter as path if it is present.
        if (encodedQueryParam)
            normalizedPath += "_" + encodedQueryParam;
        var url = new URL("" + window.location.origin);
        // All demo data are serialized in JSON format.
        url.pathname = pathPrefix + "/" + normalizedPath + ext;
        return url.pathname + url.search;
    }
    function createSearchParam(params) {
        if (params === void 0) { params = {}; }
        var keys = Object.keys(params).sort().filter(function (k) { return params[k]; });
        var searchParams = new URLSearchParams();
        keys.forEach(function (key) {
            var values = params[key];
            var array = Array.isArray(values) ? values : [values];
            array.forEach(function (val) { return searchParams.append(key, val); });
        });
        return searchParams;
    }
    tf_backend.createSearchParam = createSearchParam;
})(tf_backend || (tf_backend = {})); // namespace tf_backend
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGVyLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsicm91dGVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7Ozs7Ozs7Ozs7O2dGQWFnRjtBQUNoRixJQUFVLFVBQVUsQ0EwSG5CO0FBMUhELFdBQVUsVUFBVTtJQVVuQixDQUFDO0lBRUY7Ozs7OztPQU1HO0lBQ0gsc0JBQTZCLE9BQWdCLEVBQUUsUUFBZ0I7UUFBbEMsd0JBQUEsRUFBQSxnQkFBZ0I7UUFBRSx5QkFBQSxFQUFBLGdCQUFnQjtRQUM3RCxJQUFJLE9BQU8sQ0FBQyxPQUFPLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxLQUFLLEdBQUcsRUFBRTtZQUN2QyxPQUFPLEdBQUcsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsT0FBTyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQztTQUNoRDtRQUNELElBQU0sVUFBVSxHQUFHLFFBQVEsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUM7UUFDOUQsSUFBTSxHQUFHLEdBQUcsUUFBUSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztRQUNwQyxPQUFPO1lBQ0wsV0FBVyxFQUFFLGNBQU0sT0FBQSxVQUFVLENBQUMsT0FBTyxFQUFFLGNBQWMsRUFBRSxHQUFHLENBQUMsRUFBeEMsQ0FBd0M7WUFDM0QsV0FBVyxFQUFFLGNBQU0sT0FBQSxVQUFVLENBQUMsT0FBTyxFQUFFLGNBQWMsRUFBRSxHQUFHLENBQUMsRUFBeEMsQ0FBd0M7WUFDM0QsVUFBVSxFQUFFLGNBQU0sT0FBQSxRQUFRLEVBQVIsQ0FBUTtZQUMxQixXQUFXLEVBQUUsVUFBQyxVQUFrQixFQUFFLEtBQWEsRUFDM0MsTUFBd0IsRUFBRSxhQUFtQjtnQkFBbkIsOEJBQUEsRUFBQSxtQkFBbUI7Z0JBRS9DLE9BQU8sVUFBVSxDQUNiLFFBQVEsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxPQUFPLEdBQUcsU0FBUyxFQUN4QyxNQUFJLFVBQVUsR0FBRyxLQUFPLEVBQ3hCLGFBQWEsRUFDYixNQUFNLENBQUMsQ0FBQztZQUNkLENBQUM7WUFDRCxjQUFjLEVBQUUsY0FBTSxPQUFBLFVBQVUsQ0FBQyxPQUFPLEVBQUUsa0JBQWtCLEVBQUUsR0FBRyxDQUFDLEVBQTVDLENBQTRDO1lBQ2xFLElBQUksRUFBRSxjQUFNLE9BQUEsVUFBVSxDQUFDLE9BQU8sRUFBRSxPQUFPLEVBQUUsR0FBRyxDQUFDLEVBQWpDLENBQWlDO1lBQzdDLGlCQUFpQixFQUFFLFVBQUEsRUFBRTtnQkFDbkIsT0FBTyxVQUFVLENBQ2IsT0FBTyxFQUNQLGtCQUFrQixFQUNsQixHQUFHLEVBQ0gsaUJBQWlCLENBQUMsRUFBQyxVQUFVLEVBQUUsTUFBTSxDQUFDLEVBQUUsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ25ELENBQUM7U0FDRixDQUFDO0lBQ0osQ0FBQztJQTdCZSx1QkFBWSxlQTZCM0IsQ0FBQTtJQUFBLENBQUM7SUFFRixJQUFJLE9BQU8sR0FBVyxZQUFZLEVBQUUsQ0FBQztJQUVyQzs7T0FFRztJQUNIO1FBQ0UsT0FBTyxPQUFPLENBQUM7SUFDakIsQ0FBQztJQUZlLG9CQUFTLFlBRXhCLENBQUE7SUFFRDs7Ozs7OztPQU9HO0lBQ0gsbUJBQTBCLE1BQWM7UUFDdEMsSUFBSSxNQUFNLElBQUksSUFBSSxFQUFFO1lBQ2xCLE1BQU0sSUFBSSxLQUFLLENBQUMsNEJBQTRCLEdBQUcsTUFBTSxDQUFDLENBQUM7U0FDeEQ7UUFDRCxPQUFPLEdBQUcsTUFBTSxDQUFDO0lBQ25CLENBQUM7SUFMZSxvQkFBUyxZQUt4QixDQUFBO0lBRUQsd0JBQXdCLFVBQWtCLEVBQUUsSUFBWSxFQUNwRCxHQUFXLEVBQUUsTUFBd0I7UUFFdkMsSUFBTSxHQUFHLEdBQUcsSUFBSSxHQUFHLENBQUksTUFBTSxDQUFDLFFBQVEsQ0FBQyxNQUFNLFNBQUksVUFBVSxHQUFHLElBQU0sQ0FBQyxDQUFDO1FBQ3RFLElBQUksTUFBTTtZQUFFLEdBQUcsQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQzNDLE9BQU8sR0FBRyxDQUFDLFFBQVEsR0FBRyxHQUFHLENBQUMsTUFBTSxDQUFDO0lBQ25DLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILHdCQUF3QixVQUFrQixFQUFFLElBQVksRUFDcEQsR0FBVyxFQUFFLE1BQXdCO1FBRXZDLHlFQUF5RTtRQUN6RSx1Q0FBdUM7UUFDdkMsSUFBTSxhQUFhLEdBQUcsSUFBSSxHQUFHLENBQUksTUFBTSxDQUFDLFFBQVEsQ0FBQyxNQUFNLFNBQUksSUFBTSxDQUFDLENBQUM7UUFDOUQsSUFBQSx1Q0FBd0IsQ0FBa0I7UUFDL0MsSUFBTSxpQkFBaUIsR0FBRyxNQUFNLENBQUMsQ0FBQztZQUM5QixNQUFNLENBQUMsUUFBUSxFQUFFLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO1FBRWxELHlCQUF5QjtRQUN6QixjQUFjLEdBQUcsY0FBYyxDQUFDLE9BQU8sQ0FBQyxPQUFPLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFDckQsa0NBQWtDO1FBQ2xDLGNBQWMsR0FBRyxjQUFjLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSxHQUFHLENBQUMsQ0FBQztRQUNwRCxnREFBZ0Q7UUFDaEQsSUFBSSxpQkFBaUI7WUFBRSxjQUFjLElBQUksTUFBSSxpQkFBbUIsQ0FBQztRQUNqRSxJQUFNLEdBQUcsR0FBRyxJQUFJLEdBQUcsQ0FBQyxLQUFHLE1BQU0sQ0FBQyxRQUFRLENBQUMsTUFBUSxDQUFDLENBQUM7UUFFakQsK0NBQStDO1FBQy9DLEdBQUcsQ0FBQyxRQUFRLEdBQU0sVUFBVSxTQUFJLGNBQWMsR0FBRyxHQUFLLENBQUM7UUFDdkQsT0FBTyxHQUFHLENBQUMsUUFBUSxHQUFHLEdBQUcsQ0FBQyxNQUFNLENBQUM7SUFDbkMsQ0FBQztJQUVELDJCQUFrQyxNQUF3QjtRQUF4Qix1QkFBQSxFQUFBLFdBQXdCO1FBQ3hELElBQU0sSUFBSSxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUMsTUFBTSxDQUFDLFVBQUEsQ0FBQyxJQUFJLE9BQUEsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFULENBQVMsQ0FBQyxDQUFDO1FBQy9ELElBQU0sWUFBWSxHQUFHLElBQUksZUFBZSxFQUFFLENBQUM7UUFDM0MsSUFBSSxDQUFDLE9BQU8sQ0FBQyxVQUFBLEdBQUc7WUFDZCxJQUFNLE1BQU0sR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDM0IsSUFBTSxLQUFLLEdBQUcsS0FBSyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQ3hELEtBQUssQ0FBQyxPQUFPLENBQUMsVUFBQSxHQUFHLElBQUksT0FBQSxZQUFZLENBQUMsTUFBTSxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUMsRUFBN0IsQ0FBNkIsQ0FBQyxDQUFDO1FBQ3RELENBQUMsQ0FBQyxDQUFDO1FBQ0gsT0FBTyxZQUFZLENBQUM7SUFDdEIsQ0FBQztJQVRlLDRCQUFpQixvQkFTaEMsQ0FBQTtBQUVELENBQUMsRUExSFMsVUFBVSxLQUFWLFVBQVUsUUEwSG5CLENBQUUsdUJBQXVCIiwic291cmNlc0NvbnRlbnQiOlsiLyogQ29weXJpZ2h0IDIwMTUgVGhlIFRlbnNvckZsb3cgQXV0aG9ycy4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cblxuTGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlLCBWZXJzaW9uIDIuMCAodGhlICdMaWNlbnNlJyk7XG55b3UgbWF5IG5vdCB1c2UgdGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlIHdpdGggdGhlIExpY2Vuc2UuXG5Zb3UgbWF5IG9idGFpbiBhIGNvcHkgb2YgdGhlIExpY2Vuc2UgYXRcblxuICAgIGh0dHA6Ly93d3cuYXBhY2hlLm9yZy9saWNlbnNlcy9MSUNFTlNFLTIuMFxuXG5Vbmxlc3MgcmVxdWlyZWQgYnkgYXBwbGljYWJsZSBsYXcgb3IgYWdyZWVkIHRvIGluIHdyaXRpbmcsIHNvZnR3YXJlXG5kaXN0cmlidXRlZCB1bmRlciB0aGUgTGljZW5zZSBpcyBkaXN0cmlidXRlZCBvbiBhbiAnQVMgSVMnIEJBU0lTLFxuV0lUSE9VVCBXQVJSQU5USUVTIE9SIENPTkRJVElPTlMgT0YgQU5ZIEtJTkQsIGVpdGhlciBleHByZXNzIG9yIGltcGxpZWQuXG5TZWUgdGhlIExpY2Vuc2UgZm9yIHRoZSBzcGVjaWZpYyBsYW5ndWFnZSBnb3Zlcm5pbmcgcGVybWlzc2lvbnMgYW5kXG5saW1pdGF0aW9ucyB1bmRlciB0aGUgTGljZW5zZS5cbj09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSovXG5uYW1lc3BhY2UgdGZfYmFja2VuZCB7XG5cbmV4cG9ydCBpbnRlcmZhY2UgUm91dGVyIHtcbiAgZW52aXJvbm1lbnQ6ICgpID0+IHN0cmluZztcbiAgZXhwZXJpbWVudHM6ICgpID0+IHN0cmluZztcbiAgaXNEZW1vTW9kZTogKCkgPT4gYm9vbGVhbjtcbiAgcGx1Z2luUm91dGU6IChwbHVnaW5OYW1lOiBzdHJpbmcsIHJvdXRlOiBzdHJpbmcpID0+IHN0cmluZztcbiAgcGx1Z2luc0xpc3Rpbmc6ICgpID0+IHN0cmluZztcbiAgcnVuczogKCkgPT4gc3RyaW5nO1xuICBydW5zRm9yRXhwZXJpbWVudDogKGlkOiB0Zl9iYWNrZW5kLkV4cGVyaW1lbnRJZCkgPT4gc3RyaW5nO1xufTtcblxuLyoqXG4gKiBDcmVhdGUgYSByb3V0ZXIgZm9yIGNvbW11bmljYXRpbmcgd2l0aCB0aGUgVGVuc29yQm9hcmQgYmFja2VuZC4gWW91XG4gKiBjYW4gcGFzcyB0aGlzIHRvIGBzZXRSb3V0ZXJgIHRvIG1ha2UgaXQgdGhlIGdsb2JhbCByb3V0ZXIuXG4gKlxuICogQHBhcmFtIGRhdGFEaXIge3N0cmluZ30gVGhlIGJhc2UgcHJlZml4IGZvciBmaW5kaW5nIGRhdGEgb24gc2VydmVyLlxuICogQHBhcmFtIGRlbW9Nb2RlIHtib29sZWFufSBXaGV0aGVyIHRvIG1vZGlmeSB1cmxzIGZvciBmaWxlc3lzdGVtIGRlbW8gdXNhZ2UuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVSb3V0ZXIoZGF0YURpciA9ICdkYXRhJywgZGVtb01vZGUgPSBmYWxzZSk6IFJvdXRlciB7XG4gIGlmIChkYXRhRGlyW2RhdGFEaXIubGVuZ3RoIC0gMV0gPT09ICcvJykge1xuICAgIGRhdGFEaXIgPSBkYXRhRGlyLnNsaWNlKDAsIGRhdGFEaXIubGVuZ3RoIC0gMSk7XG4gIH1cbiAgY29uc3QgY3JlYXRlUGF0aCA9IGRlbW9Nb2RlID8gY3JlYXRlRGVtb1BhdGggOiBjcmVhdGVQcm9kUGF0aDtcbiAgY29uc3QgZXh0ID0gZGVtb01vZGUgPyAnLmpzb24nIDogJyc7XG4gIHJldHVybiB7XG4gICAgZW52aXJvbm1lbnQ6ICgpID0+IGNyZWF0ZVBhdGgoZGF0YURpciwgJy9lbnZpcm9ubWVudCcsIGV4dCksXG4gICAgZXhwZXJpbWVudHM6ICgpID0+IGNyZWF0ZVBhdGgoZGF0YURpciwgJy9leHBlcmltZW50cycsIGV4dCksXG4gICAgaXNEZW1vTW9kZTogKCkgPT4gZGVtb01vZGUsXG4gICAgcGx1Z2luUm91dGU6IChwbHVnaW5OYW1lOiBzdHJpbmcsIHJvdXRlOiBzdHJpbmcsXG4gICAgICAgIHBhcmFtcz86IFVSTFNlYXJjaFBhcmFtcywgZGVtb0N1c3RvbUV4dCA9IGV4dCk6IHN0cmluZyA9PiB7XG5cbiAgICAgIHJldHVybiBjcmVhdGVQYXRoKFxuICAgICAgICAgIGRlbW9Nb2RlID8gZGF0YURpciA6IGRhdGFEaXIgKyAnL3BsdWdpbicsXG4gICAgICAgICAgYC8ke3BsdWdpbk5hbWV9JHtyb3V0ZX1gLFxuICAgICAgICAgIGRlbW9DdXN0b21FeHQsXG4gICAgICAgICAgcGFyYW1zKTtcbiAgICB9LFxuICAgIHBsdWdpbnNMaXN0aW5nOiAoKSA9PiBjcmVhdGVQYXRoKGRhdGFEaXIsICcvcGx1Z2luc19saXN0aW5nJywgZXh0KSxcbiAgICBydW5zOiAoKSA9PiBjcmVhdGVQYXRoKGRhdGFEaXIsICcvcnVucycsIGV4dCksXG4gICAgcnVuc0ZvckV4cGVyaW1lbnQ6IGlkID0+IHtcbiAgICAgIHJldHVybiBjcmVhdGVQYXRoKFxuICAgICAgICAgIGRhdGFEaXIsXG4gICAgICAgICAgJy9leHBlcmltZW50X3J1bnMnLFxuICAgICAgICAgIGV4dCxcbiAgICAgICAgICBjcmVhdGVTZWFyY2hQYXJhbSh7ZXhwZXJpbWVudDogU3RyaW5nKGlkKX0pKTtcbiAgICB9LFxuICB9O1xufTtcblxubGV0IF9yb3V0ZXI6IFJvdXRlciA9IGNyZWF0ZVJvdXRlcigpO1xuXG4vKipcbiAqIEByZXR1cm4ge1JvdXRlcn0gdGhlIGdsb2JhbCByb3V0ZXJcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdldFJvdXRlcigpOiBSb3V0ZXIge1xuICByZXR1cm4gX3JvdXRlcjtcbn1cblxuLyoqXG4gKiBTZXQgdGhlIGdsb2JhbCByb3V0ZXIsIHRvIGJlIHJldHVybmVkIGJ5IGZ1dHVyZSBjYWxscyB0byBgZ2V0Um91dGVyYC5cbiAqIFlvdSBtYXkgd2lzaCB0byBpbnZva2UgdGhpcyBpZiB5b3UgYXJlIHJ1bm5pbmcgYSBkZW1vIHNlcnZlciB3aXRoIGFcbiAqIGN1c3RvbSBwYXRoIHByZWZpeCwgb3IgaWYgeW91IGhhdmUgY3VzdG9taXplZCB0aGUgVGVuc29yQm9hcmQgYmFja2VuZFxuICogdG8gdXNlIGEgZGlmZmVyZW50IHBhdGguXG4gKlxuICogQHBhcmFtIHtSb3V0ZXJ9IHJvdXRlciB0aGUgbmV3IGdsb2JhbCByb3V0ZXJcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHNldFJvdXRlcihyb3V0ZXI6IFJvdXRlcik6IHZvaWQge1xuICBpZiAocm91dGVyID09IG51bGwpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ1JvdXRlciByZXF1aXJlZCwgYnV0IGdvdDogJyArIHJvdXRlcik7XG4gIH1cbiAgX3JvdXRlciA9IHJvdXRlcjtcbn1cblxuZnVuY3Rpb24gY3JlYXRlUHJvZFBhdGgocGF0aFByZWZpeDogc3RyaW5nLCBwYXRoOiBzdHJpbmcsXG4gICAgZXh0OiBzdHJpbmcsIHBhcmFtcz86IFVSTFNlYXJjaFBhcmFtcyk6IHN0cmluZyB7XG5cbiAgY29uc3QgdXJsID0gbmV3IFVSTChgJHt3aW5kb3cubG9jYXRpb24ub3JpZ2lufS8ke3BhdGhQcmVmaXh9JHtwYXRofWApO1xuICBpZiAocGFyYW1zKSB1cmwuc2VhcmNoID0gcGFyYW1zLnRvU3RyaW5nKCk7XG4gIHJldHVybiB1cmwucGF0aG5hbWUgKyB1cmwuc2VhcmNoO1xufVxuXG4vKipcbiAqIENyZWF0ZXMgYSBVUkwgZm9yIGRlbW8uXG4gKiBlLmcuLFxuICogPiBjcmVhdGVEZW1vUGF0aCgnYScsICcvYicsICcuanNvbicsIHthOiAxfSlcbiAqIDwgJy9hL2JfYV8xLmpzb24nXG4gKi9cbmZ1bmN0aW9uIGNyZWF0ZURlbW9QYXRoKHBhdGhQcmVmaXg6IHN0cmluZywgcGF0aDogc3RyaW5nLFxuICAgIGV4dDogc3RyaW5nLCBwYXJhbXM/OiBVUkxTZWFyY2hQYXJhbXMpOiBzdHJpbmcge1xuXG4gIC8vIEZpcnN0LCBwYXJzZSB0aGUgcGF0aCBpbiBhIHNhZmUgbWFubmVyIGJ5IGNvbnN0cnVjdGluZyBhIFVSTC4gV2UgZG9uJ3RcbiAgLy8gdHJ1c3QgdGhlIHBhdGggc3VwcGxpZWQgYnkgY29uc3VtZXIuXG4gIGNvbnN0IHByZWZpeExlc3NVcmwgPSBuZXcgVVJMKGAke3dpbmRvdy5sb2NhdGlvbi5vcmlnaW59LyR7cGF0aH1gKTtcbiAgbGV0IHtwYXRobmFtZTogbm9ybWFsaXplZFBhdGh9ID0gcHJlZml4TGVzc1VybDtcbiAgY29uc3QgZW5jb2RlZFF1ZXJ5UGFyYW0gPSBwYXJhbXMgP1xuICAgICAgcGFyYW1zLnRvU3RyaW5nKCkucmVwbGFjZSgvWyY9JV0vZywgJ18nKSA6ICcnO1xuXG4gIC8vIFN0cmlwIGxlYWRpbmcgc2xhc2hlcy5cbiAgbm9ybWFsaXplZFBhdGggPSBub3JtYWxpemVkUGF0aC5yZXBsYWNlKC9eXFwvKy9nLCAnJyk7XG4gIC8vIENvbnZlcnQgc2xhc2hlcyB0byB1bmRlcnNjb3Jlcy5cbiAgbm9ybWFsaXplZFBhdGggPSBub3JtYWxpemVkUGF0aC5yZXBsYWNlKC9cXC8vZywgJ18nKTtcbiAgLy8gQWRkIHF1ZXJ5IHBhcmFtZXRlciBhcyBwYXRoIGlmIGl0IGlzIHByZXNlbnQuXG4gIGlmIChlbmNvZGVkUXVlcnlQYXJhbSkgbm9ybWFsaXplZFBhdGggKz0gYF8ke2VuY29kZWRRdWVyeVBhcmFtfWA7XG4gIGNvbnN0IHVybCA9IG5ldyBVUkwoYCR7d2luZG93LmxvY2F0aW9uLm9yaWdpbn1gKTtcblxuICAvLyBBbGwgZGVtbyBkYXRhIGFyZSBzZXJpYWxpemVkIGluIEpTT04gZm9ybWF0LlxuICB1cmwucGF0aG5hbWUgPSBgJHtwYXRoUHJlZml4fS8ke25vcm1hbGl6ZWRQYXRofSR7ZXh0fWA7XG4gIHJldHVybiB1cmwucGF0aG5hbWUgKyB1cmwuc2VhcmNoO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlU2VhcmNoUGFyYW0ocGFyYW1zOiBRdWVyeVBhcmFtcyA9IHt9KTogVVJMU2VhcmNoUGFyYW1zIHtcbiAgY29uc3Qga2V5cyA9IE9iamVjdC5rZXlzKHBhcmFtcykuc29ydCgpLmZpbHRlcihrID0+IHBhcmFtc1trXSk7XG4gIGNvbnN0IHNlYXJjaFBhcmFtcyA9IG5ldyBVUkxTZWFyY2hQYXJhbXMoKTtcbiAga2V5cy5mb3JFYWNoKGtleSA9PiB7XG4gICAgY29uc3QgdmFsdWVzID0gcGFyYW1zW2tleV07XG4gICAgY29uc3QgYXJyYXkgPSBBcnJheS5pc0FycmF5KHZhbHVlcykgPyB2YWx1ZXMgOiBbdmFsdWVzXTtcbiAgICBhcnJheS5mb3JFYWNoKHZhbCA9PiBzZWFyY2hQYXJhbXMuYXBwZW5kKGtleSwgdmFsKSk7XG4gIH0pO1xuICByZXR1cm4gc2VhcmNoUGFyYW1zO1xufVxuXG59ICAvLyBuYW1lc3BhY2UgdGZfYmFja2VuZFxuIl19