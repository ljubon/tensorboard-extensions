declare namespace vz_chart_helper {
    enum TooltipPosition {
        /**
         * Positions the tooltip to the bottom of the chart in most case. Positions
         * the tooltip above the chart if there isn't sufficient space below.
         */
        AUTO = "auto",
        /**
         * Position the tooltip on the bottom of the chart.
         */
        BOTTOM = "bottom",
        /**
         * Positions the tooltip to the right of the chart.
         */
        RIGHT = "right"
    }
    interface VzChartTooltip extends Element {
        content(): Element;
        hide(): void;
        updateAndPosition(anchorNode: Element, newDom: Array<any>): void;
    }
}
