declare namespace tf_backend {
    type ExperimentId = number;
    type RunId = number | null;
    type TagId = number;
    type Experiment = {
        id: ExperimentId;
        name: string;
        startTime: number;
    };
    type Run = {
        id: RunId;
        name: string;
        startTime: number;
        tags: Tag[];
    };
    type Tag = {
        id: TagId;
        name: string;
        displayName: string;
        pluginName: string;
    };
}
