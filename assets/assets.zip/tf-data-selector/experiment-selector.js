/* Copyright 2018 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the 'License');
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an 'AS IS' BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
var tf_data_selector;
(function (tf_data_selector) {
    Polymer({
        is: 'experiment-selector',
        properties: {
            excludeExperiments: {
                type: Array,
                value: function () { return []; },
            },
            alwaysExpanded: {
                type: Boolean,
                value: false,
            },
            _expanded: {
                type: Boolean,
                value: false,
            },
            _allExperiments: {
                type: Array,
                value: function () { return []; },
            },
            _experimentColoring: {
                type: Object,
                value: {
                    getColor: function (item) { return tf_color_scale.experimentsColorScale(item.title); },
                },
            },
            _selectedExpOptions: {
                type: Array,
                value: function () { return []; },
            },
        },
        observers: [
            '_changeExpanded(alwaysExpanded)',
        ],
        attached: function () {
            var _this = this;
            this._updateExpKey = tf_backend.experimentsStore
                .addListener(function () { return _this._updateExps(); });
            this._updateExps();
        },
        detached: function () {
            tf_backend.experimentsStore.removeListenerByKey(this._updateExpKey);
        },
        _updateExps: function () {
            this.set('_allExperiments', tf_backend.experimentsStore.getExperiments());
        },
        _getExperimentOptions: function (_) {
            var exclude = new Set(this.excludeExperiments.map(function (_a) {
                var id = _a.id;
                return id;
            }));
            return this._allExperiments
                .filter(function (_a) {
                var id = _a.id;
                return !exclude.has(id);
            })
                .map(function (exp) { return ({
                id: exp.id,
                title: exp.name,
                subtitle: exp.startedTime,
            }); });
        },
        _changeExpanded: function () {
            if (this.alwaysExpanded && !this._expanded) {
                this._expanded = true;
            }
        },
        _toggle: function () {
            this._expanded = !this._expanded;
        },
        _addExperiments: function () {
            var lookupMap = new Map(this._allExperiments.map(function (e) { return [e.id, e]; }));
            var newItems = this._selectedExpOptions
                .map(function (_a) {
                var id = _a.id;
                return lookupMap.get(id);
            });
            this._expanded = false;
            this.fire('experiment-added', newItems);
        },
        _getAddLabel: function (_) {
            switch (this._selectedExpOptions.length) {
                case 0:
                case 1:
                    return 'Add';
                default:
                    return 'Add All';
            }
        },
    });
})(tf_data_selector || (tf_data_selector = {})); // namespace tf_data_selector
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZXhwZXJpbWVudC1zZWxlY3Rvci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImV4cGVyaW1lbnQtc2VsZWN0b3IudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7Ozs7Ozs7Z0ZBYWdGO0FBQ2hGLElBQVUsZ0JBQWdCLENBaUd6QjtBQWpHRCxXQUFVLGdCQUFnQjtJQUUxQixPQUFPLENBQUM7UUFDTixFQUFFLEVBQUUscUJBQXFCO1FBQ3pCLFVBQVUsRUFBRTtZQUNWLGtCQUFrQixFQUFFO2dCQUNsQixJQUFJLEVBQUUsS0FBSztnQkFDWCxLQUFLLEVBQUUsY0FBb0MsT0FBQSxFQUFFLEVBQUYsQ0FBRTthQUM5QztZQUVELGNBQWMsRUFBRTtnQkFDZCxJQUFJLEVBQUUsT0FBTztnQkFDYixLQUFLLEVBQUUsS0FBSzthQUNiO1lBRUQsU0FBUyxFQUFFO2dCQUNULElBQUksRUFBRSxPQUFPO2dCQUNiLEtBQUssRUFBRSxLQUFLO2FBQ2I7WUFFRCxlQUFlLEVBQUU7Z0JBQ2YsSUFBSSxFQUFFLEtBQUs7Z0JBQ1gsS0FBSyxFQUFFLGNBQW9DLE9BQUEsRUFBRSxFQUFGLENBQUU7YUFDOUM7WUFFRCxtQkFBbUIsRUFBRTtnQkFDbkIsSUFBSSxFQUFFLE1BQU07Z0JBQ1osS0FBSyxFQUFFO29CQUNMLFFBQVEsRUFBRSxVQUFDLElBQUksSUFBSyxPQUFBLGNBQWMsQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQWhELENBQWdEO2lCQUNyRTthQUNGO1lBRUQsbUJBQW1CLEVBQUU7Z0JBQ25CLElBQUksRUFBRSxLQUFLO2dCQUNYLEtBQUssRUFBRSxjQUE2RCxPQUFBLEVBQUUsRUFBRixDQUFFO2FBQ3ZFO1NBQ0Y7UUFFRCxTQUFTLEVBQUU7WUFDVCxpQ0FBaUM7U0FDbEM7UUFFRCxRQUFRO1lBQVIsaUJBSUM7WUFIQyxJQUFJLENBQUMsYUFBYSxHQUFHLFVBQVUsQ0FBQyxnQkFBZ0I7aUJBQzNDLFdBQVcsQ0FBQyxjQUFNLE9BQUEsS0FBSSxDQUFDLFdBQVcsRUFBRSxFQUFsQixDQUFrQixDQUFDLENBQUM7WUFDM0MsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ3JCLENBQUM7UUFFRCxRQUFRO1lBQ04sVUFBVSxDQUFDLGdCQUFnQixDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQztRQUN0RSxDQUFDO1FBRUQsV0FBVztZQUNULElBQUksQ0FBQyxHQUFHLENBQUMsaUJBQWlCLEVBQUUsVUFBVSxDQUFDLGdCQUFnQixDQUFDLGNBQWMsRUFBRSxDQUFDLENBQUM7UUFDNUUsQ0FBQztRQUVELHFCQUFxQixZQUFDLENBQUM7WUFDckIsSUFBTSxPQUFPLEdBQUcsSUFBSSxHQUFHLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLEdBQUcsQ0FBQyxVQUFDLEVBQUk7b0JBQUgsVUFBRTtnQkFBTSxPQUFBLEVBQUU7WUFBRixDQUFFLENBQUMsQ0FBQyxDQUFDO1lBQ25FLE9BQU8sSUFBSSxDQUFDLGVBQWU7aUJBQ3RCLE1BQU0sQ0FBQyxVQUFDLEVBQUk7b0JBQUgsVUFBRTtnQkFBTSxPQUFBLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUM7WUFBaEIsQ0FBZ0IsQ0FBQztpQkFDbEMsR0FBRyxDQUFDLFVBQUEsR0FBRyxJQUFJLE9BQUEsQ0FBQztnQkFDWCxFQUFFLEVBQUUsR0FBRyxDQUFDLEVBQUU7Z0JBQ1YsS0FBSyxFQUFFLEdBQUcsQ0FBQyxJQUFJO2dCQUNmLFFBQVEsRUFBRSxHQUFHLENBQUMsV0FBVzthQUMxQixDQUFDLEVBSlUsQ0FJVixDQUFDLENBQUM7UUFDVixDQUFDO1FBRUQsZUFBZTtZQUNiLElBQUksSUFBSSxDQUFDLGNBQWMsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUU7Z0JBQzFDLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDO2FBQ3ZCO1FBQ0gsQ0FBQztRQUVELE9BQU87WUFDTCxJQUFJLENBQUMsU0FBUyxHQUFHLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQztRQUNuQyxDQUFDO1FBRUQsZUFBZTtZQUNiLElBQU0sU0FBUyxHQUFHLElBQUksR0FBRyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsR0FBRyxDQUFDLFVBQUEsQ0FBQyxJQUFJLE9BQUEsQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxFQUFULENBQVMsQ0FBQyxDQUFDLENBQUM7WUFDcEUsSUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLG1CQUFtQjtpQkFDcEMsR0FBRyxDQUFDLFVBQUMsRUFBSTtvQkFBSCxVQUFFO2dCQUFNLE9BQUEsU0FBUyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUM7WUFBakIsQ0FBaUIsQ0FBQyxDQUFDO1lBQ3RDLElBQUksQ0FBQyxTQUFTLEdBQUcsS0FBSyxDQUFDO1lBQ3ZCLElBQUksQ0FBQyxJQUFJLENBQUMsa0JBQWtCLEVBQUUsUUFBUSxDQUFDLENBQUM7UUFDMUMsQ0FBQztRQUVELFlBQVksWUFBQyxDQUFDO1lBQ1osUUFBUSxJQUFJLENBQUMsbUJBQW1CLENBQUMsTUFBTSxFQUFFO2dCQUN2QyxLQUFLLENBQUMsQ0FBQztnQkFDUCxLQUFLLENBQUM7b0JBQ0osT0FBTyxLQUFLLENBQUM7Z0JBQ2Y7b0JBQ0UsT0FBTyxTQUFTLENBQUE7YUFDbkI7UUFDSCxDQUFDO0tBRUYsQ0FBQyxDQUFDO0FBRUgsQ0FBQyxFQWpHUyxnQkFBZ0IsS0FBaEIsZ0JBQWdCLFFBaUd6QixDQUFFLDZCQUE2QiIsInNvdXJjZXNDb250ZW50IjpbIi8qIENvcHlyaWdodCAyMDE4IFRoZSBUZW5zb3JGbG93IEF1dGhvcnMuIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG5cbkxpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSAnTGljZW5zZScpO1xueW91IG1heSBub3QgdXNlIHRoaXMgZmlsZSBleGNlcHQgaW4gY29tcGxpYW5jZSB3aXRoIHRoZSBMaWNlbnNlLlxuWW91IG1heSBvYnRhaW4gYSBjb3B5IG9mIHRoZSBMaWNlbnNlIGF0XG5cbiAgICBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcblxuVW5sZXNzIHJlcXVpcmVkIGJ5IGFwcGxpY2FibGUgbGF3IG9yIGFncmVlZCB0byBpbiB3cml0aW5nLCBzb2Z0d2FyZVxuZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIExpY2Vuc2UgaXMgZGlzdHJpYnV0ZWQgb24gYW4gJ0FTIElTJyBCQVNJUyxcbldJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWSBLSU5ELCBlaXRoZXIgZXhwcmVzcyBvciBpbXBsaWVkLlxuU2VlIHRoZSBMaWNlbnNlIGZvciB0aGUgc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nIHBlcm1pc3Npb25zIGFuZFxubGltaXRhdGlvbnMgdW5kZXIgdGhlIExpY2Vuc2UuXG49PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0qL1xubmFtZXNwYWNlIHRmX2RhdGFfc2VsZWN0b3Ige1xuXG5Qb2x5bWVyKHtcbiAgaXM6ICdleHBlcmltZW50LXNlbGVjdG9yJyxcbiAgcHJvcGVydGllczoge1xuICAgIGV4Y2x1ZGVFeHBlcmltZW50czoge1xuICAgICAgdHlwZTogQXJyYXksXG4gICAgICB2YWx1ZTogKCk6IEFycmF5PHRmX2JhY2tlbmQuRXhwZXJpbWVudD4gPT4gW10sXG4gICAgfSxcblxuICAgIGFsd2F5c0V4cGFuZGVkOiB7XG4gICAgICB0eXBlOiBCb29sZWFuLFxuICAgICAgdmFsdWU6IGZhbHNlLFxuICAgIH0sXG5cbiAgICBfZXhwYW5kZWQ6IHtcbiAgICAgIHR5cGU6IEJvb2xlYW4sXG4gICAgICB2YWx1ZTogZmFsc2UsXG4gICAgfSxcblxuICAgIF9hbGxFeHBlcmltZW50czoge1xuICAgICAgdHlwZTogQXJyYXksXG4gICAgICB2YWx1ZTogKCk6IEFycmF5PHRmX2JhY2tlbmQuRXhwZXJpbWVudD4gPT4gW10sXG4gICAgfSxcblxuICAgIF9leHBlcmltZW50Q29sb3Jpbmc6IHtcbiAgICAgIHR5cGU6IE9iamVjdCxcbiAgICAgIHZhbHVlOiB7XG4gICAgICAgIGdldENvbG9yOiAoaXRlbSkgPT4gdGZfY29sb3Jfc2NhbGUuZXhwZXJpbWVudHNDb2xvclNjYWxlKGl0ZW0udGl0bGUpLFxuICAgICAgfSxcbiAgICB9LFxuXG4gICAgX3NlbGVjdGVkRXhwT3B0aW9uczoge1xuICAgICAgdHlwZTogQXJyYXksXG4gICAgICB2YWx1ZTogKCk6IEFycmF5PHRmX2Rhc2hib2FyZF9jb21tb24uRmlsdGVyYWJsZUNoZWNrYm94TGlzdEl0ZW0+ID0+IFtdLFxuICAgIH0sXG4gIH0sXG5cbiAgb2JzZXJ2ZXJzOiBbXG4gICAgJ19jaGFuZ2VFeHBhbmRlZChhbHdheXNFeHBhbmRlZCknLFxuICBdLFxuXG4gIGF0dGFjaGVkKCkge1xuICAgIHRoaXMuX3VwZGF0ZUV4cEtleSA9IHRmX2JhY2tlbmQuZXhwZXJpbWVudHNTdG9yZVxuICAgICAgICAuYWRkTGlzdGVuZXIoKCkgPT4gdGhpcy5fdXBkYXRlRXhwcygpKTtcbiAgICB0aGlzLl91cGRhdGVFeHBzKCk7XG4gIH0sXG5cbiAgZGV0YWNoZWQoKSB7XG4gICAgdGZfYmFja2VuZC5leHBlcmltZW50c1N0b3JlLnJlbW92ZUxpc3RlbmVyQnlLZXkodGhpcy5fdXBkYXRlRXhwS2V5KTtcbiAgfSxcblxuICBfdXBkYXRlRXhwcygpIHtcbiAgICB0aGlzLnNldCgnX2FsbEV4cGVyaW1lbnRzJywgdGZfYmFja2VuZC5leHBlcmltZW50c1N0b3JlLmdldEV4cGVyaW1lbnRzKCkpO1xuICB9LFxuXG4gIF9nZXRFeHBlcmltZW50T3B0aW9ucyhfKSB7XG4gICAgY29uc3QgZXhjbHVkZSA9IG5ldyBTZXQodGhpcy5leGNsdWRlRXhwZXJpbWVudHMubWFwKCh7aWR9KSA9PiBpZCkpO1xuICAgIHJldHVybiB0aGlzLl9hbGxFeHBlcmltZW50c1xuICAgICAgICAuZmlsdGVyKCh7aWR9KSA9PiAhZXhjbHVkZS5oYXMoaWQpKVxuICAgICAgICAubWFwKGV4cCA9PiAoe1xuICAgICAgICAgIGlkOiBleHAuaWQsXG4gICAgICAgICAgdGl0bGU6IGV4cC5uYW1lLFxuICAgICAgICAgIHN1YnRpdGxlOiBleHAuc3RhcnRlZFRpbWUsXG4gICAgICAgIH0pKTtcbiAgfSxcblxuICBfY2hhbmdlRXhwYW5kZWQoKSB7XG4gICAgaWYgKHRoaXMuYWx3YXlzRXhwYW5kZWQgJiYgIXRoaXMuX2V4cGFuZGVkKSB7XG4gICAgICB0aGlzLl9leHBhbmRlZCA9IHRydWU7XG4gICAgfVxuICB9LFxuXG4gIF90b2dnbGUoKSB7XG4gICAgdGhpcy5fZXhwYW5kZWQgPSAhdGhpcy5fZXhwYW5kZWQ7XG4gIH0sXG5cbiAgX2FkZEV4cGVyaW1lbnRzKCkge1xuICAgIGNvbnN0IGxvb2t1cE1hcCA9IG5ldyBNYXAodGhpcy5fYWxsRXhwZXJpbWVudHMubWFwKGUgPT4gW2UuaWQsIGVdKSk7XG4gICAgY29uc3QgbmV3SXRlbXMgPSB0aGlzLl9zZWxlY3RlZEV4cE9wdGlvbnNcbiAgICAgICAgLm1hcCgoe2lkfSkgPT4gbG9va3VwTWFwLmdldChpZCkpO1xuICAgIHRoaXMuX2V4cGFuZGVkID0gZmFsc2U7XG4gICAgdGhpcy5maXJlKCdleHBlcmltZW50LWFkZGVkJywgbmV3SXRlbXMpO1xuICB9LFxuXG4gIF9nZXRBZGRMYWJlbChfKSB7XG4gICAgc3dpdGNoICh0aGlzLl9zZWxlY3RlZEV4cE9wdGlvbnMubGVuZ3RoKSB7XG4gICAgICBjYXNlIDA6XG4gICAgICBjYXNlIDE6XG4gICAgICAgIHJldHVybiAnQWRkJztcbiAgICAgIGRlZmF1bHQ6XG4gICAgICAgIHJldHVybiAnQWRkIEFsbCdcbiAgICB9XG4gIH0sXG5cbn0pO1xuXG59ICAvLyBuYW1lc3BhY2UgdGZfZGF0YV9zZWxlY3RvclxuIl19