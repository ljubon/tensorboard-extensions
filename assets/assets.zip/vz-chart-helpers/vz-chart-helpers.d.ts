declare namespace vz_chart_helpers {
    interface Datum {
        wall_time: Date;
        step: number;
    }
    interface Scalar {
        scalar: number;
        smoothed: number;
    }
    type ScalarDatum = Datum & Scalar;
    type DataFn = (run: string, tag: string) => Promise<Array<Datum>>;
    interface LineChartSymbol {
        character: string;
        method: (() => Plottable.SymbolFactories.SymbolFactory);
    }
    /**
     * A list of symbols that line charts can cycle through per data series.
     */
    const SYMBOLS_LIST: LineChartSymbol[];
    /** X axis choices for TensorBoard charts. */
    enum XType {
        /** Linear scale using the "step" property of the datum. */
        STEP = "step",
        /** Temporal scale using the "wall_time" property of the datum. */
        RELATIVE = "relative",
        /**
         * Temporal scale using the "relative" property of the datum if it is present
         * or calculating from "wall_time" if it isn't.
         */
        WALL_TIME = "wall_time"
    }
    type SymbolFn = (series: string) => Plottable.SymbolFactory;
    let Y_TOOLTIP_FORMATTER_PRECISION: number;
    let STEP_FORMATTER_PRECISION: number;
    let Y_AXIS_FORMATTER_PRECISION: number;
    let TOOLTIP_Y_PIXEL_OFFSET: number;
    let TOOLTIP_CIRCLE_SIZE: number;
    let NAN_SYMBOL_SIZE: number;
    interface Point {
        x: number;
        y: number;
        datum: ScalarDatum;
        dataset: Plottable.Dataset;
    }
    interface TooltipColumnState {
        smoothingEnabled: boolean;
    }
    interface TooltipColumn {
        title: string;
        static: boolean;
        evaluate: ((p: Point, status?: TooltipColumnState) => string);
    }
    function multiscaleFormatter(digits: number): ((v: number) => string);
    function computeDomain(values: number[], ignoreOutliers: boolean): number[];
    function accessorize(key: string): Plottable.IAccessor<number>;
    interface XComponents {
        scale: Plottable.Scales.Linear | Plottable.Scales.Time;
        axis: Plottable.Axes.Numeric | Plottable.Axes.Time;
        accessor: Plottable.IAccessor<number | Date>;
    }
    let stepFormatter: (d: any) => string;
    function stepX(): XComponents;
    let timeFormatter: Plottable.Formatters.Formatter;
    function wallX(): XComponents;
    let relativeAccessor: (d: any, index: number, dataset: Plottable.Dataset) => any;
    let relativeFormatter: (n: number) => string;
    function relativeX(): XComponents;
    function getXComponents(xType: string): XComponents;
}
