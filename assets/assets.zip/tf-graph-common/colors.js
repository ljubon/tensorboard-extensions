/* Copyright 2015 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the 'License');
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an 'AS IS' BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
var tf;
(function (tf) {
    /**
     * Mapping from color palette name to color palette, which contains
     * exact colors for multiple states of a single color palette.
     */
    tf.COLORS = [
        {
            'name': 'Google Blue',
            'color': '#4184f3',
            'active': '#3a53c5',
            'disabled': '#cad8fc'
        },
        {
            'name': 'Google Red',
            'color': '#db4437',
            'active': '#8f2a0c',
            'disabled': '#e8c6c1'
        },
        {
            'name': 'Google Yellow',
            'color': '#f4b400',
            'active': '#db9200',
            'disabled': '#f7e8b0'
        },
        {
            'name': 'Google Green',
            'color': '#0f9d58',
            'active': '#488046',
            'disabled': '#c2e1cc'
        },
        {
            'name': 'Purple',
            'color': '#aa46bb',
            'active': '#5c1398',
            'disabled': '#d7bce6'
        },
        {
            'name': 'Teal',
            'color': '#00abc0',
            'active': '#47828e',
            'disabled': '#c2eaf2'
        },
        {
            'name': 'Deep Orange',
            'color': '#ff6f42',
            'active': '#ca4a06',
            'disabled': '#f2cbba'
        },
        {
            'name': 'Lime',
            'color': '#9d9c23',
            'active': '#7f771d',
            'disabled': '#f1f4c2'
        },
        {
            'name': 'Indigo',
            'color': '#5b6abf',
            'active': '#3e47a9',
            'disabled': '#c5c8e8'
        },
        {
            'name': 'Pink',
            'color': '#ef6191',
            'active': '#ca1c60',
            'disabled': '#e9b9ce'
        },
        {
            'name': 'Deep Teal',
            'color': '#00786a',
            'active': '#2b4f43',
            'disabled': '#bededa'
        },
        {
            'name': 'Deep Pink',
            'color': '#c1175a',
            'active': '#75084f',
            'disabled': '#de8cae'
        },
        {
            'name': 'Gray',
            'color': '#9E9E9E',
            'active': '#424242',
            'disabled': 'F5F5F5' // 100
        }
    ].reduce(function (m, c) {
        m[c.name] = c;
        return m;
    }, {});
    /**
     * Mapping from op category to color palette name
     * e.g.,  OP_GROUP_COLORS['state_ops'] = 'Google Blue';
     */
    tf.OP_GROUP_COLORS = [
        {
            color: 'Google Red',
            groups: [
                'gen_legacy_ops', 'legacy_ops', 'legacy_flogs_input',
                'legacy_image_input', 'legacy_input_example_input',
                'legacy_sequence_input', 'legacy_seti_input_input'
            ]
        },
        { color: 'Deep Orange', groups: ['constant_ops'] },
        { color: 'Indigo', groups: ['state_ops'] },
        { color: 'Purple', groups: ['nn_ops', 'nn'] },
        { color: 'Google Green', groups: ['math_ops'] },
        { color: 'Lime', groups: ['array_ops'] },
        { color: 'Teal', groups: ['control_flow_ops', 'data_flow_ops'] },
        { color: 'Pink', groups: ['summary_ops'] },
        { color: 'Deep Pink', groups: ['io_ops'] }
    ].reduce(function (m, c) {
        c.groups.forEach(function (group) { m[group] = c.color; });
        return m;
    }, {});
})(tf || (tf = {}));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29sb3JzLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiY29sb3JzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7Ozs7Ozs7Ozs7O2dGQWFnRjtBQUVoRixJQUFPLEVBQUUsQ0FrSFI7QUFsSEQsV0FBTyxFQUFFO0lBQ1A7OztPQUdHO0lBQ1EsU0FBTSxHQUFHO1FBQ2xCO1lBQ0UsTUFBTSxFQUFFLGFBQWE7WUFDckIsT0FBTyxFQUFFLFNBQVM7WUFDbEIsUUFBUSxFQUFFLFNBQVM7WUFDbkIsVUFBVSxFQUFFLFNBQVM7U0FDdEI7UUFDRDtZQUNFLE1BQU0sRUFBRSxZQUFZO1lBQ3BCLE9BQU8sRUFBRSxTQUFTO1lBQ2xCLFFBQVEsRUFBRSxTQUFTO1lBQ25CLFVBQVUsRUFBRSxTQUFTO1NBQ3RCO1FBQ0Q7WUFDRSxNQUFNLEVBQUUsZUFBZTtZQUN2QixPQUFPLEVBQUUsU0FBUztZQUNsQixRQUFRLEVBQUUsU0FBUztZQUNuQixVQUFVLEVBQUUsU0FBUztTQUN0QjtRQUNEO1lBQ0UsTUFBTSxFQUFFLGNBQWM7WUFDdEIsT0FBTyxFQUFFLFNBQVM7WUFDbEIsUUFBUSxFQUFFLFNBQVM7WUFDbkIsVUFBVSxFQUFFLFNBQVM7U0FDdEI7UUFDRDtZQUNFLE1BQU0sRUFBRSxRQUFRO1lBQ2hCLE9BQU8sRUFBRSxTQUFTO1lBQ2xCLFFBQVEsRUFBRSxTQUFTO1lBQ25CLFVBQVUsRUFBRSxTQUFTO1NBQ3RCO1FBQ0Q7WUFDRSxNQUFNLEVBQUUsTUFBTTtZQUNkLE9BQU8sRUFBRSxTQUFTO1lBQ2xCLFFBQVEsRUFBRSxTQUFTO1lBQ25CLFVBQVUsRUFBRSxTQUFTO1NBQ3RCO1FBQ0Q7WUFDRSxNQUFNLEVBQUUsYUFBYTtZQUNyQixPQUFPLEVBQUUsU0FBUztZQUNsQixRQUFRLEVBQUUsU0FBUztZQUNuQixVQUFVLEVBQUUsU0FBUztTQUN0QjtRQUNEO1lBQ0UsTUFBTSxFQUFFLE1BQU07WUFDZCxPQUFPLEVBQUUsU0FBUztZQUNsQixRQUFRLEVBQUUsU0FBUztZQUNuQixVQUFVLEVBQUUsU0FBUztTQUN0QjtRQUNEO1lBQ0UsTUFBTSxFQUFFLFFBQVE7WUFDaEIsT0FBTyxFQUFFLFNBQVM7WUFDbEIsUUFBUSxFQUFFLFNBQVM7WUFDbkIsVUFBVSxFQUFFLFNBQVM7U0FDdEI7UUFDRDtZQUNFLE1BQU0sRUFBRSxNQUFNO1lBQ2QsT0FBTyxFQUFFLFNBQVM7WUFDbEIsUUFBUSxFQUFFLFNBQVM7WUFDbkIsVUFBVSxFQUFFLFNBQVM7U0FDdEI7UUFDRDtZQUNFLE1BQU0sRUFBRSxXQUFXO1lBQ25CLE9BQU8sRUFBRSxTQUFTO1lBQ2xCLFFBQVEsRUFBRSxTQUFTO1lBQ25CLFVBQVUsRUFBRSxTQUFTO1NBQ3RCO1FBQ0Q7WUFDRSxNQUFNLEVBQUUsV0FBVztZQUNuQixPQUFPLEVBQUUsU0FBUztZQUNsQixRQUFRLEVBQUUsU0FBUztZQUNuQixVQUFVLEVBQUUsU0FBUztTQUN0QjtRQUNEO1lBQ0UsTUFBTSxFQUFFLE1BQU07WUFDZCxPQUFPLEVBQUUsU0FBUztZQUNsQixRQUFRLEVBQUUsU0FBUztZQUNuQixVQUFVLEVBQUUsUUFBUSxDQUFFLE1BQU07U0FDN0I7S0FDRixDQUFDLE1BQU0sQ0FBQyxVQUFDLENBQUMsRUFBRSxDQUFDO1FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDZCxPQUFPLENBQUMsQ0FBQztJQUNYLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztJQUVQOzs7T0FHRztJQUNRLGtCQUFlLEdBQUc7UUFDM0I7WUFDRSxLQUFLLEVBQUUsWUFBWTtZQUNuQixNQUFNLEVBQUU7Z0JBQ04sZ0JBQWdCLEVBQUUsWUFBWSxFQUFFLG9CQUFvQjtnQkFDcEQsb0JBQW9CLEVBQUUsNEJBQTRCO2dCQUNsRCx1QkFBdUIsRUFBRSx5QkFBeUI7YUFDbkQ7U0FDRjtRQUNELEVBQUMsS0FBSyxFQUFFLGFBQWEsRUFBRSxNQUFNLEVBQUUsQ0FBQyxjQUFjLENBQUMsRUFBQztRQUNoRCxFQUFDLEtBQUssRUFBRSxRQUFRLEVBQUUsTUFBTSxFQUFFLENBQUMsV0FBVyxDQUFDLEVBQUM7UUFDeEMsRUFBQyxLQUFLLEVBQUUsUUFBUSxFQUFFLE1BQU0sRUFBRSxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsRUFBQztRQUMzQyxFQUFDLEtBQUssRUFBRSxjQUFjLEVBQUUsTUFBTSxFQUFFLENBQUMsVUFBVSxDQUFDLEVBQUM7UUFDN0MsRUFBQyxLQUFLLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRSxDQUFDLFdBQVcsQ0FBQyxFQUFDO1FBQ3RDLEVBQUMsS0FBSyxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsQ0FBQyxrQkFBa0IsRUFBRSxlQUFlLENBQUMsRUFBQztRQUM5RCxFQUFDLEtBQUssRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLENBQUMsYUFBYSxDQUFDLEVBQUM7UUFDeEMsRUFBQyxLQUFLLEVBQUUsV0FBVyxFQUFFLE1BQU0sRUFBRSxDQUFDLFFBQVEsQ0FBQyxFQUFDO0tBQ3pDLENBQUMsTUFBTSxDQUFDLFVBQUMsQ0FBQyxFQUFFLENBQUM7UUFDWixDQUFDLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxVQUFTLEtBQUssSUFBSSxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQzFELE9BQU8sQ0FBQyxDQUFDO0lBQ1gsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQ1QsQ0FBQyxFQWxITSxFQUFFLEtBQUYsRUFBRSxRQWtIUiIsInNvdXJjZXNDb250ZW50IjpbIi8qIENvcHlyaWdodCAyMDE1IFRoZSBUZW5zb3JGbG93IEF1dGhvcnMuIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG5cbkxpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSAnTGljZW5zZScpO1xueW91IG1heSBub3QgdXNlIHRoaXMgZmlsZSBleGNlcHQgaW4gY29tcGxpYW5jZSB3aXRoIHRoZSBMaWNlbnNlLlxuWW91IG1heSBvYnRhaW4gYSBjb3B5IG9mIHRoZSBMaWNlbnNlIGF0XG5cbiAgICBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcblxuVW5sZXNzIHJlcXVpcmVkIGJ5IGFwcGxpY2FibGUgbGF3IG9yIGFncmVlZCB0byBpbiB3cml0aW5nLCBzb2Z0d2FyZVxuZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIExpY2Vuc2UgaXMgZGlzdHJpYnV0ZWQgb24gYW4gJ0FTIElTJyBCQVNJUyxcbldJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWSBLSU5ELCBlaXRoZXIgZXhwcmVzcyBvciBpbXBsaWVkLlxuU2VlIHRoZSBMaWNlbnNlIGZvciB0aGUgc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nIHBlcm1pc3Npb25zIGFuZFxubGltaXRhdGlvbnMgdW5kZXIgdGhlIExpY2Vuc2UuXG49PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0qL1xuXG5tb2R1bGUgdGYge1xuICAvKipcbiAgICogTWFwcGluZyBmcm9tIGNvbG9yIHBhbGV0dGUgbmFtZSB0byBjb2xvciBwYWxldHRlLCB3aGljaCBjb250YWluc1xuICAgKiBleGFjdCBjb2xvcnMgZm9yIG11bHRpcGxlIHN0YXRlcyBvZiBhIHNpbmdsZSBjb2xvciBwYWxldHRlLlxuICAgKi9cbiAgZXhwb3J0IGxldCBDT0xPUlMgPSBbXG4gICAge1xuICAgICAgJ25hbWUnOiAnR29vZ2xlIEJsdWUnLFxuICAgICAgJ2NvbG9yJzogJyM0MTg0ZjMnLFxuICAgICAgJ2FjdGl2ZSc6ICcjM2E1M2M1JyxcbiAgICAgICdkaXNhYmxlZCc6ICcjY2FkOGZjJ1xuICAgIH0sXG4gICAge1xuICAgICAgJ25hbWUnOiAnR29vZ2xlIFJlZCcsXG4gICAgICAnY29sb3InOiAnI2RiNDQzNycsXG4gICAgICAnYWN0aXZlJzogJyM4ZjJhMGMnLFxuICAgICAgJ2Rpc2FibGVkJzogJyNlOGM2YzEnXG4gICAgfSxcbiAgICB7XG4gICAgICAnbmFtZSc6ICdHb29nbGUgWWVsbG93JyxcbiAgICAgICdjb2xvcic6ICcjZjRiNDAwJyxcbiAgICAgICdhY3RpdmUnOiAnI2RiOTIwMCcsXG4gICAgICAnZGlzYWJsZWQnOiAnI2Y3ZThiMCdcbiAgICB9LFxuICAgIHtcbiAgICAgICduYW1lJzogJ0dvb2dsZSBHcmVlbicsXG4gICAgICAnY29sb3InOiAnIzBmOWQ1OCcsXG4gICAgICAnYWN0aXZlJzogJyM0ODgwNDYnLFxuICAgICAgJ2Rpc2FibGVkJzogJyNjMmUxY2MnXG4gICAgfSxcbiAgICB7XG4gICAgICAnbmFtZSc6ICdQdXJwbGUnLFxuICAgICAgJ2NvbG9yJzogJyNhYTQ2YmInLFxuICAgICAgJ2FjdGl2ZSc6ICcjNWMxMzk4JyxcbiAgICAgICdkaXNhYmxlZCc6ICcjZDdiY2U2J1xuICAgIH0sXG4gICAge1xuICAgICAgJ25hbWUnOiAnVGVhbCcsXG4gICAgICAnY29sb3InOiAnIzAwYWJjMCcsXG4gICAgICAnYWN0aXZlJzogJyM0NzgyOGUnLFxuICAgICAgJ2Rpc2FibGVkJzogJyNjMmVhZjInXG4gICAgfSxcbiAgICB7XG4gICAgICAnbmFtZSc6ICdEZWVwIE9yYW5nZScsXG4gICAgICAnY29sb3InOiAnI2ZmNmY0MicsXG4gICAgICAnYWN0aXZlJzogJyNjYTRhMDYnLFxuICAgICAgJ2Rpc2FibGVkJzogJyNmMmNiYmEnXG4gICAgfSxcbiAgICB7XG4gICAgICAnbmFtZSc6ICdMaW1lJyxcbiAgICAgICdjb2xvcic6ICcjOWQ5YzIzJyxcbiAgICAgICdhY3RpdmUnOiAnIzdmNzcxZCcsXG4gICAgICAnZGlzYWJsZWQnOiAnI2YxZjRjMidcbiAgICB9LFxuICAgIHtcbiAgICAgICduYW1lJzogJ0luZGlnbycsXG4gICAgICAnY29sb3InOiAnIzViNmFiZicsXG4gICAgICAnYWN0aXZlJzogJyMzZTQ3YTknLFxuICAgICAgJ2Rpc2FibGVkJzogJyNjNWM4ZTgnXG4gICAgfSxcbiAgICB7XG4gICAgICAnbmFtZSc6ICdQaW5rJyxcbiAgICAgICdjb2xvcic6ICcjZWY2MTkxJyxcbiAgICAgICdhY3RpdmUnOiAnI2NhMWM2MCcsXG4gICAgICAnZGlzYWJsZWQnOiAnI2U5YjljZSdcbiAgICB9LFxuICAgIHtcbiAgICAgICduYW1lJzogJ0RlZXAgVGVhbCcsXG4gICAgICAnY29sb3InOiAnIzAwNzg2YScsXG4gICAgICAnYWN0aXZlJzogJyMyYjRmNDMnLFxuICAgICAgJ2Rpc2FibGVkJzogJyNiZWRlZGEnXG4gICAgfSxcbiAgICB7XG4gICAgICAnbmFtZSc6ICdEZWVwIFBpbmsnLFxuICAgICAgJ2NvbG9yJzogJyNjMTE3NWEnLFxuICAgICAgJ2FjdGl2ZSc6ICcjNzUwODRmJyxcbiAgICAgICdkaXNhYmxlZCc6ICcjZGU4Y2FlJ1xuICAgIH0sXG4gICAge1xuICAgICAgJ25hbWUnOiAnR3JheScsXG4gICAgICAnY29sb3InOiAnIzlFOUU5RScsICAgLy8gNTAwXG4gICAgICAnYWN0aXZlJzogJyM0MjQyNDInLCAgLy8gODAwXG4gICAgICAnZGlzYWJsZWQnOiAnRjVGNUY1JyAgLy8gMTAwXG4gICAgfVxuICBdLnJlZHVjZSgobSwgYykgPT4ge1xuICAgIG1bYy5uYW1lXSA9IGM7XG4gICAgcmV0dXJuIG07XG4gIH0sIHt9KTtcblxuICAvKipcbiAgICogTWFwcGluZyBmcm9tIG9wIGNhdGVnb3J5IHRvIGNvbG9yIHBhbGV0dGUgbmFtZVxuICAgKiBlLmcuLCAgT1BfR1JPVVBfQ09MT1JTWydzdGF0ZV9vcHMnXSA9ICdHb29nbGUgQmx1ZSc7XG4gICAqL1xuICBleHBvcnQgbGV0IE9QX0dST1VQX0NPTE9SUyA9IFtcbiAgICB7XG4gICAgICBjb2xvcjogJ0dvb2dsZSBSZWQnLFxuICAgICAgZ3JvdXBzOiBbXG4gICAgICAgICdnZW5fbGVnYWN5X29wcycsICdsZWdhY3lfb3BzJywgJ2xlZ2FjeV9mbG9nc19pbnB1dCcsXG4gICAgICAgICdsZWdhY3lfaW1hZ2VfaW5wdXQnLCAnbGVnYWN5X2lucHV0X2V4YW1wbGVfaW5wdXQnLFxuICAgICAgICAnbGVnYWN5X3NlcXVlbmNlX2lucHV0JywgJ2xlZ2FjeV9zZXRpX2lucHV0X2lucHV0J1xuICAgICAgXVxuICAgIH0sXG4gICAge2NvbG9yOiAnRGVlcCBPcmFuZ2UnLCBncm91cHM6IFsnY29uc3RhbnRfb3BzJ119LFxuICAgIHtjb2xvcjogJ0luZGlnbycsIGdyb3VwczogWydzdGF0ZV9vcHMnXX0sXG4gICAge2NvbG9yOiAnUHVycGxlJywgZ3JvdXBzOiBbJ25uX29wcycsICdubiddfSxcbiAgICB7Y29sb3I6ICdHb29nbGUgR3JlZW4nLCBncm91cHM6IFsnbWF0aF9vcHMnXX0sXG4gICAge2NvbG9yOiAnTGltZScsIGdyb3VwczogWydhcnJheV9vcHMnXX0sXG4gICAge2NvbG9yOiAnVGVhbCcsIGdyb3VwczogWydjb250cm9sX2Zsb3dfb3BzJywgJ2RhdGFfZmxvd19vcHMnXX0sXG4gICAge2NvbG9yOiAnUGluaycsIGdyb3VwczogWydzdW1tYXJ5X29wcyddfSxcbiAgICB7Y29sb3I6ICdEZWVwIFBpbmsnLCBncm91cHM6IFsnaW9fb3BzJ119XG4gIF0ucmVkdWNlKChtLCBjKSA9PiB7XG4gICAgYy5ncm91cHMuZm9yRWFjaChmdW5jdGlvbihncm91cCkgeyBtW2dyb3VwXSA9IGMuY29sb3I7IH0pO1xuICAgIHJldHVybiBtO1xuICB9LCB7fSk7XG59XG4iXX0=