/* Copyright 2017 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the 'License');
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an 'AS IS' BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
var tf_backend;
(function (tf_backend) {
    /**
     * A class that allows marking promises as cancelled.
     *
     * This can be useful to, e.g., prevent old network requests from
     * stomping new ones and writing bad data.
     *
     * Usage:
     *
     *     const canceller = new Canceller();
     *     let myPromise: Promise<Foo> = getPromise();
     *     myPromise.then(canceller.cancellable(({value, cancelled} => {
     *       if (cancelled) {
     *         console.warn("Don't make promises you can't keep >:-{");
     *       }
     *       console.log("Enjoy your value:", value);
     *     }));
     *
     *     // If `myPromise` is resolved now, then `cancelled` will be `false`.
     *     canceller.cancelAll();
     *     // If `myPromise` is resolved now, then `cancelled` will be `true`.
     */
    var Canceller = /** @class */ (function () {
        function Canceller() {
            /**
             * How many times has `cancelAll` been called?
             */
            this.cancellationCount = 0;
        }
        /**
         * Create a cancellable task. This returns a new function that, when
         * invoked, will pass its argument to the provided function as well as
         * a `cancelled` argument. This argument will be `false` unless and
         * until `cancelAll` is invoked after the creation of this task.
         */
        Canceller.prototype.cancellable = function (f) {
            var _this = this;
            var originalCancellationCount = this.cancellationCount;
            return function (value) {
                var cancelled = _this.cancellationCount !== originalCancellationCount;
                return f({ value: value, cancelled: cancelled });
            };
        };
        /**
         * Mark all outstanding tasks as cancelled. Tasks not yet created will
         * not be affected.
         */
        Canceller.prototype.cancelAll = function () {
            this.cancellationCount++;
        };
        return Canceller;
    }());
    tf_backend.Canceller = Canceller;
})(tf_backend || (tf_backend = {})); // namespace tf_backend
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2FuY2VsbGVyLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiY2FuY2VsbGVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7Ozs7Ozs7Ozs7O2dGQWFnRjtBQUNoRixJQUFVLFVBQVUsQ0FxRG5CO0FBckRELFdBQVUsVUFBVTtJQUVwQjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7T0FvQkc7SUFDSDtRQUFBO1lBQ0U7O2VBRUc7WUFDSyxzQkFBaUIsR0FBRyxDQUFDLENBQUM7UUF3QmhDLENBQUM7UUF0QkM7Ozs7O1dBS0c7UUFDSSwrQkFBVyxHQUFsQixVQUF5QixDQUFnRDtZQUF6RSxpQkFPQztZQUxDLElBQU0seUJBQXlCLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDO1lBQ3pELE9BQU8sVUFBQyxLQUFLO2dCQUNYLElBQU0sU0FBUyxHQUFHLEtBQUksQ0FBQyxpQkFBaUIsS0FBSyx5QkFBeUIsQ0FBQztnQkFDdkUsT0FBTyxDQUFDLENBQUMsRUFBQyxLQUFLLE9BQUEsRUFBRSxTQUFTLFdBQUEsRUFBQyxDQUFDLENBQUM7WUFDL0IsQ0FBQyxDQUFDO1FBQ0osQ0FBQztRQUVEOzs7V0FHRztRQUNJLDZCQUFTLEdBQWhCO1lBQ0UsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7UUFDM0IsQ0FBQztRQUNILGdCQUFDO0lBQUQsQ0FBQyxBQTVCRCxJQTRCQztJQTVCWSxvQkFBUyxZQTRCckIsQ0FBQTtBQUVELENBQUMsRUFyRFMsVUFBVSxLQUFWLFVBQVUsUUFxRG5CLENBQUUsdUJBQXVCIiwic291cmNlc0NvbnRlbnQiOlsiLyogQ29weXJpZ2h0IDIwMTcgVGhlIFRlbnNvckZsb3cgQXV0aG9ycy4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cblxuTGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlLCBWZXJzaW9uIDIuMCAodGhlICdMaWNlbnNlJyk7XG55b3UgbWF5IG5vdCB1c2UgdGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlIHdpdGggdGhlIExpY2Vuc2UuXG5Zb3UgbWF5IG9idGFpbiBhIGNvcHkgb2YgdGhlIExpY2Vuc2UgYXRcblxuICAgIGh0dHA6Ly93d3cuYXBhY2hlLm9yZy9saWNlbnNlcy9MSUNFTlNFLTIuMFxuXG5Vbmxlc3MgcmVxdWlyZWQgYnkgYXBwbGljYWJsZSBsYXcgb3IgYWdyZWVkIHRvIGluIHdyaXRpbmcsIHNvZnR3YXJlXG5kaXN0cmlidXRlZCB1bmRlciB0aGUgTGljZW5zZSBpcyBkaXN0cmlidXRlZCBvbiBhbiAnQVMgSVMnIEJBU0lTLFxuV0lUSE9VVCBXQVJSQU5USUVTIE9SIENPTkRJVElPTlMgT0YgQU5ZIEtJTkQsIGVpdGhlciBleHByZXNzIG9yIGltcGxpZWQuXG5TZWUgdGhlIExpY2Vuc2UgZm9yIHRoZSBzcGVjaWZpYyBsYW5ndWFnZSBnb3Zlcm5pbmcgcGVybWlzc2lvbnMgYW5kXG5saW1pdGF0aW9ucyB1bmRlciB0aGUgTGljZW5zZS5cbj09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSovXG5uYW1lc3BhY2UgdGZfYmFja2VuZCB7XG5cbi8qKlxuICogQSBjbGFzcyB0aGF0IGFsbG93cyBtYXJraW5nIHByb21pc2VzIGFzIGNhbmNlbGxlZC5cbiAqXG4gKiBUaGlzIGNhbiBiZSB1c2VmdWwgdG8sIGUuZy4sIHByZXZlbnQgb2xkIG5ldHdvcmsgcmVxdWVzdHMgZnJvbVxuICogc3RvbXBpbmcgbmV3IG9uZXMgYW5kIHdyaXRpbmcgYmFkIGRhdGEuXG4gKlxuICogVXNhZ2U6XG4gKlxuICogICAgIGNvbnN0IGNhbmNlbGxlciA9IG5ldyBDYW5jZWxsZXIoKTtcbiAqICAgICBsZXQgbXlQcm9taXNlOiBQcm9taXNlPEZvbz4gPSBnZXRQcm9taXNlKCk7XG4gKiAgICAgbXlQcm9taXNlLnRoZW4oY2FuY2VsbGVyLmNhbmNlbGxhYmxlKCh7dmFsdWUsIGNhbmNlbGxlZH0gPT4ge1xuICogICAgICAgaWYgKGNhbmNlbGxlZCkge1xuICogICAgICAgICBjb25zb2xlLndhcm4oXCJEb24ndCBtYWtlIHByb21pc2VzIHlvdSBjYW4ndCBrZWVwID46LXtcIik7XG4gKiAgICAgICB9XG4gKiAgICAgICBjb25zb2xlLmxvZyhcIkVuam95IHlvdXIgdmFsdWU6XCIsIHZhbHVlKTtcbiAqICAgICB9KSk7XG4gKlxuICogICAgIC8vIElmIGBteVByb21pc2VgIGlzIHJlc29sdmVkIG5vdywgdGhlbiBgY2FuY2VsbGVkYCB3aWxsIGJlIGBmYWxzZWAuXG4gKiAgICAgY2FuY2VsbGVyLmNhbmNlbEFsbCgpO1xuICogICAgIC8vIElmIGBteVByb21pc2VgIGlzIHJlc29sdmVkIG5vdywgdGhlbiBgY2FuY2VsbGVkYCB3aWxsIGJlIGB0cnVlYC5cbiAqL1xuZXhwb3J0IGNsYXNzIENhbmNlbGxlciB7XG4gIC8qKlxuICAgKiBIb3cgbWFueSB0aW1lcyBoYXMgYGNhbmNlbEFsbGAgYmVlbiBjYWxsZWQ/XG4gICAqL1xuICBwcml2YXRlIGNhbmNlbGxhdGlvbkNvdW50ID0gMDtcblxuICAvKipcbiAgICogQ3JlYXRlIGEgY2FuY2VsbGFibGUgdGFzay4gVGhpcyByZXR1cm5zIGEgbmV3IGZ1bmN0aW9uIHRoYXQsIHdoZW5cbiAgICogaW52b2tlZCwgd2lsbCBwYXNzIGl0cyBhcmd1bWVudCB0byB0aGUgcHJvdmlkZWQgZnVuY3Rpb24gYXMgd2VsbCBhc1xuICAgKiBhIGBjYW5jZWxsZWRgIGFyZ3VtZW50LiBUaGlzIGFyZ3VtZW50IHdpbGwgYmUgYGZhbHNlYCB1bmxlc3MgYW5kXG4gICAqIHVudGlsIGBjYW5jZWxBbGxgIGlzIGludm9rZWQgYWZ0ZXIgdGhlIGNyZWF0aW9uIG9mIHRoaXMgdGFzay5cbiAgICovXG4gIHB1YmxpYyBjYW5jZWxsYWJsZTxULCBVPihmOiAocmVzdWx0OiB7dmFsdWU6IFQsIGNhbmNlbGxlZDogYm9vbGVhbn0pID0+IFUpOlxuICAgICAgKFQpID0+IFUge1xuICAgIGNvbnN0IG9yaWdpbmFsQ2FuY2VsbGF0aW9uQ291bnQgPSB0aGlzLmNhbmNlbGxhdGlvbkNvdW50O1xuICAgIHJldHVybiAodmFsdWUpID0+IHtcbiAgICAgIGNvbnN0IGNhbmNlbGxlZCA9IHRoaXMuY2FuY2VsbGF0aW9uQ291bnQgIT09IG9yaWdpbmFsQ2FuY2VsbGF0aW9uQ291bnQ7XG4gICAgICByZXR1cm4gZih7dmFsdWUsIGNhbmNlbGxlZH0pO1xuICAgIH07XG4gIH1cblxuICAvKipcbiAgICogTWFyayBhbGwgb3V0c3RhbmRpbmcgdGFza3MgYXMgY2FuY2VsbGVkLiBUYXNrcyBub3QgeWV0IGNyZWF0ZWQgd2lsbFxuICAgKiBub3QgYmUgYWZmZWN0ZWQuXG4gICAqL1xuICBwdWJsaWMgY2FuY2VsQWxsKCk6IHZvaWQge1xuICAgIHRoaXMuY2FuY2VsbGF0aW9uQ291bnQrKztcbiAgfVxufVxuXG59ICAvLyBuYW1lc3BhY2UgdGZfYmFja2VuZFxuIl19