/* Copyright 2018 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the 'License');
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an 'AS IS' BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
var tf_data_selector;
(function (tf_data_selector) {
    var Type;
    (function (Type) {
        Type[Type["WITHOUT_EXPERIMENT"] = 0] = "WITHOUT_EXPERIMENT";
        Type[Type["SINGLE"] = 1] = "SINGLE";
        Type[Type["COMPARISON"] = 2] = "COMPARISON";
    })(Type = tf_data_selector.Type || (tf_data_selector.Type = {}));
})(tf_data_selector || (tf_data_selector = {})); // namespace tf_data_selector
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidHlwZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbInR5cGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7Ozs7Ozs7Z0ZBYWdGO0FBQ2hGLElBQVUsZ0JBQWdCLENBbUJ6QjtBQW5CRCxXQUFVLGdCQUFnQjtJQUUxQixJQUFZLElBSVg7SUFKRCxXQUFZLElBQUk7UUFDZCwyREFBa0IsQ0FBQTtRQUNsQixtQ0FBTSxDQUFBO1FBQ04sMkNBQVUsQ0FBQTtJQUNaLENBQUMsRUFKVyxJQUFJLEdBQUoscUJBQUksS0FBSixxQkFBSSxRQUlmO0FBYUQsQ0FBQyxFQW5CUyxnQkFBZ0IsS0FBaEIsZ0JBQWdCLFFBbUJ6QixDQUFFLDZCQUE2QiIsInNvdXJjZXNDb250ZW50IjpbIi8qIENvcHlyaWdodCAyMDE4IFRoZSBUZW5zb3JGbG93IEF1dGhvcnMuIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG5cbkxpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSAnTGljZW5zZScpO1xueW91IG1heSBub3QgdXNlIHRoaXMgZmlsZSBleGNlcHQgaW4gY29tcGxpYW5jZSB3aXRoIHRoZSBMaWNlbnNlLlxuWW91IG1heSBvYnRhaW4gYSBjb3B5IG9mIHRoZSBMaWNlbnNlIGF0XG5cbiAgICBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcblxuVW5sZXNzIHJlcXVpcmVkIGJ5IGFwcGxpY2FibGUgbGF3IG9yIGFncmVlZCB0byBpbiB3cml0aW5nLCBzb2Z0d2FyZVxuZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIExpY2Vuc2UgaXMgZGlzdHJpYnV0ZWQgb24gYW4gJ0FTIElTJyBCQVNJUyxcbldJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWSBLSU5ELCBlaXRoZXIgZXhwcmVzcyBvciBpbXBsaWVkLlxuU2VlIHRoZSBMaWNlbnNlIGZvciB0aGUgc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nIHBlcm1pc3Npb25zIGFuZFxubGltaXRhdGlvbnMgdW5kZXIgdGhlIExpY2Vuc2UuXG49PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0qL1xubmFtZXNwYWNlIHRmX2RhdGFfc2VsZWN0b3Ige1xuXG5leHBvcnQgZW51bSBUeXBlIHtcbiAgV0lUSE9VVF9FWFBFUklNRU5ULFxuICBTSU5HTEUsXG4gIENPTVBBUklTT04sXG59XG5cbmV4cG9ydCB0eXBlIFNlbGVjdGlvbiA9IHtcbiAgZXhwZXJpbWVudD86IHRmX2JhY2tlbmQuRXhwZXJpbWVudCxcbiAgcnVuczogQXJyYXk8dGZfYmFja2VuZC5SdW4+LFxuICB0YWdSZWdleDogc3RyaW5nLFxufVxuXG5leHBvcnQgdHlwZSBEYXRhU2VsZWN0aW9uID0ge1xuICB0eXBlOiBUeXBlLFxuICBzZWxlY3Rpb25zOiBBcnJheTxTZWxlY3Rpb24+XG59XG5cbn0gIC8vIG5hbWVzcGFjZSB0Zl9kYXRhX3NlbGVjdG9yXG4iXX0=