declare namespace tf_backend {
    enum Mode {
        DB = 0,
        LOGDIR = 1
    }
    class EnvironmentStore extends BaseStore {
        private environment;
        load(): Promise<void>;
        getDataLocation(): string;
        getMode(): Mode;
        getWindowTitle(): string;
    }
    const environmentStore: EnvironmentStore;
}
