declare namespace tf_dashboard_common {
    /**
     * @polymerBehavior
     */
    const DataLoaderBehavior: {
        properties: {
            /**
             * An unique identifiable string. When changes, it expunges the data
             * cache.
             */
            loadKey: {
                type: StringConstructor;
                value: string;
            };
            dataToLoad: {
                type: ArrayConstructor;
                value: () => any[];
            };
            /**
             * A function that takes a datum as an input and returns a unique
             * identifiable string. Used for caching purposes.
             */
            getDataLoadName: {
                type: FunctionConstructor;
                value: () => (datum: any) => string;
            };
            /**
             * A function that takes as inputs:
             * 1. Implementing component of data-loader-behavior.
             * 2. datum of the request.
             * 3. The response received from the data URL.
             * This function will be called when a response from a request to that
             * data URL is successfully received.
             */
            loadDataCallback: FunctionConstructor;
            getDataLoadUrl: FunctionConstructor;
            dataLoading: {
                type: BooleanConstructor;
                readOnly: boolean;
                reflectToAttribute: boolean;
                value: boolean;
            };
            _loadedData: {
                type: ObjectConstructor;
                value: () => Set<any>;
            };
            _canceller: {
                type: ObjectConstructor;
                value: () => tf_backend.Canceller;
            };
        };
        observers: string[];
        onLoadFinish(): void;
        reload(): void;
        reset(): void;
        _dataToLoadChanged(): void;
        created(): void;
        detached(): void;
        _loadDataImpl(): void;
    };
}
