declare namespace vz_line_chart2 {
    enum State {
        NONE = 0,
        DRAG_ZOOMING = 1,
        PANNING = 2
    }
    type PanCallback = () => void;
    class PanZoomDragLayer extends Plottable.Components.Group {
        private panZoom;
        private dragZoomLayer;
        private state;
        private panStartCallback;
        private panEndCallback;
        /**
         * A Plottable component/layer with a complex interaction for the line chart.
         * When not pressing alt-key, it behaves like DragZoomLayer -- dragging a
         * region zooms the area under the gray box and double clicking resets the
         * zoom. When pressing alt-key, it lets user pan around while having mousedown
         * on the chart and let user zoom-in/out of cursor when scroll.
         */
        constructor(xScale: Plottable.QuantitativeScale<number | {
            valueOf(): number;
        }>, yScale: Plottable.QuantitativeScale<number | {
            valueOf(): number;
        }>, unzoomMethod: Function);
        static isPanKey(event: MouseEvent): boolean;
        setState(nextState: State): void;
        stateClassName(state: State): string;
        onPanStart(cb: PanCallback): void;
        onPanEnd(cb: PanCallback): void;
        onScrollZoom(cb: any): void;
        onDragZoomStart(cb: any): void;
        onDragZoomEnd(cb: any): void;
    }
}
