declare namespace vz_distribution_chart {
    class DistributionChart {
        private run2datasets;
        protected runs: string[];
        protected xAccessor: Plottable.IAccessor<number | Date>;
        protected xScale: Plottable.QuantitativeScale<number | Date>;
        protected yScale: Plottable.QuantitativeScale<number>;
        protected gridlines: Plottable.Components.Gridlines;
        protected center: Plottable.Components.Group;
        protected xAxis: Plottable.Axes.Numeric | Plottable.Axes.Time;
        protected yAxis: Plottable.Axes.Numeric;
        protected xLabel: Plottable.Components.AxisLabel;
        protected yLabel: Plottable.Components.AxisLabel;
        protected outer: Plottable.Components.Table;
        protected colorScale: Plottable.Scales.Color;
        private plots;
        private targetSVG;
        constructor(xType: string, colorScale: Plottable.Scales.Color);
        protected getDataset(run: string): Plottable.Dataset;
        protected buildChart(xType: string): void;
        protected buildPlot(xAccessor: any, xScale: any, yScale: any): Plottable.Component;
        setVisibleSeries(runs: string[]): void;
        /**
         * Set the data of a series on the chart.
         */
        setSeriesData(name: string, data: any): void;
        renderTo(targetSVG: d3.Selection<any, any, any, any>): void;
        redraw(): void;
        protected destroy(): void;
    }
}
