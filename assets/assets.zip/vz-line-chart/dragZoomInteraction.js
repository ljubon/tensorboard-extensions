var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
/* Copyright 2015 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the 'License');
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an 'AS IS' BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
var vz_line_chart;
(function (vz_line_chart) {
    var DragZoomLayer = /** @class */ (function (_super) {
        __extends(DragZoomLayer, _super);
        /**
         * Constructs a SelectionBoxLayer with an attached DragInteraction and
         * ClickInteraction. On drag, it triggers an animated zoom into the box
         * that was dragged. On double click, it zooms back out to the original
         * view, before any zooming.
         * The zoom animation uses an easing function (default
         * d3.ease('cubic-in-out')) and is customizable.
         * Usage: Construct the selection box layer and attach x and y scales,
         * and then add the layer over the plot you are zooming on using a
         * Component Group.
         * TODO(@dandelionmane) - merge this into Plottable
         */
        function DragZoomLayer(xScale, yScale, unzoomMethod) {
            var _this = _super.call(this) || this;
            _this.easeFn = d3.easeCubicInOut;
            _this._animationTime = 750;
            _this.xScale(xScale);
            _this.yScale(yScale);
            _this._dragInteraction = new Plottable.Interactions.Drag();
            _this._doubleClickInteraction = new Plottable.Interactions.Click();
            _this.setupCallbacks();
            _this.unzoomMethod = unzoomMethod;
            // Activate interaction only when the component is mounted onto DOM.
            _this.onDetach(function () {
                _this._doubleClickInteraction.detachFrom(_this);
                _this._dragInteraction.detachFrom(_this);
            });
            _this.onAnchor(function () {
                _this._doubleClickInteraction.attachTo(_this);
                _this._dragInteraction.attachTo(_this);
            });
            return _this;
        }
        /**
         * Register a method that calls when the DragZoom interaction starts.
         */
        DragZoomLayer.prototype.interactionStart = function (cb) {
            this.onStart = cb;
        };
        /**
         * Register a method that calls when the DragZoom interaction ends.
         */
        DragZoomLayer.prototype.interactionEnd = function (cb) {
            this.onEnd = cb;
        };
        /**
         * Returns backing drag interaction. Useful for customization to the
         * interaction.
         */
        DragZoomLayer.prototype.dragInteraction = function () {
            return this._dragInteraction;
        };
        DragZoomLayer.prototype.setupCallbacks = function () {
            var _this = this;
            var dragging = false;
            this._dragInteraction.onDragStart(function (startPoint) {
                _this.bounds({
                    topLeft: startPoint,
                    bottomRight: startPoint,
                });
                _this.onStart();
            });
            this._dragInteraction.onDrag(function (startPoint, endPoint) {
                _this.bounds({ topLeft: startPoint, bottomRight: endPoint });
                _this.boxVisible(true);
                dragging = true;
            });
            this._dragInteraction.onDragEnd(function (startPoint, endPoint) {
                _this.boxVisible(false);
                _this.bounds({ topLeft: startPoint, bottomRight: endPoint });
                if (dragging) {
                    _this.zoom();
                }
                else {
                    _this.onEnd();
                }
                dragging = false;
            });
            this._doubleClickInteraction.onDoubleClick(this.unzoom.bind(this));
        };
        DragZoomLayer.prototype.animationTime = function (animationTime) {
            if (animationTime == null) {
                return this._animationTime;
            }
            if (animationTime < 0) {
                throw new Error('animationTime cannot be negative');
            }
            this._animationTime = animationTime;
            return this;
        };
        /**
         * Set the easing function, which determines how the zoom interpolates
         * over time.
         */
        DragZoomLayer.prototype.ease = function (fn) {
            if (typeof (fn) !== 'function') {
                throw new Error('ease function must be a function');
            }
            if (fn(0) !== 0 || fn(1) !== 1) {
                Plottable.Utils.Window.warn('Easing function does not maintain invariant ' +
                    'f(0)==0 && f(1)==1. Bad behavior may result.');
            }
            this.easeFn = fn;
            return this;
        };
        // Zoom into extent of the selection box bounds
        DragZoomLayer.prototype.zoom = function () {
            var x0 = this.xExtent()[0].valueOf();
            var x1 = this.xExtent()[1].valueOf();
            var y0 = this.yExtent()[1].valueOf();
            var y1 = this.yExtent()[0].valueOf();
            if (x0 === x1 || y0 === y1) {
                return;
            }
            this.interpolateZoom(x0, x1, y0, y1);
        };
        // Restore the scales to their state before any zoom
        DragZoomLayer.prototype.unzoom = function () {
            // We need to reset the zoom domain unconditionally, as the data or the
            // smoothing may have updated, such that we are not longer fully zoomed out.
            var xScale = this.xScale();
            xScale._domainMin = null;
            xScale._domainMax = null;
            var xDomain = xScale._getExtent();
            this.xScale().domain(xDomain);
            this.unzoomMethod();
        };
        // If we are zooming, disable interactions, to avoid contention
        DragZoomLayer.prototype.isZooming = function (isZooming) {
            this._dragInteraction.enabled(!isZooming);
            this._doubleClickInteraction.enabled(!isZooming);
        };
        DragZoomLayer.prototype.interpolateZoom = function (x0f, x1f, y0f, y1f) {
            var _this = this;
            var x0s = this.xScale().domain()[0].valueOf();
            var x1s = this.xScale().domain()[1].valueOf();
            var y0s = this.yScale().domain()[0].valueOf();
            var y1s = this.yScale().domain()[1].valueOf();
            // Copy a ref to the ease fn, so that changing ease wont affect zooms in
            // progress.
            var ease = this.easeFn;
            var interpolator = function (a, b, p) {
                return d3.interpolateNumber(a, b)(ease(p));
            };
            this.isZooming(true);
            var start = Date.now();
            var draw = function () {
                var now = Date.now();
                var passed = now - start;
                var p = _this._animationTime === 0 ?
                    1 :
                    Math.min(1, passed / _this._animationTime);
                var x0 = interpolator(x0s, x0f, p);
                var x1 = interpolator(x1s, x1f, p);
                var y0 = interpolator(y0s, y0f, p);
                var y1 = interpolator(y1s, y1f, p);
                _this.xScale().domain([x0, x1]);
                _this.yScale().domain([y0, y1]);
                if (p < 1) {
                    Plottable.Utils.DOM.requestAnimationFramePolyfill(draw);
                }
                else {
                    _this.onEnd();
                    _this.isZooming(false);
                }
            };
            draw();
        };
        return DragZoomLayer;
    }(Plottable.Components.SelectionBoxLayer));
    vz_line_chart.DragZoomLayer = DragZoomLayer;
})(vz_line_chart || (vz_line_chart = {})); // namespace vz_line_chart
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZHJhZ1pvb21JbnRlcmFjdGlvbi5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImRyYWdab29tSW50ZXJhY3Rpb24udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztBQUFBOzs7Ozs7Ozs7Ozs7O2dGQWFnRjtBQUNoRixJQUFVLGFBQWEsQ0FzTXRCO0FBdE1ELFdBQVUsYUFBYTtJQUV2QjtRQUFtQyxpQ0FBc0M7UUFTdkU7Ozs7Ozs7Ozs7O1dBV0c7UUFDSCx1QkFDSSxNQUErRCxFQUMvRCxNQUErRCxFQUMvRCxZQUFzQjtZQUgxQixZQUlFLGlCQUFPLFNBaUJSO1lBdkNPLFlBQU0sR0FBMEIsRUFBRSxDQUFDLGNBQWMsQ0FBQztZQUNsRCxvQkFBYyxHQUFHLEdBQUcsQ0FBQztZQXNCM0IsS0FBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUNwQixLQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQ3BCLEtBQUksQ0FBQyxnQkFBZ0IsR0FBRyxJQUFJLFNBQVMsQ0FBQyxZQUFZLENBQUMsSUFBSSxFQUFFLENBQUM7WUFDMUQsS0FBSSxDQUFDLHVCQUF1QixHQUFHLElBQUksU0FBUyxDQUFDLFlBQVksQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUNsRSxLQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7WUFDdEIsS0FBSSxDQUFDLFlBQVksR0FBRyxZQUFZLENBQUM7WUFFakMsb0VBQW9FO1lBQ3BFLEtBQUksQ0FBQyxRQUFRLENBQUM7Z0JBQ1osS0FBSSxDQUFDLHVCQUF1QixDQUFDLFVBQVUsQ0FBQyxLQUFJLENBQUMsQ0FBQztnQkFDOUMsS0FBSSxDQUFDLGdCQUFnQixDQUFDLFVBQVUsQ0FBQyxLQUFJLENBQUMsQ0FBQztZQUN6QyxDQUFDLENBQUMsQ0FBQztZQUNILEtBQUksQ0FBQyxRQUFRLENBQUM7Z0JBQ1osS0FBSSxDQUFDLHVCQUF1QixDQUFDLFFBQVEsQ0FBQyxLQUFJLENBQUMsQ0FBQztnQkFDNUMsS0FBSSxDQUFDLGdCQUFnQixDQUFDLFFBQVEsQ0FBQyxLQUFJLENBQUMsQ0FBQztZQUN2QyxDQUFDLENBQUMsQ0FBQzs7UUFDTCxDQUFDO1FBRUQ7O1dBRUc7UUFDSSx3Q0FBZ0IsR0FBdkIsVUFBd0IsRUFBWTtZQUNsQyxJQUFJLENBQUMsT0FBTyxHQUFHLEVBQUUsQ0FBQztRQUNwQixDQUFDO1FBRUQ7O1dBRUc7UUFDSSxzQ0FBYyxHQUFyQixVQUFzQixFQUFZO1lBQ2hDLElBQUksQ0FBQyxLQUFLLEdBQUcsRUFBRSxDQUFDO1FBQ2xCLENBQUM7UUFFRDs7O1dBR0c7UUFDSSx1Q0FBZSxHQUF0QjtZQUNFLE9BQU8sSUFBSSxDQUFDLGdCQUFnQixDQUFDO1FBQy9CLENBQUM7UUFFTyxzQ0FBYyxHQUF0QjtZQUFBLGlCQTBCQztZQXpCQyxJQUFJLFFBQVEsR0FBRyxLQUFLLENBQUM7WUFDckIsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFdBQVcsQ0FBQyxVQUFDLFVBQTJCO2dCQUM1RCxLQUFJLENBQUMsTUFBTSxDQUFDO29CQUNWLE9BQU8sRUFBRSxVQUFVO29CQUNuQixXQUFXLEVBQUUsVUFBVTtpQkFDeEIsQ0FBQyxDQUFDO2dCQUNILEtBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztZQUNqQixDQUFDLENBQUMsQ0FBQztZQUNILElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxNQUFNLENBQUMsVUFBQyxVQUFVLEVBQUUsUUFBUTtnQkFDaEQsS0FBSSxDQUFDLE1BQU0sQ0FBQyxFQUFDLE9BQU8sRUFBRSxVQUFVLEVBQUUsV0FBVyxFQUFFLFFBQVEsRUFBQyxDQUFDLENBQUM7Z0JBQzFELEtBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUM7Z0JBQ3RCLFFBQVEsR0FBRyxJQUFJLENBQUM7WUFDbEIsQ0FBQyxDQUFDLENBQUM7WUFDSCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLFVBQUMsVUFBVSxFQUFFLFFBQVE7Z0JBQ25ELEtBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQ3ZCLEtBQUksQ0FBQyxNQUFNLENBQUMsRUFBQyxPQUFPLEVBQUUsVUFBVSxFQUFFLFdBQVcsRUFBRSxRQUFRLEVBQUMsQ0FBQyxDQUFDO2dCQUMxRCxJQUFJLFFBQVEsRUFBRTtvQkFDWixLQUFJLENBQUMsSUFBSSxFQUFFLENBQUM7aUJBQ2I7cUJBQU07b0JBQ0wsS0FBSSxDQUFDLEtBQUssRUFBRSxDQUFDO2lCQUNkO2dCQUNELFFBQVEsR0FBRyxLQUFLLENBQUM7WUFDbkIsQ0FBQyxDQUFDLENBQUM7WUFFSCxJQUFJLENBQUMsdUJBQXVCLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7UUFDckUsQ0FBQztRQU9NLHFDQUFhLEdBQXBCLFVBQXFCLGFBQXNCO1lBQ3pDLElBQUksYUFBYSxJQUFJLElBQUksRUFBRTtnQkFDekIsT0FBTyxJQUFJLENBQUMsY0FBYyxDQUFDO2FBQzVCO1lBQ0QsSUFBSSxhQUFhLEdBQUcsQ0FBQyxFQUFFO2dCQUNyQixNQUFNLElBQUksS0FBSyxDQUFDLGtDQUFrQyxDQUFDLENBQUM7YUFDckQ7WUFDRCxJQUFJLENBQUMsY0FBYyxHQUFHLGFBQWEsQ0FBQztZQUNwQyxPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7UUFFRDs7O1dBR0c7UUFDSSw0QkFBSSxHQUFYLFVBQVksRUFBeUI7WUFDbkMsSUFBSSxPQUFNLENBQUMsRUFBRSxDQUFDLEtBQUssVUFBVSxFQUFFO2dCQUM3QixNQUFNLElBQUksS0FBSyxDQUFDLGtDQUFrQyxDQUFDLENBQUM7YUFDckQ7WUFDRCxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsRUFBRTtnQkFDOUIsU0FBUyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUN2Qiw4Q0FBOEM7b0JBQzlDLDhDQUE4QyxDQUFDLENBQUM7YUFDckQ7WUFDRCxJQUFJLENBQUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztZQUNqQixPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7UUFFRCwrQ0FBK0M7UUFDdkMsNEJBQUksR0FBWjtZQUNFLElBQUksRUFBRSxHQUFXLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLEVBQUUsQ0FBQztZQUM3QyxJQUFJLEVBQUUsR0FBVyxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxFQUFFLENBQUM7WUFDN0MsSUFBSSxFQUFFLEdBQVcsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sRUFBRSxDQUFDO1lBQzdDLElBQUksRUFBRSxHQUFXLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLEVBQUUsQ0FBQztZQUU3QyxJQUFJLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsRUFBRTtnQkFDMUIsT0FBTzthQUNSO1lBRUQsSUFBSSxDQUFDLGVBQWUsQ0FBQyxFQUFFLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQztRQUN2QyxDQUFDO1FBRUQsb0RBQW9EO1FBQzVDLDhCQUFNLEdBQWQ7WUFDRSx1RUFBdUU7WUFDdkUsNEVBQTRFO1lBQzVFLElBQUksTUFBTSxHQUFHLElBQUksQ0FBQyxNQUFNLEVBQVMsQ0FBQztZQUNsQyxNQUFNLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQztZQUN6QixNQUFNLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQztZQUN6QixJQUFJLE9BQU8sR0FBRyxNQUFNLENBQUMsVUFBVSxFQUFFLENBQUM7WUFDbEMsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUM5QixJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7UUFDdEIsQ0FBQztRQUVELCtEQUErRDtRQUN2RCxpQ0FBUyxHQUFqQixVQUFrQixTQUFrQjtZQUNsQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUM7WUFDMUMsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQ25ELENBQUM7UUFFTyx1Q0FBZSxHQUF2QixVQUF3QixHQUFXLEVBQUUsR0FBVyxFQUFFLEdBQVcsRUFBRSxHQUFXO1lBQTFFLGlCQWtDQztZQWpDQyxJQUFJLEdBQUcsR0FBVyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxFQUFFLENBQUM7WUFDdEQsSUFBSSxHQUFHLEdBQVcsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sRUFBRSxDQUFDO1lBQ3RELElBQUksR0FBRyxHQUFXLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLEVBQUUsQ0FBQztZQUN0RCxJQUFJLEdBQUcsR0FBVyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxFQUFFLENBQUM7WUFFdEQsd0VBQXdFO1lBQ3hFLFlBQVk7WUFDWixJQUFJLElBQUksR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDO1lBQ3ZCLElBQUksWUFBWSxHQUFHLFVBQUMsQ0FBUyxFQUFFLENBQVMsRUFBRSxDQUFTO2dCQUMvQyxPQUFBLEVBQUUsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQW5DLENBQW1DLENBQUM7WUFFeEMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUNyQixJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUM7WUFDdkIsSUFBSSxJQUFJLEdBQUc7Z0JBQ1QsSUFBSSxHQUFHLEdBQUcsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDO2dCQUNyQixJQUFJLE1BQU0sR0FBRyxHQUFHLEdBQUcsS0FBSyxDQUFDO2dCQUN6QixJQUFJLENBQUMsR0FBRyxLQUFJLENBQUMsY0FBYyxLQUFLLENBQUMsQ0FBQyxDQUFDO29CQUMvQixDQUFDLENBQUMsQ0FBQztvQkFDSCxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxNQUFNLEdBQUcsS0FBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDO2dCQUM5QyxJQUFJLEVBQUUsR0FBRyxZQUFZLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FBQztnQkFDbkMsSUFBSSxFQUFFLEdBQUcsWUFBWSxDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUM7Z0JBQ25DLElBQUksRUFBRSxHQUFHLFlBQVksQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDO2dCQUNuQyxJQUFJLEVBQUUsR0FBRyxZQUFZLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FBQztnQkFDbkMsS0FBSSxDQUFDLE1BQU0sRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDO2dCQUMvQixLQUFJLENBQUMsTUFBTSxFQUFFLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUM7Z0JBQy9CLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRTtvQkFDVCxTQUFTLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyw2QkFBNkIsQ0FBQyxJQUFJLENBQUMsQ0FBQztpQkFDekQ7cUJBQU07b0JBQ0wsS0FBSSxDQUFDLEtBQUssRUFBRSxDQUFDO29CQUNiLEtBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUM7aUJBQ3ZCO1lBQ0gsQ0FBQyxDQUFDO1lBQ0YsSUFBSSxFQUFFLENBQUM7UUFDVCxDQUFDO1FBQ0gsb0JBQUM7SUFBRCxDQUFDLEFBbE1ELENBQW1DLFNBQVMsQ0FBQyxVQUFVLENBQUMsaUJBQWlCLEdBa014RTtJQWxNWSwyQkFBYSxnQkFrTXpCLENBQUE7QUFFRCxDQUFDLEVBdE1TLGFBQWEsS0FBYixhQUFhLFFBc010QixDQUFFLDBCQUEwQiIsInNvdXJjZXNDb250ZW50IjpbIi8qIENvcHlyaWdodCAyMDE1IFRoZSBUZW5zb3JGbG93IEF1dGhvcnMuIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG5cbkxpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSAnTGljZW5zZScpO1xueW91IG1heSBub3QgdXNlIHRoaXMgZmlsZSBleGNlcHQgaW4gY29tcGxpYW5jZSB3aXRoIHRoZSBMaWNlbnNlLlxuWW91IG1heSBvYnRhaW4gYSBjb3B5IG9mIHRoZSBMaWNlbnNlIGF0XG5cbiAgICBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcblxuVW5sZXNzIHJlcXVpcmVkIGJ5IGFwcGxpY2FibGUgbGF3IG9yIGFncmVlZCB0byBpbiB3cml0aW5nLCBzb2Z0d2FyZVxuZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIExpY2Vuc2UgaXMgZGlzdHJpYnV0ZWQgb24gYW4gJ0FTIElTJyBCQVNJUyxcbldJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWSBLSU5ELCBlaXRoZXIgZXhwcmVzcyBvciBpbXBsaWVkLlxuU2VlIHRoZSBMaWNlbnNlIGZvciB0aGUgc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nIHBlcm1pc3Npb25zIGFuZFxubGltaXRhdGlvbnMgdW5kZXIgdGhlIExpY2Vuc2UuXG49PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0qL1xubmFtZXNwYWNlIHZ6X2xpbmVfY2hhcnQge1xuXG5leHBvcnQgY2xhc3MgRHJhZ1pvb21MYXllciBleHRlbmRzIFBsb3R0YWJsZS5Db21wb25lbnRzLlNlbGVjdGlvbkJveExheWVyIHtcbiAgcHJpdmF0ZSBfZHJhZ0ludGVyYWN0aW9uOiBQbG90dGFibGUuSW50ZXJhY3Rpb25zLkRyYWc7XG4gIHByaXZhdGUgX2RvdWJsZUNsaWNrSW50ZXJhY3Rpb246IFBsb3R0YWJsZS5JbnRlcmFjdGlvbnMuQ2xpY2s7XG4gIHByaXZhdGUgZWFzZUZuOiAodDogbnVtYmVyKSA9PiBudW1iZXIgPSBkMy5lYXNlQ3ViaWNJbk91dDtcbiAgcHJpdmF0ZSBfYW5pbWF0aW9uVGltZSA9IDc1MDtcbiAgcHJpdmF0ZSBvblN0YXJ0OiBGdW5jdGlvbjtcbiAgcHJpdmF0ZSBvbkVuZDogRnVuY3Rpb247XG4gIHByaXZhdGUgdW56b29tTWV0aG9kOiBGdW5jdGlvbjtcblxuICAvKipcbiAgICogQ29uc3RydWN0cyBhIFNlbGVjdGlvbkJveExheWVyIHdpdGggYW4gYXR0YWNoZWQgRHJhZ0ludGVyYWN0aW9uIGFuZFxuICAgKiBDbGlja0ludGVyYWN0aW9uLiBPbiBkcmFnLCBpdCB0cmlnZ2VycyBhbiBhbmltYXRlZCB6b29tIGludG8gdGhlIGJveFxuICAgKiB0aGF0IHdhcyBkcmFnZ2VkLiBPbiBkb3VibGUgY2xpY2ssIGl0IHpvb21zIGJhY2sgb3V0IHRvIHRoZSBvcmlnaW5hbFxuICAgKiB2aWV3LCBiZWZvcmUgYW55IHpvb21pbmcuXG4gICAqIFRoZSB6b29tIGFuaW1hdGlvbiB1c2VzIGFuIGVhc2luZyBmdW5jdGlvbiAoZGVmYXVsdFxuICAgKiBkMy5lYXNlKCdjdWJpYy1pbi1vdXQnKSkgYW5kIGlzIGN1c3RvbWl6YWJsZS5cbiAgICogVXNhZ2U6IENvbnN0cnVjdCB0aGUgc2VsZWN0aW9uIGJveCBsYXllciBhbmQgYXR0YWNoIHggYW5kIHkgc2NhbGVzLFxuICAgKiBhbmQgdGhlbiBhZGQgdGhlIGxheWVyIG92ZXIgdGhlIHBsb3QgeW91IGFyZSB6b29taW5nIG9uIHVzaW5nIGFcbiAgICogQ29tcG9uZW50IEdyb3VwLlxuICAgKiBUT0RPKEBkYW5kZWxpb25tYW5lKSAtIG1lcmdlIHRoaXMgaW50byBQbG90dGFibGVcbiAgICovXG4gIGNvbnN0cnVjdG9yKFxuICAgICAgeFNjYWxlOiBQbG90dGFibGUuUXVhbnRpdGF0aXZlU2NhbGU8bnVtYmVyfHt2YWx1ZU9mKCk6IG51bWJlcn0+LFxuICAgICAgeVNjYWxlOiBQbG90dGFibGUuUXVhbnRpdGF0aXZlU2NhbGU8bnVtYmVyfHt2YWx1ZU9mKCk6IG51bWJlcn0+LFxuICAgICAgdW56b29tTWV0aG9kOiBGdW5jdGlvbikge1xuICAgIHN1cGVyKCk7XG4gICAgdGhpcy54U2NhbGUoeFNjYWxlKTtcbiAgICB0aGlzLnlTY2FsZSh5U2NhbGUpO1xuICAgIHRoaXMuX2RyYWdJbnRlcmFjdGlvbiA9IG5ldyBQbG90dGFibGUuSW50ZXJhY3Rpb25zLkRyYWcoKTtcbiAgICB0aGlzLl9kb3VibGVDbGlja0ludGVyYWN0aW9uID0gbmV3IFBsb3R0YWJsZS5JbnRlcmFjdGlvbnMuQ2xpY2soKTtcbiAgICB0aGlzLnNldHVwQ2FsbGJhY2tzKCk7XG4gICAgdGhpcy51bnpvb21NZXRob2QgPSB1bnpvb21NZXRob2Q7XG5cbiAgICAvLyBBY3RpdmF0ZSBpbnRlcmFjdGlvbiBvbmx5IHdoZW4gdGhlIGNvbXBvbmVudCBpcyBtb3VudGVkIG9udG8gRE9NLlxuICAgIHRoaXMub25EZXRhY2goKCkgPT4ge1xuICAgICAgdGhpcy5fZG91YmxlQ2xpY2tJbnRlcmFjdGlvbi5kZXRhY2hGcm9tKHRoaXMpO1xuICAgICAgdGhpcy5fZHJhZ0ludGVyYWN0aW9uLmRldGFjaEZyb20odGhpcyk7XG4gICAgfSk7XG4gICAgdGhpcy5vbkFuY2hvcigoKSA9PiB7XG4gICAgICB0aGlzLl9kb3VibGVDbGlja0ludGVyYWN0aW9uLmF0dGFjaFRvKHRoaXMpO1xuICAgICAgdGhpcy5fZHJhZ0ludGVyYWN0aW9uLmF0dGFjaFRvKHRoaXMpO1xuICAgIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIFJlZ2lzdGVyIGEgbWV0aG9kIHRoYXQgY2FsbHMgd2hlbiB0aGUgRHJhZ1pvb20gaW50ZXJhY3Rpb24gc3RhcnRzLlxuICAgKi9cbiAgcHVibGljIGludGVyYWN0aW9uU3RhcnQoY2I6IEZ1bmN0aW9uKSB7XG4gICAgdGhpcy5vblN0YXJ0ID0gY2I7XG4gIH1cblxuICAvKipcbiAgICogUmVnaXN0ZXIgYSBtZXRob2QgdGhhdCBjYWxscyB3aGVuIHRoZSBEcmFnWm9vbSBpbnRlcmFjdGlvbiBlbmRzLlxuICAgKi9cbiAgcHVibGljIGludGVyYWN0aW9uRW5kKGNiOiBGdW5jdGlvbikge1xuICAgIHRoaXMub25FbmQgPSBjYjtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm5zIGJhY2tpbmcgZHJhZyBpbnRlcmFjdGlvbi4gVXNlZnVsIGZvciBjdXN0b21pemF0aW9uIHRvIHRoZVxuICAgKiBpbnRlcmFjdGlvbi5cbiAgICovXG4gIHB1YmxpYyBkcmFnSW50ZXJhY3Rpb24oKTogUGxvdHRhYmxlLkludGVyYWN0aW9ucy5EcmFnIHtcbiAgICByZXR1cm4gdGhpcy5fZHJhZ0ludGVyYWN0aW9uO1xuICB9XG5cbiAgcHJpdmF0ZSBzZXR1cENhbGxiYWNrcygpIHtcbiAgICBsZXQgZHJhZ2dpbmcgPSBmYWxzZTtcbiAgICB0aGlzLl9kcmFnSW50ZXJhY3Rpb24ub25EcmFnU3RhcnQoKHN0YXJ0UG9pbnQ6IFBsb3R0YWJsZS5Qb2ludCkgPT4ge1xuICAgICAgdGhpcy5ib3VuZHMoe1xuICAgICAgICB0b3BMZWZ0OiBzdGFydFBvaW50LFxuICAgICAgICBib3R0b21SaWdodDogc3RhcnRQb2ludCxcbiAgICAgIH0pO1xuICAgICAgdGhpcy5vblN0YXJ0KCk7XG4gICAgfSk7XG4gICAgdGhpcy5fZHJhZ0ludGVyYWN0aW9uLm9uRHJhZygoc3RhcnRQb2ludCwgZW5kUG9pbnQpID0+IHtcbiAgICAgIHRoaXMuYm91bmRzKHt0b3BMZWZ0OiBzdGFydFBvaW50LCBib3R0b21SaWdodDogZW5kUG9pbnR9KTtcbiAgICAgIHRoaXMuYm94VmlzaWJsZSh0cnVlKTtcbiAgICAgIGRyYWdnaW5nID0gdHJ1ZTtcbiAgICB9KTtcbiAgICB0aGlzLl9kcmFnSW50ZXJhY3Rpb24ub25EcmFnRW5kKChzdGFydFBvaW50LCBlbmRQb2ludCkgPT4ge1xuICAgICAgdGhpcy5ib3hWaXNpYmxlKGZhbHNlKTtcbiAgICAgIHRoaXMuYm91bmRzKHt0b3BMZWZ0OiBzdGFydFBvaW50LCBib3R0b21SaWdodDogZW5kUG9pbnR9KTtcbiAgICAgIGlmIChkcmFnZ2luZykge1xuICAgICAgICB0aGlzLnpvb20oKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRoaXMub25FbmQoKTtcbiAgICAgIH1cbiAgICAgIGRyYWdnaW5nID0gZmFsc2U7XG4gICAgfSk7XG5cbiAgICB0aGlzLl9kb3VibGVDbGlja0ludGVyYWN0aW9uLm9uRG91YmxlQ2xpY2sodGhpcy51bnpvb20uYmluZCh0aGlzKSk7XG4gIH1cblxuICAvKiBTZXQgdGhlIHRpbWUgKGluIG1zKSBvdmVyIHdoaWNoIHRoZSB6b29tIHdpbGwgaW50ZXJwb2xhdGUuXG4gICAqIDAgaW1wbGllcyBubyBpbnRlcnBvbGF0aW9uLiAoaWUgem9vbSBpcyBpbnN0YW50KVxuICAgKi9cbiAgcHVibGljIGFuaW1hdGlvblRpbWUoKTogbnVtYmVyO1xuICBwdWJsaWMgYW5pbWF0aW9uVGltZShhbmltYXRpb25UaW1lOiBudW1iZXIpOiBEcmFnWm9vbUxheWVyO1xuICBwdWJsaWMgYW5pbWF0aW9uVGltZShhbmltYXRpb25UaW1lPzogbnVtYmVyKTogYW55IHtcbiAgICBpZiAoYW5pbWF0aW9uVGltZSA9PSBudWxsKSB7XG4gICAgICByZXR1cm4gdGhpcy5fYW5pbWF0aW9uVGltZTtcbiAgICB9XG4gICAgaWYgKGFuaW1hdGlvblRpbWUgPCAwKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ2FuaW1hdGlvblRpbWUgY2Fubm90IGJlIG5lZ2F0aXZlJyk7XG4gICAgfVxuICAgIHRoaXMuX2FuaW1hdGlvblRpbWUgPSBhbmltYXRpb25UaW1lO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG5cbiAgLyoqXG4gICAqIFNldCB0aGUgZWFzaW5nIGZ1bmN0aW9uLCB3aGljaCBkZXRlcm1pbmVzIGhvdyB0aGUgem9vbSBpbnRlcnBvbGF0ZXNcbiAgICogb3ZlciB0aW1lLlxuICAgKi9cbiAgcHVibGljIGVhc2UoZm46ICh0OiBudW1iZXIpID0+IG51bWJlcik6IERyYWdab29tTGF5ZXIge1xuICAgIGlmICh0eXBlb2YoZm4pICE9PSAnZnVuY3Rpb24nKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ2Vhc2UgZnVuY3Rpb24gbXVzdCBiZSBhIGZ1bmN0aW9uJyk7XG4gICAgfVxuICAgIGlmIChmbigwKSAhPT0gMCB8fCBmbigxKSAhPT0gMSkge1xuICAgICAgUGxvdHRhYmxlLlV0aWxzLldpbmRvdy53YXJuKFxuICAgICAgICAgICdFYXNpbmcgZnVuY3Rpb24gZG9lcyBub3QgbWFpbnRhaW4gaW52YXJpYW50ICcgK1xuICAgICAgICAgICdmKDApPT0wICYmIGYoMSk9PTEuIEJhZCBiZWhhdmlvciBtYXkgcmVzdWx0LicpO1xuICAgIH1cbiAgICB0aGlzLmVhc2VGbiA9IGZuO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG5cbiAgLy8gWm9vbSBpbnRvIGV4dGVudCBvZiB0aGUgc2VsZWN0aW9uIGJveCBib3VuZHNcbiAgcHJpdmF0ZSB6b29tKCkge1xuICAgIGxldCB4MDogbnVtYmVyID0gdGhpcy54RXh0ZW50KClbMF0udmFsdWVPZigpO1xuICAgIGxldCB4MTogbnVtYmVyID0gdGhpcy54RXh0ZW50KClbMV0udmFsdWVPZigpO1xuICAgIGxldCB5MDogbnVtYmVyID0gdGhpcy55RXh0ZW50KClbMV0udmFsdWVPZigpO1xuICAgIGxldCB5MTogbnVtYmVyID0gdGhpcy55RXh0ZW50KClbMF0udmFsdWVPZigpO1xuXG4gICAgaWYgKHgwID09PSB4MSB8fCB5MCA9PT0geTEpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICB0aGlzLmludGVycG9sYXRlWm9vbSh4MCwgeDEsIHkwLCB5MSk7XG4gIH1cblxuICAvLyBSZXN0b3JlIHRoZSBzY2FsZXMgdG8gdGhlaXIgc3RhdGUgYmVmb3JlIGFueSB6b29tXG4gIHByaXZhdGUgdW56b29tKCkge1xuICAgIC8vIFdlIG5lZWQgdG8gcmVzZXQgdGhlIHpvb20gZG9tYWluIHVuY29uZGl0aW9uYWxseSwgYXMgdGhlIGRhdGEgb3IgdGhlXG4gICAgLy8gc21vb3RoaW5nIG1heSBoYXZlIHVwZGF0ZWQsIHN1Y2ggdGhhdCB3ZSBhcmUgbm90IGxvbmdlciBmdWxseSB6b29tZWQgb3V0LlxuICAgIGxldCB4U2NhbGUgPSB0aGlzLnhTY2FsZSgpIGFzIGFueTtcbiAgICB4U2NhbGUuX2RvbWFpbk1pbiA9IG51bGw7XG4gICAgeFNjYWxlLl9kb21haW5NYXggPSBudWxsO1xuICAgIGxldCB4RG9tYWluID0geFNjYWxlLl9nZXRFeHRlbnQoKTtcbiAgICB0aGlzLnhTY2FsZSgpLmRvbWFpbih4RG9tYWluKTtcbiAgICB0aGlzLnVuem9vbU1ldGhvZCgpO1xuICB9XG5cbiAgLy8gSWYgd2UgYXJlIHpvb21pbmcsIGRpc2FibGUgaW50ZXJhY3Rpb25zLCB0byBhdm9pZCBjb250ZW50aW9uXG4gIHByaXZhdGUgaXNab29taW5nKGlzWm9vbWluZzogYm9vbGVhbikge1xuICAgIHRoaXMuX2RyYWdJbnRlcmFjdGlvbi5lbmFibGVkKCFpc1pvb21pbmcpO1xuICAgIHRoaXMuX2RvdWJsZUNsaWNrSW50ZXJhY3Rpb24uZW5hYmxlZCghaXNab29taW5nKTtcbiAgfVxuXG4gIHByaXZhdGUgaW50ZXJwb2xhdGVab29tKHgwZjogbnVtYmVyLCB4MWY6IG51bWJlciwgeTBmOiBudW1iZXIsIHkxZjogbnVtYmVyKSB7XG4gICAgbGV0IHgwczogbnVtYmVyID0gdGhpcy54U2NhbGUoKS5kb21haW4oKVswXS52YWx1ZU9mKCk7XG4gICAgbGV0IHgxczogbnVtYmVyID0gdGhpcy54U2NhbGUoKS5kb21haW4oKVsxXS52YWx1ZU9mKCk7XG4gICAgbGV0IHkwczogbnVtYmVyID0gdGhpcy55U2NhbGUoKS5kb21haW4oKVswXS52YWx1ZU9mKCk7XG4gICAgbGV0IHkxczogbnVtYmVyID0gdGhpcy55U2NhbGUoKS5kb21haW4oKVsxXS52YWx1ZU9mKCk7XG5cbiAgICAvLyBDb3B5IGEgcmVmIHRvIHRoZSBlYXNlIGZuLCBzbyB0aGF0IGNoYW5naW5nIGVhc2Ugd29udCBhZmZlY3Qgem9vbXMgaW5cbiAgICAvLyBwcm9ncmVzcy5cbiAgICBsZXQgZWFzZSA9IHRoaXMuZWFzZUZuO1xuICAgIGxldCBpbnRlcnBvbGF0b3IgPSAoYTogbnVtYmVyLCBiOiBudW1iZXIsIHA6IG51bWJlcikgPT5cbiAgICAgICAgZDMuaW50ZXJwb2xhdGVOdW1iZXIoYSwgYikoZWFzZShwKSk7XG5cbiAgICB0aGlzLmlzWm9vbWluZyh0cnVlKTtcbiAgICBsZXQgc3RhcnQgPSBEYXRlLm5vdygpO1xuICAgIGxldCBkcmF3ID0gKCkgPT4ge1xuICAgICAgbGV0IG5vdyA9IERhdGUubm93KCk7XG4gICAgICBsZXQgcGFzc2VkID0gbm93IC0gc3RhcnQ7XG4gICAgICBsZXQgcCA9IHRoaXMuX2FuaW1hdGlvblRpbWUgPT09IDAgP1xuICAgICAgICAgIDEgOlxuICAgICAgICAgIE1hdGgubWluKDEsIHBhc3NlZCAvIHRoaXMuX2FuaW1hdGlvblRpbWUpO1xuICAgICAgbGV0IHgwID0gaW50ZXJwb2xhdG9yKHgwcywgeDBmLCBwKTtcbiAgICAgIGxldCB4MSA9IGludGVycG9sYXRvcih4MXMsIHgxZiwgcCk7XG4gICAgICBsZXQgeTAgPSBpbnRlcnBvbGF0b3IoeTBzLCB5MGYsIHApO1xuICAgICAgbGV0IHkxID0gaW50ZXJwb2xhdG9yKHkxcywgeTFmLCBwKTtcbiAgICAgIHRoaXMueFNjYWxlKCkuZG9tYWluKFt4MCwgeDFdKTtcbiAgICAgIHRoaXMueVNjYWxlKCkuZG9tYWluKFt5MCwgeTFdKTtcbiAgICAgIGlmIChwIDwgMSkge1xuICAgICAgICBQbG90dGFibGUuVXRpbHMuRE9NLnJlcXVlc3RBbmltYXRpb25GcmFtZVBvbHlmaWxsKGRyYXcpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhpcy5vbkVuZCgpO1xuICAgICAgICB0aGlzLmlzWm9vbWluZyhmYWxzZSk7XG4gICAgICB9XG4gICAgfTtcbiAgICBkcmF3KCk7XG4gIH1cbn1cblxufSAgLy8gbmFtZXNwYWNlIHZ6X2xpbmVfY2hhcnRcbiJdfQ==