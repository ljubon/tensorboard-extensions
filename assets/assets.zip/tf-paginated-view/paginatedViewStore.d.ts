declare namespace tf_paginated_view {
    type Listener = () => void;
    /**
     * Register a listener (nullary function) to be called when the page
     * limit changes.
     */
    function addLimitListener(listener: Listener): void;
    /**
     * Remove a listener registered with `addLimitListener`.
     */
    function removeLimitListener(listener: Listener): void;
    function getLimit(): number;
    function setLimit(limit: number): void;
}
