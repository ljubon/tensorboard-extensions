declare module tf.graph.scene {
    const SVG_NAMESPACE = "http://www.w3.org/2000/svg";
    /** Enums element class of objects in the scene */
    let Class: {
        Node: {
            CONTAINER: string;
            GROUP: string;
            SHAPE: string;
            COLOR_TARGET: string;
            LABEL: string;
            BUTTON_CONTAINER: string;
            BUTTON_CIRCLE: string;
            EXPAND_BUTTON: string;
            COLLAPSE_BUTTON: string;
        };
        Edge: {
            CONTAINER: string;
            GROUP: string;
            LINE: string;
            REFERENCE_EDGE: string;
            REF_LINE: string;
            SELECTABLE: string;
            SELECTED: string;
            STRUCTURAL: string;
        };
        Annotation: {
            OUTBOX: string;
            INBOX: string;
            GROUP: string;
            NODE: string;
            EDGE: string;
            CONTROL_EDGE: string;
            LABEL: string;
            ELLIPSIS: string;
        };
        Scene: {
            GROUP: string;
            CORE: string;
            FUNCTION_LIBRARY: string;
            INEXTRACT: string;
            OUTEXTRACT: string;
        };
        Subscene: {
            GROUP: string;
        };
        OPNODE: string;
        METANODE: string;
        SERIESNODE: string;
        BRIDGENODE: string;
        ELLIPSISNODE: string;
    };
    /**
     * A health pill encapsulates an overview of tensor element values. The value
     * field is a list of 12 numbers that shed light on the status of the tensor.
     * Visualized in health pills are the 3rd through 8th (inclusive) numbers of
     * health pill values. Those 6 numbers are counts of tensor elements that fall
     * under -Inf, negative, 0, positive, +Inf, NaN (in that order).
     *
     * Please keep this interface consistent with HealthPillDatum within
     * backend.ts.
     */
    interface HealthPill {
        device_name: string;
        node_name: string;
        output_slot: number;
        dtype: string;
        shape: number[];
        value: number[];
        wall_time: number;
        step: number;
    }
    /**
     * Encapsulates how to render a single entry in a health pill. Each entry
     * corresponds to a category of tensor element values.
     */
    interface HealthPillEntry {
        background_color: string;
        label: string;
    }
    let healthPillEntries: HealthPillEntry[];
    /**
     * Helper method for fitting the graph in the svg view.
     *
     * @param svg The main svg.
     * @param zoomG The svg group used for panning and zooming.
     * @param d3zoom The zoom behavior.
     * @param callback Called when the fitting is done.
     */
    function fit(svg: any, zoomG: any, d3zoom: any, callback: any): void;
    /**
     * Helper method for panning the graph to center on the provided node,
     * if the node is currently off-screen.
     *
     * @param nodeName The node to center the graph on
     * @param svg The root SVG element for the graph
     * @param zoomG The svg group used for panning and zooming.
     * @param d3zoom The zoom behavior.
     * @return True if the graph had to be panned to display the
     *            provided node.
     */
    function panToNode(nodeName: String, svg: any, zoomG: any, d3zoom: any): boolean;
    /**
     * Given a container d3 selection, select a child svg element of a given tag
     * and class if exists or append / insert one otherwise.  If multiple children
     * matches the tag and class name, returns only the first one.
     *
     * @param container
     * @param tagName tag name.
     * @param className (optional) Class name or a list of class names.
     * @param before (optional) reference DOM node for insertion.
     * @return selection of the element
     */
    function selectOrCreateChild(container: any, tagName: string, className?: string | string[], before?: any): d3.Selection<any, any, any, any>;
    /**
     * Given a container d3 selection, select a child element of a given tag and
     * class. If multiple children matches the tag and class name, returns only
     * the first one.
     *
     * @param container
     * @param tagName tag name.
     * @param className (optional) Class name or list of class names.
     * @return selection of the element, or an empty selection
     */
    function selectChild(container: any, tagName: string, className?: string | string[]): d3.Selection<any, any, any, any>;
    /**
     * Select or create a sceneGroup and build/update its nodes and edges.
     *
     * Structure Pattern:
     *
     * <g class='scene'>
     *   <g class='core'>
     *     <g class='edges'>
     *       ... stuff from tf.graph.scene.edges.build ...
     *     </g>
     *     <g class='nodes'>
     *       ... stuff from tf.graph.scene.nodes.build ...
     *     </g>
     *   </g>
     *   <g class='in-extract'>
     *     <g class='nodes'>
     *       ... stuff from tf.graph.scene.nodes.build ...
     *     </g>
     *   </g>
     *   <g class='out-extract'>
     *     <g class='nodes'>
     *       ... stuff from tf.graph.scene.nodes.build ...
     *     </g>
     *   </g>
     * </g>
     *
     * @param container D3 selection of the parent.
     * @param renderNode render node of a metanode or series node.
     * @param sceneElement <tf-graph-scene> polymer element.
     * @param sceneClass class attribute of the scene (default='scene').
     */
    function buildGroup(container: any, renderNode: render.RenderGroupNodeInfo, sceneElement: any, sceneClass: string): d3.Selection<any, any, any, any>;
    /** Adds a click listener to a group that fires a graph-select event */
    function addGraphClickListener(graphGroup: any, sceneElement: any): void;
    /** Helper for adding transform: translate(x0, y0) */
    function translate(selection: any, x0: number, y0: number): void;
    /**
     * Helper for setting position of a svg rect
     * @param rect A d3 selection of rect(s) to set position of.
     * @param cx Center x.
     * @param cy Center x.
     * @param width Width to set.
     * @param height Height to set.
     */
    function positionRect(rect: any, cx: number, cy: number, width: number, height: number): void;
    /**
     * Positions a triangle and sizes it.
     * @param polygon polygon to set position of.
     * @param cx Center x.
     * @param cy Center y.
     * @param width Width of bounding box for triangle.
     * @param height Height of bounding box for triangle.
     */
    function positionTriangle(polygon: any, cx: any, cy: any, width: any, height: any): void;
    /**
     * Helper for setting position of a svg expand/collapse button
     * @param button container group
     * @param renderNode the render node of the group node to position
     *        the button on.
     */
    function positionButton(button: any, renderNode: render.RenderNodeInfo): void;
    /**
     * Helper for setting position of a svg ellipse
     * @param ellipse ellipse to set position of.
     * @param cx Center x.
     * @param cy Center x.
     * @param width Width to set.
     * @param height Height to set.
     */
    function positionEllipse(ellipse: any, cx: number, cy: number, width: number, height: number): void;
    /**
     * @param {number} stat A stat for a health pill (such as mean or variance).
     * @param {boolean} shouldRoundOnesDigit Whether to round this number to the
     *     ones digit. Useful for say int, uint, and bool output types.
     * @return {string} A human-friendly string representation of that stat.
     */
    function humanizeHealthPillStat(stat: any, shouldRoundOnesDigit: any): any;
    /**
     * Renders a health pill for an op atop a node.
     * nodeGroupElement: The SVG element in which to render.
     * healthPill: A list of backend.HealthPill objects.
     * nodeInfo: Info on the associated node.
     * healthPillId: A unique numeric ID assigned to this health pill.
     * healthPillWidth: Optional width of the health pill.
     * healthPillHeight: Optional height of the health pill.
     * healthPillYOffset: Optional y-offset of the health pill (that is, the
     *   color-coded region).
     * textOffset: Optional value for the x-offset of the top text label
     *   relative to the left edge of the health pill. If not provided, will
     *   default to `healthPillWidth / 2`.
     */
    function addHealthPill(nodeGroupElement: SVGElement, healthPill: HealthPill, nodeInfo: render.RenderNodeInfo, healthPillId: number, healthPillWidth?: number, healthPillHeight?: number, healthPillYOffset?: number, textXOffset?: number): void;
    /**
     * Adds health pills (which visualize tensor summaries) to a graph group.
     * @param svgRoot The root SVG element of the graph to add heath pills to.
     * @param nodeNamesToHealthPills An object mapping node name to health pill.
     * @param colors A list of colors to use.
     */
    function addHealthPills(svgRoot: SVGElement, nodeNamesToHealthPills: {
        [key: string]: HealthPill[];
    }, healthPillStepIndex: number): void;
}
