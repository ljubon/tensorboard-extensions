var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
/* Copyright 2017 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
var tf_backend;
(function (tf_backend) {
    var RunsStore = /** @class */ (function (_super) {
        __extends(RunsStore, _super);
        function RunsStore() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this._runs = [];
            return _this;
        }
        RunsStore.prototype.load = function () {
            var _this = this;
            var url = tf_backend.getRouter().runs();
            return this.requestManager.request(url).then(function (newRuns) {
                if (!_.isEqual(_this._runs, newRuns)) {
                    _this._runs = newRuns;
                    _this.emitChange();
                }
            });
        };
        /**
         * Get the current list of runs. If no data is available, this will be
         * an empty array (i.e., there is no distinction between "no runs" and
         * "no runs yet").
         */
        RunsStore.prototype.getRuns = function () {
            return this._runs.slice();
        };
        return RunsStore;
    }(tf_backend.BaseStore));
    tf_backend.RunsStore = RunsStore;
    tf_backend.runsStore = new RunsStore();
})(tf_backend || (tf_backend = {})); // namespace tf_backend
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicnVuc1N0b3JlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsicnVuc1N0b3JlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7QUFBQTs7Ozs7Ozs7Ozs7OztnRkFhZ0Y7QUFDaEYsSUFBVSxVQUFVLENBMkJuQjtBQTNCRCxXQUFVLFVBQVU7SUFFcEI7UUFBK0IsNkJBQVM7UUFBeEM7WUFBQSxxRUFxQkM7WUFwQlMsV0FBSyxHQUFhLEVBQUUsQ0FBQzs7UUFvQi9CLENBQUM7UUFsQkMsd0JBQUksR0FBSjtZQUFBLGlCQVFDO1lBUEMsSUFBTSxHQUFHLEdBQUcsV0FBQSxTQUFTLEVBQUUsQ0FBQyxJQUFJLEVBQUUsQ0FBQztZQUMvQixPQUFPLElBQUksQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFBLE9BQU87Z0JBQ2xELElBQUksQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUksQ0FBQyxLQUFLLEVBQUUsT0FBTyxDQUFDLEVBQUU7b0JBQ25DLEtBQUksQ0FBQyxLQUFLLEdBQUcsT0FBTyxDQUFDO29CQUNyQixLQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7aUJBQ25CO1lBQ0gsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDO1FBRUQ7Ozs7V0FJRztRQUNILDJCQUFPLEdBQVA7WUFDRSxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxFQUFFLENBQUM7UUFDNUIsQ0FBQztRQUNILGdCQUFDO0lBQUQsQ0FBQyxBQXJCRCxDQUErQixXQUFBLFNBQVMsR0FxQnZDO0lBckJZLG9CQUFTLFlBcUJyQixDQUFBO0lBRVksb0JBQVMsR0FBRyxJQUFJLFNBQVMsRUFBRSxDQUFDO0FBRXpDLENBQUMsRUEzQlMsVUFBVSxLQUFWLFVBQVUsUUEyQm5CLENBQUUsdUJBQXVCIiwic291cmNlc0NvbnRlbnQiOlsiLyogQ29weXJpZ2h0IDIwMTcgVGhlIFRlbnNvckZsb3cgQXV0aG9ycy4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cblxuTGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlLCBWZXJzaW9uIDIuMCAodGhlIFwiTGljZW5zZVwiKTtcbnlvdSBtYXkgbm90IHVzZSB0aGlzIGZpbGUgZXhjZXB0IGluIGNvbXBsaWFuY2Ugd2l0aCB0aGUgTGljZW5zZS5cbllvdSBtYXkgb2J0YWluIGEgY29weSBvZiB0aGUgTGljZW5zZSBhdFxuXG4gICAgaHR0cDovL3d3dy5hcGFjaGUub3JnL2xpY2Vuc2VzL0xJQ0VOU0UtMi4wXG5cblVubGVzcyByZXF1aXJlZCBieSBhcHBsaWNhYmxlIGxhdyBvciBhZ3JlZWQgdG8gaW4gd3JpdGluZywgc29mdHdhcmVcbmRpc3RyaWJ1dGVkIHVuZGVyIHRoZSBMaWNlbnNlIGlzIGRpc3RyaWJ1dGVkIG9uIGFuIFwiQVMgSVNcIiBCQVNJUyxcbldJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWSBLSU5ELCBlaXRoZXIgZXhwcmVzcyBvciBpbXBsaWVkLlxuU2VlIHRoZSBMaWNlbnNlIGZvciB0aGUgc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nIHBlcm1pc3Npb25zIGFuZFxubGltaXRhdGlvbnMgdW5kZXIgdGhlIExpY2Vuc2UuXG49PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0qL1xubmFtZXNwYWNlIHRmX2JhY2tlbmQge1xuXG5leHBvcnQgY2xhc3MgUnVuc1N0b3JlIGV4dGVuZHMgQmFzZVN0b3JlIHtcbiAgcHJpdmF0ZSBfcnVuczogc3RyaW5nW10gPSBbXTtcblxuICBsb2FkKCkge1xuICAgIGNvbnN0IHVybCA9IGdldFJvdXRlcigpLnJ1bnMoKTtcbiAgICByZXR1cm4gdGhpcy5yZXF1ZXN0TWFuYWdlci5yZXF1ZXN0KHVybCkudGhlbihuZXdSdW5zID0+IHtcbiAgICAgIGlmICghXy5pc0VxdWFsKHRoaXMuX3J1bnMsIG5ld1J1bnMpKSB7XG4gICAgICAgIHRoaXMuX3J1bnMgPSBuZXdSdW5zO1xuICAgICAgICB0aGlzLmVtaXRDaGFuZ2UoKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBHZXQgdGhlIGN1cnJlbnQgbGlzdCBvZiBydW5zLiBJZiBubyBkYXRhIGlzIGF2YWlsYWJsZSwgdGhpcyB3aWxsIGJlXG4gICAqIGFuIGVtcHR5IGFycmF5IChpLmUuLCB0aGVyZSBpcyBubyBkaXN0aW5jdGlvbiBiZXR3ZWVuIFwibm8gcnVuc1wiIGFuZFxuICAgKiBcIm5vIHJ1bnMgeWV0XCIpLlxuICAgKi9cbiAgZ2V0UnVucygpOiBzdHJpbmdbXSB7XG4gICAgcmV0dXJuIHRoaXMuX3J1bnMuc2xpY2UoKTtcbiAgfVxufVxuXG5leHBvcnQgY29uc3QgcnVuc1N0b3JlID0gbmV3IFJ1bnNTdG9yZSgpO1xuXG59ICAvLyBuYW1lc3BhY2UgdGZfYmFja2VuZFxuIl19