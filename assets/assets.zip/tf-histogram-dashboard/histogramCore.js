/* Copyright 2015 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
var tf_histogram_dashboard;
(function (tf_histogram_dashboard) {
    function backendToIntermediate(histogram) {
        var wall_time = histogram[0], step = histogram[1], buckets = histogram[2];
        return {
            wall_time: wall_time,
            step: step,
            min: d3.min(buckets.map(function (_a) {
                var left = _a[0];
                return left;
            })),
            max: d3.max(buckets.map(function (_a) {
                var right = _a[1];
                return right;
            })),
            buckets: buckets.map(function (_a) {
                var left = _a[0], right = _a[1], count = _a[2];
                return ({ left: left, right: right, count: count });
            }),
        };
    }
    tf_histogram_dashboard.backendToIntermediate = backendToIntermediate;
    /**
     * Convert histogram data to the standard D3 format to make it more
     * compatible and easier to visualize. When rendering histograms, having
     * access to the left edge and width of each bin makes things quite a
     * bit easier, so we include these in the result. We also convert the
     * bins to have a uniform width, which makes the visualization easier to
     * understand.
     *
     * @param histogram
     * @param min The leftmost edge. The binning will start on it.
     * @param max The rightmost edge. The binning will end on it.
     * @param numBins The number of bins of the converted data. The default
     * of 30 is sensible: if you use more, you start to get artifacts
     * because the event data is stored in buckets, and you start being able
     * to see the aliased borders between each bucket.
     *
     * @return A list of histogram bins. Each bin has an `x` (left
     *     edge), a `dx` (width), and a `y` (count). If the given
     *     right edges are inclusive, then these left edges (`x`) are
     *     exclusive.
     */
    function intermediateToD3(histogram, min, max, numBins) {
        if (numBins === void 0) { numBins = 30; }
        if (max === min) {
            // Create bins even if all the data has a single value.
            max = min * 1.1 + 1;
            min = min / 1.1 - 1;
        }
        // Terminology note: _buckets_ are the input to this function,
        // while _bins_ are our output.
        var binWidth = (max - min) / numBins;
        var bucketIndex = 0;
        return d3.range(min, max, binWidth).map(function (binLeft) {
            var binRight = binLeft + binWidth;
            // Take the count of each existing bucket, multiply it by the
            // proportion of overlap with the new bin, then sum and store as the
            // count for the new bin. If no overlap, will add to zero; if 100%
            // overlap, will include the full count into new bin.
            var binY = 0;
            while (bucketIndex < histogram.buckets.length) {
                // Clip the right edge because right-most edge can be
                // infinite-sized.
                var bucketRight = Math.min(max, histogram.buckets[bucketIndex].right);
                var bucketLeft = Math.max(min, histogram.buckets[bucketIndex].left);
                var intersect = Math.min(bucketRight, binRight) - Math.max(bucketLeft, binLeft);
                var count = (intersect / (bucketRight - bucketLeft)) *
                    histogram.buckets[bucketIndex].count;
                binY += intersect > 0 ? count : 0;
                // If `bucketRight` is bigger than `binRight`, then this bin is
                // finished and there is data for the next bin, so don't increment
                // `bucketIndex`.
                if (bucketRight > binRight) {
                    break;
                }
                bucketIndex++;
            }
            return { x: binLeft, dx: binWidth, y: binY };
        });
    }
    tf_histogram_dashboard.intermediateToD3 = intermediateToD3;
    function backendToVz(histograms) {
        var intermediateHistograms = histograms.map(backendToIntermediate);
        var minmin = d3.min(intermediateHistograms, function (h) { return h.min; });
        var maxmax = d3.max(intermediateHistograms, function (h) { return h.max; });
        return intermediateHistograms.map(function (h) { return ({
            wall_time: h.wall_time,
            step: h.step,
            bins: intermediateToD3(h, minmin, maxmax),
        }); });
    }
    tf_histogram_dashboard.backendToVz = backendToVz;
})(tf_histogram_dashboard || (tf_histogram_dashboard = {})); // namespace tf_histogram_dashboard
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaGlzdG9ncmFtQ29yZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImhpc3RvZ3JhbUNvcmUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7Ozs7Ozs7Z0ZBYWdGO0FBQ2hGLElBQVUsc0JBQXNCLENBcUkvQjtBQXJJRCxXQUFVLHNCQUFzQjtJQTBDaEMsK0JBQXNDLFNBQTJCO1FBRXhELElBQUEsd0JBQVMsRUFBRSxtQkFBSSxFQUFFLHNCQUFPLENBQWM7UUFDN0MsT0FBTztZQUNMLFNBQVMsV0FBQTtZQUNULElBQUksTUFBQTtZQUNKLEdBQUcsRUFBRSxFQUFFLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsVUFBQyxFQUFVO29CQUFULFlBQUk7Z0JBQVUsT0FBQSxJQUFJO1lBQUosQ0FBSSxDQUFDLENBQUM7WUFDOUMsR0FBRyxFQUFFLEVBQUUsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxVQUFDLEVBQVc7b0JBQVIsYUFBSztnQkFBUSxPQUFBLEtBQUs7WUFBTCxDQUFLLENBQUMsQ0FBQztZQUNoRCxPQUFPLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxVQUFDLEVBQW9CO29CQUFuQixZQUFJLEVBQUUsYUFBSyxFQUFFLGFBQUs7Z0JBQU0sT0FBQSxDQUFDLEVBQUMsSUFBSSxNQUFBLEVBQUUsS0FBSyxPQUFBLEVBQUUsS0FBSyxPQUFBLEVBQUMsQ0FBQztZQUF0QixDQUFzQixDQUFDO1NBQ3ZFLENBQUM7SUFDSixDQUFDO0lBVmUsNENBQXFCLHdCQVVwQyxDQUFBO0lBRUQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O09Bb0JHO0lBQ0gsMEJBQ0ksU0FBZ0MsRUFBRSxHQUFXLEVBQUUsR0FBVyxFQUMxRCxPQUFZO1FBQVosd0JBQUEsRUFBQSxZQUFZO1FBQ2QsSUFBSSxHQUFHLEtBQUssR0FBRyxFQUFFO1lBQ2YsdURBQXVEO1lBQ3ZELEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLENBQUMsQ0FBQztZQUNwQixHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxDQUFDLENBQUM7U0FDckI7UUFFRCw4REFBOEQ7UUFDOUQsK0JBQStCO1FBQy9CLElBQU0sUUFBUSxHQUFHLENBQUMsR0FBRyxHQUFHLEdBQUcsQ0FBQyxHQUFHLE9BQU8sQ0FBQztRQUV2QyxJQUFJLFdBQVcsR0FBRyxDQUFDLENBQUM7UUFDcEIsT0FBTyxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsUUFBUSxDQUFDLENBQUMsR0FBRyxDQUFDLFVBQUMsT0FBTztZQUM5QyxJQUFNLFFBQVEsR0FBRyxPQUFPLEdBQUcsUUFBUSxDQUFDO1lBRXBDLDZEQUE2RDtZQUM3RCxvRUFBb0U7WUFDcEUsa0VBQWtFO1lBQ2xFLHFEQUFxRDtZQUNyRCxJQUFJLElBQUksR0FBRyxDQUFDLENBQUM7WUFDYixPQUFPLFdBQVcsR0FBRyxTQUFTLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRTtnQkFDN0MscURBQXFEO2dCQUNyRCxrQkFBa0I7Z0JBQ2xCLElBQU0sV0FBVyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFFLFNBQVMsQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQ3hFLElBQU0sVUFBVSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFFLFNBQVMsQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7Z0JBRXRFLElBQU0sU0FBUyxHQUNYLElBQUksQ0FBQyxHQUFHLENBQUMsV0FBVyxFQUFFLFFBQVEsQ0FBQyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsVUFBVSxFQUFFLE9BQU8sQ0FBQyxDQUFDO2dCQUNwRSxJQUFNLEtBQUssR0FBRyxDQUFDLFNBQVMsR0FBRyxDQUFDLFdBQVcsR0FBRyxVQUFVLENBQUMsQ0FBQztvQkFDbEQsU0FBUyxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsQ0FBQyxLQUFLLENBQUM7Z0JBRXpDLElBQUksSUFBSSxTQUFTLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFFbEMsK0RBQStEO2dCQUMvRCxrRUFBa0U7Z0JBQ2xFLGlCQUFpQjtnQkFDakIsSUFBSSxXQUFXLEdBQUcsUUFBUSxFQUFFO29CQUMxQixNQUFNO2lCQUNQO2dCQUNELFdBQVcsRUFBRSxDQUFDO2FBQ2Y7WUFDRCxPQUFPLEVBQUMsQ0FBQyxFQUFFLE9BQU8sRUFBRSxFQUFFLEVBQUUsUUFBUSxFQUFFLENBQUMsRUFBRSxJQUFJLEVBQUMsQ0FBQztRQUM3QyxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUE3Q2UsdUNBQWdCLG1CQTZDL0IsQ0FBQTtJQUVELHFCQUE0QixVQUE4QjtRQUN4RCxJQUFNLHNCQUFzQixHQUFHLFVBQVUsQ0FBQyxHQUFHLENBQUMscUJBQXFCLENBQUMsQ0FBQztRQUNyRSxJQUFNLE1BQU0sR0FBRyxFQUFFLENBQUMsR0FBRyxDQUFDLHNCQUFzQixFQUFFLFVBQUEsQ0FBQyxJQUFJLE9BQUEsQ0FBQyxDQUFDLEdBQUcsRUFBTCxDQUFLLENBQUMsQ0FBQztRQUMxRCxJQUFNLE1BQU0sR0FBRyxFQUFFLENBQUMsR0FBRyxDQUFDLHNCQUFzQixFQUFFLFVBQUEsQ0FBQyxJQUFJLE9BQUEsQ0FBQyxDQUFDLEdBQUcsRUFBTCxDQUFLLENBQUMsQ0FBQztRQUMxRCxPQUFPLHNCQUFzQixDQUFDLEdBQUcsQ0FBQyxVQUFBLENBQUMsSUFBSSxPQUFBLENBQUM7WUFDdEMsU0FBUyxFQUFFLENBQUMsQ0FBQyxTQUFTO1lBQ3RCLElBQUksRUFBRSxDQUFDLENBQUMsSUFBSTtZQUNaLElBQUksRUFBRSxnQkFBZ0IsQ0FBQyxDQUFDLEVBQUUsTUFBTSxFQUFFLE1BQU0sQ0FBQztTQUMxQyxDQUFDLEVBSnFDLENBSXJDLENBQUMsQ0FBQztJQUNOLENBQUM7SUFUZSxrQ0FBVyxjQVMxQixDQUFBO0FBRUQsQ0FBQyxFQXJJUyxzQkFBc0IsS0FBdEIsc0JBQXNCLFFBcUkvQixDQUFFLG1DQUFtQyIsInNvdXJjZXNDb250ZW50IjpbIi8qIENvcHlyaWdodCAyMDE1IFRoZSBUZW5zb3JGbG93IEF1dGhvcnMuIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG5cbkxpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSBcIkxpY2Vuc2VcIik7XG55b3UgbWF5IG5vdCB1c2UgdGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlIHdpdGggdGhlIExpY2Vuc2UuXG5Zb3UgbWF5IG9idGFpbiBhIGNvcHkgb2YgdGhlIExpY2Vuc2UgYXRcblxuICAgIGh0dHA6Ly93d3cuYXBhY2hlLm9yZy9saWNlbnNlcy9MSUNFTlNFLTIuMFxuXG5Vbmxlc3MgcmVxdWlyZWQgYnkgYXBwbGljYWJsZSBsYXcgb3IgYWdyZWVkIHRvIGluIHdyaXRpbmcsIHNvZnR3YXJlXG5kaXN0cmlidXRlZCB1bmRlciB0aGUgTGljZW5zZSBpcyBkaXN0cmlidXRlZCBvbiBhbiBcIkFTIElTXCIgQkFTSVMsXG5XSVRIT1VUIFdBUlJBTlRJRVMgT1IgQ09ORElUSU9OUyBPRiBBTlkgS0lORCwgZWl0aGVyIGV4cHJlc3Mgb3IgaW1wbGllZC5cblNlZSB0aGUgTGljZW5zZSBmb3IgdGhlIHNwZWNpZmljIGxhbmd1YWdlIGdvdmVybmluZyBwZXJtaXNzaW9ucyBhbmRcbmxpbWl0YXRpb25zIHVuZGVyIHRoZSBMaWNlbnNlLlxuPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09Ki9cbm5hbWVzcGFjZSB0Zl9oaXN0b2dyYW1fZGFzaGJvYXJkIHtcblxuLyoqXG4gKiBGdW5jdGlvbnMgZm9yIGNvbnZlcnRpbmcgYmV0d2VlbiB0aGUgZGlmZmVyZW50IHJlcHJlc2VudGF0aW9ucyBvZlxuICogaGlzdG9ncmFtcy5cbiAqL1xuZXhwb3J0IHR5cGUgQmFja2VuZEhpc3RvZ3JhbUJpbiA9IFtcbiAgbnVtYmVyLCAgLy8gbGVmdFxuICBudW1iZXIsICAvLyByaWdodFxuICBudW1iZXIgICAvLyBjb3VudFxuXTtcblxuZXhwb3J0IHR5cGUgQmFja2VuZEhpc3RvZ3JhbSA9IFtcbiAgbnVtYmVyLCAgLy8gd2FsbF90aW1lLCBpbiBzZWNvbmRzXG4gIG51bWJlciwgIC8vIHN0ZXBcbiAgQmFja2VuZEhpc3RvZ3JhbUJpbltdXG5dO1xuXG5leHBvcnQgdHlwZSBJbnRlcm1lZGlhdGVIaXN0b2dyYW0gPSB7XG4gIHdhbGxfdGltZTogbnVtYmVyLCAgLy8gaW4gc2Vjb25kc1xuICBzdGVwOiBudW1iZXIsXG4gIG1pbjogbnVtYmVyLFxuICBtYXg6IG51bWJlcixcbiAgYnVja2V0czoge1xuICAgIGxlZnQ6IG51bWJlcixcbiAgICByaWdodDogbnVtYmVyLFxuICAgIGNvdW50OiBudW1iZXIsXG4gIH1bXSxcbn07XG5cbmV4cG9ydCB0eXBlIEQzSGlzdG9ncmFtQmluID0ge1xuICB4OiBudW1iZXIsXG4gIGR4OiBudW1iZXIsXG4gIHk6IG51bWJlcixcbn07XG5cbmV4cG9ydCB0eXBlIFZ6SGlzdG9ncmFtID0ge1xuICB3YWxsX3RpbWU6IG51bWJlciwgIC8vIGluIHNlY29uZHNcbiAgc3RlcDogbnVtYmVyLFxuICBiaW5zOiBEM0hpc3RvZ3JhbUJpbltdLFxufTtcblxuZXhwb3J0IGZ1bmN0aW9uIGJhY2tlbmRUb0ludGVybWVkaWF0ZShoaXN0b2dyYW06IEJhY2tlbmRIaXN0b2dyYW0pOlxuICAgIEludGVybWVkaWF0ZUhpc3RvZ3JhbSB7XG4gIGNvbnN0IFt3YWxsX3RpbWUsIHN0ZXAsIGJ1Y2tldHNdID0gaGlzdG9ncmFtO1xuICByZXR1cm4ge1xuICAgIHdhbGxfdGltZSxcbiAgICBzdGVwLFxuICAgIG1pbjogZDMubWluKGJ1Y2tldHMubWFwKChbbGVmdCwgLCBdKSA9PiBsZWZ0KSksXG4gICAgbWF4OiBkMy5tYXgoYnVja2V0cy5tYXAoKFssIHJpZ2h0LCBdKSA9PiByaWdodCkpLFxuICAgIGJ1Y2tldHM6IGJ1Y2tldHMubWFwKChbbGVmdCwgcmlnaHQsIGNvdW50XSkgPT4gKHtsZWZ0LCByaWdodCwgY291bnR9KSksXG4gIH07XG59XG5cbi8qKlxuICogQ29udmVydCBoaXN0b2dyYW0gZGF0YSB0byB0aGUgc3RhbmRhcmQgRDMgZm9ybWF0IHRvIG1ha2UgaXQgbW9yZVxuICogY29tcGF0aWJsZSBhbmQgZWFzaWVyIHRvIHZpc3VhbGl6ZS4gV2hlbiByZW5kZXJpbmcgaGlzdG9ncmFtcywgaGF2aW5nXG4gKiBhY2Nlc3MgdG8gdGhlIGxlZnQgZWRnZSBhbmQgd2lkdGggb2YgZWFjaCBiaW4gbWFrZXMgdGhpbmdzIHF1aXRlIGFcbiAqIGJpdCBlYXNpZXIsIHNvIHdlIGluY2x1ZGUgdGhlc2UgaW4gdGhlIHJlc3VsdC4gV2UgYWxzbyBjb252ZXJ0IHRoZVxuICogYmlucyB0byBoYXZlIGEgdW5pZm9ybSB3aWR0aCwgd2hpY2ggbWFrZXMgdGhlIHZpc3VhbGl6YXRpb24gZWFzaWVyIHRvXG4gKiB1bmRlcnN0YW5kLlxuICpcbiAqIEBwYXJhbSBoaXN0b2dyYW1cbiAqIEBwYXJhbSBtaW4gVGhlIGxlZnRtb3N0IGVkZ2UuIFRoZSBiaW5uaW5nIHdpbGwgc3RhcnQgb24gaXQuXG4gKiBAcGFyYW0gbWF4IFRoZSByaWdodG1vc3QgZWRnZS4gVGhlIGJpbm5pbmcgd2lsbCBlbmQgb24gaXQuXG4gKiBAcGFyYW0gbnVtQmlucyBUaGUgbnVtYmVyIG9mIGJpbnMgb2YgdGhlIGNvbnZlcnRlZCBkYXRhLiBUaGUgZGVmYXVsdFxuICogb2YgMzAgaXMgc2Vuc2libGU6IGlmIHlvdSB1c2UgbW9yZSwgeW91IHN0YXJ0IHRvIGdldCBhcnRpZmFjdHNcbiAqIGJlY2F1c2UgdGhlIGV2ZW50IGRhdGEgaXMgc3RvcmVkIGluIGJ1Y2tldHMsIGFuZCB5b3Ugc3RhcnQgYmVpbmcgYWJsZVxuICogdG8gc2VlIHRoZSBhbGlhc2VkIGJvcmRlcnMgYmV0d2VlbiBlYWNoIGJ1Y2tldC5cbiAqXG4gKiBAcmV0dXJuIEEgbGlzdCBvZiBoaXN0b2dyYW0gYmlucy4gRWFjaCBiaW4gaGFzIGFuIGB4YCAobGVmdFxuICogICAgIGVkZ2UpLCBhIGBkeGAgKHdpZHRoKSwgYW5kIGEgYHlgIChjb3VudCkuIElmIHRoZSBnaXZlblxuICogICAgIHJpZ2h0IGVkZ2VzIGFyZSBpbmNsdXNpdmUsIHRoZW4gdGhlc2UgbGVmdCBlZGdlcyAoYHhgKSBhcmVcbiAqICAgICBleGNsdXNpdmUuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBpbnRlcm1lZGlhdGVUb0QzKFxuICAgIGhpc3RvZ3JhbTogSW50ZXJtZWRpYXRlSGlzdG9ncmFtLCBtaW46IG51bWJlciwgbWF4OiBudW1iZXIsXG4gICAgbnVtQmlucyA9IDMwKTogRDNIaXN0b2dyYW1CaW5bXSB7XG4gIGlmIChtYXggPT09IG1pbikge1xuICAgIC8vIENyZWF0ZSBiaW5zIGV2ZW4gaWYgYWxsIHRoZSBkYXRhIGhhcyBhIHNpbmdsZSB2YWx1ZS5cbiAgICBtYXggPSBtaW4gKiAxLjEgKyAxO1xuICAgIG1pbiA9IG1pbiAvIDEuMSAtIDE7XG4gIH1cblxuICAvLyBUZXJtaW5vbG9neSBub3RlOiBfYnVja2V0c18gYXJlIHRoZSBpbnB1dCB0byB0aGlzIGZ1bmN0aW9uLFxuICAvLyB3aGlsZSBfYmluc18gYXJlIG91ciBvdXRwdXQuXG4gIGNvbnN0IGJpbldpZHRoID0gKG1heCAtIG1pbikgLyBudW1CaW5zO1xuXG4gIGxldCBidWNrZXRJbmRleCA9IDA7XG4gIHJldHVybiBkMy5yYW5nZShtaW4sIG1heCwgYmluV2lkdGgpLm1hcCgoYmluTGVmdCkgPT4ge1xuICAgIGNvbnN0IGJpblJpZ2h0ID0gYmluTGVmdCArIGJpbldpZHRoO1xuXG4gICAgLy8gVGFrZSB0aGUgY291bnQgb2YgZWFjaCBleGlzdGluZyBidWNrZXQsIG11bHRpcGx5IGl0IGJ5IHRoZVxuICAgIC8vIHByb3BvcnRpb24gb2Ygb3ZlcmxhcCB3aXRoIHRoZSBuZXcgYmluLCB0aGVuIHN1bSBhbmQgc3RvcmUgYXMgdGhlXG4gICAgLy8gY291bnQgZm9yIHRoZSBuZXcgYmluLiBJZiBubyBvdmVybGFwLCB3aWxsIGFkZCB0byB6ZXJvOyBpZiAxMDAlXG4gICAgLy8gb3ZlcmxhcCwgd2lsbCBpbmNsdWRlIHRoZSBmdWxsIGNvdW50IGludG8gbmV3IGJpbi5cbiAgICBsZXQgYmluWSA9IDA7XG4gICAgd2hpbGUgKGJ1Y2tldEluZGV4IDwgaGlzdG9ncmFtLmJ1Y2tldHMubGVuZ3RoKSB7XG4gICAgICAvLyBDbGlwIHRoZSByaWdodCBlZGdlIGJlY2F1c2UgcmlnaHQtbW9zdCBlZGdlIGNhbiBiZVxuICAgICAgLy8gaW5maW5pdGUtc2l6ZWQuXG4gICAgICBjb25zdCBidWNrZXRSaWdodCA9IE1hdGgubWluKG1heCwgaGlzdG9ncmFtLmJ1Y2tldHNbYnVja2V0SW5kZXhdLnJpZ2h0KTtcbiAgICAgIGNvbnN0IGJ1Y2tldExlZnQgPSBNYXRoLm1heChtaW4sIGhpc3RvZ3JhbS5idWNrZXRzW2J1Y2tldEluZGV4XS5sZWZ0KTtcblxuICAgICAgY29uc3QgaW50ZXJzZWN0ID1cbiAgICAgICAgICBNYXRoLm1pbihidWNrZXRSaWdodCwgYmluUmlnaHQpIC0gTWF0aC5tYXgoYnVja2V0TGVmdCwgYmluTGVmdCk7XG4gICAgICBjb25zdCBjb3VudCA9IChpbnRlcnNlY3QgLyAoYnVja2V0UmlnaHQgLSBidWNrZXRMZWZ0KSkgKlxuICAgICAgICAgIGhpc3RvZ3JhbS5idWNrZXRzW2J1Y2tldEluZGV4XS5jb3VudDtcblxuICAgICAgYmluWSArPSBpbnRlcnNlY3QgPiAwID8gY291bnQgOiAwO1xuXG4gICAgICAvLyBJZiBgYnVja2V0UmlnaHRgIGlzIGJpZ2dlciB0aGFuIGBiaW5SaWdodGAsIHRoZW4gdGhpcyBiaW4gaXNcbiAgICAgIC8vIGZpbmlzaGVkIGFuZCB0aGVyZSBpcyBkYXRhIGZvciB0aGUgbmV4dCBiaW4sIHNvIGRvbid0IGluY3JlbWVudFxuICAgICAgLy8gYGJ1Y2tldEluZGV4YC5cbiAgICAgIGlmIChidWNrZXRSaWdodCA+IGJpblJpZ2h0KSB7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgICAgYnVja2V0SW5kZXgrKztcbiAgICB9XG4gICAgcmV0dXJuIHt4OiBiaW5MZWZ0LCBkeDogYmluV2lkdGgsIHk6IGJpbll9O1xuICB9KTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGJhY2tlbmRUb1Z6KGhpc3RvZ3JhbXM6IEJhY2tlbmRIaXN0b2dyYW1bXSk6IFZ6SGlzdG9ncmFtW10ge1xuICBjb25zdCBpbnRlcm1lZGlhdGVIaXN0b2dyYW1zID0gaGlzdG9ncmFtcy5tYXAoYmFja2VuZFRvSW50ZXJtZWRpYXRlKTtcbiAgY29uc3QgbWlubWluID0gZDMubWluKGludGVybWVkaWF0ZUhpc3RvZ3JhbXMsIGggPT4gaC5taW4pO1xuICBjb25zdCBtYXhtYXggPSBkMy5tYXgoaW50ZXJtZWRpYXRlSGlzdG9ncmFtcywgaCA9PiBoLm1heCk7XG4gIHJldHVybiBpbnRlcm1lZGlhdGVIaXN0b2dyYW1zLm1hcChoID0+ICh7XG4gICAgd2FsbF90aW1lOiBoLndhbGxfdGltZSxcbiAgICBzdGVwOiBoLnN0ZXAsXG4gICAgYmluczogaW50ZXJtZWRpYXRlVG9EMyhoLCBtaW5taW4sIG1heG1heCksXG4gIH0pKTtcbn1cblxufSAgLy8gbmFtZXNwYWNlIHRmX2hpc3RvZ3JhbV9kYXNoYm9hcmRcbiJdfQ==