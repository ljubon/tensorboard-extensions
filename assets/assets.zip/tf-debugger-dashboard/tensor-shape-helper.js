/* Copyright 2017 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the 'License');
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an 'AS IS' BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
var tf_debugger_dashboard;
(function (tf_debugger_dashboard) {
    var maxElements1D = 1000;
    var maxElements2D = 250;
    /**
     * Get a Python-style slicing string representing strided slicing.
     * @param size Total size along the dimension being sliced.
     * @param maxElements Maximum number of elements allowed in the slicing result.
     * @returns A Python-style slicing string beginning with two colons, without
     *   surrounding brackets.
     */
    function getStridedSlicing(size, maxElements) {
        if (size <= maxElements) {
            return '::';
        }
        else {
            return '::' + Math.ceil(size / maxElements);
        }
    }
    /**
     * Get the default slicing given a tensor shape.
     * @param shape: The tensor shape, represented as an Array of number.
     * @return: Numpy-style slicing string, with the surrounding brackets, e.g.,
     *   '[::2, 0:10]'.
     */
    function getDefaultSlicing(shape) {
        if (shape.length === 0) {
            // Scalar: no slicing.
            return '';
        }
        else if (shape.length === 1) {
            return '[' + getStridedSlicing(shape[0], maxElements1D) + ']';
        }
        else if (shape.length === 2) {
            return '[' + getStridedSlicing(shape[0], maxElements2D) + ', ' +
                getStridedSlicing(shape[1], maxElements2D) + ']';
        }
        else if (shape.length === 3) {
            return '[0, ' + getStridedSlicing(shape[1], maxElements2D) + ', ' +
                getStridedSlicing(shape[2], maxElements2D) + ']';
        }
        else if (shape.length === 4) {
            // Assume NHWC as the default.
            return '[0, ' + getStridedSlicing(shape[1], maxElements2D) + ', ' +
                getStridedSlicing(shape[2], maxElements2D) + ', 0]';
        }
        else {
            var slicing = '[';
            for (var i = 0; i < shape.length; ++i) {
                if (i < shape.length - 2) {
                    slicing += '0';
                }
                else {
                    slicing += getStridedSlicing(shape[i], maxElements2D);
                }
                if (i < shape.length - 1) {
                    slicing += ', ';
                }
            }
            slicing += ']';
            return slicing;
        }
    }
    tf_debugger_dashboard.getDefaultSlicing = getDefaultSlicing;
    /**
     * Determine rank of a slicing string.
     * @param slicing The slicing string.
     * @return The rank.
     */
    function rankFromSlicing(slicing) {
        if (slicing.startsWith('[')) {
            slicing = slicing.slice(1, slicing.length - 1);
        }
        if (slicing.length === 0) {
            // Scalar: no slicing.
            return 0;
        }
        else {
            var slicingElements = slicing.split(',');
            var rank = slicingElements.length;
            // Examine how many of the slicing elements are single numbers, which leads
            // to a decrement in rank.
            for (var _i = 0, slicingElements_1 = slicingElements; _i < slicingElements_1.length; _i++) {
                var element = slicingElements_1[_i];
                if (!isNaN(Number(element))) {
                    rank--;
                }
            }
            return rank;
        }
    }
    tf_debugger_dashboard.rankFromSlicing = rankFromSlicing;
})(tf_debugger_dashboard || (tf_debugger_dashboard = {})); // namespace tf_debugger_dashboard
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGVuc29yLXNoYXBlLWhlbHBlci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbInRlbnNvci1zaGFwZS1oZWxwZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7Ozs7Ozs7Z0ZBYWdGO0FBQ2hGLElBQVUscUJBQXFCLENBcUY5QjtBQXJGRCxXQUFVLHFCQUFxQjtJQUUvQixJQUFNLGFBQWEsR0FBRyxJQUFJLENBQUM7SUFDM0IsSUFBTSxhQUFhLEdBQUcsR0FBRyxDQUFDO0lBRTFCOzs7Ozs7T0FNRztJQUNILDJCQUEyQixJQUFZLEVBQUUsV0FBbUI7UUFDMUQsSUFBSSxJQUFJLElBQUksV0FBVyxFQUFFO1lBQ3ZCLE9BQU8sSUFBSSxDQUFDO1NBQ2I7YUFBTTtZQUNMLE9BQU8sSUFBSSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxHQUFHLFdBQVcsQ0FBQyxDQUFDO1NBQzdDO0lBQ0gsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsMkJBQWtDLEtBQWU7UUFDL0MsSUFBSSxLQUFLLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtZQUN0QixzQkFBc0I7WUFDdEIsT0FBTyxFQUFFLENBQUM7U0FDWDthQUFNLElBQUksS0FBSyxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7WUFDN0IsT0FBTyxHQUFHLEdBQUcsaUJBQWlCLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLGFBQWEsQ0FBQyxHQUFHLEdBQUcsQ0FBQztTQUMvRDthQUFNLElBQUksS0FBSyxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7WUFDN0IsT0FBTyxHQUFHLEdBQUcsaUJBQWlCLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLGFBQWEsQ0FBQyxHQUFHLElBQUk7Z0JBQzFELGlCQUFpQixDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxhQUFhLENBQUMsR0FBRyxHQUFHLENBQUM7U0FDdEQ7YUFBTSxJQUFJLEtBQUssQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO1lBQzdCLE9BQU8sTUFBTSxHQUFHLGlCQUFpQixDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxhQUFhLENBQUMsR0FBRyxJQUFJO2dCQUM3RCxpQkFBaUIsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsYUFBYSxDQUFDLEdBQUcsR0FBRyxDQUFDO1NBQ3REO2FBQU0sSUFBSSxLQUFLLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtZQUM3Qiw4QkFBOEI7WUFDOUIsT0FBTyxNQUFNLEdBQUcsaUJBQWlCLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLGFBQWEsQ0FBQyxHQUFHLElBQUk7Z0JBQzdELGlCQUFpQixDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxhQUFhLENBQUMsR0FBRyxNQUFNLENBQUM7U0FDekQ7YUFBTTtZQUNMLElBQUksT0FBTyxHQUFHLEdBQUcsQ0FBQztZQUNsQixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsS0FBSyxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsRUFBRTtnQkFDckMsSUFBSSxDQUFDLEdBQUcsS0FBSyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7b0JBQ3hCLE9BQU8sSUFBSSxHQUFHLENBQUM7aUJBQ2hCO3FCQUFNO29CQUNMLE9BQU8sSUFBSSxpQkFBaUIsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsYUFBYSxDQUFDLENBQUM7aUJBQ3ZEO2dCQUNELElBQUksQ0FBQyxHQUFHLEtBQUssQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO29CQUN4QixPQUFPLElBQUksSUFBSSxDQUFDO2lCQUNqQjthQUNGO1lBQ0QsT0FBTyxJQUFJLEdBQUcsQ0FBQztZQUNmLE9BQU8sT0FBTyxDQUFDO1NBQ2hCO0lBQ0gsQ0FBQztJQS9CZSx1Q0FBaUIsb0JBK0JoQyxDQUFBO0lBRUQ7Ozs7T0FJRztJQUNILHlCQUFnQyxPQUFlO1FBQzdDLElBQUksT0FBTyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsRUFBRTtZQUMzQixPQUFPLEdBQUcsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsT0FBTyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQztTQUNoRDtRQUNELElBQUksT0FBTyxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7WUFDeEIsc0JBQXNCO1lBQ3RCLE9BQU8sQ0FBQyxDQUFDO1NBQ1Y7YUFBTTtZQUNMLElBQU0sZUFBZSxHQUFhLE9BQU8sQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDckQsSUFBSSxJQUFJLEdBQUcsZUFBZSxDQUFDLE1BQU0sQ0FBQztZQUNsQywyRUFBMkU7WUFDM0UsMEJBQTBCO1lBQzFCLEtBQXNCLFVBQWUsRUFBZixtQ0FBZSxFQUFmLDZCQUFlLEVBQWYsSUFBZSxFQUFFO2dCQUFsQyxJQUFNLE9BQU8sd0JBQUE7Z0JBQ2hCLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLEVBQUU7b0JBQzNCLElBQUksRUFBRSxDQUFDO2lCQUNSO2FBQ0Y7WUFDRCxPQUFPLElBQUksQ0FBQztTQUNiO0lBQ0gsQ0FBQztJQW5CZSxxQ0FBZSxrQkFtQjlCLENBQUE7QUFFRCxDQUFDLEVBckZTLHFCQUFxQixLQUFyQixxQkFBcUIsUUFxRjlCLENBQUUsa0NBQWtDIiwic291cmNlc0NvbnRlbnQiOlsiLyogQ29weXJpZ2h0IDIwMTcgVGhlIFRlbnNvckZsb3cgQXV0aG9ycy4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cblxuTGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlLCBWZXJzaW9uIDIuMCAodGhlICdMaWNlbnNlJyk7XG55b3UgbWF5IG5vdCB1c2UgdGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlIHdpdGggdGhlIExpY2Vuc2UuXG5Zb3UgbWF5IG9idGFpbiBhIGNvcHkgb2YgdGhlIExpY2Vuc2UgYXRcblxuICAgIGh0dHA6Ly93d3cuYXBhY2hlLm9yZy9saWNlbnNlcy9MSUNFTlNFLTIuMFxuXG5Vbmxlc3MgcmVxdWlyZWQgYnkgYXBwbGljYWJsZSBsYXcgb3IgYWdyZWVkIHRvIGluIHdyaXRpbmcsIHNvZnR3YXJlXG5kaXN0cmlidXRlZCB1bmRlciB0aGUgTGljZW5zZSBpcyBkaXN0cmlidXRlZCBvbiBhbiAnQVMgSVMnIEJBU0lTLFxuV0lUSE9VVCBXQVJSQU5USUVTIE9SIENPTkRJVElPTlMgT0YgQU5ZIEtJTkQsIGVpdGhlciBleHByZXNzIG9yIGltcGxpZWQuXG5TZWUgdGhlIExpY2Vuc2UgZm9yIHRoZSBzcGVjaWZpYyBsYW5ndWFnZSBnb3Zlcm5pbmcgcGVybWlzc2lvbnMgYW5kXG5saW1pdGF0aW9ucyB1bmRlciB0aGUgTGljZW5zZS5cbj09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSovXG5uYW1lc3BhY2UgdGZfZGVidWdnZXJfZGFzaGJvYXJkIHtcblxuY29uc3QgbWF4RWxlbWVudHMxRCA9IDEwMDA7XG5jb25zdCBtYXhFbGVtZW50czJEID0gMjUwO1xuXG4vKipcbiAqIEdldCBhIFB5dGhvbi1zdHlsZSBzbGljaW5nIHN0cmluZyByZXByZXNlbnRpbmcgc3RyaWRlZCBzbGljaW5nLlxuICogQHBhcmFtIHNpemUgVG90YWwgc2l6ZSBhbG9uZyB0aGUgZGltZW5zaW9uIGJlaW5nIHNsaWNlZC5cbiAqIEBwYXJhbSBtYXhFbGVtZW50cyBNYXhpbXVtIG51bWJlciBvZiBlbGVtZW50cyBhbGxvd2VkIGluIHRoZSBzbGljaW5nIHJlc3VsdC5cbiAqIEByZXR1cm5zIEEgUHl0aG9uLXN0eWxlIHNsaWNpbmcgc3RyaW5nIGJlZ2lubmluZyB3aXRoIHR3byBjb2xvbnMsIHdpdGhvdXRcbiAqICAgc3Vycm91bmRpbmcgYnJhY2tldHMuXG4gKi9cbmZ1bmN0aW9uIGdldFN0cmlkZWRTbGljaW5nKHNpemU6IG51bWJlciwgbWF4RWxlbWVudHM6IG51bWJlcik6IHN0cmluZyB7XG4gIGlmIChzaXplIDw9IG1heEVsZW1lbnRzKSB7XG4gICAgcmV0dXJuICc6Oic7XG4gIH0gZWxzZSB7XG4gICAgcmV0dXJuICc6OicgKyBNYXRoLmNlaWwoc2l6ZSAvIG1heEVsZW1lbnRzKTtcbiAgfVxufVxuXG4vKipcbiAqIEdldCB0aGUgZGVmYXVsdCBzbGljaW5nIGdpdmVuIGEgdGVuc29yIHNoYXBlLlxuICogQHBhcmFtIHNoYXBlOiBUaGUgdGVuc29yIHNoYXBlLCByZXByZXNlbnRlZCBhcyBhbiBBcnJheSBvZiBudW1iZXIuXG4gKiBAcmV0dXJuOiBOdW1weS1zdHlsZSBzbGljaW5nIHN0cmluZywgd2l0aCB0aGUgc3Vycm91bmRpbmcgYnJhY2tldHMsIGUuZy4sXG4gKiAgICdbOjoyLCAwOjEwXScuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZXREZWZhdWx0U2xpY2luZyhzaGFwZTogbnVtYmVyW10pOiBzdHJpbmcge1xuICBpZiAoc2hhcGUubGVuZ3RoID09PSAwKSB7XG4gICAgLy8gU2NhbGFyOiBubyBzbGljaW5nLlxuICAgIHJldHVybiAnJztcbiAgfSBlbHNlIGlmIChzaGFwZS5sZW5ndGggPT09IDEpIHtcbiAgICByZXR1cm4gJ1snICsgZ2V0U3RyaWRlZFNsaWNpbmcoc2hhcGVbMF0sIG1heEVsZW1lbnRzMUQpICsgJ10nO1xuICB9IGVsc2UgaWYgKHNoYXBlLmxlbmd0aCA9PT0gMikge1xuICAgIHJldHVybiAnWycgKyBnZXRTdHJpZGVkU2xpY2luZyhzaGFwZVswXSwgbWF4RWxlbWVudHMyRCkgKyAnLCAnICArXG4gICAgICAgIGdldFN0cmlkZWRTbGljaW5nKHNoYXBlWzFdLCBtYXhFbGVtZW50czJEKSArICddJztcbiAgfSBlbHNlIGlmIChzaGFwZS5sZW5ndGggPT09IDMpIHtcbiAgICByZXR1cm4gJ1swLCAnICsgZ2V0U3RyaWRlZFNsaWNpbmcoc2hhcGVbMV0sIG1heEVsZW1lbnRzMkQpICsgJywgJyAgK1xuICAgICAgICBnZXRTdHJpZGVkU2xpY2luZyhzaGFwZVsyXSwgbWF4RWxlbWVudHMyRCkgKyAnXSc7XG4gIH0gZWxzZSBpZiAoc2hhcGUubGVuZ3RoID09PSA0KSB7XG4gICAgLy8gQXNzdW1lIE5IV0MgYXMgdGhlIGRlZmF1bHQuXG4gICAgcmV0dXJuICdbMCwgJyArIGdldFN0cmlkZWRTbGljaW5nKHNoYXBlWzFdLCBtYXhFbGVtZW50czJEKSArICcsICcgICtcbiAgICAgICAgZ2V0U3RyaWRlZFNsaWNpbmcoc2hhcGVbMl0sIG1heEVsZW1lbnRzMkQpICsgJywgMF0nO1xuICB9IGVsc2Uge1xuICAgIGxldCBzbGljaW5nID0gJ1snO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgc2hhcGUubGVuZ3RoOyArK2kpIHtcbiAgICAgIGlmIChpIDwgc2hhcGUubGVuZ3RoIC0gMikge1xuICAgICAgICBzbGljaW5nICs9ICcwJztcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHNsaWNpbmcgKz0gZ2V0U3RyaWRlZFNsaWNpbmcoc2hhcGVbaV0sIG1heEVsZW1lbnRzMkQpO1xuICAgICAgfVxuICAgICAgaWYgKGkgPCBzaGFwZS5sZW5ndGggLSAxKSB7XG4gICAgICAgIHNsaWNpbmcgKz0gJywgJztcbiAgICAgIH1cbiAgICB9XG4gICAgc2xpY2luZyArPSAnXSc7XG4gICAgcmV0dXJuIHNsaWNpbmc7XG4gIH1cbn1cblxuLyoqXG4gKiBEZXRlcm1pbmUgcmFuayBvZiBhIHNsaWNpbmcgc3RyaW5nLlxuICogQHBhcmFtIHNsaWNpbmcgVGhlIHNsaWNpbmcgc3RyaW5nLlxuICogQHJldHVybiBUaGUgcmFuay5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHJhbmtGcm9tU2xpY2luZyhzbGljaW5nOiBzdHJpbmcpOiBudW1iZXIge1xuICBpZiAoc2xpY2luZy5zdGFydHNXaXRoKCdbJykpIHtcbiAgICBzbGljaW5nID0gc2xpY2luZy5zbGljZSgxLCBzbGljaW5nLmxlbmd0aCAtIDEpO1xuICB9XG4gIGlmIChzbGljaW5nLmxlbmd0aCA9PT0gMCkge1xuICAgIC8vIFNjYWxhcjogbm8gc2xpY2luZy5cbiAgICByZXR1cm4gMDtcbiAgfSBlbHNlIHtcbiAgICBjb25zdCBzbGljaW5nRWxlbWVudHM6IHN0cmluZ1tdID0gc2xpY2luZy5zcGxpdCgnLCcpO1xuICAgIGxldCByYW5rID0gc2xpY2luZ0VsZW1lbnRzLmxlbmd0aDtcbiAgICAvLyBFeGFtaW5lIGhvdyBtYW55IG9mIHRoZSBzbGljaW5nIGVsZW1lbnRzIGFyZSBzaW5nbGUgbnVtYmVycywgd2hpY2ggbGVhZHNcbiAgICAvLyB0byBhIGRlY3JlbWVudCBpbiByYW5rLlxuICAgIGZvciAoY29uc3QgZWxlbWVudCBvZiBzbGljaW5nRWxlbWVudHMpIHtcbiAgICAgIGlmICghaXNOYU4oTnVtYmVyKGVsZW1lbnQpKSkge1xuICAgICAgICByYW5rLS07XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiByYW5rO1xuICB9XG59XG5cbn0gIC8vIG5hbWVzcGFjZSB0Zl9kZWJ1Z2dlcl9kYXNoYm9hcmRcbiJdfQ==