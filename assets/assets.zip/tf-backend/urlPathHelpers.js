/* Copyright 2015 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the 'License');
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an 'AS IS' BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
var tf_backend;
(function (tf_backend) {
    /**
     * Add query parameters to a URL. Values will be URL-encoded. The URL
     * may or may not already have query parameters. For convenience,
     * parameters whose value is `undefined` will be dropped.
     *
     * For example, the following expressions are equivalent:
     *
     *     addParams("http://foo", {a: "1", b: ["2", "3+4"], c: "5"})
     *     addParams("http://foo?a=1", {b: ["2", "3+4"], c: "5", d: undefined})
     *     "http://foo?a=1&b=2&b=3%2B4&c=5"
     *
     * @deprecated If used with `router.pluginRoute`, please use the queryParams
     * argument.
     */
    function addParams(baseURL, params) {
        var keys = Object.keys(params).sort().filter(function (k) { return params[k] !== undefined; });
        if (!keys.length) {
            return baseURL; // no need to change '/foo' to '/foo?'
        }
        var delimiter = baseURL.indexOf('?') !== -1 ? '&' : '?';
        var parts = [].concat.apply([], keys.map(function (key) {
            var rawValue = params[key];
            var values = Array.isArray(rawValue) ? rawValue : [rawValue];
            return values.map(function (value) { return key + "=" + _encodeURIComponent(value); });
        }));
        var query = parts.join('&');
        return baseURL + delimiter + query;
    }
    tf_backend.addParams = addParams;
    function _encodeURIComponent(x) {
        // Replace parentheses for consistency with Python's urllib.urlencode.
        return encodeURIComponent(x).replace(/\(/g, '%28').replace(/\)/g, '%29');
    }
})(tf_backend || (tf_backend = {})); // namespace tf_backend
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidXJsUGF0aEhlbHBlcnMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJ1cmxQYXRoSGVscGVycy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7Ozs7Ozs7OztnRkFhZ0Y7QUFDaEYsSUFBVSxVQUFVLENBNkNuQjtBQTdDRCxXQUFVLFVBQVU7SUFXcEI7Ozs7Ozs7Ozs7Ozs7T0FhRztJQUNILG1CQUEwQixPQUFlLEVBQUUsTUFBbUI7UUFDNUQsSUFBTSxJQUFJLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxNQUFNLENBQUMsVUFBQSxDQUFDLElBQUksT0FBQSxNQUFNLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxFQUF2QixDQUF1QixDQUFDLENBQUM7UUFDN0UsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUU7WUFDaEIsT0FBTyxPQUFPLENBQUMsQ0FBRSxzQ0FBc0M7U0FDeEQ7UUFDRCxJQUFNLFNBQVMsR0FBRyxPQUFPLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztRQUMxRCxJQUFNLEtBQUssR0FBRyxFQUFFLENBQUMsTUFBTSxPQUFULEVBQUUsRUFBVyxJQUFJLENBQUMsR0FBRyxDQUFDLFVBQUEsR0FBRztZQUNyQyxJQUFNLFFBQVEsR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDN0IsSUFBTSxNQUFNLEdBQUcsS0FBSyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQy9ELE9BQU8sTUFBTSxDQUFDLEdBQUcsQ0FBQyxVQUFBLEtBQUssSUFBSSxPQUFHLEdBQUcsU0FBSSxtQkFBbUIsQ0FBQyxLQUFLLENBQUcsRUFBdEMsQ0FBc0MsQ0FBQyxDQUFDO1FBQ3JFLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDSixJQUFNLEtBQUssR0FBRyxLQUFLLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQzlCLE9BQU8sT0FBTyxHQUFHLFNBQVMsR0FBRyxLQUFLLENBQUM7SUFDckMsQ0FBQztJQWJlLG9CQUFTLFlBYXhCLENBQUE7SUFFRCw2QkFBNkIsQ0FBUztRQUNwQyxzRUFBc0U7UUFDdEUsT0FBTyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLEtBQUssQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDM0UsQ0FBQztBQUVELENBQUMsRUE3Q1MsVUFBVSxLQUFWLFVBQVUsUUE2Q25CLENBQUUsdUJBQXVCIiwic291cmNlc0NvbnRlbnQiOlsiLyogQ29weXJpZ2h0IDIwMTUgVGhlIFRlbnNvckZsb3cgQXV0aG9ycy4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cblxuTGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlLCBWZXJzaW9uIDIuMCAodGhlICdMaWNlbnNlJyk7XG55b3UgbWF5IG5vdCB1c2UgdGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlIHdpdGggdGhlIExpY2Vuc2UuXG5Zb3UgbWF5IG9idGFpbiBhIGNvcHkgb2YgdGhlIExpY2Vuc2UgYXRcblxuICAgIGh0dHA6Ly93d3cuYXBhY2hlLm9yZy9saWNlbnNlcy9MSUNFTlNFLTIuMFxuXG5Vbmxlc3MgcmVxdWlyZWQgYnkgYXBwbGljYWJsZSBsYXcgb3IgYWdyZWVkIHRvIGluIHdyaXRpbmcsIHNvZnR3YXJlXG5kaXN0cmlidXRlZCB1bmRlciB0aGUgTGljZW5zZSBpcyBkaXN0cmlidXRlZCBvbiBhbiAnQVMgSVMnIEJBU0lTLFxuV0lUSE9VVCBXQVJSQU5USUVTIE9SIENPTkRJVElPTlMgT0YgQU5ZIEtJTkQsIGVpdGhlciBleHByZXNzIG9yIGltcGxpZWQuXG5TZWUgdGhlIExpY2Vuc2UgZm9yIHRoZSBzcGVjaWZpYyBsYW5ndWFnZSBnb3Zlcm5pbmcgcGVybWlzc2lvbnMgYW5kXG5saW1pdGF0aW9ucyB1bmRlciB0aGUgTGljZW5zZS5cbj09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSovXG5uYW1lc3BhY2UgdGZfYmFja2VuZCB7XG5cbi8qKlxuICogQSBxdWVyeSBwYXJhbWV0ZXIgdmFsdWUgY2FuIGVpdGhlciBiZSBhIHN0cmluZyBvciBhIGxpc3Qgb2Ygc3RyaW5ncy5cbiAqIEEgc3RyaW5nIGBcImZvb1wiYCBpcyBlbmNvZGVkIGFzIGBrZXk9Zm9vYDsgYSBsaXN0IGBbXCJmb29cIiwgXCJiYXJcIl1gIGlzXG4gKiBlbmNvZGVkIGFzIGBrZXk9Zm9vJmtleT1iYXJgLlxuICovXG5leHBvcnQgdHlwZSBRdWVyeVZhbHVlID0gc3RyaW5nIHwgc3RyaW5nW107XG5cbmV4cG9ydCB0eXBlIFF1ZXJ5UGFyYW1zID0ge1trZXk6IHN0cmluZ106IFF1ZXJ5VmFsdWV9O1xuXG4vKipcbiAqIEFkZCBxdWVyeSBwYXJhbWV0ZXJzIHRvIGEgVVJMLiBWYWx1ZXMgd2lsbCBiZSBVUkwtZW5jb2RlZC4gVGhlIFVSTFxuICogbWF5IG9yIG1heSBub3QgYWxyZWFkeSBoYXZlIHF1ZXJ5IHBhcmFtZXRlcnMuIEZvciBjb252ZW5pZW5jZSxcbiAqIHBhcmFtZXRlcnMgd2hvc2UgdmFsdWUgaXMgYHVuZGVmaW5lZGAgd2lsbCBiZSBkcm9wcGVkLlxuICpcbiAqIEZvciBleGFtcGxlLCB0aGUgZm9sbG93aW5nIGV4cHJlc3Npb25zIGFyZSBlcXVpdmFsZW50OlxuICpcbiAqICAgICBhZGRQYXJhbXMoXCJodHRwOi8vZm9vXCIsIHthOiBcIjFcIiwgYjogW1wiMlwiLCBcIjMrNFwiXSwgYzogXCI1XCJ9KVxuICogICAgIGFkZFBhcmFtcyhcImh0dHA6Ly9mb28/YT0xXCIsIHtiOiBbXCIyXCIsIFwiMys0XCJdLCBjOiBcIjVcIiwgZDogdW5kZWZpbmVkfSlcbiAqICAgICBcImh0dHA6Ly9mb28/YT0xJmI9MiZiPTMlMkI0JmM9NVwiXG4gKlxuICogQGRlcHJlY2F0ZWQgSWYgdXNlZCB3aXRoIGByb3V0ZXIucGx1Z2luUm91dGVgLCBwbGVhc2UgdXNlIHRoZSBxdWVyeVBhcmFtc1xuICogYXJndW1lbnQuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBhZGRQYXJhbXMoYmFzZVVSTDogc3RyaW5nLCBwYXJhbXM6IFF1ZXJ5UGFyYW1zKTogc3RyaW5nIHtcbiAgY29uc3Qga2V5cyA9IE9iamVjdC5rZXlzKHBhcmFtcykuc29ydCgpLmZpbHRlcihrID0+IHBhcmFtc1trXSAhPT0gdW5kZWZpbmVkKTtcbiAgaWYgKCFrZXlzLmxlbmd0aCkge1xuICAgIHJldHVybiBiYXNlVVJMOyAgLy8gbm8gbmVlZCB0byBjaGFuZ2UgJy9mb28nIHRvICcvZm9vPydcbiAgfVxuICBjb25zdCBkZWxpbWl0ZXIgPSBiYXNlVVJMLmluZGV4T2YoJz8nKSAhPT0gLTEgPyAnJicgOiAnPyc7XG4gIGNvbnN0IHBhcnRzID0gW10uY29uY2F0KC4uLmtleXMubWFwKGtleSA9PiB7XG4gICAgY29uc3QgcmF3VmFsdWUgPSBwYXJhbXNba2V5XTtcbiAgICBjb25zdCB2YWx1ZXMgPSBBcnJheS5pc0FycmF5KHJhd1ZhbHVlKSA/IHJhd1ZhbHVlIDogW3Jhd1ZhbHVlXTtcbiAgICByZXR1cm4gdmFsdWVzLm1hcCh2YWx1ZSA9PiBgJHtrZXl9PSR7X2VuY29kZVVSSUNvbXBvbmVudCh2YWx1ZSl9YCk7XG4gIH0pKTtcbiAgY29uc3QgcXVlcnkgPSBwYXJ0cy5qb2luKCcmJyk7XG4gIHJldHVybiBiYXNlVVJMICsgZGVsaW1pdGVyICsgcXVlcnk7XG59XG5cbmZ1bmN0aW9uIF9lbmNvZGVVUklDb21wb25lbnQoeDogc3RyaW5nKTogc3RyaW5nIHtcbiAgLy8gUmVwbGFjZSBwYXJlbnRoZXNlcyBmb3IgY29uc2lzdGVuY3kgd2l0aCBQeXRob24ncyB1cmxsaWIudXJsZW5jb2RlLlxuICByZXR1cm4gZW5jb2RlVVJJQ29tcG9uZW50KHgpLnJlcGxhY2UoL1xcKC9nLCAnJTI4JykucmVwbGFjZSgvXFwpL2csICclMjknKTtcbn1cblxufSAgLy8gbmFtZXNwYWNlIHRmX2JhY2tlbmRcbiJdfQ==