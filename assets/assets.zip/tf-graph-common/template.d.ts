declare module tf.graph.template {
    /**
     * Detect repeating patterns of subgraphs.
     * Assign templateId to each subgraph if it belongs to a template.
     * Returns clusters of similar subgraphs .
     *
     * @param graph
     * @param verifyTemplate whether to run the template verification algorithm
     * @return a dict (template id => Array of node names)
     */
    function detect(h: any, verifyTemplate: any): {
        [templateId: string]: string[];
    };
}
