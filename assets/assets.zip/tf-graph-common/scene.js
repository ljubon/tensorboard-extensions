/* Copyright 2015 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the 'License');
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an 'AS IS' BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
var tf;
(function (tf) {
    var graph;
    (function (graph) {
        var scene;
        (function (scene) {
            scene.SVG_NAMESPACE = 'http://www.w3.org/2000/svg';
            /** Enums element class of objects in the scene */
            scene.Class = {
                Node: {
                    // <g> element that contains nodes.
                    CONTAINER: 'nodes',
                    // <g> element that contains detail about a node.
                    GROUP: 'node',
                    // <g> element that contains visual elements (like rect, ellipse).
                    SHAPE: 'nodeshape',
                    // <*> element(s) under SHAPE that should receive color updates.
                    COLOR_TARGET: 'nodecolortarget',
                    // <text> element showing the node's label.
                    LABEL: 'nodelabel',
                    // <g> element that contains all visuals for the expand/collapse
                    // button for expandable group nodes.
                    BUTTON_CONTAINER: 'buttoncontainer',
                    // <circle> element that surrounds expand/collapse buttons.
                    BUTTON_CIRCLE: 'buttoncircle',
                    // <path> element of the expand button.
                    EXPAND_BUTTON: 'expandbutton',
                    // <path> element of the collapse button.
                    COLLAPSE_BUTTON: 'collapsebutton'
                },
                Edge: {
                    CONTAINER: 'edges',
                    GROUP: 'edge',
                    LINE: 'edgeline',
                    REFERENCE_EDGE: 'referenceedge',
                    REF_LINE: 'refline',
                    SELECTABLE: 'selectableedge',
                    SELECTED: 'selectededge',
                    STRUCTURAL: 'structural'
                },
                Annotation: {
                    OUTBOX: 'out-annotations',
                    INBOX: 'in-annotations',
                    GROUP: 'annotation',
                    NODE: 'annotation-node',
                    EDGE: 'annotation-edge',
                    CONTROL_EDGE: 'annotation-control-edge',
                    LABEL: 'annotation-label',
                    ELLIPSIS: 'annotation-ellipsis'
                },
                Scene: {
                    GROUP: 'scene',
                    CORE: 'core',
                    FUNCTION_LIBRARY: 'function-library',
                    INEXTRACT: 'in-extract',
                    OUTEXTRACT: 'out-extract'
                },
                Subscene: { GROUP: 'subscene' },
                OPNODE: 'op',
                METANODE: 'meta',
                SERIESNODE: 'series',
                BRIDGENODE: 'bridge',
                ELLIPSISNODE: 'ellipsis'
            };
            /**
             * The dimensions of the minimap including padding and margin.
             */
            var MINIMAP_BOX_WIDTH = 320;
            var MINIMAP_BOX_HEIGHT = 150;
            scene.healthPillEntries = [
                {
                    background_color: '#CC2F2C',
                    label: 'NaN',
                },
                {
                    background_color: '#FF8D00',
                    label: '-∞',
                },
                {
                    background_color: '#EAEAEA',
                    label: '-',
                },
                {
                    background_color: '#A5A5A5',
                    label: '0',
                },
                {
                    background_color: '#262626',
                    label: '+',
                },
                {
                    background_color: '#003ED4',
                    label: '+∞',
                },
            ];
            /**
             * Helper method for fitting the graph in the svg view.
             *
             * @param svg The main svg.
             * @param zoomG The svg group used for panning and zooming.
             * @param d3zoom The zoom behavior.
             * @param callback Called when the fitting is done.
             */
            function fit(svg, zoomG, d3zoom, callback) {
                var svgRect = svg.getBoundingClientRect();
                var sceneSize = null;
                try {
                    sceneSize = zoomG.getBBox();
                    if (sceneSize.width === 0) {
                        // There is no scene anymore. We have been detached from the dom.
                        return;
                    }
                }
                catch (e) {
                    // Firefox produced NS_ERROR_FAILURE if we have been
                    // detached from the dom.
                    return;
                }
                var scale = 0.9 *
                    Math.min(svgRect.width / sceneSize.width, svgRect.height / sceneSize.height, 2);
                var params = graph.layout.PARAMS.graph;
                var transform = d3.zoomIdentity
                    .scale(scale)
                    .translate(params.padding.paddingLeft, params.padding.paddingTop);
                d3.select(svg)
                    .transition()
                    .duration(500)
                    .call(d3zoom.transform, transform)
                    .on('end.fitted', function () {
                    // Remove the listener for the zoomend event,
                    // so we don't get called at the end of regular zoom events,
                    // just those that fit the graph to screen.
                    d3zoom.on('end.fitted', null);
                    callback();
                });
            }
            scene.fit = fit;
            ;
            /**
             * Helper method for panning the graph to center on the provided node,
             * if the node is currently off-screen.
             *
             * @param nodeName The node to center the graph on
             * @param svg The root SVG element for the graph
             * @param zoomG The svg group used for panning and zooming.
             * @param d3zoom The zoom behavior.
             * @return True if the graph had to be panned to display the
             *            provided node.
             */
            function panToNode(nodeName, svg, zoomG, d3zoom) {
                var node = d3
                    .select('[data-name="' + nodeName + '"].' + scene.Class.Node.GROUP)
                    .node();
                if (!node) {
                    return false;
                }
                // Check if the selected node is off-screen in either
                // X or Y dimension in either direction.
                var nodeBox = node.getBBox();
                var nodeCtm = node.getScreenCTM();
                var pointTL = svg.createSVGPoint();
                var pointBR = svg.createSVGPoint();
                pointTL.x = nodeBox.x;
                pointTL.y = nodeBox.y;
                pointBR.x = nodeBox.x + nodeBox.width;
                pointBR.y = nodeBox.y + nodeBox.height;
                pointTL = pointTL.matrixTransform(nodeCtm);
                pointBR = pointBR.matrixTransform(nodeCtm);
                var isOutsideOfBounds = function (start, end, lowerBound, upperBound) {
                    // Return if even a part of the interval is out of bounds.
                    return !(start > lowerBound && end < upperBound);
                };
                var svgRect = svg.getBoundingClientRect();
                // Subtract to make sure that the node is not hidden behind the minimap.
                var horizontalBound = svgRect.left + svgRect.width - MINIMAP_BOX_WIDTH;
                var verticalBound = svgRect.top + svgRect.height - MINIMAP_BOX_HEIGHT;
                if (isOutsideOfBounds(pointTL.x, pointBR.x, svgRect.left, horizontalBound) ||
                    isOutsideOfBounds(pointTL.y, pointBR.y, svgRect.top, verticalBound)) {
                    // Determine the amount to translate the graph in both X and Y dimensions in
                    // order to center the selected node. This takes into account the position
                    // of the node, the size of the svg scene, the amount the scene has been
                    // scaled by through zooming, and any previous transforms already performed
                    // by this logic.
                    var centerX = (pointTL.x + pointBR.x) / 2;
                    var centerY = (pointTL.y + pointBR.y) / 2;
                    var dx = svgRect.left + svgRect.width / 2 - centerX;
                    var dy = svgRect.top + svgRect.height / 2 - centerY;
                    // We translate by this amount. We divide the X and Y translations by the
                    // scale to undo how translateBy scales the translations (in d3 v4).
                    var svgTransform = d3.zoomTransform(svg);
                    d3.select(svg).transition().duration(500).call(d3zoom.translateBy, dx / svgTransform.k, dy / svgTransform.k);
                    return true;
                }
                return false;
            }
            scene.panToNode = panToNode;
            ;
            /**
             * Given a container d3 selection, select a child svg element of a given tag
             * and class if exists or append / insert one otherwise.  If multiple children
             * matches the tag and class name, returns only the first one.
             *
             * @param container
             * @param tagName tag name.
             * @param className (optional) Class name or a list of class names.
             * @param before (optional) reference DOM node for insertion.
             * @return selection of the element
             */
            function selectOrCreateChild(container, tagName, className, before) {
                var child = selectChild(container, tagName, className);
                if (!child.empty()) {
                    return child;
                }
                var newElement = document.createElementNS('http://www.w3.org/2000/svg', tagName);
                if (className instanceof Array) {
                    for (var i = 0; i < className.length; i++) {
                        newElement.classList.add(className[i]);
                    }
                }
                else {
                    newElement.classList.add(className);
                }
                if (before) { // if before exists, insert
                    container.node().insertBefore(newElement, before);
                }
                else { // otherwise, append
                    container.node().appendChild(newElement);
                }
                return d3.select(newElement)
                    // need to bind data to emulate d3_selection.append
                    .datum(container.datum());
            }
            scene.selectOrCreateChild = selectOrCreateChild;
            ;
            /**
             * Given a container d3 selection, select a child element of a given tag and
             * class. If multiple children matches the tag and class name, returns only
             * the first one.
             *
             * @param container
             * @param tagName tag name.
             * @param className (optional) Class name or list of class names.
             * @return selection of the element, or an empty selection
             */
            function selectChild(container, tagName, className) {
                var children = container.node().childNodes;
                for (var i = 0; i < children.length; i++) {
                    var child = children[i];
                    if (child.tagName === tagName) {
                        if (className instanceof Array) {
                            var hasAllClasses = true;
                            for (var j = 0; j < className.length; j++) {
                                hasAllClasses =
                                    hasAllClasses && child.classList.contains(className[j]);
                            }
                            if (hasAllClasses) {
                                return d3.select(child);
                            }
                        }
                        else if ((!className || child.classList.contains(className))) {
                            return d3.select(child);
                        }
                    }
                }
                return d3.select(null);
            }
            scene.selectChild = selectChild;
            ;
            /**
             * Select or create a sceneGroup and build/update its nodes and edges.
             *
             * Structure Pattern:
             *
             * <g class='scene'>
             *   <g class='core'>
             *     <g class='edges'>
             *       ... stuff from tf.graph.scene.edges.build ...
             *     </g>
             *     <g class='nodes'>
             *       ... stuff from tf.graph.scene.nodes.build ...
             *     </g>
             *   </g>
             *   <g class='in-extract'>
             *     <g class='nodes'>
             *       ... stuff from tf.graph.scene.nodes.build ...
             *     </g>
             *   </g>
             *   <g class='out-extract'>
             *     <g class='nodes'>
             *       ... stuff from tf.graph.scene.nodes.build ...
             *     </g>
             *   </g>
             * </g>
             *
             * @param container D3 selection of the parent.
             * @param renderNode render node of a metanode or series node.
             * @param sceneElement <tf-graph-scene> polymer element.
             * @param sceneClass class attribute of the scene (default='scene').
             */
            function buildGroup(container, renderNode, sceneElement, sceneClass) {
                sceneClass = sceneClass || scene.Class.Scene.GROUP;
                var isNewSceneGroup = selectChild(container, 'g', sceneClass).empty();
                var sceneGroup = selectOrCreateChild(container, 'g', sceneClass);
                // core
                var coreGroup = selectOrCreateChild(sceneGroup, 'g', scene.Class.Scene.CORE);
                var coreNodes = _.reduce(renderNode.coreGraph.nodes(), function (nodes, name) {
                    var node = renderNode.coreGraph.node(name);
                    if (!node.excluded) {
                        nodes.push(node);
                    }
                    return nodes;
                }, []);
                if (renderNode.node.type === graph.NodeType.SERIES) {
                    // For series, we want the first item on top, so reverse the array so
                    // the first item in the series becomes last item in the top, and thus
                    // is rendered on the top.
                    coreNodes.reverse();
                }
                // Create the layer of edges for this scene (paths).
                scene.edge.buildGroup(coreGroup, renderNode.coreGraph, sceneElement);
                // Create the layer of nodes for this scene (ellipses, rects etc).
                scene.node.buildGroup(coreGroup, coreNodes, sceneElement);
                // In-extract
                if (renderNode.isolatedInExtract.length > 0) {
                    var inExtractGroup = selectOrCreateChild(sceneGroup, 'g', scene.Class.Scene.INEXTRACT);
                    scene.node.buildGroup(inExtractGroup, renderNode.isolatedInExtract, sceneElement);
                }
                else {
                    selectChild(sceneGroup, 'g', scene.Class.Scene.INEXTRACT).remove();
                }
                // Out-extract
                if (renderNode.isolatedOutExtract.length > 0) {
                    var outExtractGroup = selectOrCreateChild(sceneGroup, 'g', scene.Class.Scene.OUTEXTRACT);
                    scene.node.buildGroup(outExtractGroup, renderNode.isolatedOutExtract, sceneElement);
                }
                else {
                    selectChild(sceneGroup, 'g', scene.Class.Scene.OUTEXTRACT).remove();
                }
                // Library functions
                if (renderNode.libraryFunctionsExtract.length > 0) {
                    var outExtractGroup = selectOrCreateChild(sceneGroup, 'g', scene.Class.Scene.FUNCTION_LIBRARY);
                    scene.node.buildGroup(outExtractGroup, renderNode.libraryFunctionsExtract, sceneElement);
                }
                else {
                    selectChild(sceneGroup, 'g', scene.Class.Scene.FUNCTION_LIBRARY).remove();
                }
                position(sceneGroup, renderNode);
                // Fade in the scene group if it didn't already exist.
                if (isNewSceneGroup) {
                    sceneGroup.attr('opacity', 0).transition().attr('opacity', 1);
                }
                return sceneGroup;
            }
            scene.buildGroup = buildGroup;
            ;
            /**
             * Given a scene's svg group, set  g.in-extract, g.coreGraph, g.out-extract svg
             * groups' position relative to the scene.
             *
             * @param sceneGroup
             * @param renderNode render node of a metanode or series node.
             */
            function position(sceneGroup, renderNode) {
                // Translate scenes down by the label height so that when showing graphs in
                // expanded metanodes, the graphs are below the labels.  Do not shift them
                // down for series nodes as series nodes don't have labels inside of their
                // bounding boxes.
                var yTranslate = renderNode.node.type === graph.NodeType.SERIES ?
                    0 : graph.layout.PARAMS.subscene.meta.labelHeight;
                // core
                translate(selectChild(sceneGroup, 'g', scene.Class.Scene.CORE), 0, yTranslate);
                // in-extract
                var hasInExtract = renderNode.isolatedInExtract.length > 0;
                var hasOutExtract = renderNode.isolatedOutExtract.length > 0;
                var hasLibraryFunctions = renderNode.libraryFunctionsExtract.length > 0;
                var offset = graph.layout.PARAMS.subscene.meta.extractXOffset;
                var auxWidth = 0;
                if (hasInExtract) {
                    auxWidth += renderNode.outExtractBox.width;
                }
                if (hasOutExtract) {
                    auxWidth += renderNode.outExtractBox.width;
                }
                if (hasInExtract) {
                    var inExtractX = renderNode.coreBox.width;
                    if (auxWidth < graph.layout.MIN_AUX_WIDTH) {
                        inExtractX = inExtractX - graph.layout.MIN_AUX_WIDTH +
                            renderNode.inExtractBox.width / 2;
                    }
                    else {
                        inExtractX = inExtractX -
                            renderNode.inExtractBox.width / 2 - renderNode.outExtractBox.width -
                            (hasOutExtract ? offset : 0);
                    }
                    inExtractX = inExtractX -
                        renderNode.libraryFunctionsBox.width -
                        (hasLibraryFunctions ? offset : 0);
                    translate(selectChild(sceneGroup, 'g', scene.Class.Scene.INEXTRACT), inExtractX, yTranslate);
                }
                // out-extract
                if (hasOutExtract) {
                    var outExtractX = renderNode.coreBox.width;
                    if (auxWidth < graph.layout.MIN_AUX_WIDTH) {
                        outExtractX = outExtractX - graph.layout.MIN_AUX_WIDTH +
                            renderNode.outExtractBox.width / 2;
                    }
                    else {
                        outExtractX -= renderNode.outExtractBox.width / 2;
                    }
                    outExtractX = outExtractX -
                        renderNode.libraryFunctionsBox.width -
                        (hasLibraryFunctions ? offset : 0);
                    translate(selectChild(sceneGroup, 'g', scene.Class.Scene.OUTEXTRACT), outExtractX, yTranslate);
                }
                if (hasLibraryFunctions) {
                    var libraryFunctionsExtractX = renderNode.coreBox.width -
                        renderNode.libraryFunctionsBox.width / 2;
                    translate(selectChild(sceneGroup, 'g', scene.Class.Scene.FUNCTION_LIBRARY), libraryFunctionsExtractX, yTranslate);
                }
            }
            ;
            /** Adds a click listener to a group that fires a graph-select event */
            function addGraphClickListener(graphGroup, sceneElement) {
                d3.select(graphGroup).on('click', function () {
                    sceneElement.fire('graph-select');
                });
            }
            scene.addGraphClickListener = addGraphClickListener;
            ;
            /** Helper for adding transform: translate(x0, y0) */
            function translate(selection, x0, y0) {
                // If it is already placed on the screen, make it a transition.
                if (selection.attr('transform') != null) {
                    selection = selection.transition('position');
                }
                selection.attr('transform', 'translate(' + x0 + ',' + y0 + ')');
            }
            scene.translate = translate;
            ;
            /**
             * Helper for setting position of a svg rect
             * @param rect A d3 selection of rect(s) to set position of.
             * @param cx Center x.
             * @param cy Center x.
             * @param width Width to set.
             * @param height Height to set.
             */
            function positionRect(rect, cx, cy, width, height) {
                rect.transition()
                    .attr('x', cx - width / 2)
                    .attr('y', cy - height / 2)
                    .attr('width', width)
                    .attr('height', height);
            }
            scene.positionRect = positionRect;
            ;
            /**
             * Positions a triangle and sizes it.
             * @param polygon polygon to set position of.
             * @param cx Center x.
             * @param cy Center y.
             * @param width Width of bounding box for triangle.
             * @param height Height of bounding box for triangle.
             */
            function positionTriangle(polygon, cx, cy, width, height) {
                var halfHeight = height / 2;
                var halfWidth = width / 2;
                var points = [
                    [cx, cy - halfHeight],
                    [cx + halfWidth, cy + halfHeight],
                    [cx - halfWidth, cy + halfHeight]
                ];
                polygon.transition().attr('points', points.map(function (point) { return point.join(','); }).join(' '));
            }
            scene.positionTriangle = positionTriangle;
            ;
            /**
             * Helper for setting position of a svg expand/collapse button
             * @param button container group
             * @param renderNode the render node of the group node to position
             *        the button on.
             */
            function positionButton(button, renderNode) {
                var cx = graph.layout.computeCXPositionOfNodeShape(renderNode);
                // Position the button in the top-right corner of the group node,
                // with space given the draw the button inside of the corner.
                var width = renderNode.expanded ?
                    renderNode.width : renderNode.coreBox.width;
                var height = renderNode.expanded ?
                    renderNode.height : renderNode.coreBox.height;
                var x = cx + width / 2 - 6;
                var y = renderNode.y - height / 2 + 6;
                // For unexpanded series nodes, the button has special placement due
                // to the unique visuals of this group node.
                if (renderNode.node.type === graph.NodeType.SERIES && !renderNode.expanded) {
                    x += 10;
                    y -= 2;
                }
                var translateStr = 'translate(' + x + ',' + y + ')';
                button.selectAll('path').transition().attr('transform', translateStr);
                button.select('circle').transition().attr({ cx: x, cy: y, r: graph.layout.PARAMS.nodeSize.meta.expandButtonRadius });
            }
            scene.positionButton = positionButton;
            ;
            /**
             * Helper for setting position of a svg ellipse
             * @param ellipse ellipse to set position of.
             * @param cx Center x.
             * @param cy Center x.
             * @param width Width to set.
             * @param height Height to set.
             */
            function positionEllipse(ellipse, cx, cy, width, height) {
                ellipse.transition()
                    .attr('cx', cx)
                    .attr('cy', cy)
                    .attr('rx', width / 2)
                    .attr('ry', height / 2);
            }
            scene.positionEllipse = positionEllipse;
            ;
            /**
             * @param {number} stat A stat for a health pill (such as mean or variance).
             * @param {boolean} shouldRoundOnesDigit Whether to round this number to the
             *     ones digit. Useful for say int, uint, and bool output types.
             * @return {string} A human-friendly string representation of that stat.
             */
            function humanizeHealthPillStat(stat, shouldRoundOnesDigit) {
                if (shouldRoundOnesDigit) {
                    return stat.toFixed(0);
                }
                if (Math.abs(stat) >= 1) {
                    return stat.toFixed(1);
                }
                return stat.toExponential(1);
            }
            scene.humanizeHealthPillStat = humanizeHealthPillStat;
            /**
             * Get text content describing a health pill.
             */
            function _getHealthPillTextContent(healthPill, totalCount, elementsBreakdown, numericStats) {
                var text = 'Device: ' + healthPill.device_name + '\n';
                text += 'dtype: ' + healthPill.dtype + '\n';
                var shapeStr = '(scalar)';
                if (healthPill.shape.length > 0) {
                    shapeStr = '(' + healthPill.shape.join(',') + ')';
                }
                text += '\nshape: ' + shapeStr + '\n\n';
                text += '#(elements): ' + totalCount + '\n';
                var breakdownItems = [];
                for (var i = 0; i < elementsBreakdown.length; i++) {
                    if (elementsBreakdown[i] > 0) {
                        breakdownItems.push('#(' + scene.healthPillEntries[i].label + '): ' + elementsBreakdown[i]);
                    }
                }
                text += breakdownItems.join(', ') + '\n\n';
                // In some cases (e.g., size-0 tensors; all elements are nan or inf) the
                // min/max and mean/stddev stats are meaningless.
                if (numericStats.max >= numericStats.min) {
                    text += 'min: ' + numericStats.min + ', max: ' + numericStats.max + '\n';
                    text += 'mean: ' + numericStats.mean + ', stddev: ' + numericStats.stddev;
                }
                return text;
            }
            /**
             * Renders a health pill for an op atop a node.
             * nodeGroupElement: The SVG element in which to render.
             * healthPill: A list of backend.HealthPill objects.
             * nodeInfo: Info on the associated node.
             * healthPillId: A unique numeric ID assigned to this health pill.
             * healthPillWidth: Optional width of the health pill.
             * healthPillHeight: Optional height of the health pill.
             * healthPillYOffset: Optional y-offset of the health pill (that is, the
             *   color-coded region).
             * textOffset: Optional value for the x-offset of the top text label
             *   relative to the left edge of the health pill. If not provided, will
             *   default to `healthPillWidth / 2`.
             */
            function addHealthPill(nodeGroupElement, healthPill, nodeInfo, healthPillId, healthPillWidth, healthPillHeight, healthPillYOffset, textXOffset) {
                if (healthPillWidth === void 0) { healthPillWidth = 60; }
                if (healthPillHeight === void 0) { healthPillHeight = 10; }
                if (healthPillYOffset === void 0) { healthPillYOffset = 0; }
                // Check if text already exists at location.
                d3.select(nodeGroupElement.parentNode).selectAll('.health-pill').remove();
                if (!healthPill) {
                    return;
                }
                var lastHealthPillData = healthPill.value;
                // For now, we only visualize the 6 values that summarize counts of tensor
                // elements of various categories: -Inf, negative, 0, positive, Inf, and NaN.
                var lastHealthPillElementsBreakdown = lastHealthPillData.slice(2, 8);
                var nanCount = lastHealthPillElementsBreakdown[0];
                var negInfCount = lastHealthPillElementsBreakdown[1];
                var posInfCount = lastHealthPillElementsBreakdown[5];
                var totalCount = lastHealthPillData[1];
                var numericStats = {
                    min: lastHealthPillData[8],
                    max: lastHealthPillData[9],
                    mean: lastHealthPillData[10],
                    stddev: Math.sqrt(lastHealthPillData[11])
                };
                if (healthPillWidth == null) {
                    healthPillWidth = 60;
                }
                if (healthPillHeight == null) {
                    healthPillHeight = 10;
                }
                if (healthPillYOffset == null) {
                    healthPillYOffset = 0;
                }
                if (nodeInfo != null && nodeInfo.node.type === tf.graph.NodeType.OP) {
                    // Use a smaller health pill for op nodes (rendered as smaller ellipses).
                    healthPillWidth /= 2;
                    healthPillHeight /= 2;
                }
                var healthPillGroup = document.createElementNS(scene.SVG_NAMESPACE, 'g');
                healthPillGroup.classList.add('health-pill');
                // Define the gradient for the health pill.
                var healthPillDefs = document.createElementNS(scene.SVG_NAMESPACE, 'defs');
                healthPillGroup.appendChild(healthPillDefs);
                var healthPillGradient = document.createElementNS(scene.SVG_NAMESPACE, 'linearGradient');
                // Every element in a web page must have a unique ID.
                var healthPillGradientId = 'health-pill-gradient-' + healthPillId;
                healthPillGradient.setAttribute('id', healthPillGradientId);
                var cumulativeCount = 0;
                var previousOffset = '0%';
                for (var i = 0; i < lastHealthPillElementsBreakdown.length; i++) {
                    if (!lastHealthPillElementsBreakdown[i]) {
                        // Exclude empty categories.
                        continue;
                    }
                    cumulativeCount += lastHealthPillElementsBreakdown[i];
                    // Create a color interval using 2 stop elements.
                    var stopElement0 = document.createElementNS(scene.SVG_NAMESPACE, 'stop');
                    stopElement0.setAttribute('offset', previousOffset);
                    stopElement0.setAttribute('stop-color', scene.healthPillEntries[i].background_color);
                    healthPillGradient.appendChild(stopElement0);
                    var stopElement1 = document.createElementNS(scene.SVG_NAMESPACE, 'stop');
                    var percent = (cumulativeCount * 100 / totalCount) + '%';
                    stopElement1.setAttribute('offset', percent);
                    stopElement1.setAttribute('stop-color', scene.healthPillEntries[i].background_color);
                    healthPillGradient.appendChild(stopElement1);
                    previousOffset = percent;
                }
                healthPillDefs.appendChild(healthPillGradient);
                // Create the rectangle for the health pill.
                var rect = document.createElementNS(scene.SVG_NAMESPACE, 'rect');
                rect.setAttribute('fill', 'url(#' + healthPillGradientId + ')');
                rect.setAttribute('width', String(healthPillWidth));
                rect.setAttribute('height', String(healthPillHeight));
                rect.setAttribute('y', String(healthPillYOffset));
                healthPillGroup.appendChild(rect);
                // Show a title with specific counts on hover.
                var titleSvg = document.createElementNS(scene.SVG_NAMESPACE, 'title');
                titleSvg.textContent = _getHealthPillTextContent(healthPill, totalCount, lastHealthPillElementsBreakdown, numericStats);
                healthPillGroup.appendChild(titleSvg);
                // Center this health pill just right above the node for the op.
                var shouldRoundOnesDigit = false;
                if (nodeInfo != null) {
                    var healthPillX = nodeInfo.x - healthPillWidth / 2;
                    var healthPillY = nodeInfo.y - healthPillHeight - nodeInfo.height / 2 - 2;
                    if (nodeInfo.labelOffset < 0) {
                        // The label is positioned above the node. Do not occlude the label.
                        healthPillY += nodeInfo.labelOffset;
                    }
                    healthPillGroup.setAttribute('transform', 'translate(' + healthPillX + ', ' + healthPillY + ')');
                    if (lastHealthPillElementsBreakdown[2] ||
                        lastHealthPillElementsBreakdown[3] ||
                        lastHealthPillElementsBreakdown[4]) {
                        // At least 1 "non-Inf and non-NaN" value exists (a -, 0, or + value). Show
                        // stats on tensor values.
                        // Determine if we should display the output range as integers.
                        var node_1 = nodeInfo.node;
                        var attributes = node_1.attr;
                        if (attributes && attributes.length) {
                            // Find the attribute for output type if there is one.
                            for (var i = 0; i < attributes.length; i++) {
                                if (attributes[i].key === 'T') {
                                    // Note whether the output type is an integer.
                                    var outputType = attributes[i].value['type'];
                                    shouldRoundOnesDigit =
                                        outputType && /^DT_(BOOL|INT|UINT)/.test(outputType);
                                    break;
                                }
                            }
                        }
                    }
                }
                var statsSvg = document.createElementNS(scene.SVG_NAMESPACE, 'text');
                if (Number.isFinite(numericStats.min) && Number.isFinite(numericStats.max)) {
                    var minString = humanizeHealthPillStat(numericStats.min, shouldRoundOnesDigit);
                    var maxString = humanizeHealthPillStat(numericStats.max, shouldRoundOnesDigit);
                    if (totalCount > 1) {
                        statsSvg.textContent = minString + ' ~ ' + maxString;
                    }
                    else {
                        statsSvg.textContent = minString;
                    }
                    if (nanCount > 0 || negInfCount > 0 || posInfCount > 0) {
                        statsSvg.textContent += ' (';
                        var badValueStrings = [];
                        if (nanCount > 0) {
                            badValueStrings.push("NaN\u00D7" + nanCount);
                        }
                        if (negInfCount > 0) {
                            badValueStrings.push("-\u221E\u00D7" + negInfCount);
                        }
                        if (posInfCount > 0) {
                            badValueStrings.push("+\u221E\u00D7" + posInfCount);
                        }
                        statsSvg.textContent += badValueStrings.join('; ') + ')';
                    }
                }
                else {
                    statsSvg.textContent = '(No finite elements)';
                }
                statsSvg.classList.add('health-pill-stats');
                if (textXOffset == null) {
                    textXOffset = healthPillWidth / 2;
                }
                statsSvg.setAttribute('x', String(textXOffset));
                statsSvg.setAttribute('y', String(healthPillYOffset - 2));
                healthPillGroup.appendChild(statsSvg);
                Polymer.dom(nodeGroupElement.parentNode).appendChild(healthPillGroup);
            }
            scene.addHealthPill = addHealthPill;
            /**
             * Adds health pills (which visualize tensor summaries) to a graph group.
             * @param svgRoot The root SVG element of the graph to add heath pills to.
             * @param nodeNamesToHealthPills An object mapping node name to health pill.
             * @param colors A list of colors to use.
             */
            function addHealthPills(svgRoot, nodeNamesToHealthPills, healthPillStepIndex) {
                if (!nodeNamesToHealthPills) {
                    // No health pill information available.
                    return;
                }
                // We generate a unique ID for each health pill because the ID of each element
                // in a web page must be unique, and each health pill generates a gradient
                // that its code later refers to.
                var healthPillId = 1;
                var svgRootSelection = d3.select(svgRoot);
                svgRootSelection.selectAll('g.nodeshape')
                    .each(function (nodeInfo) {
                    // Only show health pill data for this node if it is available.
                    var healthPills = nodeNamesToHealthPills[nodeInfo.node.name];
                    var healthPill = healthPills ? healthPills[healthPillStepIndex] : null;
                    addHealthPill(this, healthPill, nodeInfo, healthPillId++);
                });
            }
            scene.addHealthPills = addHealthPills;
            ;
        })(scene = graph.scene || (graph.scene = {}));
    })(graph = tf.graph || (tf.graph = {}));
})(tf || (tf = {})); // close module
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2NlbmUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJzY2VuZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7Ozs7Ozs7OztnRkFhZ0Y7QUFDaEYsSUFBTyxFQUFFLENBMDFCUjtBQTExQkQsV0FBTyxFQUFFO0lBQUMsSUFBQSxLQUFLLENBMDFCZDtJQTExQlMsV0FBQSxLQUFLO1FBQUMsSUFBQSxLQUFLLENBMDFCcEI7UUExMUJlLFdBQUEsS0FBSztZQUNOLG1CQUFhLEdBQUcsNEJBQTRCLENBQUM7WUFFMUQsa0RBQWtEO1lBQ3ZDLFdBQUssR0FBRztnQkFDakIsSUFBSSxFQUFFO29CQUNKLG1DQUFtQztvQkFDbkMsU0FBUyxFQUFFLE9BQU87b0JBQ2xCLGlEQUFpRDtvQkFDakQsS0FBSyxFQUFFLE1BQU07b0JBQ2Isa0VBQWtFO29CQUNsRSxLQUFLLEVBQUUsV0FBVztvQkFDbEIsZ0VBQWdFO29CQUNoRSxZQUFZLEVBQUUsaUJBQWlCO29CQUMvQiwyQ0FBMkM7b0JBQzNDLEtBQUssRUFBRSxXQUFXO29CQUNsQixnRUFBZ0U7b0JBQ2hFLHFDQUFxQztvQkFDckMsZ0JBQWdCLEVBQUUsaUJBQWlCO29CQUNuQywyREFBMkQ7b0JBQzNELGFBQWEsRUFBRSxjQUFjO29CQUM3Qix1Q0FBdUM7b0JBQ3ZDLGFBQWEsRUFBRSxjQUFjO29CQUM3Qix5Q0FBeUM7b0JBQ3pDLGVBQWUsRUFBRSxnQkFBZ0I7aUJBQ2xDO2dCQUNELElBQUksRUFBRTtvQkFDSixTQUFTLEVBQUUsT0FBTztvQkFDbEIsS0FBSyxFQUFFLE1BQU07b0JBQ2IsSUFBSSxFQUFFLFVBQVU7b0JBQ2hCLGNBQWMsRUFBRSxlQUFlO29CQUMvQixRQUFRLEVBQUUsU0FBUztvQkFDbkIsVUFBVSxFQUFFLGdCQUFnQjtvQkFDNUIsUUFBUSxFQUFFLGNBQWM7b0JBQ3hCLFVBQVUsRUFBRSxZQUFZO2lCQUN6QjtnQkFDRCxVQUFVLEVBQUU7b0JBQ1YsTUFBTSxFQUFFLGlCQUFpQjtvQkFDekIsS0FBSyxFQUFFLGdCQUFnQjtvQkFDdkIsS0FBSyxFQUFFLFlBQVk7b0JBQ25CLElBQUksRUFBRSxpQkFBaUI7b0JBQ3ZCLElBQUksRUFBRSxpQkFBaUI7b0JBQ3ZCLFlBQVksRUFBRSx5QkFBeUI7b0JBQ3ZDLEtBQUssRUFBRSxrQkFBa0I7b0JBQ3pCLFFBQVEsRUFBRSxxQkFBcUI7aUJBQ2hDO2dCQUNELEtBQUssRUFBRTtvQkFDTCxLQUFLLEVBQUUsT0FBTztvQkFDZCxJQUFJLEVBQUUsTUFBTTtvQkFDWixnQkFBZ0IsRUFBRSxrQkFBa0I7b0JBQ3BDLFNBQVMsRUFBRSxZQUFZO29CQUN2QixVQUFVLEVBQUUsYUFBYTtpQkFDMUI7Z0JBQ0QsUUFBUSxFQUFFLEVBQUMsS0FBSyxFQUFFLFVBQVUsRUFBQztnQkFDN0IsTUFBTSxFQUFFLElBQUk7Z0JBQ1osUUFBUSxFQUFFLE1BQU07Z0JBQ2hCLFVBQVUsRUFBRSxRQUFRO2dCQUNwQixVQUFVLEVBQUUsUUFBUTtnQkFDcEIsWUFBWSxFQUFFLFVBQVU7YUFDekIsQ0FBQztZQUVGOztlQUVHO1lBQ0gsSUFBTSxpQkFBaUIsR0FBRyxHQUFHLENBQUM7WUFDOUIsSUFBTSxrQkFBa0IsR0FBRyxHQUFHLENBQUM7WUF1Q3BCLHVCQUFpQixHQUFzQjtnQkFDaEQ7b0JBQ0UsZ0JBQWdCLEVBQUUsU0FBUztvQkFDM0IsS0FBSyxFQUFFLEtBQUs7aUJBQ2I7Z0JBQ0Q7b0JBQ0UsZ0JBQWdCLEVBQUUsU0FBUztvQkFDM0IsS0FBSyxFQUFFLElBQUk7aUJBQ1o7Z0JBQ0Q7b0JBQ0UsZ0JBQWdCLEVBQUUsU0FBUztvQkFDM0IsS0FBSyxFQUFFLEdBQUc7aUJBQ1g7Z0JBQ0Q7b0JBQ0UsZ0JBQWdCLEVBQUUsU0FBUztvQkFDM0IsS0FBSyxFQUFFLEdBQUc7aUJBQ1g7Z0JBQ0Q7b0JBQ0UsZ0JBQWdCLEVBQUUsU0FBUztvQkFDM0IsS0FBSyxFQUFFLEdBQUc7aUJBQ1g7Z0JBQ0Q7b0JBQ0UsZ0JBQWdCLEVBQUUsU0FBUztvQkFDM0IsS0FBSyxFQUFFLElBQUk7aUJBQ1o7YUFDRixDQUFDO1lBRUY7Ozs7Ozs7ZUFPRztZQUNILGFBQW9CLEdBQUcsRUFBRSxLQUFLLEVBQUUsTUFBTSxFQUFFLFFBQVE7Z0JBQzlDLElBQUksT0FBTyxHQUFHLEdBQUcsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO2dCQUMxQyxJQUFJLFNBQVMsR0FBRyxJQUFJLENBQUM7Z0JBQ3JCLElBQUk7b0JBQ0YsU0FBUyxHQUFHLEtBQUssQ0FBQyxPQUFPLEVBQUUsQ0FBQztvQkFDNUIsSUFBSSxTQUFTLENBQUMsS0FBSyxLQUFLLENBQUMsRUFBRTt3QkFDekIsaUVBQWlFO3dCQUNqRSxPQUFPO3FCQUNSO2lCQUNGO2dCQUFDLE9BQU8sQ0FBQyxFQUFFO29CQUNWLG9EQUFvRDtvQkFDcEQseUJBQXlCO29CQUN6QixPQUFPO2lCQUNSO2dCQUNELElBQUksS0FBSyxHQUFHLEdBQUc7b0JBQ1gsSUFBSSxDQUFDLEdBQUcsQ0FDSixPQUFPLENBQUMsS0FBSyxHQUFHLFNBQVMsQ0FBQyxLQUFLLEVBQUUsT0FBTyxDQUFDLE1BQU0sR0FBRyxTQUFTLENBQUMsTUFBTSxFQUNsRSxDQUFDLENBQUMsQ0FBQztnQkFDWCxJQUFJLE1BQU0sR0FBRyxNQUFBLE1BQU0sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDO2dCQUNqQyxJQUFNLFNBQVMsR0FBRyxFQUFFLENBQUMsWUFBWTtxQkFDNUIsS0FBSyxDQUFDLEtBQUssQ0FBQztxQkFDWixTQUFTLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxXQUFXLEVBQUUsTUFBTSxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztnQkFFdEUsRUFBRSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7cUJBQ1QsVUFBVSxFQUFFO3FCQUNaLFFBQVEsQ0FBQyxHQUFHLENBQUM7cUJBQ2IsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLEVBQUUsU0FBUyxDQUFDO3FCQUNqQyxFQUFFLENBQUMsWUFBWSxFQUFFO29CQUNoQiw2Q0FBNkM7b0JBQzdDLDREQUE0RDtvQkFDNUQsMkNBQTJDO29CQUMzQyxNQUFNLENBQUMsRUFBRSxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsQ0FBQztvQkFDOUIsUUFBUSxFQUFFLENBQUM7Z0JBQ2IsQ0FBQyxDQUFDLENBQUM7WUFDWCxDQUFDO1lBbENpQixTQUFHLE1Ba0NwQixDQUFBO1lBQUEsQ0FBQztZQUVGOzs7Ozs7Ozs7O2VBVUc7WUFDSCxtQkFBMEIsUUFBZ0IsRUFBRSxHQUFHLEVBQUUsS0FBSyxFQUFFLE1BQU07Z0JBQzVELElBQUksSUFBSSxHQUFnQixFQUFFO3FCQUNWLE1BQU0sQ0FBQyxjQUFjLEdBQUcsUUFBUSxHQUFHLEtBQUssR0FBRyxNQUFBLEtBQUssQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDO3FCQUM1RCxJQUFJLEVBQUUsQ0FBQztnQkFDdkIsSUFBSSxDQUFDLElBQUksRUFBRTtvQkFDVCxPQUFPLEtBQUssQ0FBQztpQkFDZDtnQkFFRCxxREFBcUQ7Z0JBQ3JELHdDQUF3QztnQkFDeEMsSUFBSSxPQUFPLEdBQUcsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDO2dCQUM3QixJQUFJLE9BQU8sR0FBRyxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7Z0JBQ2xDLElBQUksT0FBTyxHQUFHLEdBQUcsQ0FBQyxjQUFjLEVBQUUsQ0FBQztnQkFDbkMsSUFBSSxPQUFPLEdBQUcsR0FBRyxDQUFDLGNBQWMsRUFBRSxDQUFDO2dCQUNuQyxPQUFPLENBQUMsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxDQUFDLENBQUM7Z0JBQ3RCLE9BQU8sQ0FBQyxDQUFDLEdBQUcsT0FBTyxDQUFDLENBQUMsQ0FBQztnQkFDdEIsT0FBTyxDQUFDLENBQUMsR0FBRyxPQUFPLENBQUMsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxLQUFLLENBQUM7Z0JBQ3RDLE9BQU8sQ0FBQyxDQUFDLEdBQUcsT0FBTyxDQUFDLENBQUMsR0FBRyxPQUFPLENBQUMsTUFBTSxDQUFDO2dCQUN2QyxPQUFPLEdBQUcsT0FBTyxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsQ0FBQztnQkFDM0MsT0FBTyxHQUFHLE9BQU8sQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDLENBQUM7Z0JBQzNDLElBQUksaUJBQWlCLEdBQUcsVUFBQyxLQUFLLEVBQUUsR0FBRyxFQUFFLFVBQVUsRUFBRSxVQUFVO29CQUN6RCwwREFBMEQ7b0JBQzFELE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxVQUFVLElBQUksR0FBRyxHQUFHLFVBQVUsQ0FBQyxDQUFDO2dCQUNuRCxDQUFDLENBQUM7Z0JBQ0YsSUFBSSxPQUFPLEdBQUcsR0FBRyxDQUFDLHFCQUFxQixFQUFFLENBQUM7Z0JBRTFDLHdFQUF3RTtnQkFDeEUsSUFBTSxlQUFlLEdBQUcsT0FBTyxDQUFDLElBQUksR0FBRyxPQUFPLENBQUMsS0FBSyxHQUFHLGlCQUFpQixDQUFDO2dCQUN6RSxJQUFNLGFBQWEsR0FBRyxPQUFPLENBQUMsR0FBRyxHQUFHLE9BQU8sQ0FBQyxNQUFNLEdBQUcsa0JBQWtCLENBQUM7Z0JBQ3hFLElBQUksaUJBQWlCLENBQUMsT0FBTyxDQUFDLENBQUMsRUFBRSxPQUFPLENBQUMsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxJQUFJLEVBQUUsZUFBZSxDQUFDO29CQUN0RSxpQkFBaUIsQ0FBQyxPQUFPLENBQUMsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxDQUFDLEVBQUUsT0FBTyxDQUFDLEdBQUcsRUFBRSxhQUFhLENBQUMsRUFBRTtvQkFDdkUsNEVBQTRFO29CQUM1RSwwRUFBMEU7b0JBQzFFLHdFQUF3RTtvQkFDeEUsMkVBQTJFO29CQUMzRSxpQkFBaUI7b0JBQ2pCLElBQUksT0FBTyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsR0FBRyxPQUFPLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO29CQUMxQyxJQUFJLE9BQU8sR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEdBQUcsT0FBTyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztvQkFDMUMsSUFBSSxFQUFFLEdBQUcsT0FBTyxDQUFDLElBQUksR0FBRyxPQUFPLENBQUMsS0FBSyxHQUFHLENBQUMsR0FBRyxPQUFPLENBQUM7b0JBQ3BELElBQUksRUFBRSxHQUFHLE9BQU8sQ0FBQyxHQUFHLEdBQUcsT0FBTyxDQUFDLE1BQU0sR0FBRyxDQUFDLEdBQUcsT0FBTyxDQUFDO29CQUVwRCx5RUFBeUU7b0JBQ3pFLG9FQUFvRTtvQkFDcEUsSUFBTSxZQUFZLEdBQUcsRUFBRSxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsQ0FBQztvQkFDM0MsRUFBRSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxVQUFVLEVBQUUsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUMxQyxNQUFNLENBQUMsV0FBVyxFQUNsQixFQUFFLEdBQUcsWUFBWSxDQUFDLENBQUMsRUFDbkIsRUFBRSxHQUFHLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFFekIsT0FBTyxJQUFJLENBQUM7aUJBQ2I7Z0JBQ0QsT0FBTyxLQUFLLENBQUM7WUFDZixDQUFDO1lBcERlLGVBQVMsWUFvRHhCLENBQUE7WUFBQSxDQUFDO1lBRUY7Ozs7Ozs7Ozs7ZUFVRztZQUNILDZCQUNJLFNBQVMsRUFBRSxPQUFlLEVBQUUsU0FBNkIsRUFBRSxNQUFPO2dCQUNwRSxJQUFJLEtBQUssR0FBRyxXQUFXLENBQUMsU0FBUyxFQUFFLE9BQU8sRUFBRSxTQUFTLENBQUMsQ0FBQztnQkFDdkQsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLEVBQUUsRUFBRTtvQkFDbEIsT0FBTyxLQUFLLENBQUM7aUJBQ2Q7Z0JBQ0QsSUFBSSxVQUFVLEdBQ1YsUUFBUSxDQUFDLGVBQWUsQ0FBQyw0QkFBNEIsRUFBRSxPQUFPLENBQUMsQ0FBQztnQkFFcEUsSUFBSSxTQUFTLFlBQVksS0FBSyxFQUFFO29CQUM5QixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsU0FBUyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTt3QkFDekMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7cUJBQ3hDO2lCQUNGO3FCQUFNO29CQUNMLFVBQVUsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDO2lCQUNyQztnQkFFRCxJQUFJLE1BQU0sRUFBRSxFQUFFLDJCQUEyQjtvQkFDdkMsU0FBUyxDQUFDLElBQUksRUFBRSxDQUFDLFlBQVksQ0FBQyxVQUFVLEVBQUUsTUFBTSxDQUFDLENBQUM7aUJBQ25EO3FCQUFNLEVBQUUsb0JBQW9CO29CQUMzQixTQUFTLENBQUMsSUFBSSxFQUFFLENBQUMsV0FBVyxDQUFDLFVBQVUsQ0FBQyxDQUFDO2lCQUMxQztnQkFDRCxPQUFPLEVBQUUsQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDO29CQUNuQixtREFBbUQ7cUJBQ2xELEtBQUssQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQztZQUNyQyxDQUFDO1lBekJlLHlCQUFtQixzQkF5QmxDLENBQUE7WUFBQSxDQUFDO1lBRUY7Ozs7Ozs7OztlQVNHO1lBQ0gscUJBQ0ksU0FBUyxFQUFFLE9BQWUsRUFBRSxTQUE2QjtnQkFDM0QsSUFBSSxRQUFRLEdBQUcsU0FBUyxDQUFDLElBQUksRUFBRSxDQUFDLFVBQVUsQ0FBQztnQkFDM0MsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFFBQVEsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7b0JBQ3hDLElBQUksS0FBSyxHQUFHLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDeEIsSUFBSSxLQUFLLENBQUMsT0FBTyxLQUFLLE9BQU8sRUFBRTt3QkFDN0IsSUFBSSxTQUFTLFlBQVksS0FBSyxFQUFFOzRCQUM5QixJQUFJLGFBQWEsR0FBRyxJQUFJLENBQUM7NEJBQ3pCLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxTQUFTLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO2dDQUN6QyxhQUFhO29DQUNULGFBQWEsSUFBSSxLQUFLLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzs2QkFDN0Q7NEJBQ0QsSUFBSSxhQUFhLEVBQUU7Z0NBQ2pCLE9BQU8sRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQzs2QkFDekI7eUJBQ0Y7NkJBQU0sSUFBSSxDQUFDLENBQUMsU0FBUyxJQUFJLEtBQUssQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUU7NEJBQzlELE9BQU8sRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQzt5QkFDekI7cUJBQ0Y7aUJBQ0Y7Z0JBQ0QsT0FBTyxFQUFFLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQ3pCLENBQUM7WUFyQmUsaUJBQVcsY0FxQjFCLENBQUE7WUFBQSxDQUFDO1lBRUY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztlQThCRztZQUNILG9CQUEyQixTQUFTLEVBQ2hDLFVBQXNDLEVBQ3RDLFlBQVksRUFDWixVQUFrQjtnQkFDcEIsVUFBVSxHQUFHLFVBQVUsSUFBSSxNQUFBLEtBQUssQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDO2dCQUM3QyxJQUFJLGVBQWUsR0FBRyxXQUFXLENBQUMsU0FBUyxFQUFFLEdBQUcsRUFBRSxVQUFVLENBQUMsQ0FBQyxLQUFLLEVBQUUsQ0FBQztnQkFDdEUsSUFBSSxVQUFVLEdBQUcsbUJBQW1CLENBQUMsU0FBUyxFQUFFLEdBQUcsRUFBRSxVQUFVLENBQUMsQ0FBQztnQkFFakUsT0FBTztnQkFDUCxJQUFJLFNBQVMsR0FBRyxtQkFBbUIsQ0FBQyxVQUFVLEVBQUUsR0FBRyxFQUFFLE1BQUEsS0FBSyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDdkUsSUFBSSxTQUFTLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLEtBQUssRUFBRSxFQUFFLFVBQUMsS0FBSyxFQUFFLElBQUk7b0JBQ2pELElBQUksSUFBSSxHQUFHLFVBQVUsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO29CQUMzQyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRTt3QkFDbEIsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztxQkFDbEI7b0JBQ0QsT0FBTyxLQUFLLENBQUM7Z0JBQ2YsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO2dCQUV2QixJQUFJLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxLQUFLLE1BQUEsUUFBUSxDQUFDLE1BQU0sRUFBRTtvQkFDNUMscUVBQXFFO29CQUNyRSxzRUFBc0U7b0JBQ3RFLDBCQUEwQjtvQkFDMUIsU0FBUyxDQUFDLE9BQU8sRUFBRSxDQUFDO2lCQUNyQjtnQkFFRCxvREFBb0Q7Z0JBQ3BELE1BQUEsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLEVBQUUsVUFBVSxDQUFDLFNBQVMsRUFBRSxZQUFZLENBQUMsQ0FBQztnQkFFL0Qsa0VBQWtFO2dCQUNsRSxNQUFBLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxFQUFFLFNBQVMsRUFBRSxZQUFZLENBQUMsQ0FBQztnQkFFcEQsYUFBYTtnQkFDYixJQUFJLFVBQVUsQ0FBQyxpQkFBaUIsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO29CQUMzQyxJQUFJLGNBQWMsR0FDZCxtQkFBbUIsQ0FBQyxVQUFVLEVBQUUsR0FBRyxFQUFFLE1BQUEsS0FBSyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQztvQkFDaEUsTUFBQSxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsRUFBRSxVQUFVLENBQUMsaUJBQWlCLEVBQ3hELFlBQVksQ0FBQyxDQUFDO2lCQUNuQjtxQkFBTTtvQkFDTCxXQUFXLENBQUMsVUFBVSxFQUFFLEdBQUcsRUFBRSxNQUFBLEtBQUssQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsTUFBTSxFQUFFLENBQUM7aUJBQzlEO2dCQUVELGNBQWM7Z0JBQ2QsSUFBSSxVQUFVLENBQUMsa0JBQWtCLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtvQkFDNUMsSUFBSSxlQUFlLEdBQ2YsbUJBQW1CLENBQUMsVUFBVSxFQUFFLEdBQUcsRUFBRSxNQUFBLEtBQUssQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLENBQUM7b0JBQ2pFLE1BQUEsSUFBSSxDQUFDLFVBQVUsQ0FBQyxlQUFlLEVBQUUsVUFBVSxDQUFDLGtCQUFrQixFQUMxRCxZQUFZLENBQUMsQ0FBQztpQkFDbkI7cUJBQU07b0JBQ0wsV0FBVyxDQUFDLFVBQVUsRUFBRSxHQUFHLEVBQUUsTUFBQSxLQUFLLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDO2lCQUMvRDtnQkFFRCxvQkFBb0I7Z0JBQ3BCLElBQUksVUFBVSxDQUFDLHVCQUF1QixDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7b0JBQ2pELElBQUksZUFBZSxHQUNmLG1CQUFtQixDQUFDLFVBQVUsRUFBRSxHQUFHLEVBQUUsTUFBQSxLQUFLLENBQUMsS0FBSyxDQUFDLGdCQUFnQixDQUFDLENBQUM7b0JBQ3ZFLE1BQUEsSUFBSSxDQUFDLFVBQVUsQ0FBQyxlQUFlLEVBQUUsVUFBVSxDQUFDLHVCQUF1QixFQUMvRCxZQUFZLENBQUMsQ0FBQztpQkFDbkI7cUJBQU07b0JBQ0wsV0FBVyxDQUFDLFVBQVUsRUFBRSxHQUFHLEVBQUUsTUFBQSxLQUFLLENBQUMsS0FBSyxDQUFDLGdCQUFnQixDQUFDLENBQUMsTUFBTSxFQUFFLENBQUM7aUJBQ3JFO2dCQUVELFFBQVEsQ0FBQyxVQUFVLEVBQUUsVUFBVSxDQUFDLENBQUM7Z0JBRWpDLHNEQUFzRDtnQkFDdEQsSUFBSSxlQUFlLEVBQUU7b0JBQ25CLFVBQVUsQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQyxDQUFDLFVBQVUsRUFBRSxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFDLENBQUM7aUJBQy9EO2dCQUVELE9BQU8sVUFBVSxDQUFDO1lBQ3BCLENBQUM7WUFyRWUsZ0JBQVUsYUFxRXpCLENBQUE7WUFBQSxDQUFDO1lBRUY7Ozs7OztlQU1HO1lBQ0gsa0JBQWtCLFVBQVUsRUFBRSxVQUFzQztnQkFDbEUsMkVBQTJFO2dCQUMzRSwwRUFBMEU7Z0JBQzFFLDBFQUEwRTtnQkFDMUUsa0JBQWtCO2dCQUNsQixJQUFJLFVBQVUsR0FBRyxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksS0FBSyxNQUFBLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDekQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFBLE1BQU0sQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUM7Z0JBRTlDLE9BQU87Z0JBQ1AsU0FBUyxDQUFDLFdBQVcsQ0FBQyxVQUFVLEVBQUUsR0FBRyxFQUFFLE1BQUEsS0FBSyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEVBQUUsVUFBVSxDQUFDLENBQUM7Z0JBRXpFLGFBQWE7Z0JBQ2IsSUFBSSxZQUFZLEdBQUcsVUFBVSxDQUFDLGlCQUFpQixDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7Z0JBQzNELElBQUksYUFBYSxHQUFHLFVBQVUsQ0FBQyxrQkFBa0IsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO2dCQUM3RCxJQUFJLG1CQUFtQixHQUFHLFVBQVUsQ0FBQyx1QkFBdUIsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO2dCQUV4RSxJQUFJLE1BQU0sR0FBRyxNQUFBLE1BQU0sQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUM7Z0JBRXhELElBQUksUUFBUSxHQUFHLENBQUMsQ0FBQztnQkFDakIsSUFBSSxZQUFZLEVBQUU7b0JBQ2hCLFFBQVEsSUFBSSxVQUFVLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQztpQkFDNUM7Z0JBQ0QsSUFBSSxhQUFhLEVBQUU7b0JBQ2pCLFFBQVEsSUFBSSxVQUFVLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQztpQkFDNUM7Z0JBRUQsSUFBSSxZQUFZLEVBQUU7b0JBQ2hCLElBQUksVUFBVSxHQUFHLFVBQVUsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDO29CQUMxQyxJQUFJLFFBQVEsR0FBRyxNQUFBLE1BQU0sQ0FBQyxhQUFhLEVBQUU7d0JBQ25DLFVBQVUsR0FBRyxVQUFVLEdBQUcsTUFBQSxNQUFNLENBQUMsYUFBYTs0QkFDMUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDO3FCQUN2Qzt5QkFBTTt3QkFDTCxVQUFVLEdBQUcsVUFBVTs0QkFDbkIsVUFBVSxDQUFDLFlBQVksQ0FBQyxLQUFLLEdBQUcsQ0FBQyxHQUFHLFVBQVUsQ0FBQyxhQUFhLENBQUMsS0FBSzs0QkFDbEUsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7cUJBQ2xDO29CQUNELFVBQVUsR0FBRyxVQUFVO3dCQUNuQixVQUFVLENBQUMsbUJBQW1CLENBQUMsS0FBSzt3QkFDcEMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDdkMsU0FBUyxDQUNMLFdBQVcsQ0FBQyxVQUFVLEVBQUUsR0FBRyxFQUFFLE1BQUEsS0FBSyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsRUFBRSxVQUFVLEVBQy9ELFVBQVUsQ0FBQyxDQUFDO2lCQUNqQjtnQkFFRCxjQUFjO2dCQUNkLElBQUksYUFBYSxFQUFFO29CQUNqQixJQUFJLFdBQVcsR0FBRyxVQUFVLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQztvQkFDM0MsSUFBSSxRQUFRLEdBQUcsTUFBQSxNQUFNLENBQUMsYUFBYSxFQUFFO3dCQUNuQyxXQUFXLEdBQUcsV0FBVyxHQUFHLE1BQUEsTUFBTSxDQUFDLGFBQWE7NEJBQzVDLFVBQVUsQ0FBQyxhQUFhLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQztxQkFDeEM7eUJBQU07d0JBQ0wsV0FBVyxJQUFJLFVBQVUsQ0FBQyxhQUFhLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQztxQkFDbkQ7b0JBQ0QsV0FBVyxHQUFHLFdBQVc7d0JBQ3ZCLFVBQVUsQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLO3dCQUNwQyxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUNyQyxTQUFTLENBQ0wsV0FBVyxDQUFDLFVBQVUsRUFBRSxHQUFHLEVBQUUsTUFBQSxLQUFLLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxFQUFFLFdBQVcsRUFDakUsVUFBVSxDQUFDLENBQUM7aUJBQ2pCO2dCQUVELElBQUksbUJBQW1CLEVBQUU7b0JBQ3ZCLElBQUksd0JBQXdCLEdBQUcsVUFBVSxDQUFDLE9BQU8sQ0FBQyxLQUFLO3dCQUNuRCxVQUFVLENBQUMsbUJBQW1CLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQztvQkFDN0MsU0FBUyxDQUNMLFdBQVcsQ0FBQyxVQUFVLEVBQUUsR0FBRyxFQUFFLE1BQUEsS0FBSyxDQUFDLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxFQUMxRCx3QkFBd0IsRUFDeEIsVUFBVSxDQUFDLENBQUM7aUJBQ2pCO1lBQ0gsQ0FBQztZQUFBLENBQUM7WUFFRix1RUFBdUU7WUFDdkUsK0JBQXNDLFVBQVUsRUFBRSxZQUFZO2dCQUM1RCxFQUFFLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxPQUFPLEVBQUU7b0JBQ2hDLFlBQVksQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUM7Z0JBQ3BDLENBQUMsQ0FBQyxDQUFDO1lBQ0wsQ0FBQztZQUplLDJCQUFxQix3QkFJcEMsQ0FBQTtZQUFBLENBQUM7WUFFRixxREFBcUQ7WUFDckQsbUJBQTBCLFNBQVMsRUFBRSxFQUFVLEVBQUUsRUFBVTtnQkFDekQsK0RBQStEO2dCQUMvRCxJQUFJLFNBQVMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksSUFBSSxFQUFFO29CQUN2QyxTQUFTLEdBQUcsU0FBUyxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsQ0FBQztpQkFDOUM7Z0JBQ0QsU0FBUyxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUUsWUFBWSxHQUFHLEVBQUUsR0FBRyxHQUFHLEdBQUcsRUFBRSxHQUFHLEdBQUcsQ0FBQyxDQUFDO1lBQ2xFLENBQUM7WUFOZSxlQUFTLFlBTXhCLENBQUE7WUFBQSxDQUFDO1lBRUY7Ozs7Ozs7ZUFPRztZQUNILHNCQUE2QixJQUFJLEVBQUUsRUFBVSxFQUFFLEVBQVUsRUFBRSxLQUFhLEVBQ3BFLE1BQWM7Z0JBQ2hCLElBQUksQ0FBQyxVQUFVLEVBQUU7cUJBQ2QsSUFBSSxDQUFDLEdBQUcsRUFBRSxFQUFFLEdBQUcsS0FBSyxHQUFHLENBQUMsQ0FBQztxQkFDekIsSUFBSSxDQUFDLEdBQUcsRUFBRSxFQUFFLEdBQUcsTUFBTSxHQUFHLENBQUMsQ0FBQztxQkFDMUIsSUFBSSxDQUFDLE9BQU8sRUFBRSxLQUFLLENBQUM7cUJBQ3BCLElBQUksQ0FBQyxRQUFRLEVBQUUsTUFBTSxDQUFDLENBQUM7WUFDNUIsQ0FBQztZQVBlLGtCQUFZLGVBTzNCLENBQUE7WUFBQSxDQUFDO1lBRUY7Ozs7Ozs7ZUFPRztZQUNILDBCQUFpQyxPQUFPLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxLQUFLLEVBQUUsTUFBTTtnQkFDN0QsSUFBTSxVQUFVLEdBQUcsTUFBTSxHQUFHLENBQUMsQ0FBQztnQkFDOUIsSUFBTSxTQUFTLEdBQUcsS0FBSyxHQUFHLENBQUMsQ0FBQztnQkFDNUIsSUFBTSxNQUFNLEdBQUc7b0JBQ2IsQ0FBQyxFQUFFLEVBQUUsRUFBRSxHQUFHLFVBQVUsQ0FBQztvQkFDckIsQ0FBQyxFQUFFLEdBQUcsU0FBUyxFQUFFLEVBQUUsR0FBRyxVQUFVLENBQUM7b0JBQ2pDLENBQUMsRUFBRSxHQUFHLFNBQVMsRUFBRSxFQUFFLEdBQUcsVUFBVSxDQUFDO2lCQUNsQyxDQUFDO2dCQUNGLE9BQU8sQ0FBQyxVQUFVLEVBQUUsQ0FBQyxJQUFJLENBQ3JCLFFBQVEsRUFBRSxNQUFNLENBQUMsR0FBRyxDQUFDLFVBQUEsS0FBSyxJQUFJLE9BQUEsS0FBSyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBZixDQUFlLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztZQUNoRSxDQUFDO1lBVmUsc0JBQWdCLG1CQVUvQixDQUFBO1lBQUEsQ0FBQztZQUVGOzs7OztlQUtHO1lBQ0gsd0JBQStCLE1BQU0sRUFBRSxVQUFpQztnQkFDdEUsSUFBSSxFQUFFLEdBQUcsTUFBQSxNQUFNLENBQUMsNEJBQTRCLENBQUMsVUFBVSxDQUFDLENBQUM7Z0JBQ3pELGlFQUFpRTtnQkFDakUsNkRBQTZEO2dCQUM3RCxJQUFJLEtBQUssR0FBRyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUM7b0JBQzdCLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDO2dCQUNoRCxJQUFJLE1BQU0sR0FBRyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUM7b0JBQzlCLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDO2dCQUNsRCxJQUFJLENBQUMsR0FBRyxFQUFFLEdBQUcsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQzNCLElBQUksQ0FBQyxHQUFHLFVBQVUsQ0FBQyxDQUFDLEdBQUcsTUFBTSxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQ3RDLG9FQUFvRTtnQkFDcEUsNENBQTRDO2dCQUM1QyxJQUFJLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxLQUFLLE1BQUEsUUFBUSxDQUFDLE1BQU0sSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLEVBQUU7b0JBQ3BFLENBQUMsSUFBSSxFQUFFLENBQUM7b0JBQ1IsQ0FBQyxJQUFJLENBQUMsQ0FBQztpQkFDUjtnQkFDRCxJQUFJLFlBQVksR0FBRyxZQUFZLEdBQUcsQ0FBQyxHQUFHLEdBQUcsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFDO2dCQUNwRCxNQUFNLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDLFVBQVUsRUFBRSxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUUsWUFBWSxDQUFDLENBQUM7Z0JBQ3RFLE1BQU0sQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsVUFBVSxFQUFFLENBQUMsSUFBSSxDQUNyQyxFQUFDLEVBQUUsRUFBRSxDQUFDLEVBQUUsRUFBRSxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsTUFBQSxNQUFNLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLEVBQUMsQ0FBQyxDQUFDO1lBQ3pFLENBQUM7WUFwQmUsb0JBQWMsaUJBb0I3QixDQUFBO1lBQUEsQ0FBQztZQUVGOzs7Ozs7O2VBT0c7WUFDSCx5QkFBZ0MsT0FBTyxFQUFFLEVBQVUsRUFBRSxFQUFVLEVBQzNELEtBQWEsRUFBRSxNQUFjO2dCQUMvQixPQUFPLENBQUMsVUFBVSxFQUFFO3FCQUNqQixJQUFJLENBQUMsSUFBSSxFQUFFLEVBQUUsQ0FBQztxQkFDZCxJQUFJLENBQUMsSUFBSSxFQUFFLEVBQUUsQ0FBQztxQkFDZCxJQUFJLENBQUMsSUFBSSxFQUFFLEtBQUssR0FBRyxDQUFDLENBQUM7cUJBQ3JCLElBQUksQ0FBQyxJQUFJLEVBQUUsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDO1lBQzVCLENBQUM7WUFQZSxxQkFBZSxrQkFPOUIsQ0FBQTtZQUFBLENBQUM7WUFFRjs7Ozs7ZUFLRztZQUNILGdDQUF1QyxJQUFJLEVBQUUsb0JBQW9CO2dCQUMvRCxJQUFJLG9CQUFvQixFQUFFO29CQUN4QixPQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUM7aUJBQ3hCO2dCQUNELElBQUksSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUU7b0JBQ3ZCLE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQztpQkFDeEI7Z0JBQ0QsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQy9CLENBQUM7WUFSZSw0QkFBc0IseUJBUXJDLENBQUE7WUFFRDs7ZUFFRztZQUNILG1DQUFtQyxVQUFzQixFQUN0QixVQUFrQixFQUNsQixpQkFBMkIsRUFDM0IsWUFBb0M7Z0JBQ3JFLElBQUksSUFBSSxHQUFHLFVBQVUsR0FBRyxVQUFVLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQztnQkFDdEQsSUFBSSxJQUFJLFNBQVMsR0FBRyxVQUFVLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQztnQkFFNUMsSUFBSSxRQUFRLEdBQUcsVUFBVSxDQUFDO2dCQUMxQixJQUFJLFVBQVUsQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtvQkFDL0IsUUFBUSxHQUFHLEdBQUcsR0FBRyxVQUFVLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxHQUFHLENBQUM7aUJBQ25EO2dCQUNELElBQUksSUFBSSxXQUFXLEdBQUcsUUFBUSxHQUFHLE1BQU0sQ0FBQztnQkFFeEMsSUFBSSxJQUFJLGVBQWUsR0FBRyxVQUFVLEdBQUcsSUFBSSxDQUFDO2dCQUM1QyxJQUFNLGNBQWMsR0FBRyxFQUFFLENBQUM7Z0JBQzFCLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxpQkFBaUIsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7b0JBQ2pELElBQUksaUJBQWlCLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFO3dCQUM1QixjQUFjLENBQUMsSUFBSSxDQUNmLElBQUksR0FBRyxNQUFBLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxLQUFLLEdBQUcsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztxQkFDdkU7aUJBQ0Y7Z0JBQ0QsSUFBSSxJQUFJLGNBQWMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsTUFBTSxDQUFDO2dCQUUzQyx3RUFBd0U7Z0JBQ3hFLGlEQUFpRDtnQkFDakQsSUFBSSxZQUFZLENBQUMsR0FBRyxJQUFJLFlBQVksQ0FBQyxHQUFHLEVBQUU7b0JBQ3hDLElBQUksSUFBSSxPQUFPLEdBQUcsWUFBWSxDQUFDLEdBQUcsR0FBRyxTQUFTLEdBQUcsWUFBWSxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUM7b0JBQ3pFLElBQUksSUFBSSxRQUFRLEdBQUcsWUFBWSxDQUFDLElBQUksR0FBRyxZQUFZLEdBQUcsWUFBWSxDQUFDLE1BQU0sQ0FBQztpQkFDM0U7Z0JBRUQsT0FBTyxJQUFJLENBQUM7WUFDZCxDQUFDO1lBRUQ7Ozs7Ozs7Ozs7Ozs7ZUFhRztZQUNILHVCQUNJLGdCQUE0QixFQUFFLFVBQXNCLEVBQ3BELFFBQStCLEVBQUUsWUFBb0IsRUFDckQsZUFBb0IsRUFBRSxnQkFBcUIsRUFBRSxpQkFBcUIsRUFDbEUsV0FBb0I7Z0JBRHBCLGdDQUFBLEVBQUEsb0JBQW9CO2dCQUFFLGlDQUFBLEVBQUEscUJBQXFCO2dCQUFFLGtDQUFBLEVBQUEscUJBQXFCO2dCQUVwRSw0Q0FBNEM7Z0JBQzVDLEVBQUUsQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLENBQUMsVUFBaUIsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQztnQkFFakYsSUFBSSxDQUFDLFVBQVUsRUFBRTtvQkFDZixPQUFPO2lCQUNSO2dCQUVELElBQU0sa0JBQWtCLEdBQUcsVUFBVSxDQUFDLEtBQUssQ0FBQztnQkFFNUMsMEVBQTBFO2dCQUMxRSw2RUFBNkU7Z0JBQzdFLElBQU0sK0JBQStCLEdBQUcsa0JBQWtCLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztnQkFDdkUsSUFBTSxRQUFRLEdBQUcsK0JBQStCLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ3BELElBQU0sV0FBVyxHQUFHLCtCQUErQixDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUN2RCxJQUFNLFdBQVcsR0FBRywrQkFBK0IsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDdkQsSUFBSSxVQUFVLEdBQUcsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ3ZDLElBQU0sWUFBWSxHQUEyQjtvQkFDekMsR0FBRyxFQUFFLGtCQUFrQixDQUFDLENBQUMsQ0FBQztvQkFDMUIsR0FBRyxFQUFFLGtCQUFrQixDQUFDLENBQUMsQ0FBQztvQkFDMUIsSUFBSSxFQUFFLGtCQUFrQixDQUFDLEVBQUUsQ0FBQztvQkFDNUIsTUFBTSxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsRUFBRSxDQUFDLENBQUM7aUJBQzVDLENBQUM7Z0JBRUYsSUFBSSxlQUFlLElBQUksSUFBSSxFQUFFO29CQUMzQixlQUFlLEdBQUcsRUFBRSxDQUFDO2lCQUN0QjtnQkFDRCxJQUFJLGdCQUFnQixJQUFJLElBQUksRUFBRTtvQkFDNUIsZ0JBQWdCLEdBQUcsRUFBRSxDQUFDO2lCQUN2QjtnQkFDRCxJQUFJLGlCQUFpQixJQUFJLElBQUksRUFBRTtvQkFDN0IsaUJBQWlCLEdBQUcsQ0FBQyxDQUFDO2lCQUN2QjtnQkFDRCxJQUFJLFFBQVEsSUFBSSxJQUFJLElBQUksUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLEtBQUssRUFBRSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsRUFBRSxFQUFFO29CQUNuRSx5RUFBeUU7b0JBQ3pFLGVBQWUsSUFBSSxDQUFDLENBQUM7b0JBQ3JCLGdCQUFnQixJQUFJLENBQUMsQ0FBQztpQkFDdkI7Z0JBRUQsSUFBSSxlQUFlLEdBQUcsUUFBUSxDQUFDLGVBQWUsQ0FBQyxNQUFBLGFBQWEsRUFBRSxHQUFHLENBQUMsQ0FBQztnQkFDbkUsZUFBZSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLENBQUM7Z0JBRTdDLDJDQUEyQztnQkFDM0MsSUFBSSxjQUFjLEdBQUcsUUFBUSxDQUFDLGVBQWUsQ0FBQyxNQUFBLGFBQWEsRUFBRSxNQUFNLENBQUMsQ0FBQztnQkFDckUsZUFBZSxDQUFDLFdBQVcsQ0FBQyxjQUFjLENBQUMsQ0FBQztnQkFDNUMsSUFBSSxrQkFBa0IsR0FDbEIsUUFBUSxDQUFDLGVBQWUsQ0FBQyxNQUFBLGFBQWEsRUFBRSxnQkFBZ0IsQ0FBQyxDQUFDO2dCQUU5RCxxREFBcUQ7Z0JBQ3JELElBQU0sb0JBQW9CLEdBQUcsdUJBQXVCLEdBQUcsWUFBWSxDQUFDO2dCQUNwRSxrQkFBa0IsQ0FBQyxZQUFZLENBQUMsSUFBSSxFQUFFLG9CQUFvQixDQUFDLENBQUM7Z0JBRTVELElBQUksZUFBZSxHQUFHLENBQUMsQ0FBQztnQkFDeEIsSUFBSSxjQUFjLEdBQUcsSUFBSSxDQUFDO2dCQUMxQixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsK0JBQStCLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO29CQUMvRCxJQUFJLENBQUMsK0JBQStCLENBQUMsQ0FBQyxDQUFDLEVBQUU7d0JBQ3ZDLDRCQUE0Qjt3QkFDNUIsU0FBUztxQkFDVjtvQkFDRCxlQUFlLElBQUksK0JBQStCLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBRXRELGlEQUFpRDtvQkFDakQsSUFBSSxZQUFZLEdBQUcsUUFBUSxDQUFDLGVBQWUsQ0FBQyxNQUFBLGFBQWEsRUFBRSxNQUFNLENBQUMsQ0FBQztvQkFDbkUsWUFBWSxDQUFDLFlBQVksQ0FBQyxRQUFRLEVBQUUsY0FBYyxDQUFDLENBQUM7b0JBQ3BELFlBQVksQ0FBQyxZQUFZLENBQ3JCLFlBQVksRUFBRSxNQUFBLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUM7b0JBQ3pELGtCQUFrQixDQUFDLFdBQVcsQ0FBQyxZQUFZLENBQUMsQ0FBQztvQkFFN0MsSUFBSSxZQUFZLEdBQUcsUUFBUSxDQUFDLGVBQWUsQ0FBQyxNQUFBLGFBQWEsRUFBRSxNQUFNLENBQUMsQ0FBQztvQkFDbkUsSUFBSSxPQUFPLEdBQUcsQ0FBQyxlQUFlLEdBQUcsR0FBRyxHQUFHLFVBQVUsQ0FBQyxHQUFHLEdBQUcsQ0FBQztvQkFDekQsWUFBWSxDQUFDLFlBQVksQ0FBQyxRQUFRLEVBQUUsT0FBTyxDQUFDLENBQUM7b0JBQzdDLFlBQVksQ0FBQyxZQUFZLENBQ3JCLFlBQVksRUFBRSxNQUFBLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUM7b0JBQ3pELGtCQUFrQixDQUFDLFdBQVcsQ0FBQyxZQUFZLENBQUMsQ0FBQztvQkFDN0MsY0FBYyxHQUFHLE9BQU8sQ0FBQztpQkFDMUI7Z0JBQ0QsY0FBYyxDQUFDLFdBQVcsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO2dCQUUvQyw0Q0FBNEM7Z0JBQzVDLElBQUksSUFBSSxHQUFHLFFBQVEsQ0FBQyxlQUFlLENBQUMsTUFBQSxhQUFhLEVBQUUsTUFBTSxDQUFDLENBQUM7Z0JBQzNELElBQUksQ0FBQyxZQUFZLENBQUMsTUFBTSxFQUFFLE9BQU8sR0FBRyxvQkFBb0IsR0FBRyxHQUFHLENBQUMsQ0FBQztnQkFDaEUsSUFBSSxDQUFDLFlBQVksQ0FBQyxPQUFPLEVBQUUsTUFBTSxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUM7Z0JBQ3BELElBQUksQ0FBQyxZQUFZLENBQUMsUUFBUSxFQUFFLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUM7Z0JBQ3RELElBQUksQ0FBQyxZQUFZLENBQUMsR0FBRyxFQUFFLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUM7Z0JBQ2xELGVBQWUsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUM7Z0JBRWxDLDhDQUE4QztnQkFDOUMsSUFBSSxRQUFRLEdBQUcsUUFBUSxDQUFDLGVBQWUsQ0FBQyxNQUFBLGFBQWEsRUFBRSxPQUFPLENBQUMsQ0FBQztnQkFDaEUsUUFBUSxDQUFDLFdBQVcsR0FBRyx5QkFBeUIsQ0FDNUMsVUFBVSxFQUFFLFVBQVUsRUFBRSwrQkFBK0IsRUFBRSxZQUFZLENBQUMsQ0FBQztnQkFDM0UsZUFBZSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsQ0FBQztnQkFFdEMsZ0VBQWdFO2dCQUNoRSxJQUFJLG9CQUFvQixHQUFHLEtBQUssQ0FBQztnQkFDakMsSUFBSSxRQUFRLElBQUksSUFBSSxFQUFFO29CQUNwQixJQUFJLFdBQVcsR0FBRyxRQUFRLENBQUMsQ0FBQyxHQUFHLGVBQWUsR0FBRyxDQUFDLENBQUM7b0JBQ25ELElBQUksV0FBVyxHQUFHLFFBQVEsQ0FBQyxDQUFDLEdBQUcsZ0JBQWdCLEdBQUcsUUFBUSxDQUFDLE1BQU0sR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO29CQUMxRSxJQUFJLFFBQVEsQ0FBQyxXQUFXLEdBQUcsQ0FBQyxFQUFFO3dCQUM1QixvRUFBb0U7d0JBQ3BFLFdBQVcsSUFBSSxRQUFRLENBQUMsV0FBVyxDQUFDO3FCQUNyQztvQkFDRCxlQUFlLENBQUMsWUFBWSxDQUN4QixXQUFXLEVBQUUsWUFBWSxHQUFHLFdBQVcsR0FBRyxJQUFJLEdBQUcsV0FBVyxHQUFHLEdBQUcsQ0FBQyxDQUFDO29CQUV4RSxJQUFJLCtCQUErQixDQUFDLENBQUMsQ0FBQzt3QkFDbEMsK0JBQStCLENBQUMsQ0FBQyxDQUFDO3dCQUNsQywrQkFBK0IsQ0FBQyxDQUFDLENBQUMsRUFBRTt3QkFDdEMsMkVBQTJFO3dCQUMzRSwwQkFBMEI7d0JBRTFCLCtEQUErRDt3QkFFL0QsSUFBSSxNQUFJLEdBQUcsUUFBUSxDQUFDLElBQWMsQ0FBQzt3QkFDbkMsSUFBSSxVQUFVLEdBQUcsTUFBSSxDQUFDLElBQUksQ0FBQzt3QkFDM0IsSUFBSSxVQUFVLElBQUksVUFBVSxDQUFDLE1BQU0sRUFBRTs0QkFDbkMsc0RBQXNEOzRCQUN0RCxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsVUFBVSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtnQ0FDMUMsSUFBSSxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxLQUFLLEdBQUcsRUFBRTtvQ0FDN0IsOENBQThDO29DQUM5QyxJQUFJLFVBQVUsR0FBRyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDO29DQUM3QyxvQkFBb0I7d0NBQ2hCLFVBQVUsSUFBSSxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7b0NBQ3pELE1BQU07aUNBQ1A7NkJBQ0Y7eUJBQ0Y7cUJBQ0Y7aUJBQ0Y7Z0JBRUQsSUFBSSxRQUFRLEdBQUcsUUFBUSxDQUFDLGVBQWUsQ0FBQyxNQUFBLGFBQWEsRUFBRSxNQUFNLENBQUMsQ0FBQztnQkFDL0QsSUFBSSxNQUFNLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsSUFBSSxNQUFNLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsRUFBRTtvQkFDMUUsSUFBTSxTQUFTLEdBQ1gsc0JBQXNCLENBQUMsWUFBWSxDQUFDLEdBQUcsRUFBRSxvQkFBb0IsQ0FBQyxDQUFDO29CQUNuRSxJQUFNLFNBQVMsR0FDWCxzQkFBc0IsQ0FBQyxZQUFZLENBQUMsR0FBRyxFQUFFLG9CQUFvQixDQUFDLENBQUM7b0JBQ25FLElBQUksVUFBVSxHQUFHLENBQUMsRUFBRTt3QkFDbEIsUUFBUSxDQUFDLFdBQVcsR0FBRyxTQUFTLEdBQUcsS0FBSyxHQUFHLFNBQVMsQ0FBQztxQkFDdEQ7eUJBQU07d0JBQ0wsUUFBUSxDQUFDLFdBQVcsR0FBRyxTQUFTLENBQUM7cUJBQ2xDO29CQUNELElBQUksUUFBUSxHQUFHLENBQUMsSUFBSSxXQUFXLEdBQUcsQ0FBQyxJQUFJLFdBQVcsR0FBRyxDQUFDLEVBQUU7d0JBQ3RELFFBQVEsQ0FBQyxXQUFXLElBQUksSUFBSSxDQUFDO3dCQUM3QixJQUFNLGVBQWUsR0FBYSxFQUFFLENBQUM7d0JBQ3JDLElBQUksUUFBUSxHQUFHLENBQUMsRUFBRTs0QkFDaEIsZUFBZSxDQUFDLElBQUksQ0FBQyxjQUFPLFFBQVUsQ0FBQyxDQUFDO3lCQUN6Qzt3QkFDRCxJQUFJLFdBQVcsR0FBRyxDQUFDLEVBQUU7NEJBQ25CLGVBQWUsQ0FBQyxJQUFJLENBQUMsa0JBQU0sV0FBYSxDQUFDLENBQUM7eUJBQzNDO3dCQUNELElBQUksV0FBVyxHQUFHLENBQUMsRUFBRTs0QkFDbkIsZUFBZSxDQUFDLElBQUksQ0FBQyxrQkFBTSxXQUFhLENBQUMsQ0FBQzt5QkFDM0M7d0JBQ0QsUUFBUSxDQUFDLFdBQVcsSUFBSSxlQUFlLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLEdBQUcsQ0FBQztxQkFDMUQ7aUJBQ0Y7cUJBQU07b0JBQ0wsUUFBUSxDQUFDLFdBQVcsR0FBRyxzQkFBc0IsQ0FBQztpQkFDL0M7Z0JBQ0QsUUFBUSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsbUJBQW1CLENBQUMsQ0FBQztnQkFDNUMsSUFBSSxXQUFXLElBQUksSUFBSSxFQUFFO29CQUN2QixXQUFXLEdBQUcsZUFBZSxHQUFHLENBQUMsQ0FBQztpQkFDbkM7Z0JBQ0QsUUFBUSxDQUFDLFlBQVksQ0FBQyxHQUFHLEVBQUUsTUFBTSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUM7Z0JBQ2hELFFBQVEsQ0FBQyxZQUFZLENBQUMsR0FBRyxFQUFFLE1BQU0sQ0FBQyxpQkFBaUIsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUMxRCxlQUFlLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxDQUFDO2dCQUV0QyxPQUFPLENBQUMsR0FBRyxDQUFDLGdCQUFnQixDQUFDLFVBQVUsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxlQUFlLENBQUMsQ0FBQztZQUN4RSxDQUFDO1lBMUtlLG1CQUFhLGdCQTBLNUIsQ0FBQTtZQUVEOzs7OztlQUtHO1lBQ0gsd0JBQ0ksT0FBbUIsRUFBRSxzQkFBcUQsRUFDMUUsbUJBQTJCO2dCQUM3QixJQUFJLENBQUMsc0JBQXNCLEVBQUU7b0JBQzNCLHdDQUF3QztvQkFDeEMsT0FBTztpQkFDUjtnQkFFRCw4RUFBOEU7Z0JBQzlFLDBFQUEwRTtnQkFDMUUsaUNBQWlDO2dCQUNqQyxJQUFJLFlBQVksR0FBRyxDQUFDLENBQUM7Z0JBRXJCLElBQUksZ0JBQWdCLEdBQUcsRUFBRSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQztnQkFDMUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLGFBQWEsQ0FBQztxQkFDcEMsSUFBSSxDQUFDLFVBQVMsUUFBK0I7b0JBQzVDLCtEQUErRDtvQkFDL0QsSUFBTSxXQUFXLEdBQUcsc0JBQXNCLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztvQkFDL0QsSUFBTSxVQUFVLEdBQ1osV0FBVyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO29CQUMxRCxhQUFhLENBQ1IsSUFBbUIsRUFBRSxVQUFVLEVBQUUsUUFBUSxFQUFFLFlBQVksRUFBRSxDQUFDLENBQUM7Z0JBQ2xFLENBQUMsQ0FBQyxDQUFDO1lBQ1QsQ0FBQztZQXZCZSxvQkFBYyxpQkF1QjdCLENBQUE7WUFBQSxDQUFDO1FBRUYsQ0FBQyxFQTExQmUsS0FBSyxHQUFMLFdBQUssS0FBTCxXQUFLLFFBMDFCcEI7SUFBRCxDQUFDLEVBMTFCUyxLQUFLLEdBQUwsUUFBSyxLQUFMLFFBQUssUUEwMUJkO0FBQUQsQ0FBQyxFQTExQk0sRUFBRSxLQUFGLEVBQUUsUUEwMUJSLENBQUMsZUFBZSIsInNvdXJjZXNDb250ZW50IjpbIi8qIENvcHlyaWdodCAyMDE1IFRoZSBUZW5zb3JGbG93IEF1dGhvcnMuIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG5cbkxpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSAnTGljZW5zZScpO1xueW91IG1heSBub3QgdXNlIHRoaXMgZmlsZSBleGNlcHQgaW4gY29tcGxpYW5jZSB3aXRoIHRoZSBMaWNlbnNlLlxuWW91IG1heSBvYnRhaW4gYSBjb3B5IG9mIHRoZSBMaWNlbnNlIGF0XG5cbiAgICBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcblxuVW5sZXNzIHJlcXVpcmVkIGJ5IGFwcGxpY2FibGUgbGF3IG9yIGFncmVlZCB0byBpbiB3cml0aW5nLCBzb2Z0d2FyZVxuZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIExpY2Vuc2UgaXMgZGlzdHJpYnV0ZWQgb24gYW4gJ0FTIElTJyBCQVNJUyxcbldJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWSBLSU5ELCBlaXRoZXIgZXhwcmVzcyBvciBpbXBsaWVkLlxuU2VlIHRoZSBMaWNlbnNlIGZvciB0aGUgc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nIHBlcm1pc3Npb25zIGFuZFxubGltaXRhdGlvbnMgdW5kZXIgdGhlIExpY2Vuc2UuXG49PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0qL1xubW9kdWxlIHRmLmdyYXBoLnNjZW5lIHtcbiAgZXhwb3J0IGNvbnN0IFNWR19OQU1FU1BBQ0UgPSAnaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnO1xuXG4gIC8qKiBFbnVtcyBlbGVtZW50IGNsYXNzIG9mIG9iamVjdHMgaW4gdGhlIHNjZW5lICovXG4gIGV4cG9ydCBsZXQgQ2xhc3MgPSB7XG4gICAgTm9kZToge1xuICAgICAgLy8gPGc+IGVsZW1lbnQgdGhhdCBjb250YWlucyBub2Rlcy5cbiAgICAgIENPTlRBSU5FUjogJ25vZGVzJyxcbiAgICAgIC8vIDxnPiBlbGVtZW50IHRoYXQgY29udGFpbnMgZGV0YWlsIGFib3V0IGEgbm9kZS5cbiAgICAgIEdST1VQOiAnbm9kZScsXG4gICAgICAvLyA8Zz4gZWxlbWVudCB0aGF0IGNvbnRhaW5zIHZpc3VhbCBlbGVtZW50cyAobGlrZSByZWN0LCBlbGxpcHNlKS5cbiAgICAgIFNIQVBFOiAnbm9kZXNoYXBlJyxcbiAgICAgIC8vIDwqPiBlbGVtZW50KHMpIHVuZGVyIFNIQVBFIHRoYXQgc2hvdWxkIHJlY2VpdmUgY29sb3IgdXBkYXRlcy5cbiAgICAgIENPTE9SX1RBUkdFVDogJ25vZGVjb2xvcnRhcmdldCcsXG4gICAgICAvLyA8dGV4dD4gZWxlbWVudCBzaG93aW5nIHRoZSBub2RlJ3MgbGFiZWwuXG4gICAgICBMQUJFTDogJ25vZGVsYWJlbCcsXG4gICAgICAvLyA8Zz4gZWxlbWVudCB0aGF0IGNvbnRhaW5zIGFsbCB2aXN1YWxzIGZvciB0aGUgZXhwYW5kL2NvbGxhcHNlXG4gICAgICAvLyBidXR0b24gZm9yIGV4cGFuZGFibGUgZ3JvdXAgbm9kZXMuXG4gICAgICBCVVRUT05fQ09OVEFJTkVSOiAnYnV0dG9uY29udGFpbmVyJyxcbiAgICAgIC8vIDxjaXJjbGU+IGVsZW1lbnQgdGhhdCBzdXJyb3VuZHMgZXhwYW5kL2NvbGxhcHNlIGJ1dHRvbnMuXG4gICAgICBCVVRUT05fQ0lSQ0xFOiAnYnV0dG9uY2lyY2xlJyxcbiAgICAgIC8vIDxwYXRoPiBlbGVtZW50IG9mIHRoZSBleHBhbmQgYnV0dG9uLlxuICAgICAgRVhQQU5EX0JVVFRPTjogJ2V4cGFuZGJ1dHRvbicsXG4gICAgICAvLyA8cGF0aD4gZWxlbWVudCBvZiB0aGUgY29sbGFwc2UgYnV0dG9uLlxuICAgICAgQ09MTEFQU0VfQlVUVE9OOiAnY29sbGFwc2VidXR0b24nXG4gICAgfSxcbiAgICBFZGdlOiB7XG4gICAgICBDT05UQUlORVI6ICdlZGdlcycsXG4gICAgICBHUk9VUDogJ2VkZ2UnLFxuICAgICAgTElORTogJ2VkZ2VsaW5lJyxcbiAgICAgIFJFRkVSRU5DRV9FREdFOiAncmVmZXJlbmNlZWRnZScsXG4gICAgICBSRUZfTElORTogJ3JlZmxpbmUnLFxuICAgICAgU0VMRUNUQUJMRTogJ3NlbGVjdGFibGVlZGdlJyxcbiAgICAgIFNFTEVDVEVEOiAnc2VsZWN0ZWRlZGdlJyxcbiAgICAgIFNUUlVDVFVSQUw6ICdzdHJ1Y3R1cmFsJ1xuICAgIH0sXG4gICAgQW5ub3RhdGlvbjoge1xuICAgICAgT1VUQk9YOiAnb3V0LWFubm90YXRpb25zJyxcbiAgICAgIElOQk9YOiAnaW4tYW5ub3RhdGlvbnMnLFxuICAgICAgR1JPVVA6ICdhbm5vdGF0aW9uJyxcbiAgICAgIE5PREU6ICdhbm5vdGF0aW9uLW5vZGUnLFxuICAgICAgRURHRTogJ2Fubm90YXRpb24tZWRnZScsXG4gICAgICBDT05UUk9MX0VER0U6ICdhbm5vdGF0aW9uLWNvbnRyb2wtZWRnZScsXG4gICAgICBMQUJFTDogJ2Fubm90YXRpb24tbGFiZWwnLFxuICAgICAgRUxMSVBTSVM6ICdhbm5vdGF0aW9uLWVsbGlwc2lzJ1xuICAgIH0sXG4gICAgU2NlbmU6IHtcbiAgICAgIEdST1VQOiAnc2NlbmUnLFxuICAgICAgQ09SRTogJ2NvcmUnLFxuICAgICAgRlVOQ1RJT05fTElCUkFSWTogJ2Z1bmN0aW9uLWxpYnJhcnknLFxuICAgICAgSU5FWFRSQUNUOiAnaW4tZXh0cmFjdCcsXG4gICAgICBPVVRFWFRSQUNUOiAnb3V0LWV4dHJhY3QnXG4gICAgfSxcbiAgICBTdWJzY2VuZToge0dST1VQOiAnc3Vic2NlbmUnfSxcbiAgICBPUE5PREU6ICdvcCcsXG4gICAgTUVUQU5PREU6ICdtZXRhJyxcbiAgICBTRVJJRVNOT0RFOiAnc2VyaWVzJyxcbiAgICBCUklER0VOT0RFOiAnYnJpZGdlJyxcbiAgICBFTExJUFNJU05PREU6ICdlbGxpcHNpcydcbiAgfTtcblxuICAvKipcbiAgICogVGhlIGRpbWVuc2lvbnMgb2YgdGhlIG1pbmltYXAgaW5jbHVkaW5nIHBhZGRpbmcgYW5kIG1hcmdpbi5cbiAgICovXG4gIGNvbnN0IE1JTklNQVBfQk9YX1dJRFRIID0gMzIwO1xuICBjb25zdCBNSU5JTUFQX0JPWF9IRUlHSFQgPSAxNTA7XG5cbiAgLyoqXG4gICAqIEEgaGVhbHRoIHBpbGwgZW5jYXBzdWxhdGVzIGFuIG92ZXJ2aWV3IG9mIHRlbnNvciBlbGVtZW50IHZhbHVlcy4gVGhlIHZhbHVlXG4gICAqIGZpZWxkIGlzIGEgbGlzdCBvZiAxMiBudW1iZXJzIHRoYXQgc2hlZCBsaWdodCBvbiB0aGUgc3RhdHVzIG9mIHRoZSB0ZW5zb3IuXG4gICAqIFZpc3VhbGl6ZWQgaW4gaGVhbHRoIHBpbGxzIGFyZSB0aGUgM3JkIHRocm91Z2ggOHRoIChpbmNsdXNpdmUpIG51bWJlcnMgb2ZcbiAgICogaGVhbHRoIHBpbGwgdmFsdWVzLiBUaG9zZSA2IG51bWJlcnMgYXJlIGNvdW50cyBvZiB0ZW5zb3IgZWxlbWVudHMgdGhhdCBmYWxsXG4gICAqIHVuZGVyIC1JbmYsIG5lZ2F0aXZlLCAwLCBwb3NpdGl2ZSwgK0luZiwgTmFOIChpbiB0aGF0IG9yZGVyKS5cbiAgICpcbiAgICogUGxlYXNlIGtlZXAgdGhpcyBpbnRlcmZhY2UgY29uc2lzdGVudCB3aXRoIEhlYWx0aFBpbGxEYXR1bSB3aXRoaW5cbiAgICogYmFja2VuZC50cy5cbiAgICovXG4gIGV4cG9ydCBpbnRlcmZhY2UgSGVhbHRoUGlsbCB7XG4gICAgZGV2aWNlX25hbWU6IHN0cmluZztcbiAgICBub2RlX25hbWU6IHN0cmluZztcbiAgICBvdXRwdXRfc2xvdDogbnVtYmVyO1xuICAgIGR0eXBlOiBzdHJpbmc7XG4gICAgc2hhcGU6IG51bWJlcltdO1xuICAgIHZhbHVlOiBudW1iZXJbXTtcbiAgICB3YWxsX3RpbWU6IG51bWJlcjtcbiAgICBzdGVwOiBudW1iZXI7XG4gIH1cblxuICBpbnRlcmZhY2UgSGVhbHRoUGlsbE51bWVyaWNTdGF0cyB7XG4gICAgbWluOiBudW1iZXI7XG4gICAgbWF4OiBudW1iZXI7XG4gICAgbWVhbjogbnVtYmVyO1xuICAgIHN0ZGRldjogbnVtYmVyO1xuICB9XG5cbiAgLyoqXG4gICAqIEVuY2Fwc3VsYXRlcyBob3cgdG8gcmVuZGVyIGEgc2luZ2xlIGVudHJ5IGluIGEgaGVhbHRoIHBpbGwuIEVhY2ggZW50cnlcbiAgICogY29ycmVzcG9uZHMgdG8gYSBjYXRlZ29yeSBvZiB0ZW5zb3IgZWxlbWVudCB2YWx1ZXMuXG4gICAqL1xuICBleHBvcnQgaW50ZXJmYWNlIEhlYWx0aFBpbGxFbnRyeSB7XG4gICAgYmFja2dyb3VuZF9jb2xvcjogc3RyaW5nO1xuICAgIGxhYmVsOiBzdHJpbmc7XG4gIH1cblxuICBleHBvcnQgbGV0IGhlYWx0aFBpbGxFbnRyaWVzOiBIZWFsdGhQaWxsRW50cnlbXSA9IFtcbiAgICB7XG4gICAgICBiYWNrZ3JvdW5kX2NvbG9yOiAnI0NDMkYyQycsXG4gICAgICBsYWJlbDogJ05hTicsXG4gICAgfSxcbiAgICB7XG4gICAgICBiYWNrZ3JvdW5kX2NvbG9yOiAnI0ZGOEQwMCcsXG4gICAgICBsYWJlbDogJy3iiJ4nLFxuICAgIH0sXG4gICAge1xuICAgICAgYmFja2dyb3VuZF9jb2xvcjogJyNFQUVBRUEnLFxuICAgICAgbGFiZWw6ICctJyxcbiAgICB9LFxuICAgIHtcbiAgICAgIGJhY2tncm91bmRfY29sb3I6ICcjQTVBNUE1JyxcbiAgICAgIGxhYmVsOiAnMCcsXG4gICAgfSxcbiAgICB7XG4gICAgICBiYWNrZ3JvdW5kX2NvbG9yOiAnIzI2MjYyNicsXG4gICAgICBsYWJlbDogJysnLFxuICAgIH0sXG4gICAge1xuICAgICAgYmFja2dyb3VuZF9jb2xvcjogJyMwMDNFRDQnLFxuICAgICAgbGFiZWw6ICcr4oieJyxcbiAgICB9LFxuICBdO1xuXG4gIC8qKlxuICAgKiBIZWxwZXIgbWV0aG9kIGZvciBmaXR0aW5nIHRoZSBncmFwaCBpbiB0aGUgc3ZnIHZpZXcuXG4gICAqXG4gICAqIEBwYXJhbSBzdmcgVGhlIG1haW4gc3ZnLlxuICAgKiBAcGFyYW0gem9vbUcgVGhlIHN2ZyBncm91cCB1c2VkIGZvciBwYW5uaW5nIGFuZCB6b29taW5nLlxuICAgKiBAcGFyYW0gZDN6b29tIFRoZSB6b29tIGJlaGF2aW9yLlxuICAgKiBAcGFyYW0gY2FsbGJhY2sgQ2FsbGVkIHdoZW4gdGhlIGZpdHRpbmcgaXMgZG9uZS5cbiAgICovXG4gIGV4cG9ydCBmdW5jdGlvbiBmaXQoc3ZnLCB6b29tRywgZDN6b29tLCBjYWxsYmFjaykge1xuICAgIGxldCBzdmdSZWN0ID0gc3ZnLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuICAgIGxldCBzY2VuZVNpemUgPSBudWxsO1xuICAgIHRyeSB7XG4gICAgICBzY2VuZVNpemUgPSB6b29tRy5nZXRCQm94KCk7XG4gICAgICBpZiAoc2NlbmVTaXplLndpZHRoID09PSAwKSB7XG4gICAgICAgIC8vIFRoZXJlIGlzIG5vIHNjZW5lIGFueW1vcmUuIFdlIGhhdmUgYmVlbiBkZXRhY2hlZCBmcm9tIHRoZSBkb20uXG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICAvLyBGaXJlZm94IHByb2R1Y2VkIE5TX0VSUk9SX0ZBSUxVUkUgaWYgd2UgaGF2ZSBiZWVuXG4gICAgICAvLyBkZXRhY2hlZCBmcm9tIHRoZSBkb20uXG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGxldCBzY2FsZSA9IDAuOSAqXG4gICAgICAgIE1hdGgubWluKFxuICAgICAgICAgICAgc3ZnUmVjdC53aWR0aCAvIHNjZW5lU2l6ZS53aWR0aCwgc3ZnUmVjdC5oZWlnaHQgLyBzY2VuZVNpemUuaGVpZ2h0LFxuICAgICAgICAgICAgMik7XG4gICAgbGV0IHBhcmFtcyA9IGxheW91dC5QQVJBTVMuZ3JhcGg7XG4gICAgY29uc3QgdHJhbnNmb3JtID0gZDMuem9vbUlkZW50aXR5XG4gICAgICAgIC5zY2FsZShzY2FsZSlcbiAgICAgICAgLnRyYW5zbGF0ZShwYXJhbXMucGFkZGluZy5wYWRkaW5nTGVmdCwgcGFyYW1zLnBhZGRpbmcucGFkZGluZ1RvcCk7XG5cbiAgICBkMy5zZWxlY3Qoc3ZnKVxuICAgICAgICAudHJhbnNpdGlvbigpXG4gICAgICAgIC5kdXJhdGlvbig1MDApXG4gICAgICAgIC5jYWxsKGQzem9vbS50cmFuc2Zvcm0sIHRyYW5zZm9ybSlcbiAgICAgICAgLm9uKCdlbmQuZml0dGVkJywgKCkgPT4ge1xuICAgICAgICAgIC8vIFJlbW92ZSB0aGUgbGlzdGVuZXIgZm9yIHRoZSB6b29tZW5kIGV2ZW50LFxuICAgICAgICAgIC8vIHNvIHdlIGRvbid0IGdldCBjYWxsZWQgYXQgdGhlIGVuZCBvZiByZWd1bGFyIHpvb20gZXZlbnRzLFxuICAgICAgICAgIC8vIGp1c3QgdGhvc2UgdGhhdCBmaXQgdGhlIGdyYXBoIHRvIHNjcmVlbi5cbiAgICAgICAgICBkM3pvb20ub24oJ2VuZC5maXR0ZWQnLCBudWxsKTtcbiAgICAgICAgICBjYWxsYmFjaygpO1xuICAgICAgICB9KTtcbn07XG5cbi8qKlxuICogSGVscGVyIG1ldGhvZCBmb3IgcGFubmluZyB0aGUgZ3JhcGggdG8gY2VudGVyIG9uIHRoZSBwcm92aWRlZCBub2RlLFxuICogaWYgdGhlIG5vZGUgaXMgY3VycmVudGx5IG9mZi1zY3JlZW4uXG4gKlxuICogQHBhcmFtIG5vZGVOYW1lIFRoZSBub2RlIHRvIGNlbnRlciB0aGUgZ3JhcGggb25cbiAqIEBwYXJhbSBzdmcgVGhlIHJvb3QgU1ZHIGVsZW1lbnQgZm9yIHRoZSBncmFwaFxuICogQHBhcmFtIHpvb21HIFRoZSBzdmcgZ3JvdXAgdXNlZCBmb3IgcGFubmluZyBhbmQgem9vbWluZy5cbiAqIEBwYXJhbSBkM3pvb20gVGhlIHpvb20gYmVoYXZpb3IuXG4gKiBAcmV0dXJuIFRydWUgaWYgdGhlIGdyYXBoIGhhZCB0byBiZSBwYW5uZWQgdG8gZGlzcGxheSB0aGVcbiAqICAgICAgICAgICAgcHJvdmlkZWQgbm9kZS5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHBhblRvTm9kZShub2RlTmFtZTogU3RyaW5nLCBzdmcsIHpvb21HLCBkM3pvb20pOiBib29sZWFuIHtcbiAgbGV0IG5vZGUgPSA8U1ZHQUVsZW1lbnQ+ZDNcbiAgICAgICAgICAgICAgICAgLnNlbGVjdCgnW2RhdGEtbmFtZT1cIicgKyBub2RlTmFtZSArICdcIl0uJyArIENsYXNzLk5vZGUuR1JPVVApXG4gICAgICAgICAgICAgICAgIC5ub2RlKCk7XG4gIGlmICghbm9kZSkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuXG4gIC8vIENoZWNrIGlmIHRoZSBzZWxlY3RlZCBub2RlIGlzIG9mZi1zY3JlZW4gaW4gZWl0aGVyXG4gIC8vIFggb3IgWSBkaW1lbnNpb24gaW4gZWl0aGVyIGRpcmVjdGlvbi5cbiAgbGV0IG5vZGVCb3ggPSBub2RlLmdldEJCb3goKTtcbiAgbGV0IG5vZGVDdG0gPSBub2RlLmdldFNjcmVlbkNUTSgpO1xuICBsZXQgcG9pbnRUTCA9IHN2Zy5jcmVhdGVTVkdQb2ludCgpO1xuICBsZXQgcG9pbnRCUiA9IHN2Zy5jcmVhdGVTVkdQb2ludCgpO1xuICBwb2ludFRMLnggPSBub2RlQm94Lng7XG4gIHBvaW50VEwueSA9IG5vZGVCb3gueTtcbiAgcG9pbnRCUi54ID0gbm9kZUJveC54ICsgbm9kZUJveC53aWR0aDtcbiAgcG9pbnRCUi55ID0gbm9kZUJveC55ICsgbm9kZUJveC5oZWlnaHQ7XG4gIHBvaW50VEwgPSBwb2ludFRMLm1hdHJpeFRyYW5zZm9ybShub2RlQ3RtKTtcbiAgcG9pbnRCUiA9IHBvaW50QlIubWF0cml4VHJhbnNmb3JtKG5vZGVDdG0pO1xuICBsZXQgaXNPdXRzaWRlT2ZCb3VuZHMgPSAoc3RhcnQsIGVuZCwgbG93ZXJCb3VuZCwgdXBwZXJCb3VuZCkgPT4ge1xuICAgIC8vIFJldHVybiBpZiBldmVuIGEgcGFydCBvZiB0aGUgaW50ZXJ2YWwgaXMgb3V0IG9mIGJvdW5kcy5cbiAgICByZXR1cm4gIShzdGFydCA+IGxvd2VyQm91bmQgJiYgZW5kIDwgdXBwZXJCb3VuZCk7XG4gIH07XG4gIGxldCBzdmdSZWN0ID0gc3ZnLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuXG4gIC8vIFN1YnRyYWN0IHRvIG1ha2Ugc3VyZSB0aGF0IHRoZSBub2RlIGlzIG5vdCBoaWRkZW4gYmVoaW5kIHRoZSBtaW5pbWFwLlxuICBjb25zdCBob3Jpem9udGFsQm91bmQgPSBzdmdSZWN0LmxlZnQgKyBzdmdSZWN0LndpZHRoIC0gTUlOSU1BUF9CT1hfV0lEVEg7XG4gIGNvbnN0IHZlcnRpY2FsQm91bmQgPSBzdmdSZWN0LnRvcCArIHN2Z1JlY3QuaGVpZ2h0IC0gTUlOSU1BUF9CT1hfSEVJR0hUO1xuICBpZiAoaXNPdXRzaWRlT2ZCb3VuZHMocG9pbnRUTC54LCBwb2ludEJSLngsIHN2Z1JlY3QubGVmdCwgaG9yaXpvbnRhbEJvdW5kKSB8fFxuICAgICAgaXNPdXRzaWRlT2ZCb3VuZHMocG9pbnRUTC55LCBwb2ludEJSLnksIHN2Z1JlY3QudG9wLCB2ZXJ0aWNhbEJvdW5kKSkge1xuICAgIC8vIERldGVybWluZSB0aGUgYW1vdW50IHRvIHRyYW5zbGF0ZSB0aGUgZ3JhcGggaW4gYm90aCBYIGFuZCBZIGRpbWVuc2lvbnMgaW5cbiAgICAvLyBvcmRlciB0byBjZW50ZXIgdGhlIHNlbGVjdGVkIG5vZGUuIFRoaXMgdGFrZXMgaW50byBhY2NvdW50IHRoZSBwb3NpdGlvblxuICAgIC8vIG9mIHRoZSBub2RlLCB0aGUgc2l6ZSBvZiB0aGUgc3ZnIHNjZW5lLCB0aGUgYW1vdW50IHRoZSBzY2VuZSBoYXMgYmVlblxuICAgIC8vIHNjYWxlZCBieSB0aHJvdWdoIHpvb21pbmcsIGFuZCBhbnkgcHJldmlvdXMgdHJhbnNmb3JtcyBhbHJlYWR5IHBlcmZvcm1lZFxuICAgIC8vIGJ5IHRoaXMgbG9naWMuXG4gICAgbGV0IGNlbnRlclggPSAocG9pbnRUTC54ICsgcG9pbnRCUi54KSAvIDI7XG4gICAgbGV0IGNlbnRlclkgPSAocG9pbnRUTC55ICsgcG9pbnRCUi55KSAvIDI7XG4gICAgbGV0IGR4ID0gc3ZnUmVjdC5sZWZ0ICsgc3ZnUmVjdC53aWR0aCAvIDIgLSBjZW50ZXJYO1xuICAgIGxldCBkeSA9IHN2Z1JlY3QudG9wICsgc3ZnUmVjdC5oZWlnaHQgLyAyIC0gY2VudGVyWTtcblxuICAgIC8vIFdlIHRyYW5zbGF0ZSBieSB0aGlzIGFtb3VudC4gV2UgZGl2aWRlIHRoZSBYIGFuZCBZIHRyYW5zbGF0aW9ucyBieSB0aGVcbiAgICAvLyBzY2FsZSB0byB1bmRvIGhvdyB0cmFuc2xhdGVCeSBzY2FsZXMgdGhlIHRyYW5zbGF0aW9ucyAoaW4gZDMgdjQpLlxuICAgIGNvbnN0IHN2Z1RyYW5zZm9ybSA9IGQzLnpvb21UcmFuc2Zvcm0oc3ZnKTtcbiAgICBkMy5zZWxlY3Qoc3ZnKS50cmFuc2l0aW9uKCkuZHVyYXRpb24oNTAwKS5jYWxsKFxuICAgICAgICBkM3pvb20udHJhbnNsYXRlQnksXG4gICAgICAgIGR4IC8gc3ZnVHJhbnNmb3JtLmssXG4gICAgICAgIGR5IC8gc3ZnVHJhbnNmb3JtLmspO1xuXG4gICAgcmV0dXJuIHRydWU7XG4gIH1cbiAgcmV0dXJuIGZhbHNlO1xufTtcblxuLyoqXG4gKiBHaXZlbiBhIGNvbnRhaW5lciBkMyBzZWxlY3Rpb24sIHNlbGVjdCBhIGNoaWxkIHN2ZyBlbGVtZW50IG9mIGEgZ2l2ZW4gdGFnXG4gKiBhbmQgY2xhc3MgaWYgZXhpc3RzIG9yIGFwcGVuZCAvIGluc2VydCBvbmUgb3RoZXJ3aXNlLiAgSWYgbXVsdGlwbGUgY2hpbGRyZW5cbiAqIG1hdGNoZXMgdGhlIHRhZyBhbmQgY2xhc3MgbmFtZSwgcmV0dXJucyBvbmx5IHRoZSBmaXJzdCBvbmUuXG4gKlxuICogQHBhcmFtIGNvbnRhaW5lclxuICogQHBhcmFtIHRhZ05hbWUgdGFnIG5hbWUuXG4gKiBAcGFyYW0gY2xhc3NOYW1lIChvcHRpb25hbCkgQ2xhc3MgbmFtZSBvciBhIGxpc3Qgb2YgY2xhc3MgbmFtZXMuXG4gKiBAcGFyYW0gYmVmb3JlIChvcHRpb25hbCkgcmVmZXJlbmNlIERPTSBub2RlIGZvciBpbnNlcnRpb24uXG4gKiBAcmV0dXJuIHNlbGVjdGlvbiBvZiB0aGUgZWxlbWVudFxuICovXG5leHBvcnQgZnVuY3Rpb24gc2VsZWN0T3JDcmVhdGVDaGlsZChcbiAgICBjb250YWluZXIsIHRhZ05hbWU6IHN0cmluZywgY2xhc3NOYW1lPzogc3RyaW5nIHwgc3RyaW5nW10sIGJlZm9yZT8pOiBkMy5TZWxlY3Rpb248YW55LCBhbnksIGFueSwgYW55PiB7XG4gIGxldCBjaGlsZCA9IHNlbGVjdENoaWxkKGNvbnRhaW5lciwgdGFnTmFtZSwgY2xhc3NOYW1lKTtcbiAgaWYgKCFjaGlsZC5lbXB0eSgpKSB7XG4gICAgcmV0dXJuIGNoaWxkO1xuICB9XG4gIGxldCBuZXdFbGVtZW50ID1cbiAgICAgIGRvY3VtZW50LmNyZWF0ZUVsZW1lbnROUygnaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnLCB0YWdOYW1lKTtcblxuICBpZiAoY2xhc3NOYW1lIGluc3RhbmNlb2YgQXJyYXkpIHtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGNsYXNzTmFtZS5sZW5ndGg7IGkrKykge1xuICAgICAgbmV3RWxlbWVudC5jbGFzc0xpc3QuYWRkKGNsYXNzTmFtZVtpXSk7XG4gICAgfVxuICB9IGVsc2Uge1xuICAgIG5ld0VsZW1lbnQuY2xhc3NMaXN0LmFkZChjbGFzc05hbWUpO1xuICB9XG5cbiAgaWYgKGJlZm9yZSkgeyAvLyBpZiBiZWZvcmUgZXhpc3RzLCBpbnNlcnRcbiAgICBjb250YWluZXIubm9kZSgpLmluc2VydEJlZm9yZShuZXdFbGVtZW50LCBiZWZvcmUpO1xuICB9IGVsc2UgeyAvLyBvdGhlcndpc2UsIGFwcGVuZFxuICAgIGNvbnRhaW5lci5ub2RlKCkuYXBwZW5kQ2hpbGQobmV3RWxlbWVudCk7XG4gIH1cbiAgcmV0dXJuIGQzLnNlbGVjdChuZXdFbGVtZW50KVxuICAgICAgICAgICAvLyBuZWVkIHRvIGJpbmQgZGF0YSB0byBlbXVsYXRlIGQzX3NlbGVjdGlvbi5hcHBlbmRcbiAgICAgICAgICAgLmRhdHVtKGNvbnRhaW5lci5kYXR1bSgpKTtcbn07XG5cbi8qKlxuICogR2l2ZW4gYSBjb250YWluZXIgZDMgc2VsZWN0aW9uLCBzZWxlY3QgYSBjaGlsZCBlbGVtZW50IG9mIGEgZ2l2ZW4gdGFnIGFuZFxuICogY2xhc3MuIElmIG11bHRpcGxlIGNoaWxkcmVuIG1hdGNoZXMgdGhlIHRhZyBhbmQgY2xhc3MgbmFtZSwgcmV0dXJucyBvbmx5XG4gKiB0aGUgZmlyc3Qgb25lLlxuICpcbiAqIEBwYXJhbSBjb250YWluZXJcbiAqIEBwYXJhbSB0YWdOYW1lIHRhZyBuYW1lLlxuICogQHBhcmFtIGNsYXNzTmFtZSAob3B0aW9uYWwpIENsYXNzIG5hbWUgb3IgbGlzdCBvZiBjbGFzcyBuYW1lcy5cbiAqIEByZXR1cm4gc2VsZWN0aW9uIG9mIHRoZSBlbGVtZW50LCBvciBhbiBlbXB0eSBzZWxlY3Rpb25cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHNlbGVjdENoaWxkKFxuICAgIGNvbnRhaW5lciwgdGFnTmFtZTogc3RyaW5nLCBjbGFzc05hbWU/OiBzdHJpbmcgfCBzdHJpbmdbXSk6IGQzLlNlbGVjdGlvbjxhbnksIGFueSwgYW55LCBhbnk+IHtcbiAgbGV0IGNoaWxkcmVuID0gY29udGFpbmVyLm5vZGUoKS5jaGlsZE5vZGVzO1xuICBmb3IgKGxldCBpID0gMDsgaSA8IGNoaWxkcmVuLmxlbmd0aDsgaSsrKSB7XG4gICAgbGV0IGNoaWxkID0gY2hpbGRyZW5baV07XG4gICAgaWYgKGNoaWxkLnRhZ05hbWUgPT09IHRhZ05hbWUpIHtcbiAgICAgIGlmIChjbGFzc05hbWUgaW5zdGFuY2VvZiBBcnJheSkge1xuICAgICAgICBsZXQgaGFzQWxsQ2xhc3NlcyA9IHRydWU7XG4gICAgICAgIGZvciAobGV0IGogPSAwOyBqIDwgY2xhc3NOYW1lLmxlbmd0aDsgaisrKSB7XG4gICAgICAgICAgaGFzQWxsQ2xhc3NlcyA9XG4gICAgICAgICAgICAgIGhhc0FsbENsYXNzZXMgJiYgY2hpbGQuY2xhc3NMaXN0LmNvbnRhaW5zKGNsYXNzTmFtZVtqXSk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGhhc0FsbENsYXNzZXMpIHtcbiAgICAgICAgICByZXR1cm4gZDMuc2VsZWN0KGNoaWxkKTtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIGlmICgoIWNsYXNzTmFtZSB8fCBjaGlsZC5jbGFzc0xpc3QuY29udGFpbnMoY2xhc3NOYW1lKSkpIHtcbiAgICAgICAgcmV0dXJuIGQzLnNlbGVjdChjaGlsZCk7XG4gICAgICB9XG4gICAgfVxuICB9XG4gIHJldHVybiBkMy5zZWxlY3QobnVsbCk7XG59O1xuXG4vKipcbiAqIFNlbGVjdCBvciBjcmVhdGUgYSBzY2VuZUdyb3VwIGFuZCBidWlsZC91cGRhdGUgaXRzIG5vZGVzIGFuZCBlZGdlcy5cbiAqXG4gKiBTdHJ1Y3R1cmUgUGF0dGVybjpcbiAqXG4gKiA8ZyBjbGFzcz0nc2NlbmUnPlxuICogICA8ZyBjbGFzcz0nY29yZSc+XG4gKiAgICAgPGcgY2xhc3M9J2VkZ2VzJz5cbiAqICAgICAgIC4uLiBzdHVmZiBmcm9tIHRmLmdyYXBoLnNjZW5lLmVkZ2VzLmJ1aWxkIC4uLlxuICogICAgIDwvZz5cbiAqICAgICA8ZyBjbGFzcz0nbm9kZXMnPlxuICogICAgICAgLi4uIHN0dWZmIGZyb20gdGYuZ3JhcGguc2NlbmUubm9kZXMuYnVpbGQgLi4uXG4gKiAgICAgPC9nPlxuICogICA8L2c+XG4gKiAgIDxnIGNsYXNzPSdpbi1leHRyYWN0Jz5cbiAqICAgICA8ZyBjbGFzcz0nbm9kZXMnPlxuICogICAgICAgLi4uIHN0dWZmIGZyb20gdGYuZ3JhcGguc2NlbmUubm9kZXMuYnVpbGQgLi4uXG4gKiAgICAgPC9nPlxuICogICA8L2c+XG4gKiAgIDxnIGNsYXNzPSdvdXQtZXh0cmFjdCc+XG4gKiAgICAgPGcgY2xhc3M9J25vZGVzJz5cbiAqICAgICAgIC4uLiBzdHVmZiBmcm9tIHRmLmdyYXBoLnNjZW5lLm5vZGVzLmJ1aWxkIC4uLlxuICogICAgIDwvZz5cbiAqICAgPC9nPlxuICogPC9nPlxuICpcbiAqIEBwYXJhbSBjb250YWluZXIgRDMgc2VsZWN0aW9uIG9mIHRoZSBwYXJlbnQuXG4gKiBAcGFyYW0gcmVuZGVyTm9kZSByZW5kZXIgbm9kZSBvZiBhIG1ldGFub2RlIG9yIHNlcmllcyBub2RlLlxuICogQHBhcmFtIHNjZW5lRWxlbWVudCA8dGYtZ3JhcGgtc2NlbmU+IHBvbHltZXIgZWxlbWVudC5cbiAqIEBwYXJhbSBzY2VuZUNsYXNzIGNsYXNzIGF0dHJpYnV0ZSBvZiB0aGUgc2NlbmUgKGRlZmF1bHQ9J3NjZW5lJykuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBidWlsZEdyb3VwKGNvbnRhaW5lcixcbiAgICByZW5kZXJOb2RlOiByZW5kZXIuUmVuZGVyR3JvdXBOb2RlSW5mbyxcbiAgICBzY2VuZUVsZW1lbnQsXG4gICAgc2NlbmVDbGFzczogc3RyaW5nKTogZDMuU2VsZWN0aW9uPGFueSwgYW55LCBhbnksIGFueT4ge1xuICBzY2VuZUNsYXNzID0gc2NlbmVDbGFzcyB8fCBDbGFzcy5TY2VuZS5HUk9VUDtcbiAgbGV0IGlzTmV3U2NlbmVHcm91cCA9IHNlbGVjdENoaWxkKGNvbnRhaW5lciwgJ2cnLCBzY2VuZUNsYXNzKS5lbXB0eSgpO1xuICBsZXQgc2NlbmVHcm91cCA9IHNlbGVjdE9yQ3JlYXRlQ2hpbGQoY29udGFpbmVyLCAnZycsIHNjZW5lQ2xhc3MpO1xuXG4gIC8vIGNvcmVcbiAgbGV0IGNvcmVHcm91cCA9IHNlbGVjdE9yQ3JlYXRlQ2hpbGQoc2NlbmVHcm91cCwgJ2cnLCBDbGFzcy5TY2VuZS5DT1JFKTtcbiAgbGV0IGNvcmVOb2RlcyA9IF8ucmVkdWNlKHJlbmRlck5vZGUuY29yZUdyYXBoLm5vZGVzKCksIChub2RlcywgbmFtZSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBsZXQgbm9kZSA9IHJlbmRlck5vZGUuY29yZUdyYXBoLm5vZGUobmFtZSk7XG4gICAgICAgICAgICAgICAgICAgIGlmICghbm9kZS5leGNsdWRlZCkge1xuICAgICAgICAgICAgICAgICAgICAgIG5vZGVzLnB1c2gobm9kZSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG5vZGVzO1xuICAgICAgICAgICAgICAgICAgfSwgW10pO1xuXG4gIGlmIChyZW5kZXJOb2RlLm5vZGUudHlwZSA9PT0gTm9kZVR5cGUuU0VSSUVTKSB7XG4gICAgLy8gRm9yIHNlcmllcywgd2Ugd2FudCB0aGUgZmlyc3QgaXRlbSBvbiB0b3AsIHNvIHJldmVyc2UgdGhlIGFycmF5IHNvXG4gICAgLy8gdGhlIGZpcnN0IGl0ZW0gaW4gdGhlIHNlcmllcyBiZWNvbWVzIGxhc3QgaXRlbSBpbiB0aGUgdG9wLCBhbmQgdGh1c1xuICAgIC8vIGlzIHJlbmRlcmVkIG9uIHRoZSB0b3AuXG4gICAgY29yZU5vZGVzLnJldmVyc2UoKTtcbiAgfVxuXG4gIC8vIENyZWF0ZSB0aGUgbGF5ZXIgb2YgZWRnZXMgZm9yIHRoaXMgc2NlbmUgKHBhdGhzKS5cbiAgZWRnZS5idWlsZEdyb3VwKGNvcmVHcm91cCwgcmVuZGVyTm9kZS5jb3JlR3JhcGgsIHNjZW5lRWxlbWVudCk7XG5cbiAgLy8gQ3JlYXRlIHRoZSBsYXllciBvZiBub2RlcyBmb3IgdGhpcyBzY2VuZSAoZWxsaXBzZXMsIHJlY3RzIGV0YykuXG4gIG5vZGUuYnVpbGRHcm91cChjb3JlR3JvdXAsIGNvcmVOb2Rlcywgc2NlbmVFbGVtZW50KTtcblxuICAvLyBJbi1leHRyYWN0XG4gIGlmIChyZW5kZXJOb2RlLmlzb2xhdGVkSW5FeHRyYWN0Lmxlbmd0aCA+IDApIHtcbiAgICBsZXQgaW5FeHRyYWN0R3JvdXAgPVxuICAgICAgICBzZWxlY3RPckNyZWF0ZUNoaWxkKHNjZW5lR3JvdXAsICdnJywgQ2xhc3MuU2NlbmUuSU5FWFRSQUNUKTtcbiAgICBub2RlLmJ1aWxkR3JvdXAoaW5FeHRyYWN0R3JvdXAsIHJlbmRlck5vZGUuaXNvbGF0ZWRJbkV4dHJhY3QsXG4gICAgICAgIHNjZW5lRWxlbWVudCk7XG4gIH0gZWxzZSB7XG4gICAgc2VsZWN0Q2hpbGQoc2NlbmVHcm91cCwgJ2cnLCBDbGFzcy5TY2VuZS5JTkVYVFJBQ1QpLnJlbW92ZSgpO1xuICB9XG5cbiAgLy8gT3V0LWV4dHJhY3RcbiAgaWYgKHJlbmRlck5vZGUuaXNvbGF0ZWRPdXRFeHRyYWN0Lmxlbmd0aCA+IDApIHtcbiAgICBsZXQgb3V0RXh0cmFjdEdyb3VwID1cbiAgICAgICAgc2VsZWN0T3JDcmVhdGVDaGlsZChzY2VuZUdyb3VwLCAnZycsIENsYXNzLlNjZW5lLk9VVEVYVFJBQ1QpO1xuICAgIG5vZGUuYnVpbGRHcm91cChvdXRFeHRyYWN0R3JvdXAsIHJlbmRlck5vZGUuaXNvbGF0ZWRPdXRFeHRyYWN0LFxuICAgICAgICBzY2VuZUVsZW1lbnQpO1xuICB9IGVsc2Uge1xuICAgIHNlbGVjdENoaWxkKHNjZW5lR3JvdXAsICdnJywgQ2xhc3MuU2NlbmUuT1VURVhUUkFDVCkucmVtb3ZlKCk7XG4gIH1cblxuICAvLyBMaWJyYXJ5IGZ1bmN0aW9uc1xuICBpZiAocmVuZGVyTm9kZS5saWJyYXJ5RnVuY3Rpb25zRXh0cmFjdC5sZW5ndGggPiAwKSB7XG4gICAgbGV0IG91dEV4dHJhY3RHcm91cCA9XG4gICAgICAgIHNlbGVjdE9yQ3JlYXRlQ2hpbGQoc2NlbmVHcm91cCwgJ2cnLCBDbGFzcy5TY2VuZS5GVU5DVElPTl9MSUJSQVJZKTtcbiAgICBub2RlLmJ1aWxkR3JvdXAob3V0RXh0cmFjdEdyb3VwLCByZW5kZXJOb2RlLmxpYnJhcnlGdW5jdGlvbnNFeHRyYWN0LFxuICAgICAgICBzY2VuZUVsZW1lbnQpO1xuICB9IGVsc2Uge1xuICAgIHNlbGVjdENoaWxkKHNjZW5lR3JvdXAsICdnJywgQ2xhc3MuU2NlbmUuRlVOQ1RJT05fTElCUkFSWSkucmVtb3ZlKCk7XG4gIH1cblxuICBwb3NpdGlvbihzY2VuZUdyb3VwLCByZW5kZXJOb2RlKTtcblxuICAvLyBGYWRlIGluIHRoZSBzY2VuZSBncm91cCBpZiBpdCBkaWRuJ3QgYWxyZWFkeSBleGlzdC5cbiAgaWYgKGlzTmV3U2NlbmVHcm91cCkge1xuICAgIHNjZW5lR3JvdXAuYXR0cignb3BhY2l0eScsIDApLnRyYW5zaXRpb24oKS5hdHRyKCdvcGFjaXR5JywgMSk7XG4gIH1cblxuICByZXR1cm4gc2NlbmVHcm91cDtcbn07XG5cbi8qKlxuICogR2l2ZW4gYSBzY2VuZSdzIHN2ZyBncm91cCwgc2V0ICBnLmluLWV4dHJhY3QsIGcuY29yZUdyYXBoLCBnLm91dC1leHRyYWN0IHN2Z1xuICogZ3JvdXBzJyBwb3NpdGlvbiByZWxhdGl2ZSB0byB0aGUgc2NlbmUuXG4gKlxuICogQHBhcmFtIHNjZW5lR3JvdXBcbiAqIEBwYXJhbSByZW5kZXJOb2RlIHJlbmRlciBub2RlIG9mIGEgbWV0YW5vZGUgb3Igc2VyaWVzIG5vZGUuXG4gKi9cbmZ1bmN0aW9uIHBvc2l0aW9uKHNjZW5lR3JvdXAsIHJlbmRlck5vZGU6IHJlbmRlci5SZW5kZXJHcm91cE5vZGVJbmZvKSB7XG4gIC8vIFRyYW5zbGF0ZSBzY2VuZXMgZG93biBieSB0aGUgbGFiZWwgaGVpZ2h0IHNvIHRoYXQgd2hlbiBzaG93aW5nIGdyYXBocyBpblxuICAvLyBleHBhbmRlZCBtZXRhbm9kZXMsIHRoZSBncmFwaHMgYXJlIGJlbG93IHRoZSBsYWJlbHMuICBEbyBub3Qgc2hpZnQgdGhlbVxuICAvLyBkb3duIGZvciBzZXJpZXMgbm9kZXMgYXMgc2VyaWVzIG5vZGVzIGRvbid0IGhhdmUgbGFiZWxzIGluc2lkZSBvZiB0aGVpclxuICAvLyBib3VuZGluZyBib3hlcy5cbiAgbGV0IHlUcmFuc2xhdGUgPSByZW5kZXJOb2RlLm5vZGUudHlwZSA9PT0gTm9kZVR5cGUuU0VSSUVTID9cbiAgICAwIDogbGF5b3V0LlBBUkFNUy5zdWJzY2VuZS5tZXRhLmxhYmVsSGVpZ2h0O1xuXG4gIC8vIGNvcmVcbiAgdHJhbnNsYXRlKHNlbGVjdENoaWxkKHNjZW5lR3JvdXAsICdnJywgQ2xhc3MuU2NlbmUuQ09SRSksIDAsIHlUcmFuc2xhdGUpO1xuXG4gIC8vIGluLWV4dHJhY3RcbiAgbGV0IGhhc0luRXh0cmFjdCA9IHJlbmRlck5vZGUuaXNvbGF0ZWRJbkV4dHJhY3QubGVuZ3RoID4gMDtcbiAgbGV0IGhhc091dEV4dHJhY3QgPSByZW5kZXJOb2RlLmlzb2xhdGVkT3V0RXh0cmFjdC5sZW5ndGggPiAwO1xuICBsZXQgaGFzTGlicmFyeUZ1bmN0aW9ucyA9IHJlbmRlck5vZGUubGlicmFyeUZ1bmN0aW9uc0V4dHJhY3QubGVuZ3RoID4gMDtcblxuICBsZXQgb2Zmc2V0ID0gbGF5b3V0LlBBUkFNUy5zdWJzY2VuZS5tZXRhLmV4dHJhY3RYT2Zmc2V0O1xuXG4gIGxldCBhdXhXaWR0aCA9IDA7XG4gIGlmIChoYXNJbkV4dHJhY3QpIHtcbiAgICBhdXhXaWR0aCArPSByZW5kZXJOb2RlLm91dEV4dHJhY3RCb3gud2lkdGg7XG4gIH1cbiAgaWYgKGhhc091dEV4dHJhY3QpIHtcbiAgICBhdXhXaWR0aCArPSByZW5kZXJOb2RlLm91dEV4dHJhY3RCb3gud2lkdGg7XG4gIH1cblxuICBpZiAoaGFzSW5FeHRyYWN0KSB7XG4gICAgbGV0IGluRXh0cmFjdFggPSByZW5kZXJOb2RlLmNvcmVCb3gud2lkdGg7XG4gICAgaWYgKGF1eFdpZHRoIDwgbGF5b3V0Lk1JTl9BVVhfV0lEVEgpIHtcbiAgICAgIGluRXh0cmFjdFggPSBpbkV4dHJhY3RYIC0gbGF5b3V0Lk1JTl9BVVhfV0lEVEggK1xuICAgICAgICAgIHJlbmRlck5vZGUuaW5FeHRyYWN0Qm94LndpZHRoIC8gMjtcbiAgICB9IGVsc2Uge1xuICAgICAgaW5FeHRyYWN0WCA9IGluRXh0cmFjdFggLVxuICAgICAgICAgIHJlbmRlck5vZGUuaW5FeHRyYWN0Qm94LndpZHRoIC8gMiAtIHJlbmRlck5vZGUub3V0RXh0cmFjdEJveC53aWR0aCAtXG4gICAgICAgICAgKGhhc091dEV4dHJhY3QgPyBvZmZzZXQgOiAwKTtcbiAgICB9XG4gICAgaW5FeHRyYWN0WCA9IGluRXh0cmFjdFggLVxuICAgICAgICByZW5kZXJOb2RlLmxpYnJhcnlGdW5jdGlvbnNCb3gud2lkdGggLVxuICAgICAgICAoaGFzTGlicmFyeUZ1bmN0aW9ucyA/IG9mZnNldCA6IDApO1xuICAgIHRyYW5zbGF0ZShcbiAgICAgICAgc2VsZWN0Q2hpbGQoc2NlbmVHcm91cCwgJ2cnLCBDbGFzcy5TY2VuZS5JTkVYVFJBQ1QpLCBpbkV4dHJhY3RYLFxuICAgICAgICB5VHJhbnNsYXRlKTtcbiAgfVxuXG4gIC8vIG91dC1leHRyYWN0XG4gIGlmIChoYXNPdXRFeHRyYWN0KSB7XG4gICAgbGV0IG91dEV4dHJhY3RYID0gcmVuZGVyTm9kZS5jb3JlQm94LndpZHRoO1xuICAgIGlmIChhdXhXaWR0aCA8IGxheW91dC5NSU5fQVVYX1dJRFRIKSB7XG4gICAgICBvdXRFeHRyYWN0WCA9IG91dEV4dHJhY3RYIC0gbGF5b3V0Lk1JTl9BVVhfV0lEVEggK1xuICAgICAgICAgIHJlbmRlck5vZGUub3V0RXh0cmFjdEJveC53aWR0aCAvIDI7XG4gICAgfSBlbHNlIHtcbiAgICAgIG91dEV4dHJhY3RYIC09IHJlbmRlck5vZGUub3V0RXh0cmFjdEJveC53aWR0aCAvIDI7XG4gICAgfVxuICAgIG91dEV4dHJhY3RYID0gb3V0RXh0cmFjdFggLVxuICAgICAgcmVuZGVyTm9kZS5saWJyYXJ5RnVuY3Rpb25zQm94LndpZHRoIC1cbiAgICAgIChoYXNMaWJyYXJ5RnVuY3Rpb25zID8gb2Zmc2V0IDogMCk7XG4gICAgdHJhbnNsYXRlKFxuICAgICAgICBzZWxlY3RDaGlsZChzY2VuZUdyb3VwLCAnZycsIENsYXNzLlNjZW5lLk9VVEVYVFJBQ1QpLCBvdXRFeHRyYWN0WCxcbiAgICAgICAgeVRyYW5zbGF0ZSk7XG4gIH1cblxuICBpZiAoaGFzTGlicmFyeUZ1bmN0aW9ucykge1xuICAgIGxldCBsaWJyYXJ5RnVuY3Rpb25zRXh0cmFjdFggPSByZW5kZXJOb2RlLmNvcmVCb3gud2lkdGggLVxuICAgICAgICByZW5kZXJOb2RlLmxpYnJhcnlGdW5jdGlvbnNCb3gud2lkdGggLyAyO1xuICAgIHRyYW5zbGF0ZShcbiAgICAgICAgc2VsZWN0Q2hpbGQoc2NlbmVHcm91cCwgJ2cnLCBDbGFzcy5TY2VuZS5GVU5DVElPTl9MSUJSQVJZKSxcbiAgICAgICAgbGlicmFyeUZ1bmN0aW9uc0V4dHJhY3RYLFxuICAgICAgICB5VHJhbnNsYXRlKTtcbiAgfVxufTtcblxuLyoqIEFkZHMgYSBjbGljayBsaXN0ZW5lciB0byBhIGdyb3VwIHRoYXQgZmlyZXMgYSBncmFwaC1zZWxlY3QgZXZlbnQgKi9cbmV4cG9ydCBmdW5jdGlvbiBhZGRHcmFwaENsaWNrTGlzdGVuZXIoZ3JhcGhHcm91cCwgc2NlbmVFbGVtZW50KSB7XG4gIGQzLnNlbGVjdChncmFwaEdyb3VwKS5vbignY2xpY2snLCAoKSA9PiB7XG4gICAgc2NlbmVFbGVtZW50LmZpcmUoJ2dyYXBoLXNlbGVjdCcpO1xuICB9KTtcbn07XG5cbi8qKiBIZWxwZXIgZm9yIGFkZGluZyB0cmFuc2Zvcm06IHRyYW5zbGF0ZSh4MCwgeTApICovXG5leHBvcnQgZnVuY3Rpb24gdHJhbnNsYXRlKHNlbGVjdGlvbiwgeDA6IG51bWJlciwgeTA6IG51bWJlcikge1xuICAvLyBJZiBpdCBpcyBhbHJlYWR5IHBsYWNlZCBvbiB0aGUgc2NyZWVuLCBtYWtlIGl0IGEgdHJhbnNpdGlvbi5cbiAgaWYgKHNlbGVjdGlvbi5hdHRyKCd0cmFuc2Zvcm0nKSAhPSBudWxsKSB7XG4gICAgc2VsZWN0aW9uID0gc2VsZWN0aW9uLnRyYW5zaXRpb24oJ3Bvc2l0aW9uJyk7XG4gIH1cbiAgc2VsZWN0aW9uLmF0dHIoJ3RyYW5zZm9ybScsICd0cmFuc2xhdGUoJyArIHgwICsgJywnICsgeTAgKyAnKScpO1xufTtcblxuLyoqXG4gKiBIZWxwZXIgZm9yIHNldHRpbmcgcG9zaXRpb24gb2YgYSBzdmcgcmVjdFxuICogQHBhcmFtIHJlY3QgQSBkMyBzZWxlY3Rpb24gb2YgcmVjdChzKSB0byBzZXQgcG9zaXRpb24gb2YuXG4gKiBAcGFyYW0gY3ggQ2VudGVyIHguXG4gKiBAcGFyYW0gY3kgQ2VudGVyIHguXG4gKiBAcGFyYW0gd2lkdGggV2lkdGggdG8gc2V0LlxuICogQHBhcmFtIGhlaWdodCBIZWlnaHQgdG8gc2V0LlxuICovXG5leHBvcnQgZnVuY3Rpb24gcG9zaXRpb25SZWN0KHJlY3QsIGN4OiBudW1iZXIsIGN5OiBudW1iZXIsIHdpZHRoOiBudW1iZXIsXG4gICAgaGVpZ2h0OiBudW1iZXIpIHtcbiAgcmVjdC50cmFuc2l0aW9uKClcbiAgICAuYXR0cigneCcsIGN4IC0gd2lkdGggLyAyKVxuICAgIC5hdHRyKCd5JywgY3kgLSBoZWlnaHQgLyAyKVxuICAgIC5hdHRyKCd3aWR0aCcsIHdpZHRoKVxuICAgIC5hdHRyKCdoZWlnaHQnLCBoZWlnaHQpO1xufTtcblxuLyoqXG4gKiBQb3NpdGlvbnMgYSB0cmlhbmdsZSBhbmQgc2l6ZXMgaXQuXG4gKiBAcGFyYW0gcG9seWdvbiBwb2x5Z29uIHRvIHNldCBwb3NpdGlvbiBvZi5cbiAqIEBwYXJhbSBjeCBDZW50ZXIgeC5cbiAqIEBwYXJhbSBjeSBDZW50ZXIgeS5cbiAqIEBwYXJhbSB3aWR0aCBXaWR0aCBvZiBib3VuZGluZyBib3ggZm9yIHRyaWFuZ2xlLlxuICogQHBhcmFtIGhlaWdodCBIZWlnaHQgb2YgYm91bmRpbmcgYm94IGZvciB0cmlhbmdsZS5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHBvc2l0aW9uVHJpYW5nbGUocG9seWdvbiwgY3gsIGN5LCB3aWR0aCwgaGVpZ2h0KSB7XG4gIGNvbnN0IGhhbGZIZWlnaHQgPSBoZWlnaHQgLyAyO1xuICBjb25zdCBoYWxmV2lkdGggPSB3aWR0aCAvIDI7XG4gIGNvbnN0IHBvaW50cyA9IFtcbiAgICBbY3gsIGN5IC0gaGFsZkhlaWdodF0sXG4gICAgW2N4ICsgaGFsZldpZHRoLCBjeSArIGhhbGZIZWlnaHRdLFxuICAgIFtjeCAtIGhhbGZXaWR0aCwgY3kgKyBoYWxmSGVpZ2h0XVxuICBdO1xuICBwb2x5Z29uLnRyYW5zaXRpb24oKS5hdHRyKFxuICAgICAgJ3BvaW50cycsIHBvaW50cy5tYXAocG9pbnQgPT4gcG9pbnQuam9pbignLCcpKS5qb2luKCcgJykpO1xufTtcblxuLyoqXG4gKiBIZWxwZXIgZm9yIHNldHRpbmcgcG9zaXRpb24gb2YgYSBzdmcgZXhwYW5kL2NvbGxhcHNlIGJ1dHRvblxuICogQHBhcmFtIGJ1dHRvbiBjb250YWluZXIgZ3JvdXBcbiAqIEBwYXJhbSByZW5kZXJOb2RlIHRoZSByZW5kZXIgbm9kZSBvZiB0aGUgZ3JvdXAgbm9kZSB0byBwb3NpdGlvblxuICogICAgICAgIHRoZSBidXR0b24gb24uXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBwb3NpdGlvbkJ1dHRvbihidXR0b24sIHJlbmRlck5vZGU6IHJlbmRlci5SZW5kZXJOb2RlSW5mbykge1xuICBsZXQgY3ggPSBsYXlvdXQuY29tcHV0ZUNYUG9zaXRpb25PZk5vZGVTaGFwZShyZW5kZXJOb2RlKTtcbiAgLy8gUG9zaXRpb24gdGhlIGJ1dHRvbiBpbiB0aGUgdG9wLXJpZ2h0IGNvcm5lciBvZiB0aGUgZ3JvdXAgbm9kZSxcbiAgLy8gd2l0aCBzcGFjZSBnaXZlbiB0aGUgZHJhdyB0aGUgYnV0dG9uIGluc2lkZSBvZiB0aGUgY29ybmVyLlxuICBsZXQgd2lkdGggPSByZW5kZXJOb2RlLmV4cGFuZGVkID9cbiAgICAgIHJlbmRlck5vZGUud2lkdGggOiByZW5kZXJOb2RlLmNvcmVCb3gud2lkdGg7XG4gIGxldCBoZWlnaHQgPSByZW5kZXJOb2RlLmV4cGFuZGVkID9cbiAgICAgIHJlbmRlck5vZGUuaGVpZ2h0IDogcmVuZGVyTm9kZS5jb3JlQm94LmhlaWdodDtcbiAgbGV0IHggPSBjeCArIHdpZHRoIC8gMiAtIDY7XG4gIGxldCB5ID0gcmVuZGVyTm9kZS55IC0gaGVpZ2h0IC8gMiArIDY7XG4gIC8vIEZvciB1bmV4cGFuZGVkIHNlcmllcyBub2RlcywgdGhlIGJ1dHRvbiBoYXMgc3BlY2lhbCBwbGFjZW1lbnQgZHVlXG4gIC8vIHRvIHRoZSB1bmlxdWUgdmlzdWFscyBvZiB0aGlzIGdyb3VwIG5vZGUuXG4gIGlmIChyZW5kZXJOb2RlLm5vZGUudHlwZSA9PT0gTm9kZVR5cGUuU0VSSUVTICYmICFyZW5kZXJOb2RlLmV4cGFuZGVkKSB7XG4gICAgeCArPSAxMDtcbiAgICB5IC09IDI7XG4gIH1cbiAgbGV0IHRyYW5zbGF0ZVN0ciA9ICd0cmFuc2xhdGUoJyArIHggKyAnLCcgKyB5ICsgJyknO1xuICBidXR0b24uc2VsZWN0QWxsKCdwYXRoJykudHJhbnNpdGlvbigpLmF0dHIoJ3RyYW5zZm9ybScsIHRyYW5zbGF0ZVN0cik7XG4gIGJ1dHRvbi5zZWxlY3QoJ2NpcmNsZScpLnRyYW5zaXRpb24oKS5hdHRyKFxuICAgICAge2N4OiB4LCBjeTogeSwgcjogbGF5b3V0LlBBUkFNUy5ub2RlU2l6ZS5tZXRhLmV4cGFuZEJ1dHRvblJhZGl1c30pO1xufTtcblxuLyoqXG4gKiBIZWxwZXIgZm9yIHNldHRpbmcgcG9zaXRpb24gb2YgYSBzdmcgZWxsaXBzZVxuICogQHBhcmFtIGVsbGlwc2UgZWxsaXBzZSB0byBzZXQgcG9zaXRpb24gb2YuXG4gKiBAcGFyYW0gY3ggQ2VudGVyIHguXG4gKiBAcGFyYW0gY3kgQ2VudGVyIHguXG4gKiBAcGFyYW0gd2lkdGggV2lkdGggdG8gc2V0LlxuICogQHBhcmFtIGhlaWdodCBIZWlnaHQgdG8gc2V0LlxuICovXG5leHBvcnQgZnVuY3Rpb24gcG9zaXRpb25FbGxpcHNlKGVsbGlwc2UsIGN4OiBudW1iZXIsIGN5OiBudW1iZXIsXG4gICAgd2lkdGg6IG51bWJlciwgaGVpZ2h0OiBudW1iZXIpIHtcbiAgZWxsaXBzZS50cmFuc2l0aW9uKClcbiAgICAuYXR0cignY3gnLCBjeClcbiAgICAuYXR0cignY3knLCBjeSlcbiAgICAuYXR0cigncngnLCB3aWR0aCAvIDIpXG4gICAgLmF0dHIoJ3J5JywgaGVpZ2h0IC8gMik7XG59O1xuXG4vKipcbiAqIEBwYXJhbSB7bnVtYmVyfSBzdGF0IEEgc3RhdCBmb3IgYSBoZWFsdGggcGlsbCAoc3VjaCBhcyBtZWFuIG9yIHZhcmlhbmNlKS5cbiAqIEBwYXJhbSB7Ym9vbGVhbn0gc2hvdWxkUm91bmRPbmVzRGlnaXQgV2hldGhlciB0byByb3VuZCB0aGlzIG51bWJlciB0byB0aGVcbiAqICAgICBvbmVzIGRpZ2l0LiBVc2VmdWwgZm9yIHNheSBpbnQsIHVpbnQsIGFuZCBib29sIG91dHB1dCB0eXBlcy5cbiAqIEByZXR1cm4ge3N0cmluZ30gQSBodW1hbi1mcmllbmRseSBzdHJpbmcgcmVwcmVzZW50YXRpb24gb2YgdGhhdCBzdGF0LlxuICovXG5leHBvcnQgZnVuY3Rpb24gaHVtYW5pemVIZWFsdGhQaWxsU3RhdChzdGF0LCBzaG91bGRSb3VuZE9uZXNEaWdpdCkge1xuICBpZiAoc2hvdWxkUm91bmRPbmVzRGlnaXQpIHtcbiAgICByZXR1cm4gc3RhdC50b0ZpeGVkKDApO1xuICB9XG4gIGlmIChNYXRoLmFicyhzdGF0KSA+PSAxKSB7XG4gICAgcmV0dXJuIHN0YXQudG9GaXhlZCgxKTtcbiAgfVxuICByZXR1cm4gc3RhdC50b0V4cG9uZW50aWFsKDEpO1xufVxuXG4vKipcbiAqIEdldCB0ZXh0IGNvbnRlbnQgZGVzY3JpYmluZyBhIGhlYWx0aCBwaWxsLlxuICovXG5mdW5jdGlvbiBfZ2V0SGVhbHRoUGlsbFRleHRDb250ZW50KGhlYWx0aFBpbGw6IEhlYWx0aFBpbGwsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvdGFsQ291bnQ6IG51bWJlcixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZWxlbWVudHNCcmVha2Rvd246IG51bWJlcltdLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBudW1lcmljU3RhdHM6IEhlYWx0aFBpbGxOdW1lcmljU3RhdHMpIHtcbiAgbGV0IHRleHQgPSAnRGV2aWNlOiAnICsgaGVhbHRoUGlsbC5kZXZpY2VfbmFtZSArICdcXG4nO1xuICB0ZXh0ICs9ICdkdHlwZTogJyArIGhlYWx0aFBpbGwuZHR5cGUgKyAnXFxuJztcblxuICBsZXQgc2hhcGVTdHIgPSAnKHNjYWxhciknO1xuICBpZiAoaGVhbHRoUGlsbC5zaGFwZS5sZW5ndGggPiAwKSB7XG4gICAgc2hhcGVTdHIgPSAnKCcgKyBoZWFsdGhQaWxsLnNoYXBlLmpvaW4oJywnKSArICcpJztcbiAgfVxuICB0ZXh0ICs9ICdcXG5zaGFwZTogJyArIHNoYXBlU3RyICsgJ1xcblxcbic7XG5cbiAgdGV4dCArPSAnIyhlbGVtZW50cyk6ICcgKyB0b3RhbENvdW50ICsgJ1xcbic7XG4gIGNvbnN0IGJyZWFrZG93bkl0ZW1zID0gW107XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgZWxlbWVudHNCcmVha2Rvd24ubGVuZ3RoOyBpKyspIHtcbiAgICBpZiAoZWxlbWVudHNCcmVha2Rvd25baV0gPiAwKSB7XG4gICAgICBicmVha2Rvd25JdGVtcy5wdXNoKFxuICAgICAgICAgICcjKCcgKyBoZWFsdGhQaWxsRW50cmllc1tpXS5sYWJlbCArICcpOiAnICsgZWxlbWVudHNCcmVha2Rvd25baV0pO1xuICAgIH1cbiAgfVxuICB0ZXh0ICs9IGJyZWFrZG93bkl0ZW1zLmpvaW4oJywgJykgKyAnXFxuXFxuJztcblxuICAvLyBJbiBzb21lIGNhc2VzIChlLmcuLCBzaXplLTAgdGVuc29yczsgYWxsIGVsZW1lbnRzIGFyZSBuYW4gb3IgaW5mKSB0aGVcbiAgLy8gbWluL21heCBhbmQgbWVhbi9zdGRkZXYgc3RhdHMgYXJlIG1lYW5pbmdsZXNzLlxuICBpZiAobnVtZXJpY1N0YXRzLm1heCA+PSBudW1lcmljU3RhdHMubWluKSB7XG4gICAgdGV4dCArPSAnbWluOiAnICsgbnVtZXJpY1N0YXRzLm1pbiArICcsIG1heDogJyArIG51bWVyaWNTdGF0cy5tYXggKyAnXFxuJztcbiAgICB0ZXh0ICs9ICdtZWFuOiAnICsgbnVtZXJpY1N0YXRzLm1lYW4gKyAnLCBzdGRkZXY6ICcgKyBudW1lcmljU3RhdHMuc3RkZGV2O1xuICB9XG5cbiAgcmV0dXJuIHRleHQ7XG59XG5cbi8qKlxuICogUmVuZGVycyBhIGhlYWx0aCBwaWxsIGZvciBhbiBvcCBhdG9wIGEgbm9kZS5cbiAqIG5vZGVHcm91cEVsZW1lbnQ6IFRoZSBTVkcgZWxlbWVudCBpbiB3aGljaCB0byByZW5kZXIuXG4gKiBoZWFsdGhQaWxsOiBBIGxpc3Qgb2YgYmFja2VuZC5IZWFsdGhQaWxsIG9iamVjdHMuXG4gKiBub2RlSW5mbzogSW5mbyBvbiB0aGUgYXNzb2NpYXRlZCBub2RlLlxuICogaGVhbHRoUGlsbElkOiBBIHVuaXF1ZSBudW1lcmljIElEIGFzc2lnbmVkIHRvIHRoaXMgaGVhbHRoIHBpbGwuXG4gKiBoZWFsdGhQaWxsV2lkdGg6IE9wdGlvbmFsIHdpZHRoIG9mIHRoZSBoZWFsdGggcGlsbC5cbiAqIGhlYWx0aFBpbGxIZWlnaHQ6IE9wdGlvbmFsIGhlaWdodCBvZiB0aGUgaGVhbHRoIHBpbGwuXG4gKiBoZWFsdGhQaWxsWU9mZnNldDogT3B0aW9uYWwgeS1vZmZzZXQgb2YgdGhlIGhlYWx0aCBwaWxsICh0aGF0IGlzLCB0aGVcbiAqICAgY29sb3ItY29kZWQgcmVnaW9uKS5cbiAqIHRleHRPZmZzZXQ6IE9wdGlvbmFsIHZhbHVlIGZvciB0aGUgeC1vZmZzZXQgb2YgdGhlIHRvcCB0ZXh0IGxhYmVsXG4gKiAgIHJlbGF0aXZlIHRvIHRoZSBsZWZ0IGVkZ2Ugb2YgdGhlIGhlYWx0aCBwaWxsLiBJZiBub3QgcHJvdmlkZWQsIHdpbGxcbiAqICAgZGVmYXVsdCB0byBgaGVhbHRoUGlsbFdpZHRoIC8gMmAuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBhZGRIZWFsdGhQaWxsKFxuICAgIG5vZGVHcm91cEVsZW1lbnQ6IFNWR0VsZW1lbnQsIGhlYWx0aFBpbGw6IEhlYWx0aFBpbGwsXG4gICAgbm9kZUluZm86IHJlbmRlci5SZW5kZXJOb2RlSW5mbywgaGVhbHRoUGlsbElkOiBudW1iZXIsXG4gICAgaGVhbHRoUGlsbFdpZHRoID0gNjAsIGhlYWx0aFBpbGxIZWlnaHQgPSAxMCwgaGVhbHRoUGlsbFlPZmZzZXQgPSAwLFxuICAgIHRleHRYT2Zmc2V0PzogbnVtYmVyKSB7XG4gIC8vIENoZWNrIGlmIHRleHQgYWxyZWFkeSBleGlzdHMgYXQgbG9jYXRpb24uXG4gIGQzLnNlbGVjdChub2RlR3JvdXBFbGVtZW50LnBhcmVudE5vZGUgYXMgYW55KS5zZWxlY3RBbGwoJy5oZWFsdGgtcGlsbCcpLnJlbW92ZSgpO1xuXG4gIGlmICghaGVhbHRoUGlsbCkge1xuICAgIHJldHVybjtcbiAgfVxuXG4gIGNvbnN0IGxhc3RIZWFsdGhQaWxsRGF0YSA9IGhlYWx0aFBpbGwudmFsdWU7XG5cbiAgLy8gRm9yIG5vdywgd2Ugb25seSB2aXN1YWxpemUgdGhlIDYgdmFsdWVzIHRoYXQgc3VtbWFyaXplIGNvdW50cyBvZiB0ZW5zb3JcbiAgLy8gZWxlbWVudHMgb2YgdmFyaW91cyBjYXRlZ29yaWVzOiAtSW5mLCBuZWdhdGl2ZSwgMCwgcG9zaXRpdmUsIEluZiwgYW5kIE5hTi5cbiAgY29uc3QgbGFzdEhlYWx0aFBpbGxFbGVtZW50c0JyZWFrZG93biA9IGxhc3RIZWFsdGhQaWxsRGF0YS5zbGljZSgyLCA4KTtcbiAgY29uc3QgbmFuQ291bnQgPSBsYXN0SGVhbHRoUGlsbEVsZW1lbnRzQnJlYWtkb3duWzBdO1xuICBjb25zdCBuZWdJbmZDb3VudCA9IGxhc3RIZWFsdGhQaWxsRWxlbWVudHNCcmVha2Rvd25bMV07XG4gIGNvbnN0IHBvc0luZkNvdW50ID0gbGFzdEhlYWx0aFBpbGxFbGVtZW50c0JyZWFrZG93bls1XTtcbiAgbGV0IHRvdGFsQ291bnQgPSBsYXN0SGVhbHRoUGlsbERhdGFbMV07XG4gIGNvbnN0IG51bWVyaWNTdGF0czogSGVhbHRoUGlsbE51bWVyaWNTdGF0cyA9IHtcbiAgICAgIG1pbjogbGFzdEhlYWx0aFBpbGxEYXRhWzhdLFxuICAgICAgbWF4OiBsYXN0SGVhbHRoUGlsbERhdGFbOV0sXG4gICAgICBtZWFuOiBsYXN0SGVhbHRoUGlsbERhdGFbMTBdLFxuICAgICAgc3RkZGV2OiBNYXRoLnNxcnQobGFzdEhlYWx0aFBpbGxEYXRhWzExXSlcbiAgfTtcblxuICBpZiAoaGVhbHRoUGlsbFdpZHRoID09IG51bGwpIHtcbiAgICBoZWFsdGhQaWxsV2lkdGggPSA2MDtcbiAgfVxuICBpZiAoaGVhbHRoUGlsbEhlaWdodCA9PSBudWxsKSB7XG4gICAgaGVhbHRoUGlsbEhlaWdodCA9IDEwO1xuICB9XG4gIGlmIChoZWFsdGhQaWxsWU9mZnNldCA9PSBudWxsKSB7XG4gICAgaGVhbHRoUGlsbFlPZmZzZXQgPSAwO1xuICB9XG4gIGlmIChub2RlSW5mbyAhPSBudWxsICYmIG5vZGVJbmZvLm5vZGUudHlwZSA9PT0gdGYuZ3JhcGguTm9kZVR5cGUuT1ApIHtcbiAgICAvLyBVc2UgYSBzbWFsbGVyIGhlYWx0aCBwaWxsIGZvciBvcCBub2RlcyAocmVuZGVyZWQgYXMgc21hbGxlciBlbGxpcHNlcykuXG4gICAgaGVhbHRoUGlsbFdpZHRoIC89IDI7XG4gICAgaGVhbHRoUGlsbEhlaWdodCAvPSAyO1xuICB9XG5cbiAgbGV0IGhlYWx0aFBpbGxHcm91cCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnROUyhTVkdfTkFNRVNQQUNFLCAnZycpO1xuICBoZWFsdGhQaWxsR3JvdXAuY2xhc3NMaXN0LmFkZCgnaGVhbHRoLXBpbGwnKTtcblxuICAvLyBEZWZpbmUgdGhlIGdyYWRpZW50IGZvciB0aGUgaGVhbHRoIHBpbGwuXG4gIGxldCBoZWFsdGhQaWxsRGVmcyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnROUyhTVkdfTkFNRVNQQUNFLCAnZGVmcycpO1xuICBoZWFsdGhQaWxsR3JvdXAuYXBwZW5kQ2hpbGQoaGVhbHRoUGlsbERlZnMpO1xuICBsZXQgaGVhbHRoUGlsbEdyYWRpZW50ID1cbiAgICAgIGRvY3VtZW50LmNyZWF0ZUVsZW1lbnROUyhTVkdfTkFNRVNQQUNFLCAnbGluZWFyR3JhZGllbnQnKTtcblxuICAvLyBFdmVyeSBlbGVtZW50IGluIGEgd2ViIHBhZ2UgbXVzdCBoYXZlIGEgdW5pcXVlIElELlxuICBjb25zdCBoZWFsdGhQaWxsR3JhZGllbnRJZCA9ICdoZWFsdGgtcGlsbC1ncmFkaWVudC0nICsgaGVhbHRoUGlsbElkO1xuICBoZWFsdGhQaWxsR3JhZGllbnQuc2V0QXR0cmlidXRlKCdpZCcsIGhlYWx0aFBpbGxHcmFkaWVudElkKTtcblxuICBsZXQgY3VtdWxhdGl2ZUNvdW50ID0gMDtcbiAgbGV0IHByZXZpb3VzT2Zmc2V0ID0gJzAlJztcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBsYXN0SGVhbHRoUGlsbEVsZW1lbnRzQnJlYWtkb3duLmxlbmd0aDsgaSsrKSB7XG4gICAgaWYgKCFsYXN0SGVhbHRoUGlsbEVsZW1lbnRzQnJlYWtkb3duW2ldKSB7XG4gICAgICAvLyBFeGNsdWRlIGVtcHR5IGNhdGVnb3JpZXMuXG4gICAgICBjb250aW51ZTtcbiAgICB9XG4gICAgY3VtdWxhdGl2ZUNvdW50ICs9IGxhc3RIZWFsdGhQaWxsRWxlbWVudHNCcmVha2Rvd25baV07XG5cbiAgICAvLyBDcmVhdGUgYSBjb2xvciBpbnRlcnZhbCB1c2luZyAyIHN0b3AgZWxlbWVudHMuXG4gICAgbGV0IHN0b3BFbGVtZW50MCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnROUyhTVkdfTkFNRVNQQUNFLCAnc3RvcCcpO1xuICAgIHN0b3BFbGVtZW50MC5zZXRBdHRyaWJ1dGUoJ29mZnNldCcsIHByZXZpb3VzT2Zmc2V0KTtcbiAgICBzdG9wRWxlbWVudDAuc2V0QXR0cmlidXRlKFxuICAgICAgICAnc3RvcC1jb2xvcicsIGhlYWx0aFBpbGxFbnRyaWVzW2ldLmJhY2tncm91bmRfY29sb3IpO1xuICAgIGhlYWx0aFBpbGxHcmFkaWVudC5hcHBlbmRDaGlsZChzdG9wRWxlbWVudDApO1xuXG4gICAgbGV0IHN0b3BFbGVtZW50MSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnROUyhTVkdfTkFNRVNQQUNFLCAnc3RvcCcpO1xuICAgIGxldCBwZXJjZW50ID0gKGN1bXVsYXRpdmVDb3VudCAqIDEwMCAvIHRvdGFsQ291bnQpICsgJyUnO1xuICAgIHN0b3BFbGVtZW50MS5zZXRBdHRyaWJ1dGUoJ29mZnNldCcsIHBlcmNlbnQpO1xuICAgIHN0b3BFbGVtZW50MS5zZXRBdHRyaWJ1dGUoXG4gICAgICAgICdzdG9wLWNvbG9yJywgaGVhbHRoUGlsbEVudHJpZXNbaV0uYmFja2dyb3VuZF9jb2xvcik7XG4gICAgaGVhbHRoUGlsbEdyYWRpZW50LmFwcGVuZENoaWxkKHN0b3BFbGVtZW50MSk7XG4gICAgcHJldmlvdXNPZmZzZXQgPSBwZXJjZW50O1xuICB9XG4gIGhlYWx0aFBpbGxEZWZzLmFwcGVuZENoaWxkKGhlYWx0aFBpbGxHcmFkaWVudCk7XG5cbiAgLy8gQ3JlYXRlIHRoZSByZWN0YW5nbGUgZm9yIHRoZSBoZWFsdGggcGlsbC5cbiAgbGV0IHJlY3QgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50TlMoU1ZHX05BTUVTUEFDRSwgJ3JlY3QnKTtcbiAgcmVjdC5zZXRBdHRyaWJ1dGUoJ2ZpbGwnLCAndXJsKCMnICsgaGVhbHRoUGlsbEdyYWRpZW50SWQgKyAnKScpO1xuICByZWN0LnNldEF0dHJpYnV0ZSgnd2lkdGgnLCBTdHJpbmcoaGVhbHRoUGlsbFdpZHRoKSk7XG4gIHJlY3Quc2V0QXR0cmlidXRlKCdoZWlnaHQnLCBTdHJpbmcoaGVhbHRoUGlsbEhlaWdodCkpO1xuICByZWN0LnNldEF0dHJpYnV0ZSgneScsIFN0cmluZyhoZWFsdGhQaWxsWU9mZnNldCkpO1xuICBoZWFsdGhQaWxsR3JvdXAuYXBwZW5kQ2hpbGQocmVjdCk7XG5cbiAgLy8gU2hvdyBhIHRpdGxlIHdpdGggc3BlY2lmaWMgY291bnRzIG9uIGhvdmVyLlxuICBsZXQgdGl0bGVTdmcgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50TlMoU1ZHX05BTUVTUEFDRSwgJ3RpdGxlJyk7XG4gIHRpdGxlU3ZnLnRleHRDb250ZW50ID0gX2dldEhlYWx0aFBpbGxUZXh0Q29udGVudChcbiAgICAgIGhlYWx0aFBpbGwsIHRvdGFsQ291bnQsIGxhc3RIZWFsdGhQaWxsRWxlbWVudHNCcmVha2Rvd24sIG51bWVyaWNTdGF0cyk7XG4gIGhlYWx0aFBpbGxHcm91cC5hcHBlbmRDaGlsZCh0aXRsZVN2Zyk7XG5cbiAgLy8gQ2VudGVyIHRoaXMgaGVhbHRoIHBpbGwganVzdCByaWdodCBhYm92ZSB0aGUgbm9kZSBmb3IgdGhlIG9wLlxuICBsZXQgc2hvdWxkUm91bmRPbmVzRGlnaXQgPSBmYWxzZTtcbiAgaWYgKG5vZGVJbmZvICE9IG51bGwpIHtcbiAgICBsZXQgaGVhbHRoUGlsbFggPSBub2RlSW5mby54IC0gaGVhbHRoUGlsbFdpZHRoIC8gMjtcbiAgICBsZXQgaGVhbHRoUGlsbFkgPSBub2RlSW5mby55IC0gaGVhbHRoUGlsbEhlaWdodCAtIG5vZGVJbmZvLmhlaWdodCAvIDIgLSAyO1xuICAgIGlmIChub2RlSW5mby5sYWJlbE9mZnNldCA8IDApIHtcbiAgICAgIC8vIFRoZSBsYWJlbCBpcyBwb3NpdGlvbmVkIGFib3ZlIHRoZSBub2RlLiBEbyBub3Qgb2NjbHVkZSB0aGUgbGFiZWwuXG4gICAgICBoZWFsdGhQaWxsWSArPSBub2RlSW5mby5sYWJlbE9mZnNldDtcbiAgICB9XG4gICAgaGVhbHRoUGlsbEdyb3VwLnNldEF0dHJpYnV0ZShcbiAgICAgICAgJ3RyYW5zZm9ybScsICd0cmFuc2xhdGUoJyArIGhlYWx0aFBpbGxYICsgJywgJyArIGhlYWx0aFBpbGxZICsgJyknKTtcblxuICAgIGlmIChsYXN0SGVhbHRoUGlsbEVsZW1lbnRzQnJlYWtkb3duWzJdIHx8XG4gICAgICAgIGxhc3RIZWFsdGhQaWxsRWxlbWVudHNCcmVha2Rvd25bM10gfHxcbiAgICAgICAgbGFzdEhlYWx0aFBpbGxFbGVtZW50c0JyZWFrZG93bls0XSkge1xuICAgICAgLy8gQXQgbGVhc3QgMSBcIm5vbi1JbmYgYW5kIG5vbi1OYU5cIiB2YWx1ZSBleGlzdHMgKGEgLSwgMCwgb3IgKyB2YWx1ZSkuIFNob3dcbiAgICAgIC8vIHN0YXRzIG9uIHRlbnNvciB2YWx1ZXMuXG5cbiAgICAgIC8vIERldGVybWluZSBpZiB3ZSBzaG91bGQgZGlzcGxheSB0aGUgb3V0cHV0IHJhbmdlIGFzIGludGVnZXJzLlxuXG4gICAgICBsZXQgbm9kZSA9IG5vZGVJbmZvLm5vZGUgYXMgT3BOb2RlO1xuICAgICAgbGV0IGF0dHJpYnV0ZXMgPSBub2RlLmF0dHI7XG4gICAgICBpZiAoYXR0cmlidXRlcyAmJiBhdHRyaWJ1dGVzLmxlbmd0aCkge1xuICAgICAgICAvLyBGaW5kIHRoZSBhdHRyaWJ1dGUgZm9yIG91dHB1dCB0eXBlIGlmIHRoZXJlIGlzIG9uZS5cbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBhdHRyaWJ1dGVzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgaWYgKGF0dHJpYnV0ZXNbaV0ua2V5ID09PSAnVCcpIHtcbiAgICAgICAgICAgIC8vIE5vdGUgd2hldGhlciB0aGUgb3V0cHV0IHR5cGUgaXMgYW4gaW50ZWdlci5cbiAgICAgICAgICAgIGxldCBvdXRwdXRUeXBlID0gYXR0cmlidXRlc1tpXS52YWx1ZVsndHlwZSddO1xuICAgICAgICAgICAgc2hvdWxkUm91bmRPbmVzRGlnaXQgPVxuICAgICAgICAgICAgICAgIG91dHB1dFR5cGUgJiYgL15EVF8oQk9PTHxJTlR8VUlOVCkvLnRlc3Qob3V0cHV0VHlwZSk7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICBsZXQgc3RhdHNTdmcgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50TlMoU1ZHX05BTUVTUEFDRSwgJ3RleHQnKTtcbiAgaWYgKE51bWJlci5pc0Zpbml0ZShudW1lcmljU3RhdHMubWluKSAmJiBOdW1iZXIuaXNGaW5pdGUobnVtZXJpY1N0YXRzLm1heCkpIHtcbiAgICBjb25zdCBtaW5TdHJpbmcgPVxuICAgICAgICBodW1hbml6ZUhlYWx0aFBpbGxTdGF0KG51bWVyaWNTdGF0cy5taW4sIHNob3VsZFJvdW5kT25lc0RpZ2l0KTtcbiAgICBjb25zdCBtYXhTdHJpbmcgPVxuICAgICAgICBodW1hbml6ZUhlYWx0aFBpbGxTdGF0KG51bWVyaWNTdGF0cy5tYXgsIHNob3VsZFJvdW5kT25lc0RpZ2l0KTtcbiAgICBpZiAodG90YWxDb3VudCA+IDEpIHtcbiAgICAgIHN0YXRzU3ZnLnRleHRDb250ZW50ID0gbWluU3RyaW5nICsgJyB+ICcgKyBtYXhTdHJpbmc7XG4gICAgfSBlbHNlIHtcbiAgICAgIHN0YXRzU3ZnLnRleHRDb250ZW50ID0gbWluU3RyaW5nO1xuICAgIH1cbiAgICBpZiAobmFuQ291bnQgPiAwIHx8IG5lZ0luZkNvdW50ID4gMCB8fCBwb3NJbmZDb3VudCA+IDApIHtcbiAgICAgIHN0YXRzU3ZnLnRleHRDb250ZW50ICs9ICcgKCc7XG4gICAgICBjb25zdCBiYWRWYWx1ZVN0cmluZ3M6IHN0cmluZ1tdID0gW107XG4gICAgICBpZiAobmFuQ291bnQgPiAwKSB7XG4gICAgICAgIGJhZFZhbHVlU3RyaW5ncy5wdXNoKGBOYU7DlyR7bmFuQ291bnR9YCk7XG4gICAgICB9XG4gICAgICBpZiAobmVnSW5mQ291bnQgPiAwKSB7XG4gICAgICAgIGJhZFZhbHVlU3RyaW5ncy5wdXNoKGAt4oiew5cke25lZ0luZkNvdW50fWApO1xuICAgICAgfVxuICAgICAgaWYgKHBvc0luZkNvdW50ID4gMCkge1xuICAgICAgICBiYWRWYWx1ZVN0cmluZ3MucHVzaChgK+KInsOXJHtwb3NJbmZDb3VudH1gKTtcbiAgICAgIH1cbiAgICAgIHN0YXRzU3ZnLnRleHRDb250ZW50ICs9IGJhZFZhbHVlU3RyaW5ncy5qb2luKCc7ICcpICsgJyknO1xuICAgIH1cbiAgfSBlbHNlIHtcbiAgICBzdGF0c1N2Zy50ZXh0Q29udGVudCA9ICcoTm8gZmluaXRlIGVsZW1lbnRzKSc7XG4gIH1cbiAgc3RhdHNTdmcuY2xhc3NMaXN0LmFkZCgnaGVhbHRoLXBpbGwtc3RhdHMnKTtcbiAgaWYgKHRleHRYT2Zmc2V0ID09IG51bGwpIHtcbiAgICB0ZXh0WE9mZnNldCA9IGhlYWx0aFBpbGxXaWR0aCAvIDI7XG4gIH1cbiAgc3RhdHNTdmcuc2V0QXR0cmlidXRlKCd4JywgU3RyaW5nKHRleHRYT2Zmc2V0KSk7XG4gIHN0YXRzU3ZnLnNldEF0dHJpYnV0ZSgneScsIFN0cmluZyhoZWFsdGhQaWxsWU9mZnNldCAtIDIpKTtcbiAgaGVhbHRoUGlsbEdyb3VwLmFwcGVuZENoaWxkKHN0YXRzU3ZnKTtcblxuICBQb2x5bWVyLmRvbShub2RlR3JvdXBFbGVtZW50LnBhcmVudE5vZGUpLmFwcGVuZENoaWxkKGhlYWx0aFBpbGxHcm91cCk7XG59XG5cbi8qKlxuICogQWRkcyBoZWFsdGggcGlsbHMgKHdoaWNoIHZpc3VhbGl6ZSB0ZW5zb3Igc3VtbWFyaWVzKSB0byBhIGdyYXBoIGdyb3VwLlxuICogQHBhcmFtIHN2Z1Jvb3QgVGhlIHJvb3QgU1ZHIGVsZW1lbnQgb2YgdGhlIGdyYXBoIHRvIGFkZCBoZWF0aCBwaWxscyB0by5cbiAqIEBwYXJhbSBub2RlTmFtZXNUb0hlYWx0aFBpbGxzIEFuIG9iamVjdCBtYXBwaW5nIG5vZGUgbmFtZSB0byBoZWFsdGggcGlsbC5cbiAqIEBwYXJhbSBjb2xvcnMgQSBsaXN0IG9mIGNvbG9ycyB0byB1c2UuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBhZGRIZWFsdGhQaWxscyhcbiAgICBzdmdSb290OiBTVkdFbGVtZW50LCBub2RlTmFtZXNUb0hlYWx0aFBpbGxzOiB7W2tleTogc3RyaW5nXTogSGVhbHRoUGlsbFtdfSxcbiAgICBoZWFsdGhQaWxsU3RlcEluZGV4OiBudW1iZXIpIHtcbiAgaWYgKCFub2RlTmFtZXNUb0hlYWx0aFBpbGxzKSB7XG4gICAgLy8gTm8gaGVhbHRoIHBpbGwgaW5mb3JtYXRpb24gYXZhaWxhYmxlLlxuICAgIHJldHVybjtcbiAgfVxuXG4gIC8vIFdlIGdlbmVyYXRlIGEgdW5pcXVlIElEIGZvciBlYWNoIGhlYWx0aCBwaWxsIGJlY2F1c2UgdGhlIElEIG9mIGVhY2ggZWxlbWVudFxuICAvLyBpbiBhIHdlYiBwYWdlIG11c3QgYmUgdW5pcXVlLCBhbmQgZWFjaCBoZWFsdGggcGlsbCBnZW5lcmF0ZXMgYSBncmFkaWVudFxuICAvLyB0aGF0IGl0cyBjb2RlIGxhdGVyIHJlZmVycyB0by5cbiAgbGV0IGhlYWx0aFBpbGxJZCA9IDE7XG5cbiAgbGV0IHN2Z1Jvb3RTZWxlY3Rpb24gPSBkMy5zZWxlY3Qoc3ZnUm9vdCk7XG4gIHN2Z1Jvb3RTZWxlY3Rpb24uc2VsZWN0QWxsKCdnLm5vZGVzaGFwZScpXG4gICAgICAuZWFjaChmdW5jdGlvbihub2RlSW5mbzogcmVuZGVyLlJlbmRlck5vZGVJbmZvKSB7XG4gICAgICAgIC8vIE9ubHkgc2hvdyBoZWFsdGggcGlsbCBkYXRhIGZvciB0aGlzIG5vZGUgaWYgaXQgaXMgYXZhaWxhYmxlLlxuICAgICAgICBjb25zdCBoZWFsdGhQaWxscyA9IG5vZGVOYW1lc1RvSGVhbHRoUGlsbHNbbm9kZUluZm8ubm9kZS5uYW1lXTtcbiAgICAgICAgY29uc3QgaGVhbHRoUGlsbCA9XG4gICAgICAgICAgICBoZWFsdGhQaWxscyA/IGhlYWx0aFBpbGxzW2hlYWx0aFBpbGxTdGVwSW5kZXhdIDogbnVsbDtcbiAgICAgICAgYWRkSGVhbHRoUGlsbChcbiAgICAgICAgICAgICh0aGlzIGFzIFNWR0VsZW1lbnQpLCBoZWFsdGhQaWxsLCBub2RlSW5mbywgaGVhbHRoUGlsbElkKyspO1xuICAgICAgfSk7XG59O1xuXG59IC8vIGNsb3NlIG1vZHVsZVxuIl19