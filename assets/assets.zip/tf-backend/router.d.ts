declare namespace tf_backend {
    interface Router {
        environment: () => string;
        experiments: () => string;
        isDemoMode: () => boolean;
        pluginRoute: (pluginName: string, route: string) => string;
        pluginsListing: () => string;
        runs: () => string;
        runsForExperiment: (id: tf_backend.ExperimentId) => string;
    }
    /**
     * Create a router for communicating with the TensorBoard backend. You
     * can pass this to `setRouter` to make it the global router.
     *
     * @param dataDir {string} The base prefix for finding data on server.
     * @param demoMode {boolean} Whether to modify urls for filesystem demo usage.
     */
    function createRouter(dataDir?: string, demoMode?: boolean): Router;
    /**
     * @return {Router} the global router
     */
    function getRouter(): Router;
    /**
     * Set the global router, to be returned by future calls to `getRouter`.
     * You may wish to invoke this if you are running a demo server with a
     * custom path prefix, or if you have customized the TensorBoard backend
     * to use a different path.
     *
     * @param {Router} router the new global router
     */
    function setRouter(router: Router): void;
    function createSearchParam(params?: QueryParams): URLSearchParams;
}
