var gr_paramplot_dashboard;
(function (gr_paramplot_dashboard) {
    var DataSeries = /** @class */ (function () {
        function DataSeries(name, scalarData) {
            this.name = name;
            this.scalarData = scalarData;
        }
        DataSeries.prototype.getName = function () {
            return this.name;
        };
        DataSeries.prototype.setData = function (scalarData) {
            this.scalarData = scalarData;
        };
        DataSeries.prototype.getData = function () {
            return this.scalarData;
        };
        return DataSeries;
    }());
    gr_paramplot_dashboard.DataSeries = DataSeries;
})(gr_paramplot_dashboard || (gr_paramplot_dashboard = {}));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGFyYW1wbG90LWhlbHBlcnMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJwYXJhbXBsb3QtaGVscGVycy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxJQUFVLHNCQUFzQixDQXdCL0I7QUF4QkQsV0FBVSxzQkFBc0I7SUFFNUI7UUFJSSxvQkFBWSxJQUFZLEVBQUUsVUFBMEM7WUFDaEUsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUM7WUFDakIsSUFBSSxDQUFDLFVBQVUsR0FBRyxVQUFVLENBQUM7UUFDakMsQ0FBQztRQUVELDRCQUFPLEdBQVA7WUFDSSxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUM7UUFDckIsQ0FBQztRQUVELDRCQUFPLEdBQVAsVUFBUSxVQUEwQztZQUM5QyxJQUFJLENBQUMsVUFBVSxHQUFHLFVBQVUsQ0FBQztRQUNqQyxDQUFDO1FBRUQsNEJBQU8sR0FBUDtZQUNJLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQztRQUMzQixDQUFDO1FBQ0wsaUJBQUM7SUFBRCxDQUFDLEFBcEJELElBb0JDO0lBcEJZLGlDQUFVLGFBb0J0QixDQUFBO0FBRUwsQ0FBQyxFQXhCUyxzQkFBc0IsS0FBdEIsc0JBQXNCLFFBd0IvQiIsInNvdXJjZXNDb250ZW50IjpbIm5hbWVzcGFjZSBncl9wYXJhbXBsb3RfZGFzaGJvYXJkIHtcblxuICAgIGV4cG9ydCBjbGFzcyBEYXRhU2VyaWVzIHtcbiAgICAgICAgcHJpdmF0ZSBuYW1lOiBzdHJpbmc7XG4gICAgICAgIHByaXZhdGUgc2NhbGFyRGF0YTogdnpfY2hhcnRfaGVscGVycy5TY2FsYXJEYXR1bVtdO1xuXG4gICAgICAgIGNvbnN0cnVjdG9yKG5hbWU6IHN0cmluZywgc2NhbGFyRGF0YTogdnpfY2hhcnRfaGVscGVycy5TY2FsYXJEYXR1bVtdKSB7XG4gICAgICAgICAgICB0aGlzLm5hbWUgPSBuYW1lO1xuICAgICAgICAgICAgdGhpcy5zY2FsYXJEYXRhID0gc2NhbGFyRGF0YTtcbiAgICAgICAgfVxuXG4gICAgICAgIGdldE5hbWUoKTogc3RyaW5nIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLm5hbWU7XG4gICAgICAgIH1cbiAgICAgICAgXG4gICAgICAgIHNldERhdGEoc2NhbGFyRGF0YTogdnpfY2hhcnRfaGVscGVycy5TY2FsYXJEYXR1bVtdKSB7XG4gICAgICAgICAgICB0aGlzLnNjYWxhckRhdGEgPSBzY2FsYXJEYXRhO1xuICAgICAgICB9XG5cbiAgICAgICAgZ2V0RGF0YSgpe1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuc2NhbGFyRGF0YTtcbiAgICAgICAgfVxuICAgIH1cblxufSJdfQ==