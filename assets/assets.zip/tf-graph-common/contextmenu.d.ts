declare module tf.graph.scene.contextmenu {
    /** Function that converts data to a title string. */
    interface TitleFunction {
        (data: any): string;
    }
    /** Function that takes action based on item clicked in the context menu. */
    interface ActionFunction {
        (elem: any, d: any, i: number): void;
    }
    /**
     * The interface for an item in the context menu
     */
    interface ContextMenuItem {
        title: TitleFunction;
        action: ActionFunction;
    }
    /**
     * Returns the event listener, which can be used as an argument for the d3
     * selection.on function. Renders the context menu that is to be displayed
     * in response to the event.
     */
    function getMenu(sceneElement: any, menu: ContextMenuItem[]): (data: any, index: number) => void;
}
