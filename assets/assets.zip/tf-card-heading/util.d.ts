declare namespace tf_card_heading {
    /**
     * Formats timestamp for the card header.
     * @param {Date} date
     * @return {string}
     */
    function formatDate(date: any): any;
    /**
     * Returns CSS color that will contrast against background.
     * @param {?string} background RGB hex color code, e.g. #eee, #eeeeee.
     * @return {string}
     */
    function pickTextColor(background: any): "inherit" | "#eee";
}
