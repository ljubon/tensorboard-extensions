/* Copyright 2018 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the 'License');
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an 'AS IS' BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
var tf_data_selector;
(function (tf_data_selector) {
    var _a;
    function decodeIdArray(str) {
        return str.split(',').map(function (idStr) { return parseInt(idStr, 36); }).filter(Boolean);
    }
    tf_data_selector.decodeIdArray = decodeIdArray;
    function encodeIdArray(arr) {
        return arr.map(encodeId).join(',');
    }
    tf_data_selector.encodeIdArray = encodeIdArray;
    function encodeId(id) {
        return id.toString(36);
    }
    tf_data_selector.encodeId = encodeId;
    tf_data_selector.NO_EXPERIMENT_ID = null;
    tf_data_selector.STORAGE_ALL_VALUE = '$all';
    tf_data_selector.STORAGE_NONE_VALUE = '$none';
    _a = tf_storage.makeBindings(function (str) { return tf_data_selector.decodeIdArray(str); }, function (ids) { return tf_data_selector.encodeIdArray(ids); }), tf_data_selector.getIdInitializer = _a.getInitializer, tf_data_selector.getIdObserver = _a.getObserver, tf_data_selector.setId = _a.set;
})(tf_data_selector || (tf_data_selector = {})); // namespace tf_data_selector
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RvcmFnZS11dGlscy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbInN0b3JhZ2UtdXRpbHMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7Ozs7Ozs7Z0ZBYWdGO0FBQ2hGLElBQVUsZ0JBQWdCLENBMkJ6QjtBQTNCRCxXQUFVLGdCQUFnQjs7SUFFMUIsdUJBQThCLEdBQVc7UUFDdkMsT0FBTyxHQUFHLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxVQUFBLEtBQUssSUFBSSxPQUFBLFFBQVEsQ0FBQyxLQUFLLEVBQUUsRUFBRSxDQUFDLEVBQW5CLENBQW1CLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUM7SUFDMUUsQ0FBQztJQUZlLDhCQUFhLGdCQUU1QixDQUFBO0lBRUQsdUJBQThCLEdBQWtCO1FBQzlDLE9BQU8sR0FBRyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDckMsQ0FBQztJQUZlLDhCQUFhLGdCQUU1QixDQUFBO0lBRUQsa0JBQXlCLEVBQVU7UUFDakMsT0FBTyxFQUFFLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxDQUFDO0lBQ3pCLENBQUM7SUFGZSx5QkFBUSxXQUV2QixDQUFBO0lBRVksaUNBQWdCLEdBQUcsSUFBSSxDQUFDO0lBRXhCLGtDQUFpQixHQUFHLE1BQU0sQ0FBQztJQUMzQixtQ0FBa0IsR0FBRyxPQUFPLENBQUM7SUFFN0IsNEpBTXNELEVBTGpFLHFEQUFnQyxFQUNoQywrQ0FBMEIsRUFDMUIsK0JBQVUsQ0FHd0Q7QUFFcEUsQ0FBQyxFQTNCUyxnQkFBZ0IsS0FBaEIsZ0JBQWdCLFFBMkJ6QixDQUFFLDZCQUE2QiIsInNvdXJjZXNDb250ZW50IjpbIi8qIENvcHlyaWdodCAyMDE4IFRoZSBUZW5zb3JGbG93IEF1dGhvcnMuIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG5cbkxpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSAnTGljZW5zZScpO1xueW91IG1heSBub3QgdXNlIHRoaXMgZmlsZSBleGNlcHQgaW4gY29tcGxpYW5jZSB3aXRoIHRoZSBMaWNlbnNlLlxuWW91IG1heSBvYnRhaW4gYSBjb3B5IG9mIHRoZSBMaWNlbnNlIGF0XG5cbiAgICBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcblxuVW5sZXNzIHJlcXVpcmVkIGJ5IGFwcGxpY2FibGUgbGF3IG9yIGFncmVlZCB0byBpbiB3cml0aW5nLCBzb2Z0d2FyZVxuZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIExpY2Vuc2UgaXMgZGlzdHJpYnV0ZWQgb24gYW4gJ0FTIElTJyBCQVNJUyxcbldJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWSBLSU5ELCBlaXRoZXIgZXhwcmVzcyBvciBpbXBsaWVkLlxuU2VlIHRoZSBMaWNlbnNlIGZvciB0aGUgc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nIHBlcm1pc3Npb25zIGFuZFxubGltaXRhdGlvbnMgdW5kZXIgdGhlIExpY2Vuc2UuXG49PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0qL1xubmFtZXNwYWNlIHRmX2RhdGFfc2VsZWN0b3Ige1xuXG5leHBvcnQgZnVuY3Rpb24gZGVjb2RlSWRBcnJheShzdHI6IHN0cmluZyk6IEFycmF5PG51bWJlcj4ge1xuICByZXR1cm4gc3RyLnNwbGl0KCcsJykubWFwKGlkU3RyID0+IHBhcnNlSW50KGlkU3RyLCAzNikpLmZpbHRlcihCb29sZWFuKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGVuY29kZUlkQXJyYXkoYXJyOiBBcnJheTxudW1iZXI+KTogc3RyaW5nIHtcbiAgcmV0dXJuIGFyci5tYXAoZW5jb2RlSWQpLmpvaW4oJywnKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGVuY29kZUlkKGlkOiBudW1iZXIpOiBzdHJpbmcge1xuICByZXR1cm4gaWQudG9TdHJpbmcoMzYpO1xufVxuXG5leHBvcnQgY29uc3QgTk9fRVhQRVJJTUVOVF9JRCA9IG51bGw7XG5cbmV4cG9ydCBjb25zdCBTVE9SQUdFX0FMTF9WQUxVRSA9ICckYWxsJztcbmV4cG9ydCBjb25zdCBTVE9SQUdFX05PTkVfVkFMVUUgPSAnJG5vbmUnO1xuXG5leHBvcnQgY29uc3Qge1xuICBnZXRJbml0aWFsaXplcjogZ2V0SWRJbml0aWFsaXplcixcbiAgZ2V0T2JzZXJ2ZXI6IGdldElkT2JzZXJ2ZXIsXG4gIHNldDogc2V0SWQsXG59ID0gdGZfc3RvcmFnZS5tYWtlQmluZGluZ3MoXG4gICAgKHN0cjogc3RyaW5nKTogbnVtYmVyW10gPT4gdGZfZGF0YV9zZWxlY3Rvci5kZWNvZGVJZEFycmF5KHN0ciksXG4gICAgKGlkczogbnVtYmVyW10pOiBzdHJpbmcgPT4gdGZfZGF0YV9zZWxlY3Rvci5lbmNvZGVJZEFycmF5KGlkcykpO1xuXG59ICAvLyBuYW1lc3BhY2UgdGZfZGF0YV9zZWxlY3RvclxuIl19