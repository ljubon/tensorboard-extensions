/* Copyright 2015 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the 'License');
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an 'AS IS' BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
var tf;
(function (tf) {
    var graph;
    (function (graph) {
        var parser;
        (function (parser) {
            /**
             * Parses a native js value, which can be either a string, boolean or number.
             *
             * @param value The value to be parsed.
             */
            function parseValue(value) {
                if (value === 'true') {
                    return true;
                }
                if (value === 'false') {
                    return false;
                }
                var firstChar = value[0];
                if (firstChar === '"') {
                    return value.substring(1, value.length - 1);
                }
                var num = parseFloat(value);
                return isNaN(num) ? value : num;
            }
            /**
             * Fetches a text file and returns a promise of the result.
             */
            function fetchPbTxt(filepath) {
                return new Promise(function (resolve, reject) {
                    var request = new XMLHttpRequest();
                    request.open('GET', filepath);
                    request.responseType = 'arraybuffer';
                    request.onerror = function () { return reject(request.status); };
                    request.onload = function () { return resolve(request.response); };
                    request.send(null);
                });
            }
            parser.fetchPbTxt = fetchPbTxt;
            /**
             * Fetches the metadata file, parses it and returns a promise of the result.
             */
            function fetchAndParseMetadata(path, tracker) {
                return tf.graph.util
                    .runTask('Reading metadata pbtxt', 40, function () {
                    if (path == null) {
                        return Promise.resolve(null);
                    }
                    return fetchPbTxt(path);
                }, tracker)
                    .then(function (arrayBuffer) {
                    return tf.graph.util.runAsyncPromiseTask('Parsing metadata.pbtxt', 60, function () {
                        return arrayBuffer != null ? parseStatsPbTxt(arrayBuffer) :
                            Promise.resolve(null);
                    }, tracker);
                });
            }
            parser.fetchAndParseMetadata = fetchAndParseMetadata;
            /**
             * Fetches the graph file, parses it and returns a promise of the result. The
             * result will be undefined if the graph is empty.
             */
            function fetchAndParseGraphData(path, pbTxtFile, tracker) {
                return tf.graph.util
                    .runTask('Reading graph pbtxt', 40, function () {
                    if (pbTxtFile) {
                        return new Promise(function (resolve, reject) {
                            var fileReader = new FileReader();
                            fileReader.onload = function () { return resolve(fileReader.result); };
                            fileReader.onerror = function () { return reject(fileReader.error); };
                            fileReader.readAsArrayBuffer(pbTxtFile);
                        });
                    }
                    else {
                        return fetchPbTxt(path);
                    }
                }, tracker)
                    .then(function (arrayBuffer) {
                    return tf.graph.util.runTask('Parsing graph.pbtxt', 60, function () {
                        return parseGraphPbTxt(arrayBuffer);
                    }, tracker);
                });
            }
            parser.fetchAndParseGraphData = fetchAndParseGraphData;
            /**
             * Parse a file object in a streaming fashion line by line (or custom delim).
             * Can handle very large files.
             * @param input The file object as an array buffer.
             * @param callback The callback called on each line
             * @param chunkSize The size of each read chunk. (optional)
             * @param delim The delimiter used to split a line. (optional)
             * @returns A promise for when it is finished.
             */
            function streamParse(arrayBuffer, callback, chunkSize, delim) {
                if (chunkSize === void 0) { chunkSize = 1000000; }
                if (delim === void 0) { delim = '\n'; }
                return new Promise(function (resolve, reject) {
                    var offset = 0;
                    var bufferSize = arrayBuffer.byteLength - 1;
                    var data = '';
                    function readHandler(str) {
                        offset += chunkSize;
                        var parts = str.split(delim);
                        var first = data + parts[0];
                        if (parts.length === 1) {
                            data = first;
                            readChunk(offset, chunkSize);
                            return;
                        }
                        data = parts[parts.length - 1];
                        callback(first);
                        for (var i = 1; i < parts.length - 1; i++) {
                            callback(parts[i]);
                        }
                        if (offset >= bufferSize) {
                            if (data) {
                                callback(data);
                            }
                            resolve(true);
                            return;
                        }
                        readChunk(offset, chunkSize);
                    }
                    function readChunk(offset, size) {
                        var arrayBufferChunk = arrayBuffer.slice(offset, offset + size);
                        var blob = new Blob([arrayBufferChunk]);
                        var file = new FileReader();
                        file.onload = function (e) { return readHandler(e.target.result); };
                        file.readAsText(blob);
                    }
                    readChunk(offset, chunkSize);
                });
            }
            parser.streamParse = streamParse;
            /**
             * Since proto-txt doesn't explicitly say whether an attribute is repeated
             * (an array) or not, we keep a hard-coded list of attributes that are known
             * to be repeated. This list is used in parsing time to convert repeated
             * attributes into arrays even when the attribute only shows up once in the
             * object.
             */
            var GRAPH_REPEATED_FIELDS = {
                'library.function': true,
                'library.function.node_def': true,
                'library.function.signature.input_arg': true,
                'library.function.signature.output_arg': true,
                'library.versions': true,
                'node': true,
                'node.input': true,
                'node.attr': true,
                'node.attr.value.list.type': true,
                'node.attr.value.shape.dim': true,
                'node.attr.value.tensor.string_val': true,
                'node.attr.value.tensor.tensor_shape.dim': true,
                'node.attr.value.list.shape': true,
                'node.attr.value.list.shape.dim': true,
                'node.attr.value.list.s': true
            };
            var METADATA_REPEATED_FIELDS = {
                'step_stats.dev_stats': true,
                'step_stats.dev_stats.node_stats': true,
                'step_stats.dev_stats.node_stats.output': true,
                'step_stats.dev_stats.node_stats.memory': true,
                'step_stats.dev_stats.node_stats.output.tensor_description.shape.dim': true
            };
            /**
             * Parses an ArrayBuffer of a proto txt file into a raw Graph object.
             */
            function parseGraphPbTxt(input) {
                return parsePbtxtFile(input, GRAPH_REPEATED_FIELDS);
            }
            parser.parseGraphPbTxt = parseGraphPbTxt;
            /**
             * Parses an ArrayBuffer of a proto txt file into a StepStats object.
             */
            function parseStatsPbTxt(input) {
                return parsePbtxtFile(input, METADATA_REPEATED_FIELDS)
                    .then(function (obj) { return obj['step_stats']; });
            }
            parser.parseStatsPbTxt = parseStatsPbTxt;
            /**
             * Parses a ArrayBuffer of a proto txt file into javascript object.
             *
             * @param input The ArrayBuffer or file object implementing slice.
             * @param repeatedFields Map (Set) of all the repeated fields, since you can't
             *   tell directly from the pbtxt if a field is repeated or not.
             * @returns The parsed object.
             */
            function parsePbtxtFile(input, repeatedFields) {
                var output = {};
                var stack = [];
                var path = [];
                var current = output;
                function splitNameAndValueInAttribute(line) {
                    var colonIndex = line.indexOf(':');
                    var name = line.substring(0, colonIndex).trim();
                    var value = parseValue(line.substring(colonIndex + 2).trim());
                    return {
                        name: name,
                        value: value
                    };
                }
                /**
                 * Adds a value, given the attribute name and the host object. If the
                 * attribute already exists, but is not an array, it will convert it to an
                 * array of values.
                 *
                 * @param obj The host object that holds the attribute.
                 * @param name The attribute name (key).
                 * @param value The attribute value.
                 * @param path A path that identifies the attribute. Used to check if
                 *     an attribute is an array or not.
                 */
                function addAttribute(obj, name, value, path) {
                    // We treat 'node' specially since it is done so often.
                    var existingValue = obj[name];
                    if (existingValue == null) {
                        obj[name] = path.join('.') in repeatedFields ? [value] : value;
                    }
                    else if (Array.isArray(existingValue)) {
                        existingValue.push(value);
                    }
                    else {
                        obj[name] = [existingValue, value];
                    }
                }
                // Run through the file a line at a time.
                return streamParse(input, function (line) {
                    if (!line) {
                        return;
                    }
                    line = line.trim();
                    switch (line[line.length - 1]) {
                        case '{': // create new object
                            var name_1 = line.substring(0, line.length - 2).trim();
                            var newValue = {};
                            stack.push(current);
                            path.push(name_1);
                            addAttribute(current, name_1, newValue, path);
                            current = newValue;
                            break;
                        case '}':
                            current = stack.pop();
                            path.pop();
                            break;
                        default:
                            var x = splitNameAndValueInAttribute(line);
                            addAttribute(current, x.name, x.value, path.concat(x.name));
                            break;
                    }
                }).then(function () {
                    return output;
                });
            }
        })(parser = graph.parser || (graph.parser = {}));
    })(graph = tf.graph || (tf.graph = {}));
})(tf || (tf = {})); // Close module tf.graph.parser.
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGFyc2VyLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsicGFyc2VyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7Ozs7Ozs7Ozs7O2dGQWFnRjtBQUNoRixJQUFPLEVBQUUsQ0FrUlI7QUFsUkQsV0FBTyxFQUFFO0lBQUMsSUFBQSxLQUFLLENBa1JkO0lBbFJTLFdBQUEsS0FBSztRQUFDLElBQUEsTUFBTSxDQWtSckI7UUFsUmUsV0FBQSxNQUFNO1lBRXRCOzs7O2VBSUc7WUFDSCxvQkFBb0IsS0FBYTtnQkFDL0IsSUFBSSxLQUFLLEtBQUssTUFBTSxFQUFFO29CQUNwQixPQUFPLElBQUksQ0FBQztpQkFDYjtnQkFDRCxJQUFJLEtBQUssS0FBSyxPQUFPLEVBQUU7b0JBQ3JCLE9BQU8sS0FBSyxDQUFDO2lCQUNkO2dCQUNELElBQUksU0FBUyxHQUFHLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDekIsSUFBSSxTQUFTLEtBQUssR0FBRyxFQUFFO29CQUNyQixPQUFPLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUM7aUJBQzdDO2dCQUNELElBQUksR0FBRyxHQUFHLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFDNUIsT0FBTyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO1lBQ2xDLENBQUM7WUFFRDs7ZUFFRztZQUNILG9CQUEyQixRQUFnQjtnQkFDekMsT0FBTyxJQUFJLE9BQU8sQ0FBYyxVQUFTLE9BQU8sRUFBRSxNQUFNO29CQUN0RCxJQUFNLE9BQU8sR0FBRyxJQUFJLGNBQWMsRUFBRSxDQUFDO29CQUNyQyxPQUFPLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxRQUFRLENBQUMsQ0FBQztvQkFDOUIsT0FBTyxDQUFDLFlBQVksR0FBRyxhQUFhLENBQUM7b0JBRXJDLE9BQU8sQ0FBQyxPQUFPLEdBQUcsY0FBTSxPQUFBLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLEVBQXRCLENBQXNCLENBQUM7b0JBQy9DLE9BQU8sQ0FBQyxNQUFNLEdBQUcsY0FBTSxPQUFBLE9BQU8sQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLEVBQXpCLENBQXlCLENBQUM7b0JBRWpELE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7Z0JBQ3JCLENBQUMsQ0FBQyxDQUFDO1lBQ0wsQ0FBQztZQVhlLGlCQUFVLGFBV3pCLENBQUE7WUFFRDs7ZUFFRztZQUNILCtCQUFzQyxJQUFZLEVBQUUsT0FBd0I7Z0JBQzFFLE9BQU8sRUFBRSxDQUFDLEtBQUssQ0FBQyxJQUFJO3FCQUNmLE9BQU8sQ0FDSix3QkFBd0IsRUFBRSxFQUFFLEVBQzVCO29CQUNFLElBQUksSUFBSSxJQUFJLElBQUksRUFBRTt3QkFDaEIsT0FBTyxPQUFPLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO3FCQUM5QjtvQkFDRCxPQUFPLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDMUIsQ0FBQyxFQUNELE9BQU8sQ0FBQztxQkFDWCxJQUFJLENBQUMsVUFBQyxXQUF3QjtvQkFDN0IsT0FBTyxFQUFFLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxtQkFBbUIsQ0FDcEMsd0JBQXdCLEVBQUUsRUFBRSxFQUFFO3dCQUM1QixPQUFPLFdBQVcsSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDOzRCQUM5QixPQUFPLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO29CQUNyRCxDQUFDLEVBQUUsT0FBTyxDQUFDLENBQUM7Z0JBQ2xCLENBQUMsQ0FBQyxDQUFDO1lBQ1QsQ0FBQztZQWxCZSw0QkFBcUIsd0JBa0JwQyxDQUFBO1lBRUQ7OztlQUdHO1lBQ0gsZ0NBQXVDLElBQVksRUFBRSxTQUFlLEVBQ2hFLE9BQXdCO2dCQUMxQixPQUFPLEVBQUUsQ0FBQyxLQUFLLENBQUMsSUFBSTtxQkFDZixPQUFPLENBQ0oscUJBQXFCLEVBQUUsRUFBRSxFQUN6QjtvQkFDRSxJQUFJLFNBQVMsRUFBRTt3QkFDYixPQUFPLElBQUksT0FBTyxDQUFjLFVBQVMsT0FBTyxFQUFFLE1BQU07NEJBQ3RELElBQUksVUFBVSxHQUFHLElBQUksVUFBVSxFQUFFLENBQUM7NEJBQ2xDLFVBQVUsQ0FBQyxNQUFNLEdBQUcsY0FBTSxPQUFBLE9BQU8sQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLEVBQTFCLENBQTBCLENBQUM7NEJBQ3JELFVBQVUsQ0FBQyxPQUFPLEdBQUcsY0FBTSxPQUFBLE1BQU0sQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLEVBQXhCLENBQXdCLENBQUM7NEJBQ3BELFVBQVUsQ0FBQyxpQkFBaUIsQ0FBQyxTQUFTLENBQUMsQ0FBQzt3QkFDMUMsQ0FBQyxDQUFDLENBQUM7cUJBQ0o7eUJBQU07d0JBQ0wsT0FBTyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUM7cUJBQ3pCO2dCQUNILENBQUMsRUFDRCxPQUFPLENBQUM7cUJBQ1gsSUFBSSxDQUFDLFVBQUMsV0FBd0I7b0JBQzdCLE9BQU8sRUFBRSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLHFCQUFxQixFQUFFLEVBQUUsRUFBRTt3QkFDdEQsT0FBTyxlQUFlLENBQUMsV0FBVyxDQUFDLENBQUM7b0JBQ3RDLENBQUMsRUFBRSxPQUFPLENBQUMsQ0FBQztnQkFDZCxDQUFDLENBQUMsQ0FBQztZQUNULENBQUM7WUF2QmUsNkJBQXNCLHlCQXVCckMsQ0FBQTtZQUVEOzs7Ozs7OztlQVFHO1lBQ0gscUJBQ0ksV0FBd0IsRUFBRSxRQUEwQixFQUNwRCxTQUEyQixFQUFFLEtBQW9CO2dCQUFqRCwwQkFBQSxFQUFBLG1CQUEyQjtnQkFBRSxzQkFBQSxFQUFBLFlBQW9CO2dCQUNuRCxPQUFPLElBQUksT0FBTyxDQUFVLFVBQVMsT0FBTyxFQUFFLE1BQU07b0JBQ2xELElBQUksTUFBTSxHQUFHLENBQUMsQ0FBQztvQkFDZixJQUFJLFVBQVUsR0FBRyxXQUFXLENBQUMsVUFBVSxHQUFHLENBQUMsQ0FBQztvQkFDNUMsSUFBSSxJQUFJLEdBQUcsRUFBRSxDQUFDO29CQUVkLHFCQUFxQixHQUFHO3dCQUN0QixNQUFNLElBQUksU0FBUyxDQUFDO3dCQUNwQixJQUFJLEtBQUssR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO3dCQUM3QixJQUFJLEtBQUssR0FBRyxJQUFJLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUM1QixJQUFJLEtBQUssQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFOzRCQUN0QixJQUFJLEdBQUcsS0FBSyxDQUFDOzRCQUNiLFNBQVMsQ0FBQyxNQUFNLEVBQUUsU0FBUyxDQUFDLENBQUM7NEJBQzdCLE9BQU87eUJBQ1I7d0JBQ0QsSUFBSSxHQUFHLEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDO3dCQUMvQixRQUFRLENBQUMsS0FBSyxDQUFDLENBQUM7d0JBQ2hCLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxLQUFLLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRTs0QkFDekMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO3lCQUNwQjt3QkFDRCxJQUFJLE1BQU0sSUFBSSxVQUFVLEVBQUU7NEJBQ3hCLElBQUksSUFBSSxFQUFFO2dDQUNSLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQzs2QkFDaEI7NEJBQ0QsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDOzRCQUNkLE9BQU87eUJBQ1I7d0JBQ0QsU0FBUyxDQUFDLE1BQU0sRUFBRSxTQUFTLENBQUMsQ0FBQztvQkFDL0IsQ0FBQztvQkFFRCxtQkFBbUIsTUFBYyxFQUFFLElBQVk7d0JBQzdDLElBQU0sZ0JBQWdCLEdBQUcsV0FBVyxDQUFDLEtBQUssQ0FBQyxNQUFNLEVBQUUsTUFBTSxHQUFHLElBQUksQ0FBQyxDQUFDO3dCQUVsRSxJQUFNLElBQUksR0FBRyxJQUFJLElBQUksQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQzt3QkFDMUMsSUFBTSxJQUFJLEdBQUcsSUFBSSxVQUFVLEVBQUUsQ0FBQzt3QkFDOUIsSUFBSSxDQUFDLE1BQU0sR0FBRyxVQUFDLENBQU0sSUFBSyxPQUFBLFdBQVcsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUE1QixDQUE0QixDQUFDO3dCQUN2RCxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDO29CQUN4QixDQUFDO29CQUVELFNBQVMsQ0FBQyxNQUFNLEVBQUUsU0FBUyxDQUFDLENBQUM7Z0JBQy9CLENBQUMsQ0FBQyxDQUFDO1lBQ0wsQ0FBQztZQTNDZSxrQkFBVyxjQTJDMUIsQ0FBQTtZQUVEOzs7Ozs7ZUFNRztZQUNILElBQU0scUJBQXFCLEdBQWtDO2dCQUMzRCxrQkFBa0IsRUFBRSxJQUFJO2dCQUN4QiwyQkFBMkIsRUFBRSxJQUFJO2dCQUNqQyxzQ0FBc0MsRUFBRSxJQUFJO2dCQUM1Qyx1Q0FBdUMsRUFBRSxJQUFJO2dCQUM3QyxrQkFBa0IsRUFBRSxJQUFJO2dCQUN4QixNQUFNLEVBQUUsSUFBSTtnQkFDWixZQUFZLEVBQUUsSUFBSTtnQkFDbEIsV0FBVyxFQUFFLElBQUk7Z0JBQ2pCLDJCQUEyQixFQUFFLElBQUk7Z0JBQ2pDLDJCQUEyQixFQUFFLElBQUk7Z0JBQ2pDLG1DQUFtQyxFQUFFLElBQUk7Z0JBQ3pDLHlDQUF5QyxFQUFFLElBQUk7Z0JBQy9DLDRCQUE0QixFQUFFLElBQUk7Z0JBQ2xDLGdDQUFnQyxFQUFFLElBQUk7Z0JBQ3RDLHdCQUF3QixFQUFFLElBQUk7YUFDL0IsQ0FBQztZQUVGLElBQU0sd0JBQXdCLEdBQWtDO2dCQUM5RCxzQkFBc0IsRUFBRSxJQUFJO2dCQUM1QixpQ0FBaUMsRUFBRSxJQUFJO2dCQUN2Qyx3Q0FBd0MsRUFBRSxJQUFJO2dCQUM5Qyx3Q0FBd0MsRUFBRSxJQUFJO2dCQUM5QyxxRUFBcUUsRUFBRSxJQUFJO2FBQzVFLENBQUM7WUFFRjs7ZUFFRztZQUNILHlCQUFnQyxLQUFrQjtnQkFFaEQsT0FBTyxjQUFjLENBQUMsS0FBSyxFQUFFLHFCQUFxQixDQUFDLENBQUM7WUFDdEQsQ0FBQztZQUhlLHNCQUFlLGtCQUc5QixDQUFBO1lBRUQ7O2VBRUc7WUFDSCx5QkFBZ0MsS0FBa0I7Z0JBRWhELE9BQU8sY0FBYyxDQUFDLEtBQUssRUFBRSx3QkFBd0IsQ0FBQztxQkFDakQsSUFBSSxDQUFDLFVBQUEsR0FBRyxJQUFJLE9BQUEsR0FBRyxDQUFDLFlBQVksQ0FBQyxFQUFqQixDQUFpQixDQUFDLENBQUM7WUFDdEMsQ0FBQztZQUplLHNCQUFlLGtCQUk5QixDQUFBO1lBRUQ7Ozs7Ozs7ZUFPRztZQUNILHdCQUNJLEtBQWtCLEVBQ2xCLGNBQTZDO2dCQUMvQyxJQUFJLE1BQU0sR0FBNkIsRUFBRSxDQUFDO2dCQUMxQyxJQUFJLEtBQUssR0FBRyxFQUFFLENBQUM7Z0JBQ2YsSUFBSSxJQUFJLEdBQWEsRUFBRSxDQUFDO2dCQUN4QixJQUFJLE9BQU8sR0FBNkIsTUFBTSxDQUFDO2dCQUUvQyxzQ0FBc0MsSUFBWTtvQkFDaEQsSUFBSSxVQUFVLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQztvQkFDbkMsSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsVUFBVSxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7b0JBQ2hELElBQUksS0FBSyxHQUFHLFVBQVUsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFVBQVUsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDO29CQUM5RCxPQUFPO3dCQUNMLElBQUksRUFBRSxJQUFJO3dCQUNWLEtBQUssRUFBRSxLQUFLO3FCQUNiLENBQUM7Z0JBQ0osQ0FBQztnQkFFRDs7Ozs7Ozs7OzttQkFVRztnQkFDSCxzQkFBc0IsR0FBVyxFQUFFLElBQVksRUFDM0MsS0FBbUMsRUFBRSxJQUFjO29CQUNyRCx1REFBdUQ7b0JBQ3ZELElBQUksYUFBYSxHQUFHLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQztvQkFDOUIsSUFBSSxhQUFhLElBQUksSUFBSSxFQUFFO3dCQUN6QixHQUFHLENBQUMsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztxQkFDaEU7eUJBQU0sSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxFQUFFO3dCQUN2QyxhQUFhLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO3FCQUMzQjt5QkFBTTt3QkFDTCxHQUFHLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxhQUFhLEVBQUUsS0FBSyxDQUFDLENBQUM7cUJBQ3BDO2dCQUNILENBQUM7Z0JBRUQseUNBQXlDO2dCQUN6QyxPQUFPLFdBQVcsQ0FBQyxLQUFLLEVBQUUsVUFBUyxJQUFZO29CQUM3QyxJQUFJLENBQUMsSUFBSSxFQUFFO3dCQUNULE9BQU87cUJBQ1I7b0JBQ0QsSUFBSSxHQUFHLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQztvQkFFbkIsUUFBUSxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsRUFBRTt3QkFDN0IsS0FBSyxHQUFHLEVBQUcsb0JBQW9COzRCQUM3QixJQUFJLE1BQUksR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDOzRCQUNyRCxJQUFJLFFBQVEsR0FBNkIsRUFBRSxDQUFDOzRCQUM1QyxLQUFLLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDOzRCQUNwQixJQUFJLENBQUMsSUFBSSxDQUFDLE1BQUksQ0FBQyxDQUFDOzRCQUNoQixZQUFZLENBQUMsT0FBTyxFQUFFLE1BQUksRUFBRSxRQUFRLEVBQUUsSUFBSSxDQUFDLENBQUM7NEJBQzVDLE9BQU8sR0FBRyxRQUFRLENBQUM7NEJBQ25CLE1BQU07d0JBQ1IsS0FBSyxHQUFHOzRCQUNOLE9BQU8sR0FBRyxLQUFLLENBQUMsR0FBRyxFQUFFLENBQUM7NEJBQ3RCLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQzs0QkFDWCxNQUFNO3dCQUNSOzRCQUNFLElBQUksQ0FBQyxHQUFHLDRCQUE0QixDQUFDLElBQUksQ0FBQyxDQUFDOzRCQUMzQyxZQUFZLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDOzRCQUM1RCxNQUFNO3FCQUNUO2dCQUNILENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztvQkFDTixPQUFPLE1BQU0sQ0FBQztnQkFDaEIsQ0FBQyxDQUFDLENBQUM7WUFDTCxDQUFDO1FBRUQsQ0FBQyxFQWxSZSxNQUFNLEdBQU4sWUFBTSxLQUFOLFlBQU0sUUFrUnJCO0lBQUQsQ0FBQyxFQWxSUyxLQUFLLEdBQUwsUUFBSyxLQUFMLFFBQUssUUFrUmQ7QUFBRCxDQUFDLEVBbFJNLEVBQUUsS0FBRixFQUFFLFFBa1JSLENBQUMsZ0NBQWdDIiwic291cmNlc0NvbnRlbnQiOlsiLyogQ29weXJpZ2h0IDIwMTUgVGhlIFRlbnNvckZsb3cgQXV0aG9ycy4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cblxuTGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlLCBWZXJzaW9uIDIuMCAodGhlICdMaWNlbnNlJyk7XG55b3UgbWF5IG5vdCB1c2UgdGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlIHdpdGggdGhlIExpY2Vuc2UuXG5Zb3UgbWF5IG9idGFpbiBhIGNvcHkgb2YgdGhlIExpY2Vuc2UgYXRcblxuICAgIGh0dHA6Ly93d3cuYXBhY2hlLm9yZy9saWNlbnNlcy9MSUNFTlNFLTIuMFxuXG5Vbmxlc3MgcmVxdWlyZWQgYnkgYXBwbGljYWJsZSBsYXcgb3IgYWdyZWVkIHRvIGluIHdyaXRpbmcsIHNvZnR3YXJlXG5kaXN0cmlidXRlZCB1bmRlciB0aGUgTGljZW5zZSBpcyBkaXN0cmlidXRlZCBvbiBhbiAnQVMgSVMnIEJBU0lTLFxuV0lUSE9VVCBXQVJSQU5USUVTIE9SIENPTkRJVElPTlMgT0YgQU5ZIEtJTkQsIGVpdGhlciBleHByZXNzIG9yIGltcGxpZWQuXG5TZWUgdGhlIExpY2Vuc2UgZm9yIHRoZSBzcGVjaWZpYyBsYW5ndWFnZSBnb3Zlcm5pbmcgcGVybWlzc2lvbnMgYW5kXG5saW1pdGF0aW9ucyB1bmRlciB0aGUgTGljZW5zZS5cbj09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSovXG5tb2R1bGUgdGYuZ3JhcGgucGFyc2VyIHtcblxuLyoqXG4gKiBQYXJzZXMgYSBuYXRpdmUganMgdmFsdWUsIHdoaWNoIGNhbiBiZSBlaXRoZXIgYSBzdHJpbmcsIGJvb2xlYW4gb3IgbnVtYmVyLlxuICpcbiAqIEBwYXJhbSB2YWx1ZSBUaGUgdmFsdWUgdG8gYmUgcGFyc2VkLlxuICovXG5mdW5jdGlvbiBwYXJzZVZhbHVlKHZhbHVlOiBzdHJpbmcpOiBzdHJpbmd8bnVtYmVyfGJvb2xlYW4ge1xuICBpZiAodmFsdWUgPT09ICd0cnVlJykge1xuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIGlmICh2YWx1ZSA9PT0gJ2ZhbHNlJykge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBsZXQgZmlyc3RDaGFyID0gdmFsdWVbMF07XG4gIGlmIChmaXJzdENoYXIgPT09ICdcIicpIHtcbiAgICByZXR1cm4gdmFsdWUuc3Vic3RyaW5nKDEsIHZhbHVlLmxlbmd0aCAtIDEpO1xuICB9XG4gIGxldCBudW0gPSBwYXJzZUZsb2F0KHZhbHVlKTtcbiAgcmV0dXJuIGlzTmFOKG51bSkgPyB2YWx1ZSA6IG51bTtcbn1cblxuLyoqXG4gKiBGZXRjaGVzIGEgdGV4dCBmaWxlIGFuZCByZXR1cm5zIGEgcHJvbWlzZSBvZiB0aGUgcmVzdWx0LlxuICovXG5leHBvcnQgZnVuY3Rpb24gZmV0Y2hQYlR4dChmaWxlcGF0aDogc3RyaW5nKTogUHJvbWlzZTxBcnJheUJ1ZmZlcj4ge1xuICByZXR1cm4gbmV3IFByb21pc2U8QXJyYXlCdWZmZXI+KGZ1bmN0aW9uKHJlc29sdmUsIHJlamVjdCkge1xuICAgIGNvbnN0IHJlcXVlc3QgPSBuZXcgWE1MSHR0cFJlcXVlc3QoKTtcbiAgICByZXF1ZXN0Lm9wZW4oJ0dFVCcsIGZpbGVwYXRoKTtcbiAgICByZXF1ZXN0LnJlc3BvbnNlVHlwZSA9ICdhcnJheWJ1ZmZlcic7XG5cbiAgICByZXF1ZXN0Lm9uZXJyb3IgPSAoKSA9PiByZWplY3QocmVxdWVzdC5zdGF0dXMpO1xuICAgIHJlcXVlc3Qub25sb2FkID0gKCkgPT4gcmVzb2x2ZShyZXF1ZXN0LnJlc3BvbnNlKTtcblxuICAgIHJlcXVlc3Quc2VuZChudWxsKTtcbiAgfSk7XG59XG5cbi8qKlxuICogRmV0Y2hlcyB0aGUgbWV0YWRhdGEgZmlsZSwgcGFyc2VzIGl0IGFuZCByZXR1cm5zIGEgcHJvbWlzZSBvZiB0aGUgcmVzdWx0LlxuICovXG5leHBvcnQgZnVuY3Rpb24gZmV0Y2hBbmRQYXJzZU1ldGFkYXRhKHBhdGg6IHN0cmluZywgdHJhY2tlcjogUHJvZ3Jlc3NUcmFja2VyKSB7XG4gIHJldHVybiB0Zi5ncmFwaC51dGlsXG4gICAgICAucnVuVGFzayhcbiAgICAgICAgICAnUmVhZGluZyBtZXRhZGF0YSBwYnR4dCcsIDQwLFxuICAgICAgICAgICgpID0+IHtcbiAgICAgICAgICAgIGlmIChwYXRoID09IG51bGwpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZShudWxsKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBmZXRjaFBiVHh0KHBhdGgpO1xuICAgICAgICAgIH0sXG4gICAgICAgICAgdHJhY2tlcilcbiAgICAgIC50aGVuKChhcnJheUJ1ZmZlcjogQXJyYXlCdWZmZXIpID0+IHtcbiAgICAgICAgcmV0dXJuIHRmLmdyYXBoLnV0aWwucnVuQXN5bmNQcm9taXNlVGFzayhcbiAgICAgICAgICAgICdQYXJzaW5nIG1ldGFkYXRhLnBidHh0JywgNjAsICgpID0+IHtcbiAgICAgICAgICAgICAgcmV0dXJuIGFycmF5QnVmZmVyICE9IG51bGwgPyBwYXJzZVN0YXRzUGJUeHQoYXJyYXlCdWZmZXIpIDpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBQcm9taXNlLnJlc29sdmUobnVsbCk7XG4gICAgICAgICAgICB9LCB0cmFja2VyKTtcbiAgICAgIH0pO1xufVxuXG4vKipcbiAqIEZldGNoZXMgdGhlIGdyYXBoIGZpbGUsIHBhcnNlcyBpdCBhbmQgcmV0dXJucyBhIHByb21pc2Ugb2YgdGhlIHJlc3VsdC4gVGhlXG4gKiByZXN1bHQgd2lsbCBiZSB1bmRlZmluZWQgaWYgdGhlIGdyYXBoIGlzIGVtcHR5LlxuICovXG5leHBvcnQgZnVuY3Rpb24gZmV0Y2hBbmRQYXJzZUdyYXBoRGF0YShwYXRoOiBzdHJpbmcsIHBiVHh0RmlsZTogQmxvYixcbiAgICB0cmFja2VyOiBQcm9ncmVzc1RyYWNrZXIpIHtcbiAgcmV0dXJuIHRmLmdyYXBoLnV0aWxcbiAgICAgIC5ydW5UYXNrKFxuICAgICAgICAgICdSZWFkaW5nIGdyYXBoIHBidHh0JywgNDAsXG4gICAgICAgICAgKCkgPT4ge1xuICAgICAgICAgICAgaWYgKHBiVHh0RmlsZSkge1xuICAgICAgICAgICAgICByZXR1cm4gbmV3IFByb21pc2U8QXJyYXlCdWZmZXI+KGZ1bmN0aW9uKHJlc29sdmUsIHJlamVjdCkge1xuICAgICAgICAgICAgICAgIGxldCBmaWxlUmVhZGVyID0gbmV3IEZpbGVSZWFkZXIoKTtcbiAgICAgICAgICAgICAgICBmaWxlUmVhZGVyLm9ubG9hZCA9ICgpID0+IHJlc29sdmUoZmlsZVJlYWRlci5yZXN1bHQpO1xuICAgICAgICAgICAgICAgIGZpbGVSZWFkZXIub25lcnJvciA9ICgpID0+IHJlamVjdChmaWxlUmVhZGVyLmVycm9yKTtcbiAgICAgICAgICAgICAgICBmaWxlUmVhZGVyLnJlYWRBc0FycmF5QnVmZmVyKHBiVHh0RmlsZSk7XG4gICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgcmV0dXJuIGZldGNoUGJUeHQocGF0aCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSxcbiAgICAgICAgICB0cmFja2VyKVxuICAgICAgLnRoZW4oKGFycmF5QnVmZmVyOiBBcnJheUJ1ZmZlcikgPT4ge1xuICAgICAgICByZXR1cm4gdGYuZ3JhcGgudXRpbC5ydW5UYXNrKCdQYXJzaW5nIGdyYXBoLnBidHh0JywgNjAsICgpID0+IHtcbiAgICAgICAgICByZXR1cm4gcGFyc2VHcmFwaFBiVHh0KGFycmF5QnVmZmVyKTtcbiAgICAgICAgfSwgdHJhY2tlcik7XG4gICAgICB9KTtcbn1cblxuLyoqXG4gKiBQYXJzZSBhIGZpbGUgb2JqZWN0IGluIGEgc3RyZWFtaW5nIGZhc2hpb24gbGluZSBieSBsaW5lIChvciBjdXN0b20gZGVsaW0pLlxuICogQ2FuIGhhbmRsZSB2ZXJ5IGxhcmdlIGZpbGVzLlxuICogQHBhcmFtIGlucHV0IFRoZSBmaWxlIG9iamVjdCBhcyBhbiBhcnJheSBidWZmZXIuXG4gKiBAcGFyYW0gY2FsbGJhY2sgVGhlIGNhbGxiYWNrIGNhbGxlZCBvbiBlYWNoIGxpbmVcbiAqIEBwYXJhbSBjaHVua1NpemUgVGhlIHNpemUgb2YgZWFjaCByZWFkIGNodW5rLiAob3B0aW9uYWwpXG4gKiBAcGFyYW0gZGVsaW0gVGhlIGRlbGltaXRlciB1c2VkIHRvIHNwbGl0IGEgbGluZS4gKG9wdGlvbmFsKVxuICogQHJldHVybnMgQSBwcm9taXNlIGZvciB3aGVuIGl0IGlzIGZpbmlzaGVkLlxuICovXG5leHBvcnQgZnVuY3Rpb24gc3RyZWFtUGFyc2UoXG4gICAgYXJyYXlCdWZmZXI6IEFycmF5QnVmZmVyLCBjYWxsYmFjazogKHN0cmluZykgPT4gdm9pZCxcbiAgICBjaHVua1NpemU6IG51bWJlciA9IDEwMDAwMDAsIGRlbGltOiBzdHJpbmcgPSAnXFxuJyk6IFByb21pc2U8Ym9vbGVhbj4ge1xuICByZXR1cm4gbmV3IFByb21pc2U8Ym9vbGVhbj4oZnVuY3Rpb24ocmVzb2x2ZSwgcmVqZWN0KSB7XG4gICAgbGV0IG9mZnNldCA9IDA7XG4gICAgbGV0IGJ1ZmZlclNpemUgPSBhcnJheUJ1ZmZlci5ieXRlTGVuZ3RoIC0gMTtcbiAgICBsZXQgZGF0YSA9ICcnO1xuXG4gICAgZnVuY3Rpb24gcmVhZEhhbmRsZXIoc3RyKSB7XG4gICAgICBvZmZzZXQgKz0gY2h1bmtTaXplO1xuICAgICAgbGV0IHBhcnRzID0gc3RyLnNwbGl0KGRlbGltKTtcbiAgICAgIGxldCBmaXJzdCA9IGRhdGEgKyBwYXJ0c1swXTtcbiAgICAgIGlmIChwYXJ0cy5sZW5ndGggPT09IDEpIHtcbiAgICAgICAgZGF0YSA9IGZpcnN0O1xuICAgICAgICByZWFkQ2h1bmsob2Zmc2V0LCBjaHVua1NpemUpO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBkYXRhID0gcGFydHNbcGFydHMubGVuZ3RoIC0gMV07XG4gICAgICBjYWxsYmFjayhmaXJzdCk7XG4gICAgICBmb3IgKGxldCBpID0gMTsgaSA8IHBhcnRzLmxlbmd0aCAtIDE7IGkrKykge1xuICAgICAgICBjYWxsYmFjayhwYXJ0c1tpXSk7XG4gICAgICB9XG4gICAgICBpZiAob2Zmc2V0ID49IGJ1ZmZlclNpemUpIHtcbiAgICAgICAgaWYgKGRhdGEpIHtcbiAgICAgICAgICBjYWxsYmFjayhkYXRhKTtcbiAgICAgICAgfVxuICAgICAgICByZXNvbHZlKHRydWUpO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICByZWFkQ2h1bmsob2Zmc2V0LCBjaHVua1NpemUpO1xuICAgIH1cblxuICAgIGZ1bmN0aW9uIHJlYWRDaHVuayhvZmZzZXQ6IG51bWJlciwgc2l6ZTogbnVtYmVyKSB7XG4gICAgICBjb25zdCBhcnJheUJ1ZmZlckNodW5rID0gYXJyYXlCdWZmZXIuc2xpY2Uob2Zmc2V0LCBvZmZzZXQgKyBzaXplKTtcblxuICAgICAgY29uc3QgYmxvYiA9IG5ldyBCbG9iKFthcnJheUJ1ZmZlckNodW5rXSk7XG4gICAgICBjb25zdCBmaWxlID0gbmV3IEZpbGVSZWFkZXIoKTtcbiAgICAgIGZpbGUub25sb2FkID0gKGU6IGFueSkgPT4gcmVhZEhhbmRsZXIoZS50YXJnZXQucmVzdWx0KTtcbiAgICAgIGZpbGUucmVhZEFzVGV4dChibG9iKTtcbiAgICB9XG5cbiAgICByZWFkQ2h1bmsob2Zmc2V0LCBjaHVua1NpemUpO1xuICB9KTtcbn1cblxuLyoqXG4gKiBTaW5jZSBwcm90by10eHQgZG9lc24ndCBleHBsaWNpdGx5IHNheSB3aGV0aGVyIGFuIGF0dHJpYnV0ZSBpcyByZXBlYXRlZFxuICogKGFuIGFycmF5KSBvciBub3QsIHdlIGtlZXAgYSBoYXJkLWNvZGVkIGxpc3Qgb2YgYXR0cmlidXRlcyB0aGF0IGFyZSBrbm93blxuICogdG8gYmUgcmVwZWF0ZWQuIFRoaXMgbGlzdCBpcyB1c2VkIGluIHBhcnNpbmcgdGltZSB0byBjb252ZXJ0IHJlcGVhdGVkXG4gKiBhdHRyaWJ1dGVzIGludG8gYXJyYXlzIGV2ZW4gd2hlbiB0aGUgYXR0cmlidXRlIG9ubHkgc2hvd3MgdXAgb25jZSBpbiB0aGVcbiAqIG9iamVjdC5cbiAqL1xuY29uc3QgR1JBUEhfUkVQRUFURURfRklFTERTOiB7W2F0dHJQYXRoOiBzdHJpbmddOiBib29sZWFufSA9IHtcbiAgJ2xpYnJhcnkuZnVuY3Rpb24nOiB0cnVlLFxuICAnbGlicmFyeS5mdW5jdGlvbi5ub2RlX2RlZic6IHRydWUsXG4gICdsaWJyYXJ5LmZ1bmN0aW9uLnNpZ25hdHVyZS5pbnB1dF9hcmcnOiB0cnVlLFxuICAnbGlicmFyeS5mdW5jdGlvbi5zaWduYXR1cmUub3V0cHV0X2FyZyc6IHRydWUsXG4gICdsaWJyYXJ5LnZlcnNpb25zJzogdHJ1ZSxcbiAgJ25vZGUnOiB0cnVlLFxuICAnbm9kZS5pbnB1dCc6IHRydWUsXG4gICdub2RlLmF0dHInOiB0cnVlLFxuICAnbm9kZS5hdHRyLnZhbHVlLmxpc3QudHlwZSc6IHRydWUsXG4gICdub2RlLmF0dHIudmFsdWUuc2hhcGUuZGltJzogdHJ1ZSxcbiAgJ25vZGUuYXR0ci52YWx1ZS50ZW5zb3Iuc3RyaW5nX3ZhbCc6IHRydWUsXG4gICdub2RlLmF0dHIudmFsdWUudGVuc29yLnRlbnNvcl9zaGFwZS5kaW0nOiB0cnVlLFxuICAnbm9kZS5hdHRyLnZhbHVlLmxpc3Quc2hhcGUnOiB0cnVlLFxuICAnbm9kZS5hdHRyLnZhbHVlLmxpc3Quc2hhcGUuZGltJzogdHJ1ZSxcbiAgJ25vZGUuYXR0ci52YWx1ZS5saXN0LnMnOiB0cnVlXG59O1xuXG5jb25zdCBNRVRBREFUQV9SRVBFQVRFRF9GSUVMRFM6IHtbYXR0clBhdGg6IHN0cmluZ106IGJvb2xlYW59ID0ge1xuICAnc3RlcF9zdGF0cy5kZXZfc3RhdHMnOiB0cnVlLFxuICAnc3RlcF9zdGF0cy5kZXZfc3RhdHMubm9kZV9zdGF0cyc6IHRydWUsXG4gICdzdGVwX3N0YXRzLmRldl9zdGF0cy5ub2RlX3N0YXRzLm91dHB1dCc6IHRydWUsXG4gICdzdGVwX3N0YXRzLmRldl9zdGF0cy5ub2RlX3N0YXRzLm1lbW9yeSc6IHRydWUsXG4gICdzdGVwX3N0YXRzLmRldl9zdGF0cy5ub2RlX3N0YXRzLm91dHB1dC50ZW5zb3JfZGVzY3JpcHRpb24uc2hhcGUuZGltJzogdHJ1ZVxufTtcblxuLyoqXG4gKiBQYXJzZXMgYW4gQXJyYXlCdWZmZXIgb2YgYSBwcm90byB0eHQgZmlsZSBpbnRvIGEgcmF3IEdyYXBoIG9iamVjdC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlR3JhcGhQYlR4dChpbnB1dDogQXJyYXlCdWZmZXIpOlxuICAgIFByb21pc2U8dGYuZ3JhcGgucHJvdG8uR3JhcGhEZWY+IHtcbiAgcmV0dXJuIHBhcnNlUGJ0eHRGaWxlKGlucHV0LCBHUkFQSF9SRVBFQVRFRF9GSUVMRFMpO1xufVxuXG4vKipcbiAqIFBhcnNlcyBhbiBBcnJheUJ1ZmZlciBvZiBhIHByb3RvIHR4dCBmaWxlIGludG8gYSBTdGVwU3RhdHMgb2JqZWN0LlxuICovXG5leHBvcnQgZnVuY3Rpb24gcGFyc2VTdGF0c1BiVHh0KGlucHV0OiBBcnJheUJ1ZmZlcik6XG4gICAgUHJvbWlzZTx0Zi5ncmFwaC5wcm90by5TdGVwU3RhdHM+IHtcbiAgcmV0dXJuIHBhcnNlUGJ0eHRGaWxlKGlucHV0LCBNRVRBREFUQV9SRVBFQVRFRF9GSUVMRFMpXG4gICAgICAudGhlbihvYmogPT4gb2JqWydzdGVwX3N0YXRzJ10pO1xufVxuXG4vKipcbiAqIFBhcnNlcyBhIEFycmF5QnVmZmVyIG9mIGEgcHJvdG8gdHh0IGZpbGUgaW50byBqYXZhc2NyaXB0IG9iamVjdC5cbiAqXG4gKiBAcGFyYW0gaW5wdXQgVGhlIEFycmF5QnVmZmVyIG9yIGZpbGUgb2JqZWN0IGltcGxlbWVudGluZyBzbGljZS5cbiAqIEBwYXJhbSByZXBlYXRlZEZpZWxkcyBNYXAgKFNldCkgb2YgYWxsIHRoZSByZXBlYXRlZCBmaWVsZHMsIHNpbmNlIHlvdSBjYW4ndFxuICogICB0ZWxsIGRpcmVjdGx5IGZyb20gdGhlIHBidHh0IGlmIGEgZmllbGQgaXMgcmVwZWF0ZWQgb3Igbm90LlxuICogQHJldHVybnMgVGhlIHBhcnNlZCBvYmplY3QuXG4gKi9cbmZ1bmN0aW9uIHBhcnNlUGJ0eHRGaWxlKFxuICAgIGlucHV0OiBBcnJheUJ1ZmZlcixcbiAgICByZXBlYXRlZEZpZWxkczoge1thdHRyUGF0aDogc3RyaW5nXTogYm9vbGVhbn0pOiBQcm9taXNlPGFueT4ge1xuICBsZXQgb3V0cHV0OiB7IFtuYW1lOiBzdHJpbmddOiBhbnk7IH0gPSB7fTtcbiAgbGV0IHN0YWNrID0gW107XG4gIGxldCBwYXRoOiBzdHJpbmdbXSA9IFtdO1xuICBsZXQgY3VycmVudDogeyBbbmFtZTogc3RyaW5nXTogYW55OyB9ID0gb3V0cHV0O1xuXG4gIGZ1bmN0aW9uIHNwbGl0TmFtZUFuZFZhbHVlSW5BdHRyaWJ1dGUobGluZTogc3RyaW5nKSB7XG4gICAgbGV0IGNvbG9uSW5kZXggPSBsaW5lLmluZGV4T2YoJzonKTtcbiAgICBsZXQgbmFtZSA9IGxpbmUuc3Vic3RyaW5nKDAsIGNvbG9uSW5kZXgpLnRyaW0oKTtcbiAgICBsZXQgdmFsdWUgPSBwYXJzZVZhbHVlKGxpbmUuc3Vic3RyaW5nKGNvbG9uSW5kZXggKyAyKS50cmltKCkpO1xuICAgIHJldHVybiB7XG4gICAgICBuYW1lOiBuYW1lLFxuICAgICAgdmFsdWU6IHZhbHVlXG4gICAgfTtcbiAgfVxuXG4gIC8qKlxuICAgKiBBZGRzIGEgdmFsdWUsIGdpdmVuIHRoZSBhdHRyaWJ1dGUgbmFtZSBhbmQgdGhlIGhvc3Qgb2JqZWN0LiBJZiB0aGVcbiAgICogYXR0cmlidXRlIGFscmVhZHkgZXhpc3RzLCBidXQgaXMgbm90IGFuIGFycmF5LCBpdCB3aWxsIGNvbnZlcnQgaXQgdG8gYW5cbiAgICogYXJyYXkgb2YgdmFsdWVzLlxuICAgKlxuICAgKiBAcGFyYW0gb2JqIFRoZSBob3N0IG9iamVjdCB0aGF0IGhvbGRzIHRoZSBhdHRyaWJ1dGUuXG4gICAqIEBwYXJhbSBuYW1lIFRoZSBhdHRyaWJ1dGUgbmFtZSAoa2V5KS5cbiAgICogQHBhcmFtIHZhbHVlIFRoZSBhdHRyaWJ1dGUgdmFsdWUuXG4gICAqIEBwYXJhbSBwYXRoIEEgcGF0aCB0aGF0IGlkZW50aWZpZXMgdGhlIGF0dHJpYnV0ZS4gVXNlZCB0byBjaGVjayBpZlxuICAgKiAgICAgYW4gYXR0cmlidXRlIGlzIGFuIGFycmF5IG9yIG5vdC5cbiAgICovXG4gIGZ1bmN0aW9uIGFkZEF0dHJpYnV0ZShvYmo6IE9iamVjdCwgbmFtZTogc3RyaW5nLFxuICAgICAgdmFsdWU6IE9iamVjdHxzdHJpbmd8bnVtYmVyfGJvb2xlYW4sIHBhdGg6IHN0cmluZ1tdKTogdm9pZCB7XG4gICAgLy8gV2UgdHJlYXQgJ25vZGUnIHNwZWNpYWxseSBzaW5jZSBpdCBpcyBkb25lIHNvIG9mdGVuLlxuICAgIGxldCBleGlzdGluZ1ZhbHVlID0gb2JqW25hbWVdO1xuICAgIGlmIChleGlzdGluZ1ZhbHVlID09IG51bGwpIHtcbiAgICAgIG9ialtuYW1lXSA9IHBhdGguam9pbignLicpIGluIHJlcGVhdGVkRmllbGRzID8gW3ZhbHVlXSA6IHZhbHVlO1xuICAgIH0gZWxzZSBpZiAoQXJyYXkuaXNBcnJheShleGlzdGluZ1ZhbHVlKSkge1xuICAgICAgZXhpc3RpbmdWYWx1ZS5wdXNoKHZhbHVlKTtcbiAgICB9IGVsc2Uge1xuICAgICAgb2JqW25hbWVdID0gW2V4aXN0aW5nVmFsdWUsIHZhbHVlXTtcbiAgICB9XG4gIH1cblxuICAvLyBSdW4gdGhyb3VnaCB0aGUgZmlsZSBhIGxpbmUgYXQgYSB0aW1lLlxuICByZXR1cm4gc3RyZWFtUGFyc2UoaW5wdXQsIGZ1bmN0aW9uKGxpbmU6IHN0cmluZykge1xuICAgIGlmICghbGluZSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBsaW5lID0gbGluZS50cmltKCk7XG5cbiAgICBzd2l0Y2ggKGxpbmVbbGluZS5sZW5ndGggLSAxXSkge1xuICAgICAgY2FzZSAneyc6ICAvLyBjcmVhdGUgbmV3IG9iamVjdFxuICAgICAgICBsZXQgbmFtZSA9IGxpbmUuc3Vic3RyaW5nKDAsIGxpbmUubGVuZ3RoIC0gMikudHJpbSgpO1xuICAgICAgICBsZXQgbmV3VmFsdWU6IHsgW25hbWU6IHN0cmluZ106IGFueTsgfSA9IHt9O1xuICAgICAgICBzdGFjay5wdXNoKGN1cnJlbnQpO1xuICAgICAgICBwYXRoLnB1c2gobmFtZSk7XG4gICAgICAgIGFkZEF0dHJpYnV0ZShjdXJyZW50LCBuYW1lLCBuZXdWYWx1ZSwgcGF0aCk7XG4gICAgICAgIGN1cnJlbnQgPSBuZXdWYWx1ZTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlICd9JzpcbiAgICAgICAgY3VycmVudCA9IHN0YWNrLnBvcCgpO1xuICAgICAgICBwYXRoLnBvcCgpO1xuICAgICAgICBicmVhaztcbiAgICAgIGRlZmF1bHQ6XG4gICAgICAgIGxldCB4ID0gc3BsaXROYW1lQW5kVmFsdWVJbkF0dHJpYnV0ZShsaW5lKTtcbiAgICAgICAgYWRkQXR0cmlidXRlKGN1cnJlbnQsIHgubmFtZSwgeC52YWx1ZSwgcGF0aC5jb25jYXQoeC5uYW1lKSk7XG4gICAgICAgIGJyZWFrO1xuICAgIH1cbiAgfSkudGhlbihmdW5jdGlvbigpIHtcbiAgICByZXR1cm4gb3V0cHV0O1xuICB9KTtcbn1cblxufSAvLyBDbG9zZSBtb2R1bGUgdGYuZ3JhcGgucGFyc2VyLlxuIl19