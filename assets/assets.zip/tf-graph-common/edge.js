/* Copyright 2015 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the 'License');
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an 'AS IS' BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
var tf;
(function (tf) {
    var graph;
    (function (graph_1) {
        var scene;
        (function (scene) {
            var edge;
            (function (edge) {
                /** Delimiter between dimensions when showing sizes of tensors. */
                var TENSOR_SHAPE_DELIM = '×';
                /** The minimum stroke width of an edge. */
                edge.MIN_EDGE_WIDTH = 0.75;
                /** The maximum stroke width of an edge. */
                edge.MAX_EDGE_WIDTH = 12;
                /** The exponent used in the power scale for edge thickness. */
                var EDGE_WIDTH_SCALE_EXPONENT = 0.3;
                /** The domain (min and max value) for the edge width. */
                var DOMAIN_EDGE_WIDTH_SCALE = [1, 5E6];
                edge.EDGE_WIDTH_SIZE_BASED_SCALE = d3.scalePow()
                    .exponent(EDGE_WIDTH_SCALE_EXPONENT)
                    .domain(DOMAIN_EDGE_WIDTH_SCALE)
                    .range([edge.MIN_EDGE_WIDTH, edge.MAX_EDGE_WIDTH])
                    .clamp(true);
                var arrowheadMap = d3.scaleQuantize().domain([edge.MIN_EDGE_WIDTH, edge.MAX_EDGE_WIDTH]).range([
                    'small', 'medium', 'large', 'xlarge'
                ]);
                /** Minimum stroke width to put edge labels in the middle of edges */
                var CENTER_EDGE_LABEL_MIN_STROKE_WIDTH = 2.5;
                function getEdgeKey(edgeObj) {
                    return edgeObj.v + graph_1.EDGE_KEY_DELIM + edgeObj.w;
                }
                edge.getEdgeKey = getEdgeKey;
                /**
                 * Select or Create a 'g.edges' group to a given sceneGroup
                 * and builds a number of 'g.edge' groups inside the group.
                 *
                 * Structure Pattern:
                 *
                 * <g class='edges'>
                 *   <g class='edge'>
                 *     <path class='edgeline'/>
                 *   </g>
                 *   ...
                 * </g>
                 *
                 *
                 * @param sceneGroup container
                 * @param graph
                 * @param sceneElement <tf-graph-scene> polymer element.
                 * @return selection of the created nodeGroups
                 */
                function buildGroup(sceneGroup, graph, sceneElement) {
                    var edges = [];
                    edges = _.reduce(graph.edges(), function (edges, edgeObj) {
                        var edgeLabel = graph.edge(edgeObj);
                        edges.push({
                            v: edgeObj.v,
                            w: edgeObj.w,
                            label: edgeLabel
                        });
                        return edges;
                    }, edges);
                    var container = scene.selectOrCreateChild(sceneGroup, 'g', scene.Class.Edge.CONTAINER);
                    // Select all children and join with data.
                    // (Note that all children of g.edges are g.edge)
                    var edgeGroups = container.selectAll(function () { return this.childNodes; }).data(edges, getEdgeKey);
                    // Make edges a group to support rendering multiple lines for metaedge
                    edgeGroups.enter()
                        .append('g')
                        .attr('class', scene.Class.Edge.GROUP)
                        .attr('data-edge', getEdgeKey)
                        .each(function (d) {
                        var edgeGroup = d3.select(this);
                        d.label.edgeGroup = edgeGroup;
                        // index node group for quick highlighting
                        sceneElement._edgeGroupIndex[getEdgeKey(d)] = edgeGroup;
                        if (sceneElement.handleEdgeSelected) {
                            // The user or some higher-level component has opted to make edges selectable.
                            edgeGroup
                                .on('click', function (d) {
                                // Stop this event's propagation so that it isn't also considered
                                // a graph-select.
                                d3.event.stopPropagation();
                                sceneElement.fire('edge-select', {
                                    edgeData: d,
                                    edgeGroup: edgeGroup
                                });
                            });
                        }
                        // Add line during enter because we're assuming that type of line
                        // normally does not change.
                        appendEdge(edgeGroup, d, sceneElement);
                    })
                        .merge(edgeGroups)
                        .each(position)
                        .each(function (d) {
                        stylize(d3.select(this), d, sceneElement);
                    });
                    edgeGroups.exit()
                        .each(function (d) {
                        delete sceneElement._edgeGroupIndex[getEdgeKey(d)];
                    })
                        .remove();
                    return edgeGroups;
                }
                edge.buildGroup = buildGroup;
                ;
                /**
                 * Returns the label for the given base edge.
                 * The label is the shape of the underlying tensor.
                 */
                function getLabelForBaseEdge(baseEdge, renderInfo) {
                    var node = renderInfo.getNodeByName(baseEdge.v);
                    if (node.outputShapes == null || _.isEmpty(node.outputShapes)) {
                        return null;
                    }
                    var shape = node.outputShapes[baseEdge.outputTensorKey];
                    if (shape == null) {
                        return null;
                    }
                    if (shape.length === 0) {
                        return 'scalar';
                    }
                    return shape.map(function (size) { return size === -1 ? '?' : size; })
                        .join(TENSOR_SHAPE_DELIM);
                }
                edge.getLabelForBaseEdge = getLabelForBaseEdge;
                /**
                 * Creates the label for the given metaedge. If the metaedge consists
                 * of only 1 tensor, and it's shape is known, the label will contain that
                 * shape. Otherwise, the label will say the number of tensors in the metaedge.
                 */
                function getLabelForEdge(metaedge, renderInfo) {
                    if (renderInfo.edgeLabelFunction) {
                        // The user has specified a means of computing the label.
                        return renderInfo.edgeLabelFunction(metaedge, renderInfo);
                    }
                    // Compute the label based on either tensor count or size.
                    var isMultiEdge = metaedge.baseEdgeList.length > 1;
                    return isMultiEdge ?
                        metaedge.baseEdgeList.length + ' tensors' :
                        getLabelForBaseEdge(metaedge.baseEdgeList[0], renderInfo);
                }
                edge.getLabelForEdge = getLabelForEdge;
                /**
                 * Computes the index into a set of points that constitute a path for which the
                 * distance along the path from the initial point is as large as possible
                 * without exceeding the length. This function was introduced after the
                 * native getPathSegAtLength method got deprecated by SVG 2.
                 * @param points Array of path control points. A point has x and y properties.
                 *   Must be of length at least 2.
                 * @param length The length (float).
                 * @param lineFunc A function that takes points and returns the "d" attribute
                 *   of a path made from connecting the points.
                 * @return The index into the points array.
                 */
                function getPathSegmentIndexAtLength(points, length, lineFunc) {
                    var path = document.createElementNS(tf.graph.scene.SVG_NAMESPACE, 'path');
                    for (var i = 1; i < points.length; i++) {
                        path.setAttribute("d", lineFunc(points.slice(0, i)));
                        if (path.getTotalLength() > length) {
                            // This many points has already exceeded the length.
                            return i - 1;
                        }
                    }
                    // The entire path is shorter than the specified length.
                    return points.length - 1;
                }
                /**
                 * Shortens the path enought such that the tip of the start/end marker will
                 * point to the start/end of the path. The marker can be of arbitrary size.
                 *
                 * @param points Array of path control points.
                 * @param marker D3 selection of the <marker> svg element.
                 * @param isStart Is the marker a `start-marker`. If false, the marker is
                 *     an `end-marker`.
                 * @return The new array of control points.
                 */
                function adjustPathPointsForMarker(points, marker, isStart) {
                    var lineFunc = d3.line()
                        .x(function (d) { return d.x; })
                        .y(function (d) { return d.y; });
                    var path = d3.select(document.createElementNS('http://www.w3.org/2000/svg', 'path'))
                        .attr('d', lineFunc(points));
                    var markerWidth = +marker.attr('markerWidth');
                    var viewBox = marker.attr('viewBox').split(' ').map(Number);
                    var viewBoxWidth = viewBox[2] - viewBox[0];
                    var refX = +marker.attr('refX');
                    var pathNode = path.node();
                    if (isStart) {
                        // The edge flows downwards. Do not make the edge go the whole way, lest we
                        // clobber the arrowhead.
                        var fractionStickingOut = 1 - refX / viewBoxWidth;
                        var length_1 = markerWidth * fractionStickingOut;
                        var point = pathNode.getPointAtLength(length_1);
                        // Figure out how many segments of the path we need to remove in order
                        // to shorten the path.
                        var segIndex = getPathSegmentIndexAtLength(points, length_1, lineFunc);
                        // Update the very first segment.
                        points[segIndex - 1] = { x: point.x, y: point.y };
                        // Ignore every point before segIndex - 1.
                        return points.slice(segIndex - 1);
                    }
                    else {
                        // The edge flows upwards. Do not make the edge go the whole way, lest we
                        // clobber the arrowhead.
                        var fractionStickingOut = 1 - refX / viewBoxWidth;
                        var length_2 = pathNode.getTotalLength() - markerWidth * fractionStickingOut;
                        var point = pathNode.getPointAtLength(length_2);
                        // Figure out how many segments of the path we need to remove in order
                        // to shorten the path.
                        var segIndex = getPathSegmentIndexAtLength(points, length_2, lineFunc);
                        // Update the very last segment.
                        points[segIndex] = { x: point.x, y: point.y };
                        // Ignore every point after segIndex.
                        return points.slice(0, segIndex + 1);
                    }
                }
                /**
                 * For a given d3 selection and data object, create a path to represent the
                 * edge described in d.label.
                 *
                 * If d.label is defined, it will be a RenderMetaedgeInfo instance. It
                 * will sometimes be undefined, for example for some Annotation edges for which
                 * there is no underlying Metaedge in the hierarchical graph.
                 */
                function appendEdge(edgeGroup, d, sceneElement, edgeClass) {
                    edgeClass = edgeClass || scene.Class.Edge.LINE; // set default type
                    if (d.label && d.label.structural) {
                        edgeClass += ' ' + scene.Class.Edge.STRUCTURAL;
                    }
                    if (d.label && d.label.metaedge && d.label.metaedge.numRefEdges) {
                        edgeClass += ' ' + scene.Class.Edge.REFERENCE_EDGE;
                    }
                    if (sceneElement.handleEdgeSelected) {
                        // The user has opted to make edges selectable.
                        edgeClass += ' ' + scene.Class.Edge.SELECTABLE;
                    }
                    // Give the path a unique id, which will be used to link
                    // the textPath (edge label) to this path.
                    var pathId = 'path_' + getEdgeKey(d);
                    var strokeWidth;
                    if (sceneElement.renderHierarchy.edgeWidthFunction) {
                        // Compute edge thickness based on the user-specified method.
                        strokeWidth = sceneElement.renderHierarchy.edgeWidthFunction(d, edgeClass);
                    }
                    else {
                        // Encode tensor size within edge thickness.
                        var size = 1;
                        if (d.label != null && d.label.metaedge != null) {
                            // There is an underlying Metaedge.
                            size = d.label.metaedge.totalSize;
                        }
                        strokeWidth = sceneElement.renderHierarchy.edgeWidthSizedBasedScale(size);
                    }
                    var path = edgeGroup.append('path')
                        .attr('id', pathId)
                        .attr('class', edgeClass)
                        .style('stroke-width', strokeWidth + 'px');
                    // Check if there is a reference edge and add an arrowhead of the right size.
                    if (d.label && d.label.metaedge) {
                        if (d.label.metaedge.numRefEdges) {
                            // We have a reference edge.
                            var markerId = "reference-arrowhead-" + arrowheadMap(strokeWidth);
                            path.style('marker-start', "url(#" + markerId + ")");
                            d.label.startMarkerId = markerId;
                        }
                        else {
                            // We have a dataflow edge.
                            var markerId = "dataflow-arrowhead-" + arrowheadMap(strokeWidth);
                            path.style('marker-end', "url(#" + markerId + ")");
                            d.label.endMarkerId = markerId;
                        }
                    }
                    if (d.label == null || d.label.metaedge == null) {
                        // There is no associated metaedge, thus no text.
                        // This happens for annotation edges.
                        return;
                    }
                    var labelForEdge = getLabelForEdge(d.label.metaedge, sceneElement.renderHierarchy);
                    if (labelForEdge == null) {
                        // We have no information to show on this edge.
                        return;
                    }
                    // Put edge label in the middle of edge only if the edge is thick enough.
                    var baseline = strokeWidth > CENTER_EDGE_LABEL_MIN_STROKE_WIDTH ?
                        'central' :
                        'text-after-edge';
                    edgeGroup.append('text')
                        .append('textPath')
                        .attr('xlink:href', '#' + pathId)
                        .attr('startOffset', '50%')
                        .attr('text-anchor', 'middle')
                        .attr('dominant-baseline', 'central')
                        .text(labelForEdge);
                }
                edge.appendEdge = appendEdge;
                ;
                edge.interpolate = d3.line()
                    .curve(d3.curveBasis)
                    .x(function (d) { return d.x; })
                    .y(function (d) { return d.y; });
                /**
                 * Returns a tween interpolator for the endpoint of an edge path.
                 */
                function getEdgePathInterpolator(d, i, a) {
                    var renderMetaedgeInfo = d.label;
                    var adjoiningMetaedge = renderMetaedgeInfo.adjoiningMetaedge;
                    var points = renderMetaedgeInfo.points;
                    // Adjust the path so that start/end markers point to the end
                    // of the path.
                    if (d.label.startMarkerId) {
                        points = adjustPathPointsForMarker(points, d3.select('#' + d.label.startMarkerId), true);
                    }
                    if (d.label.endMarkerId) {
                        points = adjustPathPointsForMarker(points, d3.select('#' + d.label.endMarkerId), false);
                    }
                    if (!adjoiningMetaedge) {
                        return d3.interpolate(a, edge.interpolate(points));
                    }
                    var renderPath = this;
                    // Get the adjoining path that matches the adjoining metaedge.
                    var adjoiningPath = (adjoiningMetaedge.edgeGroup.node()
                        .firstChild);
                    // Find the desired SVGPoint along the adjoining path, then convert those
                    // coordinates into the space of the renderPath using its Current
                    // Transformation Matrix (CTM).
                    var inbound = renderMetaedgeInfo.metaedge.inbound;
                    return function (t) {
                        var adjoiningPoint = adjoiningPath
                            .getPointAtLength(inbound ? adjoiningPath.getTotalLength() : 0)
                            .matrixTransform(adjoiningPath.getCTM())
                            .matrixTransform(renderPath.getCTM().inverse());
                        // Update the relevant point in the renderMetaedgeInfo's points list, then
                        // re-interpolate the path.
                        var index = inbound ? 0 : points.length - 1;
                        points[index].x = adjoiningPoint.x;
                        points[index].y = adjoiningPoint.y;
                        var dPath = edge.interpolate(points);
                        return dPath;
                    };
                }
                function position(d) {
                    d3.select(this)
                        .select('path.' + scene.Class.Edge.LINE)
                        .transition()
                        .attrTween('d', getEdgePathInterpolator);
                }
                ;
                /**
                 * For a given d3 selection and data object, mark the edge as a control
                 * dependency if it contains only control edges.
                 *
                 * d's label property will be a RenderMetaedgeInfo object.
                 */
                function stylize(edgeGroup, d, stylize) {
                    edgeGroup.classed('faded', d.label.isFadedOut);
                    var metaedge = d.label.metaedge;
                    edgeGroup.select('path.' + scene.Class.Edge.LINE)
                        .classed('control-dep', metaedge && !metaedge.numRegularEdges);
                }
                ;
            })(edge = scene.edge || (scene.edge = {}));
        })(scene = graph_1.scene || (graph_1.scene = {}));
    })(graph = tf.graph || (tf.graph = {}));
})(tf || (tf = {})); // close module
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZWRnZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImVkZ2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7Ozs7Ozs7Z0ZBYWdGO0FBQ2hGLElBQU8sRUFBRSxDQWdhUjtBQWhhRCxXQUFPLEVBQUU7SUFBQyxJQUFBLEtBQUssQ0FnYWQ7SUFoYVMsV0FBQSxPQUFLO1FBQUMsSUFBQSxLQUFLLENBZ2FwQjtRQWhhZSxXQUFBLEtBQUs7WUFBQyxJQUFBLElBQUksQ0FnYXpCO1lBaGFxQixXQUFBLElBQUk7Z0JBRTFCLGtFQUFrRTtnQkFDbEUsSUFBTSxrQkFBa0IsR0FBRyxHQUFHLENBQUM7Z0JBRS9CLDJDQUEyQztnQkFDOUIsbUJBQWMsR0FBRyxJQUFJLENBQUM7Z0JBRW5DLDJDQUEyQztnQkFDOUIsbUJBQWMsR0FBRyxFQUFFLENBQUM7Z0JBRWpDLCtEQUErRDtnQkFDL0QsSUFBTSx5QkFBeUIsR0FBRyxHQUFHLENBQUM7Z0JBRXRDLHlEQUF5RDtnQkFDekQsSUFBTSx1QkFBdUIsR0FBRyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQztnQkFFNUIsZ0NBQTJCLEdBQ3BDLEVBQUUsQ0FBQyxRQUFRLEVBQUU7cUJBQ1IsUUFBUSxDQUFDLHlCQUF5QixDQUFDO3FCQUNuQyxNQUFNLENBQUMsdUJBQXVCLENBQUM7cUJBQy9CLEtBQUssQ0FBQyxDQUFDLEtBQUEsY0FBYyxFQUFFLEtBQUEsY0FBYyxDQUFDLENBQUM7cUJBQ3ZDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFFckIsSUFBSSxZQUFZLEdBQ1osRUFBRSxDQUFDLGFBQWEsRUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUEsY0FBYyxFQUFFLEtBQUEsY0FBYyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7b0JBQ3hFLE9BQU8sRUFBRSxRQUFRLEVBQUUsT0FBTyxFQUFFLFFBQVE7aUJBQ3JDLENBQUMsQ0FBQztnQkFFUCxxRUFBcUU7Z0JBQ3JFLElBQU0sa0NBQWtDLEdBQUcsR0FBRyxDQUFDO2dCQVcvQyxvQkFBMkIsT0FBaUI7b0JBQzFDLE9BQU8sT0FBTyxDQUFDLENBQUMsR0FBRyxRQUFBLGNBQWMsR0FBRyxPQUFPLENBQUMsQ0FBQyxDQUFDO2dCQUNoRCxDQUFDO2dCQUZlLGVBQVUsYUFFekIsQ0FBQTtnQkFFRDs7Ozs7Ozs7Ozs7Ozs7Ozs7O21CQWtCRztnQkFDSCxvQkFBMkIsVUFBVSxFQUNqQyxLQUF1RSxFQUN2RSxZQUFZO29CQUNkLElBQUksS0FBSyxHQUFlLEVBQUUsQ0FBQztvQkFDM0IsS0FBSyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEtBQUssRUFBRSxFQUFFLFVBQUMsS0FBSyxFQUFFLE9BQU87d0JBQzdDLElBQUksU0FBUyxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7d0JBQ3BDLEtBQUssQ0FBQyxJQUFJLENBQUM7NEJBQ1QsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxDQUFDOzRCQUNaLENBQUMsRUFBRSxPQUFPLENBQUMsQ0FBQzs0QkFDWixLQUFLLEVBQUUsU0FBUzt5QkFDakIsQ0FBQyxDQUFDO3dCQUNILE9BQU8sS0FBSyxDQUFDO29CQUNmLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQztvQkFFVixJQUFJLFNBQVMsR0FDVCxLQUFLLENBQUMsbUJBQW1CLENBQUMsVUFBVSxFQUFFLEdBQUcsRUFBRSxNQUFBLEtBQUssQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7b0JBRXJFLDBDQUEwQztvQkFDMUMsaURBQWlEO29CQUNqRCxJQUFJLFVBQVUsR0FBSSxTQUFpQixDQUFDLFNBQVMsQ0FBQyxjQUFZLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFBLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsVUFBVSxDQUFDLENBQUM7b0JBRTVHLHNFQUFzRTtvQkFDdEUsVUFBVSxDQUFDLEtBQUssRUFBRTt5QkFDYixNQUFNLENBQUMsR0FBRyxDQUFDO3lCQUNYLElBQUksQ0FBQyxPQUFPLEVBQUUsTUFBQSxLQUFLLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQzt5QkFDL0IsSUFBSSxDQUFDLFdBQVcsRUFBRSxVQUFVLENBQUM7eUJBQzdCLElBQUksQ0FBQyxVQUFTLENBQVc7d0JBQ3hCLElBQUksU0FBUyxHQUFHLEVBQUUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUM7d0JBQ2hDLENBQUMsQ0FBQyxLQUFLLENBQUMsU0FBUyxHQUFHLFNBQVMsQ0FBQzt3QkFDOUIsMENBQTBDO3dCQUMxQyxZQUFZLENBQUMsZUFBZSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLFNBQVMsQ0FBQzt3QkFFeEQsSUFBSSxZQUFZLENBQUMsa0JBQWtCLEVBQUU7NEJBQ25DLDhFQUE4RTs0QkFDOUUsU0FBUztpQ0FDSixFQUFFLENBQUMsT0FBTyxFQUNQLFVBQUEsQ0FBQztnQ0FDQyxpRUFBaUU7Z0NBQ2pFLGtCQUFrQjtnQ0FDVixFQUFFLENBQUMsS0FBTSxDQUFDLGVBQWUsRUFBRSxDQUFDO2dDQUNwQyxZQUFZLENBQUMsSUFBSSxDQUFDLGFBQWEsRUFBRTtvQ0FDL0IsUUFBUSxFQUFFLENBQUM7b0NBQ1gsU0FBUyxFQUFFLFNBQVM7aUNBQ3JCLENBQUMsQ0FBQzs0QkFDTCxDQUFDLENBQUMsQ0FBQzt5QkFDWjt3QkFFRCxpRUFBaUU7d0JBQ2pFLDRCQUE0Qjt3QkFDNUIsVUFBVSxDQUFDLFNBQVMsRUFBRSxDQUFDLEVBQUUsWUFBWSxDQUFDLENBQUM7b0JBQ3pDLENBQUMsQ0FBQzt5QkFDRCxLQUFLLENBQUMsVUFBVSxDQUFDO3lCQUNqQixJQUFJLENBQUMsUUFBUSxDQUFDO3lCQUNkLElBQUksQ0FBQyxVQUFTLENBQUM7d0JBQ2xCLE9BQU8sQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsRUFBRSxZQUFZLENBQUMsQ0FBQztvQkFDNUMsQ0FBQyxDQUFDLENBQUM7b0JBRUgsVUFBVSxDQUFDLElBQUksRUFBRTt5QkFDZCxJQUFJLENBQUMsVUFBQSxDQUFDO3dCQUNMLE9BQU8sWUFBWSxDQUFDLGVBQWUsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDckQsQ0FBQyxDQUFDO3lCQUNELE1BQU0sRUFBRSxDQUFDO29CQUNaLE9BQU8sVUFBVSxDQUFDO2dCQUNwQixDQUFDO2dCQS9EZSxlQUFVLGFBK0R6QixDQUFBO2dCQUFBLENBQUM7Z0JBRUY7OzttQkFHRztnQkFDSCw2QkFDSSxRQUFrQixFQUFFLFVBQWtDO29CQUN4RCxJQUFJLElBQUksR0FBVyxVQUFVLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDeEQsSUFBSSxJQUFJLENBQUMsWUFBWSxJQUFJLElBQUksSUFBSSxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBRTt3QkFDN0QsT0FBTyxJQUFJLENBQUM7cUJBQ2I7b0JBQ0QsSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsZUFBZSxDQUFDLENBQUM7b0JBQ3hELElBQUksS0FBSyxJQUFJLElBQUksRUFBRTt3QkFDakIsT0FBTyxJQUFJLENBQUM7cUJBQ2I7b0JBQ0QsSUFBSSxLQUFLLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTt3QkFDdEIsT0FBTyxRQUFRLENBQUM7cUJBQ2pCO29CQUNELE9BQU8sS0FBSyxDQUFDLEdBQUcsQ0FBQyxVQUFBLElBQUksSUFBTSxPQUFPLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7eUJBQ3pELElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO2dCQUNoQyxDQUFDO2dCQWZlLHdCQUFtQixzQkFlbEMsQ0FBQTtnQkFFRDs7OzttQkFJRztnQkFDSCx5QkFBZ0MsUUFBa0IsRUFDOUMsVUFBa0M7b0JBQ3BDLElBQUksVUFBVSxDQUFDLGlCQUFpQixFQUFFO3dCQUNoQyx5REFBeUQ7d0JBQ3pELE9BQU8sVUFBVSxDQUFDLGlCQUFpQixDQUFDLFFBQVEsRUFBRSxVQUFVLENBQUMsQ0FBQztxQkFDM0Q7b0JBRUQsMERBQTBEO29CQUMxRCxJQUFJLFdBQVcsR0FBRyxRQUFRLENBQUMsWUFBWSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7b0JBQ25ELE9BQU8sV0FBVyxDQUFDLENBQUM7d0JBQ2hCLFFBQVEsQ0FBQyxZQUFZLENBQUMsTUFBTSxHQUFHLFVBQVUsQ0FBQyxDQUFDO3dCQUMzQyxtQkFBbUIsQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxFQUFFLFVBQVUsQ0FBQyxDQUFDO2dCQUNoRSxDQUFDO2dCQVplLG9CQUFlLGtCQVk5QixDQUFBO2dCQUVEOzs7Ozs7Ozs7OzttQkFXRztnQkFDSCxxQ0FDSSxNQUFzQixFQUN0QixNQUFjLEVBQ2QsUUFBNEM7b0JBQzlDLElBQU0sSUFBSSxHQUFHLFFBQVEsQ0FBQyxlQUFlLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsYUFBYSxFQUFFLE1BQU0sQ0FBQyxDQUFDO29CQUM1RSxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsTUFBTSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTt3QkFDdEMsSUFBSSxDQUFDLFlBQVksQ0FBQyxHQUFHLEVBQUUsUUFBUSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDckQsSUFBSSxJQUFJLENBQUMsY0FBYyxFQUFFLEdBQUcsTUFBTSxFQUFFOzRCQUNsQyxvREFBb0Q7NEJBQ3BELE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQzt5QkFDZDtxQkFDRjtvQkFDRCx3REFBd0Q7b0JBQ3hELE9BQU8sTUFBTSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7Z0JBQzNCLENBQUM7Z0JBRUQ7Ozs7Ozs7OzttQkFTRztnQkFDSCxtQ0FBbUMsTUFBc0IsRUFDckQsTUFBd0MsRUFBRSxPQUFnQjtvQkFDNUQsSUFBSSxRQUFRLEdBQUcsRUFBRSxDQUFDLElBQUksRUFBZ0I7eUJBQ25DLENBQUMsQ0FBQyxVQUFBLENBQUMsSUFBSSxPQUFBLENBQUMsQ0FBQyxDQUFDLEVBQUgsQ0FBRyxDQUFDO3lCQUNYLENBQUMsQ0FBQyxVQUFBLENBQUMsSUFBSSxPQUFBLENBQUMsQ0FBQyxDQUFDLEVBQUgsQ0FBRyxDQUFDLENBQUM7b0JBQ2YsSUFBSSxJQUFJLEdBQ0osRUFBRSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsZUFBZSxDQUFDLDRCQUE0QixFQUFFLE1BQU0sQ0FBQyxDQUFDO3lCQUNwRSxJQUFJLENBQUMsR0FBRyxFQUFFLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO29CQUNyQyxJQUFJLFdBQVcsR0FBRyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUM7b0JBQzlDLElBQUksT0FBTyxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDNUQsSUFBSSxZQUFZLEdBQUcsT0FBTyxDQUFDLENBQUMsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDM0MsSUFBSSxJQUFJLEdBQUcsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUNoQyxJQUFJLFFBQVEsR0FBb0IsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDO29CQUM1QyxJQUFJLE9BQU8sRUFBRTt3QkFDWCwyRUFBMkU7d0JBQzNFLHlCQUF5Qjt3QkFDekIsSUFBTSxtQkFBbUIsR0FBRyxDQUFDLEdBQUcsSUFBSSxHQUFHLFlBQVksQ0FBQzt3QkFDcEQsSUFBTSxRQUFNLEdBQUcsV0FBVyxHQUFHLG1CQUFtQixDQUFDO3dCQUNqRCxJQUFNLEtBQUssR0FBRyxRQUFRLENBQUMsZ0JBQWdCLENBQUMsUUFBTSxDQUFDLENBQUM7d0JBQ2hELHNFQUFzRTt3QkFDdEUsdUJBQXVCO3dCQUN2QixJQUFNLFFBQVEsR0FBRywyQkFBMkIsQ0FBQyxNQUFNLEVBQUUsUUFBTSxFQUFFLFFBQVEsQ0FBQyxDQUFDO3dCQUN2RSxpQ0FBaUM7d0JBQ2pDLE1BQU0sQ0FBQyxRQUFRLEdBQUcsQ0FBQyxDQUFDLEdBQUcsRUFBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUMsRUFBQyxDQUFDO3dCQUNoRCwwQ0FBMEM7d0JBQzFDLE9BQU8sTUFBTSxDQUFDLEtBQUssQ0FBQyxRQUFRLEdBQUcsQ0FBQyxDQUFDLENBQUM7cUJBQ25DO3lCQUFNO3dCQUNMLHlFQUF5RTt3QkFDekUseUJBQXlCO3dCQUN6QixJQUFNLG1CQUFtQixHQUFHLENBQUMsR0FBRyxJQUFJLEdBQUcsWUFBWSxDQUFDO3dCQUNwRCxJQUFNLFFBQU0sR0FDUixRQUFRLENBQUMsY0FBYyxFQUFFLEdBQUcsV0FBVyxHQUFHLG1CQUFtQixDQUFDO3dCQUNsRSxJQUFNLEtBQUssR0FBRyxRQUFRLENBQUMsZ0JBQWdCLENBQUMsUUFBTSxDQUFDLENBQUM7d0JBQ2hELHNFQUFzRTt3QkFDdEUsdUJBQXVCO3dCQUN2QixJQUFNLFFBQVEsR0FBRywyQkFBMkIsQ0FBQyxNQUFNLEVBQUUsUUFBTSxFQUFFLFFBQVEsQ0FBQyxDQUFDO3dCQUN2RSxnQ0FBZ0M7d0JBQ2hDLE1BQU0sQ0FBQyxRQUFRLENBQUMsR0FBRyxFQUFDLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQyxFQUFDLENBQUM7d0JBQzVDLHFDQUFxQzt3QkFDckMsT0FBTyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxRQUFRLEdBQUcsQ0FBQyxDQUFDLENBQUM7cUJBQ3RDO2dCQUNILENBQUM7Z0JBRUQ7Ozs7Ozs7bUJBT0c7Z0JBQ0gsb0JBQTJCLFNBQVMsRUFBRSxDQUFXLEVBQzdDLFlBR0MsRUFDRCxTQUFrQjtvQkFDcEIsU0FBUyxHQUFHLFNBQVMsSUFBSSxNQUFBLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsbUJBQW1CO29CQUU3RCxJQUFJLENBQUMsQ0FBQyxLQUFLLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQyxVQUFVLEVBQUU7d0JBQ2pDLFNBQVMsSUFBSSxHQUFHLEdBQUcsTUFBQSxLQUFLLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQztxQkFDMUM7b0JBQ0QsSUFBSSxDQUFDLENBQUMsS0FBSyxJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUMsUUFBUSxJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLFdBQVcsRUFBRTt3QkFDL0QsU0FBUyxJQUFJLEdBQUcsR0FBRyxNQUFBLEtBQUssQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDO3FCQUM5QztvQkFDRCxJQUFJLFlBQVksQ0FBQyxrQkFBa0IsRUFBRTt3QkFDbkMsK0NBQStDO3dCQUMvQyxTQUFTLElBQUksR0FBRyxHQUFHLE1BQUEsS0FBSyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUM7cUJBQzFDO29CQUNELHdEQUF3RDtvQkFDeEQsMENBQTBDO29CQUMxQyxJQUFJLE1BQU0sR0FBRyxPQUFPLEdBQUcsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUVyQyxJQUFJLFdBQVcsQ0FBQztvQkFDaEIsSUFBSSxZQUFZLENBQUMsZUFBZSxDQUFDLGlCQUFpQixFQUFFO3dCQUNsRCw2REFBNkQ7d0JBQzdELFdBQVcsR0FBRyxZQUFZLENBQUMsZUFBZSxDQUFDLGlCQUFpQixDQUFDLENBQUMsRUFBRSxTQUFTLENBQUMsQ0FBQztxQkFDNUU7eUJBQU07d0JBQ0wsNENBQTRDO3dCQUM1QyxJQUFJLElBQUksR0FBRyxDQUFDLENBQUM7d0JBQ2IsSUFBSSxDQUFDLENBQUMsS0FBSyxJQUFJLElBQUksSUFBSSxDQUFDLENBQUMsS0FBSyxDQUFDLFFBQVEsSUFBSSxJQUFJLEVBQUU7NEJBQy9DLG1DQUFtQzs0QkFDbkMsSUFBSSxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQzt5QkFDbkM7d0JBQ0QsV0FBVyxHQUFHLFlBQVksQ0FBQyxlQUFlLENBQUMsd0JBQXdCLENBQUMsSUFBSSxDQUFDLENBQUM7cUJBQzNFO29CQUVELElBQUksSUFBSSxHQUFHLFNBQVMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO3lCQUNuQixJQUFJLENBQUMsSUFBSSxFQUFFLE1BQU0sQ0FBQzt5QkFDbEIsSUFBSSxDQUFDLE9BQU8sRUFBRSxTQUFTLENBQUM7eUJBQ3hCLEtBQUssQ0FBQyxjQUFjLEVBQUUsV0FBVyxHQUFHLElBQUksQ0FBQyxDQUFDO29CQUUxRCw2RUFBNkU7b0JBQzdFLElBQUksQ0FBQyxDQUFDLEtBQUssSUFBSSxDQUFDLENBQUMsS0FBSyxDQUFDLFFBQVEsRUFBRTt3QkFDL0IsSUFBSSxDQUFDLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxXQUFXLEVBQUU7NEJBQ2hDLDRCQUE0Qjs0QkFDNUIsSUFBTSxRQUFRLEdBQUcseUJBQXVCLFlBQVksQ0FBQyxXQUFXLENBQUcsQ0FBQzs0QkFDcEUsSUFBSSxDQUFDLEtBQUssQ0FBQyxjQUFjLEVBQUUsVUFBUSxRQUFRLE1BQUcsQ0FBQyxDQUFDOzRCQUNoRCxDQUFDLENBQUMsS0FBSyxDQUFDLGFBQWEsR0FBRyxRQUFRLENBQUM7eUJBQ2xDOzZCQUFNOzRCQUNMLDJCQUEyQjs0QkFDM0IsSUFBTSxRQUFRLEdBQUcsd0JBQXNCLFlBQVksQ0FBQyxXQUFXLENBQUcsQ0FBQzs0QkFDbkUsSUFBSSxDQUFDLEtBQUssQ0FBQyxZQUFZLEVBQUUsVUFBUSxRQUFRLE1BQUcsQ0FBQyxDQUFDOzRCQUM5QyxDQUFDLENBQUMsS0FBSyxDQUFDLFdBQVcsR0FBRyxRQUFRLENBQUM7eUJBQ2hDO3FCQUNGO29CQUVELElBQUksQ0FBQyxDQUFDLEtBQUssSUFBSSxJQUFJLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQyxRQUFRLElBQUksSUFBSSxFQUFFO3dCQUMvQyxpREFBaUQ7d0JBQ2pELHFDQUFxQzt3QkFDckMsT0FBTztxQkFDUjtvQkFDRCxJQUFJLFlBQVksR0FBRyxlQUFlLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxRQUFRLEVBQy9DLFlBQVksQ0FBQyxlQUFlLENBQUMsQ0FBQztvQkFDbEMsSUFBSSxZQUFZLElBQUksSUFBSSxFQUFFO3dCQUN4QiwrQ0FBK0M7d0JBQy9DLE9BQU87cUJBQ1I7b0JBRUQseUVBQXlFO29CQUN6RSxJQUFJLFFBQVEsR0FBRyxXQUFXLEdBQUcsa0NBQWtDLENBQUMsQ0FBQzt3QkFDN0QsU0FBUyxDQUFDLENBQUM7d0JBQ1gsaUJBQWlCLENBQUM7b0JBRXRCLFNBQVMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO3lCQUNuQixNQUFNLENBQUMsVUFBVSxDQUFDO3lCQUNoQixJQUFJLENBQUMsWUFBWSxFQUFFLEdBQUcsR0FBRyxNQUFNLENBQUM7eUJBQ2hDLElBQUksQ0FBQyxhQUFhLEVBQUUsS0FBSyxDQUFDO3lCQUMxQixJQUFJLENBQUMsYUFBYSxFQUFFLFFBQVEsQ0FBQzt5QkFDN0IsSUFBSSxDQUFDLG1CQUFtQixFQUFFLFNBQVMsQ0FBQzt5QkFDdEMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDO2dCQUMxQixDQUFDO2dCQWhGZSxlQUFVLGFBZ0Z6QixDQUFBO2dCQUFBLENBQUM7Z0JBRVMsZ0JBQVcsR0FBb0MsRUFBRSxDQUFDLElBQUksRUFBMEI7cUJBQzdELEtBQUssQ0FBQyxFQUFFLENBQUMsVUFBVSxDQUFDO3FCQUNwQixDQUFDLENBQUMsVUFBQyxDQUFDLElBQU8sT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUEsQ0FBQyxDQUFDO3FCQUN4QixDQUFDLENBQUMsVUFBQyxDQUFDLElBQU8sT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUEsQ0FBQyxDQUFDLENBQUM7Z0JBRXZEOzttQkFFRztnQkFDSCxpQ0FBaUMsQ0FBVyxFQUFFLENBQVMsRUFBRSxDQUFTO29CQUNoRSxJQUFJLGtCQUFrQixHQUErQixDQUFDLENBQUMsS0FBSyxDQUFDO29CQUM3RCxJQUFJLGlCQUFpQixHQUFHLGtCQUFrQixDQUFDLGlCQUFpQixDQUFDO29CQUM3RCxJQUFJLE1BQU0sR0FBRyxrQkFBa0IsQ0FBQyxNQUFNLENBQUM7b0JBRXZDLDZEQUE2RDtvQkFDN0QsZUFBZTtvQkFDZixJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUMsYUFBYSxFQUFFO3dCQUN6QixNQUFNLEdBQUcseUJBQXlCLENBQzlCLE1BQU0sRUFBRSxFQUFFLENBQUMsTUFBTSxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLGFBQWEsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDO3FCQUMzRDtvQkFDRCxJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUMsV0FBVyxFQUFFO3dCQUN2QixNQUFNLEdBQUcseUJBQXlCLENBQzlCLE1BQU0sRUFBRSxFQUFFLENBQUMsTUFBTSxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDO3FCQUMxRDtvQkFFRCxJQUFJLENBQUMsaUJBQWlCLEVBQUU7d0JBQ3RCLE9BQU8sRUFBRSxDQUFDLFdBQVcsQ0FBQyxDQUFDLEVBQUUsS0FBQSxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztxQkFDL0M7b0JBRUQsSUFBSSxVQUFVLEdBQUcsSUFBSSxDQUFDO29CQUV0Qiw4REFBOEQ7b0JBQzlELElBQUksYUFBYSxHQUNDLENBQWUsaUJBQWlCLENBQUMsU0FBUyxDQUFDLElBQUksRUFBRzt5QkFDL0QsVUFBVSxDQUFDLENBQUM7b0JBRWpCLHlFQUF5RTtvQkFDekUsaUVBQWlFO29CQUNqRSwrQkFBK0I7b0JBQy9CLElBQUksT0FBTyxHQUFHLGtCQUFrQixDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUM7b0JBRWxELE9BQU8sVUFBUyxDQUFDO3dCQUNmLElBQUksY0FBYyxHQUFHLGFBQWE7NkJBQy9CLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLGNBQWMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7NkJBQzlELGVBQWUsQ0FBQyxhQUFhLENBQUMsTUFBTSxFQUFFLENBQUM7NkJBQ3ZDLGVBQWUsQ0FBQyxVQUFVLENBQUMsTUFBTSxFQUFFLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQzt3QkFFbEQsMEVBQTBFO3dCQUMxRSwyQkFBMkI7d0JBQzNCLElBQUksS0FBSyxHQUFHLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQzt3QkFDNUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxjQUFjLENBQUMsQ0FBQyxDQUFDO3dCQUNuQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLGNBQWMsQ0FBQyxDQUFDLENBQUM7d0JBQ25DLElBQUksS0FBSyxHQUFHLEtBQUEsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFDO3dCQUNoQyxPQUFPLEtBQUssQ0FBQztvQkFDZixDQUFDLENBQUM7Z0JBQ0osQ0FBQztnQkFFRCxrQkFBa0IsQ0FBQztvQkFDakIsRUFBRSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUM7eUJBQ1YsTUFBTSxDQUFDLE9BQU8sR0FBRyxNQUFBLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO3lCQUNqQyxVQUFVLEVBQUU7eUJBQ1osU0FBUyxDQUFDLEdBQUcsRUFBRSx1QkFBOEIsQ0FBQyxDQUFDO2dCQUN0RCxDQUFDO2dCQUFBLENBQUM7Z0JBRUY7Ozs7O21CQUtHO2dCQUNILGlCQUFpQixTQUFTLEVBQUUsQ0FBVyxFQUFFLE9BQU87b0JBQzlDLFNBQVMsQ0FBQyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLENBQUM7b0JBQy9DLElBQUksUUFBUSxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDO29CQUNoQyxTQUFTLENBQUMsTUFBTSxDQUFDLE9BQU8sR0FBRyxNQUFBLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO3lCQUN0QyxPQUFPLENBQUMsYUFBYSxFQUFFLFFBQVEsSUFBSSxDQUFDLFFBQVEsQ0FBQyxlQUFlLENBQUMsQ0FBQztnQkFDckUsQ0FBQztnQkFBQSxDQUFDO1lBRUYsQ0FBQyxFQWhhcUIsSUFBSSxHQUFKLFVBQUksS0FBSixVQUFJLFFBZ2F6QjtRQUFELENBQUMsRUFoYWUsS0FBSyxHQUFMLGFBQUssS0FBTCxhQUFLLFFBZ2FwQjtJQUFELENBQUMsRUFoYVMsS0FBSyxHQUFMLFFBQUssS0FBTCxRQUFLLFFBZ2FkO0FBQUQsQ0FBQyxFQWhhTSxFQUFFLEtBQUYsRUFBRSxRQWdhUixDQUFDLGVBQWUiLCJzb3VyY2VzQ29udGVudCI6WyIvKiBDb3B5cmlnaHQgMjAxNSBUaGUgVGVuc29yRmxvdyBBdXRob3JzLiBBbGwgUmlnaHRzIFJlc2VydmVkLlxuXG5MaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UsIFZlcnNpb24gMi4wICh0aGUgJ0xpY2Vuc2UnKTtcbnlvdSBtYXkgbm90IHVzZSB0aGlzIGZpbGUgZXhjZXB0IGluIGNvbXBsaWFuY2Ugd2l0aCB0aGUgTGljZW5zZS5cbllvdSBtYXkgb2J0YWluIGEgY29weSBvZiB0aGUgTGljZW5zZSBhdFxuXG4gICAgaHR0cDovL3d3dy5hcGFjaGUub3JnL2xpY2Vuc2VzL0xJQ0VOU0UtMi4wXG5cblVubGVzcyByZXF1aXJlZCBieSBhcHBsaWNhYmxlIGxhdyBvciBhZ3JlZWQgdG8gaW4gd3JpdGluZywgc29mdHdhcmVcbmRpc3RyaWJ1dGVkIHVuZGVyIHRoZSBMaWNlbnNlIGlzIGRpc3RyaWJ1dGVkIG9uIGFuICdBUyBJUycgQkFTSVMsXG5XSVRIT1VUIFdBUlJBTlRJRVMgT1IgQ09ORElUSU9OUyBPRiBBTlkgS0lORCwgZWl0aGVyIGV4cHJlc3Mgb3IgaW1wbGllZC5cblNlZSB0aGUgTGljZW5zZSBmb3IgdGhlIHNwZWNpZmljIGxhbmd1YWdlIGdvdmVybmluZyBwZXJtaXNzaW9ucyBhbmRcbmxpbWl0YXRpb25zIHVuZGVyIHRoZSBMaWNlbnNlLlxuPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09Ki9cbm1vZHVsZSB0Zi5ncmFwaC5zY2VuZS5lZGdlIHtcblxuLyoqIERlbGltaXRlciBiZXR3ZWVuIGRpbWVuc2lvbnMgd2hlbiBzaG93aW5nIHNpemVzIG9mIHRlbnNvcnMuICovXG5jb25zdCBURU5TT1JfU0hBUEVfREVMSU0gPSAnw5cnO1xuXG4vKiogVGhlIG1pbmltdW0gc3Ryb2tlIHdpZHRoIG9mIGFuIGVkZ2UuICovXG5leHBvcnQgY29uc3QgTUlOX0VER0VfV0lEVEggPSAwLjc1O1xuXG4vKiogVGhlIG1heGltdW0gc3Ryb2tlIHdpZHRoIG9mIGFuIGVkZ2UuICovXG5leHBvcnQgY29uc3QgTUFYX0VER0VfV0lEVEggPSAxMjtcblxuLyoqIFRoZSBleHBvbmVudCB1c2VkIGluIHRoZSBwb3dlciBzY2FsZSBmb3IgZWRnZSB0aGlja25lc3MuICovXG5jb25zdCBFREdFX1dJRFRIX1NDQUxFX0VYUE9ORU5UID0gMC4zO1xuXG4vKiogVGhlIGRvbWFpbiAobWluIGFuZCBtYXggdmFsdWUpIGZvciB0aGUgZWRnZSB3aWR0aC4gKi9cbmNvbnN0IERPTUFJTl9FREdFX1dJRFRIX1NDQUxFID0gWzEsIDVFNl07XG5cbmV4cG9ydCBjb25zdCBFREdFX1dJRFRIX1NJWkVfQkFTRURfU0NBTEU6IGQzLlNjYWxlUG93ZXI8bnVtYmVyLCBudW1iZXI+ID1cbiAgICBkMy5zY2FsZVBvdygpXG4gICAgICAgIC5leHBvbmVudChFREdFX1dJRFRIX1NDQUxFX0VYUE9ORU5UKVxuICAgICAgICAuZG9tYWluKERPTUFJTl9FREdFX1dJRFRIX1NDQUxFKVxuICAgICAgICAucmFuZ2UoW01JTl9FREdFX1dJRFRILCBNQVhfRURHRV9XSURUSF0pXG4gICAgICAgIC5jbGFtcCh0cnVlKTtcblxubGV0IGFycm93aGVhZE1hcCA9XG4gICAgZDMuc2NhbGVRdWFudGl6ZTxTdHJpbmc+KCkuZG9tYWluKFtNSU5fRURHRV9XSURUSCwgTUFYX0VER0VfV0lEVEhdKS5yYW5nZShbXG4gICAgICAnc21hbGwnLCAnbWVkaXVtJywgJ2xhcmdlJywgJ3hsYXJnZSdcbiAgICBdKTtcblxuLyoqIE1pbmltdW0gc3Ryb2tlIHdpZHRoIHRvIHB1dCBlZGdlIGxhYmVscyBpbiB0aGUgbWlkZGxlIG9mIGVkZ2VzICovXG5jb25zdCBDRU5URVJfRURHRV9MQUJFTF9NSU5fU1RST0tFX1dJRFRIID0gMi41O1xuXG5leHBvcnQgdHlwZSBFZGdlRGF0YSA9IHt2OiBzdHJpbmcsIHc6IHN0cmluZywgbGFiZWw6IHJlbmRlci5SZW5kZXJNZXRhZWRnZUluZm99O1xuXG4vKipcbiAqIEZ1bmN0aW9uIHJ1biB3aGVuIGFuIGVkZ2UgaXMgc2VsZWN0ZWQuXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgRWRnZVNlbGVjdGlvbkNhbGxiYWNrIHtcbiAgKGVkZ2VEYXRhOiBzY2VuZS5lZGdlLkVkZ2VEYXRhKTogdm9pZDtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGdldEVkZ2VLZXkoZWRnZU9iajogRWRnZURhdGEpIHtcbiAgcmV0dXJuIGVkZ2VPYmoudiArIEVER0VfS0VZX0RFTElNICsgZWRnZU9iai53O1xufVxuXG4vKipcbiAqIFNlbGVjdCBvciBDcmVhdGUgYSAnZy5lZGdlcycgZ3JvdXAgdG8gYSBnaXZlbiBzY2VuZUdyb3VwXG4gKiBhbmQgYnVpbGRzIGEgbnVtYmVyIG9mICdnLmVkZ2UnIGdyb3VwcyBpbnNpZGUgdGhlIGdyb3VwLlxuICpcbiAqIFN0cnVjdHVyZSBQYXR0ZXJuOlxuICpcbiAqIDxnIGNsYXNzPSdlZGdlcyc+XG4gKiAgIDxnIGNsYXNzPSdlZGdlJz5cbiAqICAgICA8cGF0aCBjbGFzcz0nZWRnZWxpbmUnLz5cbiAqICAgPC9nPlxuICogICAuLi5cbiAqIDwvZz5cbiAqXG4gKlxuICogQHBhcmFtIHNjZW5lR3JvdXAgY29udGFpbmVyXG4gKiBAcGFyYW0gZ3JhcGhcbiAqIEBwYXJhbSBzY2VuZUVsZW1lbnQgPHRmLWdyYXBoLXNjZW5lPiBwb2x5bWVyIGVsZW1lbnQuXG4gKiBAcmV0dXJuIHNlbGVjdGlvbiBvZiB0aGUgY3JlYXRlZCBub2RlR3JvdXBzXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBidWlsZEdyb3VwKHNjZW5lR3JvdXAsXG4gICAgZ3JhcGg6IGdyYXBobGliLkdyYXBoPHJlbmRlci5SZW5kZXJOb2RlSW5mbywgcmVuZGVyLlJlbmRlck1ldGFlZGdlSW5mbz4sXG4gICAgc2NlbmVFbGVtZW50KSB7XG4gIGxldCBlZGdlczogRWRnZURhdGFbXSA9IFtdO1xuICBlZGdlcyA9IF8ucmVkdWNlKGdyYXBoLmVkZ2VzKCksIChlZGdlcywgZWRnZU9iaikgPT4ge1xuICAgIGxldCBlZGdlTGFiZWwgPSBncmFwaC5lZGdlKGVkZ2VPYmopO1xuICAgIGVkZ2VzLnB1c2goe1xuICAgICAgdjogZWRnZU9iai52LFxuICAgICAgdzogZWRnZU9iai53LFxuICAgICAgbGFiZWw6IGVkZ2VMYWJlbFxuICAgIH0pO1xuICAgIHJldHVybiBlZGdlcztcbiAgfSwgZWRnZXMpO1xuXG4gIGxldCBjb250YWluZXIgPVxuICAgICAgc2NlbmUuc2VsZWN0T3JDcmVhdGVDaGlsZChzY2VuZUdyb3VwLCAnZycsIENsYXNzLkVkZ2UuQ09OVEFJTkVSKTtcblxuICAvLyBTZWxlY3QgYWxsIGNoaWxkcmVuIGFuZCBqb2luIHdpdGggZGF0YS5cbiAgLy8gKE5vdGUgdGhhdCBhbGwgY2hpbGRyZW4gb2YgZy5lZGdlcyBhcmUgZy5lZGdlKVxuICBsZXQgZWRnZUdyb3VwcyA9IChjb250YWluZXIgYXMgYW55KS5zZWxlY3RBbGwoZnVuY3Rpb24oKSB7cmV0dXJuIHRoaXMuY2hpbGROb2Rlczt9KS5kYXRhKGVkZ2VzLCBnZXRFZGdlS2V5KTtcblxuICAvLyBNYWtlIGVkZ2VzIGEgZ3JvdXAgdG8gc3VwcG9ydCByZW5kZXJpbmcgbXVsdGlwbGUgbGluZXMgZm9yIG1ldGFlZGdlXG4gIGVkZ2VHcm91cHMuZW50ZXIoKVxuICAgICAgLmFwcGVuZCgnZycpXG4gICAgICAuYXR0cignY2xhc3MnLCBDbGFzcy5FZGdlLkdST1VQKVxuICAgICAgLmF0dHIoJ2RhdGEtZWRnZScsIGdldEVkZ2VLZXkpXG4gICAgICAuZWFjaChmdW5jdGlvbihkOiBFZGdlRGF0YSkge1xuICAgICAgICBsZXQgZWRnZUdyb3VwID0gZDMuc2VsZWN0KHRoaXMpO1xuICAgICAgICBkLmxhYmVsLmVkZ2VHcm91cCA9IGVkZ2VHcm91cDtcbiAgICAgICAgLy8gaW5kZXggbm9kZSBncm91cCBmb3IgcXVpY2sgaGlnaGxpZ2h0aW5nXG4gICAgICAgIHNjZW5lRWxlbWVudC5fZWRnZUdyb3VwSW5kZXhbZ2V0RWRnZUtleShkKV0gPSBlZGdlR3JvdXA7XG5cbiAgICAgICAgaWYgKHNjZW5lRWxlbWVudC5oYW5kbGVFZGdlU2VsZWN0ZWQpIHtcbiAgICAgICAgICAvLyBUaGUgdXNlciBvciBzb21lIGhpZ2hlci1sZXZlbCBjb21wb25lbnQgaGFzIG9wdGVkIHRvIG1ha2UgZWRnZXMgc2VsZWN0YWJsZS5cbiAgICAgICAgICBlZGdlR3JvdXBcbiAgICAgICAgICAgICAgLm9uKCdjbGljaycsXG4gICAgICAgICAgICAgICAgICBkID0+IHtcbiAgICAgICAgICAgICAgICAgICAgLy8gU3RvcCB0aGlzIGV2ZW50J3MgcHJvcGFnYXRpb24gc28gdGhhdCBpdCBpc24ndCBhbHNvIGNvbnNpZGVyZWRcbiAgICAgICAgICAgICAgICAgICAgLy8gYSBncmFwaC1zZWxlY3QuXG4gICAgICAgICAgICAgICAgICAgICg8RXZlbnQ+ZDMuZXZlbnQpLnN0b3BQcm9wYWdhdGlvbigpO1xuICAgICAgICAgICAgICAgICAgICBzY2VuZUVsZW1lbnQuZmlyZSgnZWRnZS1zZWxlY3QnLCB7XG4gICAgICAgICAgICAgICAgICAgICAgZWRnZURhdGE6IGQsXG4gICAgICAgICAgICAgICAgICAgICAgZWRnZUdyb3VwOiBlZGdlR3JvdXBcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIEFkZCBsaW5lIGR1cmluZyBlbnRlciBiZWNhdXNlIHdlJ3JlIGFzc3VtaW5nIHRoYXQgdHlwZSBvZiBsaW5lXG4gICAgICAgIC8vIG5vcm1hbGx5IGRvZXMgbm90IGNoYW5nZS5cbiAgICAgICAgYXBwZW5kRWRnZShlZGdlR3JvdXAsIGQsIHNjZW5lRWxlbWVudCk7XG4gICAgICB9KVxuICAgICAgLm1lcmdlKGVkZ2VHcm91cHMpXG4gICAgICAuZWFjaChwb3NpdGlvbilcbiAgICAgIC5lYWNoKGZ1bmN0aW9uKGQpIHtcbiAgICBzdHlsaXplKGQzLnNlbGVjdCh0aGlzKSwgZCwgc2NlbmVFbGVtZW50KTtcbiAgfSk7XG5cbiAgZWRnZUdyb3Vwcy5leGl0KClcbiAgICAuZWFjaChkID0+IHtcbiAgICAgIGRlbGV0ZSBzY2VuZUVsZW1lbnQuX2VkZ2VHcm91cEluZGV4W2dldEVkZ2VLZXkoZCldO1xuICAgIH0pXG4gICAgLnJlbW92ZSgpO1xuICByZXR1cm4gZWRnZUdyb3Vwcztcbn07XG5cbi8qKlxuICogUmV0dXJucyB0aGUgbGFiZWwgZm9yIHRoZSBnaXZlbiBiYXNlIGVkZ2UuXG4gKiBUaGUgbGFiZWwgaXMgdGhlIHNoYXBlIG9mIHRoZSB1bmRlcmx5aW5nIHRlbnNvci5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdldExhYmVsRm9yQmFzZUVkZ2UoXG4gICAgYmFzZUVkZ2U6IEJhc2VFZGdlLCByZW5kZXJJbmZvOiByZW5kZXIuUmVuZGVyR3JhcGhJbmZvKTogc3RyaW5nIHtcbiAgbGV0IG5vZGUgPSA8T3BOb2RlPnJlbmRlckluZm8uZ2V0Tm9kZUJ5TmFtZShiYXNlRWRnZS52KTtcbiAgaWYgKG5vZGUub3V0cHV0U2hhcGVzID09IG51bGwgfHwgXy5pc0VtcHR5KG5vZGUub3V0cHV0U2hhcGVzKSkge1xuICAgIHJldHVybiBudWxsO1xuICB9XG4gIGxldCBzaGFwZSA9IG5vZGUub3V0cHV0U2hhcGVzW2Jhc2VFZGdlLm91dHB1dFRlbnNvcktleV07XG4gIGlmIChzaGFwZSA9PSBudWxsKSB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbiAgaWYgKHNoYXBlLmxlbmd0aCA9PT0gMCkge1xuICAgIHJldHVybiAnc2NhbGFyJztcbiAgfVxuICByZXR1cm4gc2hhcGUubWFwKHNpemUgPT4geyByZXR1cm4gc2l6ZSA9PT0gLTEgPyAnPycgOiBzaXplOyB9KVxuICAgICAgLmpvaW4oVEVOU09SX1NIQVBFX0RFTElNKTtcbn1cblxuLyoqXG4gKiBDcmVhdGVzIHRoZSBsYWJlbCBmb3IgdGhlIGdpdmVuIG1ldGFlZGdlLiBJZiB0aGUgbWV0YWVkZ2UgY29uc2lzdHNcbiAqIG9mIG9ubHkgMSB0ZW5zb3IsIGFuZCBpdCdzIHNoYXBlIGlzIGtub3duLCB0aGUgbGFiZWwgd2lsbCBjb250YWluIHRoYXRcbiAqIHNoYXBlLiBPdGhlcndpc2UsIHRoZSBsYWJlbCB3aWxsIHNheSB0aGUgbnVtYmVyIG9mIHRlbnNvcnMgaW4gdGhlIG1ldGFlZGdlLlxuICovXG5leHBvcnQgZnVuY3Rpb24gZ2V0TGFiZWxGb3JFZGdlKG1ldGFlZGdlOiBNZXRhZWRnZSxcbiAgICByZW5kZXJJbmZvOiByZW5kZXIuUmVuZGVyR3JhcGhJbmZvKTogc3RyaW5nIHtcbiAgaWYgKHJlbmRlckluZm8uZWRnZUxhYmVsRnVuY3Rpb24pIHtcbiAgICAvLyBUaGUgdXNlciBoYXMgc3BlY2lmaWVkIGEgbWVhbnMgb2YgY29tcHV0aW5nIHRoZSBsYWJlbC5cbiAgICByZXR1cm4gcmVuZGVySW5mby5lZGdlTGFiZWxGdW5jdGlvbihtZXRhZWRnZSwgcmVuZGVySW5mbyk7XG4gIH1cblxuICAvLyBDb21wdXRlIHRoZSBsYWJlbCBiYXNlZCBvbiBlaXRoZXIgdGVuc29yIGNvdW50IG9yIHNpemUuXG4gIGxldCBpc011bHRpRWRnZSA9IG1ldGFlZGdlLmJhc2VFZGdlTGlzdC5sZW5ndGggPiAxO1xuICByZXR1cm4gaXNNdWx0aUVkZ2UgP1xuICAgICAgbWV0YWVkZ2UuYmFzZUVkZ2VMaXN0Lmxlbmd0aCArICcgdGVuc29ycycgOlxuICAgICAgZ2V0TGFiZWxGb3JCYXNlRWRnZShtZXRhZWRnZS5iYXNlRWRnZUxpc3RbMF0sIHJlbmRlckluZm8pO1xufVxuXG4vKipcbiAqIENvbXB1dGVzIHRoZSBpbmRleCBpbnRvIGEgc2V0IG9mIHBvaW50cyB0aGF0IGNvbnN0aXR1dGUgYSBwYXRoIGZvciB3aGljaCB0aGVcbiAqIGRpc3RhbmNlIGFsb25nIHRoZSBwYXRoIGZyb20gdGhlIGluaXRpYWwgcG9pbnQgaXMgYXMgbGFyZ2UgYXMgcG9zc2libGVcbiAqIHdpdGhvdXQgZXhjZWVkaW5nIHRoZSBsZW5ndGguIFRoaXMgZnVuY3Rpb24gd2FzIGludHJvZHVjZWQgYWZ0ZXIgdGhlXG4gKiBuYXRpdmUgZ2V0UGF0aFNlZ0F0TGVuZ3RoIG1ldGhvZCBnb3QgZGVwcmVjYXRlZCBieSBTVkcgMi5cbiAqIEBwYXJhbSBwb2ludHMgQXJyYXkgb2YgcGF0aCBjb250cm9sIHBvaW50cy4gQSBwb2ludCBoYXMgeCBhbmQgeSBwcm9wZXJ0aWVzLlxuICogICBNdXN0IGJlIG9mIGxlbmd0aCBhdCBsZWFzdCAyLlxuICogQHBhcmFtIGxlbmd0aCBUaGUgbGVuZ3RoIChmbG9hdCkuXG4gKiBAcGFyYW0gbGluZUZ1bmMgQSBmdW5jdGlvbiB0aGF0IHRha2VzIHBvaW50cyBhbmQgcmV0dXJucyB0aGUgXCJkXCIgYXR0cmlidXRlXG4gKiAgIG9mIGEgcGF0aCBtYWRlIGZyb20gY29ubmVjdGluZyB0aGUgcG9pbnRzLlxuICogQHJldHVybiBUaGUgaW5kZXggaW50byB0aGUgcG9pbnRzIGFycmF5LlxuICovXG5mdW5jdGlvbiBnZXRQYXRoU2VnbWVudEluZGV4QXRMZW5ndGgoXG4gICAgcG9pbnRzOiByZW5kZXIuUG9pbnRbXSxcbiAgICBsZW5ndGg6IG51bWJlcixcbiAgICBsaW5lRnVuYzogKHBvaW50czogcmVuZGVyLlBvaW50W10pID0+IHN0cmluZyk6IG51bWJlciB7XG4gIGNvbnN0IHBhdGggPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50TlModGYuZ3JhcGguc2NlbmUuU1ZHX05BTUVTUEFDRSwgJ3BhdGgnKTtcbiAgZm9yIChsZXQgaSA9IDE7IGkgPCBwb2ludHMubGVuZ3RoOyBpKyspIHtcbiAgICBwYXRoLnNldEF0dHJpYnV0ZShcImRcIiwgbGluZUZ1bmMocG9pbnRzLnNsaWNlKDAsIGkpKSk7XG4gICAgaWYgKHBhdGguZ2V0VG90YWxMZW5ndGgoKSA+IGxlbmd0aCkge1xuICAgICAgLy8gVGhpcyBtYW55IHBvaW50cyBoYXMgYWxyZWFkeSBleGNlZWRlZCB0aGUgbGVuZ3RoLlxuICAgICAgcmV0dXJuIGkgLSAxO1xuICAgIH1cbiAgfVxuICAvLyBUaGUgZW50aXJlIHBhdGggaXMgc2hvcnRlciB0aGFuIHRoZSBzcGVjaWZpZWQgbGVuZ3RoLlxuICByZXR1cm4gcG9pbnRzLmxlbmd0aCAtIDE7XG59XG5cbi8qKlxuICogU2hvcnRlbnMgdGhlIHBhdGggZW5vdWdodCBzdWNoIHRoYXQgdGhlIHRpcCBvZiB0aGUgc3RhcnQvZW5kIG1hcmtlciB3aWxsXG4gKiBwb2ludCB0byB0aGUgc3RhcnQvZW5kIG9mIHRoZSBwYXRoLiBUaGUgbWFya2VyIGNhbiBiZSBvZiBhcmJpdHJhcnkgc2l6ZS5cbiAqXG4gKiBAcGFyYW0gcG9pbnRzIEFycmF5IG9mIHBhdGggY29udHJvbCBwb2ludHMuXG4gKiBAcGFyYW0gbWFya2VyIEQzIHNlbGVjdGlvbiBvZiB0aGUgPG1hcmtlcj4gc3ZnIGVsZW1lbnQuXG4gKiBAcGFyYW0gaXNTdGFydCBJcyB0aGUgbWFya2VyIGEgYHN0YXJ0LW1hcmtlcmAuIElmIGZhbHNlLCB0aGUgbWFya2VyIGlzXG4gKiAgICAgYW4gYGVuZC1tYXJrZXJgLlxuICogQHJldHVybiBUaGUgbmV3IGFycmF5IG9mIGNvbnRyb2wgcG9pbnRzLlxuICovXG5mdW5jdGlvbiBhZGp1c3RQYXRoUG9pbnRzRm9yTWFya2VyKHBvaW50czogcmVuZGVyLlBvaW50W10sXG4gICAgbWFya2VyOiBkMy5TZWxlY3Rpb248YW55LCBhbnksIGFueSwgYW55PiwgaXNTdGFydDogYm9vbGVhbik6IHJlbmRlci5Qb2ludFtdIHtcbiAgbGV0IGxpbmVGdW5jID0gZDMubGluZTxyZW5kZXIuUG9pbnQ+KClcbiAgICAueChkID0+IGQueClcbiAgICAueShkID0+IGQueSk7XG4gIGxldCBwYXRoID1cbiAgICAgIGQzLnNlbGVjdChkb2N1bWVudC5jcmVhdGVFbGVtZW50TlMoJ2h0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnJywgJ3BhdGgnKSlcbiAgICAgICAgICAuYXR0cignZCcsIGxpbmVGdW5jKHBvaW50cykpO1xuICBsZXQgbWFya2VyV2lkdGggPSArbWFya2VyLmF0dHIoJ21hcmtlcldpZHRoJyk7XG4gIGxldCB2aWV3Qm94ID0gbWFya2VyLmF0dHIoJ3ZpZXdCb3gnKS5zcGxpdCgnICcpLm1hcChOdW1iZXIpO1xuICBsZXQgdmlld0JveFdpZHRoID0gdmlld0JveFsyXSAtIHZpZXdCb3hbMF07XG4gIGxldCByZWZYID0gK21hcmtlci5hdHRyKCdyZWZYJyk7XG4gIGxldCBwYXRoTm9kZSA9IDxTVkdQYXRoRWxlbWVudD4gcGF0aC5ub2RlKCk7XG4gIGlmIChpc1N0YXJ0KSB7XG4gICAgLy8gVGhlIGVkZ2UgZmxvd3MgZG93bndhcmRzLiBEbyBub3QgbWFrZSB0aGUgZWRnZSBnbyB0aGUgd2hvbGUgd2F5LCBsZXN0IHdlXG4gICAgLy8gY2xvYmJlciB0aGUgYXJyb3doZWFkLlxuICAgIGNvbnN0IGZyYWN0aW9uU3RpY2tpbmdPdXQgPSAxIC0gcmVmWCAvIHZpZXdCb3hXaWR0aDtcbiAgICBjb25zdCBsZW5ndGggPSBtYXJrZXJXaWR0aCAqIGZyYWN0aW9uU3RpY2tpbmdPdXQ7XG4gICAgY29uc3QgcG9pbnQgPSBwYXRoTm9kZS5nZXRQb2ludEF0TGVuZ3RoKGxlbmd0aCk7XG4gICAgLy8gRmlndXJlIG91dCBob3cgbWFueSBzZWdtZW50cyBvZiB0aGUgcGF0aCB3ZSBuZWVkIHRvIHJlbW92ZSBpbiBvcmRlclxuICAgIC8vIHRvIHNob3J0ZW4gdGhlIHBhdGguXG4gICAgY29uc3Qgc2VnSW5kZXggPSBnZXRQYXRoU2VnbWVudEluZGV4QXRMZW5ndGgocG9pbnRzLCBsZW5ndGgsIGxpbmVGdW5jKTtcbiAgICAvLyBVcGRhdGUgdGhlIHZlcnkgZmlyc3Qgc2VnbWVudC5cbiAgICBwb2ludHNbc2VnSW5kZXggLSAxXSA9IHt4OiBwb2ludC54LCB5OiBwb2ludC55fTtcbiAgICAvLyBJZ25vcmUgZXZlcnkgcG9pbnQgYmVmb3JlIHNlZ0luZGV4IC0gMS5cbiAgICByZXR1cm4gcG9pbnRzLnNsaWNlKHNlZ0luZGV4IC0gMSk7XG4gIH0gZWxzZSB7XG4gICAgLy8gVGhlIGVkZ2UgZmxvd3MgdXB3YXJkcy4gRG8gbm90IG1ha2UgdGhlIGVkZ2UgZ28gdGhlIHdob2xlIHdheSwgbGVzdCB3ZVxuICAgIC8vIGNsb2JiZXIgdGhlIGFycm93aGVhZC5cbiAgICBjb25zdCBmcmFjdGlvblN0aWNraW5nT3V0ID0gMSAtIHJlZlggLyB2aWV3Qm94V2lkdGg7XG4gICAgY29uc3QgbGVuZ3RoID1cbiAgICAgICAgcGF0aE5vZGUuZ2V0VG90YWxMZW5ndGgoKSAtIG1hcmtlcldpZHRoICogZnJhY3Rpb25TdGlja2luZ091dDtcbiAgICBjb25zdCBwb2ludCA9IHBhdGhOb2RlLmdldFBvaW50QXRMZW5ndGgobGVuZ3RoKTtcbiAgICAvLyBGaWd1cmUgb3V0IGhvdyBtYW55IHNlZ21lbnRzIG9mIHRoZSBwYXRoIHdlIG5lZWQgdG8gcmVtb3ZlIGluIG9yZGVyXG4gICAgLy8gdG8gc2hvcnRlbiB0aGUgcGF0aC5cbiAgICBjb25zdCBzZWdJbmRleCA9IGdldFBhdGhTZWdtZW50SW5kZXhBdExlbmd0aChwb2ludHMsIGxlbmd0aCwgbGluZUZ1bmMpO1xuICAgIC8vIFVwZGF0ZSB0aGUgdmVyeSBsYXN0IHNlZ21lbnQuXG4gICAgcG9pbnRzW3NlZ0luZGV4XSA9IHt4OiBwb2ludC54LCB5OiBwb2ludC55fTtcbiAgICAvLyBJZ25vcmUgZXZlcnkgcG9pbnQgYWZ0ZXIgc2VnSW5kZXguXG4gICAgcmV0dXJuIHBvaW50cy5zbGljZSgwLCBzZWdJbmRleCArIDEpO1xuICB9XG59XG5cbi8qKlxuICogRm9yIGEgZ2l2ZW4gZDMgc2VsZWN0aW9uIGFuZCBkYXRhIG9iamVjdCwgY3JlYXRlIGEgcGF0aCB0byByZXByZXNlbnQgdGhlXG4gKiBlZGdlIGRlc2NyaWJlZCBpbiBkLmxhYmVsLlxuICpcbiAqIElmIGQubGFiZWwgaXMgZGVmaW5lZCwgaXQgd2lsbCBiZSBhIFJlbmRlck1ldGFlZGdlSW5mbyBpbnN0YW5jZS4gSXRcbiAqIHdpbGwgc29tZXRpbWVzIGJlIHVuZGVmaW5lZCwgZm9yIGV4YW1wbGUgZm9yIHNvbWUgQW5ub3RhdGlvbiBlZGdlcyBmb3Igd2hpY2hcbiAqIHRoZXJlIGlzIG5vIHVuZGVybHlpbmcgTWV0YWVkZ2UgaW4gdGhlIGhpZXJhcmNoaWNhbCBncmFwaC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGFwcGVuZEVkZ2UoZWRnZUdyb3VwLCBkOiBFZGdlRGF0YSxcbiAgICBzY2VuZUVsZW1lbnQ6IHtcbiAgICAgICAgcmVuZGVySGllcmFyY2h5OiByZW5kZXIuUmVuZGVyR3JhcGhJbmZvLFxuICAgICAgICBoYW5kbGVFZGdlU2VsZWN0ZWQ6IEZ1bmN0aW9uLFxuICAgIH0sXG4gICAgZWRnZUNsYXNzPzogc3RyaW5nKSB7XG4gIGVkZ2VDbGFzcyA9IGVkZ2VDbGFzcyB8fCBDbGFzcy5FZGdlLkxJTkU7IC8vIHNldCBkZWZhdWx0IHR5cGVcblxuICBpZiAoZC5sYWJlbCAmJiBkLmxhYmVsLnN0cnVjdHVyYWwpIHtcbiAgICBlZGdlQ2xhc3MgKz0gJyAnICsgQ2xhc3MuRWRnZS5TVFJVQ1RVUkFMO1xuICB9XG4gIGlmIChkLmxhYmVsICYmIGQubGFiZWwubWV0YWVkZ2UgJiYgZC5sYWJlbC5tZXRhZWRnZS5udW1SZWZFZGdlcykge1xuICAgIGVkZ2VDbGFzcyArPSAnICcgKyBDbGFzcy5FZGdlLlJFRkVSRU5DRV9FREdFO1xuICB9XG4gIGlmIChzY2VuZUVsZW1lbnQuaGFuZGxlRWRnZVNlbGVjdGVkKSB7XG4gICAgLy8gVGhlIHVzZXIgaGFzIG9wdGVkIHRvIG1ha2UgZWRnZXMgc2VsZWN0YWJsZS5cbiAgICBlZGdlQ2xhc3MgKz0gJyAnICsgQ2xhc3MuRWRnZS5TRUxFQ1RBQkxFO1xuICB9XG4gIC8vIEdpdmUgdGhlIHBhdGggYSB1bmlxdWUgaWQsIHdoaWNoIHdpbGwgYmUgdXNlZCB0byBsaW5rXG4gIC8vIHRoZSB0ZXh0UGF0aCAoZWRnZSBsYWJlbCkgdG8gdGhpcyBwYXRoLlxuICBsZXQgcGF0aElkID0gJ3BhdGhfJyArIGdldEVkZ2VLZXkoZCk7XG4gIFxuICBsZXQgc3Ryb2tlV2lkdGg7XG4gIGlmIChzY2VuZUVsZW1lbnQucmVuZGVySGllcmFyY2h5LmVkZ2VXaWR0aEZ1bmN0aW9uKSB7XG4gICAgLy8gQ29tcHV0ZSBlZGdlIHRoaWNrbmVzcyBiYXNlZCBvbiB0aGUgdXNlci1zcGVjaWZpZWQgbWV0aG9kLlxuICAgIHN0cm9rZVdpZHRoID0gc2NlbmVFbGVtZW50LnJlbmRlckhpZXJhcmNoeS5lZGdlV2lkdGhGdW5jdGlvbihkLCBlZGdlQ2xhc3MpO1xuICB9IGVsc2Uge1xuICAgIC8vIEVuY29kZSB0ZW5zb3Igc2l6ZSB3aXRoaW4gZWRnZSB0aGlja25lc3MuXG4gICAgbGV0IHNpemUgPSAxO1xuICAgIGlmIChkLmxhYmVsICE9IG51bGwgJiYgZC5sYWJlbC5tZXRhZWRnZSAhPSBudWxsKSB7XG4gICAgICAvLyBUaGVyZSBpcyBhbiB1bmRlcmx5aW5nIE1ldGFlZGdlLlxuICAgICAgc2l6ZSA9IGQubGFiZWwubWV0YWVkZ2UudG90YWxTaXplO1xuICAgIH1cbiAgICBzdHJva2VXaWR0aCA9IHNjZW5lRWxlbWVudC5yZW5kZXJIaWVyYXJjaHkuZWRnZVdpZHRoU2l6ZWRCYXNlZFNjYWxlKHNpemUpO1xuICB9XG5cbiAgbGV0IHBhdGggPSBlZGdlR3JvdXAuYXBwZW5kKCdwYXRoJylcbiAgICAgICAgICAgICAgICAgLmF0dHIoJ2lkJywgcGF0aElkKVxuICAgICAgICAgICAgICAgICAuYXR0cignY2xhc3MnLCBlZGdlQ2xhc3MpXG4gICAgICAgICAgICAgICAgIC5zdHlsZSgnc3Ryb2tlLXdpZHRoJywgc3Ryb2tlV2lkdGggKyAncHgnKTtcblxuICAvLyBDaGVjayBpZiB0aGVyZSBpcyBhIHJlZmVyZW5jZSBlZGdlIGFuZCBhZGQgYW4gYXJyb3doZWFkIG9mIHRoZSByaWdodCBzaXplLlxuICBpZiAoZC5sYWJlbCAmJiBkLmxhYmVsLm1ldGFlZGdlKSB7XG4gICAgaWYgKGQubGFiZWwubWV0YWVkZ2UubnVtUmVmRWRnZXMpIHtcbiAgICAgIC8vIFdlIGhhdmUgYSByZWZlcmVuY2UgZWRnZS5cbiAgICAgIGNvbnN0IG1hcmtlcklkID0gYHJlZmVyZW5jZS1hcnJvd2hlYWQtJHthcnJvd2hlYWRNYXAoc3Ryb2tlV2lkdGgpfWA7XG4gICAgICBwYXRoLnN0eWxlKCdtYXJrZXItc3RhcnQnLCBgdXJsKCMke21hcmtlcklkfSlgKTtcbiAgICAgIGQubGFiZWwuc3RhcnRNYXJrZXJJZCA9IG1hcmtlcklkO1xuICAgIH0gZWxzZSB7XG4gICAgICAvLyBXZSBoYXZlIGEgZGF0YWZsb3cgZWRnZS5cbiAgICAgIGNvbnN0IG1hcmtlcklkID0gYGRhdGFmbG93LWFycm93aGVhZC0ke2Fycm93aGVhZE1hcChzdHJva2VXaWR0aCl9YDtcbiAgICAgIHBhdGguc3R5bGUoJ21hcmtlci1lbmQnLCBgdXJsKCMke21hcmtlcklkfSlgKTtcbiAgICAgIGQubGFiZWwuZW5kTWFya2VySWQgPSBtYXJrZXJJZDtcbiAgICB9XG4gIH1cblxuICBpZiAoZC5sYWJlbCA9PSBudWxsIHx8IGQubGFiZWwubWV0YWVkZ2UgPT0gbnVsbCkge1xuICAgIC8vIFRoZXJlIGlzIG5vIGFzc29jaWF0ZWQgbWV0YWVkZ2UsIHRodXMgbm8gdGV4dC5cbiAgICAvLyBUaGlzIGhhcHBlbnMgZm9yIGFubm90YXRpb24gZWRnZXMuXG4gICAgcmV0dXJuO1xuICB9XG4gIGxldCBsYWJlbEZvckVkZ2UgPSBnZXRMYWJlbEZvckVkZ2UoZC5sYWJlbC5tZXRhZWRnZSxcbiAgICAgIHNjZW5lRWxlbWVudC5yZW5kZXJIaWVyYXJjaHkpO1xuICBpZiAobGFiZWxGb3JFZGdlID09IG51bGwpIHtcbiAgICAvLyBXZSBoYXZlIG5vIGluZm9ybWF0aW9uIHRvIHNob3cgb24gdGhpcyBlZGdlLlxuICAgIHJldHVybjtcbiAgfVxuXG4gIC8vIFB1dCBlZGdlIGxhYmVsIGluIHRoZSBtaWRkbGUgb2YgZWRnZSBvbmx5IGlmIHRoZSBlZGdlIGlzIHRoaWNrIGVub3VnaC5cbiAgbGV0IGJhc2VsaW5lID0gc3Ryb2tlV2lkdGggPiBDRU5URVJfRURHRV9MQUJFTF9NSU5fU1RST0tFX1dJRFRIID9cbiAgICAgICdjZW50cmFsJyA6XG4gICAgICAndGV4dC1hZnRlci1lZGdlJztcblxuICBlZGdlR3JvdXAuYXBwZW5kKCd0ZXh0JylcbiAgICAgIC5hcHBlbmQoJ3RleHRQYXRoJylcbiAgICAgICAgLmF0dHIoJ3hsaW5rOmhyZWYnLCAnIycgKyBwYXRoSWQpXG4gICAgICAgIC5hdHRyKCdzdGFydE9mZnNldCcsICc1MCUnKVxuICAgICAgICAuYXR0cigndGV4dC1hbmNob3InLCAnbWlkZGxlJylcbiAgICAgICAgLmF0dHIoJ2RvbWluYW50LWJhc2VsaW5lJywgJ2NlbnRyYWwnKVxuICAgICAgLnRleHQobGFiZWxGb3JFZGdlKTtcbn07XG5cbmV4cG9ydCBsZXQgaW50ZXJwb2xhdGU6IGQzLkxpbmU8e3g6IG51bWJlciwgeTogbnVtYmVyfT4gPSBkMy5saW5lPHt4OiBudW1iZXIsIHk6IG51bWJlcn0+KClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLmN1cnZlKGQzLmN1cnZlQmFzaXMpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgIC54KChkKSA9PiB7IHJldHVybiBkLng7fSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnkoKGQpID0+IHsgcmV0dXJuIGQueTt9KTtcblxuLyoqXG4gKiBSZXR1cm5zIGEgdHdlZW4gaW50ZXJwb2xhdG9yIGZvciB0aGUgZW5kcG9pbnQgb2YgYW4gZWRnZSBwYXRoLlxuICovXG5mdW5jdGlvbiBnZXRFZGdlUGF0aEludGVycG9sYXRvcihkOiBFZGdlRGF0YSwgaTogbnVtYmVyLCBhOiBzdHJpbmcpIHtcbiAgbGV0IHJlbmRlck1ldGFlZGdlSW5mbyA9IDxyZW5kZXIuUmVuZGVyTWV0YWVkZ2VJbmZvPiBkLmxhYmVsO1xuICBsZXQgYWRqb2luaW5nTWV0YWVkZ2UgPSByZW5kZXJNZXRhZWRnZUluZm8uYWRqb2luaW5nTWV0YWVkZ2U7XG4gIGxldCBwb2ludHMgPSByZW5kZXJNZXRhZWRnZUluZm8ucG9pbnRzO1xuXG4gIC8vIEFkanVzdCB0aGUgcGF0aCBzbyB0aGF0IHN0YXJ0L2VuZCBtYXJrZXJzIHBvaW50IHRvIHRoZSBlbmRcbiAgLy8gb2YgdGhlIHBhdGguXG4gIGlmIChkLmxhYmVsLnN0YXJ0TWFya2VySWQpIHtcbiAgICBwb2ludHMgPSBhZGp1c3RQYXRoUG9pbnRzRm9yTWFya2VyKFxuICAgICAgICBwb2ludHMsIGQzLnNlbGVjdCgnIycgKyBkLmxhYmVsLnN0YXJ0TWFya2VySWQpLCB0cnVlKTtcbiAgfVxuICBpZiAoZC5sYWJlbC5lbmRNYXJrZXJJZCkge1xuICAgIHBvaW50cyA9IGFkanVzdFBhdGhQb2ludHNGb3JNYXJrZXIoXG4gICAgICAgIHBvaW50cywgZDMuc2VsZWN0KCcjJyArIGQubGFiZWwuZW5kTWFya2VySWQpLCBmYWxzZSk7XG4gIH1cblxuICBpZiAoIWFkam9pbmluZ01ldGFlZGdlKSB7XG4gICAgcmV0dXJuIGQzLmludGVycG9sYXRlKGEsIGludGVycG9sYXRlKHBvaW50cykpO1xuICB9XG5cbiAgbGV0IHJlbmRlclBhdGggPSB0aGlzO1xuXG4gIC8vIEdldCB0aGUgYWRqb2luaW5nIHBhdGggdGhhdCBtYXRjaGVzIHRoZSBhZGpvaW5pbmcgbWV0YWVkZ2UuXG4gIGxldCBhZGpvaW5pbmdQYXRoID1cbiAgICA8U1ZHUGF0aEVsZW1lbnQ+KCg8SFRNTEVsZW1lbnQ+YWRqb2luaW5nTWV0YWVkZ2UuZWRnZUdyb3VwLm5vZGUoKSlcbiAgICAgIC5maXJzdENoaWxkKTtcblxuICAvLyBGaW5kIHRoZSBkZXNpcmVkIFNWR1BvaW50IGFsb25nIHRoZSBhZGpvaW5pbmcgcGF0aCwgdGhlbiBjb252ZXJ0IHRob3NlXG4gIC8vIGNvb3JkaW5hdGVzIGludG8gdGhlIHNwYWNlIG9mIHRoZSByZW5kZXJQYXRoIHVzaW5nIGl0cyBDdXJyZW50XG4gIC8vIFRyYW5zZm9ybWF0aW9uIE1hdHJpeCAoQ1RNKS5cbiAgbGV0IGluYm91bmQgPSByZW5kZXJNZXRhZWRnZUluZm8ubWV0YWVkZ2UuaW5ib3VuZDtcblxuICByZXR1cm4gZnVuY3Rpb24odCkge1xuICAgIGxldCBhZGpvaW5pbmdQb2ludCA9IGFkam9pbmluZ1BhdGhcbiAgICAgIC5nZXRQb2ludEF0TGVuZ3RoKGluYm91bmQgPyBhZGpvaW5pbmdQYXRoLmdldFRvdGFsTGVuZ3RoKCkgOiAwKVxuICAgICAgLm1hdHJpeFRyYW5zZm9ybShhZGpvaW5pbmdQYXRoLmdldENUTSgpKVxuICAgICAgLm1hdHJpeFRyYW5zZm9ybShyZW5kZXJQYXRoLmdldENUTSgpLmludmVyc2UoKSk7XG5cbiAgICAvLyBVcGRhdGUgdGhlIHJlbGV2YW50IHBvaW50IGluIHRoZSByZW5kZXJNZXRhZWRnZUluZm8ncyBwb2ludHMgbGlzdCwgdGhlblxuICAgIC8vIHJlLWludGVycG9sYXRlIHRoZSBwYXRoLlxuICAgIGxldCBpbmRleCA9IGluYm91bmQgPyAwIDogcG9pbnRzLmxlbmd0aCAtIDE7XG4gICAgcG9pbnRzW2luZGV4XS54ID0gYWRqb2luaW5nUG9pbnQueDtcbiAgICBwb2ludHNbaW5kZXhdLnkgPSBhZGpvaW5pbmdQb2ludC55O1xuICAgIGxldCBkUGF0aCA9IGludGVycG9sYXRlKHBvaW50cyk7XG4gICAgcmV0dXJuIGRQYXRoO1xuICB9O1xufVxuXG5mdW5jdGlvbiBwb3NpdGlvbihkKSB7XG4gIGQzLnNlbGVjdCh0aGlzKVxuICAgICAgLnNlbGVjdCgncGF0aC4nICsgQ2xhc3MuRWRnZS5MSU5FKVxuICAgICAgLnRyYW5zaXRpb24oKVxuICAgICAgLmF0dHJUd2VlbignZCcsIGdldEVkZ2VQYXRoSW50ZXJwb2xhdG9yIGFzIGFueSk7XG59O1xuXG4vKipcbiAqIEZvciBhIGdpdmVuIGQzIHNlbGVjdGlvbiBhbmQgZGF0YSBvYmplY3QsIG1hcmsgdGhlIGVkZ2UgYXMgYSBjb250cm9sXG4gKiBkZXBlbmRlbmN5IGlmIGl0IGNvbnRhaW5zIG9ubHkgY29udHJvbCBlZGdlcy5cbiAqXG4gKiBkJ3MgbGFiZWwgcHJvcGVydHkgd2lsbCBiZSBhIFJlbmRlck1ldGFlZGdlSW5mbyBvYmplY3QuXG4gKi9cbmZ1bmN0aW9uIHN0eWxpemUoZWRnZUdyb3VwLCBkOiBFZGdlRGF0YSwgc3R5bGl6ZSkge1xuICBlZGdlR3JvdXAuY2xhc3NlZCgnZmFkZWQnLCBkLmxhYmVsLmlzRmFkZWRPdXQpO1xuICBsZXQgbWV0YWVkZ2UgPSBkLmxhYmVsLm1ldGFlZGdlO1xuICBlZGdlR3JvdXAuc2VsZWN0KCdwYXRoLicgKyBDbGFzcy5FZGdlLkxJTkUpXG4gICAgICAuY2xhc3NlZCgnY29udHJvbC1kZXAnLCBtZXRhZWRnZSAmJiAhbWV0YWVkZ2UubnVtUmVndWxhckVkZ2VzKTtcbn07XG5cbn0gLy8gY2xvc2UgbW9kdWxlXG4iXX0=