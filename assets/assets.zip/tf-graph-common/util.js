/* Copyright 2015 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the 'License');
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an 'AS IS' BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
/**
 * @fileoverview Utility functions for the tensorflow graph visualizer.
 */
var tf;
(function (tf) {
    var graph;
    (function (graph) {
        var util;
        (function (util) {
            /**
             * Recommended delay (ms) when running an expensive task asynchronously
             * that gives enough time for the progress bar to update its UI.
             */
            var ASYNC_TASK_DELAY = 20;
            function time(msg, task) {
                var start = Date.now();
                var result = task();
                /* tslint:disable */
                console.log(msg, ':', Date.now() - start, 'ms');
                /* tslint:enable */
                return result;
            }
            util.time = time;
            /**
             * Creates a tracker that sets the progress property of the
             * provided polymer component. The provided component must have
             * a property called 'progress' that is not read-only. The progress
             * property is an object with a numerical 'value' property and a
             * string 'msg' property.
             */
            function getTracker(polymerComponent) {
                return {
                    setMessage: function (msg) {
                        polymerComponent.set('progress', { value: polymerComponent.progress.value, msg: msg });
                    },
                    updateProgress: function (value) {
                        polymerComponent.set('progress', {
                            value: polymerComponent.progress.value + value,
                            msg: polymerComponent.progress.msg
                        });
                    },
                    reportError: function (msg, err) {
                        // Log the stack trace in the console.
                        console.error(err.stack);
                        // And send a user-friendly message to the UI.
                        polymerComponent.set('progress', { value: polymerComponent.progress.value, msg: msg, error: true });
                    },
                };
            }
            util.getTracker = getTracker;
            /**
             * Creates a tracker for a subtask given the parent tracker, the total
             * progress
             * of the subtask and the subtask message. The parent task should pass a
             * subtracker to its subtasks. The subtask reports its own progress which
             * becomes relative to the main task.
             */
            function getSubtaskTracker(parentTracker, impactOnTotalProgress, subtaskMsg) {
                return {
                    setMessage: function (progressMsg) {
                        // The parent should show a concatenation of its message along with
                        // its subtask tracker message.
                        parentTracker.setMessage(subtaskMsg + ': ' + progressMsg);
                    },
                    updateProgress: function (incrementValue) {
                        // Update the parent progress relative to the child progress.
                        // For example, if the sub-task progresses by 30%, and the impact on the
                        // total progress is 50%, then the task progresses by 30% * 50% = 15%.
                        parentTracker.updateProgress(incrementValue * impactOnTotalProgress / 100);
                    },
                    reportError: function (msg, err) {
                        // The parent should show a concatenation of its message along with
                        // its subtask error message.
                        parentTracker.reportError(subtaskMsg + ': ' + msg, err);
                    }
                };
            }
            util.getSubtaskTracker = getSubtaskTracker;
            /**
             * Runs an expensive task and return the result.
             */
            function runTask(msg, incProgressValue, task, tracker) {
                // Update the progress message to say the current running task.
                tracker.setMessage(msg);
                // Run the expensive task with a delay that gives enough time for the
                // UI to update.
                try {
                    var result = tf.graph.util.time(msg, task);
                    // Update the progress value.
                    tracker.updateProgress(incProgressValue);
                    // Return the result to be used by other tasks.
                    return result;
                }
                catch (e) {
                    // Errors that happen inside asynchronous tasks are
                    // reported to the tracker using a user-friendly message.
                    tracker.reportError('Failed ' + msg, e);
                }
            }
            util.runTask = runTask;
            /**
             * Runs an expensive task asynchronously and returns a promise of the result.
             */
            function runAsyncTask(msg, incProgressValue, task, tracker) {
                return new Promise(function (resolve, reject) {
                    // Update the progress message to say the current running task.
                    tracker.setMessage(msg);
                    // Run the expensive task with a delay that gives enough time for the
                    // UI to update.
                    setTimeout(function () {
                        try {
                            var result = tf.graph.util.time(msg, task);
                            // Update the progress value.
                            tracker.updateProgress(incProgressValue);
                            // Return the result to be used by other tasks.
                            resolve(result);
                        }
                        catch (e) {
                            // Errors that happen inside asynchronous tasks are
                            // reported to the tracker using a user-friendly message.
                            tracker.reportError('Failed ' + msg, e);
                        }
                    }, ASYNC_TASK_DELAY);
                });
            }
            util.runAsyncTask = runAsyncTask;
            /**
             * Asynchronously runs an expensive task that returns a promise. Updates the
             * tracker's progress after the promise resolves. Returns a new promise that
             * resolves after the progress is updated.
             */
            function runAsyncPromiseTask(msg, incProgressValue, task, tracker) {
                return new Promise(function (resolve, reject) {
                    var handleError = function (e) {
                        // Errors that happen inside asynchronous tasks are
                        // reported to the tracker using a user-friendly message.
                        tracker.reportError('Failed ' + msg, e);
                        reject(e);
                    };
                    // Update the progress message to say the current running task.
                    tracker.setMessage(msg);
                    // Run the expensive task with a delay that gives enough time for the
                    // UI to update.
                    setTimeout(function () {
                        try {
                            var start_1 = Date.now();
                            task()
                                .then(function (value) {
                                /* tslint:disable */
                                console.log(msg, ':', Date.now() - start_1, 'ms');
                                // Update the progress value.
                                tracker.updateProgress(incProgressValue);
                                // Return the result to be used by other tasks.
                                resolve(value);
                            })
                                .catch(handleError);
                        }
                        catch (e) {
                            handleError(e);
                        }
                    }, ASYNC_TASK_DELAY);
                });
            }
            util.runAsyncPromiseTask = runAsyncPromiseTask;
            /**
             * Returns a query selector with escaped special characters that are not
             * allowed in a query selector.
             */
            function escapeQuerySelector(querySelector) {
                return querySelector.replace(/([:.\[\],/\\\(\)])/g, '\\$1');
            }
            util.escapeQuerySelector = escapeQuerySelector;
            // For unit conversion.
            util.MEMORY_UNITS = [
                // Atomic unit.
                { symbol: 'B' },
                // numUnits specifies how many previous units this unit contains.
                { symbol: 'KB', numUnits: 1024 }, { symbol: 'MB', numUnits: 1024 },
                { symbol: 'GB', numUnits: 1024 }, { symbol: 'TB', numUnits: 1024 },
                { symbol: 'PB', numUnits: 1024 }
            ];
            util.TIME_UNITS = [
                // Atomic unit. Finest granularity in TensorFlow stat collection.
                { symbol: 'µs' },
                // numUnits specifies how many previous units this unit contains.
                { symbol: 'ms', numUnits: 1000 }, { symbol: 's', numUnits: 1000 },
                { symbol: 'min', numUnits: 60 }, { symbol: 'hr', numUnits: 60 },
                { symbol: 'days', numUnits: 24 }
            ];
            /**
             * Returns the human readable version of the unit.
             * (e.g. 1.35 GB, 23 MB, 34 ms, 6.53 min etc).
             */
            function convertUnitsToHumanReadable(value, units, unitIndex) {
                unitIndex = unitIndex == null ? 0 : unitIndex;
                if (unitIndex + 1 < units.length &&
                    value >= units[unitIndex + 1].numUnits) {
                    return tf.graph.util.convertUnitsToHumanReadable(value / units[unitIndex + 1].numUnits, units, unitIndex + 1);
                }
                // toPrecision() has the tendency to return a number in scientific
                // notation and (number - 0) brings it back to normal notation.
                return (value.toPrecision(3) - 0) + ' ' + units[unitIndex].symbol;
            }
            util.convertUnitsToHumanReadable = convertUnitsToHumanReadable;
            function hasDisplayableNodeStats(stats) {
                if (stats &&
                    (stats.totalBytes > 0 || stats.getTotalMicros() > 0 ||
                        stats.outputSize)) {
                    return true;
                }
                return false;
            }
            util.hasDisplayableNodeStats = hasDisplayableNodeStats;
            /**
             * Given a list of strings, it returns a new list of strings with the longest
             * common prefix removed. If the common prefix is one of the strings in the
             * list, it returns the original strings.
             */
            function removeCommonPrefix(strings) {
                if (strings.length < 2) {
                    return strings;
                }
                var index = 0;
                var largestIndex = 0;
                // Find the shortest name across all strings.
                var minLength = _.min(_.map(strings, function (str) { return str.length; }));
                var _loop_1 = function () {
                    index++;
                    var prefixes = _.map(strings, function (str) { return str.substring(0, index); });
                    var allTheSame = prefixes.every(function (prefix, i) {
                        return (i === 0 ? true : prefix === prefixes[i - 1]);
                    });
                    if (allTheSame) {
                        if (index >= minLength) {
                            return { value: strings };
                        }
                        largestIndex = index;
                    }
                    else {
                        return "break";
                    }
                };
                while (true) {
                    var state_1 = _loop_1();
                    if (typeof state_1 === "object")
                        return state_1.value;
                    if (state_1 === "break")
                        break;
                }
                return _.map(strings, function (str) { return str.substring(largestIndex); });
            }
            util.removeCommonPrefix = removeCommonPrefix;
            /**
             * Given a queryString, aka ?foo=1&bar=2, return the object representation.
             */
            function getQueryParams(queryString) {
                if (queryString.charAt(0) === '?') {
                    queryString = queryString.slice(1);
                }
                var queryParams = _.chain(queryString.split('&'))
                    .map(function (item) {
                    if (item) {
                        return item.split('=');
                    }
                })
                    .compact()
                    .value();
                return _.object(queryParams);
            }
            util.getQueryParams = getQueryParams;
            /**
             * Given a timestamp in microseconds, return a human-friendly string denoting
             * how long ago the timestamp was.
             */
            function computeHumanFriendlyTime(timeInMicroseconds) {
                var timeDifferenceInMs = +(new Date()) - +(new Date(timeInMicroseconds / 1e3));
                if (timeDifferenceInMs < 30000) {
                    return 'just now';
                }
                else if (timeDifferenceInMs < 60000) {
                    return Math.floor(timeDifferenceInMs / 1000) + ' seconds ago';
                }
                else if (timeDifferenceInMs < 120000) {
                    return 'a minute ago';
                }
                else if (timeDifferenceInMs < 3600000) {
                    return Math.floor(timeDifferenceInMs / 60000) + ' minutes ago';
                }
                else if (Math.floor(timeDifferenceInMs / 3600000) == 1) {
                    return 'an hour ago';
                }
                else if (timeDifferenceInMs < 86400000) {
                    return Math.floor(timeDifferenceInMs / 3600000) + ' hours ago';
                }
                else if (timeDifferenceInMs < 172800000) {
                    return 'yesterday';
                }
                return Math.floor(timeDifferenceInMs / 86400000) + ' days ago';
            }
            util.computeHumanFriendlyTime = computeHumanFriendlyTime;
        })(util = graph.util || (graph.util = {}));
    })(graph = tf.graph || (tf.graph = {}));
})(tf || (tf = {}));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidXRpbC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbInV0aWwudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7Ozs7Ozs7Z0ZBYWdGO0FBRWhGOztHQUVHO0FBRUgsSUFBTyxFQUFFLENBd1NSO0FBeFNELFdBQU8sRUFBRTtJQUFDLElBQUEsS0FBSyxDQXdTZDtJQXhTUyxXQUFBLEtBQUs7UUFBQyxJQUFBLElBQUksQ0F3U25CO1FBeFNlLFdBQUEsSUFBSTtZQUNsQjs7O2VBR0c7WUFDSCxJQUFNLGdCQUFnQixHQUFHLEVBQUUsQ0FBQztZQUU1QixjQUF3QixHQUFXLEVBQUUsSUFBYTtnQkFDaEQsSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDO2dCQUN2QixJQUFJLE1BQU0sR0FBRyxJQUFJLEVBQUUsQ0FBQztnQkFDcEIsb0JBQW9CO2dCQUNwQixPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsSUFBSSxDQUFDLEdBQUcsRUFBRSxHQUFHLEtBQUssRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDaEQsbUJBQW1CO2dCQUNuQixPQUFPLE1BQU0sQ0FBQztZQUNoQixDQUFDO1lBUGUsU0FBSSxPQU9uQixDQUFBO1lBRUQ7Ozs7OztlQU1HO1lBQ0gsb0JBQTJCLGdCQUFxQjtnQkFDOUMsT0FBTztvQkFDTCxVQUFVLEVBQUUsVUFBUyxHQUFHO3dCQUN0QixnQkFBZ0IsQ0FBQyxHQUFHLENBQ2hCLFVBQVUsRUFBRSxFQUFDLEtBQUssRUFBRSxnQkFBZ0IsQ0FBQyxRQUFRLENBQUMsS0FBSyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUMsQ0FBQyxDQUFDO29CQUN0RSxDQUFDO29CQUNELGNBQWMsRUFBRSxVQUFTLEtBQUs7d0JBQzVCLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxVQUFVLEVBQUU7NEJBQy9CLEtBQUssRUFBRSxnQkFBZ0IsQ0FBQyxRQUFRLENBQUMsS0FBSyxHQUFHLEtBQUs7NEJBQzlDLEdBQUcsRUFBRSxnQkFBZ0IsQ0FBQyxRQUFRLENBQUMsR0FBRzt5QkFDbkMsQ0FBQyxDQUFDO29CQUNMLENBQUM7b0JBQ0QsV0FBVyxFQUFFLFVBQVMsR0FBVyxFQUFFLEdBQUc7d0JBQ3BDLHNDQUFzQzt3QkFDdEMsT0FBTyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7d0JBQ3pCLDhDQUE4Qzt3QkFDOUMsZ0JBQWdCLENBQUMsR0FBRyxDQUNoQixVQUFVLEVBQ1YsRUFBQyxLQUFLLEVBQUUsZ0JBQWdCLENBQUMsUUFBUSxDQUFDLEtBQUssRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUMsQ0FBQyxDQUFDO29CQUN2RSxDQUFDO2lCQUNGLENBQUM7WUFDSixDQUFDO1lBckJlLGVBQVUsYUFxQnpCLENBQUE7WUFFRDs7Ozs7O2VBTUc7WUFDSCwyQkFDSSxhQUE4QixFQUFFLHFCQUE2QixFQUM3RCxVQUFrQjtnQkFDcEIsT0FBTztvQkFDTCxVQUFVLEVBQUUsVUFBUyxXQUFXO3dCQUM5QixtRUFBbUU7d0JBQ25FLCtCQUErQjt3QkFDL0IsYUFBYSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEdBQUcsSUFBSSxHQUFHLFdBQVcsQ0FBQyxDQUFDO29CQUM1RCxDQUFDO29CQUNELGNBQWMsRUFBRSxVQUFTLGNBQWM7d0JBQ3JDLDZEQUE2RDt3QkFDN0Qsd0VBQXdFO3dCQUN4RSxzRUFBc0U7d0JBQ3RFLGFBQWEsQ0FBQyxjQUFjLENBQ3hCLGNBQWMsR0FBRyxxQkFBcUIsR0FBRyxHQUFHLENBQUMsQ0FBQztvQkFDcEQsQ0FBQztvQkFDRCxXQUFXLEVBQUUsVUFBUyxHQUFXLEVBQUUsR0FBVTt3QkFDM0MsbUVBQW1FO3dCQUNuRSw2QkFBNkI7d0JBQzdCLGFBQWEsQ0FBQyxXQUFXLENBQUMsVUFBVSxHQUFHLElBQUksR0FBRyxHQUFHLEVBQUUsR0FBRyxDQUFDLENBQUM7b0JBQzFELENBQUM7aUJBQ0YsQ0FBQztZQUNKLENBQUM7WUF0QmUsc0JBQWlCLG9CQXNCaEMsQ0FBQTtZQUVEOztlQUVHO1lBQ0gsaUJBQ0ksR0FBVyxFQUFFLGdCQUF3QixFQUFFLElBQWEsRUFDcEQsT0FBd0I7Z0JBQzFCLCtEQUErRDtnQkFDL0QsT0FBTyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDeEIscUVBQXFFO2dCQUNyRSxnQkFBZ0I7Z0JBQ2hCLElBQUk7b0JBQ0YsSUFBSSxNQUFNLEdBQUcsRUFBRSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxJQUFJLENBQUMsQ0FBQztvQkFDM0MsNkJBQTZCO29CQUM3QixPQUFPLENBQUMsY0FBYyxDQUFDLGdCQUFnQixDQUFDLENBQUM7b0JBQ3pDLCtDQUErQztvQkFDL0MsT0FBTyxNQUFNLENBQUM7aUJBQ2Y7Z0JBQUMsT0FBTyxDQUFDLEVBQUU7b0JBQ1YsbURBQW1EO29CQUNuRCx5REFBeUQ7b0JBQ3pELE9BQU8sQ0FBQyxXQUFXLENBQUMsU0FBUyxHQUFHLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FBQztpQkFDekM7WUFDSCxDQUFDO1lBbEJlLFlBQU8sVUFrQnRCLENBQUE7WUFFRDs7ZUFFRztZQUNILHNCQUNJLEdBQVcsRUFBRSxnQkFBd0IsRUFBRSxJQUFhLEVBQ3BELE9BQXdCO2dCQUMxQixPQUFPLElBQUksT0FBTyxDQUFDLFVBQUMsT0FBTyxFQUFFLE1BQU07b0JBQ2pDLCtEQUErRDtvQkFDL0QsT0FBTyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQztvQkFDeEIscUVBQXFFO29CQUNyRSxnQkFBZ0I7b0JBQ2hCLFVBQVUsQ0FBQzt3QkFDVCxJQUFJOzRCQUNGLElBQUksTUFBTSxHQUFHLEVBQUUsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLENBQUM7NEJBQzNDLDZCQUE2Qjs0QkFDN0IsT0FBTyxDQUFDLGNBQWMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDOzRCQUN6QywrQ0FBK0M7NEJBQy9DLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQzt5QkFDakI7d0JBQUMsT0FBTyxDQUFDLEVBQUU7NEJBQ1YsbURBQW1EOzRCQUNuRCx5REFBeUQ7NEJBQ3pELE9BQU8sQ0FBQyxXQUFXLENBQUMsU0FBUyxHQUFHLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FBQzt5QkFDekM7b0JBQ0gsQ0FBQyxFQUFFLGdCQUFnQixDQUFDLENBQUM7Z0JBQ3ZCLENBQUMsQ0FBQyxDQUFDO1lBQ0wsQ0FBQztZQXRCZSxpQkFBWSxlQXNCM0IsQ0FBQTtZQUVEOzs7O2VBSUc7WUFDSCw2QkFDSSxHQUFXLEVBQUUsZ0JBQXdCLEVBQUUsSUFBc0IsRUFDN0QsT0FBd0I7Z0JBQzFCLE9BQU8sSUFBSSxPQUFPLENBQUMsVUFBQyxPQUFPLEVBQUUsTUFBTTtvQkFDakMsSUFBSSxXQUFXLEdBQUcsVUFBUyxDQUFDO3dCQUMxQixtREFBbUQ7d0JBQ25ELHlEQUF5RDt3QkFDekQsT0FBTyxDQUFDLFdBQVcsQ0FBQyxTQUFTLEdBQUcsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDO3dCQUN4QyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQ1osQ0FBQyxDQUFDO29CQUVGLCtEQUErRDtvQkFDL0QsT0FBTyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQztvQkFDeEIscUVBQXFFO29CQUNyRSxnQkFBZ0I7b0JBQ2hCLFVBQVUsQ0FBQzt3QkFDVCxJQUFJOzRCQUNGLElBQUksT0FBSyxHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQzs0QkFDdkIsSUFBSSxFQUFFO2lDQUNELElBQUksQ0FBQyxVQUFTLEtBQUs7Z0NBQ2xCLG9CQUFvQjtnQ0FDcEIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLElBQUksQ0FBQyxHQUFHLEVBQUUsR0FBRyxPQUFLLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0NBQ2hELDZCQUE2QjtnQ0FDN0IsT0FBTyxDQUFDLGNBQWMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO2dDQUN6QywrQ0FBK0M7Z0NBQy9DLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQzs0QkFDakIsQ0FBQyxDQUFDO2lDQUNELEtBQUssQ0FBQyxXQUFXLENBQUMsQ0FBQzt5QkFDekI7d0JBQUMsT0FBTyxDQUFDLEVBQUU7NEJBQ1YsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDO3lCQUNoQjtvQkFDSCxDQUFDLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQztnQkFDdkIsQ0FBQyxDQUFDLENBQUM7WUFDTCxDQUFDO1lBakNlLHdCQUFtQixzQkFpQ2xDLENBQUE7WUFFRDs7O2VBR0c7WUFDSCw2QkFBb0MsYUFBcUI7Z0JBQ3ZELE9BQU8sYUFBYSxDQUFDLE9BQU8sQ0FBQyxxQkFBcUIsRUFBRSxNQUFNLENBQUMsQ0FBQztZQUM5RCxDQUFDO1lBRmUsd0JBQW1CLHNCQUVsQyxDQUFBO1lBRUQsdUJBQXVCO1lBQ1YsaUJBQVksR0FBRztnQkFDMUIsZUFBZTtnQkFDZixFQUFDLE1BQU0sRUFBRSxHQUFHLEVBQUM7Z0JBQ2IsaUVBQWlFO2dCQUNqRSxFQUFDLE1BQU0sRUFBRSxJQUFJLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBQyxFQUFFLEVBQUMsTUFBTSxFQUFFLElBQUksRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFDO2dCQUM5RCxFQUFDLE1BQU0sRUFBRSxJQUFJLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBQyxFQUFFLEVBQUMsTUFBTSxFQUFFLElBQUksRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFDO2dCQUM5RCxFQUFDLE1BQU0sRUFBRSxJQUFJLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBQzthQUMvQixDQUFDO1lBQ1csZUFBVSxHQUFHO2dCQUN4QixpRUFBaUU7Z0JBQ2pFLEVBQUMsTUFBTSxFQUFFLElBQUksRUFBQztnQkFDZCxpRUFBaUU7Z0JBQ2pFLEVBQUMsTUFBTSxFQUFFLElBQUksRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFDLEVBQUUsRUFBQyxNQUFNLEVBQUUsR0FBRyxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUM7Z0JBQzdELEVBQUMsTUFBTSxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUUsRUFBRSxFQUFDLEVBQUUsRUFBQyxNQUFNLEVBQUUsSUFBSSxFQUFFLFFBQVEsRUFBRSxFQUFFLEVBQUM7Z0JBQzNELEVBQUMsTUFBTSxFQUFFLE1BQU0sRUFBRSxRQUFRLEVBQUUsRUFBRSxFQUFDO2FBQy9CLENBQUM7WUFFRjs7O2VBR0c7WUFDSCxxQ0FBNEMsS0FBSyxFQUFFLEtBQUssRUFBRSxTQUFTO2dCQUNqRSxTQUFTLEdBQUcsU0FBUyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUM7Z0JBQzlDLElBQUksU0FBUyxHQUFHLENBQUMsR0FBRyxLQUFLLENBQUMsTUFBTTtvQkFDNUIsS0FBSyxJQUFJLEtBQUssQ0FBQyxTQUFTLEdBQUcsQ0FBQyxDQUFDLENBQUMsUUFBUSxFQUFFO29CQUMxQyxPQUFPLEVBQUUsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLDJCQUEyQixDQUM1QyxLQUFLLEdBQUcsS0FBSyxDQUFDLFNBQVMsR0FBRyxDQUFDLENBQUMsQ0FBQyxRQUFRLEVBQUUsS0FBSyxFQUFFLFNBQVMsR0FBRyxDQUFDLENBQUMsQ0FBQztpQkFDbEU7Z0JBQ0Qsa0VBQWtFO2dCQUNsRSwrREFBK0Q7Z0JBQy9ELE9BQU8sQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLEdBQUcsR0FBRyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsTUFBTSxDQUFDO1lBQ3BFLENBQUM7WUFWZSxnQ0FBMkIsOEJBVTFDLENBQUE7WUFFRCxpQ0FBd0MsS0FBZ0I7Z0JBQ3RELElBQUksS0FBSztvQkFDTCxDQUFDLEtBQUssQ0FBQyxVQUFVLEdBQUcsQ0FBQyxJQUFJLEtBQUssQ0FBQyxjQUFjLEVBQUUsR0FBRyxDQUFDO3dCQUNsRCxLQUFLLENBQUMsVUFBVSxDQUFDLEVBQUU7b0JBQ3RCLE9BQU8sSUFBSSxDQUFDO2lCQUNiO2dCQUNELE9BQU8sS0FBSyxDQUFDO1lBQ2YsQ0FBQztZQVBlLDRCQUF1QiwwQkFPdEMsQ0FBQTtZQUVEOzs7O2VBSUc7WUFDSCw0QkFBbUMsT0FBaUI7Z0JBQ2xELElBQUksT0FBTyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7b0JBQ3RCLE9BQU8sT0FBTyxDQUFDO2lCQUNoQjtnQkFFRCxJQUFJLEtBQUssR0FBRyxDQUFDLENBQUM7Z0JBQ2QsSUFBSSxZQUFZLEdBQUcsQ0FBQyxDQUFDO2dCQUNyQiw2Q0FBNkM7Z0JBQzdDLElBQUksU0FBUyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxPQUFPLEVBQUUsVUFBQSxHQUFHLElBQUksT0FBQSxHQUFHLENBQUMsTUFBTSxFQUFWLENBQVUsQ0FBQyxDQUFDLENBQUM7O29CQUV2RCxLQUFLLEVBQUUsQ0FBQztvQkFDUixJQUFJLFFBQVEsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLE9BQU8sRUFBRSxVQUFBLEdBQUcsSUFBSSxPQUFBLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxFQUF2QixDQUF1QixDQUFDLENBQUM7b0JBQzlELElBQUksVUFBVSxHQUFHLFFBQVEsQ0FBQyxLQUFLLENBQUMsVUFBQyxNQUFNLEVBQUUsQ0FBQzt3QkFDeEMsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsTUFBTSxLQUFLLFFBQVEsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDdkQsQ0FBQyxDQUFDLENBQUM7b0JBQ0gsSUFBSSxVQUFVLEVBQUU7d0JBQ2QsSUFBSSxLQUFLLElBQUksU0FBUyxFQUFFOzRDQUdmLE9BQU87eUJBQ2Y7d0JBQ0QsWUFBWSxHQUFHLEtBQUssQ0FBQztxQkFDdEI7eUJBQU07O3FCQUVOO2dCQUNILENBQUM7Z0JBaEJELE9BQU8sSUFBSTs7Ozs7O2lCQWdCVjtnQkFDRCxPQUFPLENBQUMsQ0FBQyxHQUFHLENBQUMsT0FBTyxFQUFFLFVBQUEsR0FBRyxJQUFJLE9BQUEsR0FBRyxDQUFDLFNBQVMsQ0FBQyxZQUFZLENBQUMsRUFBM0IsQ0FBMkIsQ0FBQyxDQUFDO1lBQzVELENBQUM7WUEzQmUsdUJBQWtCLHFCQTJCakMsQ0FBQTtZQUVEOztlQUVHO1lBQ0gsd0JBQStCLFdBQW1CO2dCQUNoRCxJQUFJLFdBQVcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxFQUFFO29CQUNqQyxXQUFXLEdBQUcsV0FBVyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztpQkFDcEM7Z0JBRUQsSUFBSSxXQUFXLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO3FCQUMxQixHQUFHLENBQUMsVUFBQyxJQUFJO29CQUNSLElBQUksSUFBSSxFQUFFO3dCQUNSLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztxQkFDeEI7Z0JBQ0gsQ0FBQyxDQUFDO3FCQUNELE9BQU8sRUFBRTtxQkFDVCxLQUFLLEVBQUUsQ0FBQztnQkFFL0IsT0FBTyxDQUFDLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxDQUFDO1lBQy9CLENBQUM7WUFmZSxtQkFBYyxpQkFlN0IsQ0FBQTtZQUVEOzs7ZUFHRztZQUNILGtDQUF5QyxrQkFBMEI7Z0JBQ2pFLElBQUksa0JBQWtCLEdBQ2xCLENBQUMsQ0FBQyxJQUFJLElBQUksRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksSUFBSSxDQUFDLGtCQUFrQixHQUFHLEdBQUcsQ0FBQyxDQUFDLENBQUM7Z0JBQzFELElBQUksa0JBQWtCLEdBQUcsS0FBSyxFQUFFO29CQUM5QixPQUFPLFVBQVUsQ0FBQztpQkFDbkI7cUJBQU0sSUFBSSxrQkFBa0IsR0FBRyxLQUFLLEVBQUU7b0JBQ3JDLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxrQkFBa0IsR0FBRyxJQUFJLENBQUMsR0FBRyxjQUFjLENBQUM7aUJBQy9EO3FCQUFNLElBQUksa0JBQWtCLEdBQUcsTUFBTSxFQUFFO29CQUN0QyxPQUFPLGNBQWMsQ0FBQztpQkFDdkI7cUJBQU0sSUFBSSxrQkFBa0IsR0FBRyxPQUFPLEVBQUU7b0JBQ3ZDLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxrQkFBa0IsR0FBRyxLQUFLLENBQUMsR0FBRyxjQUFjLENBQUM7aUJBQ2hFO3FCQUFNLElBQUksSUFBSSxDQUFDLEtBQUssQ0FBQyxrQkFBa0IsR0FBRyxPQUFPLENBQUMsSUFBSSxDQUFDLEVBQUU7b0JBQ3hELE9BQU8sYUFBYSxDQUFDO2lCQUN0QjtxQkFBTSxJQUFJLGtCQUFrQixHQUFHLFFBQVEsRUFBRTtvQkFDeEMsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLGtCQUFrQixHQUFHLE9BQU8sQ0FBQyxHQUFHLFlBQVksQ0FBQztpQkFDaEU7cUJBQU0sSUFBSSxrQkFBa0IsR0FBRyxTQUFTLEVBQUU7b0JBQ3pDLE9BQU8sV0FBVyxDQUFDO2lCQUNwQjtnQkFDRCxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsa0JBQWtCLEdBQUcsUUFBUSxDQUFDLEdBQUcsV0FBVyxDQUFDO1lBQ2pFLENBQUM7WUFuQmUsNkJBQXdCLDJCQW1CdkMsQ0FBQTtRQUNILENBQUMsRUF4U2UsSUFBSSxHQUFKLFVBQUksS0FBSixVQUFJLFFBd1NuQjtJQUFELENBQUMsRUF4U1MsS0FBSyxHQUFMLFFBQUssS0FBTCxRQUFLLFFBd1NkO0FBQUQsQ0FBQyxFQXhTTSxFQUFFLEtBQUYsRUFBRSxRQXdTUiIsInNvdXJjZXNDb250ZW50IjpbIi8qIENvcHlyaWdodCAyMDE1IFRoZSBUZW5zb3JGbG93IEF1dGhvcnMuIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG5cbkxpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSAnTGljZW5zZScpO1xueW91IG1heSBub3QgdXNlIHRoaXMgZmlsZSBleGNlcHQgaW4gY29tcGxpYW5jZSB3aXRoIHRoZSBMaWNlbnNlLlxuWW91IG1heSBvYnRhaW4gYSBjb3B5IG9mIHRoZSBMaWNlbnNlIGF0XG5cbiAgICBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcblxuVW5sZXNzIHJlcXVpcmVkIGJ5IGFwcGxpY2FibGUgbGF3IG9yIGFncmVlZCB0byBpbiB3cml0aW5nLCBzb2Z0d2FyZVxuZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIExpY2Vuc2UgaXMgZGlzdHJpYnV0ZWQgb24gYW4gJ0FTIElTJyBCQVNJUyxcbldJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWSBLSU5ELCBlaXRoZXIgZXhwcmVzcyBvciBpbXBsaWVkLlxuU2VlIHRoZSBMaWNlbnNlIGZvciB0aGUgc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nIHBlcm1pc3Npb25zIGFuZFxubGltaXRhdGlvbnMgdW5kZXIgdGhlIExpY2Vuc2UuXG49PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0qL1xuXG4vKipcbiAqIEBmaWxlb3ZlcnZpZXcgVXRpbGl0eSBmdW5jdGlvbnMgZm9yIHRoZSB0ZW5zb3JmbG93IGdyYXBoIHZpc3VhbGl6ZXIuXG4gKi9cblxubW9kdWxlIHRmLmdyYXBoLnV0aWwge1xuICAvKipcbiAgICogUmVjb21tZW5kZWQgZGVsYXkgKG1zKSB3aGVuIHJ1bm5pbmcgYW4gZXhwZW5zaXZlIHRhc2sgYXN5bmNocm9ub3VzbHlcbiAgICogdGhhdCBnaXZlcyBlbm91Z2ggdGltZSBmb3IgdGhlIHByb2dyZXNzIGJhciB0byB1cGRhdGUgaXRzIFVJLlxuICAgKi9cbiAgY29uc3QgQVNZTkNfVEFTS19ERUxBWSA9IDIwO1xuXG4gIGV4cG9ydCBmdW5jdGlvbiB0aW1lPFQ+KG1zZzogc3RyaW5nLCB0YXNrOiAoKSA9PiBUKSB7XG4gICAgbGV0IHN0YXJ0ID0gRGF0ZS5ub3coKTtcbiAgICBsZXQgcmVzdWx0ID0gdGFzaygpO1xuICAgIC8qIHRzbGludDpkaXNhYmxlICovXG4gICAgY29uc29sZS5sb2cobXNnLCAnOicsIERhdGUubm93KCkgLSBzdGFydCwgJ21zJyk7XG4gICAgLyogdHNsaW50OmVuYWJsZSAqL1xuICAgIHJldHVybiByZXN1bHQ7XG4gIH1cblxuICAvKipcbiAgICogQ3JlYXRlcyBhIHRyYWNrZXIgdGhhdCBzZXRzIHRoZSBwcm9ncmVzcyBwcm9wZXJ0eSBvZiB0aGVcbiAgICogcHJvdmlkZWQgcG9seW1lciBjb21wb25lbnQuIFRoZSBwcm92aWRlZCBjb21wb25lbnQgbXVzdCBoYXZlXG4gICAqIGEgcHJvcGVydHkgY2FsbGVkICdwcm9ncmVzcycgdGhhdCBpcyBub3QgcmVhZC1vbmx5LiBUaGUgcHJvZ3Jlc3NcbiAgICogcHJvcGVydHkgaXMgYW4gb2JqZWN0IHdpdGggYSBudW1lcmljYWwgJ3ZhbHVlJyBwcm9wZXJ0eSBhbmQgYVxuICAgKiBzdHJpbmcgJ21zZycgcHJvcGVydHkuXG4gICAqL1xuICBleHBvcnQgZnVuY3Rpb24gZ2V0VHJhY2tlcihwb2x5bWVyQ29tcG9uZW50OiBhbnkpIHtcbiAgICByZXR1cm4ge1xuICAgICAgc2V0TWVzc2FnZTogZnVuY3Rpb24obXNnKSB7XG4gICAgICAgIHBvbHltZXJDb21wb25lbnQuc2V0KFxuICAgICAgICAgICAgJ3Byb2dyZXNzJywge3ZhbHVlOiBwb2x5bWVyQ29tcG9uZW50LnByb2dyZXNzLnZhbHVlLCBtc2c6IG1zZ30pO1xuICAgICAgfSxcbiAgICAgIHVwZGF0ZVByb2dyZXNzOiBmdW5jdGlvbih2YWx1ZSkge1xuICAgICAgICBwb2x5bWVyQ29tcG9uZW50LnNldCgncHJvZ3Jlc3MnLCB7XG4gICAgICAgICAgdmFsdWU6IHBvbHltZXJDb21wb25lbnQucHJvZ3Jlc3MudmFsdWUgKyB2YWx1ZSxcbiAgICAgICAgICBtc2c6IHBvbHltZXJDb21wb25lbnQucHJvZ3Jlc3MubXNnXG4gICAgICAgIH0pO1xuICAgICAgfSxcbiAgICAgIHJlcG9ydEVycm9yOiBmdW5jdGlvbihtc2c6IHN0cmluZywgZXJyKSB7XG4gICAgICAgIC8vIExvZyB0aGUgc3RhY2sgdHJhY2UgaW4gdGhlIGNvbnNvbGUuXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoZXJyLnN0YWNrKTtcbiAgICAgICAgLy8gQW5kIHNlbmQgYSB1c2VyLWZyaWVuZGx5IG1lc3NhZ2UgdG8gdGhlIFVJLlxuICAgICAgICBwb2x5bWVyQ29tcG9uZW50LnNldChcbiAgICAgICAgICAgICdwcm9ncmVzcycsXG4gICAgICAgICAgICB7dmFsdWU6IHBvbHltZXJDb21wb25lbnQucHJvZ3Jlc3MudmFsdWUsIG1zZzogbXNnLCBlcnJvcjogdHJ1ZX0pO1xuICAgICAgfSxcbiAgICB9O1xuICB9XG5cbiAgLyoqXG4gICAqIENyZWF0ZXMgYSB0cmFja2VyIGZvciBhIHN1YnRhc2sgZ2l2ZW4gdGhlIHBhcmVudCB0cmFja2VyLCB0aGUgdG90YWxcbiAgICogcHJvZ3Jlc3NcbiAgICogb2YgdGhlIHN1YnRhc2sgYW5kIHRoZSBzdWJ0YXNrIG1lc3NhZ2UuIFRoZSBwYXJlbnQgdGFzayBzaG91bGQgcGFzcyBhXG4gICAqIHN1YnRyYWNrZXIgdG8gaXRzIHN1YnRhc2tzLiBUaGUgc3VidGFzayByZXBvcnRzIGl0cyBvd24gcHJvZ3Jlc3Mgd2hpY2hcbiAgICogYmVjb21lcyByZWxhdGl2ZSB0byB0aGUgbWFpbiB0YXNrLlxuICAgKi9cbiAgZXhwb3J0IGZ1bmN0aW9uIGdldFN1YnRhc2tUcmFja2VyKFxuICAgICAgcGFyZW50VHJhY2tlcjogUHJvZ3Jlc3NUcmFja2VyLCBpbXBhY3RPblRvdGFsUHJvZ3Jlc3M6IG51bWJlcixcbiAgICAgIHN1YnRhc2tNc2c6IHN0cmluZyk6IFByb2dyZXNzVHJhY2tlciB7XG4gICAgcmV0dXJuIHtcbiAgICAgIHNldE1lc3NhZ2U6IGZ1bmN0aW9uKHByb2dyZXNzTXNnKSB7XG4gICAgICAgIC8vIFRoZSBwYXJlbnQgc2hvdWxkIHNob3cgYSBjb25jYXRlbmF0aW9uIG9mIGl0cyBtZXNzYWdlIGFsb25nIHdpdGhcbiAgICAgICAgLy8gaXRzIHN1YnRhc2sgdHJhY2tlciBtZXNzYWdlLlxuICAgICAgICBwYXJlbnRUcmFja2VyLnNldE1lc3NhZ2Uoc3VidGFza01zZyArICc6ICcgKyBwcm9ncmVzc01zZyk7XG4gICAgICB9LFxuICAgICAgdXBkYXRlUHJvZ3Jlc3M6IGZ1bmN0aW9uKGluY3JlbWVudFZhbHVlKSB7XG4gICAgICAgIC8vIFVwZGF0ZSB0aGUgcGFyZW50IHByb2dyZXNzIHJlbGF0aXZlIHRvIHRoZSBjaGlsZCBwcm9ncmVzcy5cbiAgICAgICAgLy8gRm9yIGV4YW1wbGUsIGlmIHRoZSBzdWItdGFzayBwcm9ncmVzc2VzIGJ5IDMwJSwgYW5kIHRoZSBpbXBhY3Qgb24gdGhlXG4gICAgICAgIC8vIHRvdGFsIHByb2dyZXNzIGlzIDUwJSwgdGhlbiB0aGUgdGFzayBwcm9ncmVzc2VzIGJ5IDMwJSAqIDUwJSA9IDE1JS5cbiAgICAgICAgcGFyZW50VHJhY2tlci51cGRhdGVQcm9ncmVzcyhcbiAgICAgICAgICAgIGluY3JlbWVudFZhbHVlICogaW1wYWN0T25Ub3RhbFByb2dyZXNzIC8gMTAwKTtcbiAgICAgIH0sXG4gICAgICByZXBvcnRFcnJvcjogZnVuY3Rpb24obXNnOiBzdHJpbmcsIGVycjogRXJyb3IpIHtcbiAgICAgICAgLy8gVGhlIHBhcmVudCBzaG91bGQgc2hvdyBhIGNvbmNhdGVuYXRpb24gb2YgaXRzIG1lc3NhZ2UgYWxvbmcgd2l0aFxuICAgICAgICAvLyBpdHMgc3VidGFzayBlcnJvciBtZXNzYWdlLlxuICAgICAgICBwYXJlbnRUcmFja2VyLnJlcG9ydEVycm9yKHN1YnRhc2tNc2cgKyAnOiAnICsgbXNnLCBlcnIpO1xuICAgICAgfVxuICAgIH07XG4gIH1cblxuICAvKipcbiAgICogUnVucyBhbiBleHBlbnNpdmUgdGFzayBhbmQgcmV0dXJuIHRoZSByZXN1bHQuXG4gICAqL1xuICBleHBvcnQgZnVuY3Rpb24gcnVuVGFzazxUPihcbiAgICAgIG1zZzogc3RyaW5nLCBpbmNQcm9ncmVzc1ZhbHVlOiBudW1iZXIsIHRhc2s6ICgpID0+IFQsXG4gICAgICB0cmFja2VyOiBQcm9ncmVzc1RyYWNrZXIpOiBUIHtcbiAgICAvLyBVcGRhdGUgdGhlIHByb2dyZXNzIG1lc3NhZ2UgdG8gc2F5IHRoZSBjdXJyZW50IHJ1bm5pbmcgdGFzay5cbiAgICB0cmFja2VyLnNldE1lc3NhZ2UobXNnKTtcbiAgICAvLyBSdW4gdGhlIGV4cGVuc2l2ZSB0YXNrIHdpdGggYSBkZWxheSB0aGF0IGdpdmVzIGVub3VnaCB0aW1lIGZvciB0aGVcbiAgICAvLyBVSSB0byB1cGRhdGUuXG4gICAgdHJ5IHtcbiAgICAgIGxldCByZXN1bHQgPSB0Zi5ncmFwaC51dGlsLnRpbWUobXNnLCB0YXNrKTtcbiAgICAgIC8vIFVwZGF0ZSB0aGUgcHJvZ3Jlc3MgdmFsdWUuXG4gICAgICB0cmFja2VyLnVwZGF0ZVByb2dyZXNzKGluY1Byb2dyZXNzVmFsdWUpO1xuICAgICAgLy8gUmV0dXJuIHRoZSByZXN1bHQgdG8gYmUgdXNlZCBieSBvdGhlciB0YXNrcy5cbiAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgLy8gRXJyb3JzIHRoYXQgaGFwcGVuIGluc2lkZSBhc3luY2hyb25vdXMgdGFza3MgYXJlXG4gICAgICAvLyByZXBvcnRlZCB0byB0aGUgdHJhY2tlciB1c2luZyBhIHVzZXItZnJpZW5kbHkgbWVzc2FnZS5cbiAgICAgIHRyYWNrZXIucmVwb3J0RXJyb3IoJ0ZhaWxlZCAnICsgbXNnLCBlKTtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogUnVucyBhbiBleHBlbnNpdmUgdGFzayBhc3luY2hyb25vdXNseSBhbmQgcmV0dXJucyBhIHByb21pc2Ugb2YgdGhlIHJlc3VsdC5cbiAgICovXG4gIGV4cG9ydCBmdW5jdGlvbiBydW5Bc3luY1Rhc2s8VD4oXG4gICAgICBtc2c6IHN0cmluZywgaW5jUHJvZ3Jlc3NWYWx1ZTogbnVtYmVyLCB0YXNrOiAoKSA9PiBULFxuICAgICAgdHJhY2tlcjogUHJvZ3Jlc3NUcmFja2VyKTogUHJvbWlzZTxUPiB7XG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgIC8vIFVwZGF0ZSB0aGUgcHJvZ3Jlc3MgbWVzc2FnZSB0byBzYXkgdGhlIGN1cnJlbnQgcnVubmluZyB0YXNrLlxuICAgICAgdHJhY2tlci5zZXRNZXNzYWdlKG1zZyk7XG4gICAgICAvLyBSdW4gdGhlIGV4cGVuc2l2ZSB0YXNrIHdpdGggYSBkZWxheSB0aGF0IGdpdmVzIGVub3VnaCB0aW1lIGZvciB0aGVcbiAgICAgIC8vIFVJIHRvIHVwZGF0ZS5cbiAgICAgIHNldFRpbWVvdXQoZnVuY3Rpb24oKSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgbGV0IHJlc3VsdCA9IHRmLmdyYXBoLnV0aWwudGltZShtc2csIHRhc2spO1xuICAgICAgICAgIC8vIFVwZGF0ZSB0aGUgcHJvZ3Jlc3MgdmFsdWUuXG4gICAgICAgICAgdHJhY2tlci51cGRhdGVQcm9ncmVzcyhpbmNQcm9ncmVzc1ZhbHVlKTtcbiAgICAgICAgICAvLyBSZXR1cm4gdGhlIHJlc3VsdCB0byBiZSB1c2VkIGJ5IG90aGVyIHRhc2tzLlxuICAgICAgICAgIHJlc29sdmUocmVzdWx0KTtcbiAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgIC8vIEVycm9ycyB0aGF0IGhhcHBlbiBpbnNpZGUgYXN5bmNocm9ub3VzIHRhc2tzIGFyZVxuICAgICAgICAgIC8vIHJlcG9ydGVkIHRvIHRoZSB0cmFja2VyIHVzaW5nIGEgdXNlci1mcmllbmRseSBtZXNzYWdlLlxuICAgICAgICAgIHRyYWNrZXIucmVwb3J0RXJyb3IoJ0ZhaWxlZCAnICsgbXNnLCBlKTtcbiAgICAgICAgfVxuICAgICAgfSwgQVNZTkNfVEFTS19ERUxBWSk7XG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogQXN5bmNocm9ub3VzbHkgcnVucyBhbiBleHBlbnNpdmUgdGFzayB0aGF0IHJldHVybnMgYSBwcm9taXNlLiBVcGRhdGVzIHRoZVxuICAgKiB0cmFja2VyJ3MgcHJvZ3Jlc3MgYWZ0ZXIgdGhlIHByb21pc2UgcmVzb2x2ZXMuIFJldHVybnMgYSBuZXcgcHJvbWlzZSB0aGF0XG4gICAqIHJlc29sdmVzIGFmdGVyIHRoZSBwcm9ncmVzcyBpcyB1cGRhdGVkLlxuICAgKi9cbiAgZXhwb3J0IGZ1bmN0aW9uIHJ1bkFzeW5jUHJvbWlzZVRhc2s8VD4oXG4gICAgICBtc2c6IHN0cmluZywgaW5jUHJvZ3Jlc3NWYWx1ZTogbnVtYmVyLCB0YXNrOiAoKSA9PiBQcm9taXNlPFQ+LFxuICAgICAgdHJhY2tlcjogUHJvZ3Jlc3NUcmFja2VyKTogUHJvbWlzZTxUPiB7XG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgIGxldCBoYW5kbGVFcnJvciA9IGZ1bmN0aW9uKGUpIHtcbiAgICAgICAgLy8gRXJyb3JzIHRoYXQgaGFwcGVuIGluc2lkZSBhc3luY2hyb25vdXMgdGFza3MgYXJlXG4gICAgICAgIC8vIHJlcG9ydGVkIHRvIHRoZSB0cmFja2VyIHVzaW5nIGEgdXNlci1mcmllbmRseSBtZXNzYWdlLlxuICAgICAgICB0cmFja2VyLnJlcG9ydEVycm9yKCdGYWlsZWQgJyArIG1zZywgZSk7XG4gICAgICAgIHJlamVjdChlKTtcbiAgICAgIH07XG5cbiAgICAgIC8vIFVwZGF0ZSB0aGUgcHJvZ3Jlc3MgbWVzc2FnZSB0byBzYXkgdGhlIGN1cnJlbnQgcnVubmluZyB0YXNrLlxuICAgICAgdHJhY2tlci5zZXRNZXNzYWdlKG1zZyk7XG4gICAgICAvLyBSdW4gdGhlIGV4cGVuc2l2ZSB0YXNrIHdpdGggYSBkZWxheSB0aGF0IGdpdmVzIGVub3VnaCB0aW1lIGZvciB0aGVcbiAgICAgIC8vIFVJIHRvIHVwZGF0ZS5cbiAgICAgIHNldFRpbWVvdXQoZnVuY3Rpb24oKSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgbGV0IHN0YXJ0ID0gRGF0ZS5ub3coKTtcbiAgICAgICAgICB0YXNrKClcbiAgICAgICAgICAgICAgLnRoZW4oZnVuY3Rpb24odmFsdWUpIHtcbiAgICAgICAgICAgICAgICAvKiB0c2xpbnQ6ZGlzYWJsZSAqL1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKG1zZywgJzonLCBEYXRlLm5vdygpIC0gc3RhcnQsICdtcycpO1xuICAgICAgICAgICAgICAgIC8vIFVwZGF0ZSB0aGUgcHJvZ3Jlc3MgdmFsdWUuXG4gICAgICAgICAgICAgICAgdHJhY2tlci51cGRhdGVQcm9ncmVzcyhpbmNQcm9ncmVzc1ZhbHVlKTtcbiAgICAgICAgICAgICAgICAvLyBSZXR1cm4gdGhlIHJlc3VsdCB0byBiZSB1c2VkIGJ5IG90aGVyIHRhc2tzLlxuICAgICAgICAgICAgICAgIHJlc29sdmUodmFsdWUpO1xuICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAuY2F0Y2goaGFuZGxlRXJyb3IpO1xuICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgaGFuZGxlRXJyb3IoZSk7XG4gICAgICAgIH1cbiAgICAgIH0sIEFTWU5DX1RBU0tfREVMQVkpO1xuICAgIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybnMgYSBxdWVyeSBzZWxlY3RvciB3aXRoIGVzY2FwZWQgc3BlY2lhbCBjaGFyYWN0ZXJzIHRoYXQgYXJlIG5vdFxuICAgKiBhbGxvd2VkIGluIGEgcXVlcnkgc2VsZWN0b3IuXG4gICAqL1xuICBleHBvcnQgZnVuY3Rpb24gZXNjYXBlUXVlcnlTZWxlY3RvcihxdWVyeVNlbGVjdG9yOiBzdHJpbmcpOiBzdHJpbmcge1xuICAgIHJldHVybiBxdWVyeVNlbGVjdG9yLnJlcGxhY2UoLyhbOi5cXFtcXF0sL1xcXFxcXChcXCldKS9nLCAnXFxcXCQxJyk7XG4gIH1cblxuICAvLyBGb3IgdW5pdCBjb252ZXJzaW9uLlxuICBleHBvcnQgY29uc3QgTUVNT1JZX1VOSVRTID0gW1xuICAgIC8vIEF0b21pYyB1bml0LlxuICAgIHtzeW1ib2w6ICdCJ30sXG4gICAgLy8gbnVtVW5pdHMgc3BlY2lmaWVzIGhvdyBtYW55IHByZXZpb3VzIHVuaXRzIHRoaXMgdW5pdCBjb250YWlucy5cbiAgICB7c3ltYm9sOiAnS0InLCBudW1Vbml0czogMTAyNH0sIHtzeW1ib2w6ICdNQicsIG51bVVuaXRzOiAxMDI0fSxcbiAgICB7c3ltYm9sOiAnR0InLCBudW1Vbml0czogMTAyNH0sIHtzeW1ib2w6ICdUQicsIG51bVVuaXRzOiAxMDI0fSxcbiAgICB7c3ltYm9sOiAnUEInLCBudW1Vbml0czogMTAyNH1cbiAgXTtcbiAgZXhwb3J0IGNvbnN0IFRJTUVfVU5JVFMgPSBbXG4gICAgLy8gQXRvbWljIHVuaXQuIEZpbmVzdCBncmFudWxhcml0eSBpbiBUZW5zb3JGbG93IHN0YXQgY29sbGVjdGlvbi5cbiAgICB7c3ltYm9sOiAnwrVzJ30sXG4gICAgLy8gbnVtVW5pdHMgc3BlY2lmaWVzIGhvdyBtYW55IHByZXZpb3VzIHVuaXRzIHRoaXMgdW5pdCBjb250YWlucy5cbiAgICB7c3ltYm9sOiAnbXMnLCBudW1Vbml0czogMTAwMH0sIHtzeW1ib2w6ICdzJywgbnVtVW5pdHM6IDEwMDB9LFxuICAgIHtzeW1ib2w6ICdtaW4nLCBudW1Vbml0czogNjB9LCB7c3ltYm9sOiAnaHInLCBudW1Vbml0czogNjB9LFxuICAgIHtzeW1ib2w6ICdkYXlzJywgbnVtVW5pdHM6IDI0fVxuICBdO1xuXG4gIC8qKlxuICAgKiBSZXR1cm5zIHRoZSBodW1hbiByZWFkYWJsZSB2ZXJzaW9uIG9mIHRoZSB1bml0LlxuICAgKiAoZS5nLiAxLjM1IEdCLCAyMyBNQiwgMzQgbXMsIDYuNTMgbWluIGV0YykuXG4gICAqL1xuICBleHBvcnQgZnVuY3Rpb24gY29udmVydFVuaXRzVG9IdW1hblJlYWRhYmxlKHZhbHVlLCB1bml0cywgdW5pdEluZGV4KSB7XG4gICAgdW5pdEluZGV4ID0gdW5pdEluZGV4ID09IG51bGwgPyAwIDogdW5pdEluZGV4O1xuICAgIGlmICh1bml0SW5kZXggKyAxIDwgdW5pdHMubGVuZ3RoICYmXG4gICAgICAgIHZhbHVlID49IHVuaXRzW3VuaXRJbmRleCArIDFdLm51bVVuaXRzKSB7XG4gICAgICByZXR1cm4gdGYuZ3JhcGgudXRpbC5jb252ZXJ0VW5pdHNUb0h1bWFuUmVhZGFibGUoXG4gICAgICAgICAgdmFsdWUgLyB1bml0c1t1bml0SW5kZXggKyAxXS5udW1Vbml0cywgdW5pdHMsIHVuaXRJbmRleCArIDEpO1xuICAgIH1cbiAgICAvLyB0b1ByZWNpc2lvbigpIGhhcyB0aGUgdGVuZGVuY3kgdG8gcmV0dXJuIGEgbnVtYmVyIGluIHNjaWVudGlmaWNcbiAgICAvLyBub3RhdGlvbiBhbmQgKG51bWJlciAtIDApIGJyaW5ncyBpdCBiYWNrIHRvIG5vcm1hbCBub3RhdGlvbi5cbiAgICByZXR1cm4gKHZhbHVlLnRvUHJlY2lzaW9uKDMpIC0gMCkgKyAnICcgKyB1bml0c1t1bml0SW5kZXhdLnN5bWJvbDtcbiAgfVxuXG4gIGV4cG9ydCBmdW5jdGlvbiBoYXNEaXNwbGF5YWJsZU5vZGVTdGF0cyhzdGF0czogTm9kZVN0YXRzKSB7XG4gICAgaWYgKHN0YXRzICYmXG4gICAgICAgIChzdGF0cy50b3RhbEJ5dGVzID4gMCB8fCBzdGF0cy5nZXRUb3RhbE1pY3JvcygpID4gMCB8fFxuICAgICAgICAgc3RhdHMub3V0cHV0U2l6ZSkpIHtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cblxuICAvKipcbiAgICogR2l2ZW4gYSBsaXN0IG9mIHN0cmluZ3MsIGl0IHJldHVybnMgYSBuZXcgbGlzdCBvZiBzdHJpbmdzIHdpdGggdGhlIGxvbmdlc3RcbiAgICogY29tbW9uIHByZWZpeCByZW1vdmVkLiBJZiB0aGUgY29tbW9uIHByZWZpeCBpcyBvbmUgb2YgdGhlIHN0cmluZ3MgaW4gdGhlXG4gICAqIGxpc3QsIGl0IHJldHVybnMgdGhlIG9yaWdpbmFsIHN0cmluZ3MuXG4gICAqL1xuICBleHBvcnQgZnVuY3Rpb24gcmVtb3ZlQ29tbW9uUHJlZml4KHN0cmluZ3M6IHN0cmluZ1tdKSB7XG4gICAgaWYgKHN0cmluZ3MubGVuZ3RoIDwgMikge1xuICAgICAgcmV0dXJuIHN0cmluZ3M7XG4gICAgfVxuXG4gICAgbGV0IGluZGV4ID0gMDtcbiAgICBsZXQgbGFyZ2VzdEluZGV4ID0gMDtcbiAgICAvLyBGaW5kIHRoZSBzaG9ydGVzdCBuYW1lIGFjcm9zcyBhbGwgc3RyaW5ncy5cbiAgICBsZXQgbWluTGVuZ3RoID0gXy5taW4oXy5tYXAoc3RyaW5ncywgc3RyID0+IHN0ci5sZW5ndGgpKTtcbiAgICB3aGlsZSAodHJ1ZSkge1xuICAgICAgaW5kZXgrKztcbiAgICAgIGxldCBwcmVmaXhlcyA9IF8ubWFwKHN0cmluZ3MsIHN0ciA9PiBzdHIuc3Vic3RyaW5nKDAsIGluZGV4KSk7XG4gICAgICBsZXQgYWxsVGhlU2FtZSA9IHByZWZpeGVzLmV2ZXJ5KChwcmVmaXgsIGkpID0+IHtcbiAgICAgICAgcmV0dXJuIChpID09PSAwID8gdHJ1ZSA6IHByZWZpeCA9PT0gcHJlZml4ZXNbaSAtIDFdKTtcbiAgICAgIH0pO1xuICAgICAgaWYgKGFsbFRoZVNhbWUpIHtcbiAgICAgICAgaWYgKGluZGV4ID49IG1pbkxlbmd0aCkge1xuICAgICAgICAgIC8vIFRoZXJlIGlzIGEgc3RyaW5nIHdob3NlIHdob2xlIG5hbWUgaXMgYSBwcmVmaXggdG8gb3RoZXIgc3RyaW5nLlxuICAgICAgICAgIC8vIEluIHRoaXMgY2FzZSwgd2UgcmV0dXJuIHRoZSBvcmlnaW5hbCBsaXN0IG9mIHN0cmluZy5cbiAgICAgICAgICByZXR1cm4gc3RyaW5ncztcbiAgICAgICAgfVxuICAgICAgICBsYXJnZXN0SW5kZXggPSBpbmRleDtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gXy5tYXAoc3RyaW5ncywgc3RyID0+IHN0ci5zdWJzdHJpbmcobGFyZ2VzdEluZGV4KSk7XG4gIH1cblxuICAvKipcbiAgICogR2l2ZW4gYSBxdWVyeVN0cmluZywgYWthID9mb289MSZiYXI9MiwgcmV0dXJuIHRoZSBvYmplY3QgcmVwcmVzZW50YXRpb24uXG4gICAqL1xuICBleHBvcnQgZnVuY3Rpb24gZ2V0UXVlcnlQYXJhbXMocXVlcnlTdHJpbmc6IHN0cmluZykge1xuICAgIGlmIChxdWVyeVN0cmluZy5jaGFyQXQoMCkgPT09ICc/Jykge1xuICAgICAgcXVlcnlTdHJpbmcgPSBxdWVyeVN0cmluZy5zbGljZSgxKTtcbiAgICB9XG5cbiAgICBsZXQgcXVlcnlQYXJhbXMgPSBfLmNoYWluKHF1ZXJ5U3RyaW5nLnNwbGl0KCcmJykpXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC5tYXAoKGl0ZW0pID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoaXRlbSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGl0ZW0uc3BsaXQoJz0nKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC5jb21wYWN0KClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLnZhbHVlKCk7XG5cbiAgICByZXR1cm4gXy5vYmplY3QocXVlcnlQYXJhbXMpO1xuICB9XG5cbiAgLyoqXG4gICAqIEdpdmVuIGEgdGltZXN0YW1wIGluIG1pY3Jvc2Vjb25kcywgcmV0dXJuIGEgaHVtYW4tZnJpZW5kbHkgc3RyaW5nIGRlbm90aW5nXG4gICAqIGhvdyBsb25nIGFnbyB0aGUgdGltZXN0YW1wIHdhcy5cbiAgICovXG4gIGV4cG9ydCBmdW5jdGlvbiBjb21wdXRlSHVtYW5GcmllbmRseVRpbWUodGltZUluTWljcm9zZWNvbmRzOiBudW1iZXIpIHtcbiAgICB2YXIgdGltZURpZmZlcmVuY2VJbk1zID1cbiAgICAgICAgKyhuZXcgRGF0ZSgpKSAtICsobmV3IERhdGUodGltZUluTWljcm9zZWNvbmRzIC8gMWUzKSk7XG4gICAgaWYgKHRpbWVEaWZmZXJlbmNlSW5NcyA8IDMwMDAwKSB7XG4gICAgICByZXR1cm4gJ2p1c3Qgbm93JztcbiAgICB9IGVsc2UgaWYgKHRpbWVEaWZmZXJlbmNlSW5NcyA8IDYwMDAwKSB7XG4gICAgICByZXR1cm4gTWF0aC5mbG9vcih0aW1lRGlmZmVyZW5jZUluTXMgLyAxMDAwKSArICcgc2Vjb25kcyBhZ28nO1xuICAgIH0gZWxzZSBpZiAodGltZURpZmZlcmVuY2VJbk1zIDwgMTIwMDAwKSB7XG4gICAgICByZXR1cm4gJ2EgbWludXRlIGFnbyc7XG4gICAgfSBlbHNlIGlmICh0aW1lRGlmZmVyZW5jZUluTXMgPCAzNjAwMDAwKSB7XG4gICAgICByZXR1cm4gTWF0aC5mbG9vcih0aW1lRGlmZmVyZW5jZUluTXMgLyA2MDAwMCkgKyAnIG1pbnV0ZXMgYWdvJztcbiAgICB9IGVsc2UgaWYgKE1hdGguZmxvb3IodGltZURpZmZlcmVuY2VJbk1zIC8gMzYwMDAwMCkgPT0gMSkge1xuICAgICAgcmV0dXJuICdhbiBob3VyIGFnbyc7XG4gICAgfSBlbHNlIGlmICh0aW1lRGlmZmVyZW5jZUluTXMgPCA4NjQwMDAwMCkge1xuICAgICAgcmV0dXJuIE1hdGguZmxvb3IodGltZURpZmZlcmVuY2VJbk1zIC8gMzYwMDAwMCkgKyAnIGhvdXJzIGFnbyc7XG4gICAgfSBlbHNlIGlmICh0aW1lRGlmZmVyZW5jZUluTXMgPCAxNzI4MDAwMDApIHtcbiAgICAgIHJldHVybiAneWVzdGVyZGF5JztcbiAgICB9XG4gICAgcmV0dXJuIE1hdGguZmxvb3IodGltZURpZmZlcmVuY2VJbk1zIC8gODY0MDAwMDApICsgJyBkYXlzIGFnbyc7XG4gIH1cbn1cbiJdfQ==