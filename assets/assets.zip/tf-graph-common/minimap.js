/* Copyright 2015 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the 'License');
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an 'AS IS' BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
var tf;
(function (tf) {
    var scene;
    (function (scene) {
        /** Show minimap when the viewpoint area is less than X% of the whole area. */
        var FRAC_VIEWPOINT_AREA = 0.8;
        var Minimap = /** @class */ (function () {
            /**
             * Constructs a new minimap.
             *
             * @param svg The main svg element.
             * @param zoomG The svg group used for panning and zooming the main svg.
             * @param mainZoom The main zoom behavior.
             * @param minimap The minimap container.
             * @param maxWandH The maximum width/height for the minimap.
             * @param labelPadding Padding in pixels due to the main graph labels.
             */
            function Minimap(svg, zoomG, mainZoom, minimap, maxWandH, labelPadding) {
                var _this = this;
                this.svg = svg;
                this.labelPadding = labelPadding;
                this.zoomG = zoomG;
                this.mainZoom = mainZoom;
                this.maxWandH = maxWandH;
                var $minimap = d3.select(minimap);
                // The minimap will have 2 main components: the canvas showing the content
                // and an svg showing a rectangle of the currently zoomed/panned viewpoint.
                var $minimapSvg = $minimap.select('svg');
                // Make the viewpoint rectangle draggable.
                var $viewpoint = $minimapSvg.select('rect');
                var dragmove = function (d) {
                    _this.viewpointCoord.x = d3.event.x;
                    _this.viewpointCoord.y = d3.event.y;
                    _this.updateViewpoint();
                };
                this.viewpointCoord = { x: 0, y: 0 };
                var drag = d3.drag().subject(Object).on('drag', dragmove);
                $viewpoint.datum(this.viewpointCoord).call(drag);
                // Make the minimap clickable.
                $minimapSvg.on('click', function () {
                    if (d3.event.defaultPrevented) {
                        // This click was part of a drag event, so suppress it.
                        return;
                    }
                    // Update the coordinates of the viewpoint.
                    var width = Number($viewpoint.attr('width'));
                    var height = Number($viewpoint.attr('height'));
                    var clickCoords = d3.mouse($minimapSvg.node());
                    _this.viewpointCoord.x = clickCoords[0] - width / 2;
                    _this.viewpointCoord.y = clickCoords[1] - height / 2;
                    _this.updateViewpoint();
                });
                this.viewpoint = $viewpoint.node();
                this.minimapSvg = $minimapSvg.node();
                this.minimap = minimap;
                this.canvas = $minimap.select('canvas.first').node();
                this.canvasBuffer =
                    $minimap.select('canvas.second').node();
                this.downloadCanvas =
                    $minimap.select('canvas.download').node();
                d3.select(this.downloadCanvas).style('display', 'none');
                this.update();
            }
            /**
             * Updates the position and the size of the viewpoint rectangle.
             * It also notifies the main svg about the new panned position.
             */
            Minimap.prototype.updateViewpoint = function () {
                // Update the coordinates of the viewpoint rectangle.
                d3.select(this.viewpoint)
                    .attr('x', this.viewpointCoord.x)
                    .attr('y', this.viewpointCoord.y);
                // Update the translation vector of the main svg to reflect the
                // new viewpoint.
                var mainX = -this.viewpointCoord.x * this.scaleMain / this.scaleMinimap;
                var mainY = -this.viewpointCoord.y * this.scaleMain / this.scaleMinimap;
                d3.select(this.svg).call(this.mainZoom.transform, d3.zoomIdentity.translate(mainX, mainY).scale(this.scaleMain));
            };
            /**
             * Redraws the minimap. Should be called whenever the main svg
             * was updated (e.g. when a node was expanded).
             */
            Minimap.prototype.update = function () {
                var _this = this;
                var sceneSize = null;
                try {
                    // Get the size of the entire scene.
                    sceneSize = this.zoomG.getBBox();
                    if (sceneSize.width === 0) {
                        // There is no scene anymore. We have been detached from the dom.
                        return;
                    }
                }
                catch (e) {
                    // Firefox produced NS_ERROR_FAILURE if we have been
                    // detached from the dom.
                    return;
                }
                var $download = d3.select('#graphdownload');
                this.download = $download.node();
                $download.on('click', function (d) {
                    _this.download.href = _this.downloadCanvas.toDataURL('image/png');
                });
                var $svg = d3.select(this.svg);
                // Read all the style rules in the document and embed them into the svg.
                // The svg needs to be self contained, i.e. all the style rules need to be
                // embedded so the canvas output matches the origin.
                var stylesText = '';
                for (var k = 0; k < document.styleSheets.length; k++) {
                    try {
                        var cssRules = document.styleSheets[k].cssRules ||
                            document.styleSheets[k].rules;
                        if (cssRules == null) {
                            continue;
                        }
                        for (var i = 0; i < cssRules.length; i++) {
                            // Remove tf-* selectors from the styles.
                            stylesText +=
                                cssRules[i].cssText.replace(/ ?tf-[\w-]+ ?/g, '') + '\n';
                        }
                    }
                    catch (e) {
                        if (e.name !== 'SecurityError') {
                            throw e;
                        }
                    }
                }
                // Temporarily add the css rules to the main svg.
                var svgStyle = $svg.append('style');
                svgStyle.text(stylesText);
                // Temporarily remove the zoom/pan transform from the main svg since we
                // want the minimap to show a zoomed-out and centered view.
                var $zoomG = d3.select(this.zoomG);
                var zoomTransform = $zoomG.attr('transform');
                $zoomG.attr('transform', null);
                // Since we add padding, account for that here.
                sceneSize.height += this.labelPadding * 2;
                sceneSize.width += this.labelPadding * 2;
                // Temporarily assign an explicit width/height to the main svg, since
                // it doesn't have one (uses flex-box), but we need it for the canvas
                // to work.
                $svg
                    .attr('width', sceneSize.width)
                    .attr('height', sceneSize.height);
                // Since the content inside the svg changed (e.g. a node was expanded),
                // the aspect ratio have also changed. Thus, we need to update the scale
                // factor of the minimap. The scale factor is determined such that both
                // the width and height of the minimap are <= maximum specified w/h.
                this.scaleMinimap =
                    this.maxWandH / Math.max(sceneSize.width, sceneSize.height);
                this.minimapSize = {
                    width: sceneSize.width * this.scaleMinimap,
                    height: sceneSize.height * this.scaleMinimap
                };
                // Update the size of the minimap's svg, the buffer canvas and the
                // viewpoint rect.
                d3.select(this.minimapSvg).attr(this.minimapSize);
                d3.select(this.canvasBuffer).attr(this.minimapSize);
                // Download canvas width and height are multiples of the style width and
                // height in order to increase pixel density of the PNG for clarity.
                var downloadCanvasSelection = d3.select(this.downloadCanvas);
                downloadCanvasSelection.style('width', sceneSize.width);
                downloadCanvasSelection.style('height', sceneSize.height);
                downloadCanvasSelection.attr('width', 3 * sceneSize.width);
                downloadCanvasSelection.attr('height', 3 * sceneSize.height);
                if (this.translate != null && this.zoom != null) {
                    // Update the viewpoint rectangle shape since the aspect ratio of the
                    // map has changed.
                    requestAnimationFrame(function () { return _this.zoom(); });
                }
                // Serialize the main svg to a string which will be used as the rendering
                // content for the canvas.
                var svgXml = (new XMLSerializer()).serializeToString(this.svg);
                // Now that the svg is serialized for rendering, remove the temporarily
                // assigned styles, explicit width and height and bring back the pan/zoom
                // transform.
                svgStyle.remove();
                $svg.attr('width', null).attr('height', null);
                $zoomG.attr('transform', zoomTransform);
                var image = new Image();
                image.onload = function () {
                    // Draw the svg content onto the buffer canvas.
                    var context = _this.canvasBuffer.getContext('2d');
                    context.clearRect(0, 0, _this.canvasBuffer.width, _this.canvasBuffer.height);
                    context.drawImage(image, 0, 0, _this.minimapSize.width, _this.minimapSize.height);
                    requestAnimationFrame(function () {
                        var _a;
                        // Hide the old canvas and show the new buffer canvas.
                        d3.select(_this.canvasBuffer).style('display', null);
                        d3.select(_this.canvas).style('display', 'none');
                        // Swap the two canvases.
                        _a = [_this.canvasBuffer, _this.canvas], _this.canvas = _a[0], _this.canvasBuffer = _a[1];
                    });
                    var downloadContext = _this.downloadCanvas.getContext('2d');
                    downloadContext.clearRect(0, 0, _this.downloadCanvas.width, _this.downloadCanvas.height);
                    downloadContext.drawImage(image, 0, 0, _this.downloadCanvas.width, _this.downloadCanvas.height);
                };
                image.onerror = function () {
                    var blob = new Blob([svgXml], { type: 'image/svg+xml;charset=utf-8' });
                    image.src = URL.createObjectURL(blob);
                };
                image.src =
                    'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svgXml);
            };
            /**
             * Handles changes in zooming/panning. Should be called from the main svg
             * to notify that a zoom/pan was performed and this minimap will update it's
             * viewpoint rectangle.
             *
             * @param translate The translate vector, or none to use the last used one.
             * @param scale The scaling factor, or none to use the last used one.
             */
            Minimap.prototype.zoom = function (transform) {
                if (this.scaleMinimap == null) {
                    // Scene is not ready yet.
                    return;
                }
                // Update the new translate and scale params, only if specified.
                if (transform) {
                    this.translate = [transform.x, transform.y];
                    this.scaleMain = transform.k;
                }
                // Update the location of the viewpoint rectangle.
                var svgRect = this.svg.getBoundingClientRect();
                var $viewpoint = d3.select(this.viewpoint);
                this.viewpointCoord.x = -this.translate[0] * this.scaleMinimap /
                    this.scaleMain;
                this.viewpointCoord.y = -this.translate[1] * this.scaleMinimap /
                    this.scaleMain;
                var viewpointWidth = svgRect.width * this.scaleMinimap / this.scaleMain;
                var viewpointHeight = svgRect.height * this.scaleMinimap / this.scaleMain;
                $viewpoint
                    .attr('x', this.viewpointCoord.x)
                    .attr('y', this.viewpointCoord.y)
                    .attr('width', viewpointWidth)
                    .attr('height', viewpointHeight);
                // Show/hide the minimap depending on the viewpoint area as fraction of the
                // whole minimap.
                var mapWidth = this.minimapSize.width;
                var mapHeight = this.minimapSize.height;
                var x = this.viewpointCoord.x;
                var y = this.viewpointCoord.y;
                var w = Math.min(Math.max(0, x + viewpointWidth), mapWidth) -
                    Math.min(Math.max(0, x), mapWidth);
                var h = Math.min(Math.max(0, y + viewpointHeight), mapHeight) -
                    Math.min(Math.max(0, y), mapHeight);
                var fracIntersect = (w * h) / (mapWidth * mapHeight);
                if (fracIntersect < FRAC_VIEWPOINT_AREA) {
                    this.minimap.classList.remove('hidden');
                }
                else {
                    this.minimap.classList.add('hidden');
                }
            };
            return Minimap;
        }());
        scene.Minimap = Minimap;
    })(scene = tf.scene || (tf.scene = {}));
})(tf || (tf = {})); // close module tf.scene
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWluaW1hcC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIm1pbmltYXAudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7Ozs7Ozs7Z0ZBYWdGO0FBQ2hGLElBQU8sRUFBRSxDQTBUUjtBQTFURCxXQUFPLEVBQUU7SUFBQyxJQUFBLEtBQUssQ0EwVGQ7SUExVFMsV0FBQSxLQUFLO1FBRWYsOEVBQThFO1FBQzlFLElBQU0sbUJBQW1CLEdBQVcsR0FBRyxDQUFDO1FBRXhDO1lBdUNFOzs7Ozs7Ozs7ZUFTRztZQUNILGlCQUFZLEdBQWtCLEVBQUUsS0FBa0IsRUFDOUMsUUFBbUMsRUFBRSxPQUFvQixFQUN6RCxRQUFnQixFQUFFLFlBQW9CO2dCQUYxQyxpQkFnREM7Z0JBN0NDLElBQUksQ0FBQyxHQUFHLEdBQUcsR0FBRyxDQUFDO2dCQUNmLElBQUksQ0FBQyxZQUFZLEdBQUcsWUFBWSxDQUFDO2dCQUNqQyxJQUFJLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQztnQkFDbkIsSUFBSSxDQUFDLFFBQVEsR0FBRyxRQUFRLENBQUM7Z0JBQ3pCLElBQUksQ0FBQyxRQUFRLEdBQUcsUUFBUSxDQUFDO2dCQUN6QixJQUFJLFFBQVEsR0FBRyxFQUFFLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDO2dCQUNsQywwRUFBMEU7Z0JBQzFFLDJFQUEyRTtnQkFDM0UsSUFBSSxXQUFXLEdBQUcsUUFBUSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFFekMsMENBQTBDO2dCQUMxQyxJQUFJLFVBQVUsR0FBRyxXQUFXLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDO2dCQUM1QyxJQUFJLFFBQVEsR0FBRyxVQUFDLENBQUM7b0JBQ2YsS0FBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLEdBQWUsRUFBRSxDQUFDLEtBQU0sQ0FBQyxDQUFDLENBQUM7b0JBQ2hELEtBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxHQUFlLEVBQUUsQ0FBQyxLQUFNLENBQUMsQ0FBQyxDQUFDO29CQUNoRCxLQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7Z0JBQ3pCLENBQUMsQ0FBQztnQkFDRixJQUFJLENBQUMsY0FBYyxHQUFHLEVBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFDLENBQUM7Z0JBQ25DLElBQUksSUFBSSxHQUFHLEVBQUUsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLE1BQU0sRUFBRSxRQUFRLENBQUMsQ0FBQztnQkFDMUQsVUFBVSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsY0FBcUIsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFFeEQsOEJBQThCO2dCQUM5QixXQUFXLENBQUMsRUFBRSxDQUFDLE9BQU8sRUFBRTtvQkFDdEIsSUFBWSxFQUFFLENBQUMsS0FBTSxDQUFDLGdCQUFnQixFQUFFO3dCQUN0Qyx1REFBdUQ7d0JBQ3ZELE9BQU87cUJBQ1I7b0JBQ0QsMkNBQTJDO29CQUMzQyxJQUFJLEtBQUssR0FBRyxNQUFNLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO29CQUM3QyxJQUFJLE1BQU0sR0FBRyxNQUFNLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO29CQUMvQyxJQUFJLFdBQVcsR0FBRyxFQUFFLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxJQUFJLEVBQVMsQ0FBQyxDQUFDO29CQUN0RCxLQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsR0FBRyxXQUFXLENBQUMsQ0FBQyxDQUFDLEdBQUcsS0FBSyxHQUFHLENBQUMsQ0FBQztvQkFDbkQsS0FBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLEdBQUcsV0FBVyxDQUFDLENBQUMsQ0FBQyxHQUFHLE1BQU0sR0FBRyxDQUFDLENBQUM7b0JBQ3BELEtBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQztnQkFDekIsQ0FBQyxDQUFDLENBQUM7Z0JBQ0gsSUFBSSxDQUFDLFNBQVMsR0FBbUIsVUFBVSxDQUFDLElBQUksRUFBRSxDQUFDO2dCQUNuRCxJQUFJLENBQUMsVUFBVSxHQUFrQixXQUFXLENBQUMsSUFBSSxFQUFFLENBQUM7Z0JBQ3BELElBQUksQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDO2dCQUN2QixJQUFJLENBQUMsTUFBTSxHQUFzQixRQUFRLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDO2dCQUN4RSxJQUFJLENBQUMsWUFBWTtvQkFDTSxRQUFRLENBQUMsTUFBTSxDQUFDLGVBQWUsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDO2dCQUMvRCxJQUFJLENBQUMsY0FBYztvQkFDSSxRQUFRLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7Z0JBQ2pFLEVBQUUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxTQUFTLEVBQUUsTUFBTSxDQUFDLENBQUM7Z0JBQ3hELElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQztZQUNoQixDQUFDO1lBRUQ7OztlQUdHO1lBQ0ssaUNBQWUsR0FBdkI7Z0JBQ0UscURBQXFEO2dCQUNyRCxFQUFFLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUM7cUJBQ3BCLElBQUksQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUM7cUJBQ2hDLElBQUksQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDdEMsK0RBQStEO2dCQUMvRCxpQkFBaUI7Z0JBQ2pCLElBQUksS0FBSyxHQUFHLENBQUUsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDO2dCQUN6RSxJQUFJLEtBQUssR0FBRyxDQUFFLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQztnQkFDekUsRUFBRSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUNwQixJQUFJLENBQUMsUUFBUSxDQUFDLFNBQVMsRUFDdkIsRUFBRSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUFFLEtBQUssQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQztZQUNyRSxDQUFDO1lBRUQ7OztlQUdHO1lBQ0gsd0JBQU0sR0FBTjtnQkFBQSxpQkFzSUM7Z0JBcklDLElBQUksU0FBUyxHQUFHLElBQUksQ0FBQztnQkFDckIsSUFBSTtvQkFDRixvQ0FBb0M7b0JBQ3BDLFNBQVMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sRUFBRSxDQUFDO29CQUNqQyxJQUFJLFNBQVMsQ0FBQyxLQUFLLEtBQUssQ0FBQyxFQUFFO3dCQUN6QixpRUFBaUU7d0JBQ2pFLE9BQU87cUJBQ1I7aUJBQ0Y7Z0JBQUMsT0FBTyxDQUFDLEVBQUU7b0JBQ1Ysb0RBQW9EO29CQUNwRCx5QkFBeUI7b0JBQ3pCLE9BQU87aUJBQ1I7Z0JBQ0QsSUFBSSxTQUFTLEdBQUcsRUFBRSxDQUFDLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO2dCQUM1QyxJQUFJLENBQUMsUUFBUSxHQUFvQixTQUFTLENBQUMsSUFBSSxFQUFFLENBQUM7Z0JBQ2xELFNBQVMsQ0FBQyxFQUFFLENBQUMsT0FBTyxFQUFFLFVBQUEsQ0FBQztvQkFDckIsS0FBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLEdBQUcsS0FBSSxDQUFDLGNBQWMsQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLENBQUM7Z0JBQ2xFLENBQUMsQ0FBQyxDQUFDO2dCQUVILElBQUksSUFBSSxHQUFHLEVBQUUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUMvQix3RUFBd0U7Z0JBQ3hFLDBFQUEwRTtnQkFDMUUsb0RBQW9EO2dCQUNwRCxJQUFJLFVBQVUsR0FBRyxFQUFFLENBQUM7Z0JBQ3BCLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxRQUFRLENBQUMsV0FBVyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtvQkFDcEQsSUFBSTt3QkFDRixJQUFJLFFBQVEsR0FBUyxRQUFRLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBRSxDQUFDLFFBQVE7NEJBQzlDLFFBQVEsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFFLENBQUMsS0FBSyxDQUFDO3dCQUN2QyxJQUFJLFFBQVEsSUFBSSxJQUFJLEVBQUU7NEJBQ3BCLFNBQVM7eUJBQ1Y7d0JBQ0QsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFFBQVEsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7NEJBQ3hDLHlDQUF5Qzs0QkFDekMsVUFBVTtnQ0FDTixRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxnQkFBZ0IsRUFBRSxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUM7eUJBQzlEO3FCQUNGO29CQUFDLE9BQU8sQ0FBQyxFQUFFO3dCQUNWLElBQUksQ0FBQyxDQUFDLElBQUksS0FBSyxlQUFlLEVBQUU7NEJBQzlCLE1BQU0sQ0FBQyxDQUFDO3lCQUNUO3FCQUNGO2lCQUNGO2dCQUVELGlEQUFpRDtnQkFDakQsSUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQztnQkFDcEMsUUFBUSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztnQkFFMUIsdUVBQXVFO2dCQUN2RSwyREFBMkQ7Z0JBQzNELElBQUksTUFBTSxHQUFHLEVBQUUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUNuQyxJQUFJLGFBQWEsR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO2dCQUM3QyxNQUFNLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFFL0IsK0NBQStDO2dCQUMvQyxTQUFTLENBQUMsTUFBTSxJQUFJLElBQUksQ0FBQyxZQUFZLEdBQUcsQ0FBQyxDQUFDO2dCQUMxQyxTQUFTLENBQUMsS0FBSyxJQUFJLElBQUksQ0FBQyxZQUFZLEdBQUcsQ0FBQyxDQUFDO2dCQUV6QyxxRUFBcUU7Z0JBQ3JFLHFFQUFxRTtnQkFDckUsV0FBVztnQkFDWCxJQUFJO3FCQUNELElBQUksQ0FBQyxPQUFPLEVBQUUsU0FBUyxDQUFDLEtBQUssQ0FBQztxQkFDOUIsSUFBSSxDQUFDLFFBQVEsRUFBRSxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUM7Z0JBRXBDLHVFQUF1RTtnQkFDdkUsd0VBQXdFO2dCQUN4RSx1RUFBdUU7Z0JBQ3ZFLG9FQUFvRTtnQkFDcEUsSUFBSSxDQUFDLFlBQVk7b0JBQ2IsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxLQUFLLEVBQUUsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDO2dCQUVoRSxJQUFJLENBQUMsV0FBVyxHQUFHO29CQUNqQixLQUFLLEVBQUUsU0FBUyxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsWUFBWTtvQkFDMUMsTUFBTSxFQUFFLFNBQVMsQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLFlBQVk7aUJBQzdDLENBQUM7Z0JBRUYsa0VBQWtFO2dCQUNsRSxrQkFBa0I7Z0JBQ2xCLEVBQUUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLElBQUksQ0FBTSxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7Z0JBQ3ZELEVBQUUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksQ0FBTSxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7Z0JBRXpELHdFQUF3RTtnQkFDeEUsb0VBQW9FO2dCQUNwRSxJQUFNLHVCQUF1QixHQUFHLEVBQUUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDO2dCQUMvRCx1QkFBdUIsQ0FBQyxLQUFLLENBQUMsT0FBTyxFQUFFLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFDeEQsdUJBQXVCLENBQUMsS0FBSyxDQUFDLFFBQVEsRUFBRSxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUM7Z0JBQzFELHVCQUF1QixDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQyxHQUFHLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFDM0QsdUJBQXVCLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDLEdBQUcsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDO2dCQUU3RCxJQUFJLElBQUksQ0FBQyxTQUFTLElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxJQUFJLElBQUksSUFBSSxFQUFFO29CQUMvQyxxRUFBcUU7b0JBQ3JFLG1CQUFtQjtvQkFDbkIscUJBQXFCLENBQUMsY0FBTSxPQUFBLEtBQUksQ0FBQyxJQUFJLEVBQUUsRUFBWCxDQUFXLENBQUMsQ0FBQztpQkFDMUM7Z0JBRUQseUVBQXlFO2dCQUN6RSwwQkFBMEI7Z0JBQzFCLElBQUksTUFBTSxHQUFHLENBQUMsSUFBSSxhQUFhLEVBQUUsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFFL0QsdUVBQXVFO2dCQUN2RSx5RUFBeUU7Z0JBQ3pFLGFBQWE7Z0JBQ2IsUUFBUSxDQUFDLE1BQU0sRUFBRSxDQUFDO2dCQUNsQixJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUU5QyxNQUFNLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBRSxhQUFhLENBQUMsQ0FBQztnQkFDeEMsSUFBSSxLQUFLLEdBQUcsSUFBSSxLQUFLLEVBQUUsQ0FBQztnQkFDeEIsS0FBSyxDQUFDLE1BQU0sR0FBRztvQkFDYiwrQ0FBK0M7b0JBQy9DLElBQUksT0FBTyxHQUFHLEtBQUksQ0FBQyxZQUFZLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDO29CQUNqRCxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsS0FBSSxDQUFDLFlBQVksQ0FBQyxLQUFLLEVBQzNDLEtBQUksQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLENBQUM7b0JBQzlCLE9BQU8sQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQzNCLEtBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxFQUFFLEtBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUM7b0JBQ25ELHFCQUFxQixDQUFDOzt3QkFDcEIsc0RBQXNEO3dCQUN0RCxFQUFFLENBQUMsTUFBTSxDQUFDLEtBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxLQUFLLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxDQUFDO3dCQUNwRCxFQUFFLENBQUMsTUFBTSxDQUFDLEtBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxLQUFLLENBQUMsU0FBUyxFQUFFLE1BQU0sQ0FBQyxDQUFDO3dCQUNoRCx5QkFBeUI7d0JBQ3pCLHVDQUFtRSxFQUFsRSxvQkFBVyxFQUFFLDBCQUFpQixDQUFxQztvQkFDdEUsQ0FBQyxDQUFDLENBQUM7b0JBQ0gsSUFBSSxlQUFlLEdBQUcsS0FBSSxDQUFDLGNBQWMsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUM7b0JBQzNELGVBQWUsQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxLQUFJLENBQUMsY0FBYyxDQUFDLEtBQUssRUFDdkQsS0FBSSxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDOUIsZUFBZSxDQUFDLFNBQVMsQ0FBQyxLQUFLLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFDbkMsS0FBSSxDQUFDLGNBQWMsQ0FBQyxLQUFLLEVBQUUsS0FBSSxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsQ0FBQztnQkFDM0QsQ0FBQyxDQUFDO2dCQUNGLEtBQUssQ0FBQyxPQUFPLEdBQUc7b0JBQ2QsSUFBSSxJQUFJLEdBQUcsSUFBSSxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFDLElBQUksRUFBRSw2QkFBNkIsRUFBQyxDQUFDLENBQUM7b0JBQ3JFLEtBQUssQ0FBQyxHQUFHLEdBQUcsR0FBRyxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDeEMsQ0FBQyxDQUFDO2dCQUNGLEtBQUssQ0FBQyxHQUFHO29CQUNMLG1DQUFtQyxHQUFHLGtCQUFrQixDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQ3ZFLENBQUM7WUFFRDs7Ozs7OztlQU9HO1lBQ0gsc0JBQUksR0FBSixVQUFLLFNBQTRCO2dCQUMvQixJQUFJLElBQUksQ0FBQyxZQUFZLElBQUksSUFBSSxFQUFFO29CQUM3QiwwQkFBMEI7b0JBQzFCLE9BQU87aUJBQ1I7Z0JBQ0QsZ0VBQWdFO2dCQUNoRSxJQUFJLFNBQVMsRUFBRTtvQkFDYixJQUFJLENBQUMsU0FBUyxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQzVDLElBQUksQ0FBQyxTQUFTLEdBQUcsU0FBUyxDQUFDLENBQUMsQ0FBQztpQkFDOUI7Z0JBRUQsa0RBQWtEO2dCQUNsRCxJQUFJLE9BQU8sR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLHFCQUFxQixFQUFFLENBQUM7Z0JBQy9DLElBQUksVUFBVSxHQUFHLEVBQUUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO2dCQUMzQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLFlBQVk7b0JBQzFELElBQUksQ0FBQyxTQUFTLENBQUM7Z0JBQ25CLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsWUFBWTtvQkFDMUQsSUFBSSxDQUFDLFNBQVMsQ0FBQztnQkFDbkIsSUFBSSxjQUFjLEdBQUcsT0FBTyxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUM7Z0JBQ3hFLElBQUksZUFBZSxHQUFHLE9BQU8sQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDO2dCQUMxRSxVQUFVO3FCQUNQLElBQUksQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUM7cUJBQ2hDLElBQUksQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUM7cUJBQ2hDLElBQUksQ0FBQyxPQUFPLEVBQUUsY0FBYyxDQUFDO3FCQUM3QixJQUFJLENBQUMsUUFBUSxFQUFFLGVBQWUsQ0FBQyxDQUFDO2dCQUNuQywyRUFBMkU7Z0JBQzNFLGlCQUFpQjtnQkFDakIsSUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUM7Z0JBQ3RDLElBQUksU0FBUyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDO2dCQUN4QyxJQUFJLENBQUMsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQztnQkFDOUIsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUM7Z0JBQzlCLElBQUksQ0FBQyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLGNBQWMsQ0FBQyxFQUFFLFFBQVEsQ0FBQztvQkFDdkQsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxRQUFRLENBQUMsQ0FBQztnQkFDdkMsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUcsZUFBZSxDQUFDLEVBQUUsU0FBUyxDQUFDO29CQUN6RCxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLFNBQVMsQ0FBQyxDQUFDO2dCQUN4QyxJQUFJLGFBQWEsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLFFBQVEsR0FBRyxTQUFTLENBQUMsQ0FBQztnQkFDckQsSUFBSSxhQUFhLEdBQUcsbUJBQW1CLEVBQUU7b0JBQ3ZDLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQztpQkFDekM7cUJBQU07b0JBQ0wsSUFBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDO2lCQUN0QztZQUNILENBQUM7WUFDSCxjQUFDO1FBQUQsQ0FBQyxBQW5URCxJQW1UQztRQW5UWSxhQUFPLFVBbVRuQixDQUFBO0lBRUQsQ0FBQyxFQTFUUyxLQUFLLEdBQUwsUUFBSyxLQUFMLFFBQUssUUEwVGQ7QUFBRCxDQUFDLEVBMVRNLEVBQUUsS0FBRixFQUFFLFFBMFRSLENBQUMsd0JBQXdCIiwic291cmNlc0NvbnRlbnQiOlsiLyogQ29weXJpZ2h0IDIwMTUgVGhlIFRlbnNvckZsb3cgQXV0aG9ycy4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cblxuTGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlLCBWZXJzaW9uIDIuMCAodGhlICdMaWNlbnNlJyk7XG55b3UgbWF5IG5vdCB1c2UgdGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlIHdpdGggdGhlIExpY2Vuc2UuXG5Zb3UgbWF5IG9idGFpbiBhIGNvcHkgb2YgdGhlIExpY2Vuc2UgYXRcblxuICAgIGh0dHA6Ly93d3cuYXBhY2hlLm9yZy9saWNlbnNlcy9MSUNFTlNFLTIuMFxuXG5Vbmxlc3MgcmVxdWlyZWQgYnkgYXBwbGljYWJsZSBsYXcgb3IgYWdyZWVkIHRvIGluIHdyaXRpbmcsIHNvZnR3YXJlXG5kaXN0cmlidXRlZCB1bmRlciB0aGUgTGljZW5zZSBpcyBkaXN0cmlidXRlZCBvbiBhbiAnQVMgSVMnIEJBU0lTLFxuV0lUSE9VVCBXQVJSQU5USUVTIE9SIENPTkRJVElPTlMgT0YgQU5ZIEtJTkQsIGVpdGhlciBleHByZXNzIG9yIGltcGxpZWQuXG5TZWUgdGhlIExpY2Vuc2UgZm9yIHRoZSBzcGVjaWZpYyBsYW5ndWFnZSBnb3Zlcm5pbmcgcGVybWlzc2lvbnMgYW5kXG5saW1pdGF0aW9ucyB1bmRlciB0aGUgTGljZW5zZS5cbj09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSovXG5tb2R1bGUgdGYuc2NlbmUge1xuXG4vKiogU2hvdyBtaW5pbWFwIHdoZW4gdGhlIHZpZXdwb2ludCBhcmVhIGlzIGxlc3MgdGhhbiBYJSBvZiB0aGUgd2hvbGUgYXJlYS4gKi9cbmNvbnN0IEZSQUNfVklFV1BPSU5UX0FSRUE6IG51bWJlciA9IDAuODtcblxuZXhwb3J0IGNsYXNzIE1pbmltYXAge1xuICAvKiogVGhlIG1pbmltYXAgY29udGFpbmVyLiAqL1xuICBwcml2YXRlIG1pbmltYXA6IEhUTUxFbGVtZW50O1xuICAvKiogVGhlIGNhbnZhcyB1c2VkIGZvciBkcmF3aW5nIHRoZSBtaW5pIHZlcnNpb24gb2YgdGhlIHN2Zy4gKi9cbiAgcHJpdmF0ZSBjYW52YXM6IEhUTUxDYW52YXNFbGVtZW50O1xuICAvKiogQSBidWZmZXIgY2FudmFzIHVzZWQgZm9yIHRlbXBvcmFyeSBkcmF3aW5nIHRvIGF2b2lkIGZsaWNrZXJpbmcuICovXG4gIHByaXZhdGUgY2FudmFzQnVmZmVyOiBIVE1MQ2FudmFzRWxlbWVudDtcbiAgcHJpdmF0ZSBkb3dubG9hZDogSFRNTExpbmtFbGVtZW50O1xuICBwcml2YXRlIGRvd25sb2FkQ2FudmFzOiBIVE1MQ2FudmFzRWxlbWVudDtcblxuICAvKiogVGhlIG1pbmltYXAgc3ZnIHVzZWQgZm9yIGhvbGRpbmcgdGhlIHZpZXdwb2ludCByZWN0YW5nbGUuICovXG4gIHByaXZhdGUgbWluaW1hcFN2ZzogU1ZHU1ZHRWxlbWVudDtcbiAgLyoqIFRoZSByZWN0YW5nbGUgc2hvd2luZyB0aGUgY3VycmVudCB2aWV3cG9pbnQuICovXG4gIHByaXZhdGUgdmlld3BvaW50OiBTVkdSZWN0RWxlbWVudDtcbiAgLyoqXG4gICAqIFRoZSBzY2FsZSBmYWN0b3IgZm9yIHRoZSBtaW5pbWFwLiBUaGUgZmFjdG9yIGlzIGRldGVybWluZWQgYXV0b21hdGljYWxseVxuICAgKiBzbyB0aGF0IHRoZSBtaW5pbWFwIGRvZXNuJ3QgdmlvbGF0ZSB0aGUgbWF4aW11bSB3aWR0aC9oZWlnaHQgc3BlY2lmaWVkXG4gICAqIGluIHRoZSBjb25zdHJ1Y3Rvci4gVGhlIG1pbmltYXAgbWFpbnRhaW5zIHRoZSBzYW1lIGFzcGVjdCByYXRpbyBhcyB0aGVcbiAgICogb3JpZ2luYWwgc3ZnLlxuICAgKi9cbiAgcHJpdmF0ZSBzY2FsZU1pbmltYXA6IG51bWJlcjtcbiAgLyoqIFRoZSBtYWluIHN2ZyBlbGVtZW50LiAqL1xuICBwcml2YXRlIHN2ZzogU1ZHU1ZHRWxlbWVudDtcbiAgLyoqIFRoZSBzdmcgZ3JvdXAgdXNlZCBmb3IgcGFubmluZyBhbmQgem9vbWluZyB0aGUgbWFpbiBzdmcuICovXG4gIHByaXZhdGUgem9vbUc6IFNWR0dFbGVtZW50O1xuICAvKiogVGhlIHpvb20gYmVoYXZpb3Igb2YgdGhlIG1haW4gc3ZnLiAqL1xuICBwcml2YXRlIG1haW5ab29tOiBkMy5ab29tQmVoYXZpb3I8YW55LCBhbnk+O1xuICAvKiogVGhlIG1heGltdW0gd2lkdGggYW5kIGhlaWdodCBmb3IgdGhlIG1pbmltYXAuICovXG4gIHByaXZhdGUgbWF4V2FuZEg6IG51bWJlcjtcbiAgLyoqIFRoZSBsYXN0IHRyYW5zbGF0aW9uIHZlY3RvciB1c2VkIGluIHRoZSBtYWluIHN2Zy4gKi9cbiAgcHJpdmF0ZSB0cmFuc2xhdGU6IFtudW1iZXIsIG51bWJlcl07XG4gIC8qKiBUaGUgbGFzdCBzY2FsaW5nIGZhY3RvciB1c2VkIGluIHRoZSBtYWluIHN2Zy4gKi9cbiAgcHJpdmF0ZSBzY2FsZU1haW46IG51bWJlcjtcbiAgLyoqIFRoZSBjb29yZGluYXRlcyBvZiB0aGUgdmlld3BvaW50IHJlY3RhbmdsZS4gKi9cbiAgcHJpdmF0ZSB2aWV3cG9pbnRDb29yZDoge3g6IG51bWJlciwgeTogbnVtYmVyfTtcbiAgLyoqIFRoZSBjdXJyZW50IHNpemUgb2YgdGhlIG1pbmltYXAgKi9cbiAgcHJpdmF0ZSBtaW5pbWFwU2l6ZToge3dpZHRoOiBudW1iZXIsIGhlaWdodDogbnVtYmVyfTtcbiAgLyoqIFBhZGRpbmcgKHB4KSBkdWUgdG8gdGhlIG1haW4gbGFiZWxzIG9mIHRoZSBncmFwaC4gKi9cbiAgcHJpdmF0ZSBsYWJlbFBhZGRpbmc6IG51bWJlcjtcbiAgLyoqXG4gICAqIENvbnN0cnVjdHMgYSBuZXcgbWluaW1hcC5cbiAgICpcbiAgICogQHBhcmFtIHN2ZyBUaGUgbWFpbiBzdmcgZWxlbWVudC5cbiAgICogQHBhcmFtIHpvb21HIFRoZSBzdmcgZ3JvdXAgdXNlZCBmb3IgcGFubmluZyBhbmQgem9vbWluZyB0aGUgbWFpbiBzdmcuXG4gICAqIEBwYXJhbSBtYWluWm9vbSBUaGUgbWFpbiB6b29tIGJlaGF2aW9yLlxuICAgKiBAcGFyYW0gbWluaW1hcCBUaGUgbWluaW1hcCBjb250YWluZXIuXG4gICAqIEBwYXJhbSBtYXhXYW5kSCBUaGUgbWF4aW11bSB3aWR0aC9oZWlnaHQgZm9yIHRoZSBtaW5pbWFwLlxuICAgKiBAcGFyYW0gbGFiZWxQYWRkaW5nIFBhZGRpbmcgaW4gcGl4ZWxzIGR1ZSB0byB0aGUgbWFpbiBncmFwaCBsYWJlbHMuXG4gICAqL1xuICBjb25zdHJ1Y3Rvcihzdmc6IFNWR1NWR0VsZW1lbnQsIHpvb21HOiBTVkdHRWxlbWVudCxcbiAgICAgIG1haW5ab29tOiBkMy5ab29tQmVoYXZpb3I8YW55LCBhbnk+LCBtaW5pbWFwOiBIVE1MRWxlbWVudCxcbiAgICAgIG1heFdhbmRIOiBudW1iZXIsIGxhYmVsUGFkZGluZzogbnVtYmVyKSB7XG4gICAgdGhpcy5zdmcgPSBzdmc7XG4gICAgdGhpcy5sYWJlbFBhZGRpbmcgPSBsYWJlbFBhZGRpbmc7XG4gICAgdGhpcy56b29tRyA9IHpvb21HO1xuICAgIHRoaXMubWFpblpvb20gPSBtYWluWm9vbTtcbiAgICB0aGlzLm1heFdhbmRIID0gbWF4V2FuZEg7XG4gICAgbGV0ICRtaW5pbWFwID0gZDMuc2VsZWN0KG1pbmltYXApO1xuICAgIC8vIFRoZSBtaW5pbWFwIHdpbGwgaGF2ZSAyIG1haW4gY29tcG9uZW50czogdGhlIGNhbnZhcyBzaG93aW5nIHRoZSBjb250ZW50XG4gICAgLy8gYW5kIGFuIHN2ZyBzaG93aW5nIGEgcmVjdGFuZ2xlIG9mIHRoZSBjdXJyZW50bHkgem9vbWVkL3Bhbm5lZCB2aWV3cG9pbnQuXG4gICAgbGV0ICRtaW5pbWFwU3ZnID0gJG1pbmltYXAuc2VsZWN0KCdzdmcnKTtcblxuICAgIC8vIE1ha2UgdGhlIHZpZXdwb2ludCByZWN0YW5nbGUgZHJhZ2dhYmxlLlxuICAgIGxldCAkdmlld3BvaW50ID0gJG1pbmltYXBTdmcuc2VsZWN0KCdyZWN0Jyk7XG4gICAgbGV0IGRyYWdtb3ZlID0gKGQpID0+IHtcbiAgICAgIHRoaXMudmlld3BvaW50Q29vcmQueCA9ICg8RHJhZ0V2ZW50PmQzLmV2ZW50KS54O1xuICAgICAgdGhpcy52aWV3cG9pbnRDb29yZC55ID0gKDxEcmFnRXZlbnQ+ZDMuZXZlbnQpLnk7XG4gICAgICB0aGlzLnVwZGF0ZVZpZXdwb2ludCgpO1xuICAgIH07XG4gICAgdGhpcy52aWV3cG9pbnRDb29yZCA9IHt4OiAwLCB5OiAwfTtcbiAgICBsZXQgZHJhZyA9IGQzLmRyYWcoKS5zdWJqZWN0KE9iamVjdCkub24oJ2RyYWcnLCBkcmFnbW92ZSk7XG4gICAgJHZpZXdwb2ludC5kYXR1bSh0aGlzLnZpZXdwb2ludENvb3JkIGFzIGFueSkuY2FsbChkcmFnKTtcblxuICAgIC8vIE1ha2UgdGhlIG1pbmltYXAgY2xpY2thYmxlLlxuICAgICRtaW5pbWFwU3ZnLm9uKCdjbGljaycsICgpID0+IHtcbiAgICAgIGlmICgoPEV2ZW50PmQzLmV2ZW50KS5kZWZhdWx0UHJldmVudGVkKSB7XG4gICAgICAgIC8vIFRoaXMgY2xpY2sgd2FzIHBhcnQgb2YgYSBkcmFnIGV2ZW50LCBzbyBzdXBwcmVzcyBpdC5cbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgLy8gVXBkYXRlIHRoZSBjb29yZGluYXRlcyBvZiB0aGUgdmlld3BvaW50LlxuICAgICAgbGV0IHdpZHRoID0gTnVtYmVyKCR2aWV3cG9pbnQuYXR0cignd2lkdGgnKSk7XG4gICAgICBsZXQgaGVpZ2h0ID0gTnVtYmVyKCR2aWV3cG9pbnQuYXR0cignaGVpZ2h0JykpO1xuICAgICAgbGV0IGNsaWNrQ29vcmRzID0gZDMubW91c2UoJG1pbmltYXBTdmcubm9kZSgpIGFzIGFueSk7XG4gICAgICB0aGlzLnZpZXdwb2ludENvb3JkLnggPSBjbGlja0Nvb3Jkc1swXSAtIHdpZHRoIC8gMjtcbiAgICAgIHRoaXMudmlld3BvaW50Q29vcmQueSA9IGNsaWNrQ29vcmRzWzFdIC0gaGVpZ2h0IC8gMjtcbiAgICAgIHRoaXMudXBkYXRlVmlld3BvaW50KCk7XG4gICAgfSk7XG4gICAgdGhpcy52aWV3cG9pbnQgPSA8U1ZHUmVjdEVsZW1lbnQ+JHZpZXdwb2ludC5ub2RlKCk7XG4gICAgdGhpcy5taW5pbWFwU3ZnID0gPFNWR1NWR0VsZW1lbnQ+JG1pbmltYXBTdmcubm9kZSgpO1xuICAgIHRoaXMubWluaW1hcCA9IG1pbmltYXA7XG4gICAgdGhpcy5jYW52YXMgPSA8SFRNTENhbnZhc0VsZW1lbnQ+JG1pbmltYXAuc2VsZWN0KCdjYW52YXMuZmlyc3QnKS5ub2RlKCk7XG4gICAgdGhpcy5jYW52YXNCdWZmZXIgPVxuICAgICAgICA8SFRNTENhbnZhc0VsZW1lbnQ+JG1pbmltYXAuc2VsZWN0KCdjYW52YXMuc2Vjb25kJykubm9kZSgpO1xuICAgIHRoaXMuZG93bmxvYWRDYW52YXMgPVxuICAgICAgICA8SFRNTENhbnZhc0VsZW1lbnQ+JG1pbmltYXAuc2VsZWN0KCdjYW52YXMuZG93bmxvYWQnKS5ub2RlKCk7XG4gICAgZDMuc2VsZWN0KHRoaXMuZG93bmxvYWRDYW52YXMpLnN0eWxlKCdkaXNwbGF5JywgJ25vbmUnKTtcbiAgICB0aGlzLnVwZGF0ZSgpO1xuICB9XG5cbiAgLyoqXG4gICAqIFVwZGF0ZXMgdGhlIHBvc2l0aW9uIGFuZCB0aGUgc2l6ZSBvZiB0aGUgdmlld3BvaW50IHJlY3RhbmdsZS5cbiAgICogSXQgYWxzbyBub3RpZmllcyB0aGUgbWFpbiBzdmcgYWJvdXQgdGhlIG5ldyBwYW5uZWQgcG9zaXRpb24uXG4gICAqL1xuICBwcml2YXRlIHVwZGF0ZVZpZXdwb2ludCgpOiB2b2lkIHtcbiAgICAvLyBVcGRhdGUgdGhlIGNvb3JkaW5hdGVzIG9mIHRoZSB2aWV3cG9pbnQgcmVjdGFuZ2xlLlxuICAgIGQzLnNlbGVjdCh0aGlzLnZpZXdwb2ludClcbiAgICAgICAgLmF0dHIoJ3gnLCB0aGlzLnZpZXdwb2ludENvb3JkLngpXG4gICAgICAgIC5hdHRyKCd5JywgdGhpcy52aWV3cG9pbnRDb29yZC55KTtcbiAgICAvLyBVcGRhdGUgdGhlIHRyYW5zbGF0aW9uIHZlY3RvciBvZiB0aGUgbWFpbiBzdmcgdG8gcmVmbGVjdCB0aGVcbiAgICAvLyBuZXcgdmlld3BvaW50LlxuICAgIGxldCBtYWluWCA9IC0gdGhpcy52aWV3cG9pbnRDb29yZC54ICogdGhpcy5zY2FsZU1haW4gLyB0aGlzLnNjYWxlTWluaW1hcDtcbiAgICBsZXQgbWFpblkgPSAtIHRoaXMudmlld3BvaW50Q29vcmQueSAqIHRoaXMuc2NhbGVNYWluIC8gdGhpcy5zY2FsZU1pbmltYXA7XG4gICAgZDMuc2VsZWN0KHRoaXMuc3ZnKS5jYWxsKFxuICAgICAgICB0aGlzLm1haW5ab29tLnRyYW5zZm9ybSxcbiAgICAgICAgZDMuem9vbUlkZW50aXR5LnRyYW5zbGF0ZShtYWluWCwgbWFpblkpLnNjYWxlKHRoaXMuc2NhbGVNYWluKSk7XG4gIH1cblxuICAvKipcbiAgICogUmVkcmF3cyB0aGUgbWluaW1hcC4gU2hvdWxkIGJlIGNhbGxlZCB3aGVuZXZlciB0aGUgbWFpbiBzdmdcbiAgICogd2FzIHVwZGF0ZWQgKGUuZy4gd2hlbiBhIG5vZGUgd2FzIGV4cGFuZGVkKS5cbiAgICovXG4gIHVwZGF0ZSgpOiB2b2lkIHtcbiAgICBsZXQgc2NlbmVTaXplID0gbnVsbDtcbiAgICB0cnkge1xuICAgICAgLy8gR2V0IHRoZSBzaXplIG9mIHRoZSBlbnRpcmUgc2NlbmUuXG4gICAgICBzY2VuZVNpemUgPSB0aGlzLnpvb21HLmdldEJCb3goKTtcbiAgICAgIGlmIChzY2VuZVNpemUud2lkdGggPT09IDApIHtcbiAgICAgICAgLy8gVGhlcmUgaXMgbm8gc2NlbmUgYW55bW9yZS4gV2UgaGF2ZSBiZWVuIGRldGFjaGVkIGZyb20gdGhlIGRvbS5cbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIC8vIEZpcmVmb3ggcHJvZHVjZWQgTlNfRVJST1JfRkFJTFVSRSBpZiB3ZSBoYXZlIGJlZW5cbiAgICAgIC8vIGRldGFjaGVkIGZyb20gdGhlIGRvbS5cbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgbGV0ICRkb3dubG9hZCA9IGQzLnNlbGVjdCgnI2dyYXBoZG93bmxvYWQnKTtcbiAgICB0aGlzLmRvd25sb2FkID0gPEhUTUxMaW5rRWxlbWVudD4kZG93bmxvYWQubm9kZSgpO1xuICAgICRkb3dubG9hZC5vbignY2xpY2snLCBkID0+IHtcbiAgICAgIHRoaXMuZG93bmxvYWQuaHJlZiA9IHRoaXMuZG93bmxvYWRDYW52YXMudG9EYXRhVVJMKCdpbWFnZS9wbmcnKTtcbiAgICB9KTtcblxuICAgIGxldCAkc3ZnID0gZDMuc2VsZWN0KHRoaXMuc3ZnKTtcbiAgICAvLyBSZWFkIGFsbCB0aGUgc3R5bGUgcnVsZXMgaW4gdGhlIGRvY3VtZW50IGFuZCBlbWJlZCB0aGVtIGludG8gdGhlIHN2Zy5cbiAgICAvLyBUaGUgc3ZnIG5lZWRzIHRvIGJlIHNlbGYgY29udGFpbmVkLCBpLmUuIGFsbCB0aGUgc3R5bGUgcnVsZXMgbmVlZCB0byBiZVxuICAgIC8vIGVtYmVkZGVkIHNvIHRoZSBjYW52YXMgb3V0cHV0IG1hdGNoZXMgdGhlIG9yaWdpbi5cbiAgICBsZXQgc3R5bGVzVGV4dCA9ICcnO1xuICAgIGZvciAobGV0IGsgPSAwOyBrIDwgZG9jdW1lbnQuc3R5bGVTaGVldHMubGVuZ3RoOyBrKyspIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGxldCBjc3NSdWxlcyA9ICg8YW55PmRvY3VtZW50LnN0eWxlU2hlZXRzW2tdKS5jc3NSdWxlcyB8fFxuICAgICAgICAgICg8YW55PmRvY3VtZW50LnN0eWxlU2hlZXRzW2tdKS5ydWxlcztcbiAgICAgICAgaWYgKGNzc1J1bGVzID09IG51bGwpIHtcbiAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgfVxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGNzc1J1bGVzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgLy8gUmVtb3ZlIHRmLSogc2VsZWN0b3JzIGZyb20gdGhlIHN0eWxlcy5cbiAgICAgICAgICBzdHlsZXNUZXh0ICs9XG4gICAgICAgICAgICAgIGNzc1J1bGVzW2ldLmNzc1RleHQucmVwbGFjZSgvID90Zi1bXFx3LV0rID8vZywgJycpICsgJ1xcbic7XG4gICAgICAgIH1cbiAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgaWYgKGUubmFtZSAhPT0gJ1NlY3VyaXR5RXJyb3InKSB7XG4gICAgICAgICAgdGhyb3cgZTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cblxuICAgIC8vIFRlbXBvcmFyaWx5IGFkZCB0aGUgY3NzIHJ1bGVzIHRvIHRoZSBtYWluIHN2Zy5cbiAgICBsZXQgc3ZnU3R5bGUgPSAkc3ZnLmFwcGVuZCgnc3R5bGUnKTtcbiAgICBzdmdTdHlsZS50ZXh0KHN0eWxlc1RleHQpO1xuXG4gICAgLy8gVGVtcG9yYXJpbHkgcmVtb3ZlIHRoZSB6b29tL3BhbiB0cmFuc2Zvcm0gZnJvbSB0aGUgbWFpbiBzdmcgc2luY2Ugd2VcbiAgICAvLyB3YW50IHRoZSBtaW5pbWFwIHRvIHNob3cgYSB6b29tZWQtb3V0IGFuZCBjZW50ZXJlZCB2aWV3LlxuICAgIGxldCAkem9vbUcgPSBkMy5zZWxlY3QodGhpcy56b29tRyk7XG4gICAgbGV0IHpvb21UcmFuc2Zvcm0gPSAkem9vbUcuYXR0cigndHJhbnNmb3JtJyk7XG4gICAgJHpvb21HLmF0dHIoJ3RyYW5zZm9ybScsIG51bGwpO1xuXG4gICAgLy8gU2luY2Ugd2UgYWRkIHBhZGRpbmcsIGFjY291bnQgZm9yIHRoYXQgaGVyZS5cbiAgICBzY2VuZVNpemUuaGVpZ2h0ICs9IHRoaXMubGFiZWxQYWRkaW5nICogMjtcbiAgICBzY2VuZVNpemUud2lkdGggKz0gdGhpcy5sYWJlbFBhZGRpbmcgKiAyO1xuXG4gICAgLy8gVGVtcG9yYXJpbHkgYXNzaWduIGFuIGV4cGxpY2l0IHdpZHRoL2hlaWdodCB0byB0aGUgbWFpbiBzdmcsIHNpbmNlXG4gICAgLy8gaXQgZG9lc24ndCBoYXZlIG9uZSAodXNlcyBmbGV4LWJveCksIGJ1dCB3ZSBuZWVkIGl0IGZvciB0aGUgY2FudmFzXG4gICAgLy8gdG8gd29yay5cbiAgICAkc3ZnXG4gICAgICAuYXR0cignd2lkdGgnLCBzY2VuZVNpemUud2lkdGgpXG4gICAgICAuYXR0cignaGVpZ2h0Jywgc2NlbmVTaXplLmhlaWdodCk7XG5cbiAgICAvLyBTaW5jZSB0aGUgY29udGVudCBpbnNpZGUgdGhlIHN2ZyBjaGFuZ2VkIChlLmcuIGEgbm9kZSB3YXMgZXhwYW5kZWQpLFxuICAgIC8vIHRoZSBhc3BlY3QgcmF0aW8gaGF2ZSBhbHNvIGNoYW5nZWQuIFRodXMsIHdlIG5lZWQgdG8gdXBkYXRlIHRoZSBzY2FsZVxuICAgIC8vIGZhY3RvciBvZiB0aGUgbWluaW1hcC4gVGhlIHNjYWxlIGZhY3RvciBpcyBkZXRlcm1pbmVkIHN1Y2ggdGhhdCBib3RoXG4gICAgLy8gdGhlIHdpZHRoIGFuZCBoZWlnaHQgb2YgdGhlIG1pbmltYXAgYXJlIDw9IG1heGltdW0gc3BlY2lmaWVkIHcvaC5cbiAgICB0aGlzLnNjYWxlTWluaW1hcCA9XG4gICAgICAgIHRoaXMubWF4V2FuZEggLyBNYXRoLm1heChzY2VuZVNpemUud2lkdGgsIHNjZW5lU2l6ZS5oZWlnaHQpO1xuXG4gICAgdGhpcy5taW5pbWFwU2l6ZSA9IHtcbiAgICAgIHdpZHRoOiBzY2VuZVNpemUud2lkdGggKiB0aGlzLnNjYWxlTWluaW1hcCxcbiAgICAgIGhlaWdodDogc2NlbmVTaXplLmhlaWdodCAqIHRoaXMuc2NhbGVNaW5pbWFwXG4gICAgfTtcblxuICAgIC8vIFVwZGF0ZSB0aGUgc2l6ZSBvZiB0aGUgbWluaW1hcCdzIHN2ZywgdGhlIGJ1ZmZlciBjYW52YXMgYW5kIHRoZVxuICAgIC8vIHZpZXdwb2ludCByZWN0LlxuICAgIGQzLnNlbGVjdCh0aGlzLm1pbmltYXBTdmcpLmF0dHIoPGFueT50aGlzLm1pbmltYXBTaXplKTtcbiAgICBkMy5zZWxlY3QodGhpcy5jYW52YXNCdWZmZXIpLmF0dHIoPGFueT50aGlzLm1pbmltYXBTaXplKTtcblxuICAgIC8vIERvd25sb2FkIGNhbnZhcyB3aWR0aCBhbmQgaGVpZ2h0IGFyZSBtdWx0aXBsZXMgb2YgdGhlIHN0eWxlIHdpZHRoIGFuZFxuICAgIC8vIGhlaWdodCBpbiBvcmRlciB0byBpbmNyZWFzZSBwaXhlbCBkZW5zaXR5IG9mIHRoZSBQTkcgZm9yIGNsYXJpdHkuXG4gICAgY29uc3QgZG93bmxvYWRDYW52YXNTZWxlY3Rpb24gPSBkMy5zZWxlY3QodGhpcy5kb3dubG9hZENhbnZhcyk7XG4gICAgZG93bmxvYWRDYW52YXNTZWxlY3Rpb24uc3R5bGUoJ3dpZHRoJywgc2NlbmVTaXplLndpZHRoKTtcbiAgICBkb3dubG9hZENhbnZhc1NlbGVjdGlvbi5zdHlsZSgnaGVpZ2h0Jywgc2NlbmVTaXplLmhlaWdodCk7XG4gICAgZG93bmxvYWRDYW52YXNTZWxlY3Rpb24uYXR0cignd2lkdGgnLCAzICogc2NlbmVTaXplLndpZHRoKTtcbiAgICBkb3dubG9hZENhbnZhc1NlbGVjdGlvbi5hdHRyKCdoZWlnaHQnLCAzICogc2NlbmVTaXplLmhlaWdodCk7XG5cbiAgICBpZiAodGhpcy50cmFuc2xhdGUgIT0gbnVsbCAmJiB0aGlzLnpvb20gIT0gbnVsbCkge1xuICAgICAgLy8gVXBkYXRlIHRoZSB2aWV3cG9pbnQgcmVjdGFuZ2xlIHNoYXBlIHNpbmNlIHRoZSBhc3BlY3QgcmF0aW8gb2YgdGhlXG4gICAgICAvLyBtYXAgaGFzIGNoYW5nZWQuXG4gICAgICByZXF1ZXN0QW5pbWF0aW9uRnJhbWUoKCkgPT4gdGhpcy56b29tKCkpO1xuICAgIH1cblxuICAgIC8vIFNlcmlhbGl6ZSB0aGUgbWFpbiBzdmcgdG8gYSBzdHJpbmcgd2hpY2ggd2lsbCBiZSB1c2VkIGFzIHRoZSByZW5kZXJpbmdcbiAgICAvLyBjb250ZW50IGZvciB0aGUgY2FudmFzLlxuICAgIGxldCBzdmdYbWwgPSAobmV3IFhNTFNlcmlhbGl6ZXIoKSkuc2VyaWFsaXplVG9TdHJpbmcodGhpcy5zdmcpO1xuXG4gICAgLy8gTm93IHRoYXQgdGhlIHN2ZyBpcyBzZXJpYWxpemVkIGZvciByZW5kZXJpbmcsIHJlbW92ZSB0aGUgdGVtcG9yYXJpbHlcbiAgICAvLyBhc3NpZ25lZCBzdHlsZXMsIGV4cGxpY2l0IHdpZHRoIGFuZCBoZWlnaHQgYW5kIGJyaW5nIGJhY2sgdGhlIHBhbi96b29tXG4gICAgLy8gdHJhbnNmb3JtLlxuICAgIHN2Z1N0eWxlLnJlbW92ZSgpO1xuICAgICRzdmcuYXR0cignd2lkdGgnLCBudWxsKS5hdHRyKCdoZWlnaHQnLCBudWxsKTtcblxuICAgICR6b29tRy5hdHRyKCd0cmFuc2Zvcm0nLCB6b29tVHJhbnNmb3JtKTtcbiAgICBsZXQgaW1hZ2UgPSBuZXcgSW1hZ2UoKTtcbiAgICBpbWFnZS5vbmxvYWQgPSAoKSA9PiB7XG4gICAgICAvLyBEcmF3IHRoZSBzdmcgY29udGVudCBvbnRvIHRoZSBidWZmZXIgY2FudmFzLlxuICAgICAgbGV0IGNvbnRleHQgPSB0aGlzLmNhbnZhc0J1ZmZlci5nZXRDb250ZXh0KCcyZCcpO1xuICAgICAgY29udGV4dC5jbGVhclJlY3QoMCwgMCwgdGhpcy5jYW52YXNCdWZmZXIud2lkdGgsXG4gICAgICAgICAgdGhpcy5jYW52YXNCdWZmZXIuaGVpZ2h0KTtcbiAgICAgIGNvbnRleHQuZHJhd0ltYWdlKGltYWdlLCAwLCAwLFxuICAgICAgICB0aGlzLm1pbmltYXBTaXplLndpZHRoLCB0aGlzLm1pbmltYXBTaXplLmhlaWdodCk7XG4gICAgICByZXF1ZXN0QW5pbWF0aW9uRnJhbWUoKCkgPT4ge1xuICAgICAgICAvLyBIaWRlIHRoZSBvbGQgY2FudmFzIGFuZCBzaG93IHRoZSBuZXcgYnVmZmVyIGNhbnZhcy5cbiAgICAgICAgZDMuc2VsZWN0KHRoaXMuY2FudmFzQnVmZmVyKS5zdHlsZSgnZGlzcGxheScsIG51bGwpO1xuICAgICAgICBkMy5zZWxlY3QodGhpcy5jYW52YXMpLnN0eWxlKCdkaXNwbGF5JywgJ25vbmUnKTtcbiAgICAgICAgLy8gU3dhcCB0aGUgdHdvIGNhbnZhc2VzLlxuICAgICAgICBbdGhpcy5jYW52YXMsIHRoaXMuY2FudmFzQnVmZmVyXSA9IFt0aGlzLmNhbnZhc0J1ZmZlciwgdGhpcy5jYW52YXNdO1xuICAgICAgfSk7XG4gICAgICBsZXQgZG93bmxvYWRDb250ZXh0ID0gdGhpcy5kb3dubG9hZENhbnZhcy5nZXRDb250ZXh0KCcyZCcpO1xuICAgICAgZG93bmxvYWRDb250ZXh0LmNsZWFyUmVjdCgwLCAwLCB0aGlzLmRvd25sb2FkQ2FudmFzLndpZHRoLFxuICAgICAgICB0aGlzLmRvd25sb2FkQ2FudmFzLmhlaWdodCk7XG4gICAgICBkb3dubG9hZENvbnRleHQuZHJhd0ltYWdlKGltYWdlLCAwLCAwLFxuICAgICAgICB0aGlzLmRvd25sb2FkQ2FudmFzLndpZHRoLCB0aGlzLmRvd25sb2FkQ2FudmFzLmhlaWdodCk7XG4gICAgfTtcbiAgICBpbWFnZS5vbmVycm9yID0gKCkgPT4ge1xuICAgICAgbGV0IGJsb2IgPSBuZXcgQmxvYihbc3ZnWG1sXSwge3R5cGU6ICdpbWFnZS9zdmcreG1sO2NoYXJzZXQ9dXRmLTgnfSk7XG4gICAgICBpbWFnZS5zcmMgPSBVUkwuY3JlYXRlT2JqZWN0VVJMKGJsb2IpO1xuICAgIH07XG4gICAgaW1hZ2Uuc3JjID1cbiAgICAgICAgJ2RhdGE6aW1hZ2Uvc3ZnK3htbDtjaGFyc2V0PXV0Zi04LCcgKyBlbmNvZGVVUklDb21wb25lbnQoc3ZnWG1sKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBIYW5kbGVzIGNoYW5nZXMgaW4gem9vbWluZy9wYW5uaW5nLiBTaG91bGQgYmUgY2FsbGVkIGZyb20gdGhlIG1haW4gc3ZnXG4gICAqIHRvIG5vdGlmeSB0aGF0IGEgem9vbS9wYW4gd2FzIHBlcmZvcm1lZCBhbmQgdGhpcyBtaW5pbWFwIHdpbGwgdXBkYXRlIGl0J3NcbiAgICogdmlld3BvaW50IHJlY3RhbmdsZS5cbiAgICpcbiAgICogQHBhcmFtIHRyYW5zbGF0ZSBUaGUgdHJhbnNsYXRlIHZlY3Rvciwgb3Igbm9uZSB0byB1c2UgdGhlIGxhc3QgdXNlZCBvbmUuXG4gICAqIEBwYXJhbSBzY2FsZSBUaGUgc2NhbGluZyBmYWN0b3IsIG9yIG5vbmUgdG8gdXNlIHRoZSBsYXN0IHVzZWQgb25lLlxuICAgKi9cbiAgem9vbSh0cmFuc2Zvcm0/OiBkMy5ab29tVHJhbnNmb3JtKTogdm9pZCB7XG4gICAgaWYgKHRoaXMuc2NhbGVNaW5pbWFwID09IG51bGwpIHtcbiAgICAgIC8vIFNjZW5lIGlzIG5vdCByZWFkeSB5ZXQuXG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIC8vIFVwZGF0ZSB0aGUgbmV3IHRyYW5zbGF0ZSBhbmQgc2NhbGUgcGFyYW1zLCBvbmx5IGlmIHNwZWNpZmllZC5cbiAgICBpZiAodHJhbnNmb3JtKSB7XG4gICAgICB0aGlzLnRyYW5zbGF0ZSA9IFt0cmFuc2Zvcm0ueCwgdHJhbnNmb3JtLnldO1xuICAgICAgdGhpcy5zY2FsZU1haW4gPSB0cmFuc2Zvcm0uaztcbiAgICB9XG5cbiAgICAvLyBVcGRhdGUgdGhlIGxvY2F0aW9uIG9mIHRoZSB2aWV3cG9pbnQgcmVjdGFuZ2xlLlxuICAgIGxldCBzdmdSZWN0ID0gdGhpcy5zdmcuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gICAgbGV0ICR2aWV3cG9pbnQgPSBkMy5zZWxlY3QodGhpcy52aWV3cG9pbnQpO1xuICAgIHRoaXMudmlld3BvaW50Q29vcmQueCA9IC10aGlzLnRyYW5zbGF0ZVswXSAqIHRoaXMuc2NhbGVNaW5pbWFwIC9cbiAgICAgICAgdGhpcy5zY2FsZU1haW47XG4gICAgdGhpcy52aWV3cG9pbnRDb29yZC55ID0gLXRoaXMudHJhbnNsYXRlWzFdICogdGhpcy5zY2FsZU1pbmltYXAgL1xuICAgICAgICB0aGlzLnNjYWxlTWFpbjtcbiAgICBsZXQgdmlld3BvaW50V2lkdGggPSBzdmdSZWN0LndpZHRoICogdGhpcy5zY2FsZU1pbmltYXAgLyB0aGlzLnNjYWxlTWFpbjtcbiAgICBsZXQgdmlld3BvaW50SGVpZ2h0ID0gc3ZnUmVjdC5oZWlnaHQgKiB0aGlzLnNjYWxlTWluaW1hcCAvIHRoaXMuc2NhbGVNYWluO1xuICAgICR2aWV3cG9pbnRcbiAgICAgIC5hdHRyKCd4JywgdGhpcy52aWV3cG9pbnRDb29yZC54KVxuICAgICAgLmF0dHIoJ3knLCB0aGlzLnZpZXdwb2ludENvb3JkLnkpXG4gICAgICAuYXR0cignd2lkdGgnLCB2aWV3cG9pbnRXaWR0aClcbiAgICAgIC5hdHRyKCdoZWlnaHQnLCB2aWV3cG9pbnRIZWlnaHQpO1xuICAgIC8vIFNob3cvaGlkZSB0aGUgbWluaW1hcCBkZXBlbmRpbmcgb24gdGhlIHZpZXdwb2ludCBhcmVhIGFzIGZyYWN0aW9uIG9mIHRoZVxuICAgIC8vIHdob2xlIG1pbmltYXAuXG4gICAgbGV0IG1hcFdpZHRoID0gdGhpcy5taW5pbWFwU2l6ZS53aWR0aDtcbiAgICBsZXQgbWFwSGVpZ2h0ID0gdGhpcy5taW5pbWFwU2l6ZS5oZWlnaHQ7XG4gICAgbGV0IHggPSB0aGlzLnZpZXdwb2ludENvb3JkLng7XG4gICAgbGV0IHkgPSB0aGlzLnZpZXdwb2ludENvb3JkLnk7XG4gICAgbGV0IHcgPSBNYXRoLm1pbihNYXRoLm1heCgwLCB4ICsgdmlld3BvaW50V2lkdGgpLCBtYXBXaWR0aCkgLVxuICAgICAgICBNYXRoLm1pbihNYXRoLm1heCgwLCB4KSwgbWFwV2lkdGgpO1xuICAgIGxldCBoID0gTWF0aC5taW4oTWF0aC5tYXgoMCwgeSArIHZpZXdwb2ludEhlaWdodCksIG1hcEhlaWdodCkgLVxuICAgICAgICBNYXRoLm1pbihNYXRoLm1heCgwLCB5KSwgbWFwSGVpZ2h0KTtcbiAgICBsZXQgZnJhY0ludGVyc2VjdCA9ICh3ICogaCkgLyAobWFwV2lkdGggKiBtYXBIZWlnaHQpO1xuICAgIGlmIChmcmFjSW50ZXJzZWN0IDwgRlJBQ19WSUVXUE9JTlRfQVJFQSkge1xuICAgICAgdGhpcy5taW5pbWFwLmNsYXNzTGlzdC5yZW1vdmUoJ2hpZGRlbicpO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLm1pbmltYXAuY2xhc3NMaXN0LmFkZCgnaGlkZGVuJyk7XG4gICAgfVxuICB9XG59XG5cbn0gLy8gY2xvc2UgbW9kdWxlIHRmLnNjZW5lXG4iXX0=