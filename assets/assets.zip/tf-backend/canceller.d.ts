declare namespace tf_backend {
    /**
     * A class that allows marking promises as cancelled.
     *
     * This can be useful to, e.g., prevent old network requests from
     * stomping new ones and writing bad data.
     *
     * Usage:
     *
     *     const canceller = new Canceller();
     *     let myPromise: Promise<Foo> = getPromise();
     *     myPromise.then(canceller.cancellable(({value, cancelled} => {
     *       if (cancelled) {
     *         console.warn("Don't make promises you can't keep >:-{");
     *       }
     *       console.log("Enjoy your value:", value);
     *     }));
     *
     *     // If `myPromise` is resolved now, then `cancelled` will be `false`.
     *     canceller.cancelAll();
     *     // If `myPromise` is resolved now, then `cancelled` will be `true`.
     */
    class Canceller {
        /**
         * How many times has `cancelAll` been called?
         */
        private cancellationCount;
        /**
         * Create a cancellable task. This returns a new function that, when
         * invoked, will pass its argument to the provided function as well as
         * a `cancelled` argument. This argument will be `false` unless and
         * until `cancelAll` is invoked after the creation of this task.
         */
        cancellable<T, U>(f: (result: {
            value: T;
            cancelled: boolean;
        }) => U): (T: any) => U;
        /**
         * Mark all outstanding tasks as cancelled. Tasks not yet created will
         * not be affected.
         */
        cancelAll(): void;
    }
}
