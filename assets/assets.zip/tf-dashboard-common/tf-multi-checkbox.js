/* Copyright 2017 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the 'License');
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an 'AS IS' BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
var tf_dashboard_common;
(function (tf_dashboard_common) {
    Polymer({
        is: 'tf-multi-checkbox',
        properties: {
            names: {
                type: Array,
                value: function () { return []; },
            },
            coloring: {
                type: Object,
                value: {
                    getColor: function () { return ''; },
                },
            },
            regex: {
                type: String,
                notify: true,
                value: '',
            },
            _regex: { type: Object, computed: '_makeRegex(regex)' },
            namesMatchingRegex: {
                type: Array,
                computed: 'computeNamesMatchingRegex(names.*, _regex)'
            },
            selectionState: {
                // if a name is explicitly enabled, True, if explicitly disabled, False.
                // if undefined, default value (enable for first k names, disable after).
                type: Object,
                notify: true,
                value: function () { return ({}); },
            },
            // (Allows state to persist across regex filtering)
            outSelected: {
                type: Array,
                notify: true,
                computed: 'computeOutSelected(namesMatchingRegex.*, selectionState.*)'
            },
            maxNamesToEnableByDefault: {
                // When TB first loads, if it has k or fewer names, they are all enabled
                // by default. If there are more, then they are all disabled.
                type: Number,
                value: 40,
            },
            _debouncedRegexChange: {
                type: Object,
                // Updating the regex can be slow, because it involves updating styles
                // on a large number of Polymer paper-checkboxes. We don't want to do
                // this while the user is typing, as it may make a bad, laggy UI.
                // So we debounce the updates that come from user typing.
                value: function () {
                    var _this = this;
                    var debounced = _.debounce(function (r) {
                        _this.regex = r;
                    }, 150, { leading: false });
                    return function () {
                        var _this = this;
                        var r = this.$$('#names-regex').value;
                        if (r == '') {
                            // If the user cleared the field, they may be done typing, so
                            // update more quickly.
                            this.async(function () {
                                _this.regex = r;
                            }, 30);
                        }
                        else {
                            debounced(r);
                        }
                        ;
                    };
                },
            },
        },
        listeners: {
            'dom-change': 'synchronizeColors',
        },
        observers: [
            '_setIsolatorIcon(selectionState, names)',
        ],
        _makeRegex: function (regexString) {
            try {
                return new RegExp(regexString);
            }
            catch (e) {
                return null;
            }
        },
        _setIsolatorIcon: function () {
            var selectionMap = this.selectionState;
            var numChecked = _.filter(_.values(selectionMap)).length;
            var buttons = Array.prototype.slice.call(this.querySelectorAll('.isolator'));
            buttons.forEach(function (b) {
                if (numChecked === 1 && selectionMap[b.name]) {
                    b.icon = 'radio-button-checked';
                }
                else {
                    b.icon = 'radio-button-unchecked';
                }
            });
        },
        computeNamesMatchingRegex: function (__, ___) {
            var regex = this._regex;
            return regex ? this.names.filter(function (n) { return regex.test(n); }) : this.names;
        },
        computeOutSelected: function (__, ___) {
            var selectionState = this.selectionState;
            var num = this.maxNamesToEnableByDefault;
            var allEnabled = this.namesMatchingRegex.length <= num;
            return this.namesMatchingRegex
                .filter(function (n) {
                return selectionState[n] == null ? allEnabled : selectionState[n];
            });
        },
        synchronizeColors: function (e) {
            var _this = this;
            this._setIsolatorIcon();
            var checkboxes = this.querySelectorAll('paper-checkbox');
            checkboxes.forEach(function (p) {
                var color = _this.coloring.getColor(p.name);
                p.customStyle['--paper-checkbox-checked-color'] = color;
                p.customStyle['--paper-checkbox-checked-ink-color'] = color;
                p.customStyle['--paper-checkbox-unchecked-color'] = color;
                p.customStyle['--paper-checkbox-unchecked-ink-color'] = color;
            });
            var buttons = this.querySelectorAll('.isolator');
            buttons.forEach(function (p) {
                var color = _this.coloring.getColor(p.name);
                p.style['color'] = color;
            });
            // The updateStyles call fails silently if the browser doesn't have focus,
            // e.g. if TensorBoard was opened into a new tab that isn't visible.
            // So we wait for requestAnimationFrame.
            window.requestAnimationFrame(function () {
                _this.updateStyles();
            });
        },
        _isolateName: function (e) {
            // If user clicks on the label for one name, enable it and disable all other
            // names.
            var name = Polymer.dom(e).localTarget.name;
            var selectionState = {};
            this.names.forEach(function (n) {
                selectionState[n] = n == name;
            });
            this.selectionState = selectionState;
        },
        _checkboxChange: function (e) {
            var target = Polymer.dom(e).localTarget;
            var newSelectionState = _.clone(this.selectionState);
            newSelectionState[target.name] = target.checked;
            // n.b. notifyPath won't work because names may have periods.
            this.selectionState = newSelectionState;
        },
        _isChecked: function (item, outSelectedChange) {
            return this.outSelected.indexOf(item) != -1;
        },
        toggleAll: function () {
            var _this = this;
            var anyToggledOn = this.namesMatchingRegex
                .some(function (n) { return _this.selectionState[n]; });
            var selectionStateIsDefault = Object.keys(this.selectionState).length == 0;
            var defaultOff = this.namesMatchingRegex.length > this.maxRunsToEnableByDefault;
            // We have names toggled either if some were explicitly toggled on, or if
            // we are in the default state, and there are few enough that we default
            // to toggling on.
            anyToggledOn = anyToggledOn || selectionStateIsDefault && !defaultOff;
            // If any are toggled on, we turn everything off. Or, if none are toggled
            // on, we turn everything on.
            var newRunsDisabled = {};
            this.names.forEach(function (n) {
                newRunsDisabled[n] = !anyToggledOn;
            });
            this.selectionState = newRunsDisabled;
        },
    });
})(tf_dashboard_common || (tf_dashboard_common = {})); // namespace tf_dashboard_common
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGYtbXVsdGktY2hlY2tib3guanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJ0Zi1tdWx0aS1jaGVja2JveC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7Ozs7Ozs7OztnRkFhZ0Y7QUFDaEYsSUFBVSxtQkFBbUIsQ0FpTDVCO0FBakxELFdBQVUsbUJBQW1CO0lBRTdCLE9BQU8sQ0FBQztRQUNOLEVBQUUsRUFBRSxtQkFBbUI7UUFDdkIsVUFBVSxFQUFFO1lBQ1YsS0FBSyxFQUFFO2dCQUNMLElBQUksRUFBRSxLQUFLO2dCQUNYLEtBQUssRUFBRSxjQUFNLE9BQUEsRUFBRSxFQUFGLENBQUU7YUFDaEI7WUFDRCxRQUFRLEVBQUU7Z0JBQ1IsSUFBSSxFQUFFLE1BQU07Z0JBQ1osS0FBSyxFQUFFO29CQUNMLFFBQVEsRUFBRSxjQUFNLE9BQUEsRUFBRSxFQUFGLENBQUU7aUJBQ25CO2FBQ0Y7WUFDRCxLQUFLLEVBQUU7Z0JBQ0wsSUFBSSxFQUFFLE1BQU07Z0JBQ1osTUFBTSxFQUFFLElBQUk7Z0JBQ1osS0FBSyxFQUFFLEVBQUU7YUFDVjtZQUNELE1BQU0sRUFBRSxFQUFDLElBQUksRUFBRSxNQUFNLEVBQUUsUUFBUSxFQUFFLG1CQUFtQixFQUFDO1lBQ3JELGtCQUFrQixFQUFFO2dCQUNsQixJQUFJLEVBQUUsS0FBSztnQkFDWCxRQUFRLEVBQUUsNENBQTRDO2FBQ3ZEO1lBQ0QsY0FBYyxFQUFFO2dCQUNkLHdFQUF3RTtnQkFDeEUseUVBQXlFO2dCQUN6RSxJQUFJLEVBQUUsTUFBTTtnQkFDWixNQUFNLEVBQUUsSUFBSTtnQkFDWixLQUFLLEVBQUUsY0FBTSxPQUFBLENBQUMsRUFBRSxDQUFDLEVBQUosQ0FBSTthQUNsQjtZQUNELG1EQUFtRDtZQUNuRCxXQUFXLEVBQUU7Z0JBQ1gsSUFBSSxFQUFFLEtBQUs7Z0JBQ1gsTUFBTSxFQUFFLElBQUk7Z0JBQ1osUUFBUSxFQUFFLDREQUE0RDthQUN2RTtZQUNELHlCQUF5QixFQUFFO2dCQUN6Qix3RUFBd0U7Z0JBQ3hFLDZEQUE2RDtnQkFDN0QsSUFBSSxFQUFFLE1BQU07Z0JBQ1osS0FBSyxFQUFFLEVBQUU7YUFDVjtZQUNELHFCQUFxQixFQUFFO2dCQUNyQixJQUFJLEVBQUUsTUFBTTtnQkFDWixzRUFBc0U7Z0JBQ3RFLHFFQUFxRTtnQkFDckUsaUVBQWlFO2dCQUNqRSx5REFBeUQ7Z0JBQ3pELEtBQUssRUFBRTtvQkFBQSxpQkFnQk47b0JBZkMsSUFBSSxTQUFTLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxVQUFBLENBQUM7d0JBQzFCLEtBQUksQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDO29CQUNqQixDQUFDLEVBQUUsR0FBRyxFQUFFLEVBQUMsT0FBTyxFQUFFLEtBQUssRUFBQyxDQUFDLENBQUM7b0JBQzFCLE9BQU87d0JBQUEsaUJBV047d0JBVkMsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLEVBQUUsQ0FBQyxjQUFjLENBQUMsQ0FBQyxLQUFLLENBQUM7d0JBQ3RDLElBQUksQ0FBQyxJQUFJLEVBQUUsRUFBRTs0QkFDWCw2REFBNkQ7NEJBQzdELHVCQUF1Qjs0QkFDdkIsSUFBSSxDQUFDLEtBQUssQ0FBQztnQ0FDVCxLQUFJLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQzs0QkFDakIsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO3lCQUNSOzZCQUFNOzRCQUNMLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQzt5QkFDZDt3QkFBQSxDQUFDO29CQUNKLENBQUMsQ0FBQztnQkFDSixDQUFDO2FBQ0Y7U0FDRjtRQUNELFNBQVMsRUFBRTtZQUNULFlBQVksRUFBRSxtQkFBbUI7U0FDbEM7UUFDRCxTQUFTLEVBQUU7WUFDVCx5Q0FBeUM7U0FDMUM7UUFDRCxVQUFVLEVBQUUsVUFBUyxXQUFXO1lBQzlCLElBQUk7Z0JBQ0YsT0FBTyxJQUFJLE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQzthQUNoQztZQUFDLE9BQU8sQ0FBQyxFQUFFO2dCQUNWLE9BQU8sSUFBSSxDQUFDO2FBQ2I7UUFDSCxDQUFDO1FBQ0QsZ0JBQWdCLEVBQUU7WUFDaEIsSUFBSSxZQUFZLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQztZQUN2QyxJQUFJLFVBQVUsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7WUFDekQsSUFBSSxPQUFPLEdBQ1AsS0FBSyxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDO1lBRW5FLE9BQU8sQ0FBQyxPQUFPLENBQUMsVUFBUyxDQUFDO2dCQUN4QixJQUFJLFVBQVUsS0FBSyxDQUFDLElBQUksWUFBWSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRTtvQkFDNUMsQ0FBQyxDQUFDLElBQUksR0FBRyxzQkFBc0IsQ0FBQztpQkFDakM7cUJBQU07b0JBQ0wsQ0FBQyxDQUFDLElBQUksR0FBRyx3QkFBd0IsQ0FBQztpQkFDbkM7WUFDSCxDQUFDLENBQUMsQ0FBQztRQUNMLENBQUM7UUFDRCx5QkFBeUIsRUFBRSxVQUFTLEVBQUUsRUFBRSxHQUFHO1lBQ3pDLElBQU0sS0FBSyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUM7WUFDMUIsT0FBTyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLFVBQUEsQ0FBQyxJQUFJLE9BQUEsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBYixDQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQztRQUNwRSxDQUFDO1FBQ0Qsa0JBQWtCLEVBQUUsVUFBUyxFQUFFLEVBQUUsR0FBRztZQUNsQyxJQUFJLGNBQWMsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDO1lBQ3pDLElBQUksR0FBRyxHQUFHLElBQUksQ0FBQyx5QkFBeUIsQ0FBQztZQUN6QyxJQUFJLFVBQVUsR0FBRyxJQUFJLENBQUMsa0JBQWtCLENBQUMsTUFBTSxJQUFJLEdBQUcsQ0FBQztZQUN2RCxPQUFPLElBQUksQ0FBQyxrQkFBa0I7aUJBQ3pCLE1BQU0sQ0FBQyxVQUFBLENBQUM7Z0JBQ1AsT0FBTyxjQUFjLENBQUMsQ0FBQyxDQUFDLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUNwRSxDQUFDLENBQUMsQ0FBQztRQUNULENBQUM7UUFDRCxpQkFBaUIsRUFBRSxVQUFTLENBQUM7WUFBVixpQkFzQmxCO1lBckJDLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO1lBRXhCLElBQU0sVUFBVSxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO1lBQzNELFVBQVUsQ0FBQyxPQUFPLENBQUMsVUFBQSxDQUFDO2dCQUNsQixJQUFNLEtBQUssR0FBRyxLQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7Z0JBQzdDLENBQUMsQ0FBQyxXQUFXLENBQUMsZ0NBQWdDLENBQUMsR0FBRyxLQUFLLENBQUM7Z0JBQ3hELENBQUMsQ0FBQyxXQUFXLENBQUMsb0NBQW9DLENBQUMsR0FBRyxLQUFLLENBQUM7Z0JBQzVELENBQUMsQ0FBQyxXQUFXLENBQUMsa0NBQWtDLENBQUMsR0FBRyxLQUFLLENBQUM7Z0JBQzFELENBQUMsQ0FBQyxXQUFXLENBQUMsc0NBQXNDLENBQUMsR0FBRyxLQUFLLENBQUM7WUFDaEUsQ0FBQyxDQUFDLENBQUM7WUFDSCxJQUFNLE9BQU8sR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsV0FBVyxDQUFDLENBQUM7WUFDbkQsT0FBTyxDQUFDLE9BQU8sQ0FBQyxVQUFBLENBQUM7Z0JBQ2YsSUFBTSxLQUFLLEdBQUcsS0FBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUM3QyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxHQUFHLEtBQUssQ0FBQztZQUMzQixDQUFDLENBQUMsQ0FBQztZQUNILDBFQUEwRTtZQUMxRSxvRUFBb0U7WUFDcEUsd0NBQXdDO1lBQ3hDLE1BQU0sQ0FBQyxxQkFBcUIsQ0FBQztnQkFDM0IsS0FBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1lBQ3RCLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQztRQUNELFlBQVksRUFBRSxVQUFTLENBQUM7WUFDdEIsNEVBQTRFO1lBQzVFLFNBQVM7WUFDVCxJQUFJLElBQUksR0FBSSxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBUyxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUM7WUFDcEQsSUFBSSxjQUFjLEdBQUcsRUFBRSxDQUFDO1lBQ3hCLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLFVBQVMsQ0FBQztnQkFDM0IsY0FBYyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxJQUFJLENBQUM7WUFDaEMsQ0FBQyxDQUFDLENBQUM7WUFDSCxJQUFJLENBQUMsY0FBYyxHQUFHLGNBQWMsQ0FBQztRQUN2QyxDQUFDO1FBQ0QsZUFBZSxFQUFFLFVBQVMsQ0FBQztZQUN6QixJQUFJLE1BQU0sR0FBSSxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBUyxDQUFDLFdBQVcsQ0FBQztZQUNqRCxJQUFNLGlCQUFpQixHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDO1lBQ3ZELGlCQUFpQixDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsR0FBRyxNQUFNLENBQUMsT0FBTyxDQUFDO1lBQ2hELDZEQUE2RDtZQUM3RCxJQUFJLENBQUMsY0FBYyxHQUFHLGlCQUFpQixDQUFDO1FBQzFDLENBQUM7UUFDRCxVQUFVLEVBQUUsVUFBUyxJQUFJLEVBQUUsaUJBQWlCO1lBQzFDLE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7UUFDOUMsQ0FBQztRQUNELFNBQVMsRUFBRTtZQUFBLGlCQXNCVjtZQXJCQyxJQUFJLFlBQVksR0FBRyxJQUFJLENBQUMsa0JBQWtCO2lCQUNyQyxJQUFJLENBQUMsVUFBQyxDQUFDLElBQUssT0FBQSxLQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxFQUF0QixDQUFzQixDQUFDLENBQUM7WUFFekMsSUFBSSx1QkFBdUIsR0FDdkIsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQztZQUVqRCxJQUFJLFVBQVUsR0FDVixJQUFJLENBQUMsa0JBQWtCLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyx3QkFBd0IsQ0FBQztZQUNuRSx5RUFBeUU7WUFDekUsd0VBQXdFO1lBQ3hFLGtCQUFrQjtZQUNsQixZQUFZLEdBQUcsWUFBWSxJQUFJLHVCQUF1QixJQUFJLENBQUMsVUFBVSxDQUFDO1lBRXRFLHlFQUF5RTtZQUN6RSw2QkFBNkI7WUFFN0IsSUFBSSxlQUFlLEdBQUcsRUFBRSxDQUFDO1lBQ3pCLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLFVBQVMsQ0FBQztnQkFDM0IsZUFBZSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDO1lBQ3JDLENBQUMsQ0FBQyxDQUFDO1lBQ0gsSUFBSSxDQUFDLGNBQWMsR0FBRyxlQUFlLENBQUM7UUFDeEMsQ0FBQztLQUNGLENBQUMsQ0FBQztBQUVILENBQUMsRUFqTFMsbUJBQW1CLEtBQW5CLG1CQUFtQixRQWlMNUIsQ0FBRSxnQ0FBZ0MiLCJzb3VyY2VzQ29udGVudCI6WyIvKiBDb3B5cmlnaHQgMjAxNyBUaGUgVGVuc29yRmxvdyBBdXRob3JzLiBBbGwgUmlnaHRzIFJlc2VydmVkLlxuXG5MaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UsIFZlcnNpb24gMi4wICh0aGUgJ0xpY2Vuc2UnKTtcbnlvdSBtYXkgbm90IHVzZSB0aGlzIGZpbGUgZXhjZXB0IGluIGNvbXBsaWFuY2Ugd2l0aCB0aGUgTGljZW5zZS5cbllvdSBtYXkgb2J0YWluIGEgY29weSBvZiB0aGUgTGljZW5zZSBhdFxuXG4gICAgaHR0cDovL3d3dy5hcGFjaGUub3JnL2xpY2Vuc2VzL0xJQ0VOU0UtMi4wXG5cblVubGVzcyByZXF1aXJlZCBieSBhcHBsaWNhYmxlIGxhdyBvciBhZ3JlZWQgdG8gaW4gd3JpdGluZywgc29mdHdhcmVcbmRpc3RyaWJ1dGVkIHVuZGVyIHRoZSBMaWNlbnNlIGlzIGRpc3RyaWJ1dGVkIG9uIGFuICdBUyBJUycgQkFTSVMsXG5XSVRIT1VUIFdBUlJBTlRJRVMgT1IgQ09ORElUSU9OUyBPRiBBTlkgS0lORCwgZWl0aGVyIGV4cHJlc3Mgb3IgaW1wbGllZC5cblNlZSB0aGUgTGljZW5zZSBmb3IgdGhlIHNwZWNpZmljIGxhbmd1YWdlIGdvdmVybmluZyBwZXJtaXNzaW9ucyBhbmRcbmxpbWl0YXRpb25zIHVuZGVyIHRoZSBMaWNlbnNlLlxuPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09Ki9cbm5hbWVzcGFjZSB0Zl9kYXNoYm9hcmRfY29tbW9uIHtcblxuUG9seW1lcih7XG4gIGlzOiAndGYtbXVsdGktY2hlY2tib3gnLFxuICBwcm9wZXJ0aWVzOiB7XG4gICAgbmFtZXM6IHtcbiAgICAgIHR5cGU6IEFycmF5LFxuICAgICAgdmFsdWU6ICgpID0+IFtdLFxuICAgIH0sICAvLyBBbGwgdGhlIHZhbHVlcyBvZiBjaGVja2JveFxuICAgIGNvbG9yaW5nOiB7XG4gICAgICB0eXBlOiBPYmplY3QsXG4gICAgICB2YWx1ZToge1xuICAgICAgICBnZXRDb2xvcjogKCkgPT4gJycsXG4gICAgICB9LFxuICAgIH0sXG4gICAgcmVnZXg6IHtcbiAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgIG5vdGlmeTogdHJ1ZSxcbiAgICAgIHZhbHVlOiAnJyxcbiAgICB9LCAgLy8gUmVnZXggZm9yIGZpbHRlcmluZyB0aGUgbmFtZXNcbiAgICBfcmVnZXg6IHt0eXBlOiBPYmplY3QsIGNvbXB1dGVkOiAnX21ha2VSZWdleChyZWdleCknfSxcbiAgICBuYW1lc01hdGNoaW5nUmVnZXg6IHtcbiAgICAgIHR5cGU6IEFycmF5LFxuICAgICAgY29tcHV0ZWQ6ICdjb21wdXRlTmFtZXNNYXRjaGluZ1JlZ2V4KG5hbWVzLiosIF9yZWdleCknXG4gICAgfSwgIC8vIFJ1bnMgdGhhdCBtYXRjaCB0aGUgcmVnZXhcbiAgICBzZWxlY3Rpb25TdGF0ZToge1xuICAgICAgLy8gaWYgYSBuYW1lIGlzIGV4cGxpY2l0bHkgZW5hYmxlZCwgVHJ1ZSwgaWYgZXhwbGljaXRseSBkaXNhYmxlZCwgRmFsc2UuXG4gICAgICAvLyBpZiB1bmRlZmluZWQsIGRlZmF1bHQgdmFsdWUgKGVuYWJsZSBmb3IgZmlyc3QgayBuYW1lcywgZGlzYWJsZSBhZnRlcikuXG4gICAgICB0eXBlOiBPYmplY3QsXG4gICAgICBub3RpZnk6IHRydWUsXG4gICAgICB2YWx1ZTogKCkgPT4gKHt9KSxcbiAgICB9LFxuICAgIC8vIChBbGxvd3Mgc3RhdGUgdG8gcGVyc2lzdCBhY3Jvc3MgcmVnZXggZmlsdGVyaW5nKVxuICAgIG91dFNlbGVjdGVkOiB7XG4gICAgICB0eXBlOiBBcnJheSxcbiAgICAgIG5vdGlmeTogdHJ1ZSxcbiAgICAgIGNvbXB1dGVkOiAnY29tcHV0ZU91dFNlbGVjdGVkKG5hbWVzTWF0Y2hpbmdSZWdleC4qLCBzZWxlY3Rpb25TdGF0ZS4qKSdcbiAgICB9LFxuICAgIG1heE5hbWVzVG9FbmFibGVCeURlZmF1bHQ6IHtcbiAgICAgIC8vIFdoZW4gVEIgZmlyc3QgbG9hZHMsIGlmIGl0IGhhcyBrIG9yIGZld2VyIG5hbWVzLCB0aGV5IGFyZSBhbGwgZW5hYmxlZFxuICAgICAgLy8gYnkgZGVmYXVsdC4gSWYgdGhlcmUgYXJlIG1vcmUsIHRoZW4gdGhleSBhcmUgYWxsIGRpc2FibGVkLlxuICAgICAgdHlwZTogTnVtYmVyLFxuICAgICAgdmFsdWU6IDQwLFxuICAgIH0sXG4gICAgX2RlYm91bmNlZFJlZ2V4Q2hhbmdlOiB7XG4gICAgICB0eXBlOiBPYmplY3QsXG4gICAgICAvLyBVcGRhdGluZyB0aGUgcmVnZXggY2FuIGJlIHNsb3csIGJlY2F1c2UgaXQgaW52b2x2ZXMgdXBkYXRpbmcgc3R5bGVzXG4gICAgICAvLyBvbiBhIGxhcmdlIG51bWJlciBvZiBQb2x5bWVyIHBhcGVyLWNoZWNrYm94ZXMuIFdlIGRvbid0IHdhbnQgdG8gZG9cbiAgICAgIC8vIHRoaXMgd2hpbGUgdGhlIHVzZXIgaXMgdHlwaW5nLCBhcyBpdCBtYXkgbWFrZSBhIGJhZCwgbGFnZ3kgVUkuXG4gICAgICAvLyBTbyB3ZSBkZWJvdW5jZSB0aGUgdXBkYXRlcyB0aGF0IGNvbWUgZnJvbSB1c2VyIHR5cGluZy5cbiAgICAgIHZhbHVlOiBmdW5jdGlvbigpIHtcbiAgICAgICAgdmFyIGRlYm91bmNlZCA9IF8uZGVib3VuY2UociA9PiB7XG4gICAgICAgICAgdGhpcy5yZWdleCA9IHI7XG4gICAgICAgIH0sIDE1MCwge2xlYWRpbmc6IGZhbHNlfSk7XG4gICAgICAgIHJldHVybiBmdW5jdGlvbigpIHtcbiAgICAgICAgICB2YXIgciA9IHRoaXMuJCQoJyNuYW1lcy1yZWdleCcpLnZhbHVlO1xuICAgICAgICAgIGlmIChyID09ICcnKSB7XG4gICAgICAgICAgICAvLyBJZiB0aGUgdXNlciBjbGVhcmVkIHRoZSBmaWVsZCwgdGhleSBtYXkgYmUgZG9uZSB0eXBpbmcsIHNvXG4gICAgICAgICAgICAvLyB1cGRhdGUgbW9yZSBxdWlja2x5LlxuICAgICAgICAgICAgdGhpcy5hc3luYygoKSA9PiB7XG4gICAgICAgICAgICAgIHRoaXMucmVnZXggPSByO1xuICAgICAgICAgICAgfSwgMzApO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBkZWJvdW5jZWQocik7XG4gICAgICAgICAgfTtcbiAgICAgICAgfTtcbiAgICAgIH0sXG4gICAgfSxcbiAgfSxcbiAgbGlzdGVuZXJzOiB7XG4gICAgJ2RvbS1jaGFuZ2UnOiAnc3luY2hyb25pemVDb2xvcnMnLFxuICB9LFxuICBvYnNlcnZlcnM6IFtcbiAgICAnX3NldElzb2xhdG9ySWNvbihzZWxlY3Rpb25TdGF0ZSwgbmFtZXMpJyxcbiAgXSxcbiAgX21ha2VSZWdleDogZnVuY3Rpb24ocmVnZXhTdHJpbmcpIHtcbiAgICB0cnkge1xuICAgICAgcmV0dXJuIG5ldyBSZWdFeHAocmVnZXhTdHJpbmcpO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgfSxcbiAgX3NldElzb2xhdG9ySWNvbjogZnVuY3Rpb24oKSB7XG4gICAgdmFyIHNlbGVjdGlvbk1hcCA9IHRoaXMuc2VsZWN0aW9uU3RhdGU7XG4gICAgdmFyIG51bUNoZWNrZWQgPSBfLmZpbHRlcihfLnZhbHVlcyhzZWxlY3Rpb25NYXApKS5sZW5ndGg7XG4gICAgdmFyIGJ1dHRvbnMgPVxuICAgICAgICBBcnJheS5wcm90b3R5cGUuc2xpY2UuY2FsbCh0aGlzLnF1ZXJ5U2VsZWN0b3JBbGwoJy5pc29sYXRvcicpKTtcblxuICAgIGJ1dHRvbnMuZm9yRWFjaChmdW5jdGlvbihiKSB7XG4gICAgICBpZiAobnVtQ2hlY2tlZCA9PT0gMSAmJiBzZWxlY3Rpb25NYXBbYi5uYW1lXSkge1xuICAgICAgICBiLmljb24gPSAncmFkaW8tYnV0dG9uLWNoZWNrZWQnO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgYi5pY29uID0gJ3JhZGlvLWJ1dHRvbi11bmNoZWNrZWQnO1xuICAgICAgfVxuICAgIH0pO1xuICB9LFxuICBjb21wdXRlTmFtZXNNYXRjaGluZ1JlZ2V4OiBmdW5jdGlvbihfXywgX19fKSB7XG4gICAgY29uc3QgcmVnZXggPSB0aGlzLl9yZWdleDtcbiAgICByZXR1cm4gcmVnZXggPyB0aGlzLm5hbWVzLmZpbHRlcihuID0+IHJlZ2V4LnRlc3QobikpIDogdGhpcy5uYW1lcztcbiAgfSxcbiAgY29tcHV0ZU91dFNlbGVjdGVkOiBmdW5jdGlvbihfXywgX19fKSB7XG4gICAgdmFyIHNlbGVjdGlvblN0YXRlID0gdGhpcy5zZWxlY3Rpb25TdGF0ZTtcbiAgICB2YXIgbnVtID0gdGhpcy5tYXhOYW1lc1RvRW5hYmxlQnlEZWZhdWx0O1xuICAgIHZhciBhbGxFbmFibGVkID0gdGhpcy5uYW1lc01hdGNoaW5nUmVnZXgubGVuZ3RoIDw9IG51bTtcbiAgICByZXR1cm4gdGhpcy5uYW1lc01hdGNoaW5nUmVnZXhcbiAgICAgICAgLmZpbHRlcihuID0+IHtcbiAgICAgICAgICByZXR1cm4gc2VsZWN0aW9uU3RhdGVbbl0gPT0gbnVsbCA/IGFsbEVuYWJsZWQgOiBzZWxlY3Rpb25TdGF0ZVtuXTtcbiAgICAgICAgfSk7XG4gIH0sXG4gIHN5bmNocm9uaXplQ29sb3JzOiBmdW5jdGlvbihlKSB7XG4gICAgdGhpcy5fc2V0SXNvbGF0b3JJY29uKCk7XG5cbiAgICBjb25zdCBjaGVja2JveGVzID0gdGhpcy5xdWVyeVNlbGVjdG9yQWxsKCdwYXBlci1jaGVja2JveCcpO1xuICAgIGNoZWNrYm94ZXMuZm9yRWFjaChwID0+IHtcbiAgICAgIGNvbnN0IGNvbG9yID0gdGhpcy5jb2xvcmluZy5nZXRDb2xvcihwLm5hbWUpO1xuICAgICAgcC5jdXN0b21TdHlsZVsnLS1wYXBlci1jaGVja2JveC1jaGVja2VkLWNvbG9yJ10gPSBjb2xvcjtcbiAgICAgIHAuY3VzdG9tU3R5bGVbJy0tcGFwZXItY2hlY2tib3gtY2hlY2tlZC1pbmstY29sb3InXSA9IGNvbG9yO1xuICAgICAgcC5jdXN0b21TdHlsZVsnLS1wYXBlci1jaGVja2JveC11bmNoZWNrZWQtY29sb3InXSA9IGNvbG9yO1xuICAgICAgcC5jdXN0b21TdHlsZVsnLS1wYXBlci1jaGVja2JveC11bmNoZWNrZWQtaW5rLWNvbG9yJ10gPSBjb2xvcjtcbiAgICB9KTtcbiAgICBjb25zdCBidXR0b25zID0gdGhpcy5xdWVyeVNlbGVjdG9yQWxsKCcuaXNvbGF0b3InKTtcbiAgICBidXR0b25zLmZvckVhY2gocCA9PiB7XG4gICAgICBjb25zdCBjb2xvciA9IHRoaXMuY29sb3JpbmcuZ2V0Q29sb3IocC5uYW1lKTtcbiAgICAgIHAuc3R5bGVbJ2NvbG9yJ10gPSBjb2xvcjtcbiAgICB9KTtcbiAgICAvLyBUaGUgdXBkYXRlU3R5bGVzIGNhbGwgZmFpbHMgc2lsZW50bHkgaWYgdGhlIGJyb3dzZXIgZG9lc24ndCBoYXZlIGZvY3VzLFxuICAgIC8vIGUuZy4gaWYgVGVuc29yQm9hcmQgd2FzIG9wZW5lZCBpbnRvIGEgbmV3IHRhYiB0aGF0IGlzbid0IHZpc2libGUuXG4gICAgLy8gU28gd2Ugd2FpdCBmb3IgcmVxdWVzdEFuaW1hdGlvbkZyYW1lLlxuICAgIHdpbmRvdy5yZXF1ZXN0QW5pbWF0aW9uRnJhbWUoKCkgPT4ge1xuICAgICAgdGhpcy51cGRhdGVTdHlsZXMoKTtcbiAgICB9KTtcbiAgfSxcbiAgX2lzb2xhdGVOYW1lOiBmdW5jdGlvbihlKSB7XG4gICAgLy8gSWYgdXNlciBjbGlja3Mgb24gdGhlIGxhYmVsIGZvciBvbmUgbmFtZSwgZW5hYmxlIGl0IGFuZCBkaXNhYmxlIGFsbCBvdGhlclxuICAgIC8vIG5hbWVzLlxuICAgIHZhciBuYW1lID0gKFBvbHltZXIuZG9tKGUpIGFzIGFueSkubG9jYWxUYXJnZXQubmFtZTtcbiAgICB2YXIgc2VsZWN0aW9uU3RhdGUgPSB7fTtcbiAgICB0aGlzLm5hbWVzLmZvckVhY2goZnVuY3Rpb24obikge1xuICAgICAgc2VsZWN0aW9uU3RhdGVbbl0gPSBuID09IG5hbWU7XG4gICAgfSk7XG4gICAgdGhpcy5zZWxlY3Rpb25TdGF0ZSA9IHNlbGVjdGlvblN0YXRlO1xuICB9LFxuICBfY2hlY2tib3hDaGFuZ2U6IGZ1bmN0aW9uKGUpIHtcbiAgICB2YXIgdGFyZ2V0ID0gKFBvbHltZXIuZG9tKGUpIGFzIGFueSkubG9jYWxUYXJnZXQ7XG4gICAgY29uc3QgbmV3U2VsZWN0aW9uU3RhdGUgPSBfLmNsb25lKHRoaXMuc2VsZWN0aW9uU3RhdGUpO1xuICAgIG5ld1NlbGVjdGlvblN0YXRlW3RhcmdldC5uYW1lXSA9IHRhcmdldC5jaGVja2VkO1xuICAgIC8vIG4uYi4gbm90aWZ5UGF0aCB3b24ndCB3b3JrIGJlY2F1c2UgbmFtZXMgbWF5IGhhdmUgcGVyaW9kcy5cbiAgICB0aGlzLnNlbGVjdGlvblN0YXRlID0gbmV3U2VsZWN0aW9uU3RhdGU7XG4gIH0sXG4gIF9pc0NoZWNrZWQ6IGZ1bmN0aW9uKGl0ZW0sIG91dFNlbGVjdGVkQ2hhbmdlKSB7XG4gICAgcmV0dXJuIHRoaXMub3V0U2VsZWN0ZWQuaW5kZXhPZihpdGVtKSAhPSAtMTtcbiAgfSxcbiAgdG9nZ2xlQWxsOiBmdW5jdGlvbigpIHtcbiAgICB2YXIgYW55VG9nZ2xlZE9uID0gdGhpcy5uYW1lc01hdGNoaW5nUmVnZXhcbiAgICAgICAgLnNvbWUoKG4pID0+IHRoaXMuc2VsZWN0aW9uU3RhdGVbbl0pO1xuXG4gICAgdmFyIHNlbGVjdGlvblN0YXRlSXNEZWZhdWx0ID1cbiAgICAgICAgT2JqZWN0LmtleXModGhpcy5zZWxlY3Rpb25TdGF0ZSkubGVuZ3RoID09IDA7XG5cbiAgICB2YXIgZGVmYXVsdE9mZiA9XG4gICAgICAgIHRoaXMubmFtZXNNYXRjaGluZ1JlZ2V4Lmxlbmd0aCA+IHRoaXMubWF4UnVuc1RvRW5hYmxlQnlEZWZhdWx0O1xuICAgIC8vIFdlIGhhdmUgbmFtZXMgdG9nZ2xlZCBlaXRoZXIgaWYgc29tZSB3ZXJlIGV4cGxpY2l0bHkgdG9nZ2xlZCBvbiwgb3IgaWZcbiAgICAvLyB3ZSBhcmUgaW4gdGhlIGRlZmF1bHQgc3RhdGUsIGFuZCB0aGVyZSBhcmUgZmV3IGVub3VnaCB0aGF0IHdlIGRlZmF1bHRcbiAgICAvLyB0byB0b2dnbGluZyBvbi5cbiAgICBhbnlUb2dnbGVkT24gPSBhbnlUb2dnbGVkT24gfHwgc2VsZWN0aW9uU3RhdGVJc0RlZmF1bHQgJiYgIWRlZmF1bHRPZmY7XG5cbiAgICAvLyBJZiBhbnkgYXJlIHRvZ2dsZWQgb24sIHdlIHR1cm4gZXZlcnl0aGluZyBvZmYuIE9yLCBpZiBub25lIGFyZSB0b2dnbGVkXG4gICAgLy8gb24sIHdlIHR1cm4gZXZlcnl0aGluZyBvbi5cblxuICAgIHZhciBuZXdSdW5zRGlzYWJsZWQgPSB7fTtcbiAgICB0aGlzLm5hbWVzLmZvckVhY2goZnVuY3Rpb24obikge1xuICAgICAgbmV3UnVuc0Rpc2FibGVkW25dID0gIWFueVRvZ2dsZWRPbjtcbiAgICB9KTtcbiAgICB0aGlzLnNlbGVjdGlvblN0YXRlID0gbmV3UnVuc0Rpc2FibGVkO1xuICB9LFxufSk7XG5cbn0gIC8vIG5hbWVzcGFjZSB0Zl9kYXNoYm9hcmRfY29tbW9uXG4iXX0=