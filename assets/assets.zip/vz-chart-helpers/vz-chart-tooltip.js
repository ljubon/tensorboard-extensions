/* Copyright 2018 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
var vz_chart_helper;
(function (vz_chart_helper) {
    var TooltipPosition;
    (function (TooltipPosition) {
        /**
         * Positions the tooltip to the bottom of the chart in most case. Positions
         * the tooltip above the chart if there isn't sufficient space below.
         */
        TooltipPosition["AUTO"] = "auto";
        /**
         * Position the tooltip on the bottom of the chart.
         */
        TooltipPosition["BOTTOM"] = "bottom";
        /**
         * Positions the tooltip to the right of the chart.
         */
        TooltipPosition["RIGHT"] = "right";
    })(TooltipPosition = vz_chart_helper.TooltipPosition || (vz_chart_helper.TooltipPosition = {}));
    Polymer({
        is: 'vz-chart-tooltip',
        properties: {
            /**
             * Possible values are TooltipPosition.BOTTOM and TooltipPosition.RIGHT.
             */
            position: {
                type: String,
                value: TooltipPosition.AUTO,
            },
            /**
             * Minimum instance from the edge of the screen.
             */
            minDistFromEdge: {
                type: Number,
                value: 15,
            },
        },
        ready: function () {
            this._styleCache = null;
            this._raf = null;
            this._tunnel = null;
        },
        attached: function () {
            this._tunnel = this._createTunnel();
        },
        detached: function () {
            this.hide();
            this._removeTunnel(this._tunnel);
            this._tunnel = null;
        },
        hide: function () {
            window.cancelAnimationFrame(this._raf);
            this._styleCache = null;
            this.content().style.opacity = 0;
        },
        content: function () {
            return this._tunnel.firstElementChild;
        },
        /**
         * CSS Scopes the newly added DOM (in most tooltip where columns are
         * invariable, only newly added rows are necessary to be scoped) and positions
         * the tooltip with respect to the anchorNode.
         */
        updateAndPosition: function (anchorNode, newDom) {
            var _this = this;
            newDom.forEach(function (row) { return _this.scopeSubtree(row); });
            window.cancelAnimationFrame(this._raf);
            this._raf = window.requestAnimationFrame(function () {
                if (!_this.isAttached)
                    return;
                _this._repositionImpl(anchorNode);
            });
        },
        _repositionImpl: function (anchorNode) {
            var tooltipContent = this.content();
            var nodeRect = anchorNode.getBoundingClientRect();
            var tooltipRect = tooltipContent.getBoundingClientRect();
            var viewportHeight = window.innerHeight;
            var documentWidth = document.body.clientWidth;
            var anchorTop = nodeRect.top;
            var anchorBottom = anchorTop + nodeRect.height;
            var effectiveTooltipHeight = tooltipRect.height +
                vz_chart_helpers.TOOLTIP_Y_PIXEL_OFFSET;
            var bottom = null;
            var left = Math.max(this.minDistFromEdge, nodeRect.left);
            var right = null;
            var top = anchorTop;
            if (this.position == TooltipPosition.RIGHT) {
                left = nodeRect.right;
            }
            else {
                top = anchorBottom + vz_chart_helpers.TOOLTIP_Y_PIXEL_OFFSET;
                // prevent it from falling off the right side of the screen.
                if (documentWidth < left + tooltipRect.width + this.minDistFromEdge) {
                    left = null;
                    right = this.minDistFromEdge;
                }
            }
            // If there is not enough space to render tooltip below the anchorNode in
            // the viewport and there is enough space above, place it above the
            // anchorNode.
            if (this.position == TooltipPosition.AUTO &&
                nodeRect.top - effectiveTooltipHeight > 0 &&
                viewportHeight < nodeRect.top + nodeRect.height +
                    effectiveTooltipHeight) {
                top = null;
                bottom = viewportHeight - anchorTop +
                    vz_chart_helpers.TOOLTIP_Y_PIXEL_OFFSET;
            }
            var newStyle = {
                opacity: 1,
                left: left ? left + "px" : null,
                right: right ? right + "px" : null,
                top: top ? top + "px" : null,
                bottom: bottom ? bottom + "px" : null,
            };
            // Do not update the style (which can cause re-layout) if it has not
            // changed.
            if (!_.isEqual(this._styleCache, newStyle)) {
                Object.assign(tooltipContent.style, newStyle);
                this._styleCache = newStyle;
            }
        },
        _createTunnel: function () {
            var div = document.createElement('div');
            div.classList.add(this.is + "-tunnel");
            var template = this.instanceTemplate(this.$.template);
            this.scopeSubtree(template);
            div.appendChild(template);
            document.body.appendChild(div);
            return div;
        },
        _removeTunnel: function (tunnel) {
            document.body.removeChild(tunnel);
        },
    });
})(vz_chart_helper || (vz_chart_helper = {})); // namespace vz_chart_helper
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidnotY2hhcnQtdG9vbHRpcC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbInZ6LWNoYXJ0LXRvb2x0aXAudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7Ozs7Ozs7Z0ZBYWdGO0FBQ2hGLElBQVUsZUFBZSxDQThKeEI7QUE5SkQsV0FBVSxlQUFlO0lBRXpCLElBQVksZUFjWDtJQWRELFdBQVksZUFBZTtRQUN6Qjs7O1dBR0c7UUFDSCxnQ0FBYSxDQUFBO1FBQ2I7O1dBRUc7UUFDSCxvQ0FBaUIsQ0FBQTtRQUNqQjs7V0FFRztRQUNILGtDQUFlLENBQUE7SUFDakIsQ0FBQyxFQWRXLGVBQWUsR0FBZiwrQkFBZSxLQUFmLCtCQUFlLFFBYzFCO0lBUUQsT0FBTyxDQUFDO1FBQ04sRUFBRSxFQUFFLGtCQUFrQjtRQUN0QixVQUFVLEVBQUU7WUFDVjs7ZUFFRztZQUNILFFBQVEsRUFBRTtnQkFDUixJQUFJLEVBQUUsTUFBTTtnQkFDWixLQUFLLEVBQUUsZUFBZSxDQUFDLElBQUk7YUFDNUI7WUFFRDs7ZUFFRztZQUNILGVBQWUsRUFBRTtnQkFDZixJQUFJLEVBQUUsTUFBTTtnQkFDWixLQUFLLEVBQUUsRUFBRTthQUNWO1NBQ0Y7UUFFRCxLQUFLO1lBQ0gsSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUM7WUFDeEIsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUM7WUFDakIsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUM7UUFDdEIsQ0FBQztRQUVELFFBQVE7WUFDTixJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUN0QyxDQUFDO1FBRUQsUUFBUTtZQUNOLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQztZQUNaLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQ2pDLElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDO1FBQ3RCLENBQUM7UUFFRCxJQUFJO1lBQ0YsTUFBTSxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUN2QyxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQztZQUN4QixJQUFJLENBQUMsT0FBTyxFQUFFLENBQUMsS0FBSyxDQUFDLE9BQU8sR0FBRyxDQUFDLENBQUM7UUFDbkMsQ0FBQztRQUVELE9BQU8sRUFBUDtZQUNFLE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQztRQUN4QyxDQUFDO1FBRUQ7Ozs7V0FJRztRQUNILGlCQUFpQixZQUFDLFVBQW1CLEVBQUUsTUFBaUI7WUFBeEQsaUJBUUM7WUFQQyxNQUFNLENBQUMsT0FBTyxDQUFDLFVBQUEsR0FBRyxJQUFJLE9BQUEsS0FBSSxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsRUFBdEIsQ0FBc0IsQ0FBQyxDQUFDO1lBRTlDLE1BQU0sQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDdkMsSUFBSSxDQUFDLElBQUksR0FBRyxNQUFNLENBQUMscUJBQXFCLENBQUM7Z0JBQ3ZDLElBQUksQ0FBQyxLQUFJLENBQUMsVUFBVTtvQkFBRSxPQUFPO2dCQUM3QixLQUFJLENBQUMsZUFBZSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBQ25DLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQztRQUVELGVBQWUsWUFBQyxVQUFtQjtZQUNqQyxJQUFNLGNBQWMsR0FBRyxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7WUFFdEMsSUFBTSxRQUFRLEdBQUcsVUFBVSxDQUFDLHFCQUFxQixFQUFFLENBQUM7WUFDcEQsSUFBTSxXQUFXLEdBQUcsY0FBYyxDQUFDLHFCQUFxQixFQUFFLENBQUM7WUFDM0QsSUFBTSxjQUFjLEdBQUcsTUFBTSxDQUFDLFdBQVcsQ0FBQztZQUMxQyxJQUFNLGFBQWEsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQztZQUVoRCxJQUFNLFNBQVMsR0FBRyxRQUFRLENBQUMsR0FBRyxDQUFDO1lBQy9CLElBQU0sWUFBWSxHQUFHLFNBQVMsR0FBRyxRQUFRLENBQUMsTUFBTSxDQUFDO1lBQ2pELElBQU0sc0JBQXNCLEdBQUcsV0FBVyxDQUFDLE1BQU07Z0JBQzdDLGdCQUFnQixDQUFDLHNCQUFzQixDQUFDO1lBRTVDLElBQUksTUFBTSxHQUFHLElBQUksQ0FBQztZQUNsQixJQUFJLElBQUksR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxlQUFlLEVBQUUsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQ3pELElBQUksS0FBSyxHQUFHLElBQUksQ0FBQztZQUNqQixJQUFJLEdBQUcsR0FBRyxTQUFTLENBQUM7WUFFcEIsSUFBSSxJQUFJLENBQUMsUUFBUSxJQUFJLGVBQWUsQ0FBQyxLQUFLLEVBQUU7Z0JBQzFDLElBQUksR0FBRyxRQUFRLENBQUMsS0FBSyxDQUFDO2FBQ3ZCO2lCQUFNO2dCQUNMLEdBQUcsR0FBRyxZQUFZLEdBQUcsZ0JBQWdCLENBQUMsc0JBQXNCLENBQUM7Z0JBRTdELDREQUE0RDtnQkFDNUQsSUFBSSxhQUFhLEdBQUcsSUFBSSxHQUFHLFdBQVcsQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLGVBQWUsRUFBRTtvQkFDbkUsSUFBSSxHQUFHLElBQUksQ0FBQztvQkFDWixLQUFLLEdBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQztpQkFDOUI7YUFDRjtZQUVELHlFQUF5RTtZQUN6RSxtRUFBbUU7WUFDbkUsY0FBYztZQUNkLElBQUksSUFBSSxDQUFDLFFBQVEsSUFBSSxlQUFlLENBQUMsSUFBSTtnQkFDckMsUUFBUSxDQUFDLEdBQUcsR0FBRyxzQkFBc0IsR0FBRyxDQUFDO2dCQUN6QyxjQUFjLEdBQUcsUUFBUSxDQUFDLEdBQUcsR0FBRyxRQUFRLENBQUMsTUFBTTtvQkFDM0Msc0JBQXNCLEVBQUU7Z0JBQzlCLEdBQUcsR0FBRyxJQUFJLENBQUM7Z0JBQ1gsTUFBTSxHQUFHLGNBQWMsR0FBRyxTQUFTO29CQUMvQixnQkFBZ0IsQ0FBQyxzQkFBc0IsQ0FBQzthQUM3QztZQUVELElBQU0sUUFBUSxHQUFHO2dCQUNmLE9BQU8sRUFBRSxDQUFDO2dCQUNWLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFJLElBQUksT0FBSSxDQUFDLENBQUMsQ0FBQyxJQUFJO2dCQUMvQixLQUFLLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBSSxLQUFLLE9BQUksQ0FBQyxDQUFDLENBQUMsSUFBSTtnQkFDbEMsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUksR0FBRyxPQUFJLENBQUMsQ0FBQyxDQUFDLElBQUk7Z0JBQzVCLE1BQU0sRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFJLE1BQU0sT0FBSSxDQUFDLENBQUMsQ0FBQyxJQUFJO2FBQ3RDLENBQUM7WUFFRixvRUFBb0U7WUFDcEUsV0FBVztZQUNYLElBQUksQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUUsUUFBUSxDQUFDLEVBQUU7Z0JBQzFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLEtBQUssRUFBRSxRQUFRLENBQUMsQ0FBQztnQkFDOUMsSUFBSSxDQUFDLFdBQVcsR0FBRyxRQUFRLENBQUM7YUFDN0I7UUFDSCxDQUFDO1FBRUQsYUFBYSxFQUFiO1lBQ0UsSUFBTSxHQUFHLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUMxQyxHQUFHLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBSSxJQUFJLENBQUMsRUFBRSxZQUFTLENBQUMsQ0FBQztZQUN2QyxJQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUN4RCxJQUFJLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQzVCLEdBQUcsQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFDLENBQUM7WUFDMUIsUUFBUSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDL0IsT0FBTyxHQUFHLENBQUM7UUFDYixDQUFDO1FBRUQsYUFBYSxZQUFDLE1BQWU7WUFDM0IsUUFBUSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDcEMsQ0FBQztLQUNGLENBQUMsQ0FBQztBQUVILENBQUMsRUE5SlMsZUFBZSxLQUFmLGVBQWUsUUE4SnhCLENBQUUsNEJBQTRCIiwic291cmNlc0NvbnRlbnQiOlsiLyogQ29weXJpZ2h0IDIwMTggVGhlIFRlbnNvckZsb3cgQXV0aG9ycy4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cblxuTGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlLCBWZXJzaW9uIDIuMCAodGhlIFwiTGljZW5zZVwiKTtcbnlvdSBtYXkgbm90IHVzZSB0aGlzIGZpbGUgZXhjZXB0IGluIGNvbXBsaWFuY2Ugd2l0aCB0aGUgTGljZW5zZS5cbllvdSBtYXkgb2J0YWluIGEgY29weSBvZiB0aGUgTGljZW5zZSBhdFxuXG4gICAgaHR0cDovL3d3dy5hcGFjaGUub3JnL2xpY2Vuc2VzL0xJQ0VOU0UtMi4wXG5cblVubGVzcyByZXF1aXJlZCBieSBhcHBsaWNhYmxlIGxhdyBvciBhZ3JlZWQgdG8gaW4gd3JpdGluZywgc29mdHdhcmVcbmRpc3RyaWJ1dGVkIHVuZGVyIHRoZSBMaWNlbnNlIGlzIGRpc3RyaWJ1dGVkIG9uIGFuIFwiQVMgSVNcIiBCQVNJUyxcbldJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWSBLSU5ELCBlaXRoZXIgZXhwcmVzcyBvciBpbXBsaWVkLlxuU2VlIHRoZSBMaWNlbnNlIGZvciB0aGUgc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nIHBlcm1pc3Npb25zIGFuZFxubGltaXRhdGlvbnMgdW5kZXIgdGhlIExpY2Vuc2UuXG49PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0qL1xubmFtZXNwYWNlIHZ6X2NoYXJ0X2hlbHBlciB7XG5cbmV4cG9ydCBlbnVtIFRvb2x0aXBQb3NpdGlvbiB7XG4gIC8qKlxuICAgKiBQb3NpdGlvbnMgdGhlIHRvb2x0aXAgdG8gdGhlIGJvdHRvbSBvZiB0aGUgY2hhcnQgaW4gbW9zdCBjYXNlLiBQb3NpdGlvbnNcbiAgICogdGhlIHRvb2x0aXAgYWJvdmUgdGhlIGNoYXJ0IGlmIHRoZXJlIGlzbid0IHN1ZmZpY2llbnQgc3BhY2UgYmVsb3cuXG4gICAqL1xuICBBVVRPID0gJ2F1dG8nLFxuICAvKipcbiAgICogUG9zaXRpb24gdGhlIHRvb2x0aXAgb24gdGhlIGJvdHRvbSBvZiB0aGUgY2hhcnQuXG4gICAqL1xuICBCT1RUT00gPSAnYm90dG9tJyxcbiAgLyoqXG4gICAqIFBvc2l0aW9ucyB0aGUgdG9vbHRpcCB0byB0aGUgcmlnaHQgb2YgdGhlIGNoYXJ0LlxuICAgKi9cbiAgUklHSFQgPSAncmlnaHQnLFxufVxuXG5leHBvcnQgaW50ZXJmYWNlIFZ6Q2hhcnRUb29sdGlwIGV4dGVuZHMgRWxlbWVudCB7XG4gIGNvbnRlbnQoKTogRWxlbWVudDtcbiAgaGlkZSgpOiB2b2lkO1xuICB1cGRhdGVBbmRQb3NpdGlvbihhbmNob3JOb2RlOiBFbGVtZW50LCBuZXdEb206IEFycmF5PGFueT4pOiB2b2lkO1xufVxuXG5Qb2x5bWVyKHtcbiAgaXM6ICd2ei1jaGFydC10b29sdGlwJyxcbiAgcHJvcGVydGllczoge1xuICAgIC8qKlxuICAgICAqIFBvc3NpYmxlIHZhbHVlcyBhcmUgVG9vbHRpcFBvc2l0aW9uLkJPVFRPTSBhbmQgVG9vbHRpcFBvc2l0aW9uLlJJR0hULlxuICAgICAqL1xuICAgIHBvc2l0aW9uOiB7XG4gICAgICB0eXBlOiBTdHJpbmcsXG4gICAgICB2YWx1ZTogVG9vbHRpcFBvc2l0aW9uLkFVVE8sXG4gICAgfSxcblxuICAgIC8qKlxuICAgICAqIE1pbmltdW0gaW5zdGFuY2UgZnJvbSB0aGUgZWRnZSBvZiB0aGUgc2NyZWVuLlxuICAgICAqL1xuICAgIG1pbkRpc3RGcm9tRWRnZToge1xuICAgICAgdHlwZTogTnVtYmVyLFxuICAgICAgdmFsdWU6IDE1LFxuICAgIH0sXG4gIH0sXG5cbiAgcmVhZHkoKSB7XG4gICAgdGhpcy5fc3R5bGVDYWNoZSA9IG51bGw7XG4gICAgdGhpcy5fcmFmID0gbnVsbDtcbiAgICB0aGlzLl90dW5uZWwgPSBudWxsO1xuICB9LFxuXG4gIGF0dGFjaGVkKCkge1xuICAgIHRoaXMuX3R1bm5lbCA9IHRoaXMuX2NyZWF0ZVR1bm5lbCgpO1xuICB9LFxuXG4gIGRldGFjaGVkKCkge1xuICAgIHRoaXMuaGlkZSgpO1xuICAgIHRoaXMuX3JlbW92ZVR1bm5lbCh0aGlzLl90dW5uZWwpO1xuICAgIHRoaXMuX3R1bm5lbCA9IG51bGw7XG4gIH0sXG5cbiAgaGlkZSgpIHtcbiAgICB3aW5kb3cuY2FuY2VsQW5pbWF0aW9uRnJhbWUodGhpcy5fcmFmKTtcbiAgICB0aGlzLl9zdHlsZUNhY2hlID0gbnVsbDtcbiAgICB0aGlzLmNvbnRlbnQoKS5zdHlsZS5vcGFjaXR5ID0gMDtcbiAgfSxcblxuICBjb250ZW50KCk6IEVsZW1lbnQge1xuICAgIHJldHVybiB0aGlzLl90dW5uZWwuZmlyc3RFbGVtZW50Q2hpbGQ7XG4gIH0sXG5cbiAgLyoqXG4gICAqIENTUyBTY29wZXMgdGhlIG5ld2x5IGFkZGVkIERPTSAoaW4gbW9zdCB0b29sdGlwIHdoZXJlIGNvbHVtbnMgYXJlXG4gICAqIGludmFyaWFibGUsIG9ubHkgbmV3bHkgYWRkZWQgcm93cyBhcmUgbmVjZXNzYXJ5IHRvIGJlIHNjb3BlZCkgYW5kIHBvc2l0aW9uc1xuICAgKiB0aGUgdG9vbHRpcCB3aXRoIHJlc3BlY3QgdG8gdGhlIGFuY2hvck5vZGUuXG4gICAqL1xuICB1cGRhdGVBbmRQb3NpdGlvbihhbmNob3JOb2RlOiBFbGVtZW50LCBuZXdEb206IEVsZW1lbnRbXSkge1xuICAgIG5ld0RvbS5mb3JFYWNoKHJvdyA9PiB0aGlzLnNjb3BlU3VidHJlZShyb3cpKTtcblxuICAgIHdpbmRvdy5jYW5jZWxBbmltYXRpb25GcmFtZSh0aGlzLl9yYWYpO1xuICAgIHRoaXMuX3JhZiA9IHdpbmRvdy5yZXF1ZXN0QW5pbWF0aW9uRnJhbWUoKCkgPT4ge1xuICAgICAgaWYgKCF0aGlzLmlzQXR0YWNoZWQpIHJldHVybjtcbiAgICAgIHRoaXMuX3JlcG9zaXRpb25JbXBsKGFuY2hvck5vZGUpO1xuICAgIH0pO1xuICB9LFxuXG4gIF9yZXBvc2l0aW9uSW1wbChhbmNob3JOb2RlOiBFbGVtZW50KSB7XG4gICAgY29uc3QgdG9vbHRpcENvbnRlbnQgPSB0aGlzLmNvbnRlbnQoKTtcblxuICAgIGNvbnN0IG5vZGVSZWN0ID0gYW5jaG9yTm9kZS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgICBjb25zdCB0b29sdGlwUmVjdCA9IHRvb2x0aXBDb250ZW50LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuICAgIGNvbnN0IHZpZXdwb3J0SGVpZ2h0ID0gd2luZG93LmlubmVySGVpZ2h0O1xuICAgIGNvbnN0IGRvY3VtZW50V2lkdGggPSBkb2N1bWVudC5ib2R5LmNsaWVudFdpZHRoO1xuXG4gICAgY29uc3QgYW5jaG9yVG9wID0gbm9kZVJlY3QudG9wO1xuICAgIGNvbnN0IGFuY2hvckJvdHRvbSA9IGFuY2hvclRvcCArIG5vZGVSZWN0LmhlaWdodDtcbiAgICBjb25zdCBlZmZlY3RpdmVUb29sdGlwSGVpZ2h0ID0gdG9vbHRpcFJlY3QuaGVpZ2h0ICtcbiAgICAgICAgdnpfY2hhcnRfaGVscGVycy5UT09MVElQX1lfUElYRUxfT0ZGU0VUO1xuXG4gICAgbGV0IGJvdHRvbSA9IG51bGw7XG4gICAgbGV0IGxlZnQgPSBNYXRoLm1heCh0aGlzLm1pbkRpc3RGcm9tRWRnZSwgbm9kZVJlY3QubGVmdCk7XG4gICAgbGV0IHJpZ2h0ID0gbnVsbDtcbiAgICBsZXQgdG9wID0gYW5jaG9yVG9wO1xuXG4gICAgaWYgKHRoaXMucG9zaXRpb24gPT0gVG9vbHRpcFBvc2l0aW9uLlJJR0hUKSB7XG4gICAgICBsZWZ0ID0gbm9kZVJlY3QucmlnaHQ7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRvcCA9IGFuY2hvckJvdHRvbSArIHZ6X2NoYXJ0X2hlbHBlcnMuVE9PTFRJUF9ZX1BJWEVMX09GRlNFVDtcblxuICAgICAgLy8gcHJldmVudCBpdCBmcm9tIGZhbGxpbmcgb2ZmIHRoZSByaWdodCBzaWRlIG9mIHRoZSBzY3JlZW4uXG4gICAgICBpZiAoZG9jdW1lbnRXaWR0aCA8IGxlZnQgKyB0b29sdGlwUmVjdC53aWR0aCArIHRoaXMubWluRGlzdEZyb21FZGdlKSB7XG4gICAgICAgIGxlZnQgPSBudWxsO1xuICAgICAgICByaWdodCA9IHRoaXMubWluRGlzdEZyb21FZGdlO1xuICAgICAgfVxuICAgIH1cblxuICAgIC8vIElmIHRoZXJlIGlzIG5vdCBlbm91Z2ggc3BhY2UgdG8gcmVuZGVyIHRvb2x0aXAgYmVsb3cgdGhlIGFuY2hvck5vZGUgaW5cbiAgICAvLyB0aGUgdmlld3BvcnQgYW5kIHRoZXJlIGlzIGVub3VnaCBzcGFjZSBhYm92ZSwgcGxhY2UgaXQgYWJvdmUgdGhlXG4gICAgLy8gYW5jaG9yTm9kZS5cbiAgICBpZiAodGhpcy5wb3NpdGlvbiA9PSBUb29sdGlwUG9zaXRpb24uQVVUTyAmJlxuICAgICAgICBub2RlUmVjdC50b3AgLSBlZmZlY3RpdmVUb29sdGlwSGVpZ2h0ID4gMCAmJlxuICAgICAgICB2aWV3cG9ydEhlaWdodCA8IG5vZGVSZWN0LnRvcCArIG5vZGVSZWN0LmhlaWdodCArXG4gICAgICAgICAgICBlZmZlY3RpdmVUb29sdGlwSGVpZ2h0KSB7XG4gICAgICB0b3AgPSBudWxsO1xuICAgICAgYm90dG9tID0gdmlld3BvcnRIZWlnaHQgLSBhbmNob3JUb3AgK1xuICAgICAgICAgIHZ6X2NoYXJ0X2hlbHBlcnMuVE9PTFRJUF9ZX1BJWEVMX09GRlNFVDtcbiAgICB9XG5cbiAgICBjb25zdCBuZXdTdHlsZSA9IHtcbiAgICAgIG9wYWNpdHk6IDEsXG4gICAgICBsZWZ0OiBsZWZ0ID8gYCR7bGVmdH1weGAgOiBudWxsLFxuICAgICAgcmlnaHQ6IHJpZ2h0ID8gYCR7cmlnaHR9cHhgIDogbnVsbCxcbiAgICAgIHRvcDogdG9wID8gYCR7dG9wfXB4YCA6IG51bGwsXG4gICAgICBib3R0b206IGJvdHRvbSA/IGAke2JvdHRvbX1weGAgOiBudWxsLFxuICAgIH07XG5cbiAgICAvLyBEbyBub3QgdXBkYXRlIHRoZSBzdHlsZSAod2hpY2ggY2FuIGNhdXNlIHJlLWxheW91dCkgaWYgaXQgaGFzIG5vdFxuICAgIC8vIGNoYW5nZWQuXG4gICAgaWYgKCFfLmlzRXF1YWwodGhpcy5fc3R5bGVDYWNoZSwgbmV3U3R5bGUpKSB7XG4gICAgICBPYmplY3QuYXNzaWduKHRvb2x0aXBDb250ZW50LnN0eWxlLCBuZXdTdHlsZSk7XG4gICAgICB0aGlzLl9zdHlsZUNhY2hlID0gbmV3U3R5bGU7XG4gICAgfVxuICB9LFxuXG4gIF9jcmVhdGVUdW5uZWwoKTogRWxlbWVudCB7XG4gICAgY29uc3QgZGl2ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gICAgZGl2LmNsYXNzTGlzdC5hZGQoYCR7dGhpcy5pc30tdHVubmVsYCk7XG4gICAgY29uc3QgdGVtcGxhdGUgPSB0aGlzLmluc3RhbmNlVGVtcGxhdGUodGhpcy4kLnRlbXBsYXRlKTtcbiAgICB0aGlzLnNjb3BlU3VidHJlZSh0ZW1wbGF0ZSk7XG4gICAgZGl2LmFwcGVuZENoaWxkKHRlbXBsYXRlKTtcbiAgICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKGRpdik7XG4gICAgcmV0dXJuIGRpdjtcbiAgfSxcblxuICBfcmVtb3ZlVHVubmVsKHR1bm5lbDogRWxlbWVudCkge1xuICAgIGRvY3VtZW50LmJvZHkucmVtb3ZlQ2hpbGQodHVubmVsKTtcbiAgfSxcbn0pO1xuXG59ICAvLyBuYW1lc3BhY2UgdnpfY2hhcnRfaGVscGVyXG4iXX0=