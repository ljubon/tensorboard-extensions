/* Copyright 2015 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
var vz_line_chart;
(function (vz_line_chart) {
    /**
     * The maximum number of marker symbols within any line for a data series. Too
     * many markers clutter the chart.
     */
    var _MAX_MARKERS = 20;
    Polymer({
        is: 'vz-line-chart',
        properties: {
            /**
             * Scale that maps series names to colors. The default colors are from
             * d3.schemeCategory10. Use this property to replace the default line
             * colors with colors of your own choice.
             * @type {Plottable.Scales.Color}
             * @required
             */
            colorScale: {
                type: Object,
                value: function () {
                    return new Plottable.Scales.Color().range(d3.schemeCategory10);
                }
            },
            /**
             * A function that takes a data series string and returns a
             * Plottable.SymbolFactory to use for rendering that series. This property
             * implements the vz_chart_helpers.SymbolFn interface.
             */
            symbolFunction: Object,
            /**
             * Whether smoothing is enabled or not. If true, smoothed lines will be
             * plotted in the chart while the unsmoothed lines will be ghosted in
             * the background.
             *
             * The smoothing algorithm is a simple moving average, which, given a
             * point p and a window w, replaces p with a simple average of the
             * points in the [p - floor(w/2), p + floor(w/2)] range.  If there
             * aren't enough points to cover the entire window to the left, the
             * window is reduced to fit exactly the amount of elements available.
             * This means that the smoothed line will be less in and gradually
             * become more smooth until the desired window is reached. However when
             * there aren't enough points on the right, the line stops being
             * rendered at all.
             */
            smoothingEnabled: {
                type: Boolean,
                notify: true,
                value: false,
            },
            /**
             * Weight (between 0.0 and 1.0) of the smoothing. This weight controls
             * the window size, and a weight of 1.0 means using 50% of the entire
             * dataset as the window, while a weight of 0.0 means using a window of
             * 0 (and thus replacing each point with themselves).
             *
             * The growth between 0.0 and 1.0 is not linear though. Because
             * changing the window from 0% to 30% of the dataset smooths the line a
             * lot more than changing the window from 70% to 100%, an exponential
             * function is used instead: http://i.imgur.com/bDrhEZU.png. This
             * function increases the size of the window slowly at the beginning
             * and gradually speeds up the growth, but 0.0 still means a window of
             * 0 and 1.0 still means a window of the dataset's length.
             */
            smoothingWeight: { type: Number, value: 0.6 },
            /**
             * This is a helper field for automatically generating commonly used
             * functions for xComponentsCreationMethod. Valid values are what can
             * be processed by vz_chart_helpers.getXComponents() and include
             * "step", "wall_time", and "relative".
             */
            xType: { type: String, value: '' },
            /**
             * We accept a function for creating an XComponents object instead of such
             * an object itself because the Axis must be made right when we make the
             * LineChart object, lest we use a previously destroyed Axis. See the async
             * logic below that uses this property.
             *
             * Note that this function returns a function because polymer calls the
             * outer function to compute the value. We actually want the value of this
             * property to be the inner function.
             *
             * @type {function(): vz_chart_helpers.XComponents}
             */
            xComponentsCreationMethod: {
                type: Object,
                /* Note: We have to provide a nonsense value for
                 * xComponentsCreationMethod here, because Polymer observers only
                 * trigger after all parameters are set. */
                value: ''
            },
            /**
             * A formatter for values along the X-axis. Optional. Defaults to a
             * reasonable formatter.
             *
             * @type {function(number): string}
             */
            xAxisFormatter: Object,
            /**
             * A formatter for values along the Y-axis. Optional. Defaults to a
             * reasonable formatter.
             *
             * @type {function(number): string}
             */
            yAxisFormatter: Object,
            /**
             * A method that implements the Plottable.IAccessor<number> interface. Used
             * for accessing the y value from a data point.
             *
             * Note that this function returns a function because polymer calls the
             * outer function to compute the value. We actually want the value of this
             * property to be the inner function.
             */
            yValueAccessor: { type: Object, value: function () { return (function (d) { return d.scalar; }); } },
            /**
             * An array of ChartHelper.TooltipColumn objects. Used to populate the table
             * within the tooltip. The table contains 1 row per run.
             *
             * Note that this function returns a function because polymer calls the
             * outer function to compute the value. We actually want the value of this
             * property to be the inner function.
             *
             */
            tooltipColumns: {
                type: Array,
                value: function () {
                    var valueFormatter = vz_chart_helpers.multiscaleFormatter(vz_chart_helpers.Y_TOOLTIP_FORMATTER_PRECISION);
                    var formatValueOrNaN = function (x) { return isNaN(x) ? 'NaN' : valueFormatter(x); };
                    return [
                        {
                            title: 'Name',
                            evaluate: function (d) { return d.dataset.metadata().name; },
                        },
                        {
                            title: 'Smoothed',
                            evaluate: function (d, statusObject) {
                                var smoothingEnabled = statusObject && statusObject.smoothingEnabled;
                                return formatValueOrNaN(smoothingEnabled ? d.datum.smoothed : d.datum.scalar);
                            },
                        },
                        {
                            title: 'Value',
                            evaluate: function (d) { return formatValueOrNaN(d.datum.scalar); },
                        },
                        {
                            title: 'Step',
                            evaluate: function (d) { return vz_chart_helpers.stepFormatter(d.datum.step); },
                        },
                        {
                            title: 'Time',
                            evaluate: function (d) { return vz_chart_helpers.timeFormatter(d.datum.wall_time); },
                        },
                        {
                            title: 'Relative',
                            evaluate: function (d) { return vz_chart_helpers.relativeFormatter(vz_chart_helpers.relativeAccessor(d.datum, -1, d.dataset)); },
                        },
                    ];
                }
            },
            /**
             * An optional FillArea object. If provided, the chart will
             * visualize fill area alongside the primary line for each series. If set,
             * consider setting ignoreYOutliers to false. Otherwise, outlier
             * calculations may deem some margins to be outliers, and some portions of
             * the fill area may not display.
             */
            fillArea: Object,
            /**
             * An optional array of 2 numbers for the min and max of the default range
             * of the Y axis. If not provided, a reasonable range will be generated.
             * This property is a list instead of 2 individual properties to emphasize
             * that both the min and the max must be specified (or neither at all).
             */
            defaultXRange: Array,
            /**
             * An optional array of 2 numbers for the min and max of the default range
             * of the Y axis. If not provided, a reasonable range will be generated.
             * This property is a list instead of 2 individual properties to emphasize
             * that both the min and the max must be specified (or neither at all).
             */
            defaultYRange: Array,
            /**
             * Tooltip header innerHTML text. We cannot use a dom-repeat inside of a
             * table element because Polymer does not support that. This seems like
             * a bug in Polymer. Hence, we manually generate the HTML for creating a row
             * of table headers.
             */
            _tooltipTableHeaderHtml: {
                type: String,
                computed: "_computeTooltipTableHeaderHtml(tooltipColumns)",
            },
            /**
             * The scale for the y-axis. Allows:
             * - "linear" - linear scale (Plottable.Scales.Linear)
             * - "log" - modified-log scale (Plottable.Scales.ModifiedLog)
             */
            yScaleType: { type: String, value: 'linear' },
            /**
             * Whether to ignore outlier data when computing the yScale domain.
             */
            ignoreYOutliers: {
                type: Boolean,
                value: false,
            },
            /**
             * Change how the tooltip is sorted. Allows:
             * - "default" - Sort the tooltip by input order.
             * - "ascending" - Sort the tooltip by ascending value.
             * - "descending" - Sort the tooltip by descending value.
             * - "nearest" - Sort the tooltip by closest to cursor.
             */
            tooltipSortingMethod: { type: String, value: 'default' },
            /**
             * Change how the tooltip is positioned. Allows:
             * - "bottom" - Position the tooltip on the bottom of the chart.
             * - "right" - Position the tooltip to the right of the chart.
             */
            tooltipPosition: { type: String, value: 'bottom' },
            _attached: Boolean,
            _chart: Object,
            _visibleSeriesCache: {
                type: Array,
                value: function () {
                    return [];
                }
            },
            _seriesDataCache: {
                type: Object,
                value: function () {
                    return {};
                }
            },
            _makeChartAsyncCallbackId: { type: Number, value: null },
        },
        observers: [
            '_makeChart(xComponentsCreationMethod, xType, yValueAccessor, yScaleType, tooltipColumns, colorScale, _attached)',
            '_reloadFromCache(_chart)',
            '_smoothingChanged(smoothingEnabled, smoothingWeight, _chart)',
            '_tooltipSortingMethodChanged(tooltipSortingMethod, _chart)',
            '_tooltipPositionChanged(tooltipPosition, _chart)',
            '_outliersChanged(ignoreYOutliers, _chart)'
        ],
        /**
         * Sets the series that the chart displays. Series with other names will
         * not be displayed.
         *
         * @param {Array<String>} names Array with the names of the series to
         * display.
         */
        setVisibleSeries: function (names) {
            this._visibleSeriesCache = names;
            if (this._chart) {
                this._chart.setVisibleSeries(names);
                this.redraw();
            }
        },
        /**
         * Sets the data of one of the series. Note that to display this series
         * its name must be in the setVisibleSeries() array.
         *
         * @param {string} name Name of the series.
         * @param {Array< vz_chart_helpers.ScalarDatum>} data Data of the series.
         * This is an array of objects with at least the following properties:
         * - step: (Number) - index of the datum.
         * - wall_time: (Date) - Date object with the datum's time.
         * - scalar: (Number) - Value of the datum.
         */
        setSeriesData: function (name, data) {
            this._seriesDataCache[name] = data;
            if (this._chart) {
                this._chart.setSeriesData(name, data);
            }
        },
        /**
         * Reset the chart domain. If the chart has not rendered yet, a call to this
         * method no-ops.
         */
        resetDomain: function () {
            if (this._chart) {
                this._chart.resetDomain();
            }
        },
        /**
         * Re-renders the chart. Useful if e.g. the container size changed.
         */
        redraw: function () {
            if (this._chart) {
                this._chart.redraw();
            }
        },
        attached: function () {
            this._attached = true;
        },
        detached: function () {
            if (this._chart)
                this._chart.destroy();
            this._attached = false;
        },
        ready: function () {
            this.scopeSubtree(this.$.tooltip, true);
            this.scopeSubtree(this.$.chartdiv, true);
        },
        /**
         * Creates a chart, and asynchronously renders it. Fires a chart-rendered
         * event after the chart is rendered.
         */
        _makeChart: function (xComponentsCreationMethod, xType, yValueAccessor, yScaleType, tooltipColumns, colorScale, _attached) {
            // Find the actual xComponentsCreationMethod.
            if (!xType && !xComponentsCreationMethod) {
                xComponentsCreationMethod = vz_chart_helpers.stepX;
            }
            else if (xType) {
                xComponentsCreationMethod = function () {
                    return vz_chart_helpers.getXComponents(xType);
                };
            }
            if (this._makeChartAsyncCallbackId !== null) {
                this.cancelAsync(this._makeChartAsyncCallbackId);
                this._makeChartAsyncCallbackId = null;
            }
            this._makeChartAsyncCallbackId = this.async(function () {
                this._makeChartAsyncCallbackId = null;
                if (!this._attached ||
                    !xComponentsCreationMethod ||
                    !this.yValueAccessor ||
                    !this.tooltipColumns) {
                    return;
                }
                var tooltip = d3.select(this.$.tooltip);
                // We directly reference properties of `this` because this call is
                // asynchronous, and values may have changed in between the call being
                // initiated and actually being run.
                var chart = new LineChart(xComponentsCreationMethod, this.yValueAccessor, yScaleType, colorScale, tooltip, this.tooltipColumns, this.fillArea, this.defaultXRange, this.defaultYRange, this.symbolFunction, this.xAxisFormatter, this.yAxisFormatter);
                var div = d3.select(this.$.chartdiv);
                chart.renderTo(div);
                if (this._chart)
                    this._chart.destroy();
                this._chart = chart;
            }, 350);
        },
        _reloadFromCache: function () {
            if (this._chart) {
                this._chart.setVisibleSeries(this._visibleSeriesCache);
                this._visibleSeriesCache.forEach(function (name) {
                    this._chart.setSeriesData(name, this._seriesDataCache[name] || []);
                }.bind(this));
            }
        },
        _smoothingChanged: function () {
            if (!this._chart) {
                return;
            }
            if (this.smoothingEnabled) {
                this._chart.smoothingUpdate(this.smoothingWeight);
            }
            else {
                this._chart.smoothingDisable();
            }
        },
        _outliersChanged: function () {
            if (!this._chart) {
                return;
            }
            this._chart.ignoreYOutliers(this.ignoreYOutliers);
        },
        _tooltipSortingMethodChanged: function () {
            if (this._chart) {
                this._chart.setTooltipSortingMethod(this.tooltipSortingMethod);
            }
        },
        _tooltipPositionChanged: function () {
            if (this._chart) {
                this._chart.setTooltipPosition(this.tooltipPosition);
            }
        },
        _computeTooltipTableHeaderHtml: function (tooltipColumns) {
            var _this = this;
            // The first column contains the circle with the color of the run.
            var titles = [""].concat(_.map(tooltipColumns, 'title'));
            return titles.map(function (title) { return "<th>" + _this._sanitize(title) + "</th>"; }).join('');
        },
        _sanitize: function (value) {
            return value.replace(/</g, '&lt;')
                .replace(/>/g, '&gt;') // for symmetry :-)
                .replace(/&/g, '&amp;');
        },
    });
    var LineChart = /** @class */ (function () {
        function LineChart(xComponentsCreationMethod, yValueAccessor, yScaleType, colorScale, tooltip, tooltipColumns, fillArea, defaultXRange, defaultYRange, symbolFunction, xAxisFormatter, yAxisFormatter) {
            this.seriesNames = [];
            this.name2datasets = {};
            this.colorScale = colorScale;
            this.tooltip = tooltip;
            this.datasets = [];
            this._ignoreYOutliers = false;
            // lastPointDataset is a dataset that contains just the last point of
            // every dataset we're currently drawing.
            this.lastPointsDataset = new Plottable.Dataset();
            this.nanDataset = new Plottable.Dataset();
            this.yValueAccessor = yValueAccessor;
            // The symbol function maps series to marker. It uses a special dataset that
            // varies based on whether smoothing is enabled.
            this.symbolFunction = symbolFunction;
            // need to do a single bind, so we can deregister the callback from
            // old Plottable.Datasets. (Deregistration is done by identity checks.)
            this.onDatasetChanged = this._onDatasetChanged.bind(this);
            this._defaultXRange = defaultXRange;
            this._defaultYRange = defaultYRange;
            this.tooltipColumns = tooltipColumns;
            this.buildChart(xComponentsCreationMethod, yValueAccessor, yScaleType, fillArea, xAxisFormatter, yAxisFormatter);
        }
        LineChart.prototype.buildChart = function (xComponentsCreationMethod, yValueAccessor, yScaleType, fillArea, xAxisFormatter, yAxisFormatter) {
            if (this.outer) {
                this.outer.destroy();
            }
            var xComponents = xComponentsCreationMethod();
            this.xAccessor = xComponents.accessor;
            this.xScale = xComponents.scale;
            this.xAxis = xComponents.axis;
            this.xAxis.margin(0).tickLabelPadding(3);
            if (xAxisFormatter) {
                this.xAxis.formatter(xAxisFormatter);
            }
            this.yScale = LineChart.getYScaleFromType(yScaleType);
            this.yAxis = new Plottable.Axes.Numeric(this.yScale, 'left');
            this.yAxis.margin(0).tickLabelPadding(5);
            this.yAxis.formatter(yAxisFormatter ? yAxisFormatter
                : vz_chart_helpers.multiscaleFormatter(vz_chart_helpers.Y_AXIS_FORMATTER_PRECISION));
            this.yAxis.usesTextWidthApproximation(true);
            this.fillArea = fillArea;
            this.dzl = new vz_line_chart.DragZoomLayer(this.xScale, this.yScale, this.resetYDomain.bind(this));
            this.tooltipInteraction = this.createTooltipInteraction(this.dzl);
            this.tooltipPointsComponent = new Plottable.Component();
            var plot = this.buildPlot(this.xScale, this.yScale, fillArea);
            this.gridlines =
                new Plottable.Components.Gridlines(this.xScale, this.yScale);
            var xZeroLine = new Plottable.Components.GuideLineLayer('horizontal');
            xZeroLine.scale(this.yScale).value(0);
            var yZeroLine = new Plottable.Components.GuideLineLayer('vertical');
            yZeroLine.scale(this.xScale).value(0);
            this.center = new Plottable.Components.Group([
                this.gridlines, xZeroLine, yZeroLine, plot,
                this.dzl, this.tooltipPointsComponent
            ]);
            this.outer = new Plottable.Components.Table([[this.yAxis, this.center], [null, this.xAxis]]);
        };
        LineChart.prototype.buildPlot = function (xScale, yScale, fillArea) {
            var _this = this;
            if (fillArea) {
                this.marginAreaPlot = new Plottable.Plots.Area();
                this.marginAreaPlot.x(this.xAccessor, xScale);
                this.marginAreaPlot.y(fillArea.higherAccessor, yScale);
                this.marginAreaPlot.y0(fillArea.lowerAccessor);
                this.marginAreaPlot.attr('fill', function (d, i, dataset) {
                    return _this.colorScale.scale(dataset.metadata().name);
                });
                this.marginAreaPlot.attr('fill-opacity', 0.3);
                this.marginAreaPlot.attr('stroke-width', 0);
            }
            this.smoothedAccessor = function (d) { return d.smoothed; };
            var linePlot = new Plottable.Plots.Line();
            linePlot.x(this.xAccessor, xScale);
            linePlot.y(this.yValueAccessor, yScale);
            linePlot.attr('stroke', function (d, i, dataset) {
                return _this.colorScale.scale(dataset.metadata().name);
            });
            this.linePlot = linePlot;
            this.setupTooltips(linePlot);
            var smoothLinePlot = new Plottable.Plots.Line();
            smoothLinePlot.x(this.xAccessor, xScale);
            smoothLinePlot.y(this.smoothedAccessor, yScale);
            smoothLinePlot.attr('stroke', function (d, i, dataset) {
                return _this.colorScale.scale(dataset.metadata().name);
            });
            this.smoothLinePlot = smoothLinePlot;
            if (this.symbolFunction) {
                var markersScatterPlot = new Plottable.Plots.Scatter();
                markersScatterPlot.x(this.xAccessor, xScale);
                markersScatterPlot.y(this.yValueAccessor, yScale);
                markersScatterPlot.attr('fill', function (d, i, dataset) {
                    return _this.colorScale.scale(dataset.metadata().name);
                });
                markersScatterPlot.attr('opacity', 1);
                markersScatterPlot.size(vz_chart_helpers.TOOLTIP_CIRCLE_SIZE * 2);
                markersScatterPlot.symbol(function (d, i, dataset) {
                    return _this.symbolFunction(dataset.metadata().name);
                });
                // Use a special dataset because this scatter plot should use the accesor
                // that depends on whether smoothing is enabled.
                this.markersScatterPlot = markersScatterPlot;
            }
            // The scatterPlot will display the last point for each dataset.
            // This way, if there is only one datum for the series, it is still
            // visible. We hide it when tooltips are active to keep things clean.
            var scatterPlot = new Plottable.Plots.Scatter();
            scatterPlot.x(this.xAccessor, xScale);
            scatterPlot.y(this.yValueAccessor, yScale);
            scatterPlot.attr('fill', function (d) { return _this.colorScale.scale(d.name); });
            scatterPlot.attr('opacity', 1);
            scatterPlot.size(vz_chart_helpers.TOOLTIP_CIRCLE_SIZE * 2);
            scatterPlot.datasets([this.lastPointsDataset]);
            this.scatterPlot = scatterPlot;
            var nanDisplay = new Plottable.Plots.Scatter();
            nanDisplay.x(this.xAccessor, xScale);
            nanDisplay.y(function (x) { return x.displayY; }, yScale);
            nanDisplay.attr('fill', function (d) { return _this.colorScale.scale(d.name); });
            nanDisplay.attr('opacity', 1);
            nanDisplay.size(vz_chart_helpers.NAN_SYMBOL_SIZE * 2);
            nanDisplay.datasets([this.nanDataset]);
            nanDisplay.symbol(Plottable.SymbolFactories.triangle);
            this.nanDisplay = nanDisplay;
            var groups = [nanDisplay, scatterPlot, smoothLinePlot, linePlot];
            if (this.marginAreaPlot) {
                groups.push(this.marginAreaPlot);
            }
            if (this.markersScatterPlot) {
                groups.push(this.markersScatterPlot);
            }
            return new Plottable.Components.Group(groups);
        };
        /** Updates the chart when a dataset changes. Called every time the data of
         * a dataset changes to update the charts.
         */
        LineChart.prototype._onDatasetChanged = function (dataset) {
            if (this.smoothingEnabled) {
                this.resmoothDataset(dataset);
            }
            this.updateSpecialDatasets();
        };
        LineChart.prototype.ignoreYOutliers = function (ignoreYOutliers) {
            if (ignoreYOutliers !== this._ignoreYOutliers) {
                this._ignoreYOutliers = ignoreYOutliers;
                this.updateSpecialDatasets();
                this.resetYDomain();
            }
        };
        /** Constructs special datasets. Each special dataset contains exceptional
         * values from all of the regular datasets, e.g. last points in series, or
         * NaN values. Those points will have a `name` and `relative` property added
         * (since usually those are context in the surrounding dataset).
         */
        LineChart.prototype.updateSpecialDatasets = function () {
            var accessor = this.getYAxisAccessor();
            var lastPointsData = this.datasets
                .map(function (d) {
                var datum = null;
                // filter out NaNs to ensure last point is a clean one
                var nonNanData = d.data().filter(function (x) { return !isNaN(accessor(x, -1, d)); });
                if (nonNanData.length > 0) {
                    var idx = nonNanData.length - 1;
                    datum = nonNanData[idx];
                    datum.name = d.metadata().name;
                    datum.relative = vz_chart_helpers.relativeAccessor(datum, -1, d);
                }
                return datum;
            })
                .filter(function (x) { return x != null; });
            this.lastPointsDataset.data(lastPointsData);
            if (this.markersScatterPlot) {
                this.markersScatterPlot.datasets(this.datasets.map(this.createSampledDatasetForMarkers));
            }
            // Take a dataset, return an array of NaN data points
            // the NaN points will have a "displayY" property which is the
            // y-value of a nearby point that was not NaN (0 if all points are NaN)
            var datasetToNaNData = function (d) {
                var displayY = null;
                var data = d.data();
                var i = 0;
                while (i < data.length && displayY == null) {
                    if (!isNaN(accessor(data[i], -1, d))) {
                        displayY = accessor(data[i], -1, d);
                    }
                    i++;
                }
                if (displayY == null) {
                    displayY = 0;
                }
                var nanData = [];
                for (i = 0; i < data.length; i++) {
                    if (!isNaN(accessor(data[i], -1, d))) {
                        displayY = accessor(data[i], -1, d);
                    }
                    else {
                        data[i].name = d.metadata().name;
                        data[i].displayY = displayY;
                        data[i].relative = vz_chart_helpers.relativeAccessor(data[i], -1, d);
                        nanData.push(data[i]);
                    }
                }
                return nanData;
            };
            var nanData = _.flatten(this.datasets.map(datasetToNaNData));
            this.nanDataset.data(nanData);
        };
        LineChart.prototype.resetDomain = function () {
            this.resetXDomain();
            this.resetYDomain();
        };
        LineChart.prototype.resetXDomain = function () {
            var xDomain;
            if (this._defaultXRange != null) {
                // Use the range specified by the caller.
                xDomain = this._defaultXRange;
            }
            else {
                // (Copied from DragZoomLayer.unzoom.)
                var xScale = this.xScale;
                xScale._domainMin = null;
                xScale._domainMax = null;
                xDomain = xScale._getExtent();
            }
            this.xScale.domain(xDomain);
        };
        LineChart.prototype.resetYDomain = function () {
            var yDomain;
            if (this._defaultYRange != null) {
                // Use the range specified by the caller.
                yDomain = this._defaultYRange;
            }
            else {
                // Generate a reasonable range.
                var accessors_1 = this.getAccessorsForComputingYRange();
                var datasetToValues = function (d) {
                    return accessors_1.map(function (accessor) { return d.data().map(function (x) { return accessor(x, -1, d); }); });
                };
                var vals = _.flattenDeep(this.datasets.map(datasetToValues))
                    .filter(isFinite);
                yDomain = vz_chart_helpers.computeDomain(vals, this._ignoreYOutliers);
            }
            this.yScale.domain(yDomain);
        };
        LineChart.prototype.getAccessorsForComputingYRange = function () {
            var accessors = [this.getYAxisAccessor()];
            if (this.fillArea) {
                // Make the Y domain take margins into account.
                accessors.push(this.fillArea.lowerAccessor, this.fillArea.higherAccessor);
            }
            return accessors;
        };
        LineChart.prototype.getYAxisAccessor = function () {
            return this.smoothingEnabled ? this.smoothedAccessor : this.yValueAccessor;
        };
        LineChart.prototype.createTooltipInteraction = function (dzl) {
            var _this = this;
            var pi = new Plottable.Interactions.Pointer();
            // Disable interaction while drag zooming.
            dzl.interactionStart(function () {
                pi.enabled(false);
                _this.hideTooltips();
            });
            dzl.interactionEnd(function () { return pi.enabled(true); });
            pi.onPointerMove(function (p) {
                // Line plot must be initialized to draw.
                if (!_this.linePlot)
                    return;
                var target = {
                    x: p.x,
                    y: p.y,
                    datum: null,
                    dataset: null,
                };
                var bbox = _this.gridlines.content().node().getBBox();
                // pts is the closets point to the tooltip for each dataset
                var pts = _this.linePlot.datasets()
                    .map(function (dataset) { return _this.findClosestPoint(target, dataset); })
                    .filter(Boolean);
                var intersectsBBox = Plottable.Utils.DOM.intersectsBBox;
                // We draw tooltips for points that are NaN, or are currently visible
                var ptsForTooltips = pts.filter(function (p) { return intersectsBBox(p.x, p.y, bbox) ||
                    isNaN(_this.yValueAccessor(p.datum, 0, p.dataset)); });
                // Only draw little indicator circles for the non-NaN points
                var ptsToCircle = ptsForTooltips.filter(function (p) { return !isNaN(_this.yValueAccessor(p.datum, 0, p.dataset)); });
                var ptsSelection = _this.tooltipPointsComponent.content().selectAll('.point').data(ptsToCircle, function (p) { return p.dataset.metadata().name; });
                if (pts.length !== 0) {
                    ptsSelection.enter().append('circle').classed('point', true);
                    ptsSelection.attr('r', vz_chart_helpers.TOOLTIP_CIRCLE_SIZE)
                        .attr('cx', function (p) { return p.x; })
                        .attr('cy', function (p) { return p.y; })
                        .style('stroke', 'none')
                        .attr('fill', function (p) { return _this.colorScale.scale(p.dataset.metadata().name); });
                    ptsSelection.exit().remove();
                    _this.drawTooltips(ptsForTooltips, target, _this.tooltipColumns);
                }
                else {
                    _this.hideTooltips();
                }
            });
            pi.onPointerExit(function () { return _this.hideTooltips(); });
            return pi;
        };
        LineChart.prototype.hideTooltips = function () {
            this.tooltip.style('opacity', 0);
            this.scatterPlot.attr('opacity', 1);
            this.tooltipPointsComponent.content().selectAll('.point').remove();
        };
        LineChart.prototype.setupTooltips = function (plot) {
            var _this = this;
            plot.onDetach(function () {
                _this.tooltipInteraction.detachFrom(plot);
                _this.tooltipInteraction.enabled(false);
            });
            plot.onAnchor(function () {
                _this.tooltipInteraction.attachTo(plot);
                _this.tooltipInteraction.enabled(true);
            });
        };
        LineChart.prototype.drawTooltips = function (points, target, tooltipColumns) {
            var _this = this;
            // Formatters for value, step, and wall_time
            this.scatterPlot.attr('opacity', 0);
            var valueFormatter = vz_chart_helpers.multiscaleFormatter(vz_chart_helpers.Y_TOOLTIP_FORMATTER_PRECISION);
            var dist = function (p) {
                return Math.pow(p.x - target.x, 2) + Math.pow(p.y - target.y, 2);
            };
            var closestDist = _.min(points.map(dist));
            var valueSortMethod = this.yValueAccessor;
            if (this.smoothingEnabled) {
                valueSortMethod = this.smoothedAccessor;
            }
            if (this.tooltipSortingMethod === 'ascending') {
                points = _.sortBy(points, function (d) { return valueSortMethod(d.datum, -1, d.dataset); });
            }
            else if (this.tooltipSortingMethod === 'descending') {
                points = _.sortBy(points, function (d) { return valueSortMethod(d.datum, -1, d.dataset); })
                    .reverse();
            }
            else if (this.tooltipSortingMethod === 'nearest') {
                points = _.sortBy(points, dist);
            }
            else {
                // The 'default' sorting method maintains the order of names passed to
                // setVisibleSeries(). However we reverse that order when defining the
                // datasets. So we must call reverse again to restore the order.
                points = points.slice(0).reverse();
            }
            var rows = this.tooltip.select('tbody')
                .html('')
                .selectAll('tr')
                .data(points)
                .enter()
                .append('tr');
            // Grey out the point if any of the following are true:
            // - The cursor is outside of the x-extent of the dataset
            // - The point's y value is NaN
            rows.classed('distant', function (d) {
                var firstPoint = d.dataset.data()[0];
                var lastPoint = _.last(d.dataset.data());
                var firstX = _this.xScale.scale(_this.xAccessor(firstPoint, 0, d.dataset));
                var lastX = _this.xScale.scale(_this.xAccessor(lastPoint, 0, d.dataset));
                var s = _this.smoothingEnabled ?
                    d.datum.smoothed : _this.yValueAccessor(d.datum, 0, d.dataset);
                return target.x < firstX || target.x > lastX || isNaN(s);
            });
            rows.classed('closest', function (p) { return dist(p) === closestDist; });
            // It is a bit hacky that we are manually applying the width to the swatch
            // and the nowrap property to the text here. The reason is as follows:
            // the style gets updated asynchronously by Polymer scopeSubtree observer.
            // Which means we would get incorrect sizing information since the text
            // would wrap by default. However, we need correct measurements so that
            // we can stop the text from falling off the edge of the screen.
            // therefore, we apply the size-critical styles directly.
            rows.style('white-space', 'nowrap');
            rows.append('td')
                .append('span')
                .classed('swatch', true)
                .style('background-color', function (d) { return _this.colorScale.scale(d.dataset.metadata().name); });
            _.each(tooltipColumns, function (column) {
                rows.append('td').text(function (d) { return column.evaluate(d, {
                    smoothingEnabled: _this.smoothingEnabled,
                }); });
            });
            // compute left position
            var documentWidth = document.body.clientWidth;
            var node = this.tooltip.node();
            var parentRect = node.parentElement.getBoundingClientRect();
            var nodeRect = node.getBoundingClientRect();
            // prevent it from falling off the right side of the screen
            var left = documentWidth - parentRect.left - nodeRect.width - 60, top = 0;
            if (this.tooltipPosition === 'right') {
                left = Math.min(parentRect.width, left);
            }
            else { // 'bottom'
                left = Math.min(0, left);
                top = parentRect.height + vz_chart_helpers.TOOLTIP_Y_PIXEL_OFFSET;
            }
            this.tooltip.style('transform', 'translate(' + left + 'px,' + top + 'px)');
            this.tooltip.style('opacity', 1);
        };
        LineChart.prototype.findClosestPoint = function (target, dataset) {
            var _this = this;
            var points = dataset.data().map(function (d, i) {
                var x = _this.xAccessor(d, i, dataset);
                var y = _this.smoothingEnabled ? _this.smoothedAccessor(d, i, dataset) :
                    _this.yValueAccessor(d, i, dataset);
                return {
                    x: _this.xScale.scale(x),
                    y: _this.yScale.scale(y),
                    datum: d,
                    dataset: dataset,
                };
            });
            var idx = sortedIndexBy(points, target, function (p) { return p.x; });
            if (idx === points.length) {
                return points[points.length - 1];
            }
            else if (idx === 0) {
                return points[0];
            }
            else {
                var prev = points[idx - 1];
                var next = points[idx];
                var prevDist = Math.abs(prev.x - target.x);
                var nextDist = Math.abs(next.x - target.x);
                return prevDist < nextDist ? prev : next;
            }
        };
        LineChart.prototype.resmoothDataset = function (dataset) {
            var _this = this;
            var data = dataset.data();
            var smoothingWeight = this.smoothingWeight;
            // 1st-order IIR low-pass filter to attenuate the higher-
            // frequency components of the time-series.
            var last = data.length > 0 ? 0 : NaN;
            var numAccum = 0;
            data.forEach(function (d, i) {
                var nextVal = _this.yValueAccessor(d, i, dataset);
                if (!_.isFinite(nextVal)) {
                    d.smoothed = nextVal;
                }
                else {
                    last = last * smoothingWeight + (1 - smoothingWeight) * nextVal;
                    numAccum++;
                    // The uncorrected moving average is biased towards the initial value.
                    // For example, if initialized with `0`, with smoothingWeight `s`, where
                    // every data point is `c`, after `t` steps the moving average is
                    // ```
                    //   EMA = 0*s^(t) + c*(1 - s)*s^(t-1) + c*(1 - s)*s^(t-2) + ...
                    //       = c*(1 - s^t)
                    // ```
                    // If initialized with `0`, dividing by (1 - s^t) is enough to debias
                    // the moving average. We count the number of finite data points and
                    // divide appropriately before storing the data.
                    var debiasWeight = 1;
                    if (smoothingWeight !== 1.0) {
                        debiasWeight = 1.0 - Math.pow(smoothingWeight, numAccum);
                    }
                    d.smoothed = last / debiasWeight;
                }
            });
        };
        LineChart.prototype.getDataset = function (name) {
            if (this.name2datasets[name] === undefined) {
                this.name2datasets[name] = new Plottable.Dataset([], { name: name });
            }
            return this.name2datasets[name];
        };
        LineChart.getYScaleFromType = function (yScaleType) {
            if (yScaleType === 'log') {
                return new Plottable.Scales.ModifiedLog();
            }
            else if (yScaleType === 'linear') {
                return new Plottable.Scales.Linear();
            }
            else {
                throw new Error('Unrecognized yScale type ' + yScaleType);
            }
        };
        /**
         * Update the selected series on the chart.
         */
        LineChart.prototype.setVisibleSeries = function (names) {
            var _this = this;
            names = names.sort();
            this.seriesNames = names;
            names.reverse(); // draw first series on top
            this.datasets.forEach(function (d) { return d.offUpdate(_this.onDatasetChanged); });
            this.datasets = names.map(function (r) { return _this.getDataset(r); });
            this.datasets.forEach(function (d) { return d.onUpdate(_this.onDatasetChanged); });
            this.linePlot.datasets(this.datasets);
            if (this.smoothingEnabled) {
                this.smoothLinePlot.datasets(this.datasets);
            }
            if (this.marginAreaPlot) {
                this.marginAreaPlot.datasets(this.datasets);
            }
            this.updateSpecialDatasets();
        };
        /**
         * Samples a dataset so that it contains no more than _MAX_MARKERS number of
         * data points. This function returns the original dataset if it does not
         * exceed that many points.
         */
        LineChart.prototype.createSampledDatasetForMarkers = function (original) {
            var originalData = original.data();
            if (originalData.length <= _MAX_MARKERS) {
                // This dataset is small enough. Do not sample.
                return original;
            }
            // Downsample the data. Otherwise, too many markers clutter the chart.
            var skipLength = Math.ceil(originalData.length / _MAX_MARKERS);
            var data = new Array(Math.floor(originalData.length / skipLength));
            for (var i = 0, j = 0; i < data.length; i++, j += skipLength) {
                data[i] = originalData[j];
            }
            return new Plottable.Dataset(data, original.metadata());
        };
        /**
         * Set the data of a series on the chart.
         */
        LineChart.prototype.setSeriesData = function (name, data) {
            this.getDataset(name).data(data);
        };
        LineChart.prototype.smoothingUpdate = function (weight) {
            var _this = this;
            this.smoothingWeight = weight;
            this.datasets.forEach(function (d) { return _this.resmoothDataset(d); });
            if (!this.smoothingEnabled) {
                this.linePlot.addClass('ghost');
                this.scatterPlot.y(this.smoothedAccessor, this.yScale);
                this.smoothingEnabled = true;
                this.smoothLinePlot.datasets(this.datasets);
            }
            if (this.markersScatterPlot) {
                // Use the correct accessor for marker positioning.
                this.markersScatterPlot.y(this.getYAxisAccessor(), this.yScale);
            }
            this.updateSpecialDatasets();
        };
        LineChart.prototype.smoothingDisable = function () {
            if (this.smoothingEnabled) {
                this.linePlot.removeClass('ghost');
                this.scatterPlot.y(this.yValueAccessor, this.yScale);
                this.smoothLinePlot.datasets([]);
                this.smoothingEnabled = false;
                this.updateSpecialDatasets();
            }
            if (this.markersScatterPlot) {
                // Use the correct accessor (which depends on whether smoothing is
                // enabled) for marker positioning.
                this.markersScatterPlot.y(this.getYAxisAccessor(), this.yScale);
            }
        };
        LineChart.prototype.setTooltipSortingMethod = function (method) {
            this.tooltipSortingMethod = method;
        };
        LineChart.prototype.setTooltipPosition = function (position) {
            this.tooltipPosition = position;
        };
        LineChart.prototype.renderTo = function (targetSVG) {
            this.targetSVG = targetSVG;
            this.outer.renderTo(targetSVG);
            if (this._defaultXRange != null) {
                // A higher-level component provided a default range for the X axis.
                // Start with that range.
                this.resetXDomain();
            }
            if (this._defaultYRange != null) {
                // A higher-level component provided a default range for the Y axis.
                // Start with that range.
                this.resetYDomain();
            }
        };
        LineChart.prototype.redraw = function () {
            this.outer.redraw();
        };
        LineChart.prototype.destroy = function () {
            // Destroying outer destroys all subcomponents recursively.
            if (this.outer)
                this.outer.destroy();
        };
        return LineChart;
    }());
    /**
     * Binary searches and finds "closest" index of a value in an array. As the name
     * indicates, `array` must be sorted. When there is no exact match, it returns
     * index of a first item that is larger than the value.
     * API Signature and method inspired by lodash#sortedIndexBy.
     * TODO(stephanwlee): Use _.sortedIndexBy when types are migrated to v4.
     */
    function sortedIndexBy(array, value, iteratee) {
        var query = iteratee(value);
        var low = 0;
        var high = array.length;
        while (low < high) {
            var mid = Math.floor((low + high) / 2);
            var midVal = iteratee(array[mid]);
            if (midVal < query) {
                low = mid + 1;
            }
            else {
                high = mid;
            }
        }
        return high;
    }
})(vz_line_chart || (vz_line_chart = {})); // namespace vz_line_chart
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidnotbGluZS1jaGFydC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbInZ6LWxpbmUtY2hhcnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7Ozs7Ozs7Z0ZBYWdGO0FBQ2hGLElBQVUsYUFBYSxDQXlyQ3RCO0FBenJDRCxXQUFVLGFBQWE7SUFjdkI7OztPQUdHO0lBQ0gsSUFBTSxZQUFZLEdBQUcsRUFBRSxDQUFDO0lBRXhCLE9BQU8sQ0FBQztRQUNOLEVBQUUsRUFBRSxlQUFlO1FBQ25CLFVBQVUsRUFBRTtZQUNWOzs7Ozs7ZUFNRztZQUNILFVBQVUsRUFBRTtnQkFDVixJQUFJLEVBQUUsTUFBTTtnQkFDWixLQUFLLEVBQUU7b0JBQ0wsT0FBTyxJQUFJLFNBQVMsQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO2dCQUNqRSxDQUFDO2FBQ0Y7WUFFRDs7OztlQUlHO1lBQ0gsY0FBYyxFQUFFLE1BQU07WUFFdEI7Ozs7Ozs7Ozs7Ozs7O2VBY0c7WUFDSCxnQkFBZ0IsRUFBRTtnQkFDaEIsSUFBSSxFQUFFLE9BQU87Z0JBQ2IsTUFBTSxFQUFFLElBQUk7Z0JBQ1osS0FBSyxFQUFFLEtBQUs7YUFDYjtZQUVEOzs7Ozs7Ozs7Ozs7O2VBYUc7WUFDSCxlQUFlLEVBQUUsRUFBQyxJQUFJLEVBQUUsTUFBTSxFQUFFLEtBQUssRUFBRSxHQUFHLEVBQUM7WUFFM0M7Ozs7O2VBS0c7WUFDSCxLQUFLLEVBQUUsRUFBQyxJQUFJLEVBQUUsTUFBTSxFQUFFLEtBQUssRUFBRSxFQUFFLEVBQUM7WUFFaEM7Ozs7Ozs7Ozs7O2VBV0c7WUFDSCx5QkFBeUIsRUFBRTtnQkFDekIsSUFBSSxFQUFFLE1BQU07Z0JBQ1o7OzJEQUUyQztnQkFDM0MsS0FBSyxFQUFFLEVBQUU7YUFDVjtZQUVEOzs7OztlQUtHO1lBQ0gsY0FBYyxFQUFFLE1BQU07WUFFdEI7Ozs7O2VBS0c7WUFDSCxjQUFjLEVBQUUsTUFBTTtZQUV0Qjs7Ozs7OztlQU9HO1lBQ0gsY0FBYyxFQUFFLEVBQUMsSUFBSSxFQUFFLE1BQU0sRUFBRSxLQUFLLEVBQUUsY0FBTSxPQUFBLENBQUMsVUFBQSxDQUFDLElBQUksT0FBQSxDQUFDLENBQUMsTUFBTSxFQUFSLENBQVEsQ0FBQyxFQUFmLENBQWUsRUFBQztZQUU1RDs7Ozs7Ozs7ZUFRRztZQUNILGNBQWMsRUFBRTtnQkFDZCxJQUFJLEVBQUUsS0FBSztnQkFDWCxLQUFLLEVBQUU7b0JBQ0wsSUFBTSxjQUFjLEdBQUcsZ0JBQWdCLENBQUMsbUJBQW1CLENBQ3ZELGdCQUFnQixDQUFDLDZCQUE2QixDQUFDLENBQUM7b0JBQ3BELElBQU0sZ0JBQWdCLEdBQUcsVUFBQyxDQUFDLElBQUssT0FBQSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxFQUFwQyxDQUFvQyxDQUFDO29CQUVyRSxPQUFPO3dCQUNMOzRCQUNFLEtBQUssRUFBRSxNQUFNOzRCQUNiLFFBQVEsRUFBRSxVQUFDLENBQUMsSUFBSyxPQUFBLENBQUMsQ0FBQyxPQUFPLENBQUMsUUFBUSxFQUFFLENBQUMsSUFBSSxFQUF6QixDQUF5Qjt5QkFDM0M7d0JBQ0Q7NEJBQ0UsS0FBSyxFQUFFLFVBQVU7NEJBQ2pCLFFBQVEsRUFBRSxVQUFDLENBQUMsRUFBRSxZQUFZO2dDQUN4QixJQUFNLGdCQUFnQixHQUNsQixZQUFZLElBQUksWUFBWSxDQUFDLGdCQUFnQixDQUFDO2dDQUNsRCxPQUFPLGdCQUFnQixDQUNuQixnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUM7NEJBQzVELENBQUM7eUJBQ0Y7d0JBQ0Q7NEJBQ0UsS0FBSyxFQUFFLE9BQU87NEJBQ2QsUUFBUSxFQUFFLFVBQUMsQ0FBQyxJQUFLLE9BQUEsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsRUFBaEMsQ0FBZ0M7eUJBQ2xEO3dCQUNEOzRCQUNFLEtBQUssRUFBRSxNQUFNOzRCQUNiLFFBQVEsRUFBRSxVQUFDLENBQUMsSUFBSyxPQUFBLGdCQUFnQixDQUFDLGFBQWEsQ0FDM0MsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsRUFEQSxDQUNBO3lCQUNsQjt3QkFDRDs0QkFDRSxLQUFLLEVBQUUsTUFBTTs0QkFDYixRQUFRLEVBQUUsVUFBQyxDQUFDLElBQUssT0FBQSxnQkFBZ0IsQ0FBQyxhQUFhLENBQzNDLENBQUMsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLEVBREwsQ0FDSzt5QkFDdkI7d0JBQ0Q7NEJBQ0UsS0FBSyxFQUFFLFVBQVU7NEJBQ2pCLFFBQVEsRUFBRSxVQUFDLENBQUMsSUFBSyxPQUFBLGdCQUFnQixDQUFDLGlCQUFpQixDQUMvQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxFQUQ3QyxDQUM2Qzt5QkFDL0Q7cUJBQ0YsQ0FBQztnQkFDSixDQUFDO2FBQ0Y7WUFFRDs7Ozs7O2VBTUc7WUFDSCxRQUFRLEVBQUUsTUFBTTtZQUVoQjs7Ozs7ZUFLRztZQUNILGFBQWEsRUFBRSxLQUFLO1lBRXBCOzs7OztlQUtHO1lBQ0gsYUFBYSxFQUFFLEtBQUs7WUFFcEI7Ozs7O2VBS0c7WUFDSCx1QkFBdUIsRUFBRTtnQkFDdkIsSUFBSSxFQUFFLE1BQU07Z0JBQ1osUUFBUSxFQUFFLGdEQUFnRDthQUMzRDtZQUVEOzs7O2VBSUc7WUFDSCxVQUFVLEVBQUUsRUFBQyxJQUFJLEVBQUUsTUFBTSxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUM7WUFFM0M7O2VBRUc7WUFDSCxlQUFlLEVBQUU7Z0JBQ2YsSUFBSSxFQUFFLE9BQU87Z0JBQ2IsS0FBSyxFQUFFLEtBQUs7YUFDYjtZQUVEOzs7Ozs7ZUFNRztZQUNILG9CQUFvQixFQUFFLEVBQUMsSUFBSSxFQUFFLE1BQU0sRUFBRSxLQUFLLEVBQUUsU0FBUyxFQUFDO1lBRXREOzs7O2VBSUc7WUFDSCxlQUFlLEVBQUUsRUFBQyxJQUFJLEVBQUUsTUFBTSxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUM7WUFFaEQsU0FBUyxFQUFFLE9BQU87WUFDbEIsTUFBTSxFQUFFLE1BQU07WUFDZCxtQkFBbUIsRUFBRTtnQkFDbkIsSUFBSSxFQUFFLEtBQUs7Z0JBQ1gsS0FBSyxFQUFFO29CQUNMLE9BQU8sRUFBRSxDQUFBO2dCQUNYLENBQUM7YUFDRjtZQUNELGdCQUFnQixFQUFFO2dCQUNoQixJQUFJLEVBQUUsTUFBTTtnQkFDWixLQUFLLEVBQUU7b0JBQ0wsT0FBTyxFQUFFLENBQUE7Z0JBQ1gsQ0FBQzthQUNGO1lBQ0QseUJBQXlCLEVBQUUsRUFBQyxJQUFJLEVBQUUsTUFBTSxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUM7U0FDdkQ7UUFDRCxTQUFTLEVBQUU7WUFDVCxpSEFBaUg7WUFDakgsMEJBQTBCO1lBQzFCLDhEQUE4RDtZQUM5RCw0REFBNEQ7WUFDNUQsa0RBQWtEO1lBQ2xELDJDQUEyQztTQUM1QztRQUVEOzs7Ozs7V0FNRztRQUNILGdCQUFnQixFQUFFLFVBQVMsS0FBSztZQUM5QixJQUFJLENBQUMsbUJBQW1CLEdBQUcsS0FBSyxDQUFDO1lBQ2pDLElBQUksSUFBSSxDQUFDLE1BQU0sRUFBRTtnQkFDZixJQUFJLENBQUMsTUFBTSxDQUFDLGdCQUFnQixDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUNwQyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7YUFDZjtRQUNILENBQUM7UUFFRDs7Ozs7Ozs7OztXQVVHO1FBQ0gsYUFBYSxFQUFFLFVBQVMsSUFBSSxFQUFFLElBQUk7WUFDaEMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxHQUFHLElBQUksQ0FBQztZQUNuQyxJQUFJLElBQUksQ0FBQyxNQUFNLEVBQUU7Z0JBQ2YsSUFBSSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDO2FBQ3ZDO1FBQ0gsQ0FBQztRQUVEOzs7V0FHRztRQUNILFdBQVcsRUFBRTtZQUNYLElBQUksSUFBSSxDQUFDLE1BQU0sRUFBRTtnQkFDZixJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsRUFBRSxDQUFDO2FBQzNCO1FBQ0gsQ0FBQztRQUVEOztXQUVHO1FBQ0gsTUFBTSxFQUFFO1lBQ04sSUFBSSxJQUFJLENBQUMsTUFBTSxFQUFFO2dCQUNmLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFLENBQUM7YUFDdEI7UUFDSCxDQUFDO1FBRUQsUUFBUSxFQUFFO1lBQ1IsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUM7UUFDeEIsQ0FBQztRQUVELFFBQVEsRUFBRTtZQUNSLElBQUksSUFBSSxDQUFDLE1BQU07Z0JBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUUsQ0FBQztZQUN2QyxJQUFJLENBQUMsU0FBUyxHQUFHLEtBQUssQ0FBQztRQUN6QixDQUFDO1FBRUQsS0FBSyxFQUFFO1lBQ0wsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsQ0FBQztZQUN4QyxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQzNDLENBQUM7UUFFRDs7O1dBR0c7UUFDSCxVQUFVLEVBQUUsVUFDUix5QkFBeUIsRUFDekIsS0FBSyxFQUNMLGNBQWMsRUFDZCxVQUFVLEVBQ1YsY0FBYyxFQUNkLFVBQVUsRUFDVixTQUFTO1lBQ1gsNkNBQTZDO1lBQzdDLElBQUksQ0FBQyxLQUFLLElBQUksQ0FBQyx5QkFBeUIsRUFBRTtnQkFDeEMseUJBQXlCLEdBQUcsZ0JBQWdCLENBQUMsS0FBSyxDQUFDO2FBQ3BEO2lCQUFNLElBQUksS0FBSyxFQUFFO2dCQUNoQix5QkFBeUIsR0FBRztvQkFDeEIsT0FBQSxnQkFBZ0IsQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDO2dCQUF0QyxDQUFzQyxDQUFDO2FBQzVDO1lBRUQsSUFBSSxJQUFJLENBQUMseUJBQXlCLEtBQUssSUFBSSxFQUFFO2dCQUMzQyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDO2dCQUNqRCxJQUFJLENBQUMseUJBQXlCLEdBQUcsSUFBSSxDQUFDO2FBQ3ZDO1lBRUQsSUFBSSxDQUFDLHlCQUF5QixHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7Z0JBQzFDLElBQUksQ0FBQyx5QkFBeUIsR0FBRyxJQUFJLENBQUM7Z0JBQ3RDLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUztvQkFDZixDQUFDLHlCQUF5QjtvQkFDMUIsQ0FBQyxJQUFJLENBQUMsY0FBYztvQkFDcEIsQ0FBQyxJQUFJLENBQUMsY0FBYyxFQUFFO29CQUN4QixPQUFPO2lCQUNSO2dCQUNELElBQUksT0FBTyxHQUFHLEVBQUUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztnQkFDeEMsa0VBQWtFO2dCQUNsRSxzRUFBc0U7Z0JBQ3RFLG9DQUFvQztnQkFDcEMsSUFBSSxLQUFLLEdBQUcsSUFBSSxTQUFTLENBQ3JCLHlCQUF5QixFQUN6QixJQUFJLENBQUMsY0FBYyxFQUNuQixVQUFVLEVBQ1YsVUFBVSxFQUNWLE9BQU8sRUFDUCxJQUFJLENBQUMsY0FBYyxFQUNuQixJQUFJLENBQUMsUUFBUSxFQUNiLElBQUksQ0FBQyxhQUFhLEVBQ2xCLElBQUksQ0FBQyxhQUFhLEVBQ2xCLElBQUksQ0FBQyxjQUFjLEVBQ25CLElBQUksQ0FBQyxjQUFjLEVBQ25CLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQztnQkFDekIsSUFBSSxHQUFHLEdBQUcsRUFBRSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDO2dCQUNyQyxLQUFLLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUNwQixJQUFJLElBQUksQ0FBQyxNQUFNO29CQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFLENBQUM7Z0JBQ3ZDLElBQUksQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDO1lBQ3RCLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQztRQUNWLENBQUM7UUFFRCxnQkFBZ0IsRUFBRTtZQUNoQixJQUFJLElBQUksQ0FBQyxNQUFNLEVBQUU7Z0JBQ2YsSUFBSSxDQUFDLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsQ0FBQztnQkFDdkQsSUFBSSxDQUFDLG1CQUFtQixDQUFDLE9BQU8sQ0FBQyxVQUFTLElBQUk7b0JBQzVDLElBQUksQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDLENBQUM7Z0JBQ3JFLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQzthQUNmO1FBQ0gsQ0FBQztRQUNELGlCQUFpQixFQUFFO1lBQ2pCLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFO2dCQUNoQixPQUFPO2FBQ1I7WUFDRCxJQUFJLElBQUksQ0FBQyxnQkFBZ0IsRUFBRTtnQkFDekIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDO2FBQ25EO2lCQUFNO2dCQUNMLElBQUksQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQzthQUNoQztRQUNILENBQUM7UUFDRCxnQkFBZ0IsRUFBRTtZQUNoQixJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRTtnQkFDaEIsT0FBTzthQUNSO1lBQ0QsSUFBSSxDQUFDLE1BQU0sQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDO1FBQ3BELENBQUM7UUFDRCw0QkFBNEIsRUFBRTtZQUM1QixJQUFJLElBQUksQ0FBQyxNQUFNLEVBQUU7Z0JBQ2YsSUFBSSxDQUFDLE1BQU0sQ0FBQyx1QkFBdUIsQ0FBQyxJQUFJLENBQUMsb0JBQW9CLENBQUMsQ0FBQzthQUNoRTtRQUNILENBQUM7UUFDRCx1QkFBdUIsRUFBRTtZQUN2QixJQUFJLElBQUksQ0FBQyxNQUFNLEVBQUU7Z0JBQ2YsSUFBSSxDQUFDLE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUM7YUFDdEQ7UUFDSCxDQUFDO1FBQ0QsOEJBQThCLFlBQUMsY0FBYztZQUE3QyxpQkFJQztZQUhDLGtFQUFrRTtZQUNsRSxJQUFNLE1BQU0sSUFBSSxFQUFFLFNBQUssQ0FBQyxDQUFDLEdBQUcsQ0FBQyxjQUFjLEVBQUUsT0FBTyxDQUFDLENBQUMsQ0FBQztZQUN2RCxPQUFPLE1BQU0sQ0FBQyxHQUFHLENBQUMsVUFBQSxLQUFLLElBQUksT0FBQSxTQUFPLEtBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLFVBQU8sRUFBbkMsQ0FBbUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUMzRSxDQUFDO1FBQ0QsU0FBUyxZQUFDLEtBQUs7WUFDYixPQUFPLEtBQUssQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFLE1BQU0sQ0FBQztpQkFDckIsT0FBTyxDQUFDLElBQUksRUFBRSxNQUFNLENBQUMsQ0FBRSxtQkFBbUI7aUJBQzFDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFDdEMsQ0FBQztLQUNGLENBQUMsQ0FBQztJQUVIO1FBaURFLG1CQUNJLHlCQUE2RCxFQUM3RCxjQUEyQyxFQUMzQyxVQUFrQixFQUNsQixVQUFrQyxFQUNsQyxPQUF5QyxFQUN6QyxjQUFnRCxFQUNoRCxRQUFrQixFQUNsQixhQUF3QixFQUN4QixhQUF3QixFQUN4QixjQUEwQyxFQUMxQyxjQUFtQyxFQUNuQyxjQUFtQztZQUNyQyxJQUFJLENBQUMsV0FBVyxHQUFHLEVBQUUsQ0FBQztZQUN0QixJQUFJLENBQUMsYUFBYSxHQUFHLEVBQUUsQ0FBQztZQUN4QixJQUFJLENBQUMsVUFBVSxHQUFHLFVBQVUsQ0FBQztZQUM3QixJQUFJLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQztZQUN2QixJQUFJLENBQUMsUUFBUSxHQUFHLEVBQUUsQ0FBQztZQUNuQixJQUFJLENBQUMsZ0JBQWdCLEdBQUcsS0FBSyxDQUFDO1lBQzlCLHFFQUFxRTtZQUNyRSx5Q0FBeUM7WUFDekMsSUFBSSxDQUFDLGlCQUFpQixHQUFHLElBQUksU0FBUyxDQUFDLE9BQU8sRUFBRSxDQUFDO1lBQ2pELElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxTQUFTLENBQUMsT0FBTyxFQUFFLENBQUM7WUFDMUMsSUFBSSxDQUFDLGNBQWMsR0FBRyxjQUFjLENBQUM7WUFFckMsNEVBQTRFO1lBQzVFLGdEQUFnRDtZQUNoRCxJQUFJLENBQUMsY0FBYyxHQUFHLGNBQWMsQ0FBQztZQUVyQyxtRUFBbUU7WUFDbkUsdUVBQXVFO1lBQ3ZFLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1lBRTFELElBQUksQ0FBQyxjQUFjLEdBQUcsYUFBYSxDQUFDO1lBQ3BDLElBQUksQ0FBQyxjQUFjLEdBQUcsYUFBYSxDQUFDO1lBQ3BDLElBQUksQ0FBQyxjQUFjLEdBQUcsY0FBYyxDQUFDO1lBRXJDLElBQUksQ0FBQyxVQUFVLENBQ1gseUJBQXlCLEVBQ3pCLGNBQWMsRUFDZCxVQUFVLEVBQ1YsUUFBUSxFQUNSLGNBQWMsRUFDZCxjQUFjLENBQUMsQ0FBQztRQUN0QixDQUFDO1FBRU8sOEJBQVUsR0FBbEIsVUFDSSx5QkFBNkQsRUFDN0QsY0FBMkMsRUFDM0MsVUFBa0IsRUFDbEIsUUFBa0IsRUFDbEIsY0FBa0MsRUFDbEMsY0FBa0M7WUFDcEMsSUFBSSxJQUFJLENBQUMsS0FBSyxFQUFFO2dCQUNkLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxFQUFFLENBQUM7YUFDdEI7WUFDRCxJQUFNLFdBQVcsR0FBRyx5QkFBeUIsRUFBRSxDQUFDO1lBQ2hELElBQUksQ0FBQyxTQUFTLEdBQUcsV0FBVyxDQUFDLFFBQVEsQ0FBQztZQUN0QyxJQUFJLENBQUMsTUFBTSxHQUFHLFdBQVcsQ0FBQyxLQUFLLENBQUM7WUFDaEMsSUFBSSxDQUFDLEtBQUssR0FBRyxXQUFXLENBQUMsSUFBSSxDQUFDO1lBQzlCLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3pDLElBQUksY0FBYyxFQUFFO2dCQUNsQixJQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsQ0FBQzthQUN0QztZQUNELElBQUksQ0FBQyxNQUFNLEdBQUcsU0FBUyxDQUFDLGlCQUFpQixDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBQ3RELElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxTQUFTLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLE1BQU0sQ0FBQyxDQUFDO1lBQzdELElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3pDLElBQUksQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsY0FBYztnQkFDbEQsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLG1CQUFtQixDQUNsQyxnQkFBZ0IsQ0FBQywwQkFBMEIsQ0FBQyxDQUFDLENBQUM7WUFDcEQsSUFBSSxDQUFDLEtBQUssQ0FBQywwQkFBMEIsQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUM1QyxJQUFJLENBQUMsUUFBUSxHQUFHLFFBQVEsQ0FBQztZQUV6QixJQUFJLENBQUMsR0FBRyxHQUFHLElBQUksY0FBQSxhQUFhLENBQ3hCLElBQUksQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1lBRTVELElBQUksQ0FBQyxrQkFBa0IsR0FBRyxJQUFJLENBQUMsd0JBQXdCLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ2xFLElBQUksQ0FBQyxzQkFBc0IsR0FBRyxJQUFJLFNBQVMsQ0FBQyxTQUFTLEVBQUUsQ0FBQztZQUV4RCxJQUFNLElBQUksR0FBRyxJQUFJLENBQUMsU0FBUyxDQUN2QixJQUFJLENBQUMsTUFBTSxFQUNYLElBQUksQ0FBQyxNQUFNLEVBQ1gsUUFBUSxDQUFDLENBQUM7WUFFZCxJQUFJLENBQUMsU0FBUztnQkFDVixJQUFJLFNBQVMsQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBRWpFLElBQUksU0FBUyxHQUFHLElBQUksU0FBUyxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsWUFBWSxDQUFDLENBQUM7WUFDdEUsU0FBUyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3RDLElBQUksU0FBUyxHQUFHLElBQUksU0FBUyxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsVUFBVSxDQUFDLENBQUM7WUFDcEUsU0FBUyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBRXRDLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxTQUFTLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQztnQkFDekMsSUFBSSxDQUFDLFNBQVMsRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFFLElBQUk7Z0JBQzFDLElBQUksQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLHNCQUFzQjthQUFDLENBQUMsQ0FBQztZQUM1QyxJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksU0FBUyxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQ3ZDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3ZELENBQUM7UUFFTyw2QkFBUyxHQUFqQixVQUFrQixNQUFNLEVBQUUsTUFBTSxFQUFFLFFBQVE7WUFBMUMsaUJBb0ZDO1lBbEZDLElBQUksUUFBUSxFQUFFO2dCQUNaLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxTQUFTLENBQUMsS0FBSyxDQUFDLElBQUksRUFBZSxDQUFDO2dCQUM5RCxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLE1BQU0sQ0FBQyxDQUFDO2dCQUM5QyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsY0FBYyxFQUFFLE1BQU0sQ0FBQyxDQUFDO2dCQUN2RCxJQUFJLENBQUMsY0FBYyxDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUMsYUFBYSxDQUFDLENBQUM7Z0JBQy9DLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUNwQixNQUFNLEVBQ04sVUFBQyxDQUF5QixFQUFFLENBQVMsRUFBRSxPQUEwQjtvQkFDN0QsT0FBQSxLQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsUUFBUSxFQUFFLENBQUMsSUFBSSxDQUFDO2dCQUE5QyxDQUE4QyxDQUFDLENBQUM7Z0JBQ3hELElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLGNBQWMsRUFBRSxHQUFHLENBQUMsQ0FBQztnQkFDOUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUMsQ0FBQyxDQUFDO2FBQzdDO1lBRUQsSUFBSSxDQUFDLGdCQUFnQixHQUFHLFVBQUMsQ0FBZ0MsSUFBSyxPQUFBLENBQUMsQ0FBQyxRQUFRLEVBQVYsQ0FBVSxDQUFDO1lBQ3pFLElBQUksUUFBUSxHQUFHLElBQUksU0FBUyxDQUFDLEtBQUssQ0FBQyxJQUFJLEVBQWUsQ0FBQztZQUN2RCxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsTUFBTSxDQUFDLENBQUM7WUFDbkMsUUFBUSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsY0FBYyxFQUFFLE1BQU0sQ0FBQyxDQUFDO1lBQ3hDLFFBQVEsQ0FBQyxJQUFJLENBQ1QsUUFBUSxFQUNSLFVBQUMsQ0FBeUIsRUFBRSxDQUFTLEVBQUUsT0FBMEI7Z0JBQzdELE9BQUEsS0FBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxDQUFDLElBQUksQ0FBQztZQUE5QyxDQUE4QyxDQUFDLENBQUM7WUFDeEQsSUFBSSxDQUFDLFFBQVEsR0FBRyxRQUFRLENBQUM7WUFDekIsSUFBSSxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUU3QixJQUFJLGNBQWMsR0FBRyxJQUFJLFNBQVMsQ0FBQyxLQUFLLENBQUMsSUFBSSxFQUFlLENBQUM7WUFDN0QsY0FBYyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLE1BQU0sQ0FBQyxDQUFDO1lBQ3pDLGNBQWMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGdCQUFnQixFQUFFLE1BQU0sQ0FBQyxDQUFDO1lBQ2hELGNBQWMsQ0FBQyxJQUFJLENBQ2YsUUFBUSxFQUNSLFVBQUMsQ0FBeUIsRUFBRSxDQUFTLEVBQUUsT0FBMEI7Z0JBQzdELE9BQUEsS0FBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxDQUFDLElBQUksQ0FBQztZQUE5QyxDQUE4QyxDQUFDLENBQUM7WUFDeEQsSUFBSSxDQUFDLGNBQWMsR0FBRyxjQUFjLENBQUM7WUFFckMsSUFBSSxJQUFJLENBQUMsY0FBYyxFQUFFO2dCQUN2QixJQUFNLGtCQUFrQixHQUFHLElBQUksU0FBUyxDQUFDLEtBQUssQ0FBQyxPQUFPLEVBQXVCLENBQUM7Z0JBQzlFLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLE1BQU0sQ0FBQyxDQUFDO2dCQUM3QyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGNBQWMsRUFBRSxNQUFNLENBQUMsQ0FBQztnQkFDbEQsa0JBQWtCLENBQUMsSUFBSSxDQUNuQixNQUFNLEVBQ04sVUFBQyxDQUF5QixFQUFFLENBQVMsRUFBRSxPQUEwQjtvQkFDN0QsT0FBQSxLQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsUUFBUSxFQUFFLENBQUMsSUFBSSxDQUFDO2dCQUE5QyxDQUE4QyxDQUFDLENBQUM7Z0JBQ3hELGtCQUFrQixDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFDLENBQUM7Z0JBQ3RDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxtQkFBbUIsR0FBRyxDQUFDLENBQUMsQ0FBQztnQkFDbEUsa0JBQWtCLENBQUMsTUFBTSxDQUNyQixVQUFDLENBQXlCLEVBQUUsQ0FBUyxFQUFFLE9BQTBCO29CQUMvRCxPQUFPLEtBQUksQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUN0RCxDQUFDLENBQUMsQ0FBQztnQkFDUCx5RUFBeUU7Z0JBQ3pFLGdEQUFnRDtnQkFDaEQsSUFBSSxDQUFDLGtCQUFrQixHQUFHLGtCQUFrQixDQUFDO2FBQzlDO1lBRUQsZ0VBQWdFO1lBQ2hFLG1FQUFtRTtZQUNuRSxxRUFBcUU7WUFDckUsSUFBSSxXQUFXLEdBQUcsSUFBSSxTQUFTLENBQUMsS0FBSyxDQUFDLE9BQU8sRUFBdUIsQ0FBQztZQUNyRSxXQUFXLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsTUFBTSxDQUFDLENBQUM7WUFDdEMsV0FBVyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsY0FBYyxFQUFFLE1BQU0sQ0FBQyxDQUFDO1lBQzNDLFdBQVcsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLFVBQUMsQ0FBTSxJQUFLLE9BQUEsS0FBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUE3QixDQUE2QixDQUFDLENBQUM7WUFDcEUsV0FBVyxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFDLENBQUM7WUFDL0IsV0FBVyxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxtQkFBbUIsR0FBRyxDQUFDLENBQUMsQ0FBQztZQUMzRCxXQUFXLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQztZQUMvQyxJQUFJLENBQUMsV0FBVyxHQUFHLFdBQVcsQ0FBQztZQUUvQixJQUFJLFVBQVUsR0FBRyxJQUFJLFNBQVMsQ0FBQyxLQUFLLENBQUMsT0FBTyxFQUF1QixDQUFDO1lBQ3BFLFVBQVUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxNQUFNLENBQUMsQ0FBQztZQUNyQyxVQUFVLENBQUMsQ0FBQyxDQUFDLFVBQUMsQ0FBQyxJQUFLLE9BQUEsQ0FBQyxDQUFDLFFBQVEsRUFBVixDQUFVLEVBQUUsTUFBTSxDQUFDLENBQUM7WUFDeEMsVUFBVSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsVUFBQyxDQUFNLElBQUssT0FBQSxLQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQTdCLENBQTZCLENBQUMsQ0FBQztZQUNuRSxVQUFVLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUMsQ0FBQztZQUM5QixVQUFVLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGVBQWUsR0FBRyxDQUFDLENBQUMsQ0FBQztZQUN0RCxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUM7WUFDdkMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsZUFBZSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQ3RELElBQUksQ0FBQyxVQUFVLEdBQUcsVUFBVSxDQUFDO1lBRTdCLElBQU0sTUFBTSxHQUFHLENBQUMsVUFBVSxFQUFFLFdBQVcsRUFBRSxjQUFjLEVBQUUsUUFBUSxDQUFDLENBQUM7WUFDbkUsSUFBSSxJQUFJLENBQUMsY0FBYyxFQUFFO2dCQUN2QixNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQzthQUNsQztZQUNELElBQUksSUFBSSxDQUFDLGtCQUFrQixFQUFFO2dCQUMzQixNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO2FBQ3RDO1lBQ0QsT0FBTyxJQUFJLFNBQVMsQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ2hELENBQUM7UUFFRDs7V0FFRztRQUNLLHFDQUFpQixHQUF6QixVQUEwQixPQUEwQjtZQUNsRCxJQUFJLElBQUksQ0FBQyxnQkFBZ0IsRUFBRTtnQkFDekIsSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsQ0FBQzthQUMvQjtZQUNELElBQUksQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO1FBQy9CLENBQUM7UUFFTSxtQ0FBZSxHQUF0QixVQUF1QixlQUF3QjtZQUM3QyxJQUFJLGVBQWUsS0FBSyxJQUFJLENBQUMsZ0JBQWdCLEVBQUU7Z0JBQzdDLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxlQUFlLENBQUM7Z0JBQ3hDLElBQUksQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO2dCQUM3QixJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7YUFDckI7UUFDSCxDQUFDO1FBRUQ7Ozs7V0FJRztRQUNLLHlDQUFxQixHQUE3QjtZQUNFLElBQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO1lBRXpDLElBQUksY0FBYyxHQUNkLElBQUksQ0FBQyxRQUFRO2lCQUNSLEdBQUcsQ0FBQyxVQUFDLENBQUM7Z0JBQ0wsSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDO2dCQUNqQixzREFBc0Q7Z0JBQ3RELElBQUksVUFBVSxHQUNWLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxNQUFNLENBQUMsVUFBQyxDQUFDLElBQUssT0FBQSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQTFCLENBQTBCLENBQUMsQ0FBQztnQkFDdkQsSUFBSSxVQUFVLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtvQkFDekIsSUFBSSxHQUFHLEdBQUcsVUFBVSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7b0JBQ2hDLEtBQUssR0FBRyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUM7b0JBQ3hCLEtBQUssQ0FBQyxJQUFJLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxDQUFDLElBQUksQ0FBQztvQkFDL0IsS0FBSyxDQUFDLFFBQVEsR0FBRyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFLLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7aUJBQ2xFO2dCQUNELE9BQU8sS0FBSyxDQUFDO1lBQ2YsQ0FBQyxDQUFDO2lCQUNELE1BQU0sQ0FBQyxVQUFDLENBQUMsSUFBSyxPQUFBLENBQUMsSUFBSSxJQUFJLEVBQVQsQ0FBUyxDQUFDLENBQUM7WUFDbEMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQztZQUU1QyxJQUFJLElBQUksQ0FBQyxrQkFBa0IsRUFBRTtnQkFDM0IsSUFBSSxDQUFDLGtCQUFrQixDQUFDLFFBQVEsQ0FDNUIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLDhCQUE4QixDQUFDLENBQUMsQ0FBQzthQUM3RDtZQUVELHFEQUFxRDtZQUNyRCw4REFBOEQ7WUFDOUQsdUVBQXVFO1lBQ3ZFLElBQUksZ0JBQWdCLEdBQUcsVUFBQyxDQUFvQjtnQkFDMUMsSUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDO2dCQUNwQixJQUFJLElBQUksR0FBRyxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7Z0JBQ3BCLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDVixPQUFPLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxJQUFJLFFBQVEsSUFBSSxJQUFJLEVBQUU7b0JBQzFDLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFO3dCQUNwQyxRQUFRLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztxQkFDckM7b0JBQ0QsQ0FBQyxFQUFFLENBQUM7aUJBQ0w7Z0JBQ0QsSUFBSSxRQUFRLElBQUksSUFBSSxFQUFFO29CQUNwQixRQUFRLEdBQUcsQ0FBQyxDQUFDO2lCQUNkO2dCQUNELElBQUksT0FBTyxHQUFHLEVBQUUsQ0FBQztnQkFDakIsS0FBSyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO29CQUNoQyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRTt3QkFDcEMsUUFBUSxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7cUJBQ3JDO3lCQUFNO3dCQUNMLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLEdBQUcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxDQUFDLElBQUksQ0FBQzt3QkFDakMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsR0FBRyxRQUFRLENBQUM7d0JBQzVCLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLEdBQUcsZ0JBQWdCLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO3dCQUNyRSxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO3FCQUN2QjtpQkFDRjtnQkFDRCxPQUFPLE9BQU8sQ0FBQztZQUNqQixDQUFDLENBQUM7WUFDRixJQUFJLE9BQU8sR0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQztZQUM3RCxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUNoQyxDQUFDO1FBRU0sK0JBQVcsR0FBbEI7WUFDRSxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7WUFDcEIsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1FBQ3RCLENBQUM7UUFFTyxnQ0FBWSxHQUFwQjtZQUNFLElBQUksT0FBTyxDQUFDO1lBQ1osSUFBSSxJQUFJLENBQUMsY0FBYyxJQUFJLElBQUksRUFBRTtnQkFDL0IseUNBQXlDO2dCQUN6QyxPQUFPLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQzthQUMvQjtpQkFBTTtnQkFDTCxzQ0FBc0M7Z0JBQ3RDLElBQU0sTUFBTSxHQUFHLElBQUksQ0FBQyxNQUFhLENBQUM7Z0JBQ2xDLE1BQU0sQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDO2dCQUN6QixNQUFNLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQztnQkFDekIsT0FBTyxHQUFHLE1BQU0sQ0FBQyxVQUFVLEVBQUUsQ0FBQzthQUMvQjtZQUNELElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQzlCLENBQUM7UUFFTyxnQ0FBWSxHQUFwQjtZQUNFLElBQUksT0FBTyxDQUFDO1lBQ1osSUFBSSxJQUFJLENBQUMsY0FBYyxJQUFJLElBQUksRUFBRTtnQkFDL0IseUNBQXlDO2dCQUN6QyxPQUFPLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQzthQUMvQjtpQkFBTTtnQkFDTCwrQkFBK0I7Z0JBQy9CLElBQU0sV0FBUyxHQUFHLElBQUksQ0FBQyw4QkFBOEIsRUFBRSxDQUFDO2dCQUN4RCxJQUFJLGVBQWUsR0FBeUMsVUFBQyxDQUFDO29CQUM1RCxPQUFPLFdBQVMsQ0FBQyxHQUFHLENBQUMsVUFBQSxRQUFRLElBQUksT0FBQSxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUMsR0FBRyxDQUFDLFVBQUEsQ0FBQyxJQUFJLE9BQUEsUUFBUSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBbEIsQ0FBa0IsQ0FBQyxFQUFyQyxDQUFxQyxDQUFDLENBQUM7Z0JBQzFFLENBQUMsQ0FBQztnQkFDRixJQUFNLElBQUksR0FBRyxDQUFDLENBQUMsV0FBVyxDQUFTLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFDO3FCQUNqRSxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUM7Z0JBQ3RCLE9BQU8sR0FBRyxnQkFBZ0IsQ0FBQyxhQUFhLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO2FBQ3ZFO1lBQ0QsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDOUIsQ0FBQztRQUVPLGtEQUE4QixHQUF0QztZQUNFLElBQU0sU0FBUyxHQUFHLENBQUMsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUMsQ0FBQztZQUM1QyxJQUFJLElBQUksQ0FBQyxRQUFRLEVBQUU7Z0JBQ2pCLCtDQUErQztnQkFDL0MsU0FBUyxDQUFDLElBQUksQ0FDVixJQUFJLENBQUMsUUFBUSxDQUFDLGFBQWEsRUFDM0IsSUFBSSxDQUFDLFFBQVEsQ0FBQyxjQUFjLENBQUMsQ0FBQzthQUNuQztZQUNELE9BQU8sU0FBUyxDQUFDO1FBQ25CLENBQUM7UUFFTyxvQ0FBZ0IsR0FBeEI7WUFDRSxPQUFPLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDO1FBQzdFLENBQUM7UUFFTyw0Q0FBd0IsR0FBaEMsVUFBaUMsR0FBa0I7WUFBbkQsaUJBc0RDO1lBcERDLElBQU0sRUFBRSxHQUFHLElBQUksU0FBUyxDQUFDLFlBQVksQ0FBQyxPQUFPLEVBQUUsQ0FBQztZQUNoRCwwQ0FBMEM7WUFDMUMsR0FBRyxDQUFDLGdCQUFnQixDQUFDO2dCQUNuQixFQUFFLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUNsQixLQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7WUFDdEIsQ0FBQyxDQUFDLENBQUM7WUFDSCxHQUFHLENBQUMsY0FBYyxDQUFDLGNBQU0sT0FBQSxFQUFFLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxFQUFoQixDQUFnQixDQUFDLENBQUM7WUFFM0MsRUFBRSxDQUFDLGFBQWEsQ0FBQyxVQUFDLENBQWtCO2dCQUNsQyx5Q0FBeUM7Z0JBQ3pDLElBQUksQ0FBQyxLQUFJLENBQUMsUUFBUTtvQkFBRSxPQUFPO2dCQUMzQixJQUFJLE1BQU0sR0FBMkI7b0JBQ25DLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztvQkFDTixDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7b0JBQ04sS0FBSyxFQUFFLElBQUk7b0JBQ1gsT0FBTyxFQUFFLElBQUk7aUJBQ2QsQ0FBQztnQkFDRixJQUFJLElBQUksR0FBa0IsS0FBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxJQUFJLEVBQUcsQ0FBQyxPQUFPLEVBQUUsQ0FBQztnQkFDckUsMkRBQTJEO2dCQUMzRCxJQUFJLEdBQUcsR0FBRyxLQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsRUFBRTtxQkFDbkIsR0FBRyxDQUFDLFVBQUMsT0FBTyxJQUFLLE9BQUEsS0FBSSxDQUFDLGdCQUFnQixDQUFDLE1BQU0sRUFBRSxPQUFPLENBQUMsRUFBdEMsQ0FBc0MsQ0FBQztxQkFDeEQsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDO2dCQUMvQixJQUFJLGNBQWMsR0FBRyxTQUFTLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxjQUFjLENBQUM7Z0JBQ3hELHFFQUFxRTtnQkFDckUsSUFBSSxjQUFjLEdBQUcsR0FBRyxDQUFDLE1BQU0sQ0FDM0IsVUFBQyxDQUFDLElBQUssT0FBQSxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQztvQkFDakMsS0FBSyxDQUFDLEtBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLEtBQUssRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEVBRDlDLENBQzhDLENBQUMsQ0FBQztnQkFDM0QsNERBQTREO2dCQUM1RCxJQUFJLFdBQVcsR0FBRyxjQUFjLENBQUMsTUFBTSxDQUNuQyxVQUFDLENBQUMsSUFBSyxPQUFBLENBQUMsS0FBSyxDQUFDLEtBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLEtBQUssRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEVBQWxELENBQWtELENBQUMsQ0FBQztnQkFFL0QsSUFBSSxZQUFZLEdBQ1osS0FBSSxDQUFDLHNCQUFzQixDQUFDLE9BQU8sRUFBRSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQzFELFdBQVcsRUFDWCxVQUFDLENBQXlCLElBQUssT0FBQSxDQUFDLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxDQUFDLElBQUksRUFBekIsQ0FBeUIsQ0FBQyxDQUFDO2dCQUNsRSxJQUFJLEdBQUcsQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO29CQUNwQixZQUFZLENBQUMsS0FBSyxFQUFFLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUM7b0JBQzdELFlBQVksQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLGdCQUFnQixDQUFDLG1CQUFtQixDQUFDO3lCQUN2RCxJQUFJLENBQUMsSUFBSSxFQUFFLFVBQUMsQ0FBQyxJQUFLLE9BQUEsQ0FBQyxDQUFDLENBQUMsRUFBSCxDQUFHLENBQUM7eUJBQ3RCLElBQUksQ0FBQyxJQUFJLEVBQUUsVUFBQyxDQUFDLElBQUssT0FBQSxDQUFDLENBQUMsQ0FBQyxFQUFILENBQUcsQ0FBQzt5QkFDdEIsS0FBSyxDQUFDLFFBQVEsRUFBRSxNQUFNLENBQUM7eUJBQ3ZCLElBQUksQ0FDRCxNQUFNLEVBQ04sVUFBQyxDQUFDLElBQUssT0FBQSxLQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFoRCxDQUFnRCxDQUFDLENBQUM7b0JBQ2pFLFlBQVksQ0FBQyxJQUFJLEVBQUUsQ0FBQyxNQUFNLEVBQUUsQ0FBQztvQkFDN0IsS0FBSSxDQUFDLFlBQVksQ0FBQyxjQUFjLEVBQUUsTUFBTSxFQUFFLEtBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQztpQkFDaEU7cUJBQU07b0JBQ0wsS0FBSSxDQUFDLFlBQVksRUFBRSxDQUFDO2lCQUNyQjtZQUNILENBQUMsQ0FBQyxDQUFDO1lBQ0gsRUFBRSxDQUFDLGFBQWEsQ0FBQyxjQUFNLE9BQUEsS0FBSSxDQUFDLFlBQVksRUFBRSxFQUFuQixDQUFtQixDQUFDLENBQUM7WUFDNUMsT0FBTyxFQUFFLENBQUM7UUFDWixDQUFDO1FBRU8sZ0NBQVksR0FBcEI7WUFDRSxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFDLENBQUM7WUFDakMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQyxDQUFDO1lBQ3BDLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDckUsQ0FBQztRQUVPLGlDQUFhLEdBQXJCLFVBQXNCLElBQTJDO1lBQWpFLGlCQVNDO1lBUkMsSUFBSSxDQUFDLFFBQVEsQ0FBQztnQkFDWixLQUFJLENBQUMsa0JBQWtCLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUN6QyxLQUFJLENBQUMsa0JBQWtCLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ3pDLENBQUMsQ0FBQyxDQUFDO1lBQ0gsSUFBSSxDQUFDLFFBQVEsQ0FBQztnQkFDWixLQUFJLENBQUMsa0JBQWtCLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUN2QyxLQUFJLENBQUMsa0JBQWtCLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQ3hDLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQztRQUVPLGdDQUFZLEdBQXBCLFVBQ0ksTUFBZ0MsRUFDaEMsTUFBOEIsRUFDOUIsY0FBZ0Q7WUFIcEQsaUJBMEZDO1lBdEZDLDRDQUE0QztZQUM1QyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFDLENBQUM7WUFDcEMsSUFBSSxjQUFjLEdBQUcsZ0JBQWdCLENBQUMsbUJBQW1CLENBQ3JELGdCQUFnQixDQUFDLDZCQUE2QixDQUFDLENBQUM7WUFFcEQsSUFBSSxJQUFJLEdBQUcsVUFBQyxDQUF5QjtnQkFDakMsT0FBQSxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7WUFBekQsQ0FBeUQsQ0FBQztZQUM5RCxJQUFJLFdBQVcsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztZQUUxQyxJQUFJLGVBQWUsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDO1lBQzFDLElBQUksSUFBSSxDQUFDLGdCQUFnQixFQUFFO2dCQUN6QixlQUFlLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDO2FBQ3pDO1lBRUQsSUFBSSxJQUFJLENBQUMsb0JBQW9CLEtBQUssV0FBVyxFQUFFO2dCQUM3QyxNQUFNLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsVUFBQyxDQUFDLElBQUssT0FBQSxlQUFlLENBQUMsQ0FBQyxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLEVBQXZDLENBQXVDLENBQUMsQ0FBQzthQUMzRTtpQkFBTSxJQUFJLElBQUksQ0FBQyxvQkFBb0IsS0FBSyxZQUFZLEVBQUU7Z0JBQ3JELE1BQU0sR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxVQUFDLENBQUMsSUFBSyxPQUFBLGVBQWUsQ0FBQyxDQUFDLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsRUFBdkMsQ0FBdUMsQ0FBQztxQkFDM0QsT0FBTyxFQUFFLENBQUM7YUFDekI7aUJBQU0sSUFBSSxJQUFJLENBQUMsb0JBQW9CLEtBQUssU0FBUyxFQUFFO2dCQUNsRCxNQUFNLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLENBQUM7YUFDakM7aUJBQU07Z0JBQ0wsc0VBQXNFO2dCQUN0RSxzRUFBc0U7Z0JBQ3RFLGdFQUFnRTtnQkFDaEUsTUFBTSxHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxFQUFFLENBQUM7YUFDcEM7WUFFRCxJQUFJLElBQUksR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7aUJBQ3ZCLElBQUksQ0FBQyxFQUFFLENBQUM7aUJBQ1IsU0FBUyxDQUFDLElBQUksQ0FBQztpQkFDZixJQUFJLENBQUMsTUFBTSxDQUFDO2lCQUNaLEtBQUssRUFBRTtpQkFDUCxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDN0IsdURBQXVEO1lBQ3ZELHlEQUF5RDtZQUN6RCwrQkFBK0I7WUFDL0IsSUFBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTLEVBQUUsVUFBQyxDQUFDO2dCQUN4QixJQUFJLFVBQVUsR0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNyQyxJQUFJLFNBQVMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQztnQkFDekMsSUFBSSxNQUFNLEdBQUcsS0FBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsS0FBSSxDQUFDLFNBQVMsQ0FBQyxVQUFVLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO2dCQUN6RSxJQUFJLEtBQUssR0FBRyxLQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxLQUFJLENBQUMsU0FBUyxDQUFDLFNBQVMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7Z0JBQ3ZFLElBQUksQ0FBQyxHQUFHLEtBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO29CQUMzQixDQUFDLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsS0FBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsS0FBSyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7Z0JBQ2xFLE9BQU8sTUFBTSxDQUFDLENBQUMsR0FBRyxNQUFNLElBQUksTUFBTSxDQUFDLENBQUMsR0FBRyxLQUFLLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQzNELENBQUMsQ0FBQyxDQUFDO1lBQ0gsSUFBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTLEVBQUUsVUFBQyxDQUFDLElBQUssT0FBQSxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssV0FBVyxFQUF2QixDQUF1QixDQUFDLENBQUM7WUFDeEQsMEVBQTBFO1lBQzFFLHNFQUFzRTtZQUN0RSwwRUFBMEU7WUFDMUUsdUVBQXVFO1lBQ3ZFLHVFQUF1RTtZQUN2RSxnRUFBZ0U7WUFDaEUseURBQXlEO1lBQ3pELElBQUksQ0FBQyxLQUFLLENBQUMsYUFBYSxFQUFFLFFBQVEsQ0FBQyxDQUFDO1lBQ3BDLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDO2lCQUNaLE1BQU0sQ0FBQyxNQUFNLENBQUM7aUJBQ2QsT0FBTyxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUM7aUJBQ3ZCLEtBQUssQ0FDRixrQkFBa0IsRUFDbEIsVUFBQyxDQUFDLElBQUssT0FBQSxLQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFoRCxDQUFnRCxDQUFDLENBQUM7WUFFakUsQ0FBQyxDQUFDLElBQUksQ0FBQyxjQUFjLEVBQUUsVUFBQyxNQUFNO2dCQUM1QixJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FDbEIsVUFBQyxDQUFDLElBQUssT0FBQSxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsRUFBRTtvQkFDeEIsZ0JBQWdCLEVBQUUsS0FBSSxDQUFDLGdCQUFnQjtpQkFDeEMsQ0FBQyxFQUZLLENBRUwsQ0FBQyxDQUFDO1lBQ1YsQ0FBQyxDQUFDLENBQUM7WUFFSCx3QkFBd0I7WUFDeEIsSUFBSSxhQUFhLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUM7WUFDOUMsSUFBSSxJQUFJLEdBQVEsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsQ0FBQztZQUNwQyxJQUFJLFVBQVUsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLHFCQUFxQixFQUFFLENBQUM7WUFDNUQsSUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLHFCQUFxQixFQUFFLENBQUM7WUFDNUMsMkRBQTJEO1lBQzNELElBQUksSUFBSSxHQUFHLGFBQWEsR0FBRyxVQUFVLENBQUMsSUFBSSxHQUFHLFFBQVEsQ0FBQyxLQUFLLEdBQUcsRUFBRSxFQUFFLEdBQUcsR0FBRyxDQUFDLENBQUM7WUFFMUUsSUFBSSxJQUFJLENBQUMsZUFBZSxLQUFLLE9BQU8sRUFBRTtnQkFDcEMsSUFBSSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsQ0FBQzthQUN6QztpQkFBTSxFQUFHLFdBQVc7Z0JBQ25CLElBQUksR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDekIsR0FBRyxHQUFHLFVBQVUsQ0FBQyxNQUFNLEdBQUcsZ0JBQWdCLENBQUMsc0JBQXNCLENBQUM7YUFDbkU7WUFFRCxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxXQUFXLEVBQUUsWUFBWSxHQUFHLElBQUksR0FBRyxLQUFLLEdBQUcsR0FBRyxHQUFHLEtBQUssQ0FBQyxDQUFDO1lBQzNFLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUNuQyxDQUFDO1FBRU8sb0NBQWdCLEdBQXhCLFVBQ0ksTUFBOEIsRUFDOUIsT0FBMEI7WUFGOUIsaUJBMkJDO1lBeEJDLElBQUksTUFBTSxHQUE2QixPQUFPLENBQUMsSUFBSSxFQUFFLENBQUMsR0FBRyxDQUFDLFVBQUMsQ0FBQyxFQUFFLENBQUM7Z0JBQzdELElBQUksQ0FBQyxHQUFHLEtBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxPQUFPLENBQUMsQ0FBQztnQkFDdEMsSUFBSSxDQUFDLEdBQUcsS0FBSSxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxLQUFJLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxPQUFPLENBQUMsQ0FBQyxDQUFDO29CQUN0QyxLQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsT0FBTyxDQUFDLENBQUM7Z0JBQ25FLE9BQU87b0JBQ0wsQ0FBQyxFQUFFLEtBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztvQkFDdkIsQ0FBQyxFQUFFLEtBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztvQkFDdkIsS0FBSyxFQUFFLENBQUM7b0JBQ1IsT0FBTyxFQUFFLE9BQU87aUJBQ2pCLENBQUM7WUFDSixDQUFDLENBQUMsQ0FBQztZQUNILElBQUksR0FBRyxHQUNILGFBQWEsQ0FBQyxNQUFNLEVBQUUsTUFBTSxFQUFFLFVBQUMsQ0FBeUIsSUFBSyxPQUFBLENBQUMsQ0FBQyxDQUFDLEVBQUgsQ0FBRyxDQUFDLENBQUM7WUFDdEUsSUFBSSxHQUFHLEtBQUssTUFBTSxDQUFDLE1BQU0sRUFBRTtnQkFDekIsT0FBTyxNQUFNLENBQUMsTUFBTSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQzthQUNsQztpQkFBTSxJQUFJLEdBQUcsS0FBSyxDQUFDLEVBQUU7Z0JBQ3BCLE9BQU8sTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQ2xCO2lCQUFNO2dCQUNMLElBQUksSUFBSSxHQUFHLE1BQU0sQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDLENBQUM7Z0JBQzNCLElBQUksSUFBSSxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDdkIsSUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDM0MsSUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDM0MsT0FBTyxRQUFRLEdBQUcsUUFBUSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQzthQUMxQztRQUNILENBQUM7UUFFTyxtQ0FBZSxHQUF2QixVQUF3QixPQUEwQjtZQUFsRCxpQkErQkM7WUE5QkMsSUFBSSxJQUFJLEdBQUcsT0FBTyxDQUFDLElBQUksRUFBRSxDQUFDO1lBQzFCLElBQU0sZUFBZSxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUM7WUFDN0MseURBQXlEO1lBQ3pELDJDQUEyQztZQUMzQyxJQUFJLElBQUksR0FBRyxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7WUFDckMsSUFBSSxRQUFRLEdBQUcsQ0FBQyxDQUFDO1lBQ2pCLElBQUksQ0FBQyxPQUFPLENBQUMsVUFBQyxDQUFDLEVBQUUsQ0FBQztnQkFDaEIsSUFBSSxPQUFPLEdBQUcsS0FBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxDQUFDO2dCQUNqRCxJQUFJLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsRUFBRTtvQkFDeEIsQ0FBQyxDQUFDLFFBQVEsR0FBRyxPQUFPLENBQUM7aUJBQ3RCO3FCQUFNO29CQUNMLElBQUksR0FBRyxJQUFJLEdBQUcsZUFBZSxHQUFHLENBQUMsQ0FBQyxHQUFHLGVBQWUsQ0FBQyxHQUFHLE9BQU8sQ0FBQztvQkFDaEUsUUFBUSxFQUFFLENBQUM7b0JBQ1gsc0VBQXNFO29CQUN0RSx3RUFBd0U7b0JBQ3hFLGlFQUFpRTtvQkFDakUsTUFBTTtvQkFDTixnRUFBZ0U7b0JBQ2hFLHNCQUFzQjtvQkFDdEIsTUFBTTtvQkFDTixxRUFBcUU7b0JBQ3JFLG9FQUFvRTtvQkFDcEUsZ0RBQWdEO29CQUNoRCxJQUFJLFlBQVksR0FBRyxDQUFDLENBQUM7b0JBQ3JCLElBQUksZUFBZSxLQUFLLEdBQUcsRUFBRTt3QkFDM0IsWUFBWSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsRUFBRSxRQUFRLENBQUMsQ0FBQztxQkFDMUQ7b0JBQ0QsQ0FBQyxDQUFDLFFBQVEsR0FBRyxJQUFJLEdBQUcsWUFBWSxDQUFDO2lCQUNsQztZQUNILENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQztRQUVPLDhCQUFVLEdBQWxCLFVBQW1CLElBQVk7WUFDN0IsSUFBSSxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxLQUFLLFNBQVMsRUFBRTtnQkFDMUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsR0FBRyxJQUFJLFNBQVMsQ0FBQyxPQUFPLENBQUMsRUFBRSxFQUFFLEVBQUMsSUFBSSxFQUFFLElBQUksRUFBQyxDQUFDLENBQUM7YUFDcEU7WUFDRCxPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDbEMsQ0FBQztRQUVNLDJCQUFpQixHQUF4QixVQUF5QixVQUFrQjtZQUV6QyxJQUFJLFVBQVUsS0FBSyxLQUFLLEVBQUU7Z0JBQ3hCLE9BQU8sSUFBSSxTQUFTLENBQUMsTUFBTSxDQUFDLFdBQVcsRUFBRSxDQUFDO2FBQzNDO2lCQUFNLElBQUksVUFBVSxLQUFLLFFBQVEsRUFBRTtnQkFDbEMsT0FBTyxJQUFJLFNBQVMsQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFLENBQUM7YUFDdEM7aUJBQU07Z0JBQ0wsTUFBTSxJQUFJLEtBQUssQ0FBQywyQkFBMkIsR0FBRyxVQUFVLENBQUMsQ0FBQzthQUMzRDtRQUNILENBQUM7UUFFRDs7V0FFRztRQUNJLG9DQUFnQixHQUF2QixVQUF3QixLQUFlO1lBQXZDLGlCQWlCQztZQWhCQyxLQUFLLEdBQUcsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO1lBQ3JCLElBQUksQ0FBQyxXQUFXLEdBQUcsS0FBSyxDQUFDO1lBRXpCLEtBQUssQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFFLDJCQUEyQjtZQUM3QyxJQUFJLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxVQUFDLENBQUMsSUFBSyxPQUFBLENBQUMsQ0FBQyxTQUFTLENBQUMsS0FBSSxDQUFDLGdCQUFnQixDQUFDLEVBQWxDLENBQWtDLENBQUMsQ0FBQztZQUNqRSxJQUFJLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQyxHQUFHLENBQUMsVUFBQyxDQUFDLElBQUssT0FBQSxLQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxFQUFsQixDQUFrQixDQUFDLENBQUM7WUFDckQsSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsVUFBQyxDQUFDLElBQUssT0FBQSxDQUFDLENBQUMsUUFBUSxDQUFDLEtBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFqQyxDQUFpQyxDQUFDLENBQUM7WUFDaEUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBRXRDLElBQUksSUFBSSxDQUFDLGdCQUFnQixFQUFFO2dCQUN6QixJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7YUFDN0M7WUFDRCxJQUFJLElBQUksQ0FBQyxjQUFjLEVBQUU7Z0JBQ3ZCLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQzthQUM3QztZQUNELElBQUksQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO1FBQy9CLENBQUM7UUFFRDs7OztXQUlHO1FBQ0ksa0RBQThCLEdBQXJDLFVBQXNDLFFBQTJCO1lBRS9ELElBQU0sWUFBWSxHQUFHLFFBQVEsQ0FBQyxJQUFJLEVBQUUsQ0FBQztZQUNyQyxJQUFJLFlBQVksQ0FBQyxNQUFNLElBQUksWUFBWSxFQUFFO2dCQUN2QywrQ0FBK0M7Z0JBQy9DLE9BQU8sUUFBUSxDQUFDO2FBQ2pCO1lBRUQsc0VBQXNFO1lBQ3RFLElBQU0sVUFBVSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLE1BQU0sR0FBRyxZQUFZLENBQUMsQ0FBQztZQUNqRSxJQUFNLElBQUksR0FBRyxJQUFJLEtBQUssQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxNQUFNLEdBQUcsVUFBVSxDQUFDLENBQUMsQ0FBQztZQUNyRSxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsSUFBSSxVQUFVLEVBQUU7Z0JBQzVELElBQUksQ0FBQyxDQUFDLENBQUMsR0FBRyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFDM0I7WUFDRCxPQUFPLElBQUksU0FBUyxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsUUFBUSxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUM7UUFDMUQsQ0FBQztRQUVEOztXQUVHO1FBQ0ksaUNBQWEsR0FBcEIsVUFBcUIsSUFBWSxFQUFFLElBQXFDO1lBQ3RFLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ25DLENBQUM7UUFFTSxtQ0FBZSxHQUF0QixVQUF1QixNQUFjO1lBQXJDLGlCQWlCQztZQWhCQyxJQUFJLENBQUMsZUFBZSxHQUFHLE1BQU0sQ0FBQztZQUM5QixJQUFJLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxVQUFDLENBQUMsSUFBSyxPQUFBLEtBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLEVBQXZCLENBQXVCLENBQUMsQ0FBQztZQUV0RCxJQUFJLENBQUMsSUFBSSxDQUFDLGdCQUFnQixFQUFFO2dCQUMxQixJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQztnQkFDaEMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGdCQUFnQixFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztnQkFDdkQsSUFBSSxDQUFDLGdCQUFnQixHQUFHLElBQUksQ0FBQztnQkFDN0IsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO2FBQzdDO1lBRUQsSUFBSSxJQUFJLENBQUMsa0JBQWtCLEVBQUU7Z0JBQzNCLG1EQUFtRDtnQkFDbkQsSUFBSSxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7YUFDakU7WUFFRCxJQUFJLENBQUMscUJBQXFCLEVBQUUsQ0FBQztRQUMvQixDQUFDO1FBRU0sb0NBQWdCLEdBQXZCO1lBQ0UsSUFBSSxJQUFJLENBQUMsZ0JBQWdCLEVBQUU7Z0JBQ3pCLElBQUksQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxDQUFDO2dCQUNuQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsY0FBYyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztnQkFDckQsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLENBQUM7Z0JBQ2pDLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxLQUFLLENBQUM7Z0JBQzlCLElBQUksQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO2FBQzlCO1lBQ0QsSUFBSSxJQUFJLENBQUMsa0JBQWtCLEVBQUU7Z0JBQzNCLGtFQUFrRTtnQkFDbEUsbUNBQW1DO2dCQUNuQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQzthQUNqRTtRQUNILENBQUM7UUFFTSwyQ0FBdUIsR0FBOUIsVUFBK0IsTUFBYztZQUMzQyxJQUFJLENBQUMsb0JBQW9CLEdBQUcsTUFBTSxDQUFDO1FBQ3JDLENBQUM7UUFFTSxzQ0FBa0IsR0FBekIsVUFBMEIsUUFBZ0I7WUFDeEMsSUFBSSxDQUFDLGVBQWUsR0FBRyxRQUFRLENBQUM7UUFDbEMsQ0FBQztRQUVNLDRCQUFRLEdBQWYsVUFBZ0IsU0FBMkM7WUFDekQsSUFBSSxDQUFDLFNBQVMsR0FBRyxTQUFTLENBQUM7WUFDM0IsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLENBQUM7WUFFL0IsSUFBSSxJQUFJLENBQUMsY0FBYyxJQUFJLElBQUksRUFBRTtnQkFDL0Isb0VBQW9FO2dCQUNwRSx5QkFBeUI7Z0JBQ3pCLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQzthQUNyQjtZQUVELElBQUksSUFBSSxDQUFDLGNBQWMsSUFBSSxJQUFJLEVBQUU7Z0JBQy9CLG9FQUFvRTtnQkFDcEUseUJBQXlCO2dCQUN6QixJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7YUFDckI7UUFDSCxDQUFDO1FBRU0sMEJBQU0sR0FBYjtZQUNFLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDdEIsQ0FBQztRQUVNLDJCQUFPLEdBQWQ7WUFDRSwyREFBMkQ7WUFDM0QsSUFBSSxJQUFJLENBQUMsS0FBSztnQkFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sRUFBRSxDQUFDO1FBQ3ZDLENBQUM7UUFDSCxnQkFBQztJQUFELENBQUMsQUE1dEJELElBNHRCQztJQUVEOzs7Ozs7T0FNRztJQUNILHVCQUEwQixLQUFVLEVBQUUsS0FBUSxFQUFFLFFBQTRCO1FBRTFFLElBQU0sS0FBSyxHQUFHLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUU5QixJQUFJLEdBQUcsR0FBRyxDQUFDLENBQUM7UUFDWixJQUFJLElBQUksR0FBRyxLQUFLLENBQUMsTUFBTSxDQUFDO1FBRXhCLE9BQU8sR0FBRyxHQUFHLElBQUksRUFBRTtZQUNqQixJQUFNLEdBQUcsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO1lBQ3pDLElBQU0sTUFBTSxHQUFHLFFBQVEsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztZQUNwQyxJQUFJLE1BQU0sR0FBRyxLQUFLLEVBQUU7Z0JBQ2xCLEdBQUcsR0FBRyxHQUFHLEdBQUcsQ0FBQyxDQUFDO2FBQ2Y7aUJBQU07Z0JBQ0wsSUFBSSxHQUFHLEdBQUcsQ0FBQzthQUNaO1NBQ0Y7UUFDRCxPQUFPLElBQUksQ0FBQztJQUNkLENBQUM7QUFFRCxDQUFDLEVBenJDUyxhQUFhLEtBQWIsYUFBYSxRQXlyQ3RCLENBQUUsMEJBQTBCIiwic291cmNlc0NvbnRlbnQiOlsiLyogQ29weXJpZ2h0IDIwMTUgVGhlIFRlbnNvckZsb3cgQXV0aG9ycy4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cblxuTGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlLCBWZXJzaW9uIDIuMCAodGhlIFwiTGljZW5zZVwiKTtcbnlvdSBtYXkgbm90IHVzZSB0aGlzIGZpbGUgZXhjZXB0IGluIGNvbXBsaWFuY2Ugd2l0aCB0aGUgTGljZW5zZS5cbllvdSBtYXkgb2J0YWluIGEgY29weSBvZiB0aGUgTGljZW5zZSBhdFxuXG4gICAgaHR0cDovL3d3dy5hcGFjaGUub3JnL2xpY2Vuc2VzL0xJQ0VOU0UtMi4wXG5cblVubGVzcyByZXF1aXJlZCBieSBhcHBsaWNhYmxlIGxhdyBvciBhZ3JlZWQgdG8gaW4gd3JpdGluZywgc29mdHdhcmVcbmRpc3RyaWJ1dGVkIHVuZGVyIHRoZSBMaWNlbnNlIGlzIGRpc3RyaWJ1dGVkIG9uIGFuIFwiQVMgSVNcIiBCQVNJUyxcbldJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWSBLSU5ELCBlaXRoZXIgZXhwcmVzcyBvciBpbXBsaWVkLlxuU2VlIHRoZSBMaWNlbnNlIGZvciB0aGUgc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nIHBlcm1pc3Npb25zIGFuZFxubGltaXRhdGlvbnMgdW5kZXIgdGhlIExpY2Vuc2UuXG49PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0qL1xubmFtZXNwYWNlIHZ6X2xpbmVfY2hhcnQge1xuXG4vKipcbiAqIEFuIGludGVyZmFjZSB0aGF0IGRlc2NyaWJlcyBhIGZpbGwgYXJlYSB0byB2aXN1YWxpemUuIFRoZSBmaWxsIGFyZWEgaXNcbiAqIHZpc3VhbGl6ZWQgd2l0aCBhIGxlc3MgaW50ZW5zZSB2ZXJzaW9uIG9mIHRoZSBjb2xvciBmb3IgYSBnaXZlbiBzZXJpZXMuXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgRmlsbEFyZWEge1xuICAvLyBUaGUgbG93ZXIgZW5kIG9mIHRoZSBmaWxsIGFyZWEuXG4gIGxvd2VyQWNjZXNzb3I6IFBsb3R0YWJsZS5JQWNjZXNzb3I8bnVtYmVyPjtcblxuICAvLyBUaGUgaGlnaGVyIGVuZCBvZiB0aGUgZmlsbCBhcmVhLlxuICBoaWdoZXJBY2Nlc3NvcjogUGxvdHRhYmxlLklBY2Nlc3NvcjxudW1iZXI+O1xufVxuXG4vKipcbiAqIFRoZSBtYXhpbXVtIG51bWJlciBvZiBtYXJrZXIgc3ltYm9scyB3aXRoaW4gYW55IGxpbmUgZm9yIGEgZGF0YSBzZXJpZXMuIFRvb1xuICogbWFueSBtYXJrZXJzIGNsdXR0ZXIgdGhlIGNoYXJ0LlxuICovXG5jb25zdCBfTUFYX01BUktFUlMgPSAyMDtcblxuUG9seW1lcih7XG4gIGlzOiAndnotbGluZS1jaGFydCcsXG4gIHByb3BlcnRpZXM6IHtcbiAgICAvKipcbiAgICAgKiBTY2FsZSB0aGF0IG1hcHMgc2VyaWVzIG5hbWVzIHRvIGNvbG9ycy4gVGhlIGRlZmF1bHQgY29sb3JzIGFyZSBmcm9tXG4gICAgICogZDMuc2NoZW1lQ2F0ZWdvcnkxMC4gVXNlIHRoaXMgcHJvcGVydHkgdG8gcmVwbGFjZSB0aGUgZGVmYXVsdCBsaW5lXG4gICAgICogY29sb3JzIHdpdGggY29sb3JzIG9mIHlvdXIgb3duIGNob2ljZS5cbiAgICAgKiBAdHlwZSB7UGxvdHRhYmxlLlNjYWxlcy5Db2xvcn1cbiAgICAgKiBAcmVxdWlyZWRcbiAgICAgKi9cbiAgICBjb2xvclNjYWxlOiB7XG4gICAgICB0eXBlOiBPYmplY3QsXG4gICAgICB2YWx1ZTogZnVuY3Rpb24oKSB7XG4gICAgICAgIHJldHVybiBuZXcgUGxvdHRhYmxlLlNjYWxlcy5Db2xvcigpLnJhbmdlKGQzLnNjaGVtZUNhdGVnb3J5MTApO1xuICAgICAgfVxuICAgIH0sXG5cbiAgICAvKipcbiAgICAgKiBBIGZ1bmN0aW9uIHRoYXQgdGFrZXMgYSBkYXRhIHNlcmllcyBzdHJpbmcgYW5kIHJldHVybnMgYVxuICAgICAqIFBsb3R0YWJsZS5TeW1ib2xGYWN0b3J5IHRvIHVzZSBmb3IgcmVuZGVyaW5nIHRoYXQgc2VyaWVzLiBUaGlzIHByb3BlcnR5XG4gICAgICogaW1wbGVtZW50cyB0aGUgdnpfY2hhcnRfaGVscGVycy5TeW1ib2xGbiBpbnRlcmZhY2UuXG4gICAgICovXG4gICAgc3ltYm9sRnVuY3Rpb246IE9iamVjdCxcblxuICAgIC8qKlxuICAgICAqIFdoZXRoZXIgc21vb3RoaW5nIGlzIGVuYWJsZWQgb3Igbm90LiBJZiB0cnVlLCBzbW9vdGhlZCBsaW5lcyB3aWxsIGJlXG4gICAgICogcGxvdHRlZCBpbiB0aGUgY2hhcnQgd2hpbGUgdGhlIHVuc21vb3RoZWQgbGluZXMgd2lsbCBiZSBnaG9zdGVkIGluXG4gICAgICogdGhlIGJhY2tncm91bmQuXG4gICAgICpcbiAgICAgKiBUaGUgc21vb3RoaW5nIGFsZ29yaXRobSBpcyBhIHNpbXBsZSBtb3ZpbmcgYXZlcmFnZSwgd2hpY2gsIGdpdmVuIGFcbiAgICAgKiBwb2ludCBwIGFuZCBhIHdpbmRvdyB3LCByZXBsYWNlcyBwIHdpdGggYSBzaW1wbGUgYXZlcmFnZSBvZiB0aGVcbiAgICAgKiBwb2ludHMgaW4gdGhlIFtwIC0gZmxvb3Iody8yKSwgcCArIGZsb29yKHcvMildIHJhbmdlLiAgSWYgdGhlcmVcbiAgICAgKiBhcmVuJ3QgZW5vdWdoIHBvaW50cyB0byBjb3ZlciB0aGUgZW50aXJlIHdpbmRvdyB0byB0aGUgbGVmdCwgdGhlXG4gICAgICogd2luZG93IGlzIHJlZHVjZWQgdG8gZml0IGV4YWN0bHkgdGhlIGFtb3VudCBvZiBlbGVtZW50cyBhdmFpbGFibGUuXG4gICAgICogVGhpcyBtZWFucyB0aGF0IHRoZSBzbW9vdGhlZCBsaW5lIHdpbGwgYmUgbGVzcyBpbiBhbmQgZ3JhZHVhbGx5XG4gICAgICogYmVjb21lIG1vcmUgc21vb3RoIHVudGlsIHRoZSBkZXNpcmVkIHdpbmRvdyBpcyByZWFjaGVkLiBIb3dldmVyIHdoZW5cbiAgICAgKiB0aGVyZSBhcmVuJ3QgZW5vdWdoIHBvaW50cyBvbiB0aGUgcmlnaHQsIHRoZSBsaW5lIHN0b3BzIGJlaW5nXG4gICAgICogcmVuZGVyZWQgYXQgYWxsLlxuICAgICAqL1xuICAgIHNtb290aGluZ0VuYWJsZWQ6IHtcbiAgICAgIHR5cGU6IEJvb2xlYW4sXG4gICAgICBub3RpZnk6IHRydWUsXG4gICAgICB2YWx1ZTogZmFsc2UsXG4gICAgfSxcblxuICAgIC8qKlxuICAgICAqIFdlaWdodCAoYmV0d2VlbiAwLjAgYW5kIDEuMCkgb2YgdGhlIHNtb290aGluZy4gVGhpcyB3ZWlnaHQgY29udHJvbHNcbiAgICAgKiB0aGUgd2luZG93IHNpemUsIGFuZCBhIHdlaWdodCBvZiAxLjAgbWVhbnMgdXNpbmcgNTAlIG9mIHRoZSBlbnRpcmVcbiAgICAgKiBkYXRhc2V0IGFzIHRoZSB3aW5kb3csIHdoaWxlIGEgd2VpZ2h0IG9mIDAuMCBtZWFucyB1c2luZyBhIHdpbmRvdyBvZlxuICAgICAqIDAgKGFuZCB0aHVzIHJlcGxhY2luZyBlYWNoIHBvaW50IHdpdGggdGhlbXNlbHZlcykuXG4gICAgICpcbiAgICAgKiBUaGUgZ3Jvd3RoIGJldHdlZW4gMC4wIGFuZCAxLjAgaXMgbm90IGxpbmVhciB0aG91Z2guIEJlY2F1c2VcbiAgICAgKiBjaGFuZ2luZyB0aGUgd2luZG93IGZyb20gMCUgdG8gMzAlIG9mIHRoZSBkYXRhc2V0IHNtb290aHMgdGhlIGxpbmUgYVxuICAgICAqIGxvdCBtb3JlIHRoYW4gY2hhbmdpbmcgdGhlIHdpbmRvdyBmcm9tIDcwJSB0byAxMDAlLCBhbiBleHBvbmVudGlhbFxuICAgICAqIGZ1bmN0aW9uIGlzIHVzZWQgaW5zdGVhZDogaHR0cDovL2kuaW1ndXIuY29tL2JEcmhFWlUucG5nLiBUaGlzXG4gICAgICogZnVuY3Rpb24gaW5jcmVhc2VzIHRoZSBzaXplIG9mIHRoZSB3aW5kb3cgc2xvd2x5IGF0IHRoZSBiZWdpbm5pbmdcbiAgICAgKiBhbmQgZ3JhZHVhbGx5IHNwZWVkcyB1cCB0aGUgZ3Jvd3RoLCBidXQgMC4wIHN0aWxsIG1lYW5zIGEgd2luZG93IG9mXG4gICAgICogMCBhbmQgMS4wIHN0aWxsIG1lYW5zIGEgd2luZG93IG9mIHRoZSBkYXRhc2V0J3MgbGVuZ3RoLlxuICAgICAqL1xuICAgIHNtb290aGluZ1dlaWdodDoge3R5cGU6IE51bWJlciwgdmFsdWU6IDAuNn0sXG5cbiAgICAvKipcbiAgICAgKiBUaGlzIGlzIGEgaGVscGVyIGZpZWxkIGZvciBhdXRvbWF0aWNhbGx5IGdlbmVyYXRpbmcgY29tbW9ubHkgdXNlZFxuICAgICAqIGZ1bmN0aW9ucyBmb3IgeENvbXBvbmVudHNDcmVhdGlvbk1ldGhvZC4gVmFsaWQgdmFsdWVzIGFyZSB3aGF0IGNhblxuICAgICAqIGJlIHByb2Nlc3NlZCBieSB2el9jaGFydF9oZWxwZXJzLmdldFhDb21wb25lbnRzKCkgYW5kIGluY2x1ZGVcbiAgICAgKiBcInN0ZXBcIiwgXCJ3YWxsX3RpbWVcIiwgYW5kIFwicmVsYXRpdmVcIi5cbiAgICAgKi9cbiAgICB4VHlwZToge3R5cGU6IFN0cmluZywgdmFsdWU6ICcnfSxcblxuICAgIC8qKlxuICAgICAqIFdlIGFjY2VwdCBhIGZ1bmN0aW9uIGZvciBjcmVhdGluZyBhbiBYQ29tcG9uZW50cyBvYmplY3QgaW5zdGVhZCBvZiBzdWNoXG4gICAgICogYW4gb2JqZWN0IGl0c2VsZiBiZWNhdXNlIHRoZSBBeGlzIG11c3QgYmUgbWFkZSByaWdodCB3aGVuIHdlIG1ha2UgdGhlXG4gICAgICogTGluZUNoYXJ0IG9iamVjdCwgbGVzdCB3ZSB1c2UgYSBwcmV2aW91c2x5IGRlc3Ryb3llZCBBeGlzLiBTZWUgdGhlIGFzeW5jXG4gICAgICogbG9naWMgYmVsb3cgdGhhdCB1c2VzIHRoaXMgcHJvcGVydHkuXG4gICAgICpcbiAgICAgKiBOb3RlIHRoYXQgdGhpcyBmdW5jdGlvbiByZXR1cm5zIGEgZnVuY3Rpb24gYmVjYXVzZSBwb2x5bWVyIGNhbGxzIHRoZVxuICAgICAqIG91dGVyIGZ1bmN0aW9uIHRvIGNvbXB1dGUgdGhlIHZhbHVlLiBXZSBhY3R1YWxseSB3YW50IHRoZSB2YWx1ZSBvZiB0aGlzXG4gICAgICogcHJvcGVydHkgdG8gYmUgdGhlIGlubmVyIGZ1bmN0aW9uLlxuICAgICAqXG4gICAgICogQHR5cGUge2Z1bmN0aW9uKCk6IHZ6X2NoYXJ0X2hlbHBlcnMuWENvbXBvbmVudHN9XG4gICAgICovXG4gICAgeENvbXBvbmVudHNDcmVhdGlvbk1ldGhvZDoge1xuICAgICAgdHlwZTogT2JqZWN0LFxuICAgICAgLyogTm90ZTogV2UgaGF2ZSB0byBwcm92aWRlIGEgbm9uc2Vuc2UgdmFsdWUgZm9yXG4gICAgICAgKiB4Q29tcG9uZW50c0NyZWF0aW9uTWV0aG9kIGhlcmUsIGJlY2F1c2UgUG9seW1lciBvYnNlcnZlcnMgb25seVxuICAgICAgICogdHJpZ2dlciBhZnRlciBhbGwgcGFyYW1ldGVycyBhcmUgc2V0LiAqL1xuICAgICAgdmFsdWU6ICcnXG4gICAgfSxcblxuICAgIC8qKlxuICAgICAqIEEgZm9ybWF0dGVyIGZvciB2YWx1ZXMgYWxvbmcgdGhlIFgtYXhpcy4gT3B0aW9uYWwuIERlZmF1bHRzIHRvIGFcbiAgICAgKiByZWFzb25hYmxlIGZvcm1hdHRlci5cbiAgICAgKlxuICAgICAqIEB0eXBlIHtmdW5jdGlvbihudW1iZXIpOiBzdHJpbmd9XG4gICAgICovXG4gICAgeEF4aXNGb3JtYXR0ZXI6IE9iamVjdCxcblxuICAgIC8qKlxuICAgICAqIEEgZm9ybWF0dGVyIGZvciB2YWx1ZXMgYWxvbmcgdGhlIFktYXhpcy4gT3B0aW9uYWwuIERlZmF1bHRzIHRvIGFcbiAgICAgKiByZWFzb25hYmxlIGZvcm1hdHRlci5cbiAgICAgKlxuICAgICAqIEB0eXBlIHtmdW5jdGlvbihudW1iZXIpOiBzdHJpbmd9XG4gICAgICovXG4gICAgeUF4aXNGb3JtYXR0ZXI6IE9iamVjdCxcblxuICAgIC8qKlxuICAgICAqIEEgbWV0aG9kIHRoYXQgaW1wbGVtZW50cyB0aGUgUGxvdHRhYmxlLklBY2Nlc3NvcjxudW1iZXI+IGludGVyZmFjZS4gVXNlZFxuICAgICAqIGZvciBhY2Nlc3NpbmcgdGhlIHkgdmFsdWUgZnJvbSBhIGRhdGEgcG9pbnQuXG4gICAgICpcbiAgICAgKiBOb3RlIHRoYXQgdGhpcyBmdW5jdGlvbiByZXR1cm5zIGEgZnVuY3Rpb24gYmVjYXVzZSBwb2x5bWVyIGNhbGxzIHRoZVxuICAgICAqIG91dGVyIGZ1bmN0aW9uIHRvIGNvbXB1dGUgdGhlIHZhbHVlLiBXZSBhY3R1YWxseSB3YW50IHRoZSB2YWx1ZSBvZiB0aGlzXG4gICAgICogcHJvcGVydHkgdG8gYmUgdGhlIGlubmVyIGZ1bmN0aW9uLlxuICAgICAqL1xuICAgIHlWYWx1ZUFjY2Vzc29yOiB7dHlwZTogT2JqZWN0LCB2YWx1ZTogKCkgPT4gKGQgPT4gZC5zY2FsYXIpfSxcblxuICAgIC8qKlxuICAgICAqIEFuIGFycmF5IG9mIENoYXJ0SGVscGVyLlRvb2x0aXBDb2x1bW4gb2JqZWN0cy4gVXNlZCB0byBwb3B1bGF0ZSB0aGUgdGFibGVcbiAgICAgKiB3aXRoaW4gdGhlIHRvb2x0aXAuIFRoZSB0YWJsZSBjb250YWlucyAxIHJvdyBwZXIgcnVuLlxuICAgICAqXG4gICAgICogTm90ZSB0aGF0IHRoaXMgZnVuY3Rpb24gcmV0dXJucyBhIGZ1bmN0aW9uIGJlY2F1c2UgcG9seW1lciBjYWxscyB0aGVcbiAgICAgKiBvdXRlciBmdW5jdGlvbiB0byBjb21wdXRlIHRoZSB2YWx1ZS4gV2UgYWN0dWFsbHkgd2FudCB0aGUgdmFsdWUgb2YgdGhpc1xuICAgICAqIHByb3BlcnR5IHRvIGJlIHRoZSBpbm5lciBmdW5jdGlvbi5cbiAgICAgKlxuICAgICAqL1xuICAgIHRvb2x0aXBDb2x1bW5zOiB7XG4gICAgICB0eXBlOiBBcnJheSxcbiAgICAgIHZhbHVlOiBmdW5jdGlvbigpIHtcbiAgICAgICAgY29uc3QgdmFsdWVGb3JtYXR0ZXIgPSB2el9jaGFydF9oZWxwZXJzLm11bHRpc2NhbGVGb3JtYXR0ZXIoXG4gICAgICAgICAgICB2el9jaGFydF9oZWxwZXJzLllfVE9PTFRJUF9GT1JNQVRURVJfUFJFQ0lTSU9OKTtcbiAgICAgICAgY29uc3QgZm9ybWF0VmFsdWVPck5hTiA9ICh4KSA9PiBpc05hTih4KSA/ICdOYU4nIDogdmFsdWVGb3JtYXR0ZXIoeCk7XG5cbiAgICAgICAgcmV0dXJuIFtcbiAgICAgICAgICB7XG4gICAgICAgICAgICB0aXRsZTogJ05hbWUnLFxuICAgICAgICAgICAgZXZhbHVhdGU6IChkKSA9PiBkLmRhdGFzZXQubWV0YWRhdGEoKS5uYW1lLFxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgdGl0bGU6ICdTbW9vdGhlZCcsXG4gICAgICAgICAgICBldmFsdWF0ZTogKGQsIHN0YXR1c09iamVjdCkgPT4ge1xuICAgICAgICAgICAgICBjb25zdCBzbW9vdGhpbmdFbmFibGVkID1cbiAgICAgICAgICAgICAgICAgIHN0YXR1c09iamVjdCAmJiBzdGF0dXNPYmplY3Quc21vb3RoaW5nRW5hYmxlZDtcbiAgICAgICAgICAgICAgcmV0dXJuIGZvcm1hdFZhbHVlT3JOYU4oXG4gICAgICAgICAgICAgICAgICBzbW9vdGhpbmdFbmFibGVkID8gZC5kYXR1bS5zbW9vdGhlZCA6IGQuZGF0dW0uc2NhbGFyKTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICB0aXRsZTogJ1ZhbHVlJyxcbiAgICAgICAgICAgIGV2YWx1YXRlOiAoZCkgPT4gZm9ybWF0VmFsdWVPck5hTihkLmRhdHVtLnNjYWxhciksXG4gICAgICAgICAgfSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICB0aXRsZTogJ1N0ZXAnLFxuICAgICAgICAgICAgZXZhbHVhdGU6IChkKSA9PiB2el9jaGFydF9oZWxwZXJzLnN0ZXBGb3JtYXR0ZXIoXG4gICAgICAgICAgICAgICAgZC5kYXR1bS5zdGVwKSxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIHRpdGxlOiAnVGltZScsXG4gICAgICAgICAgICBldmFsdWF0ZTogKGQpID0+IHZ6X2NoYXJ0X2hlbHBlcnMudGltZUZvcm1hdHRlcihcbiAgICAgICAgICAgICAgICBkLmRhdHVtLndhbGxfdGltZSksXG4gICAgICAgICAgfSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICB0aXRsZTogJ1JlbGF0aXZlJyxcbiAgICAgICAgICAgIGV2YWx1YXRlOiAoZCkgPT4gdnpfY2hhcnRfaGVscGVycy5yZWxhdGl2ZUZvcm1hdHRlcihcbiAgICAgICAgICAgICAgICB2el9jaGFydF9oZWxwZXJzLnJlbGF0aXZlQWNjZXNzb3IoZC5kYXR1bSwgLTEsIGQuZGF0YXNldCkpLFxuICAgICAgICAgIH0sXG4gICAgICAgIF07XG4gICAgICB9XG4gICAgfSxcblxuICAgIC8qKlxuICAgICAqIEFuIG9wdGlvbmFsIEZpbGxBcmVhIG9iamVjdC4gSWYgcHJvdmlkZWQsIHRoZSBjaGFydCB3aWxsXG4gICAgICogdmlzdWFsaXplIGZpbGwgYXJlYSBhbG9uZ3NpZGUgdGhlIHByaW1hcnkgbGluZSBmb3IgZWFjaCBzZXJpZXMuIElmIHNldCxcbiAgICAgKiBjb25zaWRlciBzZXR0aW5nIGlnbm9yZVlPdXRsaWVycyB0byBmYWxzZS4gT3RoZXJ3aXNlLCBvdXRsaWVyXG4gICAgICogY2FsY3VsYXRpb25zIG1heSBkZWVtIHNvbWUgbWFyZ2lucyB0byBiZSBvdXRsaWVycywgYW5kIHNvbWUgcG9ydGlvbnMgb2ZcbiAgICAgKiB0aGUgZmlsbCBhcmVhIG1heSBub3QgZGlzcGxheS5cbiAgICAgKi9cbiAgICBmaWxsQXJlYTogT2JqZWN0LFxuXG4gICAgLyoqXG4gICAgICogQW4gb3B0aW9uYWwgYXJyYXkgb2YgMiBudW1iZXJzIGZvciB0aGUgbWluIGFuZCBtYXggb2YgdGhlIGRlZmF1bHQgcmFuZ2VcbiAgICAgKiBvZiB0aGUgWSBheGlzLiBJZiBub3QgcHJvdmlkZWQsIGEgcmVhc29uYWJsZSByYW5nZSB3aWxsIGJlIGdlbmVyYXRlZC5cbiAgICAgKiBUaGlzIHByb3BlcnR5IGlzIGEgbGlzdCBpbnN0ZWFkIG9mIDIgaW5kaXZpZHVhbCBwcm9wZXJ0aWVzIHRvIGVtcGhhc2l6ZVxuICAgICAqIHRoYXQgYm90aCB0aGUgbWluIGFuZCB0aGUgbWF4IG11c3QgYmUgc3BlY2lmaWVkIChvciBuZWl0aGVyIGF0IGFsbCkuXG4gICAgICovXG4gICAgZGVmYXVsdFhSYW5nZTogQXJyYXksXG5cbiAgICAvKipcbiAgICAgKiBBbiBvcHRpb25hbCBhcnJheSBvZiAyIG51bWJlcnMgZm9yIHRoZSBtaW4gYW5kIG1heCBvZiB0aGUgZGVmYXVsdCByYW5nZVxuICAgICAqIG9mIHRoZSBZIGF4aXMuIElmIG5vdCBwcm92aWRlZCwgYSByZWFzb25hYmxlIHJhbmdlIHdpbGwgYmUgZ2VuZXJhdGVkLlxuICAgICAqIFRoaXMgcHJvcGVydHkgaXMgYSBsaXN0IGluc3RlYWQgb2YgMiBpbmRpdmlkdWFsIHByb3BlcnRpZXMgdG8gZW1waGFzaXplXG4gICAgICogdGhhdCBib3RoIHRoZSBtaW4gYW5kIHRoZSBtYXggbXVzdCBiZSBzcGVjaWZpZWQgKG9yIG5laXRoZXIgYXQgYWxsKS5cbiAgICAgKi9cbiAgICBkZWZhdWx0WVJhbmdlOiBBcnJheSxcblxuICAgIC8qKlxuICAgICAqIFRvb2x0aXAgaGVhZGVyIGlubmVySFRNTCB0ZXh0LiBXZSBjYW5ub3QgdXNlIGEgZG9tLXJlcGVhdCBpbnNpZGUgb2YgYVxuICAgICAqIHRhYmxlIGVsZW1lbnQgYmVjYXVzZSBQb2x5bWVyIGRvZXMgbm90IHN1cHBvcnQgdGhhdC4gVGhpcyBzZWVtcyBsaWtlXG4gICAgICogYSBidWcgaW4gUG9seW1lci4gSGVuY2UsIHdlIG1hbnVhbGx5IGdlbmVyYXRlIHRoZSBIVE1MIGZvciBjcmVhdGluZyBhIHJvd1xuICAgICAqIG9mIHRhYmxlIGhlYWRlcnMuXG4gICAgICovXG4gICAgX3Rvb2x0aXBUYWJsZUhlYWRlckh0bWw6IHtcbiAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgIGNvbXB1dGVkOiBcIl9jb21wdXRlVG9vbHRpcFRhYmxlSGVhZGVySHRtbCh0b29sdGlwQ29sdW1ucylcIixcbiAgICB9LFxuXG4gICAgLyoqXG4gICAgICogVGhlIHNjYWxlIGZvciB0aGUgeS1heGlzLiBBbGxvd3M6XG4gICAgICogLSBcImxpbmVhclwiIC0gbGluZWFyIHNjYWxlIChQbG90dGFibGUuU2NhbGVzLkxpbmVhcilcbiAgICAgKiAtIFwibG9nXCIgLSBtb2RpZmllZC1sb2cgc2NhbGUgKFBsb3R0YWJsZS5TY2FsZXMuTW9kaWZpZWRMb2cpXG4gICAgICovXG4gICAgeVNjYWxlVHlwZToge3R5cGU6IFN0cmluZywgdmFsdWU6ICdsaW5lYXInfSxcblxuICAgIC8qKlxuICAgICAqIFdoZXRoZXIgdG8gaWdub3JlIG91dGxpZXIgZGF0YSB3aGVuIGNvbXB1dGluZyB0aGUgeVNjYWxlIGRvbWFpbi5cbiAgICAgKi9cbiAgICBpZ25vcmVZT3V0bGllcnM6IHtcbiAgICAgIHR5cGU6IEJvb2xlYW4sXG4gICAgICB2YWx1ZTogZmFsc2UsXG4gICAgfSxcblxuICAgIC8qKlxuICAgICAqIENoYW5nZSBob3cgdGhlIHRvb2x0aXAgaXMgc29ydGVkLiBBbGxvd3M6XG4gICAgICogLSBcImRlZmF1bHRcIiAtIFNvcnQgdGhlIHRvb2x0aXAgYnkgaW5wdXQgb3JkZXIuXG4gICAgICogLSBcImFzY2VuZGluZ1wiIC0gU29ydCB0aGUgdG9vbHRpcCBieSBhc2NlbmRpbmcgdmFsdWUuXG4gICAgICogLSBcImRlc2NlbmRpbmdcIiAtIFNvcnQgdGhlIHRvb2x0aXAgYnkgZGVzY2VuZGluZyB2YWx1ZS5cbiAgICAgKiAtIFwibmVhcmVzdFwiIC0gU29ydCB0aGUgdG9vbHRpcCBieSBjbG9zZXN0IHRvIGN1cnNvci5cbiAgICAgKi9cbiAgICB0b29sdGlwU29ydGluZ01ldGhvZDoge3R5cGU6IFN0cmluZywgdmFsdWU6ICdkZWZhdWx0J30sXG5cbiAgICAvKipcbiAgICAgKiBDaGFuZ2UgaG93IHRoZSB0b29sdGlwIGlzIHBvc2l0aW9uZWQuIEFsbG93czpcbiAgICAgKiAtIFwiYm90dG9tXCIgLSBQb3NpdGlvbiB0aGUgdG9vbHRpcCBvbiB0aGUgYm90dG9tIG9mIHRoZSBjaGFydC5cbiAgICAgKiAtIFwicmlnaHRcIiAtIFBvc2l0aW9uIHRoZSB0b29sdGlwIHRvIHRoZSByaWdodCBvZiB0aGUgY2hhcnQuXG4gICAgICovXG4gICAgdG9vbHRpcFBvc2l0aW9uOiB7dHlwZTogU3RyaW5nLCB2YWx1ZTogJ2JvdHRvbSd9LFxuXG4gICAgX2F0dGFjaGVkOiBCb29sZWFuLFxuICAgIF9jaGFydDogT2JqZWN0LFxuICAgIF92aXNpYmxlU2VyaWVzQ2FjaGU6IHtcbiAgICAgIHR5cGU6IEFycmF5LFxuICAgICAgdmFsdWU6IGZ1bmN0aW9uKCkge1xuICAgICAgICByZXR1cm4gW11cbiAgICAgIH1cbiAgICB9LFxuICAgIF9zZXJpZXNEYXRhQ2FjaGU6IHtcbiAgICAgIHR5cGU6IE9iamVjdCxcbiAgICAgIHZhbHVlOiBmdW5jdGlvbigpIHtcbiAgICAgICAgcmV0dXJuIHt9XG4gICAgICB9XG4gICAgfSxcbiAgICBfbWFrZUNoYXJ0QXN5bmNDYWxsYmFja0lkOiB7dHlwZTogTnVtYmVyLCB2YWx1ZTogbnVsbH0sXG4gIH0sXG4gIG9ic2VydmVyczogW1xuICAgICdfbWFrZUNoYXJ0KHhDb21wb25lbnRzQ3JlYXRpb25NZXRob2QsIHhUeXBlLCB5VmFsdWVBY2Nlc3NvciwgeVNjYWxlVHlwZSwgdG9vbHRpcENvbHVtbnMsIGNvbG9yU2NhbGUsIF9hdHRhY2hlZCknLFxuICAgICdfcmVsb2FkRnJvbUNhY2hlKF9jaGFydCknLFxuICAgICdfc21vb3RoaW5nQ2hhbmdlZChzbW9vdGhpbmdFbmFibGVkLCBzbW9vdGhpbmdXZWlnaHQsIF9jaGFydCknLFxuICAgICdfdG9vbHRpcFNvcnRpbmdNZXRob2RDaGFuZ2VkKHRvb2x0aXBTb3J0aW5nTWV0aG9kLCBfY2hhcnQpJyxcbiAgICAnX3Rvb2x0aXBQb3NpdGlvbkNoYW5nZWQodG9vbHRpcFBvc2l0aW9uLCBfY2hhcnQpJyxcbiAgICAnX291dGxpZXJzQ2hhbmdlZChpZ25vcmVZT3V0bGllcnMsIF9jaGFydCknXG4gIF0sXG5cbiAgLyoqXG4gICAqIFNldHMgdGhlIHNlcmllcyB0aGF0IHRoZSBjaGFydCBkaXNwbGF5cy4gU2VyaWVzIHdpdGggb3RoZXIgbmFtZXMgd2lsbFxuICAgKiBub3QgYmUgZGlzcGxheWVkLlxuICAgKlxuICAgKiBAcGFyYW0ge0FycmF5PFN0cmluZz59IG5hbWVzIEFycmF5IHdpdGggdGhlIG5hbWVzIG9mIHRoZSBzZXJpZXMgdG9cbiAgICogZGlzcGxheS5cbiAgICovXG4gIHNldFZpc2libGVTZXJpZXM6IGZ1bmN0aW9uKG5hbWVzKSB7XG4gICAgdGhpcy5fdmlzaWJsZVNlcmllc0NhY2hlID0gbmFtZXM7XG4gICAgaWYgKHRoaXMuX2NoYXJ0KSB7XG4gICAgICB0aGlzLl9jaGFydC5zZXRWaXNpYmxlU2VyaWVzKG5hbWVzKTtcbiAgICAgIHRoaXMucmVkcmF3KCk7XG4gICAgfVxuICB9LFxuXG4gIC8qKlxuICAgKiBTZXRzIHRoZSBkYXRhIG9mIG9uZSBvZiB0aGUgc2VyaWVzLiBOb3RlIHRoYXQgdG8gZGlzcGxheSB0aGlzIHNlcmllc1xuICAgKiBpdHMgbmFtZSBtdXN0IGJlIGluIHRoZSBzZXRWaXNpYmxlU2VyaWVzKCkgYXJyYXkuXG4gICAqXG4gICAqIEBwYXJhbSB7c3RyaW5nfSBuYW1lIE5hbWUgb2YgdGhlIHNlcmllcy5cbiAgICogQHBhcmFtIHtBcnJheTwgdnpfY2hhcnRfaGVscGVycy5TY2FsYXJEYXR1bT59IGRhdGEgRGF0YSBvZiB0aGUgc2VyaWVzLlxuICAgKiBUaGlzIGlzIGFuIGFycmF5IG9mIG9iamVjdHMgd2l0aCBhdCBsZWFzdCB0aGUgZm9sbG93aW5nIHByb3BlcnRpZXM6XG4gICAqIC0gc3RlcDogKE51bWJlcikgLSBpbmRleCBvZiB0aGUgZGF0dW0uXG4gICAqIC0gd2FsbF90aW1lOiAoRGF0ZSkgLSBEYXRlIG9iamVjdCB3aXRoIHRoZSBkYXR1bSdzIHRpbWUuXG4gICAqIC0gc2NhbGFyOiAoTnVtYmVyKSAtIFZhbHVlIG9mIHRoZSBkYXR1bS5cbiAgICovXG4gIHNldFNlcmllc0RhdGE6IGZ1bmN0aW9uKG5hbWUsIGRhdGEpIHtcbiAgICB0aGlzLl9zZXJpZXNEYXRhQ2FjaGVbbmFtZV0gPSBkYXRhO1xuICAgIGlmICh0aGlzLl9jaGFydCkge1xuICAgICAgdGhpcy5fY2hhcnQuc2V0U2VyaWVzRGF0YShuYW1lLCBkYXRhKTtcbiAgICB9XG4gIH0sXG5cbiAgLyoqXG4gICAqIFJlc2V0IHRoZSBjaGFydCBkb21haW4uIElmIHRoZSBjaGFydCBoYXMgbm90IHJlbmRlcmVkIHlldCwgYSBjYWxsIHRvIHRoaXNcbiAgICogbWV0aG9kIG5vLW9wcy5cbiAgICovXG4gIHJlc2V0RG9tYWluOiBmdW5jdGlvbigpIHtcbiAgICBpZiAodGhpcy5fY2hhcnQpIHtcbiAgICAgIHRoaXMuX2NoYXJ0LnJlc2V0RG9tYWluKCk7XG4gICAgfVxuICB9LFxuXG4gIC8qKlxuICAgKiBSZS1yZW5kZXJzIHRoZSBjaGFydC4gVXNlZnVsIGlmIGUuZy4gdGhlIGNvbnRhaW5lciBzaXplIGNoYW5nZWQuXG4gICAqL1xuICByZWRyYXc6IGZ1bmN0aW9uKCkge1xuICAgIGlmICh0aGlzLl9jaGFydCkge1xuICAgICAgdGhpcy5fY2hhcnQucmVkcmF3KCk7XG4gICAgfVxuICB9LFxuXG4gIGF0dGFjaGVkOiBmdW5jdGlvbigpIHtcbiAgICB0aGlzLl9hdHRhY2hlZCA9IHRydWU7XG4gIH0sXG5cbiAgZGV0YWNoZWQ6IGZ1bmN0aW9uKCkge1xuICAgIGlmICh0aGlzLl9jaGFydCkgdGhpcy5fY2hhcnQuZGVzdHJveSgpO1xuICAgIHRoaXMuX2F0dGFjaGVkID0gZmFsc2U7XG4gIH0sXG5cbiAgcmVhZHk6IGZ1bmN0aW9uKCkge1xuICAgIHRoaXMuc2NvcGVTdWJ0cmVlKHRoaXMuJC50b29sdGlwLCB0cnVlKTtcbiAgICB0aGlzLnNjb3BlU3VidHJlZSh0aGlzLiQuY2hhcnRkaXYsIHRydWUpO1xuICB9LFxuXG4gIC8qKlxuICAgKiBDcmVhdGVzIGEgY2hhcnQsIGFuZCBhc3luY2hyb25vdXNseSByZW5kZXJzIGl0LiBGaXJlcyBhIGNoYXJ0LXJlbmRlcmVkXG4gICAqIGV2ZW50IGFmdGVyIHRoZSBjaGFydCBpcyByZW5kZXJlZC5cbiAgICovXG4gIF9tYWtlQ2hhcnQ6IGZ1bmN0aW9uKFxuICAgICAgeENvbXBvbmVudHNDcmVhdGlvbk1ldGhvZCxcbiAgICAgIHhUeXBlLFxuICAgICAgeVZhbHVlQWNjZXNzb3IsXG4gICAgICB5U2NhbGVUeXBlLFxuICAgICAgdG9vbHRpcENvbHVtbnMsXG4gICAgICBjb2xvclNjYWxlLFxuICAgICAgX2F0dGFjaGVkKSB7XG4gICAgLy8gRmluZCB0aGUgYWN0dWFsIHhDb21wb25lbnRzQ3JlYXRpb25NZXRob2QuXG4gICAgaWYgKCF4VHlwZSAmJiAheENvbXBvbmVudHNDcmVhdGlvbk1ldGhvZCkge1xuICAgICAgeENvbXBvbmVudHNDcmVhdGlvbk1ldGhvZCA9IHZ6X2NoYXJ0X2hlbHBlcnMuc3RlcFg7XG4gICAgfSBlbHNlIGlmICh4VHlwZSkge1xuICAgICAgeENvbXBvbmVudHNDcmVhdGlvbk1ldGhvZCA9ICgpID0+XG4gICAgICAgICAgdnpfY2hhcnRfaGVscGVycy5nZXRYQ29tcG9uZW50cyh4VHlwZSk7XG4gICAgfVxuXG4gICAgaWYgKHRoaXMuX21ha2VDaGFydEFzeW5jQ2FsbGJhY2tJZCAhPT0gbnVsbCkge1xuICAgICAgdGhpcy5jYW5jZWxBc3luYyh0aGlzLl9tYWtlQ2hhcnRBc3luY0NhbGxiYWNrSWQpO1xuICAgICAgdGhpcy5fbWFrZUNoYXJ0QXN5bmNDYWxsYmFja0lkID0gbnVsbDtcbiAgICB9XG5cbiAgICB0aGlzLl9tYWtlQ2hhcnRBc3luY0NhbGxiYWNrSWQgPSB0aGlzLmFzeW5jKGZ1bmN0aW9uKCkge1xuICAgICAgdGhpcy5fbWFrZUNoYXJ0QXN5bmNDYWxsYmFja0lkID0gbnVsbDtcbiAgICAgIGlmICghdGhpcy5fYXR0YWNoZWQgfHxcbiAgICAgICAgICAheENvbXBvbmVudHNDcmVhdGlvbk1ldGhvZCB8fFxuICAgICAgICAgICF0aGlzLnlWYWx1ZUFjY2Vzc29yIHx8XG4gICAgICAgICAgIXRoaXMudG9vbHRpcENvbHVtbnMpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgdmFyIHRvb2x0aXAgPSBkMy5zZWxlY3QodGhpcy4kLnRvb2x0aXApO1xuICAgICAgLy8gV2UgZGlyZWN0bHkgcmVmZXJlbmNlIHByb3BlcnRpZXMgb2YgYHRoaXNgIGJlY2F1c2UgdGhpcyBjYWxsIGlzXG4gICAgICAvLyBhc3luY2hyb25vdXMsIGFuZCB2YWx1ZXMgbWF5IGhhdmUgY2hhbmdlZCBpbiBiZXR3ZWVuIHRoZSBjYWxsIGJlaW5nXG4gICAgICAvLyBpbml0aWF0ZWQgYW5kIGFjdHVhbGx5IGJlaW5nIHJ1bi5cbiAgICAgIHZhciBjaGFydCA9IG5ldyBMaW5lQ2hhcnQoXG4gICAgICAgICAgeENvbXBvbmVudHNDcmVhdGlvbk1ldGhvZCxcbiAgICAgICAgICB0aGlzLnlWYWx1ZUFjY2Vzc29yLFxuICAgICAgICAgIHlTY2FsZVR5cGUsXG4gICAgICAgICAgY29sb3JTY2FsZSxcbiAgICAgICAgICB0b29sdGlwLFxuICAgICAgICAgIHRoaXMudG9vbHRpcENvbHVtbnMsXG4gICAgICAgICAgdGhpcy5maWxsQXJlYSxcbiAgICAgICAgICB0aGlzLmRlZmF1bHRYUmFuZ2UsXG4gICAgICAgICAgdGhpcy5kZWZhdWx0WVJhbmdlLFxuICAgICAgICAgIHRoaXMuc3ltYm9sRnVuY3Rpb24sXG4gICAgICAgICAgdGhpcy54QXhpc0Zvcm1hdHRlcixcbiAgICAgICAgICB0aGlzLnlBeGlzRm9ybWF0dGVyKTtcbiAgICAgIHZhciBkaXYgPSBkMy5zZWxlY3QodGhpcy4kLmNoYXJ0ZGl2KTtcbiAgICAgIGNoYXJ0LnJlbmRlclRvKGRpdik7XG4gICAgICBpZiAodGhpcy5fY2hhcnQpIHRoaXMuX2NoYXJ0LmRlc3Ryb3koKTtcbiAgICAgIHRoaXMuX2NoYXJ0ID0gY2hhcnQ7XG4gICAgfSwgMzUwKTtcbiAgfSxcblxuICBfcmVsb2FkRnJvbUNhY2hlOiBmdW5jdGlvbigpIHtcbiAgICBpZiAodGhpcy5fY2hhcnQpIHtcbiAgICAgIHRoaXMuX2NoYXJ0LnNldFZpc2libGVTZXJpZXModGhpcy5fdmlzaWJsZVNlcmllc0NhY2hlKTtcbiAgICAgIHRoaXMuX3Zpc2libGVTZXJpZXNDYWNoZS5mb3JFYWNoKGZ1bmN0aW9uKG5hbWUpIHtcbiAgICAgICAgdGhpcy5fY2hhcnQuc2V0U2VyaWVzRGF0YShuYW1lLCB0aGlzLl9zZXJpZXNEYXRhQ2FjaGVbbmFtZV0gfHwgW10pO1xuICAgICAgfS5iaW5kKHRoaXMpKTtcbiAgICB9XG4gIH0sXG4gIF9zbW9vdGhpbmdDaGFuZ2VkOiBmdW5jdGlvbigpIHtcbiAgICBpZiAoIXRoaXMuX2NoYXJ0KSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGlmICh0aGlzLnNtb290aGluZ0VuYWJsZWQpIHtcbiAgICAgIHRoaXMuX2NoYXJ0LnNtb290aGluZ1VwZGF0ZSh0aGlzLnNtb290aGluZ1dlaWdodCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMuX2NoYXJ0LnNtb290aGluZ0Rpc2FibGUoKTtcbiAgICB9XG4gIH0sXG4gIF9vdXRsaWVyc0NoYW5nZWQ6IGZ1bmN0aW9uKCkge1xuICAgIGlmICghdGhpcy5fY2hhcnQpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgdGhpcy5fY2hhcnQuaWdub3JlWU91dGxpZXJzKHRoaXMuaWdub3JlWU91dGxpZXJzKTtcbiAgfSxcbiAgX3Rvb2x0aXBTb3J0aW5nTWV0aG9kQ2hhbmdlZDogZnVuY3Rpb24oKSB7XG4gICAgaWYgKHRoaXMuX2NoYXJ0KSB7XG4gICAgICB0aGlzLl9jaGFydC5zZXRUb29sdGlwU29ydGluZ01ldGhvZCh0aGlzLnRvb2x0aXBTb3J0aW5nTWV0aG9kKTtcbiAgICB9XG4gIH0sXG4gIF90b29sdGlwUG9zaXRpb25DaGFuZ2VkOiBmdW5jdGlvbigpIHtcbiAgICBpZiAodGhpcy5fY2hhcnQpIHtcbiAgICAgIHRoaXMuX2NoYXJ0LnNldFRvb2x0aXBQb3NpdGlvbih0aGlzLnRvb2x0aXBQb3NpdGlvbik7XG4gICAgfVxuICB9LFxuICBfY29tcHV0ZVRvb2x0aXBUYWJsZUhlYWRlckh0bWwodG9vbHRpcENvbHVtbnMpIHtcbiAgICAvLyBUaGUgZmlyc3QgY29sdW1uIGNvbnRhaW5zIHRoZSBjaXJjbGUgd2l0aCB0aGUgY29sb3Igb2YgdGhlIHJ1bi5cbiAgICBjb25zdCB0aXRsZXMgPSBbXCJcIiwgLi4uXy5tYXAodG9vbHRpcENvbHVtbnMsICd0aXRsZScpXTtcbiAgICByZXR1cm4gdGl0bGVzLm1hcCh0aXRsZSA9PiBgPHRoPiR7dGhpcy5fc2FuaXRpemUodGl0bGUpfTwvdGg+YCkuam9pbignJyk7XG4gIH0sXG4gIF9zYW5pdGl6ZSh2YWx1ZSkge1xuICAgIHJldHVybiB2YWx1ZS5yZXBsYWNlKC88L2csICcmbHQ7JylcbiAgICAgICAgICAgICAgICAucmVwbGFjZSgvPi9nLCAnJmd0OycpICAvLyBmb3Igc3ltbWV0cnkgOi0pXG4gICAgICAgICAgICAgICAgLnJlcGxhY2UoLyYvZywgJyZhbXA7Jyk7XG4gIH0sXG59KTtcblxuY2xhc3MgTGluZUNoYXJ0IHtcbiAgcHJpdmF0ZSBuYW1lMmRhdGFzZXRzOiB7W25hbWU6IHN0cmluZ106IFBsb3R0YWJsZS5EYXRhc2V0fTtcbiAgcHJpdmF0ZSBzZXJpZXNOYW1lczogc3RyaW5nW107XG5cbiAgcHJpdmF0ZSB4QWNjZXNzb3I6IFBsb3R0YWJsZS5JQWNjZXNzb3I8bnVtYmVyfERhdGU+O1xuICBwcml2YXRlIHhTY2FsZTogUGxvdHRhYmxlLlF1YW50aXRhdGl2ZVNjYWxlPG51bWJlcnxEYXRlPjtcbiAgcHJpdmF0ZSB5U2NhbGU6IFBsb3R0YWJsZS5RdWFudGl0YXRpdmVTY2FsZTxudW1iZXI+O1xuICBwcml2YXRlIGdyaWRsaW5lczogUGxvdHRhYmxlLkNvbXBvbmVudHMuR3JpZGxpbmVzO1xuICBwcml2YXRlIGNlbnRlcjogUGxvdHRhYmxlLkNvbXBvbmVudHMuR3JvdXA7XG4gIHByaXZhdGUgeEF4aXM6IFBsb3R0YWJsZS5BeGVzLk51bWVyaWN8UGxvdHRhYmxlLkF4ZXMuVGltZTtcbiAgcHJpdmF0ZSB5QXhpczogUGxvdHRhYmxlLkF4ZXMuTnVtZXJpYztcbiAgcHJpdmF0ZSBvdXRlcjogUGxvdHRhYmxlLkNvbXBvbmVudHMuVGFibGU7XG4gIHByaXZhdGUgY29sb3JTY2FsZTogUGxvdHRhYmxlLlNjYWxlcy5Db2xvcjtcbiAgcHJpdmF0ZSBzeW1ib2xGdW5jdGlvbjogdnpfY2hhcnRfaGVscGVycy5TeW1ib2xGbjtcblxuICBwcml2YXRlIHRvb2x0aXBDb2x1bW5zOiB2el9jaGFydF9oZWxwZXJzLlRvb2x0aXBDb2x1bW5bXTtcbiAgcHJpdmF0ZSB0b29sdGlwOiBkMy5TZWxlY3Rpb248YW55LCBhbnksIGFueSwgYW55PjtcbiAgcHJpdmF0ZSB0b29sdGlwSW50ZXJhY3Rpb246IFBsb3R0YWJsZS5JbnRlcmFjdGlvbnMuUG9pbnRlcjtcbiAgcHJpdmF0ZSB0b29sdGlwUG9pbnRzQ29tcG9uZW50OiBQbG90dGFibGUuQ29tcG9uZW50O1xuXG4gIHByaXZhdGUgZHpsOiBEcmFnWm9vbUxheWVyO1xuXG4gIHByaXZhdGUgbGluZVBsb3Q6IFBsb3R0YWJsZS5QbG90cy5MaW5lPG51bWJlcnxEYXRlPjtcbiAgcHJpdmF0ZSBzbW9vdGhMaW5lUGxvdDogUGxvdHRhYmxlLlBsb3RzLkxpbmU8bnVtYmVyfERhdGU+O1xuICBwcml2YXRlIG1hcmdpbkFyZWFQbG90PzogUGxvdHRhYmxlLlBsb3RzLkFyZWE8bnVtYmVyfERhdGU+O1xuICBwcml2YXRlIHNjYXR0ZXJQbG90OiBQbG90dGFibGUuUGxvdHMuU2NhdHRlcjxudW1iZXJ8RGF0ZSwgTnVtYmVyPjtcbiAgcHJpdmF0ZSBuYW5EaXNwbGF5OiBQbG90dGFibGUuUGxvdHMuU2NhdHRlcjxudW1iZXJ8RGF0ZSwgTnVtYmVyPjtcbiAgcHJpdmF0ZSBtYXJrZXJzU2NhdHRlclBsb3Q6IFBsb3R0YWJsZS5QbG90cy5TY2F0dGVyPG51bWJlcnxEYXRlLCBudW1iZXI+O1xuXG4gIHByaXZhdGUgeVZhbHVlQWNjZXNzb3I6IFBsb3R0YWJsZS5JQWNjZXNzb3I8bnVtYmVyPjtcbiAgcHJpdmF0ZSBzbW9vdGhlZEFjY2Vzc29yOiBQbG90dGFibGUuSUFjY2Vzc29yPG51bWJlcj47XG4gIHByaXZhdGUgbGFzdFBvaW50c0RhdGFzZXQ6IFBsb3R0YWJsZS5EYXRhc2V0O1xuICBwcml2YXRlIGZpbGxBcmVhPzogRmlsbEFyZWE7XG4gIHByaXZhdGUgZGF0YXNldHM6IFBsb3R0YWJsZS5EYXRhc2V0W107XG4gIHByaXZhdGUgb25EYXRhc2V0Q2hhbmdlZDogKGRhdGFzZXQ6IFBsb3R0YWJsZS5EYXRhc2V0KSA9PiB2b2lkO1xuICBwcml2YXRlIG5hbkRhdGFzZXQ6IFBsb3R0YWJsZS5EYXRhc2V0O1xuICBwcml2YXRlIHNtb290aGluZ1dlaWdodDogbnVtYmVyO1xuICBwcml2YXRlIHNtb290aGluZ0VuYWJsZWQ6IGJvb2xlYW47XG4gIHByaXZhdGUgdG9vbHRpcFNvcnRpbmdNZXRob2Q6IHN0cmluZztcbiAgcHJpdmF0ZSB0b29sdGlwUG9zaXRpb246IHN0cmluZztcbiAgcHJpdmF0ZSBfaWdub3JlWU91dGxpZXJzOiBib29sZWFuO1xuXG4gIC8vIEFuIG9wdGlvbmFsIGxpc3Qgb2YgMiBudW1iZXJzLlxuICBwcml2YXRlIF9kZWZhdWx0WFJhbmdlOiBudW1iZXJbXTtcbiAgLy8gQW4gb3B0aW9uYWwgbGlzdCBvZiAyIG51bWJlcnMuXG4gIHByaXZhdGUgX2RlZmF1bHRZUmFuZ2U6IG51bWJlcltdO1xuXG4gIHByaXZhdGUgdGFyZ2V0U1ZHOiBkMy5TZWxlY3Rpb248YW55LCBhbnksIGFueSwgYW55PjtcblxuICBjb25zdHJ1Y3RvcihcbiAgICAgIHhDb21wb25lbnRzQ3JlYXRpb25NZXRob2Q6ICgpID0+IHZ6X2NoYXJ0X2hlbHBlcnMuWENvbXBvbmVudHMsXG4gICAgICB5VmFsdWVBY2Nlc3NvcjogUGxvdHRhYmxlLklBY2Nlc3NvcjxudW1iZXI+LFxuICAgICAgeVNjYWxlVHlwZTogc3RyaW5nLFxuICAgICAgY29sb3JTY2FsZTogUGxvdHRhYmxlLlNjYWxlcy5Db2xvcixcbiAgICAgIHRvb2x0aXA6IGQzLlNlbGVjdGlvbjxhbnksIGFueSwgYW55LCBhbnk+LFxuICAgICAgdG9vbHRpcENvbHVtbnM6IHZ6X2NoYXJ0X2hlbHBlcnMuVG9vbHRpcENvbHVtbltdLFxuICAgICAgZmlsbEFyZWE6IEZpbGxBcmVhLFxuICAgICAgZGVmYXVsdFhSYW5nZT86IG51bWJlcltdLFxuICAgICAgZGVmYXVsdFlSYW5nZT86IG51bWJlcltdLFxuICAgICAgc3ltYm9sRnVuY3Rpb24/OiB2el9jaGFydF9oZWxwZXJzLlN5bWJvbEZuLFxuICAgICAgeEF4aXNGb3JtYXR0ZXI/OiAobnVtYmVyKSA9PiBzdHJpbmcsXG4gICAgICB5QXhpc0Zvcm1hdHRlcj86IChudW1iZXIpID0+IHN0cmluZykge1xuICAgIHRoaXMuc2VyaWVzTmFtZXMgPSBbXTtcbiAgICB0aGlzLm5hbWUyZGF0YXNldHMgPSB7fTtcbiAgICB0aGlzLmNvbG9yU2NhbGUgPSBjb2xvclNjYWxlO1xuICAgIHRoaXMudG9vbHRpcCA9IHRvb2x0aXA7XG4gICAgdGhpcy5kYXRhc2V0cyA9IFtdO1xuICAgIHRoaXMuX2lnbm9yZVlPdXRsaWVycyA9IGZhbHNlO1xuICAgIC8vIGxhc3RQb2ludERhdGFzZXQgaXMgYSBkYXRhc2V0IHRoYXQgY29udGFpbnMganVzdCB0aGUgbGFzdCBwb2ludCBvZlxuICAgIC8vIGV2ZXJ5IGRhdGFzZXQgd2UncmUgY3VycmVudGx5IGRyYXdpbmcuXG4gICAgdGhpcy5sYXN0UG9pbnRzRGF0YXNldCA9IG5ldyBQbG90dGFibGUuRGF0YXNldCgpO1xuICAgIHRoaXMubmFuRGF0YXNldCA9IG5ldyBQbG90dGFibGUuRGF0YXNldCgpO1xuICAgIHRoaXMueVZhbHVlQWNjZXNzb3IgPSB5VmFsdWVBY2Nlc3NvcjtcblxuICAgIC8vIFRoZSBzeW1ib2wgZnVuY3Rpb24gbWFwcyBzZXJpZXMgdG8gbWFya2VyLiBJdCB1c2VzIGEgc3BlY2lhbCBkYXRhc2V0IHRoYXRcbiAgICAvLyB2YXJpZXMgYmFzZWQgb24gd2hldGhlciBzbW9vdGhpbmcgaXMgZW5hYmxlZC5cbiAgICB0aGlzLnN5bWJvbEZ1bmN0aW9uID0gc3ltYm9sRnVuY3Rpb247XG5cbiAgICAvLyBuZWVkIHRvIGRvIGEgc2luZ2xlIGJpbmQsIHNvIHdlIGNhbiBkZXJlZ2lzdGVyIHRoZSBjYWxsYmFjayBmcm9tXG4gICAgLy8gb2xkIFBsb3R0YWJsZS5EYXRhc2V0cy4gKERlcmVnaXN0cmF0aW9uIGlzIGRvbmUgYnkgaWRlbnRpdHkgY2hlY2tzLilcbiAgICB0aGlzLm9uRGF0YXNldENoYW5nZWQgPSB0aGlzLl9vbkRhdGFzZXRDaGFuZ2VkLmJpbmQodGhpcyk7XG5cbiAgICB0aGlzLl9kZWZhdWx0WFJhbmdlID0gZGVmYXVsdFhSYW5nZTtcbiAgICB0aGlzLl9kZWZhdWx0WVJhbmdlID0gZGVmYXVsdFlSYW5nZTtcbiAgICB0aGlzLnRvb2x0aXBDb2x1bW5zID0gdG9vbHRpcENvbHVtbnM7XG5cbiAgICB0aGlzLmJ1aWxkQ2hhcnQoXG4gICAgICAgIHhDb21wb25lbnRzQ3JlYXRpb25NZXRob2QsXG4gICAgICAgIHlWYWx1ZUFjY2Vzc29yLFxuICAgICAgICB5U2NhbGVUeXBlLFxuICAgICAgICBmaWxsQXJlYSxcbiAgICAgICAgeEF4aXNGb3JtYXR0ZXIsXG4gICAgICAgIHlBeGlzRm9ybWF0dGVyKTtcbiAgfVxuXG4gIHByaXZhdGUgYnVpbGRDaGFydChcbiAgICAgIHhDb21wb25lbnRzQ3JlYXRpb25NZXRob2Q6ICgpID0+IHZ6X2NoYXJ0X2hlbHBlcnMuWENvbXBvbmVudHMsXG4gICAgICB5VmFsdWVBY2Nlc3NvcjogUGxvdHRhYmxlLklBY2Nlc3NvcjxudW1iZXI+LFxuICAgICAgeVNjYWxlVHlwZTogc3RyaW5nLFxuICAgICAgZmlsbEFyZWE6IEZpbGxBcmVhLFxuICAgICAgeEF4aXNGb3JtYXR0ZXI6IChudW1iZXIpID0+IHN0cmluZyxcbiAgICAgIHlBeGlzRm9ybWF0dGVyOiAobnVtYmVyKSA9PiBzdHJpbmcpIHtcbiAgICBpZiAodGhpcy5vdXRlcikge1xuICAgICAgdGhpcy5vdXRlci5kZXN0cm95KCk7XG4gICAgfVxuICAgIGNvbnN0IHhDb21wb25lbnRzID0geENvbXBvbmVudHNDcmVhdGlvbk1ldGhvZCgpO1xuICAgIHRoaXMueEFjY2Vzc29yID0geENvbXBvbmVudHMuYWNjZXNzb3I7XG4gICAgdGhpcy54U2NhbGUgPSB4Q29tcG9uZW50cy5zY2FsZTtcbiAgICB0aGlzLnhBeGlzID0geENvbXBvbmVudHMuYXhpcztcbiAgICB0aGlzLnhBeGlzLm1hcmdpbigwKS50aWNrTGFiZWxQYWRkaW5nKDMpO1xuICAgIGlmICh4QXhpc0Zvcm1hdHRlcikge1xuICAgICAgdGhpcy54QXhpcy5mb3JtYXR0ZXIoeEF4aXNGb3JtYXR0ZXIpO1xuICAgIH1cbiAgICB0aGlzLnlTY2FsZSA9IExpbmVDaGFydC5nZXRZU2NhbGVGcm9tVHlwZSh5U2NhbGVUeXBlKTtcbiAgICB0aGlzLnlBeGlzID0gbmV3IFBsb3R0YWJsZS5BeGVzLk51bWVyaWModGhpcy55U2NhbGUsICdsZWZ0Jyk7XG4gICAgdGhpcy55QXhpcy5tYXJnaW4oMCkudGlja0xhYmVsUGFkZGluZyg1KTtcbiAgICB0aGlzLnlBeGlzLmZvcm1hdHRlcih5QXhpc0Zvcm1hdHRlciA/IHlBeGlzRm9ybWF0dGVyXG4gICAgICA6IHZ6X2NoYXJ0X2hlbHBlcnMubXVsdGlzY2FsZUZvcm1hdHRlcihcbiAgICAgICAgICB2el9jaGFydF9oZWxwZXJzLllfQVhJU19GT1JNQVRURVJfUFJFQ0lTSU9OKSk7XG4gICAgdGhpcy55QXhpcy51c2VzVGV4dFdpZHRoQXBwcm94aW1hdGlvbih0cnVlKTtcbiAgICB0aGlzLmZpbGxBcmVhID0gZmlsbEFyZWE7XG5cbiAgICB0aGlzLmR6bCA9IG5ldyBEcmFnWm9vbUxheWVyKFxuICAgICAgICB0aGlzLnhTY2FsZSwgdGhpcy55U2NhbGUsIHRoaXMucmVzZXRZRG9tYWluLmJpbmQodGhpcykpO1xuXG4gICAgdGhpcy50b29sdGlwSW50ZXJhY3Rpb24gPSB0aGlzLmNyZWF0ZVRvb2x0aXBJbnRlcmFjdGlvbih0aGlzLmR6bCk7XG4gICAgdGhpcy50b29sdGlwUG9pbnRzQ29tcG9uZW50ID0gbmV3IFBsb3R0YWJsZS5Db21wb25lbnQoKTtcblxuICAgIGNvbnN0IHBsb3QgPSB0aGlzLmJ1aWxkUGxvdChcbiAgICAgICAgdGhpcy54U2NhbGUsXG4gICAgICAgIHRoaXMueVNjYWxlLFxuICAgICAgICBmaWxsQXJlYSk7XG5cbiAgICB0aGlzLmdyaWRsaW5lcyA9XG4gICAgICAgIG5ldyBQbG90dGFibGUuQ29tcG9uZW50cy5HcmlkbGluZXModGhpcy54U2NhbGUsIHRoaXMueVNjYWxlKTtcblxuICAgIGxldCB4WmVyb0xpbmUgPSBuZXcgUGxvdHRhYmxlLkNvbXBvbmVudHMuR3VpZGVMaW5lTGF5ZXIoJ2hvcml6b250YWwnKTtcbiAgICB4WmVyb0xpbmUuc2NhbGUodGhpcy55U2NhbGUpLnZhbHVlKDApO1xuICAgIGxldCB5WmVyb0xpbmUgPSBuZXcgUGxvdHRhYmxlLkNvbXBvbmVudHMuR3VpZGVMaW5lTGF5ZXIoJ3ZlcnRpY2FsJyk7XG4gICAgeVplcm9MaW5lLnNjYWxlKHRoaXMueFNjYWxlKS52YWx1ZSgwKTtcblxuICAgIHRoaXMuY2VudGVyID0gbmV3IFBsb3R0YWJsZS5Db21wb25lbnRzLkdyb3VwKFtcbiAgICAgICAgdGhpcy5ncmlkbGluZXMsIHhaZXJvTGluZSwgeVplcm9MaW5lLCBwbG90LFxuICAgICAgICB0aGlzLmR6bCwgdGhpcy50b29sdGlwUG9pbnRzQ29tcG9uZW50XSk7XG4gICAgdGhpcy5vdXRlciA9IG5ldyBQbG90dGFibGUuQ29tcG9uZW50cy5UYWJsZShcbiAgICAgICAgW1t0aGlzLnlBeGlzLCB0aGlzLmNlbnRlcl0sIFtudWxsLCB0aGlzLnhBeGlzXV0pO1xuICB9XG5cbiAgcHJpdmF0ZSBidWlsZFBsb3QoeFNjYWxlLCB5U2NhbGUsIGZpbGxBcmVhKTpcbiAgICAgIFBsb3R0YWJsZS5Db21wb25lbnQge1xuICAgIGlmIChmaWxsQXJlYSkge1xuICAgICAgdGhpcy5tYXJnaW5BcmVhUGxvdCA9IG5ldyBQbG90dGFibGUuUGxvdHMuQXJlYTxudW1iZXJ8RGF0ZT4oKTtcbiAgICAgIHRoaXMubWFyZ2luQXJlYVBsb3QueCh0aGlzLnhBY2Nlc3NvciwgeFNjYWxlKTtcbiAgICAgIHRoaXMubWFyZ2luQXJlYVBsb3QueShmaWxsQXJlYS5oaWdoZXJBY2Nlc3NvciwgeVNjYWxlKTtcbiAgICAgIHRoaXMubWFyZ2luQXJlYVBsb3QueTAoZmlsbEFyZWEubG93ZXJBY2Nlc3Nvcik7XG4gICAgICB0aGlzLm1hcmdpbkFyZWFQbG90LmF0dHIoXG4gICAgICAgICAgJ2ZpbGwnLFxuICAgICAgICAgIChkOiB2el9jaGFydF9oZWxwZXJzLkRhdHVtLCBpOiBudW1iZXIsIGRhdGFzZXQ6IFBsb3R0YWJsZS5EYXRhc2V0KSA9PlxuICAgICAgICAgICAgICB0aGlzLmNvbG9yU2NhbGUuc2NhbGUoZGF0YXNldC5tZXRhZGF0YSgpLm5hbWUpKTtcbiAgICAgIHRoaXMubWFyZ2luQXJlYVBsb3QuYXR0cignZmlsbC1vcGFjaXR5JywgMC4zKTtcbiAgICAgIHRoaXMubWFyZ2luQXJlYVBsb3QuYXR0cignc3Ryb2tlLXdpZHRoJywgMCk7XG4gICAgfVxuXG4gICAgdGhpcy5zbW9vdGhlZEFjY2Vzc29yID0gKGQ6ICB2el9jaGFydF9oZWxwZXJzLlNjYWxhckRhdHVtKSA9PiBkLnNtb290aGVkO1xuICAgIGxldCBsaW5lUGxvdCA9IG5ldyBQbG90dGFibGUuUGxvdHMuTGluZTxudW1iZXJ8RGF0ZT4oKTtcbiAgICBsaW5lUGxvdC54KHRoaXMueEFjY2Vzc29yLCB4U2NhbGUpO1xuICAgIGxpbmVQbG90LnkodGhpcy55VmFsdWVBY2Nlc3NvciwgeVNjYWxlKTtcbiAgICBsaW5lUGxvdC5hdHRyKFxuICAgICAgICAnc3Ryb2tlJyxcbiAgICAgICAgKGQ6IHZ6X2NoYXJ0X2hlbHBlcnMuRGF0dW0sIGk6IG51bWJlciwgZGF0YXNldDogUGxvdHRhYmxlLkRhdGFzZXQpID0+XG4gICAgICAgICAgICB0aGlzLmNvbG9yU2NhbGUuc2NhbGUoZGF0YXNldC5tZXRhZGF0YSgpLm5hbWUpKTtcbiAgICB0aGlzLmxpbmVQbG90ID0gbGluZVBsb3Q7XG4gICAgdGhpcy5zZXR1cFRvb2x0aXBzKGxpbmVQbG90KTtcblxuICAgIGxldCBzbW9vdGhMaW5lUGxvdCA9IG5ldyBQbG90dGFibGUuUGxvdHMuTGluZTxudW1iZXJ8RGF0ZT4oKTtcbiAgICBzbW9vdGhMaW5lUGxvdC54KHRoaXMueEFjY2Vzc29yLCB4U2NhbGUpO1xuICAgIHNtb290aExpbmVQbG90LnkodGhpcy5zbW9vdGhlZEFjY2Vzc29yLCB5U2NhbGUpO1xuICAgIHNtb290aExpbmVQbG90LmF0dHIoXG4gICAgICAgICdzdHJva2UnLFxuICAgICAgICAoZDogdnpfY2hhcnRfaGVscGVycy5EYXR1bSwgaTogbnVtYmVyLCBkYXRhc2V0OiBQbG90dGFibGUuRGF0YXNldCkgPT5cbiAgICAgICAgICAgIHRoaXMuY29sb3JTY2FsZS5zY2FsZShkYXRhc2V0Lm1ldGFkYXRhKCkubmFtZSkpO1xuICAgIHRoaXMuc21vb3RoTGluZVBsb3QgPSBzbW9vdGhMaW5lUGxvdDtcblxuICAgIGlmICh0aGlzLnN5bWJvbEZ1bmN0aW9uKSB7XG4gICAgICBjb25zdCBtYXJrZXJzU2NhdHRlclBsb3QgPSBuZXcgUGxvdHRhYmxlLlBsb3RzLlNjYXR0ZXI8bnVtYmVyfERhdGUsIG51bWJlcj4oKTtcbiAgICAgIG1hcmtlcnNTY2F0dGVyUGxvdC54KHRoaXMueEFjY2Vzc29yLCB4U2NhbGUpO1xuICAgICAgbWFya2Vyc1NjYXR0ZXJQbG90LnkodGhpcy55VmFsdWVBY2Nlc3NvciwgeVNjYWxlKTtcbiAgICAgIG1hcmtlcnNTY2F0dGVyUGxvdC5hdHRyKFxuICAgICAgICAgICdmaWxsJyxcbiAgICAgICAgICAoZDogdnpfY2hhcnRfaGVscGVycy5EYXR1bSwgaTogbnVtYmVyLCBkYXRhc2V0OiBQbG90dGFibGUuRGF0YXNldCkgPT5cbiAgICAgICAgICAgICAgdGhpcy5jb2xvclNjYWxlLnNjYWxlKGRhdGFzZXQubWV0YWRhdGEoKS5uYW1lKSk7XG4gICAgICBtYXJrZXJzU2NhdHRlclBsb3QuYXR0cignb3BhY2l0eScsIDEpO1xuICAgICAgbWFya2Vyc1NjYXR0ZXJQbG90LnNpemUodnpfY2hhcnRfaGVscGVycy5UT09MVElQX0NJUkNMRV9TSVpFICogMik7XG4gICAgICBtYXJrZXJzU2NhdHRlclBsb3Quc3ltYm9sKFxuICAgICAgICAgIChkOiB2el9jaGFydF9oZWxwZXJzLkRhdHVtLCBpOiBudW1iZXIsIGRhdGFzZXQ6IFBsb3R0YWJsZS5EYXRhc2V0KSA9PiB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5zeW1ib2xGdW5jdGlvbihkYXRhc2V0Lm1ldGFkYXRhKCkubmFtZSk7XG4gICAgICAgICAgfSk7XG4gICAgICAvLyBVc2UgYSBzcGVjaWFsIGRhdGFzZXQgYmVjYXVzZSB0aGlzIHNjYXR0ZXIgcGxvdCBzaG91bGQgdXNlIHRoZSBhY2Nlc29yXG4gICAgICAvLyB0aGF0IGRlcGVuZHMgb24gd2hldGhlciBzbW9vdGhpbmcgaXMgZW5hYmxlZC5cbiAgICAgIHRoaXMubWFya2Vyc1NjYXR0ZXJQbG90ID0gbWFya2Vyc1NjYXR0ZXJQbG90O1xuICAgIH1cblxuICAgIC8vIFRoZSBzY2F0dGVyUGxvdCB3aWxsIGRpc3BsYXkgdGhlIGxhc3QgcG9pbnQgZm9yIGVhY2ggZGF0YXNldC5cbiAgICAvLyBUaGlzIHdheSwgaWYgdGhlcmUgaXMgb25seSBvbmUgZGF0dW0gZm9yIHRoZSBzZXJpZXMsIGl0IGlzIHN0aWxsXG4gICAgLy8gdmlzaWJsZS4gV2UgaGlkZSBpdCB3aGVuIHRvb2x0aXBzIGFyZSBhY3RpdmUgdG8ga2VlcCB0aGluZ3MgY2xlYW4uXG4gICAgbGV0IHNjYXR0ZXJQbG90ID0gbmV3IFBsb3R0YWJsZS5QbG90cy5TY2F0dGVyPG51bWJlcnxEYXRlLCBudW1iZXI+KCk7XG4gICAgc2NhdHRlclBsb3QueCh0aGlzLnhBY2Nlc3NvciwgeFNjYWxlKTtcbiAgICBzY2F0dGVyUGxvdC55KHRoaXMueVZhbHVlQWNjZXNzb3IsIHlTY2FsZSk7XG4gICAgc2NhdHRlclBsb3QuYXR0cignZmlsbCcsIChkOiBhbnkpID0+IHRoaXMuY29sb3JTY2FsZS5zY2FsZShkLm5hbWUpKTtcbiAgICBzY2F0dGVyUGxvdC5hdHRyKCdvcGFjaXR5JywgMSk7XG4gICAgc2NhdHRlclBsb3Quc2l6ZSh2el9jaGFydF9oZWxwZXJzLlRPT0xUSVBfQ0lSQ0xFX1NJWkUgKiAyKTtcbiAgICBzY2F0dGVyUGxvdC5kYXRhc2V0cyhbdGhpcy5sYXN0UG9pbnRzRGF0YXNldF0pO1xuICAgIHRoaXMuc2NhdHRlclBsb3QgPSBzY2F0dGVyUGxvdDtcblxuICAgIGxldCBuYW5EaXNwbGF5ID0gbmV3IFBsb3R0YWJsZS5QbG90cy5TY2F0dGVyPG51bWJlcnxEYXRlLCBudW1iZXI+KCk7XG4gICAgbmFuRGlzcGxheS54KHRoaXMueEFjY2Vzc29yLCB4U2NhbGUpO1xuICAgIG5hbkRpc3BsYXkueSgoeCkgPT4geC5kaXNwbGF5WSwgeVNjYWxlKTtcbiAgICBuYW5EaXNwbGF5LmF0dHIoJ2ZpbGwnLCAoZDogYW55KSA9PiB0aGlzLmNvbG9yU2NhbGUuc2NhbGUoZC5uYW1lKSk7XG4gICAgbmFuRGlzcGxheS5hdHRyKCdvcGFjaXR5JywgMSk7XG4gICAgbmFuRGlzcGxheS5zaXplKHZ6X2NoYXJ0X2hlbHBlcnMuTkFOX1NZTUJPTF9TSVpFICogMik7XG4gICAgbmFuRGlzcGxheS5kYXRhc2V0cyhbdGhpcy5uYW5EYXRhc2V0XSk7XG4gICAgbmFuRGlzcGxheS5zeW1ib2woUGxvdHRhYmxlLlN5bWJvbEZhY3Rvcmllcy50cmlhbmdsZSk7XG4gICAgdGhpcy5uYW5EaXNwbGF5ID0gbmFuRGlzcGxheTtcblxuICAgIGNvbnN0IGdyb3VwcyA9IFtuYW5EaXNwbGF5LCBzY2F0dGVyUGxvdCwgc21vb3RoTGluZVBsb3QsIGxpbmVQbG90XTtcbiAgICBpZiAodGhpcy5tYXJnaW5BcmVhUGxvdCkge1xuICAgICAgZ3JvdXBzLnB1c2godGhpcy5tYXJnaW5BcmVhUGxvdCk7XG4gICAgfVxuICAgIGlmICh0aGlzLm1hcmtlcnNTY2F0dGVyUGxvdCkge1xuICAgICAgZ3JvdXBzLnB1c2godGhpcy5tYXJrZXJzU2NhdHRlclBsb3QpO1xuICAgIH1cbiAgICByZXR1cm4gbmV3IFBsb3R0YWJsZS5Db21wb25lbnRzLkdyb3VwKGdyb3Vwcyk7XG4gIH1cblxuICAvKiogVXBkYXRlcyB0aGUgY2hhcnQgd2hlbiBhIGRhdGFzZXQgY2hhbmdlcy4gQ2FsbGVkIGV2ZXJ5IHRpbWUgdGhlIGRhdGEgb2ZcbiAgICogYSBkYXRhc2V0IGNoYW5nZXMgdG8gdXBkYXRlIHRoZSBjaGFydHMuXG4gICAqL1xuICBwcml2YXRlIF9vbkRhdGFzZXRDaGFuZ2VkKGRhdGFzZXQ6IFBsb3R0YWJsZS5EYXRhc2V0KSB7XG4gICAgaWYgKHRoaXMuc21vb3RoaW5nRW5hYmxlZCkge1xuICAgICAgdGhpcy5yZXNtb290aERhdGFzZXQoZGF0YXNldCk7XG4gICAgfVxuICAgIHRoaXMudXBkYXRlU3BlY2lhbERhdGFzZXRzKCk7XG4gIH1cblxuICBwdWJsaWMgaWdub3JlWU91dGxpZXJzKGlnbm9yZVlPdXRsaWVyczogYm9vbGVhbikge1xuICAgIGlmIChpZ25vcmVZT3V0bGllcnMgIT09IHRoaXMuX2lnbm9yZVlPdXRsaWVycykge1xuICAgICAgdGhpcy5faWdub3JlWU91dGxpZXJzID0gaWdub3JlWU91dGxpZXJzO1xuICAgICAgdGhpcy51cGRhdGVTcGVjaWFsRGF0YXNldHMoKTtcbiAgICAgIHRoaXMucmVzZXRZRG9tYWluKCk7XG4gICAgfVxuICB9XG5cbiAgLyoqIENvbnN0cnVjdHMgc3BlY2lhbCBkYXRhc2V0cy4gRWFjaCBzcGVjaWFsIGRhdGFzZXQgY29udGFpbnMgZXhjZXB0aW9uYWxcbiAgICogdmFsdWVzIGZyb20gYWxsIG9mIHRoZSByZWd1bGFyIGRhdGFzZXRzLCBlLmcuIGxhc3QgcG9pbnRzIGluIHNlcmllcywgb3JcbiAgICogTmFOIHZhbHVlcy4gVGhvc2UgcG9pbnRzIHdpbGwgaGF2ZSBhIGBuYW1lYCBhbmQgYHJlbGF0aXZlYCBwcm9wZXJ0eSBhZGRlZFxuICAgKiAoc2luY2UgdXN1YWxseSB0aG9zZSBhcmUgY29udGV4dCBpbiB0aGUgc3Vycm91bmRpbmcgZGF0YXNldCkuXG4gICAqL1xuICBwcml2YXRlIHVwZGF0ZVNwZWNpYWxEYXRhc2V0cygpIHtcbiAgICBjb25zdCBhY2Nlc3NvciA9IHRoaXMuZ2V0WUF4aXNBY2Nlc3NvcigpO1xuXG4gICAgbGV0IGxhc3RQb2ludHNEYXRhID1cbiAgICAgICAgdGhpcy5kYXRhc2V0c1xuICAgICAgICAgICAgLm1hcCgoZCkgPT4ge1xuICAgICAgICAgICAgICBsZXQgZGF0dW0gPSBudWxsO1xuICAgICAgICAgICAgICAvLyBmaWx0ZXIgb3V0IE5hTnMgdG8gZW5zdXJlIGxhc3QgcG9pbnQgaXMgYSBjbGVhbiBvbmVcbiAgICAgICAgICAgICAgbGV0IG5vbk5hbkRhdGEgPVxuICAgICAgICAgICAgICAgICAgZC5kYXRhKCkuZmlsdGVyKCh4KSA9PiAhaXNOYU4oYWNjZXNzb3IoeCwgLTEsIGQpKSk7XG4gICAgICAgICAgICAgIGlmIChub25OYW5EYXRhLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgICAgICBsZXQgaWR4ID0gbm9uTmFuRGF0YS5sZW5ndGggLSAxO1xuICAgICAgICAgICAgICAgIGRhdHVtID0gbm9uTmFuRGF0YVtpZHhdO1xuICAgICAgICAgICAgICAgIGRhdHVtLm5hbWUgPSBkLm1ldGFkYXRhKCkubmFtZTtcbiAgICAgICAgICAgICAgICBkYXR1bS5yZWxhdGl2ZSA9IHZ6X2NoYXJ0X2hlbHBlcnMucmVsYXRpdmVBY2Nlc3NvcihkYXR1bSwgLTEsIGQpO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIHJldHVybiBkYXR1bTtcbiAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAuZmlsdGVyKCh4KSA9PiB4ICE9IG51bGwpO1xuICAgIHRoaXMubGFzdFBvaW50c0RhdGFzZXQuZGF0YShsYXN0UG9pbnRzRGF0YSk7XG5cbiAgICBpZiAodGhpcy5tYXJrZXJzU2NhdHRlclBsb3QpIHtcbiAgICAgIHRoaXMubWFya2Vyc1NjYXR0ZXJQbG90LmRhdGFzZXRzKFxuICAgICAgICAgIHRoaXMuZGF0YXNldHMubWFwKHRoaXMuY3JlYXRlU2FtcGxlZERhdGFzZXRGb3JNYXJrZXJzKSk7XG4gICAgfVxuXG4gICAgLy8gVGFrZSBhIGRhdGFzZXQsIHJldHVybiBhbiBhcnJheSBvZiBOYU4gZGF0YSBwb2ludHNcbiAgICAvLyB0aGUgTmFOIHBvaW50cyB3aWxsIGhhdmUgYSBcImRpc3BsYXlZXCIgcHJvcGVydHkgd2hpY2ggaXMgdGhlXG4gICAgLy8geS12YWx1ZSBvZiBhIG5lYXJieSBwb2ludCB0aGF0IHdhcyBub3QgTmFOICgwIGlmIGFsbCBwb2ludHMgYXJlIE5hTilcbiAgICBsZXQgZGF0YXNldFRvTmFORGF0YSA9IChkOiBQbG90dGFibGUuRGF0YXNldCkgPT4ge1xuICAgICAgbGV0IGRpc3BsYXlZID0gbnVsbDtcbiAgICAgIGxldCBkYXRhID0gZC5kYXRhKCk7XG4gICAgICBsZXQgaSA9IDA7XG4gICAgICB3aGlsZSAoaSA8IGRhdGEubGVuZ3RoICYmIGRpc3BsYXlZID09IG51bGwpIHtcbiAgICAgICAgaWYgKCFpc05hTihhY2Nlc3NvcihkYXRhW2ldLCAtMSwgZCkpKSB7XG4gICAgICAgICAgZGlzcGxheVkgPSBhY2Nlc3NvcihkYXRhW2ldLCAtMSwgZCk7XG4gICAgICAgIH1cbiAgICAgICAgaSsrO1xuICAgICAgfVxuICAgICAgaWYgKGRpc3BsYXlZID09IG51bGwpIHtcbiAgICAgICAgZGlzcGxheVkgPSAwO1xuICAgICAgfVxuICAgICAgbGV0IG5hbkRhdGEgPSBbXTtcbiAgICAgIGZvciAoaSA9IDA7IGkgPCBkYXRhLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIGlmICghaXNOYU4oYWNjZXNzb3IoZGF0YVtpXSwgLTEsIGQpKSkge1xuICAgICAgICAgIGRpc3BsYXlZID0gYWNjZXNzb3IoZGF0YVtpXSwgLTEsIGQpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGRhdGFbaV0ubmFtZSA9IGQubWV0YWRhdGEoKS5uYW1lO1xuICAgICAgICAgIGRhdGFbaV0uZGlzcGxheVkgPSBkaXNwbGF5WTtcbiAgICAgICAgICBkYXRhW2ldLnJlbGF0aXZlID0gdnpfY2hhcnRfaGVscGVycy5yZWxhdGl2ZUFjY2Vzc29yKGRhdGFbaV0sIC0xLCBkKTtcbiAgICAgICAgICBuYW5EYXRhLnB1c2goZGF0YVtpXSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJldHVybiBuYW5EYXRhO1xuICAgIH07XG4gICAgbGV0IG5hbkRhdGEgPSBfLmZsYXR0ZW4odGhpcy5kYXRhc2V0cy5tYXAoZGF0YXNldFRvTmFORGF0YSkpO1xuICAgIHRoaXMubmFuRGF0YXNldC5kYXRhKG5hbkRhdGEpO1xuICB9XG5cbiAgcHVibGljIHJlc2V0RG9tYWluKCkge1xuICAgIHRoaXMucmVzZXRYRG9tYWluKCk7XG4gICAgdGhpcy5yZXNldFlEb21haW4oKTtcbiAgfVxuXG4gIHByaXZhdGUgcmVzZXRYRG9tYWluKCkge1xuICAgIGxldCB4RG9tYWluO1xuICAgIGlmICh0aGlzLl9kZWZhdWx0WFJhbmdlICE9IG51bGwpIHtcbiAgICAgIC8vIFVzZSB0aGUgcmFuZ2Ugc3BlY2lmaWVkIGJ5IHRoZSBjYWxsZXIuXG4gICAgICB4RG9tYWluID0gdGhpcy5fZGVmYXVsdFhSYW5nZTtcbiAgICB9IGVsc2Uge1xuICAgICAgLy8gKENvcGllZCBmcm9tIERyYWdab29tTGF5ZXIudW56b29tLilcbiAgICAgIGNvbnN0IHhTY2FsZSA9IHRoaXMueFNjYWxlIGFzIGFueTtcbiAgICAgIHhTY2FsZS5fZG9tYWluTWluID0gbnVsbDtcbiAgICAgIHhTY2FsZS5fZG9tYWluTWF4ID0gbnVsbDtcbiAgICAgIHhEb21haW4gPSB4U2NhbGUuX2dldEV4dGVudCgpO1xuICAgIH1cbiAgICB0aGlzLnhTY2FsZS5kb21haW4oeERvbWFpbik7XG4gIH1cblxuICBwcml2YXRlIHJlc2V0WURvbWFpbigpIHtcbiAgICBsZXQgeURvbWFpbjtcbiAgICBpZiAodGhpcy5fZGVmYXVsdFlSYW5nZSAhPSBudWxsKSB7XG4gICAgICAvLyBVc2UgdGhlIHJhbmdlIHNwZWNpZmllZCBieSB0aGUgY2FsbGVyLlxuICAgICAgeURvbWFpbiA9IHRoaXMuX2RlZmF1bHRZUmFuZ2U7XG4gICAgfSBlbHNlIHtcbiAgICAgIC8vIEdlbmVyYXRlIGEgcmVhc29uYWJsZSByYW5nZS5cbiAgICAgIGNvbnN0IGFjY2Vzc29ycyA9IHRoaXMuZ2V0QWNjZXNzb3JzRm9yQ29tcHV0aW5nWVJhbmdlKCk7XG4gICAgICBsZXQgZGF0YXNldFRvVmFsdWVzOiAoZDogUGxvdHRhYmxlLkRhdGFzZXQpID0+IG51bWJlcltdW10gPSAoZCkgPT4ge1xuICAgICAgICByZXR1cm4gYWNjZXNzb3JzLm1hcChhY2Nlc3NvciA9PiBkLmRhdGEoKS5tYXAoeCA9PiBhY2Nlc3Nvcih4LCAtMSwgZCkpKTtcbiAgICAgIH07XG4gICAgICBjb25zdCB2YWxzID0gXy5mbGF0dGVuRGVlcDxudW1iZXI+KHRoaXMuZGF0YXNldHMubWFwKGRhdGFzZXRUb1ZhbHVlcykpXG4gICAgICAgICAgLmZpbHRlcihpc0Zpbml0ZSk7XG4gICAgICB5RG9tYWluID0gdnpfY2hhcnRfaGVscGVycy5jb21wdXRlRG9tYWluKHZhbHMsIHRoaXMuX2lnbm9yZVlPdXRsaWVycyk7XG4gICAgfVxuICAgIHRoaXMueVNjYWxlLmRvbWFpbih5RG9tYWluKTtcbiAgfVxuXG4gIHByaXZhdGUgZ2V0QWNjZXNzb3JzRm9yQ29tcHV0aW5nWVJhbmdlKCk6IFBsb3R0YWJsZS5JQWNjZXNzb3I8bnVtYmVyPltdIHtcbiAgICBjb25zdCBhY2Nlc3NvcnMgPSBbdGhpcy5nZXRZQXhpc0FjY2Vzc29yKCldO1xuICAgIGlmICh0aGlzLmZpbGxBcmVhKSB7XG4gICAgICAvLyBNYWtlIHRoZSBZIGRvbWFpbiB0YWtlIG1hcmdpbnMgaW50byBhY2NvdW50LlxuICAgICAgYWNjZXNzb3JzLnB1c2goXG4gICAgICAgICAgdGhpcy5maWxsQXJlYS5sb3dlckFjY2Vzc29yLFxuICAgICAgICAgIHRoaXMuZmlsbEFyZWEuaGlnaGVyQWNjZXNzb3IpO1xuICAgIH1cbiAgICByZXR1cm4gYWNjZXNzb3JzO1xuICB9XG5cbiAgcHJpdmF0ZSBnZXRZQXhpc0FjY2Vzc29yKCkge1xuICAgIHJldHVybiB0aGlzLnNtb290aGluZ0VuYWJsZWQgPyB0aGlzLnNtb290aGVkQWNjZXNzb3IgOiB0aGlzLnlWYWx1ZUFjY2Vzc29yO1xuICB9XG5cbiAgcHJpdmF0ZSBjcmVhdGVUb29sdGlwSW50ZXJhY3Rpb24oZHpsOiBEcmFnWm9vbUxheWVyKTpcbiAgICAgIFBsb3R0YWJsZS5JbnRlcmFjdGlvbnMuUG9pbnRlciB7XG4gICAgY29uc3QgcGkgPSBuZXcgUGxvdHRhYmxlLkludGVyYWN0aW9ucy5Qb2ludGVyKCk7XG4gICAgLy8gRGlzYWJsZSBpbnRlcmFjdGlvbiB3aGlsZSBkcmFnIHpvb21pbmcuXG4gICAgZHpsLmludGVyYWN0aW9uU3RhcnQoKCkgPT4ge1xuICAgICAgcGkuZW5hYmxlZChmYWxzZSk7XG4gICAgICB0aGlzLmhpZGVUb29sdGlwcygpO1xuICAgIH0pO1xuICAgIGR6bC5pbnRlcmFjdGlvbkVuZCgoKSA9PiBwaS5lbmFibGVkKHRydWUpKTtcblxuICAgIHBpLm9uUG9pbnRlck1vdmUoKHA6IFBsb3R0YWJsZS5Qb2ludCkgPT4ge1xuICAgICAgLy8gTGluZSBwbG90IG11c3QgYmUgaW5pdGlhbGl6ZWQgdG8gZHJhdy5cbiAgICAgIGlmICghdGhpcy5saW5lUGxvdCkgcmV0dXJuO1xuICAgICAgbGV0IHRhcmdldDogdnpfY2hhcnRfaGVscGVycy5Qb2ludCA9IHtcbiAgICAgICAgeDogcC54LFxuICAgICAgICB5OiBwLnksXG4gICAgICAgIGRhdHVtOiBudWxsLFxuICAgICAgICBkYXRhc2V0OiBudWxsLFxuICAgICAgfTtcbiAgICAgIGxldCBiYm94OiBTVkdSZWN0ID0gKDxhbnk+dGhpcy5ncmlkbGluZXMuY29udGVudCgpLm5vZGUoKSkuZ2V0QkJveCgpO1xuICAgICAgLy8gcHRzIGlzIHRoZSBjbG9zZXRzIHBvaW50IHRvIHRoZSB0b29sdGlwIGZvciBlYWNoIGRhdGFzZXRcbiAgICAgIGxldCBwdHMgPSB0aGlzLmxpbmVQbG90LmRhdGFzZXRzKClcbiAgICAgICAgICAgICAgICAgICAgLm1hcCgoZGF0YXNldCkgPT4gdGhpcy5maW5kQ2xvc2VzdFBvaW50KHRhcmdldCwgZGF0YXNldCkpXG4gICAgICAgICAgICAgICAgICAgIC5maWx0ZXIoQm9vbGVhbik7XG4gICAgICBsZXQgaW50ZXJzZWN0c0JCb3ggPSBQbG90dGFibGUuVXRpbHMuRE9NLmludGVyc2VjdHNCQm94O1xuICAgICAgLy8gV2UgZHJhdyB0b29sdGlwcyBmb3IgcG9pbnRzIHRoYXQgYXJlIE5hTiwgb3IgYXJlIGN1cnJlbnRseSB2aXNpYmxlXG4gICAgICBsZXQgcHRzRm9yVG9vbHRpcHMgPSBwdHMuZmlsdGVyKFxuICAgICAgICAgIChwKSA9PiBpbnRlcnNlY3RzQkJveChwLngsIHAueSwgYmJveCkgfHxcbiAgICAgICAgICAgICAgaXNOYU4odGhpcy55VmFsdWVBY2Nlc3NvcihwLmRhdHVtLCAwLCBwLmRhdGFzZXQpKSk7XG4gICAgICAvLyBPbmx5IGRyYXcgbGl0dGxlIGluZGljYXRvciBjaXJjbGVzIGZvciB0aGUgbm9uLU5hTiBwb2ludHNcbiAgICAgIGxldCBwdHNUb0NpcmNsZSA9IHB0c0ZvclRvb2x0aXBzLmZpbHRlcihcbiAgICAgICAgICAocCkgPT4gIWlzTmFOKHRoaXMueVZhbHVlQWNjZXNzb3IocC5kYXR1bSwgMCwgcC5kYXRhc2V0KSkpO1xuXG4gICAgICBsZXQgcHRzU2VsZWN0aW9uOiBhbnkgPVxuICAgICAgICAgIHRoaXMudG9vbHRpcFBvaW50c0NvbXBvbmVudC5jb250ZW50KCkuc2VsZWN0QWxsKCcucG9pbnQnKS5kYXRhKFxuICAgICAgICAgICAgICBwdHNUb0NpcmNsZSxcbiAgICAgICAgICAgICAgKHA6IHZ6X2NoYXJ0X2hlbHBlcnMuUG9pbnQpID0+IHAuZGF0YXNldC5tZXRhZGF0YSgpLm5hbWUpO1xuICAgICAgaWYgKHB0cy5sZW5ndGggIT09IDApIHtcbiAgICAgICAgcHRzU2VsZWN0aW9uLmVudGVyKCkuYXBwZW5kKCdjaXJjbGUnKS5jbGFzc2VkKCdwb2ludCcsIHRydWUpO1xuICAgICAgICBwdHNTZWxlY3Rpb24uYXR0cigncicsIHZ6X2NoYXJ0X2hlbHBlcnMuVE9PTFRJUF9DSVJDTEVfU0laRSlcbiAgICAgICAgICAgIC5hdHRyKCdjeCcsIChwKSA9PiBwLngpXG4gICAgICAgICAgICAuYXR0cignY3knLCAocCkgPT4gcC55KVxuICAgICAgICAgICAgLnN0eWxlKCdzdHJva2UnLCAnbm9uZScpXG4gICAgICAgICAgICAuYXR0cihcbiAgICAgICAgICAgICAgICAnZmlsbCcsXG4gICAgICAgICAgICAgICAgKHApID0+IHRoaXMuY29sb3JTY2FsZS5zY2FsZShwLmRhdGFzZXQubWV0YWRhdGEoKS5uYW1lKSk7XG4gICAgICAgIHB0c1NlbGVjdGlvbi5leGl0KCkucmVtb3ZlKCk7XG4gICAgICAgIHRoaXMuZHJhd1Rvb2x0aXBzKHB0c0ZvclRvb2x0aXBzLCB0YXJnZXQsIHRoaXMudG9vbHRpcENvbHVtbnMpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhpcy5oaWRlVG9vbHRpcHMoKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgICBwaS5vblBvaW50ZXJFeGl0KCgpID0+IHRoaXMuaGlkZVRvb2x0aXBzKCkpO1xuICAgIHJldHVybiBwaTtcbiAgfVxuXG4gIHByaXZhdGUgaGlkZVRvb2x0aXBzKCk6IHZvaWQge1xuICAgIHRoaXMudG9vbHRpcC5zdHlsZSgnb3BhY2l0eScsIDApO1xuICAgIHRoaXMuc2NhdHRlclBsb3QuYXR0cignb3BhY2l0eScsIDEpO1xuICAgIHRoaXMudG9vbHRpcFBvaW50c0NvbXBvbmVudC5jb250ZW50KCkuc2VsZWN0QWxsKCcucG9pbnQnKS5yZW1vdmUoKTtcbiAgfVxuXG4gIHByaXZhdGUgc2V0dXBUb29sdGlwcyhwbG90OiBQbG90dGFibGUuWFlQbG90PG51bWJlcnxEYXRlLCBudW1iZXI+KTogdm9pZCB7XG4gICAgcGxvdC5vbkRldGFjaCgoKSA9PiB7XG4gICAgICB0aGlzLnRvb2x0aXBJbnRlcmFjdGlvbi5kZXRhY2hGcm9tKHBsb3QpO1xuICAgICAgdGhpcy50b29sdGlwSW50ZXJhY3Rpb24uZW5hYmxlZChmYWxzZSk7XG4gICAgfSk7XG4gICAgcGxvdC5vbkFuY2hvcigoKSA9PiB7XG4gICAgICB0aGlzLnRvb2x0aXBJbnRlcmFjdGlvbi5hdHRhY2hUbyhwbG90KTtcbiAgICAgIHRoaXMudG9vbHRpcEludGVyYWN0aW9uLmVuYWJsZWQodHJ1ZSk7XG4gICAgfSk7XG4gIH1cblxuICBwcml2YXRlIGRyYXdUb29sdGlwcyhcbiAgICAgIHBvaW50czogdnpfY2hhcnRfaGVscGVycy5Qb2ludFtdLFxuICAgICAgdGFyZ2V0OiB2el9jaGFydF9oZWxwZXJzLlBvaW50LFxuICAgICAgdG9vbHRpcENvbHVtbnM6IHZ6X2NoYXJ0X2hlbHBlcnMuVG9vbHRpcENvbHVtbltdKSB7XG4gICAgLy8gRm9ybWF0dGVycyBmb3IgdmFsdWUsIHN0ZXAsIGFuZCB3YWxsX3RpbWVcbiAgICB0aGlzLnNjYXR0ZXJQbG90LmF0dHIoJ29wYWNpdHknLCAwKTtcbiAgICBsZXQgdmFsdWVGb3JtYXR0ZXIgPSB2el9jaGFydF9oZWxwZXJzLm11bHRpc2NhbGVGb3JtYXR0ZXIoXG4gICAgICAgIHZ6X2NoYXJ0X2hlbHBlcnMuWV9UT09MVElQX0ZPUk1BVFRFUl9QUkVDSVNJT04pO1xuXG4gICAgbGV0IGRpc3QgPSAocDogdnpfY2hhcnRfaGVscGVycy5Qb2ludCkgPT5cbiAgICAgICAgTWF0aC5wb3cocC54IC0gdGFyZ2V0LngsIDIpICsgTWF0aC5wb3cocC55IC0gdGFyZ2V0LnksIDIpO1xuICAgIGxldCBjbG9zZXN0RGlzdCA9IF8ubWluKHBvaW50cy5tYXAoZGlzdCkpO1xuXG4gICAgbGV0IHZhbHVlU29ydE1ldGhvZCA9IHRoaXMueVZhbHVlQWNjZXNzb3I7XG4gICAgaWYgKHRoaXMuc21vb3RoaW5nRW5hYmxlZCkge1xuICAgICAgdmFsdWVTb3J0TWV0aG9kID0gdGhpcy5zbW9vdGhlZEFjY2Vzc29yO1xuICAgIH1cblxuICAgIGlmICh0aGlzLnRvb2x0aXBTb3J0aW5nTWV0aG9kID09PSAnYXNjZW5kaW5nJykge1xuICAgICAgcG9pbnRzID0gXy5zb3J0QnkocG9pbnRzLCAoZCkgPT4gdmFsdWVTb3J0TWV0aG9kKGQuZGF0dW0sIC0xLCBkLmRhdGFzZXQpKTtcbiAgICB9IGVsc2UgaWYgKHRoaXMudG9vbHRpcFNvcnRpbmdNZXRob2QgPT09ICdkZXNjZW5kaW5nJykge1xuICAgICAgcG9pbnRzID0gXy5zb3J0QnkocG9pbnRzLCAoZCkgPT4gdmFsdWVTb3J0TWV0aG9kKGQuZGF0dW0sIC0xLCBkLmRhdGFzZXQpKVxuICAgICAgICAgICAgICAgICAgIC5yZXZlcnNlKCk7XG4gICAgfSBlbHNlIGlmICh0aGlzLnRvb2x0aXBTb3J0aW5nTWV0aG9kID09PSAnbmVhcmVzdCcpIHtcbiAgICAgIHBvaW50cyA9IF8uc29ydEJ5KHBvaW50cywgZGlzdCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIC8vIFRoZSAnZGVmYXVsdCcgc29ydGluZyBtZXRob2QgbWFpbnRhaW5zIHRoZSBvcmRlciBvZiBuYW1lcyBwYXNzZWQgdG9cbiAgICAgIC8vIHNldFZpc2libGVTZXJpZXMoKS4gSG93ZXZlciB3ZSByZXZlcnNlIHRoYXQgb3JkZXIgd2hlbiBkZWZpbmluZyB0aGVcbiAgICAgIC8vIGRhdGFzZXRzLiBTbyB3ZSBtdXN0IGNhbGwgcmV2ZXJzZSBhZ2FpbiB0byByZXN0b3JlIHRoZSBvcmRlci5cbiAgICAgIHBvaW50cyA9IHBvaW50cy5zbGljZSgwKS5yZXZlcnNlKCk7XG4gICAgfVxuXG4gICAgbGV0IHJvd3MgPSB0aGlzLnRvb2x0aXAuc2VsZWN0KCd0Ym9keScpXG4gICAgICAgICAgICAgICAgICAgLmh0bWwoJycpXG4gICAgICAgICAgICAgICAgICAgLnNlbGVjdEFsbCgndHInKVxuICAgICAgICAgICAgICAgICAgIC5kYXRhKHBvaW50cylcbiAgICAgICAgICAgICAgICAgICAuZW50ZXIoKVxuICAgICAgICAgICAgICAgICAgIC5hcHBlbmQoJ3RyJyk7XG4gICAgLy8gR3JleSBvdXQgdGhlIHBvaW50IGlmIGFueSBvZiB0aGUgZm9sbG93aW5nIGFyZSB0cnVlOlxuICAgIC8vIC0gVGhlIGN1cnNvciBpcyBvdXRzaWRlIG9mIHRoZSB4LWV4dGVudCBvZiB0aGUgZGF0YXNldFxuICAgIC8vIC0gVGhlIHBvaW50J3MgeSB2YWx1ZSBpcyBOYU5cbiAgICByb3dzLmNsYXNzZWQoJ2Rpc3RhbnQnLCAoZCkgPT4ge1xuICAgICAgbGV0IGZpcnN0UG9pbnQgPSBkLmRhdGFzZXQuZGF0YSgpWzBdO1xuICAgICAgbGV0IGxhc3RQb2ludCA9IF8ubGFzdChkLmRhdGFzZXQuZGF0YSgpKTtcbiAgICAgIGxldCBmaXJzdFggPSB0aGlzLnhTY2FsZS5zY2FsZSh0aGlzLnhBY2Nlc3NvcihmaXJzdFBvaW50LCAwLCBkLmRhdGFzZXQpKTtcbiAgICAgIGxldCBsYXN0WCA9IHRoaXMueFNjYWxlLnNjYWxlKHRoaXMueEFjY2Vzc29yKGxhc3RQb2ludCwgMCwgZC5kYXRhc2V0KSk7XG4gICAgICBsZXQgcyA9IHRoaXMuc21vb3RoaW5nRW5hYmxlZCA/XG4gICAgICAgICAgZC5kYXR1bS5zbW9vdGhlZCA6IHRoaXMueVZhbHVlQWNjZXNzb3IoZC5kYXR1bSwgMCwgZC5kYXRhc2V0KTtcbiAgICAgIHJldHVybiB0YXJnZXQueCA8IGZpcnN0WCB8fCB0YXJnZXQueCA+IGxhc3RYIHx8IGlzTmFOKHMpO1xuICAgIH0pO1xuICAgIHJvd3MuY2xhc3NlZCgnY2xvc2VzdCcsIChwKSA9PiBkaXN0KHApID09PSBjbG9zZXN0RGlzdCk7XG4gICAgLy8gSXQgaXMgYSBiaXQgaGFja3kgdGhhdCB3ZSBhcmUgbWFudWFsbHkgYXBwbHlpbmcgdGhlIHdpZHRoIHRvIHRoZSBzd2F0Y2hcbiAgICAvLyBhbmQgdGhlIG5vd3JhcCBwcm9wZXJ0eSB0byB0aGUgdGV4dCBoZXJlLiBUaGUgcmVhc29uIGlzIGFzIGZvbGxvd3M6XG4gICAgLy8gdGhlIHN0eWxlIGdldHMgdXBkYXRlZCBhc3luY2hyb25vdXNseSBieSBQb2x5bWVyIHNjb3BlU3VidHJlZSBvYnNlcnZlci5cbiAgICAvLyBXaGljaCBtZWFucyB3ZSB3b3VsZCBnZXQgaW5jb3JyZWN0IHNpemluZyBpbmZvcm1hdGlvbiBzaW5jZSB0aGUgdGV4dFxuICAgIC8vIHdvdWxkIHdyYXAgYnkgZGVmYXVsdC4gSG93ZXZlciwgd2UgbmVlZCBjb3JyZWN0IG1lYXN1cmVtZW50cyBzbyB0aGF0XG4gICAgLy8gd2UgY2FuIHN0b3AgdGhlIHRleHQgZnJvbSBmYWxsaW5nIG9mZiB0aGUgZWRnZSBvZiB0aGUgc2NyZWVuLlxuICAgIC8vIHRoZXJlZm9yZSwgd2UgYXBwbHkgdGhlIHNpemUtY3JpdGljYWwgc3R5bGVzIGRpcmVjdGx5LlxuICAgIHJvd3Muc3R5bGUoJ3doaXRlLXNwYWNlJywgJ25vd3JhcCcpO1xuICAgIHJvd3MuYXBwZW5kKCd0ZCcpXG4gICAgICAgIC5hcHBlbmQoJ3NwYW4nKVxuICAgICAgICAuY2xhc3NlZCgnc3dhdGNoJywgdHJ1ZSlcbiAgICAgICAgLnN0eWxlKFxuICAgICAgICAgICAgJ2JhY2tncm91bmQtY29sb3InLFxuICAgICAgICAgICAgKGQpID0+IHRoaXMuY29sb3JTY2FsZS5zY2FsZShkLmRhdGFzZXQubWV0YWRhdGEoKS5uYW1lKSk7XG5cbiAgICBfLmVhY2godG9vbHRpcENvbHVtbnMsIChjb2x1bW4pID0+IHtcbiAgICAgIHJvd3MuYXBwZW5kKCd0ZCcpLnRleHQoXG4gICAgICAgICAgKGQpID0+IGNvbHVtbi5ldmFsdWF0ZShkLCB7XG4gICAgICAgICAgICBzbW9vdGhpbmdFbmFibGVkOiB0aGlzLnNtb290aGluZ0VuYWJsZWQsXG4gICAgICAgICAgfSkpO1xuICAgIH0pO1xuXG4gICAgLy8gY29tcHV0ZSBsZWZ0IHBvc2l0aW9uXG4gICAgbGV0IGRvY3VtZW50V2lkdGggPSBkb2N1bWVudC5ib2R5LmNsaWVudFdpZHRoO1xuICAgIGxldCBub2RlOiBhbnkgPSB0aGlzLnRvb2x0aXAubm9kZSgpO1xuICAgIGxldCBwYXJlbnRSZWN0ID0gbm9kZS5wYXJlbnRFbGVtZW50LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuICAgIGxldCBub2RlUmVjdCA9IG5vZGUuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gICAgLy8gcHJldmVudCBpdCBmcm9tIGZhbGxpbmcgb2ZmIHRoZSByaWdodCBzaWRlIG9mIHRoZSBzY3JlZW5cbiAgICBsZXQgbGVmdCA9IGRvY3VtZW50V2lkdGggLSBwYXJlbnRSZWN0LmxlZnQgLSBub2RlUmVjdC53aWR0aCAtIDYwLCB0b3AgPSAwO1xuXG4gICAgaWYgKHRoaXMudG9vbHRpcFBvc2l0aW9uID09PSAncmlnaHQnKSB7XG4gICAgICBsZWZ0ID0gTWF0aC5taW4ocGFyZW50UmVjdC53aWR0aCwgbGVmdCk7XG4gICAgfSBlbHNlIHsgIC8vICdib3R0b20nXG4gICAgICBsZWZ0ID0gTWF0aC5taW4oMCwgbGVmdCk7XG4gICAgICB0b3AgPSBwYXJlbnRSZWN0LmhlaWdodCArIHZ6X2NoYXJ0X2hlbHBlcnMuVE9PTFRJUF9ZX1BJWEVMX09GRlNFVDtcbiAgICB9XG5cbiAgICB0aGlzLnRvb2x0aXAuc3R5bGUoJ3RyYW5zZm9ybScsICd0cmFuc2xhdGUoJyArIGxlZnQgKyAncHgsJyArIHRvcCArICdweCknKTtcbiAgICB0aGlzLnRvb2x0aXAuc3R5bGUoJ29wYWNpdHknLCAxKTtcbiAgfVxuXG4gIHByaXZhdGUgZmluZENsb3Nlc3RQb2ludChcbiAgICAgIHRhcmdldDogdnpfY2hhcnRfaGVscGVycy5Qb2ludCxcbiAgICAgIGRhdGFzZXQ6IFBsb3R0YWJsZS5EYXRhc2V0KTogdnpfY2hhcnRfaGVscGVycy5Qb2ludCB7XG4gICAgbGV0IHBvaW50czogdnpfY2hhcnRfaGVscGVycy5Qb2ludFtdID0gZGF0YXNldC5kYXRhKCkubWFwKChkLCBpKSA9PiB7XG4gICAgICBsZXQgeCA9IHRoaXMueEFjY2Vzc29yKGQsIGksIGRhdGFzZXQpO1xuICAgICAgbGV0IHkgPSB0aGlzLnNtb290aGluZ0VuYWJsZWQgPyB0aGlzLnNtb290aGVkQWNjZXNzb3IoZCwgaSwgZGF0YXNldCkgOlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnlWYWx1ZUFjY2Vzc29yKGQsIGksIGRhdGFzZXQpO1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgeDogdGhpcy54U2NhbGUuc2NhbGUoeCksXG4gICAgICAgIHk6IHRoaXMueVNjYWxlLnNjYWxlKHkpLFxuICAgICAgICBkYXR1bTogZCxcbiAgICAgICAgZGF0YXNldDogZGF0YXNldCxcbiAgICAgIH07XG4gICAgfSk7XG4gICAgbGV0IGlkeDogbnVtYmVyID1cbiAgICAgICAgc29ydGVkSW5kZXhCeShwb2ludHMsIHRhcmdldCwgKHA6IHZ6X2NoYXJ0X2hlbHBlcnMuUG9pbnQpID0+IHAueCk7XG4gICAgaWYgKGlkeCA9PT0gcG9pbnRzLmxlbmd0aCkge1xuICAgICAgcmV0dXJuIHBvaW50c1twb2ludHMubGVuZ3RoIC0gMV07XG4gICAgfSBlbHNlIGlmIChpZHggPT09IDApIHtcbiAgICAgIHJldHVybiBwb2ludHNbMF07XG4gICAgfSBlbHNlIHtcbiAgICAgIGxldCBwcmV2ID0gcG9pbnRzW2lkeCAtIDFdO1xuICAgICAgbGV0IG5leHQgPSBwb2ludHNbaWR4XTtcbiAgICAgIGxldCBwcmV2RGlzdCA9IE1hdGguYWJzKHByZXYueCAtIHRhcmdldC54KTtcbiAgICAgIGxldCBuZXh0RGlzdCA9IE1hdGguYWJzKG5leHQueCAtIHRhcmdldC54KTtcbiAgICAgIHJldHVybiBwcmV2RGlzdCA8IG5leHREaXN0ID8gcHJldiA6IG5leHQ7XG4gICAgfVxuICB9XG5cbiAgcHJpdmF0ZSByZXNtb290aERhdGFzZXQoZGF0YXNldDogUGxvdHRhYmxlLkRhdGFzZXQpIHtcbiAgICBsZXQgZGF0YSA9IGRhdGFzZXQuZGF0YSgpO1xuICAgIGNvbnN0IHNtb290aGluZ1dlaWdodCA9IHRoaXMuc21vb3RoaW5nV2VpZ2h0O1xuICAgIC8vIDFzdC1vcmRlciBJSVIgbG93LXBhc3MgZmlsdGVyIHRvIGF0dGVudWF0ZSB0aGUgaGlnaGVyLVxuICAgIC8vIGZyZXF1ZW5jeSBjb21wb25lbnRzIG9mIHRoZSB0aW1lLXNlcmllcy5cbiAgICBsZXQgbGFzdCA9IGRhdGEubGVuZ3RoID4gMCA/IDAgOiBOYU47XG4gICAgbGV0IG51bUFjY3VtID0gMDtcbiAgICBkYXRhLmZvckVhY2goKGQsIGkpID0+IHtcbiAgICAgIGxldCBuZXh0VmFsID0gdGhpcy55VmFsdWVBY2Nlc3NvcihkLCBpLCBkYXRhc2V0KTtcbiAgICAgIGlmICghXy5pc0Zpbml0ZShuZXh0VmFsKSkge1xuICAgICAgICBkLnNtb290aGVkID0gbmV4dFZhbDtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGxhc3QgPSBsYXN0ICogc21vb3RoaW5nV2VpZ2h0ICsgKDEgLSBzbW9vdGhpbmdXZWlnaHQpICogbmV4dFZhbDtcbiAgICAgICAgbnVtQWNjdW0rKztcbiAgICAgICAgLy8gVGhlIHVuY29ycmVjdGVkIG1vdmluZyBhdmVyYWdlIGlzIGJpYXNlZCB0b3dhcmRzIHRoZSBpbml0aWFsIHZhbHVlLlxuICAgICAgICAvLyBGb3IgZXhhbXBsZSwgaWYgaW5pdGlhbGl6ZWQgd2l0aCBgMGAsIHdpdGggc21vb3RoaW5nV2VpZ2h0IGBzYCwgd2hlcmVcbiAgICAgICAgLy8gZXZlcnkgZGF0YSBwb2ludCBpcyBgY2AsIGFmdGVyIGB0YCBzdGVwcyB0aGUgbW92aW5nIGF2ZXJhZ2UgaXNcbiAgICAgICAgLy8gYGBgXG4gICAgICAgIC8vICAgRU1BID0gMCpzXih0KSArIGMqKDEgLSBzKSpzXih0LTEpICsgYyooMSAtIHMpKnNeKHQtMikgKyAuLi5cbiAgICAgICAgLy8gICAgICAgPSBjKigxIC0gc150KVxuICAgICAgICAvLyBgYGBcbiAgICAgICAgLy8gSWYgaW5pdGlhbGl6ZWQgd2l0aCBgMGAsIGRpdmlkaW5nIGJ5ICgxIC0gc150KSBpcyBlbm91Z2ggdG8gZGViaWFzXG4gICAgICAgIC8vIHRoZSBtb3ZpbmcgYXZlcmFnZS4gV2UgY291bnQgdGhlIG51bWJlciBvZiBmaW5pdGUgZGF0YSBwb2ludHMgYW5kXG4gICAgICAgIC8vIGRpdmlkZSBhcHByb3ByaWF0ZWx5IGJlZm9yZSBzdG9yaW5nIHRoZSBkYXRhLlxuICAgICAgICBsZXQgZGViaWFzV2VpZ2h0ID0gMTtcbiAgICAgICAgaWYgKHNtb290aGluZ1dlaWdodCAhPT0gMS4wKSB7XG4gICAgICAgICAgZGViaWFzV2VpZ2h0ID0gMS4wIC0gTWF0aC5wb3coc21vb3RoaW5nV2VpZ2h0LCBudW1BY2N1bSk7XG4gICAgICAgIH1cbiAgICAgICAgZC5zbW9vdGhlZCA9IGxhc3QgLyBkZWJpYXNXZWlnaHQ7XG4gICAgICB9XG4gICAgfSk7XG4gIH1cblxuICBwcml2YXRlIGdldERhdGFzZXQobmFtZTogc3RyaW5nKSB7XG4gICAgaWYgKHRoaXMubmFtZTJkYXRhc2V0c1tuYW1lXSA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICB0aGlzLm5hbWUyZGF0YXNldHNbbmFtZV0gPSBuZXcgUGxvdHRhYmxlLkRhdGFzZXQoW10sIHtuYW1lOiBuYW1lfSk7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLm5hbWUyZGF0YXNldHNbbmFtZV07XG4gIH1cblxuICBzdGF0aWMgZ2V0WVNjYWxlRnJvbVR5cGUoeVNjYWxlVHlwZTogc3RyaW5nKTpcbiAgICAgIFBsb3R0YWJsZS5RdWFudGl0YXRpdmVTY2FsZTxudW1iZXI+IHtcbiAgICBpZiAoeVNjYWxlVHlwZSA9PT0gJ2xvZycpIHtcbiAgICAgIHJldHVybiBuZXcgUGxvdHRhYmxlLlNjYWxlcy5Nb2RpZmllZExvZygpO1xuICAgIH0gZWxzZSBpZiAoeVNjYWxlVHlwZSA9PT0gJ2xpbmVhcicpIHtcbiAgICAgIHJldHVybiBuZXcgUGxvdHRhYmxlLlNjYWxlcy5MaW5lYXIoKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKCdVbnJlY29nbml6ZWQgeVNjYWxlIHR5cGUgJyArIHlTY2FsZVR5cGUpO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBVcGRhdGUgdGhlIHNlbGVjdGVkIHNlcmllcyBvbiB0aGUgY2hhcnQuXG4gICAqL1xuICBwdWJsaWMgc2V0VmlzaWJsZVNlcmllcyhuYW1lczogc3RyaW5nW10pIHtcbiAgICBuYW1lcyA9IG5hbWVzLnNvcnQoKTtcbiAgICB0aGlzLnNlcmllc05hbWVzID0gbmFtZXM7XG5cbiAgICBuYW1lcy5yZXZlcnNlKCk7ICAvLyBkcmF3IGZpcnN0IHNlcmllcyBvbiB0b3BcbiAgICB0aGlzLmRhdGFzZXRzLmZvckVhY2goKGQpID0+IGQub2ZmVXBkYXRlKHRoaXMub25EYXRhc2V0Q2hhbmdlZCkpO1xuICAgIHRoaXMuZGF0YXNldHMgPSBuYW1lcy5tYXAoKHIpID0+IHRoaXMuZ2V0RGF0YXNldChyKSk7XG4gICAgdGhpcy5kYXRhc2V0cy5mb3JFYWNoKChkKSA9PiBkLm9uVXBkYXRlKHRoaXMub25EYXRhc2V0Q2hhbmdlZCkpO1xuICAgIHRoaXMubGluZVBsb3QuZGF0YXNldHModGhpcy5kYXRhc2V0cyk7XG5cbiAgICBpZiAodGhpcy5zbW9vdGhpbmdFbmFibGVkKSB7XG4gICAgICB0aGlzLnNtb290aExpbmVQbG90LmRhdGFzZXRzKHRoaXMuZGF0YXNldHMpO1xuICAgIH1cbiAgICBpZiAodGhpcy5tYXJnaW5BcmVhUGxvdCkge1xuICAgICAgdGhpcy5tYXJnaW5BcmVhUGxvdC5kYXRhc2V0cyh0aGlzLmRhdGFzZXRzKTtcbiAgICB9XG4gICAgdGhpcy51cGRhdGVTcGVjaWFsRGF0YXNldHMoKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBTYW1wbGVzIGEgZGF0YXNldCBzbyB0aGF0IGl0IGNvbnRhaW5zIG5vIG1vcmUgdGhhbiBfTUFYX01BUktFUlMgbnVtYmVyIG9mXG4gICAqIGRhdGEgcG9pbnRzLiBUaGlzIGZ1bmN0aW9uIHJldHVybnMgdGhlIG9yaWdpbmFsIGRhdGFzZXQgaWYgaXQgZG9lcyBub3RcbiAgICogZXhjZWVkIHRoYXQgbWFueSBwb2ludHMuXG4gICAqL1xuICBwdWJsaWMgY3JlYXRlU2FtcGxlZERhdGFzZXRGb3JNYXJrZXJzKG9yaWdpbmFsOiBQbG90dGFibGUuRGF0YXNldCk6XG4gICAgICBQbG90dGFibGUuRGF0YXNldCB7XG4gICAgY29uc3Qgb3JpZ2luYWxEYXRhID0gb3JpZ2luYWwuZGF0YSgpO1xuICAgIGlmIChvcmlnaW5hbERhdGEubGVuZ3RoIDw9IF9NQVhfTUFSS0VSUykge1xuICAgICAgLy8gVGhpcyBkYXRhc2V0IGlzIHNtYWxsIGVub3VnaC4gRG8gbm90IHNhbXBsZS5cbiAgICAgIHJldHVybiBvcmlnaW5hbDtcbiAgICB9XG5cbiAgICAvLyBEb3duc2FtcGxlIHRoZSBkYXRhLiBPdGhlcndpc2UsIHRvbyBtYW55IG1hcmtlcnMgY2x1dHRlciB0aGUgY2hhcnQuXG4gICAgY29uc3Qgc2tpcExlbmd0aCA9IE1hdGguY2VpbChvcmlnaW5hbERhdGEubGVuZ3RoIC8gX01BWF9NQVJLRVJTKTtcbiAgICBjb25zdCBkYXRhID0gbmV3IEFycmF5KE1hdGguZmxvb3Iob3JpZ2luYWxEYXRhLmxlbmd0aCAvIHNraXBMZW5ndGgpKTtcbiAgICBmb3IgKGxldCBpID0gMCwgaiA9IDA7IGkgPCBkYXRhLmxlbmd0aDsgaSsrLCBqICs9IHNraXBMZW5ndGgpIHtcbiAgICAgIGRhdGFbaV0gPSBvcmlnaW5hbERhdGFbal07XG4gICAgfVxuICAgIHJldHVybiBuZXcgUGxvdHRhYmxlLkRhdGFzZXQoZGF0YSwgb3JpZ2luYWwubWV0YWRhdGEoKSk7XG4gIH1cblxuICAvKipcbiAgICogU2V0IHRoZSBkYXRhIG9mIGEgc2VyaWVzIG9uIHRoZSBjaGFydC5cbiAgICovXG4gIHB1YmxpYyBzZXRTZXJpZXNEYXRhKG5hbWU6IHN0cmluZywgZGF0YTogIHZ6X2NoYXJ0X2hlbHBlcnMuU2NhbGFyRGF0dW1bXSkge1xuICAgIHRoaXMuZ2V0RGF0YXNldChuYW1lKS5kYXRhKGRhdGEpO1xuICB9XG5cbiAgcHVibGljIHNtb290aGluZ1VwZGF0ZSh3ZWlnaHQ6IG51bWJlcikge1xuICAgIHRoaXMuc21vb3RoaW5nV2VpZ2h0ID0gd2VpZ2h0O1xuICAgIHRoaXMuZGF0YXNldHMuZm9yRWFjaCgoZCkgPT4gdGhpcy5yZXNtb290aERhdGFzZXQoZCkpO1xuXG4gICAgaWYgKCF0aGlzLnNtb290aGluZ0VuYWJsZWQpIHtcbiAgICAgIHRoaXMubGluZVBsb3QuYWRkQ2xhc3MoJ2dob3N0Jyk7XG4gICAgICB0aGlzLnNjYXR0ZXJQbG90LnkodGhpcy5zbW9vdGhlZEFjY2Vzc29yLCB0aGlzLnlTY2FsZSk7XG4gICAgICB0aGlzLnNtb290aGluZ0VuYWJsZWQgPSB0cnVlO1xuICAgICAgdGhpcy5zbW9vdGhMaW5lUGxvdC5kYXRhc2V0cyh0aGlzLmRhdGFzZXRzKTtcbiAgICB9XG5cbiAgICBpZiAodGhpcy5tYXJrZXJzU2NhdHRlclBsb3QpIHtcbiAgICAgIC8vIFVzZSB0aGUgY29ycmVjdCBhY2Nlc3NvciBmb3IgbWFya2VyIHBvc2l0aW9uaW5nLlxuICAgICAgdGhpcy5tYXJrZXJzU2NhdHRlclBsb3QueSh0aGlzLmdldFlBeGlzQWNjZXNzb3IoKSwgdGhpcy55U2NhbGUpO1xuICAgIH1cblxuICAgIHRoaXMudXBkYXRlU3BlY2lhbERhdGFzZXRzKCk7XG4gIH1cblxuICBwdWJsaWMgc21vb3RoaW5nRGlzYWJsZSgpIHtcbiAgICBpZiAodGhpcy5zbW9vdGhpbmdFbmFibGVkKSB7XG4gICAgICB0aGlzLmxpbmVQbG90LnJlbW92ZUNsYXNzKCdnaG9zdCcpO1xuICAgICAgdGhpcy5zY2F0dGVyUGxvdC55KHRoaXMueVZhbHVlQWNjZXNzb3IsIHRoaXMueVNjYWxlKTtcbiAgICAgIHRoaXMuc21vb3RoTGluZVBsb3QuZGF0YXNldHMoW10pO1xuICAgICAgdGhpcy5zbW9vdGhpbmdFbmFibGVkID0gZmFsc2U7XG4gICAgICB0aGlzLnVwZGF0ZVNwZWNpYWxEYXRhc2V0cygpO1xuICAgIH1cbiAgICBpZiAodGhpcy5tYXJrZXJzU2NhdHRlclBsb3QpIHtcbiAgICAgIC8vIFVzZSB0aGUgY29ycmVjdCBhY2Nlc3NvciAod2hpY2ggZGVwZW5kcyBvbiB3aGV0aGVyIHNtb290aGluZyBpc1xuICAgICAgLy8gZW5hYmxlZCkgZm9yIG1hcmtlciBwb3NpdGlvbmluZy5cbiAgICAgIHRoaXMubWFya2Vyc1NjYXR0ZXJQbG90LnkodGhpcy5nZXRZQXhpc0FjY2Vzc29yKCksIHRoaXMueVNjYWxlKTtcbiAgICB9XG4gIH1cblxuICBwdWJsaWMgc2V0VG9vbHRpcFNvcnRpbmdNZXRob2QobWV0aG9kOiBzdHJpbmcpIHtcbiAgICB0aGlzLnRvb2x0aXBTb3J0aW5nTWV0aG9kID0gbWV0aG9kO1xuICB9XG5cbiAgcHVibGljIHNldFRvb2x0aXBQb3NpdGlvbihwb3NpdGlvbjogc3RyaW5nKSB7XG4gICAgdGhpcy50b29sdGlwUG9zaXRpb24gPSBwb3NpdGlvbjtcbiAgfVxuXG4gIHB1YmxpYyByZW5kZXJUbyh0YXJnZXRTVkc6IGQzLlNlbGVjdGlvbjxhbnksIGFueSwgYW55LCBhbnk+KSB7XG4gICAgdGhpcy50YXJnZXRTVkcgPSB0YXJnZXRTVkc7XG4gICAgdGhpcy5vdXRlci5yZW5kZXJUbyh0YXJnZXRTVkcpO1xuXG4gICAgaWYgKHRoaXMuX2RlZmF1bHRYUmFuZ2UgIT0gbnVsbCkge1xuICAgICAgLy8gQSBoaWdoZXItbGV2ZWwgY29tcG9uZW50IHByb3ZpZGVkIGEgZGVmYXVsdCByYW5nZSBmb3IgdGhlIFggYXhpcy5cbiAgICAgIC8vIFN0YXJ0IHdpdGggdGhhdCByYW5nZS5cbiAgICAgIHRoaXMucmVzZXRYRG9tYWluKCk7XG4gICAgfVxuXG4gICAgaWYgKHRoaXMuX2RlZmF1bHRZUmFuZ2UgIT0gbnVsbCkge1xuICAgICAgLy8gQSBoaWdoZXItbGV2ZWwgY29tcG9uZW50IHByb3ZpZGVkIGEgZGVmYXVsdCByYW5nZSBmb3IgdGhlIFkgYXhpcy5cbiAgICAgIC8vIFN0YXJ0IHdpdGggdGhhdCByYW5nZS5cbiAgICAgIHRoaXMucmVzZXRZRG9tYWluKCk7XG4gICAgfVxuICB9XG5cbiAgcHVibGljIHJlZHJhdygpIHtcbiAgICB0aGlzLm91dGVyLnJlZHJhdygpO1xuICB9XG5cbiAgcHVibGljIGRlc3Ryb3koKSB7XG4gICAgLy8gRGVzdHJveWluZyBvdXRlciBkZXN0cm95cyBhbGwgc3ViY29tcG9uZW50cyByZWN1cnNpdmVseS5cbiAgICBpZiAodGhpcy5vdXRlcikgdGhpcy5vdXRlci5kZXN0cm95KCk7XG4gIH1cbn1cblxuLyoqXG4gKiBCaW5hcnkgc2VhcmNoZXMgYW5kIGZpbmRzIFwiY2xvc2VzdFwiIGluZGV4IG9mIGEgdmFsdWUgaW4gYW4gYXJyYXkuIEFzIHRoZSBuYW1lXG4gKiBpbmRpY2F0ZXMsIGBhcnJheWAgbXVzdCBiZSBzb3J0ZWQuIFdoZW4gdGhlcmUgaXMgbm8gZXhhY3QgbWF0Y2gsIGl0IHJldHVybnNcbiAqIGluZGV4IG9mIGEgZmlyc3QgaXRlbSB0aGF0IGlzIGxhcmdlciB0aGFuIHRoZSB2YWx1ZS5cbiAqIEFQSSBTaWduYXR1cmUgYW5kIG1ldGhvZCBpbnNwaXJlZCBieSBsb2Rhc2gjc29ydGVkSW5kZXhCeS5cbiAqIFRPRE8oc3RlcGhhbndsZWUpOiBVc2UgXy5zb3J0ZWRJbmRleEJ5IHdoZW4gdHlwZXMgYXJlIG1pZ3JhdGVkIHRvIHY0LlxuICovXG5mdW5jdGlvbiBzb3J0ZWRJbmRleEJ5PFQ+KGFycmF5OiBUW10sIHZhbHVlOiBULCBpdGVyYXRlZTogKHZhbDogVCkgPT4gbnVtYmVyKTpcbiAgICBudW1iZXIge1xuICBjb25zdCBxdWVyeSA9IGl0ZXJhdGVlKHZhbHVlKTtcblxuICBsZXQgbG93ID0gMDtcbiAgbGV0IGhpZ2ggPSBhcnJheS5sZW5ndGg7XG5cbiAgd2hpbGUgKGxvdyA8IGhpZ2gpIHtcbiAgICBjb25zdCBtaWQgPSBNYXRoLmZsb29yKChsb3cgKyBoaWdoKSAvIDIpO1xuICAgIGNvbnN0IG1pZFZhbCA9IGl0ZXJhdGVlKGFycmF5W21pZF0pO1xuICAgIGlmIChtaWRWYWwgPCBxdWVyeSkge1xuICAgICAgbG93ID0gbWlkICsgMTtcbiAgICB9IGVsc2Uge1xuICAgICAgaGlnaCA9IG1pZDtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIGhpZ2g7XG59XG5cbn0gIC8vIG5hbWVzcGFjZSB2el9saW5lX2NoYXJ0XG4iXX0=