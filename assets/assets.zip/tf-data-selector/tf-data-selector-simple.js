/* Copyright 2018 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the 'License');
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an 'AS IS' BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
var tf_data_selector;
(function (tf_data_selector) {
    var NO_EXPERIMENT_ID = null;
    Polymer({
        is: 'tf-data-selector-simple',
        properties: {
            _allExperiments: {
                type: Array,
                value: function () { return []; },
            },
            _allRuns: {
                type: Array,
                value: function () { return []; },
            },
            _selectedExperimentIds: {
                type: Array,
                value: tf_data_selector.getIdInitializer('e', {
                    defaultValue: [],
                    polymerProperty: '_selectedExperimentIds',
                }),
            },
            _selectedExperiments: {
                type: Array,
                observer: '_persistExperimentIds',
            },
            _selectedRunNames: {
                type: Array,
                value: tf_storage.getObjectInitializer('runs', {
                    defaultValue: [],
                    polymerProperty: '_selectedRunNames',
                }),
            },
            _selectedRuns: {
                type: Array,
                observer: '_persistRunNames',
            },
            _expToRunsAndTags: {
                type: Object,
                value: function () { return null; },
            },
            _tagRegex: {
                type: String,
                value: tf_storage.getStringInitializer('tagFilter', { defaultValue: '', polymerProperty: '_tagRegex' }),
                observer: '_persistTagFilter',
            },
            _requestManager: {
                type: Object,
                value: function () { return new tf_backend.RequestManager(); },
            },
            // Output property. It has subset of _selections.
            selection: {
                type: Object,
                notify: true,
                computed: '_computeSelection(_selectedExperiments, _expToRunsAndTags, _selectedRuns, _tagRegex)',
            },
        },
        observers: [
            '_fetchNewRunsAndTags(_selectedExperiments)',
        ],
        _persistExperimentIds: function () {
            var value = this._selectedExperiments.map(function (_a) {
                var id = _a.id;
                return id;
            });
            tf_data_selector.setId('e', value, { defaultValue: [] });
        },
        _persistRunNames: function () {
            var value = this._selectedRuns.map(function (_a) {
                var id = _a.id;
                return id;
            });
            tf_storage.setObject('runs', value, { defaultValue: [] });
        },
        _persistTagFilter: tf_storage.getStringObserver('tagFilter', { defaultValue: '', polymerProperty: '_tagRegex' }),
        attached: function () {
            var _this = this;
            this._updateExpKey = tf_backend.experimentsStore.addListener(function () {
                _this._allExperiments = tf_backend.experimentsStore.getExperiments();
            });
            this._allExperiments = tf_backend.experimentsStore.getExperiments();
            this._updateRunKey = tf_backend.runsStore.addListener(function () {
                _this._allRuns = Array.from(new Set(tf_backend.runsStore.getRuns()));
            });
            this._allRuns = Array.from(new Set(tf_backend.runsStore.getRuns()));
        },
        detached: function () {
            tf_backend.experimentsStore.removeListenerByKey(this._updateExpKey);
            tf_backend.experimentsStore.removeListenerByKey(this._updateRunKey);
        },
        _getExperimentColor: function () {
            return {
                getColor: function (item) {
                    return tf_color_scale.experimentsColorScale(item.title);
                },
            };
        },
        _getRunColor: function () {
            return {
                getColor: function (item) {
                    return tf_color_scale.runsColorScale(item.title);
                },
            };
        },
        _getRunsUsesCheckboxColors: function () {
            return this._selectedExperiments.length <= 1;
        },
        _getExperimentOptions: function (_) {
            return this._allExperiments
                .map(function (experiment) { return ({
                id: experiment.id,
                title: experiment.name,
                subtitle: getShortDateString(new Date(experiment.startTime)),
            }); });
        },
        _getRunOptions: function () {
            return this._allRuns.map(function (run) { return ({ id: run, title: run }); });
        },
        _getExperimentsSelectionState: function () {
            var allIds = this._allExperiments.map(function (_a) {
                var id = _a.id;
                return id;
            });
            var selectedIds = new Set(this._selectedExperimentIds);
            var state = {};
            allIds.forEach(function (id) { return state[id] = selectedIds.has(id); });
            return state;
        },
        _getRunsSelectionState: function () {
            var allIds = this._allRuns;
            var selectedIds = new Set(this._selectedRunNames);
            var state = {};
            allIds.forEach(function (id) { return state[id] = selectedIds.has(id); });
            return state;
        },
        _computeSelection: function () {
            var _this = this;
            var expMap = new Map(this._allExperiments.map(function (exp) { return [exp.id, exp]; }));
            var selectedRunNames = new Set(this._selectedRuns.map(function (_a) {
                var title = _a.title;
                return title;
            }));
            var completeExps = this._selectedExperiments
                .filter(function (_a) {
                var id = _a.id;
                return (_this._expToRunsAndTags || new Map()).has(id);
            })
                .map(function (_a) {
                var id = _a.id;
                return expMap.get(id);
            });
            var selections = completeExps.map(function (experiment) {
                return {
                    experiment: experiment,
                    runs: _this._expToRunsAndTags.get(experiment.id)
                        .filter(function (run) { return selectedRunNames.has(run.name); }),
                    tagRegex: _this._tagRegex,
                };
            });
            return {
                type: selections.length == 1 ?
                    tf_data_selector.Type.SINGLE : tf_data_selector.Type.COMPARISON,
                selections: selections,
            };
        },
        _fetchNewRunsAndTags: function () {
            var _this = this;
            var expMap = new Map(this._allExperiments.map(function (exp) { return [exp.id, exp]; }));
            var expsToFetch = this._selectedExperiments
                .filter(function (_a) {
                var id = _a.id;
                return !(_this._expToRunsAndTags || new Map()).has(id);
            })
                .map(function (_a) {
                var id = _a.id;
                return expMap.get(id);
            });
            var fetches = expsToFetch.map(function (exp) { return _this._fetchRunsAndTags(exp); });
            Promise.all(fetches).then(function (results) {
                var newExpToRunsAndTags = new Map(_this._expToRunsAndTags);
                results.forEach(function (runs, index) {
                    var exp = expsToFetch[index];
                    newExpToRunsAndTags.set(exp.id, runs);
                });
                _this._expToRunsAndTags = newExpToRunsAndTags;
            });
        },
        _fetchRunsAndTags: function (exp) {
            var id = exp.id;
            console.assert(id != null, 'Expected an experiment Id');
            var url = tf_backend.getRouter().runsForExperiment(id);
            return this._requestManager.request(url);
        },
    });
    function getShortDateString(date) {
        return date.toLocaleDateString(undefined, {
            month: 'long',
            day: 'numeric',
            hour: 'numeric',
            minute: 'numeric',
            second: 'numeric',
        });
    }
})(tf_data_selector || (tf_data_selector = {})); // namespace tf_data_selector
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGYtZGF0YS1zZWxlY3Rvci1zaW1wbGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJ0Zi1kYXRhLXNlbGVjdG9yLXNpbXBsZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7Ozs7Ozs7OztnRkFhZ0Y7QUFDaEYsSUFBVSxnQkFBZ0IsQ0FxTnpCO0FBck5ELFdBQVUsZ0JBQWdCO0lBRTFCLElBQU0sZ0JBQWdCLEdBQUcsSUFBSSxDQUFDO0lBRTlCLE9BQU8sQ0FBQztRQUNOLEVBQUUsRUFBRSx5QkFBeUI7UUFDN0IsVUFBVSxFQUFFO1lBQ1YsZUFBZSxFQUFFO2dCQUNmLElBQUksRUFBRSxLQUFLO2dCQUNYLEtBQUssRUFBRSxjQUErQixPQUFBLEVBQUUsRUFBRixDQUFFO2FBQ3pDO1lBRUQsUUFBUSxFQUFFO2dCQUNSLElBQUksRUFBRSxLQUFLO2dCQUNYLEtBQUssRUFBRSxjQUFnQixPQUFBLEVBQUUsRUFBRixDQUFFO2FBQzFCO1lBRUQsc0JBQXNCLEVBQUU7Z0JBQ3RCLElBQUksRUFBRSxLQUFLO2dCQUNYLEtBQUssRUFBRSxpQkFBQSxnQkFBZ0IsQ0FBQyxHQUFHLEVBQUU7b0JBQzNCLFlBQVksRUFBRSxFQUFFO29CQUNoQixlQUFlLEVBQUUsd0JBQXdCO2lCQUMxQyxDQUFDO2FBQ0g7WUFFRCxvQkFBb0IsRUFBRTtnQkFDcEIsSUFBSSxFQUFFLEtBQUs7Z0JBQ1gsUUFBUSxFQUFFLHVCQUF1QjthQUNsQztZQUVELGlCQUFpQixFQUFFO2dCQUNqQixJQUFJLEVBQUUsS0FBSztnQkFDWCxLQUFLLEVBQUUsVUFBVSxDQUFDLG9CQUFvQixDQUFDLE1BQU0sRUFBRTtvQkFDN0MsWUFBWSxFQUFFLEVBQUU7b0JBQ2hCLGVBQWUsRUFBRSxtQkFBbUI7aUJBQ3JDLENBQUM7YUFDSDtZQUVELGFBQWEsRUFBRTtnQkFDYixJQUFJLEVBQUUsS0FBSztnQkFDWCxRQUFRLEVBQUUsa0JBQWtCO2FBQzdCO1lBRUQsaUJBQWlCLEVBQUU7Z0JBQ2pCLElBQUksRUFBRSxNQUFNO2dCQUNaLEtBQUssRUFBRSxjQUFNLE9BQUEsSUFBSSxFQUFKLENBQUk7YUFDbEI7WUFFRCxTQUFTLEVBQUU7Z0JBQ1QsSUFBSSxFQUFFLE1BQU07Z0JBQ1osS0FBSyxFQUFFLFVBQVUsQ0FBQyxvQkFBb0IsQ0FDbEMsV0FBVyxFQUFFLEVBQUMsWUFBWSxFQUFFLEVBQUUsRUFBRSxlQUFlLEVBQUUsV0FBVyxFQUFDLENBQUM7Z0JBQ2xFLFFBQVEsRUFBRSxtQkFBbUI7YUFDOUI7WUFFRCxlQUFlLEVBQUU7Z0JBQ2YsSUFBSSxFQUFFLE1BQU07Z0JBQ1osS0FBSyxFQUFFLGNBQU0sT0FBQSxJQUFJLFVBQVUsQ0FBQyxjQUFjLEVBQUUsRUFBL0IsQ0FBK0I7YUFDN0M7WUFFRCxpREFBaUQ7WUFDakQsU0FBUyxFQUFFO2dCQUNULElBQUksRUFBRSxNQUFNO2dCQUNaLE1BQU0sRUFBRSxJQUFJO2dCQUNaLFFBQVEsRUFBRSxzRkFBc0Y7YUFDakc7U0FDRjtRQUVELFNBQVMsRUFBRTtZQUNULDRDQUE0QztTQUM3QztRQUVELHFCQUFxQjtZQUNuQixJQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsb0JBQW9CLENBQUMsR0FBRyxDQUFDLFVBQUMsRUFBSTtvQkFBSCxVQUFFO2dCQUFNLE9BQUEsRUFBRTtZQUFGLENBQUUsQ0FBQyxDQUFDO1lBQzFELGlCQUFBLEtBQUssQ0FBQyxHQUFHLEVBQUUsS0FBSyxFQUFFLEVBQUMsWUFBWSxFQUFFLEVBQUUsRUFBQyxDQUFDLENBQUM7UUFDeEMsQ0FBQztRQUVELGdCQUFnQjtZQUNkLElBQU0sS0FBSyxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLFVBQUMsRUFBSTtvQkFBSCxVQUFFO2dCQUFNLE9BQUEsRUFBRTtZQUFGLENBQUUsQ0FBQyxDQUFDO1lBQ25ELFVBQVUsQ0FBQyxTQUFTLENBQUMsTUFBTSxFQUFFLEtBQUssRUFBRSxFQUFDLFlBQVksRUFBRSxFQUFFLEVBQUMsQ0FBQyxDQUFDO1FBQzFELENBQUM7UUFFRCxpQkFBaUIsRUFBRSxVQUFVLENBQUMsaUJBQWlCLENBQzNDLFdBQVcsRUFBRSxFQUFDLFlBQVksRUFBRSxFQUFFLEVBQUUsZUFBZSxFQUFFLFdBQVcsRUFBQyxDQUFDO1FBRWxFLFFBQVE7WUFBUixpQkFVQztZQVRDLElBQUksQ0FBQyxhQUFhLEdBQUcsVUFBVSxDQUFDLGdCQUFnQixDQUFDLFdBQVcsQ0FBQztnQkFDM0QsS0FBSSxDQUFDLGVBQWUsR0FBRyxVQUFVLENBQUMsZ0JBQWdCLENBQUMsY0FBYyxFQUFFLENBQUM7WUFDdEUsQ0FBQyxDQUFDLENBQUM7WUFDSCxJQUFJLENBQUMsZUFBZSxHQUFHLFVBQVUsQ0FBQyxnQkFBZ0IsQ0FBQyxjQUFjLEVBQUUsQ0FBQztZQUVwRSxJQUFJLENBQUMsYUFBYSxHQUFHLFVBQVUsQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDO2dCQUNwRCxLQUFJLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxHQUFHLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDLENBQUM7WUFDdEUsQ0FBQyxDQUFDLENBQUM7WUFDSCxJQUFJLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxHQUFHLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFDdEUsQ0FBQztRQUVELFFBQVE7WUFDTixVQUFVLENBQUMsZ0JBQWdCLENBQUMsbUJBQW1CLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDO1lBQ3BFLFVBQVUsQ0FBQyxnQkFBZ0IsQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUM7UUFDdEUsQ0FBQztRQUVELG1CQUFtQjtZQUNqQixPQUFPO2dCQUNMLFFBQVEsRUFDSixVQUFDLElBQW9EO29CQUNqRCxPQUFBLGNBQWMsQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDO2dCQUFoRCxDQUFnRDthQUN6RCxDQUFDO1FBQ0osQ0FBQztRQUVELFlBQVk7WUFDVixPQUFPO2dCQUNMLFFBQVEsRUFDSixVQUFDLElBQW9EO29CQUNqRCxPQUFBLGNBQWMsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQztnQkFBekMsQ0FBeUM7YUFDbEQsQ0FBQztRQUNKLENBQUM7UUFFRCwwQkFBMEIsRUFBMUI7WUFDRSxPQUFPLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxNQUFNLElBQUksQ0FBQyxDQUFDO1FBQy9DLENBQUM7UUFFRCxxQkFBcUIsRUFBckIsVUFBc0IsQ0FBQztZQUNyQixPQUFPLElBQUksQ0FBQyxlQUFlO2lCQUN0QixHQUFHLENBQUMsVUFBQSxVQUFVLElBQUksT0FBQSxDQUFDO2dCQUNsQixFQUFFLEVBQUUsVUFBVSxDQUFDLEVBQUU7Z0JBQ2pCLEtBQUssRUFBRSxVQUFVLENBQUMsSUFBSTtnQkFDdEIsUUFBUSxFQUFFLGtCQUFrQixDQUFDLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsQ0FBQzthQUM3RCxDQUFDLEVBSmlCLENBSWpCLENBQUMsQ0FBQztRQUNWLENBQUM7UUFFRCxjQUFjLEVBQWQ7WUFDRSxPQUFPLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLFVBQUEsR0FBRyxJQUFJLE9BQUEsQ0FBQyxFQUFDLEVBQUUsRUFBRSxHQUFHLEVBQUUsS0FBSyxFQUFFLEdBQUcsRUFBQyxDQUFDLEVBQXZCLENBQXVCLENBQUMsQ0FBQztRQUMzRCxDQUFDO1FBRUQsNkJBQTZCO1lBQzNCLElBQU0sTUFBTSxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsR0FBRyxDQUFDLFVBQUMsRUFBSTtvQkFBSCxVQUFFO2dCQUFNLE9BQUEsRUFBRTtZQUFGLENBQUUsQ0FBQyxDQUFDO1lBQ3RELElBQU0sV0FBVyxHQUFHLElBQUksR0FBRyxDQUFDLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDO1lBQ3pELElBQU0sS0FBSyxHQUFHLEVBQUUsQ0FBQztZQUNqQixNQUFNLENBQUMsT0FBTyxDQUFDLFVBQUEsRUFBRSxJQUFJLE9BQUEsS0FBSyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFdBQVcsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEVBQS9CLENBQStCLENBQUMsQ0FBQztZQUN0RCxPQUFPLEtBQUssQ0FBQztRQUNmLENBQUM7UUFFRCxzQkFBc0I7WUFDcEIsSUFBTSxNQUFNLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQztZQUM3QixJQUFNLFdBQVcsR0FBRyxJQUFJLEdBQUcsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsQ0FBQztZQUNwRCxJQUFNLEtBQUssR0FBRyxFQUFFLENBQUM7WUFDakIsTUFBTSxDQUFDLE9BQU8sQ0FBQyxVQUFBLEVBQUUsSUFBSSxPQUFBLEtBQUssQ0FBQyxFQUFFLENBQUMsR0FBRyxXQUFXLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxFQUEvQixDQUErQixDQUFDLENBQUM7WUFDdEQsT0FBTyxLQUFLLENBQUM7UUFDZixDQUFDO1FBRUQsaUJBQWlCO1lBQWpCLGlCQXVCQztZQXRCQyxJQUFNLE1BQU0sR0FBRyxJQUFJLEdBQUcsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLEdBQUcsQ0FBQyxVQUFBLEdBQUcsSUFBSSxPQUFBLENBQUMsR0FBRyxDQUFDLEVBQUUsRUFBRSxHQUFHLENBQUMsRUFBYixDQUFhLENBQUMsQ0FBQyxDQUFDO1lBQ3ZFLElBQU0sZ0JBQWdCLEdBQUcsSUFBSSxHQUFHLENBQzVCLElBQUksQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLFVBQUMsRUFBTztvQkFBTixnQkFBSztnQkFBTSxPQUFBLEtBQUs7WUFBTCxDQUFLLENBQUMsQ0FBQyxDQUFDO1lBRWhELElBQU0sWUFBWSxHQUFHLElBQUksQ0FBQyxvQkFBb0I7aUJBQ3pDLE1BQU0sQ0FBQyxVQUFDLEVBQUk7b0JBQUgsVUFBRTtnQkFBTSxPQUFBLENBQUMsS0FBSSxDQUFDLGlCQUFpQixJQUFJLElBQUksR0FBRyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDO1lBQTdDLENBQTZDLENBQUM7aUJBQy9ELEdBQUcsQ0FBQyxVQUFDLEVBQUk7b0JBQUgsVUFBRTtnQkFBTSxPQUFBLE1BQU0sQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDO1lBQWQsQ0FBYyxDQUFDLENBQUM7WUFFbkMsSUFBTSxVQUFVLEdBQUcsWUFBWSxDQUFDLEdBQUcsQ0FBQyxVQUFBLFVBQVU7Z0JBQzVDLE9BQU87b0JBQ0wsVUFBVSxZQUFBO29CQUNWLElBQUksRUFBRSxLQUFJLENBQUMsaUJBQWlCLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUM7eUJBQzFDLE1BQU0sQ0FBQyxVQUFBLEdBQUcsSUFBSSxPQUFBLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQTlCLENBQThCLENBQUM7b0JBQ2xELFFBQVEsRUFBRSxLQUFJLENBQUMsU0FBUztpQkFDekIsQ0FBQztZQUNKLENBQUMsQ0FBQyxDQUFDO1lBRUgsT0FBTztnQkFDTCxJQUFJLEVBQUUsVUFBVSxDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUMsQ0FBQztvQkFDMUIsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLFVBQVU7Z0JBQ25FLFVBQVUsWUFBQTthQUNYLENBQUM7UUFDSixDQUFDO1FBRUQsb0JBQW9CO1lBQXBCLGlCQWVDO1lBZEMsSUFBTSxNQUFNLEdBQUcsSUFBSSxHQUFHLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxHQUFHLENBQUMsVUFBQSxHQUFHLElBQUksT0FBQSxDQUFDLEdBQUcsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDLEVBQWIsQ0FBYSxDQUFDLENBQUMsQ0FBQztZQUN2RSxJQUFNLFdBQVcsR0FBRyxJQUFJLENBQUMsb0JBQW9CO2lCQUN4QyxNQUFNLENBQUMsVUFBQyxFQUFJO29CQUFILFVBQUU7Z0JBQU0sT0FBQSxDQUFDLENBQUMsS0FBSSxDQUFDLGlCQUFpQixJQUFJLElBQUksR0FBRyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDO1lBQTlDLENBQThDLENBQUM7aUJBQ2hFLEdBQUcsQ0FBQyxVQUFDLEVBQUk7b0JBQUgsVUFBRTtnQkFBTSxPQUFBLE1BQU0sQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDO1lBQWQsQ0FBYyxDQUFDLENBQUM7WUFFbkMsSUFBTSxPQUFPLEdBQUcsV0FBVyxDQUFDLEdBQUcsQ0FBQyxVQUFBLEdBQUcsSUFBSSxPQUFBLEtBQUksQ0FBQyxpQkFBaUIsQ0FBQyxHQUFHLENBQUMsRUFBM0IsQ0FBMkIsQ0FBQyxDQUFDO1lBQ3BFLE9BQU8sQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQUEsT0FBTztnQkFDL0IsSUFBTSxtQkFBbUIsR0FBRyxJQUFJLEdBQUcsQ0FBQyxLQUFJLENBQUMsaUJBQWlCLENBQUMsQ0FBQztnQkFDNUQsT0FBTyxDQUFDLE9BQU8sQ0FBQyxVQUFDLElBQUksRUFBRSxLQUFLO29CQUMxQixJQUFNLEdBQUcsR0FBRyxXQUFXLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQy9CLG1CQUFtQixDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsRUFBRSxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUN4QyxDQUFDLENBQUMsQ0FBQztnQkFDSCxLQUFJLENBQUMsaUJBQWlCLEdBQUcsbUJBQW1CLENBQUM7WUFDL0MsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDO1FBRUQsaUJBQWlCLEVBQWpCLFVBQWtCLEdBQTBCO1lBQzFDLElBQU0sRUFBRSxHQUFHLEdBQUcsQ0FBQyxFQUFFLENBQUM7WUFDbEIsT0FBTyxDQUFDLE1BQU0sQ0FBQyxFQUFFLElBQUksSUFBSSxFQUFFLDJCQUEyQixDQUFDLENBQUM7WUFFeEQsSUFBTSxHQUFHLEdBQUcsVUFBVSxDQUFDLFNBQVMsRUFBRSxDQUFDLGlCQUFpQixDQUFDLEVBQUUsQ0FBQyxDQUFDO1lBQ3pELE9BQU8sSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDM0MsQ0FBQztLQUVGLENBQUMsQ0FBQztJQUVILDRCQUE0QixJQUFVO1FBQ3BDLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLFNBQVMsRUFBRTtZQUN4QyxLQUFLLEVBQUUsTUFBTTtZQUNiLEdBQUcsRUFBRSxTQUFTO1lBQ2QsSUFBSSxFQUFFLFNBQVM7WUFDZixNQUFNLEVBQUUsU0FBUztZQUNqQixNQUFNLEVBQUUsU0FBUztTQUNsQixDQUFDLENBQUM7SUFDTCxDQUFDO0FBRUQsQ0FBQyxFQXJOUyxnQkFBZ0IsS0FBaEIsZ0JBQWdCLFFBcU56QixDQUFFLDZCQUE2QiIsInNvdXJjZXNDb250ZW50IjpbIi8qIENvcHlyaWdodCAyMDE4IFRoZSBUZW5zb3JGbG93IEF1dGhvcnMuIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG5cbkxpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSAnTGljZW5zZScpO1xueW91IG1heSBub3QgdXNlIHRoaXMgZmlsZSBleGNlcHQgaW4gY29tcGxpYW5jZSB3aXRoIHRoZSBMaWNlbnNlLlxuWW91IG1heSBvYnRhaW4gYSBjb3B5IG9mIHRoZSBMaWNlbnNlIGF0XG5cbiAgICBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcblxuVW5sZXNzIHJlcXVpcmVkIGJ5IGFwcGxpY2FibGUgbGF3IG9yIGFncmVlZCB0byBpbiB3cml0aW5nLCBzb2Z0d2FyZVxuZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIExpY2Vuc2UgaXMgZGlzdHJpYnV0ZWQgb24gYW4gJ0FTIElTJyBCQVNJUyxcbldJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWSBLSU5ELCBlaXRoZXIgZXhwcmVzcyBvciBpbXBsaWVkLlxuU2VlIHRoZSBMaWNlbnNlIGZvciB0aGUgc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nIHBlcm1pc3Npb25zIGFuZFxubGltaXRhdGlvbnMgdW5kZXIgdGhlIExpY2Vuc2UuXG49PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0qL1xubmFtZXNwYWNlIHRmX2RhdGFfc2VsZWN0b3Ige1xuXG5jb25zdCBOT19FWFBFUklNRU5UX0lEID0gbnVsbDtcblxuUG9seW1lcih7XG4gIGlzOiAndGYtZGF0YS1zZWxlY3Rvci1zaW1wbGUnLFxuICBwcm9wZXJ0aWVzOiB7XG4gICAgX2FsbEV4cGVyaW1lbnRzOiB7XG4gICAgICB0eXBlOiBBcnJheSxcbiAgICAgIHZhbHVlOiAoKTogdGZfYmFja2VuZC5FeHBlcmltZW50W10gPT4gW10sXG4gICAgfSxcblxuICAgIF9hbGxSdW5zOiB7XG4gICAgICB0eXBlOiBBcnJheSxcbiAgICAgIHZhbHVlOiAoKTogc3RyaW5nW10gPT4gW10sXG4gICAgfSxcblxuICAgIF9zZWxlY3RlZEV4cGVyaW1lbnRJZHM6IHtcbiAgICAgIHR5cGU6IEFycmF5LFxuICAgICAgdmFsdWU6IGdldElkSW5pdGlhbGl6ZXIoJ2UnLCB7XG4gICAgICAgIGRlZmF1bHRWYWx1ZTogW10sXG4gICAgICAgIHBvbHltZXJQcm9wZXJ0eTogJ19zZWxlY3RlZEV4cGVyaW1lbnRJZHMnLFxuICAgICAgfSksXG4gICAgfSxcblxuICAgIF9zZWxlY3RlZEV4cGVyaW1lbnRzOiB7XG4gICAgICB0eXBlOiBBcnJheSxcbiAgICAgIG9ic2VydmVyOiAnX3BlcnNpc3RFeHBlcmltZW50SWRzJyxcbiAgICB9LFxuXG4gICAgX3NlbGVjdGVkUnVuTmFtZXM6IHtcbiAgICAgIHR5cGU6IEFycmF5LFxuICAgICAgdmFsdWU6IHRmX3N0b3JhZ2UuZ2V0T2JqZWN0SW5pdGlhbGl6ZXIoJ3J1bnMnLCB7XG4gICAgICAgIGRlZmF1bHRWYWx1ZTogW10sXG4gICAgICAgIHBvbHltZXJQcm9wZXJ0eTogJ19zZWxlY3RlZFJ1bk5hbWVzJyxcbiAgICAgIH0pLFxuICAgIH0sXG5cbiAgICBfc2VsZWN0ZWRSdW5zOiB7XG4gICAgICB0eXBlOiBBcnJheSxcbiAgICAgIG9ic2VydmVyOiAnX3BlcnNpc3RSdW5OYW1lcycsXG4gICAgfSxcblxuICAgIF9leHBUb1J1bnNBbmRUYWdzOiB7XG4gICAgICB0eXBlOiBPYmplY3QsXG4gICAgICB2YWx1ZTogKCkgPT4gbnVsbCxcbiAgICB9LFxuXG4gICAgX3RhZ1JlZ2V4OiB7XG4gICAgICB0eXBlOiBTdHJpbmcsXG4gICAgICB2YWx1ZTogdGZfc3RvcmFnZS5nZXRTdHJpbmdJbml0aWFsaXplcihcbiAgICAgICAgICAndGFnRmlsdGVyJywge2RlZmF1bHRWYWx1ZTogJycsIHBvbHltZXJQcm9wZXJ0eTogJ190YWdSZWdleCd9KSxcbiAgICAgIG9ic2VydmVyOiAnX3BlcnNpc3RUYWdGaWx0ZXInLFxuICAgIH0sXG5cbiAgICBfcmVxdWVzdE1hbmFnZXI6IHtcbiAgICAgIHR5cGU6IE9iamVjdCxcbiAgICAgIHZhbHVlOiAoKSA9PiBuZXcgdGZfYmFja2VuZC5SZXF1ZXN0TWFuYWdlcigpLFxuICAgIH0sXG5cbiAgICAvLyBPdXRwdXQgcHJvcGVydHkuIEl0IGhhcyBzdWJzZXQgb2YgX3NlbGVjdGlvbnMuXG4gICAgc2VsZWN0aW9uOiB7XG4gICAgICB0eXBlOiBPYmplY3QsXG4gICAgICBub3RpZnk6IHRydWUsXG4gICAgICBjb21wdXRlZDogJ19jb21wdXRlU2VsZWN0aW9uKF9zZWxlY3RlZEV4cGVyaW1lbnRzLCBfZXhwVG9SdW5zQW5kVGFncywgX3NlbGVjdGVkUnVucywgX3RhZ1JlZ2V4KScsXG4gICAgfSxcbiAgfSxcblxuICBvYnNlcnZlcnM6IFtcbiAgICAnX2ZldGNoTmV3UnVuc0FuZFRhZ3MoX3NlbGVjdGVkRXhwZXJpbWVudHMpJyxcbiAgXSxcblxuICBfcGVyc2lzdEV4cGVyaW1lbnRJZHMoKSB7XG4gICAgY29uc3QgdmFsdWUgPSB0aGlzLl9zZWxlY3RlZEV4cGVyaW1lbnRzLm1hcCgoe2lkfSkgPT4gaWQpO1xuICAgIHNldElkKCdlJywgdmFsdWUsIHtkZWZhdWx0VmFsdWU6IFtdfSk7XG4gIH0sXG5cbiAgX3BlcnNpc3RSdW5OYW1lcygpIHtcbiAgICBjb25zdCB2YWx1ZSA9IHRoaXMuX3NlbGVjdGVkUnVucy5tYXAoKHtpZH0pID0+IGlkKTtcbiAgICB0Zl9zdG9yYWdlLnNldE9iamVjdCgncnVucycsIHZhbHVlLCB7ZGVmYXVsdFZhbHVlOiBbXX0pO1xuICB9LFxuXG4gIF9wZXJzaXN0VGFnRmlsdGVyOiB0Zl9zdG9yYWdlLmdldFN0cmluZ09ic2VydmVyKFxuICAgICAgJ3RhZ0ZpbHRlcicsIHtkZWZhdWx0VmFsdWU6ICcnLCBwb2x5bWVyUHJvcGVydHk6ICdfdGFnUmVnZXgnfSksXG5cbiAgYXR0YWNoZWQoKSB7XG4gICAgdGhpcy5fdXBkYXRlRXhwS2V5ID0gdGZfYmFja2VuZC5leHBlcmltZW50c1N0b3JlLmFkZExpc3RlbmVyKCgpID0+IHtcbiAgICAgIHRoaXMuX2FsbEV4cGVyaW1lbnRzID0gdGZfYmFja2VuZC5leHBlcmltZW50c1N0b3JlLmdldEV4cGVyaW1lbnRzKCk7XG4gICAgfSk7XG4gICAgdGhpcy5fYWxsRXhwZXJpbWVudHMgPSB0Zl9iYWNrZW5kLmV4cGVyaW1lbnRzU3RvcmUuZ2V0RXhwZXJpbWVudHMoKTtcblxuICAgIHRoaXMuX3VwZGF0ZVJ1bktleSA9IHRmX2JhY2tlbmQucnVuc1N0b3JlLmFkZExpc3RlbmVyKCgpID0+IHtcbiAgICAgIHRoaXMuX2FsbFJ1bnMgPSBBcnJheS5mcm9tKG5ldyBTZXQodGZfYmFja2VuZC5ydW5zU3RvcmUuZ2V0UnVucygpKSk7XG4gICAgfSk7XG4gICAgdGhpcy5fYWxsUnVucyA9IEFycmF5LmZyb20obmV3IFNldCh0Zl9iYWNrZW5kLnJ1bnNTdG9yZS5nZXRSdW5zKCkpKTtcbiAgfSxcblxuICBkZXRhY2hlZCgpIHtcbiAgICB0Zl9iYWNrZW5kLmV4cGVyaW1lbnRzU3RvcmUucmVtb3ZlTGlzdGVuZXJCeUtleSh0aGlzLl91cGRhdGVFeHBLZXkpO1xuICAgIHRmX2JhY2tlbmQuZXhwZXJpbWVudHNTdG9yZS5yZW1vdmVMaXN0ZW5lckJ5S2V5KHRoaXMuX3VwZGF0ZVJ1bktleSk7XG4gIH0sXG5cbiAgX2dldEV4cGVyaW1lbnRDb2xvcigpIHtcbiAgICByZXR1cm4ge1xuICAgICAgZ2V0Q29sb3I6XG4gICAgICAgICAgKGl0ZW06IHRmX2Rhc2hib2FyZF9jb21tb24uRmlsdGVyYWJsZUNoZWNrYm94TGlzdEl0ZW0pOiBzdHJpbmcgPT5cbiAgICAgICAgICAgICAgdGZfY29sb3Jfc2NhbGUuZXhwZXJpbWVudHNDb2xvclNjYWxlKGl0ZW0udGl0bGUpLFxuICAgIH07XG4gIH0sXG5cbiAgX2dldFJ1bkNvbG9yKCkge1xuICAgIHJldHVybiB7XG4gICAgICBnZXRDb2xvcjpcbiAgICAgICAgICAoaXRlbTogdGZfZGFzaGJvYXJkX2NvbW1vbi5GaWx0ZXJhYmxlQ2hlY2tib3hMaXN0SXRlbSk6IHN0cmluZyA9PlxuICAgICAgICAgICAgICB0Zl9jb2xvcl9zY2FsZS5ydW5zQ29sb3JTY2FsZShpdGVtLnRpdGxlKSxcbiAgICB9O1xuICB9LFxuXG4gIF9nZXRSdW5zVXNlc0NoZWNrYm94Q29sb3JzKCk6IGJvb2xlYW4ge1xuICAgIHJldHVybiB0aGlzLl9zZWxlY3RlZEV4cGVyaW1lbnRzLmxlbmd0aCA8PSAxO1xuICB9LFxuXG4gIF9nZXRFeHBlcmltZW50T3B0aW9ucyhfKTogdGZfZGFzaGJvYXJkX2NvbW1vbi5GaWx0ZXJhYmxlQ2hlY2tib3hMaXN0SXRlbVtdIHtcbiAgICByZXR1cm4gdGhpcy5fYWxsRXhwZXJpbWVudHNcbiAgICAgICAgLm1hcChleHBlcmltZW50ID0+ICh7XG4gICAgICAgICAgaWQ6IGV4cGVyaW1lbnQuaWQsXG4gICAgICAgICAgdGl0bGU6IGV4cGVyaW1lbnQubmFtZSxcbiAgICAgICAgICBzdWJ0aXRsZTogZ2V0U2hvcnREYXRlU3RyaW5nKG5ldyBEYXRlKGV4cGVyaW1lbnQuc3RhcnRUaW1lKSksXG4gICAgICAgIH0pKTtcbiAgfSxcblxuICBfZ2V0UnVuT3B0aW9ucygpOiB0Zl9kYXNoYm9hcmRfY29tbW9uLkZpbHRlcmFibGVDaGVja2JveExpc3RJdGVtW10ge1xuICAgIHJldHVybiB0aGlzLl9hbGxSdW5zLm1hcChydW4gPT4gKHtpZDogcnVuLCB0aXRsZTogcnVufSkpO1xuICB9LFxuXG4gIF9nZXRFeHBlcmltZW50c1NlbGVjdGlvblN0YXRlKCkge1xuICAgIGNvbnN0IGFsbElkcyA9IHRoaXMuX2FsbEV4cGVyaW1lbnRzLm1hcCgoe2lkfSkgPT4gaWQpO1xuICAgIGNvbnN0IHNlbGVjdGVkSWRzID0gbmV3IFNldCh0aGlzLl9zZWxlY3RlZEV4cGVyaW1lbnRJZHMpO1xuICAgIGNvbnN0IHN0YXRlID0ge307XG4gICAgYWxsSWRzLmZvckVhY2goaWQgPT4gc3RhdGVbaWRdID0gc2VsZWN0ZWRJZHMuaGFzKGlkKSk7XG4gICAgcmV0dXJuIHN0YXRlO1xuICB9LFxuXG4gIF9nZXRSdW5zU2VsZWN0aW9uU3RhdGUoKSB7XG4gICAgY29uc3QgYWxsSWRzID0gdGhpcy5fYWxsUnVucztcbiAgICBjb25zdCBzZWxlY3RlZElkcyA9IG5ldyBTZXQodGhpcy5fc2VsZWN0ZWRSdW5OYW1lcyk7XG4gICAgY29uc3Qgc3RhdGUgPSB7fTtcbiAgICBhbGxJZHMuZm9yRWFjaChpZCA9PiBzdGF0ZVtpZF0gPSBzZWxlY3RlZElkcy5oYXMoaWQpKTtcbiAgICByZXR1cm4gc3RhdGU7XG4gIH0sXG5cbiAgX2NvbXB1dGVTZWxlY3Rpb24oKSB7XG4gICAgY29uc3QgZXhwTWFwID0gbmV3IE1hcCh0aGlzLl9hbGxFeHBlcmltZW50cy5tYXAoZXhwID0+IFtleHAuaWQsIGV4cF0pKTtcbiAgICBjb25zdCBzZWxlY3RlZFJ1bk5hbWVzID0gbmV3IFNldChcbiAgICAgICAgdGhpcy5fc2VsZWN0ZWRSdW5zLm1hcCgoe3RpdGxlfSkgPT4gdGl0bGUpKTtcblxuICAgIGNvbnN0IGNvbXBsZXRlRXhwcyA9IHRoaXMuX3NlbGVjdGVkRXhwZXJpbWVudHNcbiAgICAgICAgLmZpbHRlcigoe2lkfSkgPT4gKHRoaXMuX2V4cFRvUnVuc0FuZFRhZ3MgfHwgbmV3IE1hcCgpKS5oYXMoaWQpKVxuICAgICAgICAubWFwKCh7aWR9KSA9PiBleHBNYXAuZ2V0KGlkKSk7XG5cbiAgICBjb25zdCBzZWxlY3Rpb25zID0gY29tcGxldGVFeHBzLm1hcChleHBlcmltZW50ID0+IHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIGV4cGVyaW1lbnQsXG4gICAgICAgIHJ1bnM6IHRoaXMuX2V4cFRvUnVuc0FuZFRhZ3MuZ2V0KGV4cGVyaW1lbnQuaWQpXG4gICAgICAgICAgICAuZmlsdGVyKHJ1biA9PiBzZWxlY3RlZFJ1bk5hbWVzLmhhcyhydW4ubmFtZSkpLFxuICAgICAgICB0YWdSZWdleDogdGhpcy5fdGFnUmVnZXgsXG4gICAgICB9O1xuICAgIH0pO1xuXG4gICAgcmV0dXJuIHtcbiAgICAgIHR5cGU6IHNlbGVjdGlvbnMubGVuZ3RoID09IDEgP1xuICAgICAgICAgIHRmX2RhdGFfc2VsZWN0b3IuVHlwZS5TSU5HTEUgOiB0Zl9kYXRhX3NlbGVjdG9yLlR5cGUuQ09NUEFSSVNPTixcbiAgICAgIHNlbGVjdGlvbnMsXG4gICAgfTtcbiAgfSxcblxuICBfZmV0Y2hOZXdSdW5zQW5kVGFncygpIHtcbiAgICBjb25zdCBleHBNYXAgPSBuZXcgTWFwKHRoaXMuX2FsbEV4cGVyaW1lbnRzLm1hcChleHAgPT4gW2V4cC5pZCwgZXhwXSkpO1xuICAgIGNvbnN0IGV4cHNUb0ZldGNoID0gdGhpcy5fc2VsZWN0ZWRFeHBlcmltZW50c1xuICAgICAgICAuZmlsdGVyKCh7aWR9KSA9PiAhKHRoaXMuX2V4cFRvUnVuc0FuZFRhZ3MgfHwgbmV3IE1hcCgpKS5oYXMoaWQpKVxuICAgICAgICAubWFwKCh7aWR9KSA9PiBleHBNYXAuZ2V0KGlkKSk7XG5cbiAgICBjb25zdCBmZXRjaGVzID0gZXhwc1RvRmV0Y2gubWFwKGV4cCA9PiB0aGlzLl9mZXRjaFJ1bnNBbmRUYWdzKGV4cCkpO1xuICAgIFByb21pc2UuYWxsKGZldGNoZXMpLnRoZW4ocmVzdWx0cyA9PiB7XG4gICAgICBjb25zdCBuZXdFeHBUb1J1bnNBbmRUYWdzID0gbmV3IE1hcCh0aGlzLl9leHBUb1J1bnNBbmRUYWdzKTtcbiAgICAgIHJlc3VsdHMuZm9yRWFjaCgocnVucywgaW5kZXgpID0+IHtcbiAgICAgICAgY29uc3QgZXhwID0gZXhwc1RvRmV0Y2hbaW5kZXhdO1xuICAgICAgICBuZXdFeHBUb1J1bnNBbmRUYWdzLnNldChleHAuaWQsIHJ1bnMpO1xuICAgICAgfSk7XG4gICAgICB0aGlzLl9leHBUb1J1bnNBbmRUYWdzID0gbmV3RXhwVG9SdW5zQW5kVGFncztcbiAgICB9KTtcbiAgfSxcblxuICBfZmV0Y2hSdW5zQW5kVGFncyhleHA6IHRmX2JhY2tlbmQuRXhwZXJpbWVudCk6IFByb21pc2U8dm9pZD4ge1xuICAgIGNvbnN0IGlkID0gZXhwLmlkO1xuICAgIGNvbnNvbGUuYXNzZXJ0KGlkICE9IG51bGwsICdFeHBlY3RlZCBhbiBleHBlcmltZW50IElkJyk7XG5cbiAgICBjb25zdCB1cmwgPSB0Zl9iYWNrZW5kLmdldFJvdXRlcigpLnJ1bnNGb3JFeHBlcmltZW50KGlkKTtcbiAgICByZXR1cm4gdGhpcy5fcmVxdWVzdE1hbmFnZXIucmVxdWVzdCh1cmwpO1xuICB9LFxuXG59KTtcblxuZnVuY3Rpb24gZ2V0U2hvcnREYXRlU3RyaW5nKGRhdGU6IERhdGUpOiBzdHJpbmcge1xuICByZXR1cm4gZGF0ZS50b0xvY2FsZURhdGVTdHJpbmcodW5kZWZpbmVkLCB7XG4gICAgbW9udGg6ICdsb25nJyxcbiAgICBkYXk6ICdudW1lcmljJyxcbiAgICBob3VyOiAnbnVtZXJpYycsXG4gICAgbWludXRlOiAnbnVtZXJpYycsXG4gICAgc2Vjb25kOiAnbnVtZXJpYycsXG4gIH0pO1xufVxuXG59ICAvLyBuYW1lc3BhY2UgdGZfZGF0YV9zZWxlY3RvclxuIl19