var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
/* Copyright 2015 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the 'License');
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an 'AS IS' BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
/**
 * Package for the Render Hierarchy for TensorFlow graph.
 */
var tf;
(function (tf) {
    var graph;
    (function (graph_1) {
        var render;
        (function (render) {
            /**
             * Color parameters for op nodes.
             */
            render.OpNodeColors = { DEFAULT_FILL: '#ffffff', DEFAULT_STROKE: '#b2b2b2',
                COMPATIBLE: '#0f9d58', INCOMPATIBLE: '#db4437' };
            /**
             * Color parameters for node encoding.
             * @type {Object}
             */
            render.MetanodeColors = {
                /**
                 * Default fill and stroke to use when no other information is available.
                 */
                DEFAULT_FILL: '#d9d9d9',
                DEFAULT_STROKE: '#a6a6a6',
                SATURATION: 0.6,
                LIGHTNESS: 0.85,
                /**
                 * Neutral color to use when the node is expanded (used when coloring by
                 * compute time, memory and device).
                 */
                EXPANDED_COLOR: '#f0f0f0',
                /**
                 * Standard hue values for node color palette.
                 */
                HUES: [220, 100, 180, 40, 20, 340, 260, 300, 140, 60],
                STRUCTURE_PALETTE: function (id, lightened) {
                    // The code below is a flexible way to computationally create a set
                    // of colors that go well together.
                    var hues = render.MetanodeColors.HUES;
                    var n = hues.length;
                    var hue = hues[id % n];
                    var m = Math.sin(hue * Math.PI / 360);
                    var sat = lightened ? 30 : 90 - 60 * m;
                    var light = lightened ? 95 : 80;
                    return d3.hsl(hue, .01 * sat, .01 * light).toString();
                },
                DEVICE_PALETTE: function (index) {
                    return render.MetanodeColors.STRUCTURE_PALETTE(index);
                },
                XLA_CLUSTER_PALETTE: function (index) {
                    return render.MetanodeColors.STRUCTURE_PALETTE(index);
                },
                UNKNOWN: '#eee',
                GRADIENT_OUTLINE: '#888'
            };
            /**
             * Color parameters for op nodes.
             */
            render.SeriesNodeColors = {
                DEFAULT_FILL: 'white',
                DEFAULT_STROKE: '#b2b2b2'
            };
            /**
             * Parameters that affect how the graph is rendered on the screen.
             */
            var PARAMS = {
                /**
                 * Whether to extract high degree nodes from the core part of the graph.
                 */
                enableExtraction: true,
                /**
                 * The minimum number of nodes for a graph to have in order for high in and
                 * out degree nodes to be extracted in auxiliary. The aim here is to prevent
                 * nodes from being extracted from small graphs.
                 */
                minNodeCountForExtraction: 15,
                /**
                 * The minimum in or out degree a node must have in order to be possibly
                 * extracted.
                 */
                minDegreeForExtraction: 5,
                /**
                 * Maximum number of control edges a node can have before they aren't
                 * displayed.
                 */
                maxControlDegree: 4,
                /**
                 * Maximum in (for outbound bridge paths) or out (for inbound bridge paths)
                 * degree of a node allowed for a bridge path to be rendered to it from a
                 * subhierarchy of nodes. Having a max prevents having too many nodes emanate
                 * from a subhierarchy and crowding up.
                 */
                maxBridgePathDegree: 4,
                /**
                 * Types patterns for predefined out-extract nodes, which are
                 * sink-like nodes that will be extracted from the main graph.
                 */
                outExtractTypes: [
                    'NoOp' // NoOps are sink-like used for managing control dependencies.
                ],
                /**
                 * Types patterns for predefined in-extract nodes, which are
                 * source-like nodes that will be extracted from the main graph.
                 */
                inExtractTypes: [],
                /**
                 * When removing edges from a high degree node, remove all of its edges if
                 * detachAllEdgesForHighDegree is true.  Otherwise remove all in-edges if
                 * the node has high in-degree, or all out-edges if the node has high
                 * out-degree.
                 */
                detachAllEdgesForHighDegree: true,
                /**
                 * After extracting high in/out degree nodes and predefined
                 * source-like/sink-like, extract isolated nodes to the side
                 * if this extractIsolatedNodesWithAnnotationsOnOneSide is true.
                 */
                extractIsolatedNodesWithAnnotationsOnOneSide: true,
                /**
                 * Whether to add bridge nodes and edges to the core when building the
                 * subhierarchy of an expanded metanode. See buildSubhierarchy().
                 */
                enableBridgegraph: true,
                /**
                 * 2 colors, for the minimum and maximum value respectively, whenever we
                 * have a gradient scale.
                 */
                minMaxColors: ['#fff5f0', '#fb6a4a'],
                /**
                 * Maximum number of annotations to be displayed on a node before an
                 * ellipsis is used.
                 */
                maxAnnotations: 5
            };
            /**
             * The regular expression to use when parsing for the string that is
             * used to label a function node in the graph. We strip away a prefix
             * indicating that the node represents a function definition. We also
             * remove an arbitrary hexadecimal suffix and the number following it
             * if it is present. To be clear, we extract foo from
             * __function_library__foo_deadb00f_42.
             */
            var nodeDisplayNameRegex = new RegExp('^(?:' + tf.graph.FUNCTION_LIBRARY_NODE_PREFIX +
                ')?(\\w+)_[a-z0-9]{8}(?:_\\d+)?$');
            /**
             * Stores the rendering information, such as x and y coordinates,
             * for each node in the graph.
             */
            var RenderGraphInfo = /** @class */ (function () {
                function RenderGraphInfo(hierarchy, displayingStats) {
                    this.hierarchy = hierarchy;
                    this.displayingStats = displayingStats;
                    this.index = {};
                    this.renderedOpNames = [];
                    this.computeScales();
                    // Maps node name to whether the rendering hierarchy was already
                    // constructed.
                    this.hasSubhierarchy = {};
                    this.root = new RenderGroupNodeInfo(hierarchy.root, hierarchy.graphOptions);
                    this.index[hierarchy.root.name] = this.root;
                    this.renderedOpNames.push(hierarchy.root.name);
                    this.buildSubhierarchy(hierarchy.root.name);
                    this.root.expanded = true;
                    this.traceInputs = false;
                }
                RenderGraphInfo.prototype.computeScales = function () {
                    this.deviceColorMap = d3.scaleOrdinal()
                        .domain(this.hierarchy.devices)
                        .range(_.map(d3.range(this.hierarchy.devices.length), render.MetanodeColors.DEVICE_PALETTE));
                    this.xlaClusterColorMap =
                        d3.scaleOrdinal()
                            .domain(this.hierarchy.xlaClusters)
                            .range(_.map(d3.range(this.hierarchy.xlaClusters.length), render.MetanodeColors.XLA_CLUSTER_PALETTE));
                    var topLevelGraph = this.hierarchy.root.metagraph;
                    // Find the maximum memory usage. Use 0 as the minimum.
                    var maxMemory = d3.max(topLevelGraph.nodes(), function (nodeName, index) {
                        var node = topLevelGraph.node(nodeName);
                        // Some ops don't have stats at all.
                        if (node.stats != null) {
                            return node.stats.totalBytes;
                        }
                    });
                    this.memoryUsageScale = d3.scaleLinear()
                        .domain([0, maxMemory])
                        .range(PARAMS.minMaxColors);
                    // Find the maximum compute time. Use 0 as the minimum.
                    var maxComputeTime = d3.max(topLevelGraph.nodes(), function (nodeName, index) {
                        var node = topLevelGraph.node(nodeName);
                        // Some ops don't have stats at all.
                        if (node.stats != null) {
                            return node.stats.getTotalMicros();
                        }
                    });
                    this.computeTimeScale = d3.scaleLinear()
                        .domain([0, maxComputeTime])
                        .range(PARAMS.minMaxColors);
                    this.edgeWidthSizedBasedScale = this.hierarchy.hasShapeInfo ?
                        graph_1.scene.edge.EDGE_WIDTH_SIZE_BASED_SCALE :
                        d3.scaleLinear()
                            .domain([1, this.hierarchy.maxMetaEdgeSize])
                            .range([graph_1.scene.edge.MIN_EDGE_WIDTH, graph_1.scene.edge.MAX_EDGE_WIDTH]);
                };
                /**
                 * Get a previously created RenderNodeInfo by its node name.
                 */
                RenderGraphInfo.prototype.getRenderNodeByName = function (nodeName) {
                    return this.index[nodeName];
                };
                /**
                 * Get the underlying node in the hierarchical graph by its name.
                 */
                RenderGraphInfo.prototype.getNodeByName = function (nodeName) {
                    return this.hierarchy.node(nodeName);
                };
                RenderGraphInfo.prototype.colorHistogram = function (histogram, colors) {
                    if (Object.keys(histogram).length > 0) {
                        // Compute the total # of items.
                        var numItems_1 = _.sum(Object.keys(histogram).map(function (key) { return histogram[key]; }));
                        return Object.keys(histogram).map(function (key) { return ({
                            color: colors(key),
                            // Normalize to a proportion of total # of items.
                            proportion: histogram[key] / numItems_1,
                        }); });
                    }
                    console.info('no pairs found!');
                    return null;
                };
                /**
                 * Get a previously created RenderNodeInfo for the specified node name,
                 * or create one if it hasn't been created yet.
                 */
                RenderGraphInfo.prototype.getOrCreateRenderNodeByName = function (nodeName) {
                    var _a, _b;
                    // Polymer may invoke this with null.
                    if (!nodeName) {
                        return null;
                    }
                    if (nodeName in this.index) {
                        return this.index[nodeName];
                    }
                    var node = this.hierarchy.node(nodeName);
                    // Exit early if the node does not exist in the hierarchy. This can happen
                    // when a graph is reloaded while the infocard points to a node not visible
                    // at the top-level.
                    if (!node) {
                        return null;
                    }
                    var renderInfo = node.isGroupNode ?
                        new RenderGroupNodeInfo(node, this.hierarchy.graphOptions) :
                        new RenderNodeInfo(node);
                    this.index[nodeName] = renderInfo;
                    this.renderedOpNames.push(nodeName);
                    if (node.stats) {
                        renderInfo.memoryColor = this.memoryUsageScale(node.stats.totalBytes);
                        renderInfo.computeTimeColor =
                            this.computeTimeScale(node.stats.getTotalMicros());
                    }
                    // We only fade nodes when we're displaying stats.
                    renderInfo.isFadedOut = this.displayingStats &&
                        !tf.graph.util.hasDisplayableNodeStats(node.stats);
                    var deviceHistogram = null;
                    var xlaClusterHistogram = null;
                    var opCompatibility = null;
                    if (node.isGroupNode) {
                        deviceHistogram = node.deviceHistogram;
                        xlaClusterHistogram = node.xlaClusterHistogram;
                        var compat = node.compatibilityHistogram.compatible;
                        var incompat = node.compatibilityHistogram.incompatible;
                        if (compat != 0 || incompat != 0) {
                            opCompatibility = compat / (compat + incompat);
                        }
                    }
                    else {
                        var device = renderInfo.node.device;
                        if (device) {
                            deviceHistogram = (_a = {}, _a[device] = 1, _a);
                        }
                        var xlaCluster = renderInfo.node.xlaCluster;
                        if (xlaCluster) {
                            xlaClusterHistogram = (_b = {}, _b[xlaCluster] = 1, _b);
                        }
                        if (renderInfo.node.type === graph_1.NodeType.OP) {
                            opCompatibility = renderInfo.node.compatible ? 1 : 0;
                        }
                    }
                    if (deviceHistogram) {
                        renderInfo.deviceColors =
                            this.colorHistogram(deviceHistogram, this.deviceColorMap);
                    }
                    if (xlaClusterHistogram) {
                        renderInfo.xlaClusterColors =
                            this.colorHistogram(xlaClusterHistogram, this.xlaClusterColorMap);
                    }
                    if (opCompatibility != null) {
                        renderInfo.compatibilityColors = [
                            {
                                color: tf.graph.render.OpNodeColors.COMPATIBLE,
                                proportion: opCompatibility
                            },
                            {
                                color: tf.graph.render.OpNodeColors.INCOMPATIBLE,
                                proportion: 1 - opCompatibility
                            }
                        ];
                    }
                    return this.index[nodeName];
                };
                /**
                 * Return the nearest ancestor node, including itself, that is visible
                 * in the visualization. This method is used so that we can select
                 * (highlight) a node that isn't drawn yet, by selecting (highlighting)
                 * its nearest ancestor that has been drawn.
                 */
                RenderGraphInfo.prototype.getNearestVisibleAncestor = function (name) {
                    var path = graph_1.getHierarchicalPath(name);
                    var i = 0;
                    var renderNode = null;
                    // Fallthrough. If everything was expanded return the node.
                    var nodeName = name;
                    for (; i < path.length; i++) {
                        nodeName = path[i];
                        renderNode = this.getRenderNodeByName(nodeName);
                        // Op nodes have expanded set to false by default.
                        if (!renderNode.expanded) {
                            break;
                        }
                    }
                    // Check case where highlighted node is an embedded node whose parent node
                    // is also its hierarchical parent. In this case, we want to return the
                    // embedded node name, as it is also displayed if its parent has been
                    // displayed.
                    if (i == path.length - 2) {
                        var nextName = path[i + 1];
                        if (renderNode.inAnnotations.nodeNames[nextName]) {
                            return nextName;
                        }
                        if (renderNode.outAnnotations.nodeNames[nextName]) {
                            return nextName;
                        }
                    }
                    return nodeName;
                };
                // TODO: Delete this an any code it touches (all deprecated).
                RenderGraphInfo.prototype.setDepth = function (depth) {
                    setGroupNodeDepth(this.root, +depth);
                };
                /**
                 * Returns true if the renderNode is an isolated node within its parent node.
                 */
                RenderGraphInfo.prototype.isNodeAuxiliary = function (renderNode) {
                    var parentNode = this.getRenderNodeByName(renderNode.node.parentNode.name);
                    var found = _.find(parentNode.isolatedInExtract, function (node) {
                        return node.node.name === renderNode.node.name;
                    });
                    if (found) {
                        return true;
                    }
                    found = _.find(parentNode.isolatedOutExtract, function (node) {
                        return node.node.name === renderNode.node.name;
                    });
                    return !!found;
                };
                /**
                 * Returns a list of ops that have been rendered so far for this graph. More
                 * ops may later be rendered if the user expands nodes for instance. The list
                 * returned here can only stay the same size or grow on successive calls.
                 */
                RenderGraphInfo.prototype.getNamesOfRenderedOps = function () {
                    return this.renderedOpNames;
                };
                /**
                 * Clones an op node and adds it to a metagraph. Does nothing if an op node
                 * with the same new name has already been created within the metagraph. This
                 * method is used when duplicating a library function to be injected within a
                 * metanode representing a function call.
                 * @param parentMetanode The parent metanode on which to add the new node.
                 * @param node The op node to clone.
                 * @param newPrefix The prefix string to use in lieu of the one that merely
                 *     indicates that the metanode represents a function defined in the
                 *     library. This prefix should reflect graph hierarchy.
                 * @return The newly created op node (the clone of the original).
                 */
                RenderGraphInfo.prototype.cloneAndAddFunctionOpNode = function (parentMetanode, libraryFunctionNodeName, node, newPrefix) {
                    var _this = this;
                    var newName = node.name.replace(libraryFunctionNodeName, newPrefix);
                    var newOpNode = parentMetanode.metagraph.node(newName);
                    if (newOpNode) {
                        // This node had already been created and added to the graph.
                        return newOpNode;
                    }
                    // Create a new op node.
                    newOpNode = new graph_1.OpNodeImpl({
                        name: newName,
                        input: [],
                        device: node.device,
                        op: node.op,
                        attr: _.cloneDeep(node.attr),
                    });
                    // Update various properties.
                    newOpNode.cardinality = node.cardinality;
                    newOpNode.include = node.include;
                    newOpNode.outputShapes = _.cloneDeep(node.outputShapes);
                    newOpNode.xlaCluster = node.xlaCluster;
                    newOpNode.functionInputIndex = node.functionInputIndex;
                    newOpNode.functionOutputIndex = node.functionOutputIndex;
                    // Update the inputs of the new node to reflect the new path.
                    newOpNode.inputs = node.inputs.map(function (normalizedInput) {
                        var newNormalizedInput = _.clone(normalizedInput);
                        newNormalizedInput.name = normalizedInput.name.replace(libraryFunctionNodeName, newPrefix);
                        return newNormalizedInput;
                    });
                    // Add the new op node to the hierarchy and metagraph. Also add it to its
                    // parent metanode.
                    newOpNode.parentNode = parentMetanode;
                    parentMetanode.metagraph.setNode(newOpNode.name, newOpNode);
                    this.hierarchy.setNode(newOpNode.name, newOpNode);
                    // Update embeddings.
                    var updateEmbeddingOpNode = function (embeddingNode) {
                        return _this.cloneAndAddFunctionOpNode(parentMetanode, libraryFunctionNodeName, embeddingNode, newPrefix);
                    };
                    newOpNode.inEmbeddings = node.inEmbeddings.map(updateEmbeddingOpNode);
                    newOpNode.outEmbeddings = node.outEmbeddings.map(updateEmbeddingOpNode);
                    return newOpNode;
                };
                /**
                 * Clones a Metanode that represents a function defined in the graph library.
                 * We dynamically inject a clone of a function into a meta graph when the user
                 * expands a function call. We cannot do this at the beginning because the
                 * functions may recursively call themselves or other functions.
                 * @param metagraph The metagraph we are currently rendering the sub-hierarchy
                 *     for.
                 * @param opNodeToReplace The op node in the graph to replace with a new
                 *     (expandable) metanode that visualizes the innards of a function.
                 * @param libraryMetanode The metanode for a library function to clone.
                 * @param oldPrefix The old prefix to replace (that just reflects how this
                 *     node is for a library function).
                 * @param newPrefix The prefix string to use in lieu of the one that merely
                 *     indicates that the metanode represents a function defined in the
                 *     library. This prefix should reflect graph hierarchy.
                 */
                RenderGraphInfo.prototype.cloneFunctionLibraryMetanode = function (metagraph, opNodeToReplace, libraryMetanode, oldPrefix, newPrefix) {
                    // Make a mapping between function output index and the new node for the
                    // output.
                    var functionOutputIndexToNode = {};
                    var newMetanode = this.cloneFunctionLibraryMetanodeHelper(metagraph, opNodeToReplace, libraryMetanode, oldPrefix, newPrefix, functionOutputIndexToNode);
                    if (!_.isEmpty(functionOutputIndexToNode)) {
                        // After we have cloned the edges within the metanode, we still must add
                        // edges that emanate out of output ops within the function.
                        this.patchEdgesFromFunctionOutputs(opNodeToReplace, functionOutputIndexToNode);
                    }
                    return newMetanode;
                };
                /**
                 * A helper subroutine that performs the bulk of the logic for
                 * `cloneFunctionLibraryMetanode`.
                 * @param metagraph The metagraph we are currently rendering the sub-hierarchy
                 *     for.
                 * @param opNodeToReplace The op node in the graph to replace with a new
                 *     (expandable) metanode that visualizes the innards of a function.
                 * @param libraryMetanode The metanode for a library function to clone.
                 * @param oldPrefix The old prefix to replace (that just reflects how this
                 *     node is for a library function).
                 * @param newPrefix The prefix string to use in lieu of the one that merely
                 *     indicates that the metanode represents a function defined in the
                 *     library. This prefix should reflect graph hierarchy.
                 * @param functionOutputIndexToNode A mapping between function output index
                 *     and the corresponding output node. Used to connect outputs with
                 *     destinations outside of the function metanode.
                 */
                RenderGraphInfo.prototype.cloneFunctionLibraryMetanodeHelper = function (metagraph, opNodeToReplace, libraryMetanode, oldPrefix, newPrefix, functionOutputIndexToNode) {
                    var _this = this;
                    var newMetanode = tf.graph.createMetanode(libraryMetanode.name.replace(oldPrefix, newPrefix));
                    // Copy over various properties.
                    newMetanode.depth = libraryMetanode.depth;
                    newMetanode.cardinality = libraryMetanode.cardinality;
                    newMetanode.templateId = libraryMetanode.templateId;
                    newMetanode.opHistogram = _.clone(libraryMetanode.opHistogram);
                    newMetanode.deviceHistogram = _.clone(libraryMetanode.deviceHistogram);
                    newMetanode.xlaClusterHistogram =
                        _.clone(libraryMetanode.xlaClusterHistogram);
                    newMetanode.hasNonControlEdges = libraryMetanode.hasNonControlEdges;
                    newMetanode.include = libraryMetanode.include;
                    newMetanode.nodeAttributes = _.clone(libraryMetanode.nodeAttributes);
                    newMetanode.associatedFunction = libraryMetanode.associatedFunction;
                    // Recursively duplicate the children nodes.
                    _.each(libraryMetanode.metagraph.nodes(), function (nodeName) {
                        var node = libraryMetanode.metagraph.node(nodeName);
                        switch (node.type) {
                            case graph_1.NodeType.META:
                                // Recursively duplicate the metanode.
                                var newNode = _this.cloneFunctionLibraryMetanodeHelper(metagraph, opNodeToReplace, node, oldPrefix, newPrefix, functionOutputIndexToNode);
                                // Add the new node to the graph.
                                newNode.parentNode = newMetanode;
                                newMetanode.metagraph.setNode(newNode.name, newNode);
                                _this.hierarchy.setNode(newNode.name, newNode);
                                break;
                            case graph_1.NodeType.OP:
                                // Duplicate the op node.
                                var newOpNode = _this.cloneAndAddFunctionOpNode(newMetanode, oldPrefix, node, newPrefix);
                                if (_.isNumber(newOpNode.functionInputIndex)) {
                                    // This node represents an input_arg of the library function. Give
                                    // it edges so that its bridge edges are created correctly.
                                    _this.patchEdgesIntoFunctionInputs(opNodeToReplace, newOpNode);
                                }
                                if (_.isNumber(newOpNode.functionOutputIndex)) {
                                    functionOutputIndexToNode[newOpNode.functionOutputIndex] =
                                        newOpNode;
                                }
                                break;
                            default:
                                // This logic should never run because the meta graph should only
                                // contain meta and op nodes.
                                console.warn(node.name + ' is oddly neither a metanode nor an opnode.');
                        }
                    });
                    // Clone the edges within the function library metanode.
                    this.cloneLibraryMetanodeEdges(libraryMetanode, newMetanode, oldPrefix, newPrefix);
                    return newMetanode;
                };
                /**
                 * Clones the edges within `libraryMetanode` and adds them to `newMetanode`.
                 * The names of edge sources and destinations have their prefixes replaced
                 * with new prefixes that reflect their hierarchical positions in the graph
                 * instead of within the function library template. This is a subroutine for
                 * dynamically injecting a function metanode into the graph.
                 */
                RenderGraphInfo.prototype.cloneLibraryMetanodeEdges = function (libraryMetanode, newMetanode, oldPrefix, newPrefix) {
                    _.each(libraryMetanode.metagraph.edges(), function (edgeObject) {
                        var edge = libraryMetanode.metagraph.edge(edgeObject);
                        var newV = edge.v.replace(oldPrefix, newPrefix);
                        var newW = edge.w.replace(oldPrefix, newPrefix);
                        var newMetaEdge = new graph_1.MetaedgeImpl(newV, newW);
                        // Duplicate various properties.
                        newMetaEdge.inbound = edge.inbound;
                        newMetaEdge.numRegularEdges = edge.numRegularEdges;
                        newMetaEdge.numControlEdges = edge.numControlEdges;
                        newMetaEdge.numRefEdges = edge.numRefEdges;
                        newMetaEdge.totalSize = edge.totalSize;
                        if (edge.baseEdgeList) {
                            newMetaEdge.baseEdgeList = edge.baseEdgeList.map(function (baseEdge) {
                                var newBaseEdge = _.clone(baseEdge);
                                newBaseEdge.v = baseEdge.v.replace(oldPrefix, newPrefix);
                                newBaseEdge.w = baseEdge.w.replace(oldPrefix, newPrefix);
                                return newBaseEdge;
                            });
                        }
                        // Set the direction of the edge based on whether it is inbound. The edge
                        // is inbound if its destination is within the metagraph.
                        if (newMetanode.metagraph.node(newW)) {
                            newMetanode.metagraph.setEdge(newV, newW, newMetaEdge);
                        }
                        else {
                            newMetanode.metagraph.setEdge(newW, newV, newMetaEdge);
                        }
                    });
                };
                /**
                 * When a metanode representing a function is cloned and placed into the
                 * graph, we must create edges between inputs into the function call and the
                 * input ops within the function. This function performs that patching.
                 */
                RenderGraphInfo.prototype.patchEdgesIntoFunctionInputs = function (opNodeToReplace, newOpNode) {
                    // If the last few raw inputs are the same node, previous graph logic
                    // collapses them into a single normalized input.
                    var inputIndex = Math.min(newOpNode.functionInputIndex, opNodeToReplace.inputs.length - 1);
                    var newInput = _.clone(opNodeToReplace.inputs[inputIndex]);
                    while (newInput.isControlDependency) {
                        // Ignore control dependencies - they are not assigned to
                        // input_args.
                        inputIndex++;
                        newInput = opNodeToReplace.inputs[inputIndex];
                    }
                    // Clone the normalized input object.
                    newOpNode.inputs.push(newInput);
                    // Update values in the corresponding edge in the high-level
                    // metagraph.
                    var originalMetaEdges = this.hierarchy.getPredecessors(opNodeToReplace.name);
                    // Find the metaedge that the input index corresponds to.
                    // A metaedge may correspond to several edges. For instance,
                    // an edge may enter a series node.
                    var originalMetaEdge;
                    var regularEdgeCount = 0;
                    _.each(originalMetaEdges.regular, function (metaEdge) {
                        regularEdgeCount += metaEdge.numRegularEdges;
                        if (regularEdgeCount > inputIndex) {
                            originalMetaEdge = metaEdge;
                            // Terminate the loop.
                            return false;
                        }
                    });
                    // Also change any base edges that point into the original node to
                    // point to the input arg within the function. These are used to
                    // make bridge edges.
                    _.each(originalMetaEdge.baseEdgeList, function (edge) {
                        if (edge.w === opNodeToReplace.name) {
                            edge.w = newOpNode.name;
                        }
                        if (edge.v === opNodeToReplace.name) {
                            edge.v = newOpNode.name;
                        }
                    });
                };
                /**
                 * When a metanode representing a function is cloned and placed into the
                 * graph, we must create edges between output ops within the new function
                 * metanode to its successors. This function does that after scanning the
                 * successors of the function call.
                 */
                RenderGraphInfo.prototype.patchEdgesFromFunctionOutputs = function (opNodeToReplace, functionOutputIndexToDestinationNode) {
                    var _this = this;
                    // Connect the outputs of the function to other ops.
                    var originalMetaEdges = this.hierarchy.getSuccessors(opNodeToReplace.name);
                    _.each(originalMetaEdges.regular, function (metaedge) {
                        _.each(metaedge.baseEdgeList, function (baseEdge) {
                            // Destination nodes within regular base edges are op nodes.
                            var destinationNode = _this.hierarchy.node(baseEdge.w);
                            _.each(destinationNode.inputs, function (normalizedInput) {
                                // If an output of the function is an input into the op, map it back
                                // to the output within the function so bridge edges are computed.
                                if (normalizedInput.name === opNodeToReplace.name) {
                                    // Map the output tensor index (which in this case is for sure
                                    // numeric because it is an output of a metanode) to the correct
                                    // function output.
                                    var outputNode = functionOutputIndexToDestinationNode[normalizedInput.outputTensorKey];
                                    normalizedInput.name = outputNode.name;
                                    normalizedInput.outputTensorKey = baseEdge.outputTensorKey;
                                }
                            });
                        });
                        // Modify the list of base edges to point from the output so that bridge
                        // edges are correct.
                        _.each(metaedge.baseEdgeList, function (baseEdge) {
                            baseEdge.v =
                                functionOutputIndexToDestinationNode[baseEdge.outputTensorKey].name;
                            baseEdge.outputTensorKey = '0';
                        });
                    });
                };
                RenderGraphInfo.prototype.buildSubhierarchy = function (nodeName) {
                    var _this = this;
                    // Terminate if the rendering hierarchy was already constructed
                    // for this node.
                    if (nodeName in this.hasSubhierarchy) {
                        return;
                    }
                    // Record that we constructed the rendering hierarchy for this node, so we
                    // don't construct it another time.
                    this.hasSubhierarchy[nodeName] = true;
                    var renderNodeInfo = this.index[nodeName];
                    // If it is not a meta node or a series node, don't do anything.
                    if (renderNodeInfo.node.type !== graph_1.NodeType.META &&
                        renderNodeInfo.node.type !== graph_1.NodeType.SERIES) {
                        return;
                    }
                    // At this point we know the rendering information is about a group node.
                    var renderGroupNodeInfo = renderNodeInfo;
                    var metagraph = renderGroupNodeInfo.node.metagraph;
                    var coreGraph = renderGroupNodeInfo.coreGraph;
                    var nodesThatGotCloned = [];
                    var functionCallMetanodesToAdd = [];
                    if (!_.isEmpty(this.hierarchy.libraryFunctions)) {
                        // This graph has library functions. Add them to the current
                        // sub-hierarchy if necessary.
                        _.each(metagraph.nodes(), function (childName) {
                            // Why is this so often undefined?
                            var originalNode = metagraph.node(childName);
                            var libraryFunctionData = _this.hierarchy.libraryFunctions[originalNode.op];
                            if (!libraryFunctionData) {
                                // This node is not a function call.
                                return;
                            }
                            if (childName.indexOf(tf.graph.FUNCTION_LIBRARY_NODE_PREFIX) === 0) {
                                // Do not replace library functions in the graph. The library
                                // functions serve as templates for other nodes.
                                return;
                            }
                            // We later replace the node that is a function call with a copy of the
                            // function metagraph. We do not do so now because we are also looping
                            // through all the nodes.
                            var clonedMetanode = _this.cloneFunctionLibraryMetanode(metagraph, originalNode, libraryFunctionData.node, libraryFunctionData.node.name, originalNode.name);
                            nodesThatGotCloned.push(originalNode);
                            functionCallMetanodesToAdd.push(clonedMetanode);
                        });
                        // Perform node replacement.
                        _.each(functionCallMetanodesToAdd, function (clonedMetanode, i) {
                            var originalNode = nodesThatGotCloned[i];
                            clonedMetanode.parentNode = originalNode.parentNode;
                            metagraph.setNode(originalNode.name, clonedMetanode);
                            _this.hierarchy.setNode(originalNode.name, clonedMetanode);
                        });
                    }
                    // Create render nodes to represent each child from the metagraph. Although
                    // these will initially be added to the coreGraph, they may later be
                    // extracted. Also, due to extraction, the coreGraph may contain disjoint
                    // groups between which there is no visible path (other than annotations).
                    _.each(metagraph.nodes(), function (childName) {
                        var childRenderInfo = _this.getOrCreateRenderNodeByName(childName);
                        var childNode = childRenderInfo.node;
                        coreGraph.setNode(childName, childRenderInfo);
                        if (!childNode.isGroupNode) {
                            _.each(childNode.inEmbeddings, function (embedding) {
                                var renderMetaedgeInfo = new RenderMetaedgeInfo(null);
                                var renderNodeInfo = new RenderNodeInfo(embedding);
                                addInAnnotation(childRenderInfo, embedding, renderNodeInfo, renderMetaedgeInfo, AnnotationType.CONSTANT);
                                _this.index[embedding.name] = renderNodeInfo;
                            });
                            _.each(childNode.outEmbeddings, function (embedding) {
                                var renderMetaedgeInfo = new RenderMetaedgeInfo(null);
                                var renderNodeInfo = new RenderNodeInfo(embedding);
                                addOutAnnotation(childRenderInfo, embedding, renderNodeInfo, renderMetaedgeInfo, AnnotationType.SUMMARY);
                                _this.index[embedding.name] = renderNodeInfo;
                            });
                        }
                    });
                    // Add render metaedge info for edges in the metagraph.
                    _.each(metagraph.edges(), function (edgeObj) {
                        var metaedge = metagraph.edge(edgeObj);
                        var renderMetaedgeInfo = new RenderMetaedgeInfo(metaedge);
                        renderMetaedgeInfo.isFadedOut =
                            _this.index[edgeObj.v].isFadedOut || _this.index[edgeObj.w].isFadedOut;
                        coreGraph.setEdge(edgeObj.v, edgeObj.w, renderMetaedgeInfo);
                    });
                    if (PARAMS.enableExtraction &&
                        renderGroupNodeInfo.node.type === graph_1.NodeType.META) {
                        extractHighDegrees(renderGroupNodeInfo);
                    }
                    // If there are functions, it is possible for metanodes to be dynamically
                    // added later. Construct the hierarchies for nodes that are predecessors to
                    // nodes in the current hierarchy so that edges are drawn correctly.
                    if (!_.isEmpty(this.hierarchy.libraryFunctions)) {
                        this.buildSubhierarchiesForNeededFunctions(metagraph);
                    }
                    if (nodeName === tf.graph.ROOT_NAME) {
                        // Add all metanodes representing library function templates into the
                        // library function scene group for the root node.
                        _.forOwn(this.hierarchy.libraryFunctions, function (libraryFunctionData, functionName) {
                            var node = libraryFunctionData.node;
                            var childRenderInfo = _this.getOrCreateRenderNodeByName(node.name);
                            renderGroupNodeInfo.libraryFunctionsExtract.push(childRenderInfo);
                            // Do not render function definitions in the core graph.
                            childRenderInfo.node.include = graph_1.InclusionType.EXCLUDE;
                            coreGraph.removeNode(node.name);
                        });
                    }
                    // Look up the parent node's render information and short circuit if none.
                    var parentNode = renderGroupNodeInfo.node.parentNode;
                    if (!parentNode) {
                        return;
                    }
                    var parentNodeInfo = this.index[parentNode.name];
                    // Utility function for computing the name of a bridge node.
                    var getBridgeNodeName = function (inbound) {
                        var rest = [];
                        for (var _i = 1; _i < arguments.length; _i++) {
                            rest[_i - 1] = arguments[_i];
                        }
                        return rest.concat([inbound ? 'IN' : 'OUT']).join('~~');
                    };
                    // Build out the bridgegraph.
                    var bridgegraph = this.hierarchy.getBridgegraph(nodeName);
                    // Look for popular nodes so we can make annotations instead of paths.
                    var otherCounts = {
                        // Counts of edges coming INTO other nodes by name (outgoing from self).
                        in: {},
                        // Counts of edges going OUT from other nodes by name (coming into self).
                        out: {},
                        // Counts of all control edges involving other nodes by name.
                        control: {},
                    };
                    _.each(bridgegraph.edges(), function (e) {
                        // An edge is inbound if its destination node is in the metagraph.
                        var inbound = !!metagraph.node(e.w);
                        var otherName = inbound ? e.v : e.w;
                        var metaedge = bridgegraph.edge(e);
                        if (!metaedge.numRegularEdges) {
                            otherCounts.control[otherName] =
                                (otherCounts.control[otherName] || 0) + 1;
                        }
                        else if (inbound) {
                            otherCounts.out[otherName] = (otherCounts.out[otherName] || 0) + 1;
                        }
                        else {
                            otherCounts.in[otherName] = (otherCounts.in[otherName] || 0) + 1;
                        }
                    });
                    // Add annotations and edges for bridgegraph relationships.
                    var hierarchyNodeMap = this.hierarchy.getNodeMap();
                    _.each(bridgegraph.edges(), function (bridgeEdgeObj) {
                        var bridgeMetaedge = bridgegraph.edge(bridgeEdgeObj);
                        // Determine whether this bridge edge is incoming by checking the
                        // metagraph for a node that matches the destination end.
                        var inbound = !!metagraph.node(bridgeEdgeObj.w);
                        // Based on the direction of the edge, one endpoint will be an immediate
                        // child of this renderNodeInfo, and the other endpoint will be a sibling
                        // of the parent (or an ancestor further up).
                        var _a = inbound ?
                            [bridgeEdgeObj.w, bridgeEdgeObj.v] :
                            [bridgeEdgeObj.v, bridgeEdgeObj.w], childName = _a[0], otherName = _a[1];
                        var childRenderInfo = _this.index[childName];
                        var otherRenderInfo = _this.index[otherName];
                        var otherNode = otherRenderInfo ?
                            otherRenderInfo.node :
                            hierarchyNodeMap[otherName];
                        // Determine whether this edge is a control edge between nodes where
                        // either node is high-degree with respect to control edges. This will
                        // be a signal to show it as an annotation instead of a bridge edge.
                        var isHighDegreeControlEdge = !bridgeMetaedge.numRegularEdges &&
                            otherCounts.control[otherName] > PARAMS.maxControlDegree;
                        var _b = inbound ?
                            [renderNodeInfo.inAnnotations, childRenderInfo.inAnnotations] :
                            [renderNodeInfo.outAnnotations, childRenderInfo.outAnnotations], childAnnotations = _b[1];
                        // Don't render a bridge path if the other node has in or out degree above
                        // a threshold, lest bridge paths emanating out of a metagraph crowd up,
                        // as was the case for the Fatcat LSTM lstm_1 > lstm_1 metagraph.
                        var otherDegreeCount = (inbound ? otherCounts.out : otherCounts.in)[otherName];
                        var isOtherHighDegree = otherDegreeCount > PARAMS.maxBridgePathDegree;
                        // The adjoining render metaedge info from the parent's coreGraph, if any.
                        // It will either be a Metaedge involving this node directly, if it
                        // previously came from a metagraph, or it'll be a Metaedge involving
                        // a previously created bridge node standing in for the other node.
                        var adjoiningMetaedge = null;
                        // We can only hope to render a bridge path if:
                        //  - bridgegraph paths are enabled,
                        //  - the other node is not too high-degree,
                        //  - the child is in the core (not extracted for being high-degree), and
                        //  - there's a path (in the traversal sense) between child and other.
                        var canDrawBridgePath = false;
                        if (PARAMS.enableBridgegraph &&
                            !isOtherHighDegree &&
                            !isHighDegreeControlEdge &&
                            childRenderInfo.isInCore()) {
                            // Utility function for finding an adjoining metaedge.
                            var findAdjoiningMetaedge = function (targetName) {
                                var adjoiningEdgeObj = inbound ?
                                    { v: targetName, w: nodeName } :
                                    { v: nodeName, w: targetName };
                                return parentNodeInfo.coreGraph.edge(adjoiningEdgeObj);
                            };
                            adjoiningMetaedge = findAdjoiningMetaedge(otherName);
                            if (!adjoiningMetaedge) {
                                adjoiningMetaedge = findAdjoiningMetaedge(getBridgeNodeName(inbound, otherName, parentNode.name));
                            }
                            canDrawBridgePath = !!adjoiningMetaedge;
                        }
                        // Although dataflow edges are acyclic, control dependency edges may
                        // actually point 'backwards' in the graph. If this bridgeMetaedge is
                        // a control dependency, we need to determine whether it's backwards
                        // pointing so that we render it appropriately.
                        //
                        // For instance, say we're rendering a graph with nodes named A/B and Z/Y,
                        // and we're currently rendering the bridgegraph for A. Further, let's say
                        // that there was an original BaseEdge from A/B->Z/Y and a CONTROL EDGE
                        // from Z/Y=>A/B.
                        //
                        //     +----------------+
                        //     | A              |
                        //     |  +-----+       |         +------+
                        //     |  | B   |>----->|>------->| Z    |
                        //     |  |     |       |         |      |
                        //     |  |     |   *   |         |      |
                        //     |  |     |<=====<|<=======<|      |
                        //     |  +-----+       |         +------+
                        //     +----------------+
                        //
                        // When we render the subhierarchy for Metanode A, we'll come across a
                        // control-only Metaedge in the bridgegraph from Z=>A/B (*). The question
                        // is whether this edge is backwards.
                        //
                        // To answer that question, we follow the chain of adjoining metaedges
                        // until we reach the topmost one. In this case, that's the control-only
                        // Metaedge Z=>A in the ROOT's metagraph. We determine that this edge
                        // is backwards by looking at the topological ordering of ROOT's metagraph
                        // (which ignores control edges) and seeing that Z comes AFTER A.
                        //
                        // The property of being backwards is independent of whether the edge
                        // is inbound or outbound. In the preceding example, if we were building
                        // the subhierarchy for Z, we'd find bridge edge Z/Y=>A, walk to its
                        // topmost adjoining metaedge Z=>A and discover that it's backwards.
                        var backwards = false;
                        if (adjoiningMetaedge && !bridgeMetaedge.numRegularEdges) {
                            // Find the top-most adjoining render metaedge information, and the
                            // GroupNode whose metagraph must contain the associated metaedge.
                            var topAdjoiningMetaedge = adjoiningMetaedge;
                            var topGroupNode = parentNodeInfo.node;
                            while (topAdjoiningMetaedge.adjoiningMetaedge) {
                                topAdjoiningMetaedge = topAdjoiningMetaedge.adjoiningMetaedge;
                                topGroupNode = topGroupNode.parentNode;
                            }
                            // Check against the topological ordering for the top node. The current
                            // bridge metaedge we're evaluating is backwards if its source comes
                            // after its destination.
                            var ordering = _this.hierarchy.getTopologicalOrdering(topGroupNode.name);
                            var e = topAdjoiningMetaedge.metaedge;
                            backwards = ordering[e.v] > ordering[e.w];
                        }
                        // Render backwards control edges as annotations.
                        canDrawBridgePath = canDrawBridgePath && !backwards;
                        // If we can't make a bridge path for any reason, then we add an
                        // annotation instead.
                        if (!canDrawBridgePath) {
                            childAnnotations.push(new Annotation(otherNode, otherRenderInfo, new RenderMetaedgeInfo(bridgeMetaedge), AnnotationType.SHORTCUT, inbound));
                            return;
                        }
                        // At this point, all conditions have been met for drawing a bridge path.
                        // Find or create the IN/OUT node representing otherNode.
                        var bridgeContainerName = getBridgeNodeName(inbound, nodeName);
                        var bridgeNodeName = getBridgeNodeName(inbound, otherName, nodeName);
                        var bridgeNodeRenderInfo = coreGraph.node(bridgeNodeName);
                        if (!bridgeNodeRenderInfo) {
                            // Find or create the directional container for the bridge node.
                            var bridgeContainerInfo = coreGraph.node(bridgeContainerName);
                            if (!bridgeContainerInfo) {
                                var bridgeContainerNode = {
                                    // Important node properties.
                                    name: bridgeContainerName,
                                    type: graph_1.NodeType.BRIDGE,
                                    // Unused node properties.
                                    isGroupNode: false,
                                    cardinality: 0,
                                    parentNode: null,
                                    stats: null,
                                    include: graph_1.InclusionType.UNSPECIFIED,
                                    // BridgeNode properties.
                                    inbound: inbound,
                                    nodeAttributes: {},
                                };
                                bridgeContainerInfo =
                                    new RenderNodeInfo(bridgeContainerNode);
                                _this.index[bridgeContainerName] = bridgeContainerInfo;
                                coreGraph.setNode(bridgeContainerName, bridgeContainerInfo);
                            }
                            var bridgeNode = {
                                // Important node properties.
                                name: bridgeNodeName,
                                type: graph_1.NodeType.BRIDGE,
                                // Unimportant node properties.
                                isGroupNode: false,
                                cardinality: 1,
                                parentNode: null,
                                stats: null,
                                include: graph_1.InclusionType.UNSPECIFIED,
                                // BridgeNode properties.
                                inbound: inbound,
                                nodeAttributes: {},
                            };
                            bridgeNodeRenderInfo = new RenderNodeInfo(bridgeNode);
                            _this.index[bridgeNodeName] = bridgeNodeRenderInfo;
                            coreGraph.setNode(bridgeNodeName, bridgeNodeRenderInfo);
                            // Set bridgeNode to be a graphlib child of the container node.
                            coreGraph.setParent(bridgeNodeName, bridgeContainerName);
                            bridgeContainerInfo.node.cardinality++;
                        }
                        // Create and add a bridge render metaedge.
                        var bridgeRenderMetaedge = new RenderMetaedgeInfo(bridgeMetaedge);
                        bridgeRenderMetaedge.adjoiningMetaedge = adjoiningMetaedge;
                        inbound ?
                            coreGraph.setEdge(bridgeNodeName, childName, bridgeRenderMetaedge) :
                            coreGraph.setEdge(childName, bridgeNodeName, bridgeRenderMetaedge);
                    }); // End _.each(bridgegraph.edges).
                    // For each bridge container (IN and/or OUT), add structural edges between
                    // terminal nodes and that container. A terminal node is one which has no
                    // non-bridge edges in the direction of the container.
                    //
                    // For example, consider a Metanode A which contains two child nodes A/B
                    // and A/C. Let's say it has one edge in the metagraph from A/B->A/C, and
                    // one edge in the bridgegraph from Z->A/C.
                    //
                    // At this point, we've added a container bridge node IN to house all
                    // incoming bridge nodes. We've also added a bridge node Z' (with parent IN)
                    // to A, and a bridge edge from Z'->C.
                    //
                    //     +----------------------+
                    //     | A          +---+     |
                    //     |    +------>| C |     |
                    //     |    |       +---+     |
                    //     |    |         ^       |
                    //     |    |         |       |
                    //     |    |    +----|----+  |
                    //     |    |    | IN |    |  |
                    //     |  +---+  |  +---+  |  |
                    //     |  | B |  |  | Z'|  |  |
                    //     |  +---+  |  +---+  |  |
                    //     |         +---------+  |
                    //     +----------------------+
                    //
                    // With no other help, dagre would lay out B and Z' on the same level,
                    // because both of them have no incoming edges. In other words, B is a
                    // terminal node in the INCOMING direction.
                    //
                    // But we want to force dagre to lay out Z' (and everything in IN) lower
                    // than all non-bridge nodes, so that there's enough room for the bridge
                    // edges after they've been adjusted to meet up with paths coming in from
                    // outside.
                    //
                    // To force Z' (and all other bridge nodes) to be lowest in the graph, we
                    // identify terminal nodes like B and give them structural edges to
                    // a new structural bridge node S which we add to IN.
                    //
                    //     +----------------------+
                    //     | A          +---+     |
                    //     |       +--->| C |     |
                    //     |       |    +---+     |
                    //     |     +---+    ^       |
                    //     |     | B |    |       |
                    //     |     +---+    |       |
                    //     |       ^      |       |
                    //     |       |      |       |
                    //     |  +----|------|----+  |
                    //     |  |IN  |      |    |  |
                    //     |  |  +---+  +---+  |  |
                    //     |  |  | S |  | Z'|  |  |
                    //     |  |  +---+  +---+  |  |
                    //     |  +----------------+  |
                    //     +----------------------+
                    //
                    // This ensures that dagre will lay out the bridge containers strictly at
                    // the ends of the graph. The structural edges will never be seen in the
                    // visualization except as a debugging aid.
                    _.each([true, false], function (inbound) {
                        var bridgeContainerName = getBridgeNodeName(inbound, nodeName);
                        var bridgeContainerInfo = coreGraph.node(bridgeContainerName);
                        if (!bridgeContainerInfo) {
                            return;
                        }
                        _.each(coreGraph.nodes(), function (childName) {
                            // Short-circuit if this child is a bridge node or it's not a terminal
                            // node in the direction we're interested in.
                            var childNodeInfo = coreGraph.node(childName);
                            if (childNodeInfo.node.type === graph_1.NodeType.BRIDGE) {
                                return;
                            }
                            var isTerminal = inbound ?
                                !coreGraph.predecessors(childName).length :
                                !coreGraph.successors(childName).length;
                            if (!isTerminal) {
                                return;
                            }
                            // Find or create a bridge node in the container for all structural
                            // metaedges. It would have been nice to skip this step and simply
                            // set a metaedge between the terminal node and the container node, but
                            // in that case, something about the graph upsets dagre.layout()'s
                            // longestPath algorithm (was getting errors due to an undefined).
                            var structuralNodeName = getBridgeNodeName(inbound, nodeName, 'STRUCTURAL_TARGET');
                            var structuralRenderInfo = coreGraph.node(structuralNodeName);
                            if (!structuralRenderInfo) {
                                var bridgeNode = {
                                    // Important Node properties.
                                    name: structuralNodeName,
                                    type: graph_1.NodeType.BRIDGE,
                                    // Unimportant Node properties.
                                    isGroupNode: false,
                                    cardinality: 1,
                                    parentNode: null,
                                    stats: null,
                                    include: graph_1.InclusionType.UNSPECIFIED,
                                    // BridgeNode properties.
                                    inbound: inbound,
                                    nodeAttributes: {},
                                };
                                structuralRenderInfo = new RenderNodeInfo(bridgeNode);
                                structuralRenderInfo.structural = true;
                                _this.index[structuralNodeName] = structuralRenderInfo;
                                coreGraph.setNode(structuralNodeName, structuralRenderInfo);
                                bridgeContainerInfo.node.cardinality++;
                                coreGraph.setParent(structuralNodeName, bridgeContainerName);
                            }
                            // Create the structural Metaedge and insert it.
                            var structuralMetaedgeInfo = new RenderMetaedgeInfo(null);
                            structuralMetaedgeInfo.structural = true;
                            structuralMetaedgeInfo.weight--; // Reduce weight for dagre layout.
                            inbound ?
                                coreGraph.setEdge(structuralNodeName, childName, structuralMetaedgeInfo) :
                                coreGraph.setEdge(childName, structuralNodeName, structuralMetaedgeInfo);
                        });
                    });
                };
                /**
                 * This method builds subhierarchies for function calls that are needed for
                 * rendering edges in the current subhierarchy being built.
                 *
                 * When building subhierarchies for a metagraph M, the subhierarchies of
                 * metanodes containing endpoint nodes for edges within metagraph M must
                 * already be built. Otherwise, bridge edges will be missing from the graph.
                 */
                RenderGraphInfo.prototype.buildSubhierarchiesForNeededFunctions = function (metagraph) {
                    var _this = this;
                    _.each(metagraph.edges(), function (edgeObj) {
                        var metaedge = metagraph.edge(edgeObj);
                        var renderMetaedgeInfo = new RenderMetaedgeInfo(metaedge);
                        _.forEach(renderMetaedgeInfo.metaedge.baseEdgeList, function (baseEdge) {
                            var sourcePathList = baseEdge.v.split(tf.graph.NAMESPACE_DELIM);
                            for (var i = sourcePathList.length; i >= 0; i--) {
                                var fromBeginningPathList = sourcePathList.slice(0, i);
                                var node = _this.hierarchy.node(fromBeginningPathList.join(tf.graph.NAMESPACE_DELIM));
                                if (node) {
                                    if (node.type === graph_1.NodeType.OP &&
                                        _this.hierarchy.libraryFunctions[node.op]) {
                                        for (var j = 1; j < fromBeginningPathList.length; j++) {
                                            // Expand all hierarchies including the parent.
                                            var currentNodeName = fromBeginningPathList
                                                .slice(0, j).join(tf.graph.NAMESPACE_DELIM);
                                            if (!currentNodeName) {
                                                continue;
                                            }
                                            // Build the hierarchy for this current level.
                                            _this.buildSubhierarchy(currentNodeName);
                                        }
                                    }
                                    // No need to analyze the other higher hierarchies.
                                    break;
                                }
                            }
                        });
                    });
                };
                return RenderGraphInfo;
            }());
            render.RenderGraphInfo = RenderGraphInfo;
            /**
             * A class for rendering annotation object which contains label
             * about the node embedded as annotation, type of annotation and the location
             * of both the annotation's node and edge.
             *
             * Annotation objects include embedded constants, embedded summary, and
             * edge shortcuts.
             */
            var Annotation = /** @class */ (function () {
                /**
                 * Creates a new Annotation.
                 *
                 * @param node The underlying node this annotation points to.
                 * @param renderNodeInfo The render information for the underlying node
                 *     this annotation points to. This can be null if the annotation
                 *     denotes an embedding (constant, summary), in which case we
                 *     use the node property.
                 * @param renderMetaedgeInfo The render information for the edge associated
                 *     with the annotation.
                 * @param type The type of the annotation.
                 * @param isIn True if it is an in-annotation. False if it is an
                 *     out-annotation.
                 */
                function Annotation(node, renderNodeInfo, renderMetaedgeInfo, type, isIn) {
                    this.node = node;
                    this.renderNodeInfo = renderNodeInfo;
                    this.renderMetaedgeInfo = renderMetaedgeInfo;
                    this.annotationType = type;
                    // Properties specified by layout
                    this.dx = 0;
                    this.dy = 0;
                    this.width = 0;
                    this.height = 0;
                    // Properties needed for generating an ID for the edge's path element if
                    // this annotation is associated with a metaedge.
                    if (renderMetaedgeInfo && renderMetaedgeInfo.metaedge) {
                        this.v = renderMetaedgeInfo.metaedge.v;
                        this.w = renderMetaedgeInfo.metaedge.w;
                    }
                    this.isIn = isIn;
                    this.points = [];
                }
                return Annotation;
            }());
            render.Annotation = Annotation;
            ;
            var AnnotationType;
            (function (AnnotationType) {
                AnnotationType[AnnotationType["SHORTCUT"] = 0] = "SHORTCUT";
                AnnotationType[AnnotationType["CONSTANT"] = 1] = "CONSTANT";
                AnnotationType[AnnotationType["SUMMARY"] = 2] = "SUMMARY";
                AnnotationType[AnnotationType["ELLIPSIS"] = 3] = "ELLIPSIS";
            })(AnnotationType = render.AnnotationType || (render.AnnotationType = {}));
            ;
            /**
             * Manages a list of annotations. Two will be used for each
             * RenderNodeInfo, one for in annotations and one for out annotations.
             */
            var AnnotationList = /** @class */ (function () {
                function AnnotationList() {
                    this.list = [];
                    this.nodeNames = {};
                }
                /**
                 * Append an annotation to the list, or a stand-in ellipsis annotation instead
                 * if this would make it too many.
                 */
                AnnotationList.prototype.push = function (annotation) {
                    if (annotation.node.name in this.nodeNames) {
                        return; // Skip duplicate annotation.
                    }
                    this.nodeNames[annotation.node.name] = true;
                    if (this.list.length < PARAMS.maxAnnotations) {
                        this.list.push(annotation);
                        return;
                    }
                    var lastAnnotation = this.list[this.list.length - 1];
                    if (lastAnnotation.annotationType === AnnotationType.ELLIPSIS) {
                        var ellipsisNode_1 = lastAnnotation.node;
                        ellipsisNode_1.setNumMoreNodes(++ellipsisNode_1.numMoreNodes);
                        return;
                    }
                    var ellipsisNode = new tf.graph.EllipsisNodeImpl(1);
                    this.list.push(new Annotation(ellipsisNode, new RenderNodeInfo(ellipsisNode), null, AnnotationType.ELLIPSIS, annotation.isIn));
                };
                return AnnotationList;
            }());
            render.AnnotationList = AnnotationList;
            /**
             * Contains rendering information about a node in the hierarchical graph.
             */
            var RenderNodeInfo = /** @class */ (function () {
                function RenderNodeInfo(node) {
                    this.node = node;
                    this.expanded = false;
                    this.inAnnotations = new AnnotationList();
                    this.outAnnotations = new AnnotationList();
                    // Params specified by layout
                    this.x = 0;
                    this.y = 0;
                    this.width = 0;
                    this.height = 0;
                    this.inboxWidth = 0;
                    this.outboxWidth = 0;
                    this.excluded = false;
                    // Params for bridge paths.
                    this.structural = false;
                    // Params for node box.
                    this.labelOffset = 0;
                    this.radius = 0;
                    // Params for expanded node
                    this.labelHeight = 0;
                    this.paddingTop = 0;
                    this.paddingLeft = 0;
                    this.paddingRight = 0;
                    this.paddingBottom = 0;
                    this.isInExtract = false;
                    this.isOutExtract = false;
                    this.coreBox = { width: 0, height: 0 };
                    // By default, we don't fade nodes out. Default to false for safety.
                    this.isFadedOut = false;
                    // Only use the portion beyond the last delimiter as the display
                    // name.
                    this.displayName = node.name.substring(node.name.lastIndexOf(tf.graph.NAMESPACE_DELIM) + 1);
                    if (node.type === graph_1.NodeType.META &&
                        node.associatedFunction) {
                        // Function names are suffixed with a length-8 hexadecimal string
                        // followed by an optional number. We remove that suffix because
                        // the user did not generate that suffix. That suffix merely
                        // serves to differentiate between functions with different
                        // signatures but the same name otherwise.
                        // Furthermore, we remove the prefix that merely ascertains this
                        // node as a function definition. There is no reason for the user
                        // to see that in the graph, as the node would already be within
                        // the functions scene group.
                        var match = this.displayName.match(nodeDisplayNameRegex);
                        if (match) {
                            // The display name had been successfully extracted. This is the most
                            // common scenario.
                            this.displayName = match[1];
                        }
                        else if (_.startsWith(this.displayName, tf.graph.FUNCTION_LIBRARY_NODE_PREFIX)) {
                            // The string does not match the usual pattern for how functions are
                            // named. Just use the entire second portion of the string as the name
                            // if we can successfully remove the prefix.
                            this.displayName = this.displayName.substring(tf.graph.FUNCTION_LIBRARY_NODE_PREFIX.length);
                        }
                    }
                }
                RenderNodeInfo.prototype.isInCore = function () {
                    return !this.isInExtract && !this.isOutExtract && !this.isLibraryFunction;
                };
                return RenderNodeInfo;
            }());
            render.RenderNodeInfo = RenderNodeInfo;
            /**
             * Contains rendering information about a Metaedge from the underlying
             * hierarchical graph. It may be from either a metagraph or a bridgegraph.
             */
            var RenderMetaedgeInfo = /** @class */ (function () {
                function RenderMetaedgeInfo(metaedge) {
                    this.metaedge = metaedge;
                    this.adjoiningMetaedge = null;
                    this.structural = false;
                    this.weight = 1;
                    this.isFadedOut = false;
                }
                return RenderMetaedgeInfo;
            }());
            render.RenderMetaedgeInfo = RenderMetaedgeInfo;
            function addInAnnotation(node, predecessor, predecessorRenderInfo, edge, type) {
                var annotation = new Annotation(predecessor, predecessorRenderInfo, edge, type, true);
                node.inAnnotations.push(annotation);
            }
            function addOutAnnotation(node, successor, successorRenderInfo, edge, type) {
                var annotation = new Annotation(successor, successorRenderInfo, edge, type, false);
                node.outAnnotations.push(annotation);
            }
            function setGraphDepth(graph, depth) {
                _.each(graph.nodes(), function (nodeName) {
                    var child = graph.node(nodeName);
                    child.expanded = depth > 1; // set all child of depth 1 to collapsed
                    if (depth > 0) {
                        switch (child.node.type) {
                            case graph_1.NodeType.META:
                            case graph_1.NodeType.SERIES:
                                setGroupNodeDepth(child, depth - 1);
                                break;
                            // Do nothing for leaf
                        }
                    }
                });
            }
            ;
            var RenderGroupNodeInfo = /** @class */ (function (_super) {
                __extends(RenderGroupNodeInfo, _super);
                function RenderGroupNodeInfo(groupNode, graphOptions) {
                    var _this = _super.call(this, groupNode) || this;
                    var metagraph = groupNode.metagraph;
                    var gl = metagraph.graph();
                    graphOptions.compound = true;
                    _this.coreGraph =
                        graph_1.createGraph(gl.name, graph_1.GraphType.CORE, graphOptions);
                    _this.inExtractBox = { width: 0, height: 0 };
                    _this.outExtractBox = { width: 0, height: 0 };
                    _this.libraryFunctionsBox = { width: 0, height: 0 };
                    _this.isolatedInExtract = [];
                    _this.isolatedOutExtract = [];
                    _this.libraryFunctionsExtract = [];
                    return _this;
                }
                return RenderGroupNodeInfo;
            }(RenderNodeInfo));
            render.RenderGroupNodeInfo = RenderGroupNodeInfo;
            function setGroupNodeDepth(renderInfo, depth) {
                if (renderInfo.coreGraph) {
                    setGraphDepth(renderInfo.coreGraph, depth);
                }
            }
            /**
             * Remove an edge from the graph and add annotations to both ends of the edge.
             *
             * @param The core graph.
             * @param v Source name.
             * @param w Sink name.
             */
            function createShortcut(graph, v, w) {
                var src = graph.node(v);
                var sink = graph.node(w);
                var edge = graph.edge(v, w);
                // If either of the nodes is explicitly included in the main graph and
                // both nodes are in the main graph then do not create the shortcut
                // and instead keep the real edge.
                if ((src.node.include === graph_1.InclusionType.INCLUDE ||
                    sink.node.include === graph_1.InclusionType.INCLUDE) &&
                    src.node.include !== graph_1.InclusionType.EXCLUDE &&
                    sink.node.include !== graph_1.InclusionType.EXCLUDE) {
                    return;
                }
                // Add each annotation.
                addOutAnnotation(src, sink.node, sink, edge, AnnotationType.SHORTCUT);
                addInAnnotation(sink, src.node, src, edge, AnnotationType.SHORTCUT);
                // Remove the edge from the core graph.
                graph.removeEdge(v, w);
            }
            /**
             * Remove edges from a node, and set its isOutExtract property to true,
             * and remove the node and move it to isolatedOutExtract.
             *
             * If detachAllEdgesForHighDegree or forceDetach is true, extract all of its
             * edges. Otherwise, only extract all in-edges.
             */
            function makeOutExtract(renderNode, n, forceDetach) {
                var graph = renderNode.coreGraph;
                var child = graph.node(n);
                child.isOutExtract = true;
                _.each(graph.predecessors(n), function (p, index) {
                    createShortcut(graph, p, n);
                });
                if (PARAMS.detachAllEdgesForHighDegree || forceDetach) {
                    _.each(graph.successors(n), function (s, index) {
                        createShortcut(graph, n, s);
                    });
                }
                // Remove the node from the core graph if it no longer has neighbors.
                if (graph.neighbors(n).length === 0) {
                    child.node.include = graph_1.InclusionType.EXCLUDE;
                    renderNode.isolatedOutExtract.push(child);
                    graph.removeNode(n);
                }
            }
            /**
             * Remove edges from a node, set its isInExtract property to true,
             * and remove the node and move it to isolatedInExtract.
             *
             * If detachAllEdgesForHighDegree or forceDetach is true, extract all of its
             * edges. Otherwise, only remove all out-edges.
             */
            function makeInExtract(renderNode, n, forceDetach) {
                var graph = renderNode.coreGraph;
                var child = graph.node(n);
                child.isInExtract = true;
                _.each(graph.successors(n), function (s, index) {
                    createShortcut(graph, n, s);
                });
                if (PARAMS.detachAllEdgesForHighDegree || forceDetach) {
                    _.each(graph.predecessors(n), function (p, index) {
                        createShortcut(graph, p, n);
                    });
                }
                // Remove the node from the core graph if it no longer has neighbors.
                if (graph.neighbors(n).length === 0) {
                    child.node.include = graph_1.InclusionType.EXCLUDE;
                    renderNode.isolatedInExtract.push(child);
                    graph.removeNode(n);
                }
            }
            render.makeInExtract = makeInExtract;
            /**
             * Check whether the node's type is a member of the given list of types.
             *
             * @param node Node.
             * @param types List of type to match.
             */
            function hasTypeIn(node, types) {
                if (node.type === graph_1.NodeType.OP) {
                    for (var i = 0; i < types.length; i++) {
                        if (node.op === types[i]) {
                            return true;
                        }
                    }
                }
                else if (node.type === graph_1.NodeType.META) {
                    var rootOpNode = node.getRootOp();
                    if (rootOpNode) {
                        for (var i = 0; i < types.length; i++) {
                            if (rootOpNode.op === types[i]) {
                                return true;
                            }
                        }
                    }
                }
                return false;
            }
            /** Move nodes that are specified to be excluded out of the core graph. */
            function extractSpecifiedNodes(renderNode) {
                var graph = renderNode.coreGraph;
                _.each(graph.nodes(), function (n) {
                    var renderInfo = graph.node(n);
                    if (renderInfo.node.include === graph_1.InclusionType.EXCLUDE &&
                        !n.startsWith(tf.graph.FUNCTION_LIBRARY_NODE_PREFIX)) {
                        // Move the node if the node is excluded and not part of the library
                        // function scene group, which contains nodes that do not represent ops in
                        // the graph and should thus never have its nodes added to the core graph.
                        if (renderNode.coreGraph.outEdges(n).length >
                            renderNode.coreGraph.inEdges(n).length) {
                            makeOutExtract(renderNode, n, true);
                        }
                        else {
                            makeInExtract(renderNode, n, true);
                        }
                    }
                });
            }
            /** Remove edges from pre-defined out-extract patterns */
            function extractPredefinedSink(renderNode) {
                var graph = renderNode.coreGraph;
                _.each(graph.nodes(), function (n) {
                    var renderInfo = graph.node(n);
                    if (renderInfo.node.include !== graph_1.InclusionType.UNSPECIFIED) {
                        return;
                    }
                    if (hasTypeIn(renderInfo.node, PARAMS.outExtractTypes)) {
                        makeOutExtract(renderNode, n);
                    }
                });
            }
            /** Remove edges from pre-defined in-extract patterns */
            function extractPredefinedSource(renderNode) {
                var graph = renderNode.coreGraph;
                _.each(graph.nodes(), function (n) {
                    var renderInfo = graph.node(n);
                    if (renderInfo.node.include !== graph_1.InclusionType.UNSPECIFIED) {
                        return;
                    }
                    if (hasTypeIn(renderInfo.node, PARAMS.inExtractTypes)) {
                        makeInExtract(renderNode, n);
                    }
                });
            }
            /** Extract nodes deemed to have either high in-degree or high out-degree. */
            function extractHighInOrOutDegree(renderNode) {
                var graph = renderNode.coreGraph;
                // Create mappings from node to in and out degrees. Count the number of valid
                // nodes along the way.
                var nodeToInDegree = {};
                var nodeToOutDegree = {};
                var validNodeCount = 0;
                _.each(graph.nodes(), function (currentNode) {
                    if (graph.node(currentNode).node.include !== graph_1.InclusionType.UNSPECIFIED) {
                        // This node is not included in the first place.
                        return;
                    }
                    // Count the in and out degrees based on only regular edges, unless there
                    // are no regular edges, in which case use the number of control edges.
                    // This is done so that control edges don't affect if nodes are extracted
                    // from the core graph, unless the node is only used for control.
                    var inDegree = _.reduce(graph.predecessors(currentNode), function (inDegree, pred) {
                        var metaedge = graph.edge(pred, currentNode).metaedge;
                        return inDegree + (metaedge.numRegularEdges ? 1 : 0);
                    }, 0);
                    if (inDegree === 0 && graph.predecessors(currentNode).length > 0) {
                        inDegree = graph.predecessors(currentNode).length;
                    }
                    var outDegree = _.reduce(graph.successors(currentNode), function (outDegree, succ) {
                        var metaedge = graph.edge(currentNode, succ).metaedge;
                        return outDegree + (metaedge.numRegularEdges ? 1 : 0);
                    }, 0);
                    if (outDegree === 0 && graph.successors(currentNode).length > 0) {
                        outDegree = graph.successors(currentNode).length;
                    }
                    // Store the in and out degrees of this node to avoid recomputing.
                    nodeToInDegree[currentNode] = inDegree;
                    nodeToOutDegree[currentNode] = outDegree;
                    validNodeCount++;
                });
                if (validNodeCount < PARAMS.minNodeCountForExtraction) {
                    // This graph has few nodes. Do not extract any nodes.
                    return;
                }
                // We only extract if the node has a min in or out degree greater than this.
                var minUpperBound = PARAMS.minDegreeForExtraction - 1;
                // Mark for extraction nodes with in-degree > Q3 + (Q3 - Q1).
                var q3Index = Math.round(validNodeCount * 0.75);
                var q1Index = Math.round(validNodeCount * 0.25);
                var sortedByInDegree = Object.keys(nodeToInDegree).sort(function (node0, node1) {
                    return nodeToInDegree[node0] - nodeToInDegree[node1];
                });
                var inDegreeQ3 = nodeToInDegree[sortedByInDegree[q3Index]];
                var inDegreeQ1 = nodeToInDegree[sortedByInDegree[q1Index]];
                var inDegreeUpperBound = inDegreeQ3 + inDegreeQ3 - inDegreeQ1;
                // Only extract if the upper bound is high enough.
                inDegreeUpperBound = Math.max(inDegreeUpperBound, minUpperBound);
                for (var i = validNodeCount - 1; nodeToInDegree[sortedByInDegree[i]] > inDegreeUpperBound; i--) {
                    // Extract a high in-degree node.
                    makeInExtract(renderNode, sortedByInDegree[i]);
                }
                // Mark for extraction nodes with out-degree > Q3 + (Q3 - Q1) * 4.
                var sortedByOutDegree = Object.keys(nodeToOutDegree).sort(function (node0, node1) {
                    return nodeToOutDegree[node0] - nodeToOutDegree[node1];
                });
                var outDegreeQ3 = nodeToOutDegree[sortedByOutDegree[q3Index]];
                var outDegreeQ1 = nodeToOutDegree[sortedByOutDegree[q1Index]];
                // The upper bound for extracting out-degree nodes is higher than that for
                // extracting in-degree ones (Note the "* 4") because, in practice, some
                // graphs look worse with a smaller out-degree bound. For instance, a smaller
                // out-degree bound removes the convolution nodes from cifar 10 train's graph.
                var outDegreeUpperBound = outDegreeQ3 + (outDegreeQ3 - outDegreeQ1) * 4;
                // Only extract if the upper bound is high enough.
                outDegreeUpperBound = Math.max(outDegreeUpperBound, minUpperBound);
                for (var i = validNodeCount - 1; nodeToOutDegree[sortedByOutDegree[i]] > outDegreeUpperBound; i--) {
                    var node = graph.node(sortedByOutDegree[i]);
                    if (!node || node.isInExtract) {
                        // This node has already been extracted due to high in-degree. It might
                        // have been removed from the graph in general (during in-degree
                        // extraction) due to a lack of neighbors. Do not extract this node twice.
                        continue;
                    }
                    // Extract a high out-degree node that has not already been extracted.
                    makeOutExtract(renderNode, sortedByOutDegree[i]);
                }
            }
            /** Remove control edges from nodes that have too many control edges */
            function removeControlEdges(renderNode) {
                var graph = renderNode.coreGraph;
                // Collect control edges into a map by node name.
                var map = {};
                _.each(graph.edges(), function (e) {
                    if (!graph.edge(e).metaedge.numRegularEdges) {
                        (map[e.v] = map[e.v] || []).push(e);
                        (map[e.w] = map[e.w] || []).push(e);
                    }
                });
                // For each node with too many control edges, turn them into annotations.
                _.each(map, function (edges, nodeName) {
                    if (edges.length > PARAMS.maxControlDegree) {
                        _.each(edges, function (e) { return createShortcut(graph, e.v, e.w); });
                    }
                });
            }
            /**
             * Given an integer, picks a hue that is far apart from other colors.
             * The formula for picking color that avoid collision is:
             *     hue = (color range * golden ratio * index) % color range
             */
            function mapIndexToHue(id) {
                var GOLDEN_RATIO = 1.61803398875;
                // Hue of 0 is reserved for the gray nodes.
                var MIN_HUE = 1;
                var MAX_HUE = 359;
                var COLOR_RANGE = MAX_HUE - MIN_HUE;
                return MIN_HUE + ((COLOR_RANGE * GOLDEN_RATIO * id) % COLOR_RANGE);
            }
            render.mapIndexToHue = mapIndexToHue;
            ;
            /**
             * Remove edges and add to annotation instead.
             *
             * For root node, consider predefined types for source and sink.
             * We do not extract predefined type from non-root so that Variables and the
             * sgd node (op type = 'NoOp') do not get extract from inside own group.
             *
             * The order of extraction is important here as swapping the order can totally
             * screw up the graph layout.
             *
             * @param {Render.Node} renderNode Node to manipulate.
             */
            function extractHighDegrees(renderNode) {
                extractSpecifiedNodes(renderNode);
                if (PARAMS.outExtractTypes) {
                    extractPredefinedSink(renderNode);
                }
                // This has to come before extract high in-degree to protect the core part
                // that takes many variables.
                if (PARAMS.inExtractTypes) {
                    extractPredefinedSource(renderNode);
                }
                extractHighInOrOutDegree(renderNode);
                if (PARAMS.maxControlDegree) {
                    removeControlEdges(renderNode);
                }
                // Extract isolated nodes, which can be
                // (1) source-like and sink-like nodes that are not originally isolated but
                //     become isolated after further removal.
                // (2) isolated nodes with annotations on one-side.  These might be either
                //     - nodes that originally have high out-degree but because we remove
                //       high in-degree nodes first, they no longer have high in-degree when
                //       we check.  (Detecting all high-degree before removing also leads to
                //       another problem.)
                //     - nodes that do not have high degree, but their neighbors are all
                //       extracted, so it might make sense to extract them too.
                var graph = renderNode.coreGraph;
                _.each(graph.nodes(), function (n) {
                    var child = graph.node(n);
                    var degree = graph.neighbors(n).length;
                    if (child.node.include !== graph_1.InclusionType.UNSPECIFIED) {
                        return;
                    }
                    if (degree === 0) {
                        var hasOutAnnotations = child.outAnnotations.list.length > 0;
                        var hasInAnnotations = child.inAnnotations.list.length > 0;
                        if (child.isInExtract) { // Is source-like.
                            // This case only happens if detachAllEdgesForHighDegree is false.
                            // (Otherwise all source-like nodes are all isolated already.)
                            renderNode.isolatedInExtract.push(child);
                            child.node.include = graph_1.InclusionType.EXCLUDE;
                            graph.removeNode(n);
                        }
                        else if (child.isOutExtract) { // Is sink-like.
                            // This case only happens if detachAllEdgesForHighDegree is false.
                            // // (Otherwise all sink-like nodes are all isolated already.)
                            renderNode.isolatedOutExtract.push(child);
                            child.node.include = graph_1.InclusionType.EXCLUDE;
                            graph.removeNode(n);
                        }
                        else if (PARAMS.extractIsolatedNodesWithAnnotationsOnOneSide) {
                            if (hasOutAnnotations && !hasInAnnotations) {
                                child.isInExtract = true; // for ones with high out-annotations
                                renderNode.isolatedInExtract.push(child);
                                child.node.include = graph_1.InclusionType.EXCLUDE;
                                graph.removeNode(n);
                            }
                            else if (hasInAnnotations && !hasOutAnnotations) {
                                child.isOutExtract = true; // for ones with high in-annotations
                                renderNode.isolatedOutExtract.push(child);
                                child.node.include = graph_1.InclusionType.EXCLUDE;
                                graph.removeNode(n);
                            }
                            else {
                                // if a low degree node has both in- & out- annotations, do nothing
                                // because it is unclear which side it should go to.
                            }
                        }
                    }
                });
            }
            /**
             * Expands nodes in the graph until the desired node is visible.
             *
             * @param scene The scene polymer component.
             * @param renderHierarchy The render hierarchy.
             * @param tensorName The name of a tensor.
             * @return A string that is the name of the node representing the given tensor.
             *     Note that the original tensor name might differ from this returned node
             *     name. Specifically, for instance, the tensor name usually ends with an
             *     output slot index (such as :0), while the node name lacks that suffix.
             */
            function expandUntilNodeIsShown(scene, renderHierarchy, tensorName) {
                var splitTensorName = tensorName.split('/');
                // Graph names do not take into account the output slot. Strip it.
                var lastNodeNameMatch = splitTensorName[splitTensorName.length - 1].match(/(.*):\w+/);
                if (lastNodeNameMatch.length === 2) {
                    splitTensorName[splitTensorName.length - 1] = lastNodeNameMatch[1];
                }
                var nodeName = splitTensorName[0];
                var renderNode = renderHierarchy.getRenderNodeByName(nodeName);
                for (var i = 1; i < splitTensorName.length; i++) {
                    // Op nodes are not expandable.
                    if (renderNode.node.type === tf.graph.NodeType.OP) {
                        break;
                    }
                    renderHierarchy.buildSubhierarchy(nodeName);
                    renderNode.expanded = true;
                    scene.setNodeExpanded(renderNode);
                    nodeName += '/' + splitTensorName[i];
                    renderNode = renderHierarchy.getRenderNodeByName(nodeName);
                }
                return renderNode.node.name;
            }
            render.expandUntilNodeIsShown = expandUntilNodeIsShown;
        })(render = graph_1.render || (graph_1.render = {}));
    })(graph = tf.graph || (tf.graph = {}));
})(tf || (tf = {})); // close module tf.graph.render
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVuZGVyLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsicmVuZGVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7QUFBQTs7Ozs7Ozs7Ozs7OztnRkFhZ0Y7QUFDaEY7O0dBRUc7QUFDSCxJQUFPLEVBQUUsQ0FvdEVSO0FBcHRFRCxXQUFPLEVBQUU7SUFBQyxJQUFBLEtBQUssQ0FvdEVkO0lBcHRFUyxXQUFBLE9BQUs7UUFBQyxJQUFBLE1BQU0sQ0FvdEVyQjtRQXB0RWUsV0FBQSxNQUFNO1lBSXRCOztlQUVHO1lBQ1EsbUJBQVksR0FBRyxFQUFDLFlBQVksRUFBRSxTQUFTLEVBQUUsY0FBYyxFQUFFLFNBQVM7Z0JBQ2xELFVBQVUsRUFBRSxTQUFTLEVBQUUsWUFBWSxFQUFFLFNBQVMsRUFBQyxDQUFDO1lBRTNFOzs7ZUFHRztZQUNRLHFCQUFjLEdBQUc7Z0JBQzFCOzttQkFFRztnQkFDSCxZQUFZLEVBQUUsU0FBUztnQkFDdkIsY0FBYyxFQUFFLFNBQVM7Z0JBQ3pCLFVBQVUsRUFBRSxHQUFHO2dCQUNmLFNBQVMsRUFBRSxJQUFJO2dCQUNmOzs7bUJBR0c7Z0JBQ0gsY0FBYyxFQUFFLFNBQVM7Z0JBQ3pCOzttQkFFRztnQkFDSCxJQUFJLEVBQUUsQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxFQUFFLENBQUM7Z0JBQ3JELGlCQUFpQixZQUFDLEVBQVUsRUFBRSxTQUFtQjtvQkFDL0MsbUVBQW1FO29CQUNuRSxtQ0FBbUM7b0JBQ25DLElBQUksSUFBSSxHQUFHLE9BQUEsY0FBYyxDQUFDLElBQUksQ0FBQztvQkFDL0IsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQztvQkFDcEIsSUFBSSxHQUFHLEdBQUcsSUFBSSxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQztvQkFDdkIsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLEVBQUUsR0FBRyxHQUFHLENBQUMsQ0FBQztvQkFDdEMsSUFBSSxHQUFHLEdBQUcsU0FBUyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDO29CQUN2QyxJQUFJLEtBQUssR0FBRyxTQUFTLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO29CQUNoQyxPQUFPLEVBQUUsQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFFLEdBQUcsR0FBRyxHQUFHLEVBQUUsR0FBRyxHQUFHLEtBQUssQ0FBQyxDQUFDLFFBQVEsRUFBRSxDQUFDO2dCQUN4RCxDQUFDO2dCQUNELGNBQWMsRUFBZCxVQUFlLEtBQWE7b0JBQzFCLE9BQU8sT0FBQSxjQUFjLENBQUMsaUJBQWlCLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQ2pELENBQUM7Z0JBQ0QsbUJBQW1CLEVBQW5CLFVBQW9CLEtBQWE7b0JBQy9CLE9BQU8sT0FBQSxjQUFjLENBQUMsaUJBQWlCLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQ2pELENBQUM7Z0JBQ0QsT0FBTyxFQUFFLE1BQU07Z0JBQ2YsZ0JBQWdCLEVBQUUsTUFBTTthQUN6QixDQUFDO1lBRUY7O2VBRUc7WUFDUSx1QkFBZ0IsR0FBRztnQkFDNUIsWUFBWSxFQUFFLE9BQU87Z0JBQ3JCLGNBQWMsRUFBRSxTQUFTO2FBQzFCLENBQUM7WUFzQkY7O2VBRUc7WUFDSCxJQUFNLE1BQU0sR0FBRztnQkFDYjs7bUJBRUc7Z0JBQ0gsZ0JBQWdCLEVBQUUsSUFBSTtnQkFDdEI7Ozs7bUJBSUc7Z0JBQ0gseUJBQXlCLEVBQUUsRUFBRTtnQkFDN0I7OzttQkFHRztnQkFDSCxzQkFBc0IsRUFBRSxDQUFDO2dCQUN6Qjs7O21CQUdHO2dCQUNILGdCQUFnQixFQUFFLENBQUM7Z0JBQ25COzs7OzttQkFLRztnQkFDSCxtQkFBbUIsRUFBRSxDQUFDO2dCQUN0Qjs7O21CQUdHO2dCQUNILGVBQWUsRUFBRTtvQkFDZixNQUFNLENBQUUsOERBQThEO2lCQUN2RTtnQkFFRDs7O21CQUdHO2dCQUNILGNBQWMsRUFBRSxFQUFFO2dCQUVsQjs7Ozs7bUJBS0c7Z0JBQ0gsMkJBQTJCLEVBQUUsSUFBSTtnQkFFakM7Ozs7bUJBSUc7Z0JBQ0gsNENBQTRDLEVBQUUsSUFBSTtnQkFFbEQ7OzttQkFHRztnQkFDSCxpQkFBaUIsRUFBRSxJQUFJO2dCQUV2Qjs7O21CQUdHO2dCQUNILFlBQVksRUFBRSxDQUFDLFNBQVMsRUFBRSxTQUFTLENBQUM7Z0JBRXBDOzs7bUJBR0c7Z0JBQ0gsY0FBYyxFQUFFLENBQUM7YUFDbEIsQ0FBQztZQUVGOzs7Ozs7O2VBT0c7WUFDSCxJQUFNLG9CQUFvQixHQUFHLElBQUksTUFBTSxDQUNuQyxNQUFNLEdBQUcsRUFBRSxDQUFDLEtBQUssQ0FBQyw0QkFBNEI7Z0JBQzFDLGlDQUFpQyxDQUFDLENBQUM7WUFFM0M7OztlQUdHO1lBQ0g7Z0JBd0JFLHlCQUFZLFNBQThCLEVBQUUsZUFBd0I7b0JBQ2xFLElBQUksQ0FBQyxTQUFTLEdBQUcsU0FBUyxDQUFDO29CQUMzQixJQUFJLENBQUMsZUFBZSxHQUFHLGVBQWUsQ0FBQztvQkFDdkMsSUFBSSxDQUFDLEtBQUssR0FBRyxFQUFFLENBQUM7b0JBQ2hCLElBQUksQ0FBQyxlQUFlLEdBQUcsRUFBRSxDQUFDO29CQUUxQixJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7b0JBQ3JCLGdFQUFnRTtvQkFDaEUsZUFBZTtvQkFDZixJQUFJLENBQUMsZUFBZSxHQUFHLEVBQUUsQ0FBQztvQkFDMUIsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLG1CQUFtQixDQUFDLFNBQVMsQ0FBQyxJQUFJLEVBQUUsU0FBUyxDQUFDLFlBQVksQ0FBQyxDQUFDO29CQUM1RSxJQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQztvQkFDNUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztvQkFDL0MsSUFBSSxDQUFDLGlCQUFpQixDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7b0JBQzVDLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQztvQkFDMUIsSUFBSSxDQUFDLFdBQVcsR0FBRyxLQUFLLENBQUM7Z0JBQzNCLENBQUM7Z0JBRUQsdUNBQWEsR0FBYjtvQkFDRSxJQUFJLENBQUMsY0FBYyxHQUFHLEVBQUUsQ0FBQyxZQUFZLEVBQVU7eUJBQzFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQzt5QkFDOUIsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsRUFDdkMsT0FBQSxjQUFjLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQztvQkFFakQsSUFBSSxDQUFDLGtCQUFrQjt3QkFDbkIsRUFBRSxDQUFDLFlBQVksRUFBVTs2QkFDcEIsTUFBTSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDOzZCQUNsQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FDUixFQUFFLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxFQUMzQyxPQUFBLGNBQWMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUM7b0JBRWpELElBQUksYUFBYSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQztvQkFDbEQsdURBQXVEO29CQUN2RCxJQUFJLFNBQVMsR0FBRyxFQUFFLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxLQUFLLEVBQUUsRUFDeEMsVUFBQyxRQUFRLEVBQUUsS0FBSzt3QkFDbEIsSUFBSSxJQUFJLEdBQUcsYUFBYSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQzt3QkFDeEMsb0NBQW9DO3dCQUNwQyxJQUFJLElBQUksQ0FBQyxLQUFLLElBQUksSUFBSSxFQUFFOzRCQUN0QixPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDO3lCQUM5QjtvQkFDSCxDQUFDLENBQUMsQ0FBQztvQkFDSCxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsRUFBRSxDQUFDLFdBQVcsRUFBa0I7eUJBQ25ELE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxTQUFTLENBQUMsQ0FBQzt5QkFDdEIsS0FBSyxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQztvQkFFaEMsdURBQXVEO29CQUN2RCxJQUFJLGNBQWMsR0FBRyxFQUFFLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxLQUFLLEVBQUUsRUFDN0MsVUFBQyxRQUFRLEVBQUUsS0FBSzt3QkFDbEIsSUFBSSxJQUFJLEdBQUcsYUFBYSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQzt3QkFDeEMsb0NBQW9DO3dCQUNwQyxJQUFJLElBQUksQ0FBQyxLQUFLLElBQUksSUFBSSxFQUFFOzRCQUN0QixPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsY0FBYyxFQUFFLENBQUM7eUJBQ3BDO29CQUNILENBQUMsQ0FBQyxDQUFDO29CQUNILElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxFQUFFLENBQUMsV0FBVyxFQUFrQjt5QkFDbkQsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLGNBQWMsQ0FBQyxDQUFDO3lCQUMzQixLQUFLLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDO29CQUVoQyxJQUFJLENBQUMsd0JBQXdCLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxZQUFZLENBQUMsQ0FBQzt3QkFDM0QsUUFBQSxLQUFLLENBQUMsSUFBSSxDQUFDLDJCQUEyQixDQUFDLENBQUM7d0JBQ3hDLEVBQUUsQ0FBQyxXQUFXLEVBQUU7NkJBQ2IsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsZUFBZSxDQUFDLENBQUM7NkJBQzNDLEtBQUssQ0FBQyxDQUFDLFFBQUEsS0FBSyxDQUFDLElBQUksQ0FBQyxjQUFjLEVBQUUsUUFBQSxLQUFLLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUM7Z0JBQ3JFLENBQUM7Z0JBRUQ7O21CQUVHO2dCQUNILDZDQUFtQixHQUFuQixVQUFvQixRQUFnQjtvQkFDbEMsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDO2dCQUM5QixDQUFDO2dCQUVEOzttQkFFRztnQkFDSCx1Q0FBYSxHQUFiLFVBQWMsUUFBZ0I7b0JBQzVCLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7Z0JBQ3ZDLENBQUM7Z0JBRU8sd0NBQWMsR0FBdEIsVUFDSSxTQUFtQyxFQUNuQyxNQUF1QztvQkFFekMsSUFBSSxNQUFNLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7d0JBQ3JDLGdDQUFnQzt3QkFDaEMsSUFBTSxVQUFRLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxVQUFBLEdBQUcsSUFBSSxPQUFBLFNBQVMsQ0FBQyxHQUFHLENBQUMsRUFBZCxDQUFjLENBQUMsQ0FBQyxDQUFDO3dCQUMxRSxPQUFPLE1BQU0sQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsR0FBRyxDQUFDLFVBQUEsR0FBRyxJQUFJLE9BQUEsQ0FBQzs0QkFDeEMsS0FBSyxFQUFFLE1BQU0sQ0FBQyxHQUFHLENBQUM7NEJBQ2xCLGlEQUFpRDs0QkFDakQsVUFBVSxFQUFFLFNBQVMsQ0FBQyxHQUFHLENBQUMsR0FBRyxVQUFRO3lCQUN0QyxDQUFDLEVBSnVDLENBSXZDLENBQUMsQ0FBQztxQkFDTDtvQkFDRCxPQUFPLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLENBQUM7b0JBQ2hDLE9BQU8sSUFBSSxDQUFDO2dCQUNkLENBQUM7Z0JBRUQ7OzttQkFHRztnQkFDSCxxREFBMkIsR0FBM0IsVUFBNEIsUUFBZ0I7O29CQUMxQyxxQ0FBcUM7b0JBQ3JDLElBQUksQ0FBQyxRQUFRLEVBQUU7d0JBQ2IsT0FBTyxJQUFJLENBQUM7cUJBQ2I7b0JBRUQsSUFBSSxRQUFRLElBQUksSUFBSSxDQUFDLEtBQUssRUFBRTt3QkFDMUIsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDO3FCQUM3QjtvQkFFRCxJQUFJLElBQUksR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztvQkFDekMsMEVBQTBFO29CQUMxRSwyRUFBMkU7b0JBQzNFLG9CQUFvQjtvQkFDcEIsSUFBSSxDQUFDLElBQUksRUFBRTt3QkFDVCxPQUFPLElBQUksQ0FBQztxQkFDYjtvQkFDRCxJQUFJLFVBQVUsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7d0JBQy9CLElBQUksbUJBQW1CLENBQVksSUFBSSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQzt3QkFDdkUsSUFBSSxjQUFjLENBQUMsSUFBSSxDQUFDLENBQUM7b0JBQzdCLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLEdBQUcsVUFBVSxDQUFDO29CQUNsQyxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztvQkFFcEMsSUFBSSxJQUFJLENBQUMsS0FBSyxFQUFFO3dCQUNkLFVBQVUsQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLENBQUM7d0JBQ3RFLFVBQVUsQ0FBQyxnQkFBZ0I7NEJBQ3ZCLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLGNBQWMsRUFBRSxDQUFDLENBQUM7cUJBQ3hEO29CQUVELGtEQUFrRDtvQkFDbEQsVUFBVSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsZUFBZTt3QkFDeEMsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBRXZELElBQUksZUFBZSxHQUFHLElBQUksQ0FBQztvQkFDM0IsSUFBSSxtQkFBbUIsR0FBRyxJQUFJLENBQUM7b0JBQy9CLElBQUksZUFBZSxHQUFHLElBQUksQ0FBQztvQkFDM0IsSUFBSSxJQUFJLENBQUMsV0FBVyxFQUFFO3dCQUNwQixlQUFlLEdBQWUsSUFBSyxDQUFDLGVBQWUsQ0FBQzt3QkFDcEQsbUJBQW1CLEdBQWUsSUFBSyxDQUFDLG1CQUFtQixDQUFDO3dCQUM1RCxJQUFJLE1BQU0sR0FBZSxJQUFLLENBQUMsc0JBQXNCLENBQUMsVUFBVSxDQUFDO3dCQUNqRSxJQUFJLFFBQVEsR0FBZSxJQUFLLENBQUMsc0JBQXNCLENBQUMsWUFBWSxDQUFDO3dCQUNyRSxJQUFJLE1BQU0sSUFBSSxDQUFDLElBQUksUUFBUSxJQUFJLENBQUMsRUFBRTs0QkFDaEMsZUFBZSxHQUFHLE1BQU0sR0FBRyxDQUFDLE1BQU0sR0FBRyxRQUFRLENBQUMsQ0FBQzt5QkFDaEQ7cUJBQ0Y7eUJBQU07d0JBQ0wsSUFBSSxNQUFNLEdBQVksVUFBVSxDQUFDLElBQUssQ0FBQyxNQUFNLENBQUM7d0JBQzlDLElBQUksTUFBTSxFQUFFOzRCQUNWLGVBQWUsYUFBSSxHQUFDLE1BQU0sSUFBRyxDQUFDLEtBQUMsQ0FBQzt5QkFDakM7d0JBQ0QsSUFBSSxVQUFVLEdBQVksVUFBVSxDQUFDLElBQUssQ0FBQyxVQUFVLENBQUM7d0JBQ3RELElBQUksVUFBVSxFQUFFOzRCQUNkLG1CQUFtQixhQUFJLEdBQUMsVUFBVSxJQUFHLENBQUMsS0FBQyxDQUFDO3lCQUN6Qzt3QkFDRCxJQUFJLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxLQUFLLFFBQUEsUUFBUSxDQUFDLEVBQUUsRUFBRTs0QkFDeEMsZUFBZSxHQUFZLFVBQVUsQ0FBQyxJQUFLLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzt5QkFDaEU7cUJBQ0Y7b0JBQ0QsSUFBSSxlQUFlLEVBQUU7d0JBQ25CLFVBQVUsQ0FBQyxZQUFZOzRCQUNuQixJQUFJLENBQUMsY0FBYyxDQUFDLGVBQWUsRUFBRSxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUM7cUJBQy9EO29CQUNELElBQUksbUJBQW1CLEVBQUU7d0JBQ3ZCLFVBQVUsQ0FBQyxnQkFBZ0I7NEJBQ3ZCLElBQUksQ0FBQyxjQUFjLENBQUMsbUJBQW1CLEVBQUUsSUFBSSxDQUFDLGtCQUFrQixDQUFDLENBQUM7cUJBQ3ZFO29CQUNELElBQUksZUFBZSxJQUFJLElBQUksRUFBRTt3QkFDM0IsVUFBVSxDQUFDLG1CQUFtQixHQUFHOzRCQUMvQjtnQ0FDRSxLQUFLLEVBQUUsRUFBRSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLFVBQVU7Z0NBQzlDLFVBQVUsRUFBRSxlQUFlOzZCQUM1Qjs0QkFDRDtnQ0FDRSxLQUFLLEVBQUUsRUFBRSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLFlBQVk7Z0NBQ2hELFVBQVUsRUFBRSxDQUFDLEdBQUcsZUFBZTs2QkFDaEM7eUJBQ0YsQ0FBQztxQkFDSDtvQkFFRCxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUM7Z0JBQzlCLENBQUM7Z0JBRUQ7Ozs7O21CQUtHO2dCQUNILG1EQUF5QixHQUF6QixVQUEwQixJQUFZO29CQUNwQyxJQUFJLElBQUksR0FBRyxRQUFBLG1CQUFtQixDQUFDLElBQUksQ0FBQyxDQUFDO29CQUNyQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7b0JBQ1YsSUFBSSxVQUFVLEdBQW1CLElBQUksQ0FBQztvQkFDdEMsMkRBQTJEO29CQUMzRCxJQUFJLFFBQVEsR0FBRyxJQUFJLENBQUM7b0JBQ3BCLE9BQU8sQ0FBQyxHQUFHLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7d0JBQzNCLFFBQVEsR0FBRyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQ25CLFVBQVUsR0FBRyxJQUFJLENBQUMsbUJBQW1CLENBQUMsUUFBUSxDQUFDLENBQUM7d0JBQ2hELGtEQUFrRDt3QkFDbEQsSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLEVBQUU7NEJBQ3hCLE1BQU07eUJBQ1A7cUJBQ0Y7b0JBRUQsMEVBQTBFO29CQUMxRSx1RUFBdUU7b0JBQ3ZFLHFFQUFxRTtvQkFDckUsYUFBYTtvQkFDYixJQUFJLENBQUMsSUFBSSxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTt3QkFDeEIsSUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQzt3QkFDM0IsSUFBSSxVQUFVLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsRUFBRTs0QkFDaEQsT0FBTyxRQUFRLENBQUM7eUJBQ2pCO3dCQUVELElBQUksVUFBVSxDQUFDLGNBQWMsQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLEVBQUU7NEJBQ2pELE9BQU8sUUFBUSxDQUFDO3lCQUNqQjtxQkFDRjtvQkFFRCxPQUFPLFFBQVEsQ0FBQztnQkFDbEIsQ0FBQztnQkFFRCw2REFBNkQ7Z0JBQzdELGtDQUFRLEdBQVIsVUFBUyxLQUFhO29CQUNwQixpQkFBaUIsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQ3ZDLENBQUM7Z0JBRUQ7O21CQUVHO2dCQUNILHlDQUFlLEdBQWYsVUFBZ0IsVUFBMEI7b0JBQ3hDLElBQUksVUFBVSxHQUF3QixJQUFJLENBQUMsbUJBQW1CLENBQzVELFVBQVUsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDO29CQUNuQyxJQUFJLEtBQUssR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsRUFBRSxVQUFBLElBQUk7d0JBQ25ELE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLEtBQUssVUFBVSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7b0JBQ2pELENBQUMsQ0FBQyxDQUFDO29CQUNILElBQUksS0FBSyxFQUFFO3dCQUNULE9BQU8sSUFBSSxDQUFDO3FCQUNiO29CQUNELEtBQUssR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxrQkFBa0IsRUFBRSxVQUFBLElBQUk7d0JBQ2hELE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLEtBQUssVUFBVSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7b0JBQ2pELENBQUMsQ0FBQyxDQUFDO29CQUNILE9BQU8sQ0FBQyxDQUFDLEtBQUssQ0FBQztnQkFDakIsQ0FBQztnQkFFRDs7OzttQkFJRztnQkFDSCwrQ0FBcUIsR0FBckI7b0JBQ0UsT0FBTyxJQUFJLENBQUMsZUFBZSxDQUFDO2dCQUM5QixDQUFDO2dCQUVEOzs7Ozs7Ozs7OzttQkFXRztnQkFDSyxtREFBeUIsR0FBakMsVUFDSSxjQUF3QixFQUN4Qix1QkFBK0IsRUFDL0IsSUFBWSxFQUNaLFNBQWlCO29CQUpyQixpQkFxREM7b0JBaERDLElBQU0sT0FBTyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUM3Qix1QkFBdUIsRUFBRSxTQUFTLENBQUMsQ0FBQztvQkFDeEMsSUFBSSxTQUFTLEdBQUcsY0FBYyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7b0JBQ3ZELElBQUksU0FBUyxFQUFFO3dCQUNiLDZEQUE2RDt3QkFDN0QsT0FBTyxTQUFtQixDQUFDO3FCQUM1QjtvQkFFRCx3QkFBd0I7b0JBQ3hCLFNBQVMsR0FBRyxJQUFJLFFBQUEsVUFBVSxDQUFDO3dCQUN6QixJQUFJLEVBQUUsT0FBTzt3QkFDYixLQUFLLEVBQUUsRUFBRTt3QkFDVCxNQUFNLEVBQUUsSUFBSSxDQUFDLE1BQU07d0JBQ25CLEVBQUUsRUFBRSxJQUFJLENBQUMsRUFBRTt3QkFDWCxJQUFJLEVBQUUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO3FCQUM3QixDQUFDLENBQUM7b0JBRUgsNkJBQTZCO29CQUM3QixTQUFTLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUM7b0JBQ3pDLFNBQVMsQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQztvQkFDakMsU0FBUyxDQUFDLFlBQVksR0FBRyxDQUFDLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQztvQkFDeEQsU0FBUyxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDO29CQUN2QyxTQUFTLENBQUMsa0JBQWtCLEdBQUcsSUFBSSxDQUFDLGtCQUFrQixDQUFDO29CQUN2RCxTQUFTLENBQUMsbUJBQW1CLEdBQUcsSUFBSSxDQUFDLG1CQUFtQixDQUFDO29CQUV6RCw2REFBNkQ7b0JBQzdELFNBQVMsQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsVUFBQSxlQUFlO3dCQUNoRCxJQUFNLGtCQUFrQixHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsZUFBZSxDQUFDLENBQUM7d0JBQ3BELGtCQUFrQixDQUFDLElBQUksR0FBRyxlQUFlLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FDbEQsdUJBQXVCLEVBQUUsU0FBUyxDQUFDLENBQUM7d0JBQ3hDLE9BQU8sa0JBQWtCLENBQUM7b0JBQzVCLENBQUMsQ0FBQyxDQUFDO29CQUVILHlFQUF5RTtvQkFDekUsbUJBQW1CO29CQUNuQixTQUFTLENBQUMsVUFBVSxHQUFHLGNBQWMsQ0FBQztvQkFDdEMsY0FBYyxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLElBQUksRUFBRSxTQUFTLENBQUMsQ0FBQztvQkFDNUQsSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLElBQUksRUFBRSxTQUFTLENBQUMsQ0FBQztvQkFFbEQscUJBQXFCO29CQUNyQixJQUFNLHFCQUFxQixHQUFHLFVBQUEsYUFBYTt3QkFDekMsT0FBTyxLQUFJLENBQUMseUJBQXlCLENBQ2pDLGNBQWMsRUFBRSx1QkFBdUIsRUFBRSxhQUFhLEVBQUUsU0FBUyxDQUFDLENBQUM7b0JBQ3pFLENBQUMsQ0FBQTtvQkFDRCxTQUFTLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLHFCQUFxQixDQUFDLENBQUM7b0JBQ3RFLFNBQVMsQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMscUJBQXFCLENBQUMsQ0FBQztvQkFFeEUsT0FBTyxTQUFTLENBQUM7Z0JBQ25CLENBQUM7Z0JBRUQ7Ozs7Ozs7Ozs7Ozs7OzttQkFlRztnQkFDSyxzREFBNEIsR0FBcEMsVUFDSSxTQUFxRCxFQUNyRCxlQUF1QixFQUN2QixlQUF5QixFQUN6QixTQUFpQixFQUNqQixTQUFpQjtvQkFDbkIsd0VBQXdFO29CQUN4RSxVQUFVO29CQUNWLElBQU0seUJBQXlCLEdBQUcsRUFBRSxDQUFDO29CQUVyQyxJQUFNLFdBQVcsR0FBRyxJQUFJLENBQUMsa0NBQWtDLENBQ3ZELFNBQVMsRUFDVCxlQUFlLEVBQ2YsZUFBZSxFQUNmLFNBQVMsRUFDVCxTQUFTLEVBQ1QseUJBQXlCLENBQUMsQ0FBQztvQkFFL0IsSUFBSSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMseUJBQXlCLENBQUMsRUFBRTt3QkFDekMsd0VBQXdFO3dCQUN4RSw0REFBNEQ7d0JBQzVELElBQUksQ0FBQyw2QkFBNkIsQ0FDOUIsZUFBZSxFQUFFLHlCQUF5QixDQUFDLENBQUM7cUJBQ2pEO29CQUVELE9BQU8sV0FBVyxDQUFDO2dCQUNyQixDQUFDO2dCQUVEOzs7Ozs7Ozs7Ozs7Ozs7O21CQWdCRztnQkFDSyw0REFBa0MsR0FBMUMsVUFDSSxTQUFxRCxFQUNyRCxlQUF1QixFQUN2QixlQUF5QixFQUN6QixTQUFpQixFQUNqQixTQUFpQixFQUNqQix5QkFBZ0Q7b0JBTnBELGlCQXVFQztvQkFoRUMsSUFBTSxXQUFXLEdBQUcsRUFBRSxDQUFDLEtBQUssQ0FBQyxjQUFjLENBQ3ZDLGVBQWUsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsRUFBRSxTQUFTLENBQUMsQ0FBQyxDQUFDO29CQUV4RCxnQ0FBZ0M7b0JBQ2hDLFdBQVcsQ0FBQyxLQUFLLEdBQUcsZUFBZSxDQUFDLEtBQUssQ0FBQztvQkFDMUMsV0FBVyxDQUFDLFdBQVcsR0FBRyxlQUFlLENBQUMsV0FBVyxDQUFDO29CQUN0RCxXQUFXLENBQUMsVUFBVSxHQUFHLGVBQWUsQ0FBQyxVQUFVLENBQUM7b0JBQ3BELFdBQVcsQ0FBQyxXQUFXLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxlQUFlLENBQUMsV0FBVyxDQUFDLENBQUM7b0JBQy9ELFdBQVcsQ0FBQyxlQUFlLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxlQUFlLENBQUMsZUFBZSxDQUFDLENBQUM7b0JBQ3ZFLFdBQVcsQ0FBQyxtQkFBbUI7d0JBQzNCLENBQUMsQ0FBQyxLQUFLLENBQUMsZUFBZSxDQUFDLG1CQUFtQixDQUFDLENBQUM7b0JBQ2pELFdBQVcsQ0FBQyxrQkFBa0IsR0FBRyxlQUFlLENBQUMsa0JBQWtCLENBQUM7b0JBQ3BFLFdBQVcsQ0FBQyxPQUFPLEdBQUcsZUFBZSxDQUFDLE9BQU8sQ0FBQztvQkFDOUMsV0FBVyxDQUFDLGNBQWMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLGVBQWUsQ0FBQyxjQUFjLENBQUMsQ0FBQztvQkFDckUsV0FBVyxDQUFDLGtCQUFrQixHQUFHLGVBQWUsQ0FBQyxrQkFBa0IsQ0FBQztvQkFFcEUsNENBQTRDO29CQUM1QyxDQUFDLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUFFLEVBQUUsVUFBQSxRQUFRO3dCQUNoRCxJQUFNLElBQUksR0FBRyxlQUFlLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQzt3QkFFdEQsUUFBUSxJQUFJLENBQUMsSUFBSSxFQUFFOzRCQUNqQixLQUFLLFFBQUEsUUFBUSxDQUFDLElBQUk7Z0NBQ2hCLHNDQUFzQztnQ0FDdEMsSUFBTSxPQUFPLEdBQUcsS0FBSSxDQUFDLGtDQUFrQyxDQUNuRCxTQUFTLEVBQ1QsZUFBZSxFQUNmLElBQWdCLEVBQ2hCLFNBQVMsRUFDVCxTQUFTLEVBQ1QseUJBQXlCLENBQUMsQ0FBQztnQ0FFL0IsaUNBQWlDO2dDQUNqQyxPQUFPLENBQUMsVUFBVSxHQUFHLFdBQVcsQ0FBQztnQ0FDakMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxPQUFPLENBQUMsQ0FBQztnQ0FDckQsS0FBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxPQUFPLENBQUMsQ0FBQztnQ0FDOUMsTUFBTTs0QkFDUixLQUFLLFFBQUEsUUFBUSxDQUFDLEVBQUU7Z0NBQ2QseUJBQXlCO2dDQUN6QixJQUFNLFNBQVMsR0FBRyxLQUFJLENBQUMseUJBQXlCLENBQzVDLFdBQVcsRUFBRSxTQUFTLEVBQUUsSUFBYyxFQUFFLFNBQVMsQ0FBQyxDQUFDO2dDQUN2RCxJQUFJLENBQUMsQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLGtCQUFrQixDQUFDLEVBQUU7b0NBQzVDLGtFQUFrRTtvQ0FDbEUsMkRBQTJEO29DQUMzRCxLQUFJLENBQUMsNEJBQTRCLENBQUMsZUFBZSxFQUFFLFNBQVMsQ0FBQyxDQUFDO2lDQUMvRDtnQ0FFRCxJQUFJLENBQUMsQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLG1CQUFtQixDQUFDLEVBQUU7b0NBQzdDLHlCQUF5QixDQUFDLFNBQVMsQ0FBQyxtQkFBbUIsQ0FBQzt3Q0FDcEQsU0FBUyxDQUFDO2lDQUNmO2dDQUNELE1BQU07NEJBQ1I7Z0NBQ0UsaUVBQWlFO2dDQUNqRSw2QkFBNkI7Z0NBQzdCLE9BQU8sQ0FBQyxJQUFJLENBQ1IsSUFBSSxDQUFDLElBQUksR0FBRyw2Q0FBNkMsQ0FBQyxDQUFDO3lCQUNsRTtvQkFDSCxDQUFDLENBQUMsQ0FBQztvQkFFSCx3REFBd0Q7b0JBQ3hELElBQUksQ0FBQyx5QkFBeUIsQ0FDMUIsZUFBZSxFQUFFLFdBQVcsRUFBRSxTQUFTLEVBQUUsU0FBUyxDQUFDLENBQUM7b0JBRXhELE9BQU8sV0FBVyxDQUFDO2dCQUNyQixDQUFDO2dCQUVEOzs7Ozs7bUJBTUc7Z0JBQ0ssbURBQXlCLEdBQWpDLFVBQ0ksZUFBeUIsRUFDekIsV0FBcUIsRUFDckIsU0FBaUIsRUFDakIsU0FBaUI7b0JBQ25CLENBQUMsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLFNBQVMsQ0FBQyxLQUFLLEVBQUUsRUFDcEMsVUFBQyxVQUErQjt3QkFDbEMsSUFBTSxJQUFJLEdBQUcsZUFBZSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7d0JBQ3hELElBQU0sSUFBSSxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFNBQVMsRUFBRSxTQUFTLENBQUMsQ0FBQzt3QkFDbEQsSUFBTSxJQUFJLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsU0FBUyxFQUFFLFNBQVMsQ0FBQyxDQUFDO3dCQUVsRCxJQUFNLFdBQVcsR0FBRyxJQUFJLFFBQUEsWUFBWSxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQzt3QkFFakQsZ0NBQWdDO3dCQUNoQyxXQUFXLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUM7d0JBQ25DLFdBQVcsQ0FBQyxlQUFlLEdBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQzt3QkFDbkQsV0FBVyxDQUFDLGVBQWUsR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDO3dCQUNuRCxXQUFXLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUM7d0JBQzNDLFdBQVcsQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQzt3QkFDdkMsSUFBSSxJQUFJLENBQUMsWUFBWSxFQUFFOzRCQUNyQixXQUFXLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLFVBQUEsUUFBUTtnQ0FDdkQsSUFBTSxXQUFXLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQztnQ0FDdEMsV0FBVyxDQUFDLENBQUMsR0FBRyxRQUFRLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxTQUFTLEVBQUUsU0FBUyxDQUFDLENBQUM7Z0NBQ3pELFdBQVcsQ0FBQyxDQUFDLEdBQUcsUUFBUSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsU0FBUyxFQUFFLFNBQVMsQ0FBQyxDQUFDO2dDQUN6RCxPQUFPLFdBQVcsQ0FBQzs0QkFDckIsQ0FBQyxDQUFDLENBQUM7eUJBQ0o7d0JBRUQseUVBQXlFO3dCQUN6RSx5REFBeUQ7d0JBQ3pELElBQUksV0FBVyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUU7NEJBQ3BDLFdBQVcsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxJQUFJLEVBQUUsV0FBVyxDQUFDLENBQUM7eUJBQ3hEOzZCQUFNOzRCQUNMLFdBQVcsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxJQUFJLEVBQUUsV0FBVyxDQUFDLENBQUM7eUJBQ3hEO29CQUNILENBQUMsQ0FBQyxDQUFDO2dCQUNMLENBQUM7Z0JBRUQ7Ozs7bUJBSUc7Z0JBQ0ssc0RBQTRCLEdBQXBDLFVBQ0ksZUFBdUIsRUFBRSxTQUFpQjtvQkFDNUMscUVBQXFFO29CQUNyRSxpREFBaUQ7b0JBQ2pELElBQUksVUFBVSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQ3JCLFNBQVMsQ0FBQyxrQkFBa0IsRUFDNUIsZUFBZSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUM7b0JBQ3ZDLElBQUksUUFBUSxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsZUFBZSxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDO29CQUMzRCxPQUFPLFFBQVEsQ0FBQyxtQkFBbUIsRUFBRTt3QkFDbkMseURBQXlEO3dCQUN6RCxjQUFjO3dCQUNkLFVBQVUsRUFBRSxDQUFDO3dCQUNiLFFBQVEsR0FBRyxlQUFlLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDO3FCQUMvQztvQkFDRCxxQ0FBcUM7b0JBQ3JDLFNBQVMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO29CQUVoQyw0REFBNEQ7b0JBQzVELGFBQWE7b0JBQ2IsSUFBTSxpQkFBaUIsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLGVBQWUsQ0FDcEQsZUFBZSxDQUFDLElBQUksQ0FBQyxDQUFDO29CQUUxQix5REFBeUQ7b0JBQ3pELDREQUE0RDtvQkFDNUQsbUNBQW1DO29CQUNuQyxJQUFJLGdCQUEwQixDQUFDO29CQUMvQixJQUFJLGdCQUFnQixHQUFHLENBQUMsQ0FBQztvQkFDekIsQ0FBQyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLEVBQUUsVUFBQSxRQUFRO3dCQUN4QyxnQkFBZ0IsSUFBSSxRQUFRLENBQUMsZUFBZSxDQUFDO3dCQUM3QyxJQUFJLGdCQUFnQixHQUFHLFVBQVUsRUFBRTs0QkFDakMsZ0JBQWdCLEdBQUcsUUFBUSxDQUFDOzRCQUM1QixzQkFBc0I7NEJBQ3RCLE9BQU8sS0FBSyxDQUFDO3lCQUNkO29CQUNILENBQUMsQ0FBQyxDQUFDO29CQUVILGtFQUFrRTtvQkFDbEUsZ0VBQWdFO29CQUNoRSxxQkFBcUI7b0JBQ3JCLENBQUMsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsWUFBWSxFQUFFLFVBQUEsSUFBSTt3QkFDeEMsSUFBSSxJQUFJLENBQUMsQ0FBQyxLQUFLLGVBQWUsQ0FBQyxJQUFJLEVBQUU7NEJBQ25DLElBQUksQ0FBQyxDQUFDLEdBQUcsU0FBUyxDQUFDLElBQUksQ0FBQzt5QkFDekI7d0JBQ0QsSUFBSSxJQUFJLENBQUMsQ0FBQyxLQUFLLGVBQWUsQ0FBQyxJQUFJLEVBQUU7NEJBQ25DLElBQUksQ0FBQyxDQUFDLEdBQUcsU0FBUyxDQUFDLElBQUksQ0FBQzt5QkFDekI7b0JBQ0gsQ0FBQyxDQUFDLENBQUM7Z0JBQ0wsQ0FBQztnQkFFRDs7Ozs7bUJBS0c7Z0JBQ0ssdURBQTZCLEdBQXJDLFVBQ0ksZUFBdUIsRUFDdkIsb0NBQTJEO29CQUYvRCxpQkFpQ0M7b0JBOUJDLG9EQUFvRDtvQkFDcEQsSUFBTSxpQkFBaUIsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLGFBQWEsQ0FDbEQsZUFBZSxDQUFDLElBQUksQ0FBQyxDQUFDO29CQUMxQixDQUFDLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLE9BQU8sRUFBRSxVQUFDLFFBQVE7d0JBQ3pDLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFlBQVksRUFBRSxVQUFBLFFBQVE7NEJBQ3BDLDREQUE0RDs0QkFDNUQsSUFBTSxlQUFlLEdBQUcsS0FBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBVyxDQUFDOzRCQUNsRSxDQUFDLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxNQUFNLEVBQUUsVUFBQSxlQUFlO2dDQUM1QyxvRUFBb0U7Z0NBQ3BFLGtFQUFrRTtnQ0FDbEUsSUFBSSxlQUFlLENBQUMsSUFBSSxLQUFLLGVBQWUsQ0FBQyxJQUFJLEVBQUU7b0NBQ2pELDhEQUE4RDtvQ0FDOUQsZ0VBQWdFO29DQUNoRSxtQkFBbUI7b0NBQ25CLElBQU0sVUFBVSxHQUFHLG9DQUFvQyxDQUNuRCxlQUFlLENBQUMsZUFBZSxDQUFDLENBQUM7b0NBQ3JDLGVBQWUsQ0FBQyxJQUFJLEdBQUcsVUFBVSxDQUFDLElBQUksQ0FBQztvQ0FDdkMsZUFBZSxDQUFDLGVBQWUsR0FBRyxRQUFRLENBQUMsZUFBZSxDQUFDO2lDQUM1RDs0QkFDSCxDQUFDLENBQUMsQ0FBQzt3QkFDTCxDQUFDLENBQUMsQ0FBQzt3QkFFSCx3RUFBd0U7d0JBQ3hFLHFCQUFxQjt3QkFDckIsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsWUFBWSxFQUFFLFVBQUMsUUFBUTs0QkFDckMsUUFBUSxDQUFDLENBQUM7Z0NBQ04sb0NBQW9DLENBQUMsUUFBUSxDQUFDLGVBQWUsQ0FBQyxDQUFDLElBQUksQ0FBQzs0QkFDeEUsUUFBUSxDQUFDLGVBQWUsR0FBRyxHQUFHLENBQUM7d0JBQ2pDLENBQUMsQ0FBQyxDQUFDO29CQUNMLENBQUMsQ0FBQyxDQUFDO2dCQUNMLENBQUM7Z0JBRUQsMkNBQWlCLEdBQWpCLFVBQWtCLFFBQWdCO29CQUFsQyxpQkF3ZkM7b0JBdmZDLCtEQUErRDtvQkFDL0QsaUJBQWlCO29CQUNqQixJQUFJLFFBQVEsSUFBSSxJQUFJLENBQUMsZUFBZSxFQUFFO3dCQUNwQyxPQUFPO3FCQUNSO29CQUVELDBFQUEwRTtvQkFDMUUsbUNBQW1DO29CQUNuQyxJQUFJLENBQUMsZUFBZSxDQUFDLFFBQVEsQ0FBQyxHQUFHLElBQUksQ0FBQztvQkFFdEMsSUFBSSxjQUFjLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQztvQkFFMUMsZ0VBQWdFO29CQUNoRSxJQUFJLGNBQWMsQ0FBQyxJQUFJLENBQUMsSUFBSSxLQUFLLFFBQUEsUUFBUSxDQUFDLElBQUk7d0JBQzFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsSUFBSSxLQUFLLFFBQUEsUUFBUSxDQUFDLE1BQU0sRUFBRTt3QkFDaEQsT0FBTztxQkFDUjtvQkFFRCx5RUFBeUU7b0JBQ3pFLElBQUksbUJBQW1CLEdBQXlCLGNBQWMsQ0FBQztvQkFDL0QsSUFBSSxTQUFTLEdBQUcsbUJBQW1CLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQztvQkFDbkQsSUFBSSxTQUFTLEdBQUcsbUJBQW1CLENBQUMsU0FBUyxDQUFDO29CQUU5QyxJQUFNLGtCQUFrQixHQUFHLEVBQUUsQ0FBQztvQkFDOUIsSUFBTSwwQkFBMEIsR0FBRyxFQUFFLENBQUM7b0JBQ3RDLElBQUksQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsZ0JBQWdCLENBQUMsRUFBRTt3QkFDL0MsNERBQTREO3dCQUM1RCw4QkFBOEI7d0JBQzlCLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssRUFBRSxFQUFFLFVBQUEsU0FBUzs0QkFDakMsa0NBQWtDOzRCQUNsQyxJQUFNLFlBQVksR0FBRyxTQUFTLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBVyxDQUFDOzRCQUN6RCxJQUFNLG1CQUFtQixHQUNyQixLQUFJLENBQUMsU0FBUyxDQUFDLGdCQUFnQixDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsQ0FBQzs0QkFDckQsSUFBSSxDQUFDLG1CQUFtQixFQUFFO2dDQUN4QixvQ0FBb0M7Z0NBQ3BDLE9BQU87NkJBQ1I7NEJBRUQsSUFBSSxTQUFTLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsNEJBQTRCLENBQUMsS0FBSyxDQUFDLEVBQUU7Z0NBQ2xFLDZEQUE2RDtnQ0FDN0QsZ0RBQWdEO2dDQUNoRCxPQUFPOzZCQUNSOzRCQUVELHVFQUF1RTs0QkFDdkUsc0VBQXNFOzRCQUN0RSx5QkFBeUI7NEJBQ3pCLElBQU0sY0FBYyxHQUFHLEtBQUksQ0FBQyw0QkFBNEIsQ0FDcEQsU0FBUyxFQUNULFlBQVksRUFDWixtQkFBbUIsQ0FBQyxJQUFJLEVBQ3hCLG1CQUFtQixDQUFDLElBQUksQ0FBQyxJQUFJLEVBQzdCLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQzs0QkFDdkIsa0JBQWtCLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDOzRCQUN0QywwQkFBMEIsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUM7d0JBQ2xELENBQUMsQ0FBQyxDQUFDO3dCQUVILDRCQUE0Qjt3QkFDNUIsQ0FBQyxDQUFDLElBQUksQ0FBQywwQkFBMEIsRUFBRSxVQUFDLGNBQWMsRUFBRSxDQUFDOzRCQUNuRCxJQUFNLFlBQVksR0FBRyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsQ0FBQzs0QkFDM0MsY0FBYyxDQUFDLFVBQVUsR0FBRyxZQUFZLENBQUMsVUFBVSxDQUFDOzRCQUNwRCxTQUFTLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxJQUFJLEVBQUUsY0FBYyxDQUFDLENBQUM7NEJBQ3JELEtBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxJQUFJLEVBQUUsY0FBYyxDQUFDLENBQUM7d0JBQzVELENBQUMsQ0FBQyxDQUFDO3FCQUNKO29CQUVELDJFQUEyRTtvQkFDM0Usb0VBQW9FO29CQUNwRSx5RUFBeUU7b0JBQ3pFLDBFQUEwRTtvQkFDMUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUFFLEVBQUUsVUFBQSxTQUFTO3dCQUVqQyxJQUFJLGVBQWUsR0FBRyxLQUFJLENBQUMsMkJBQTJCLENBQUMsU0FBUyxDQUFDLENBQUM7d0JBQ2xFLElBQUksU0FBUyxHQUFHLGVBQWUsQ0FBQyxJQUFJLENBQUM7d0JBRXJDLFNBQVMsQ0FBQyxPQUFPLENBQUMsU0FBUyxFQUFFLGVBQWUsQ0FBQyxDQUFDO3dCQUU5QyxJQUFJLENBQUMsU0FBUyxDQUFDLFdBQVcsRUFBRTs0QkFDMUIsQ0FBQyxDQUFDLElBQUksQ0FBVSxTQUFVLENBQUMsWUFBWSxFQUFFLFVBQUEsU0FBUztnQ0FDaEQsSUFBSSxrQkFBa0IsR0FBRyxJQUFJLGtCQUFrQixDQUFDLElBQUksQ0FBQyxDQUFDO2dDQUN0RCxJQUFJLGNBQWMsR0FBRyxJQUFJLGNBQWMsQ0FBQyxTQUFTLENBQUMsQ0FBQztnQ0FDbkQsZUFBZSxDQUFDLGVBQWUsRUFBRSxTQUFTLEVBQUUsY0FBYyxFQUFFLGtCQUFrQixFQUMxRSxjQUFjLENBQUMsUUFBUSxDQUFDLENBQUM7Z0NBQzdCLEtBQUksQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxHQUFHLGNBQWMsQ0FBQzs0QkFDOUMsQ0FBQyxDQUFDLENBQUM7NEJBQ0gsQ0FBQyxDQUFDLElBQUksQ0FBVSxTQUFVLENBQUMsYUFBYSxFQUFFLFVBQUEsU0FBUztnQ0FDakQsSUFBSSxrQkFBa0IsR0FBRyxJQUFJLGtCQUFrQixDQUFDLElBQUksQ0FBQyxDQUFDO2dDQUN0RCxJQUFJLGNBQWMsR0FBRyxJQUFJLGNBQWMsQ0FBQyxTQUFTLENBQUMsQ0FBQztnQ0FDbkQsZ0JBQWdCLENBQUMsZUFBZSxFQUFFLFNBQVMsRUFBRSxjQUFjLEVBQUUsa0JBQWtCLEVBQzNFLGNBQWMsQ0FBQyxPQUFPLENBQUMsQ0FBQztnQ0FDNUIsS0FBSSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLEdBQUcsY0FBYyxDQUFDOzRCQUM5QyxDQUFDLENBQUMsQ0FBQzt5QkFDSjtvQkFFSCxDQUFDLENBQUMsQ0FBQztvQkFFSCx1REFBdUQ7b0JBQ3ZELENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssRUFBRSxFQUFFLFVBQUEsT0FBTzt3QkFDL0IsSUFBSSxRQUFRLEdBQUcsU0FBUyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQzt3QkFDdkMsSUFBSSxrQkFBa0IsR0FBRyxJQUFJLGtCQUFrQixDQUFDLFFBQVEsQ0FBQyxDQUFDO3dCQUMxRCxrQkFBa0IsQ0FBQyxVQUFVOzRCQUN6QixLQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLElBQUksS0FBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDO3dCQUN6RSxTQUFTLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEVBQUUsT0FBTyxDQUFDLENBQUMsRUFBRSxrQkFBa0IsQ0FBQyxDQUFDO29CQUM5RCxDQUFDLENBQUMsQ0FBQztvQkFFSCxJQUFJLE1BQU0sQ0FBQyxnQkFBZ0I7d0JBQ3ZCLG1CQUFtQixDQUFDLElBQUksQ0FBQyxJQUFJLEtBQUssUUFBQSxRQUFRLENBQUMsSUFBSSxFQUFFO3dCQUNuRCxrQkFBa0IsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO3FCQUN6QztvQkFFRCx5RUFBeUU7b0JBQ3pFLDRFQUE0RTtvQkFDNUUsb0VBQW9FO29CQUNwRSxJQUFJLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLGdCQUFnQixDQUFDLEVBQUU7d0JBQy9DLElBQUksQ0FBQyxxQ0FBcUMsQ0FBQyxTQUFTLENBQUMsQ0FBQztxQkFDdkQ7b0JBRUQsSUFBSSxRQUFRLEtBQUssRUFBRSxDQUFDLEtBQUssQ0FBQyxTQUFTLEVBQUU7d0JBQ25DLHFFQUFxRTt3QkFDckUsa0RBQWtEO3dCQUNsRCxDQUFDLENBQUMsTUFBTSxDQUNKLElBQUksQ0FBQyxTQUFTLENBQUMsZ0JBQWdCLEVBQy9CLFVBQUMsbUJBQW1CLEVBQUUsWUFBWTs0QkFDcEMsSUFBTSxJQUFJLEdBQUcsbUJBQW1CLENBQUMsSUFBSSxDQUFDOzRCQUN0QyxJQUFNLGVBQWUsR0FBRyxLQUFJLENBQUMsMkJBQTJCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDOzRCQUNwRSxtQkFBbUIsQ0FBQyx1QkFBdUIsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUM7NEJBRWxFLHdEQUF3RDs0QkFDeEQsZUFBZSxDQUFDLElBQUksQ0FBQyxPQUFPLEdBQUcsUUFBQSxhQUFhLENBQUMsT0FBTyxDQUFDOzRCQUNyRCxTQUFTLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQzt3QkFDbEMsQ0FBQyxDQUFDLENBQUM7cUJBQ0o7b0JBRUQsMEVBQTBFO29CQUMxRSxJQUFJLFVBQVUsR0FBRyxtQkFBbUIsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDO29CQUNyRCxJQUFJLENBQUMsVUFBVSxFQUFFO3dCQUNmLE9BQU87cUJBQ1I7b0JBQ0QsSUFBSSxjQUFjLEdBQ00sSUFBSSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUM7b0JBRXBELDREQUE0RDtvQkFDNUQsSUFBSSxpQkFBaUIsR0FBRyxVQUFDLE9BQU87d0JBQUUsY0FBTzs2QkFBUCxVQUFPLEVBQVAscUJBQU8sRUFBUCxJQUFPOzRCQUFQLDZCQUFPOzt3QkFDckMsT0FBQSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztvQkFBaEQsQ0FBZ0QsQ0FBQztvQkFFckQsNkJBQTZCO29CQUM3QixJQUFJLFdBQVcsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsQ0FBQztvQkFFMUQsc0VBQXNFO29CQUN0RSxJQUFJLFdBQVcsR0FBRzt3QkFDaEIsd0VBQXdFO3dCQUN4RSxFQUFFLEVBQWlDLEVBQUU7d0JBQ3JDLHlFQUF5RTt3QkFDekUsR0FBRyxFQUFpQyxFQUFFO3dCQUN0Qyw2REFBNkQ7d0JBQzdELE9BQU8sRUFBaUMsRUFBRTtxQkFDM0MsQ0FBQztvQkFDRixDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLEVBQUUsRUFBRSxVQUFBLENBQUM7d0JBQzNCLGtFQUFrRTt3QkFDbEUsSUFBSSxPQUFPLEdBQUcsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUNwQyxJQUFJLFNBQVMsR0FBRyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQ3BDLElBQUksUUFBUSxHQUFHLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQ25DLElBQUksQ0FBQyxRQUFRLENBQUMsZUFBZSxFQUFFOzRCQUM3QixXQUFXLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQztnQ0FDNUIsQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQzt5QkFDN0M7NkJBQU0sSUFBSSxPQUFPLEVBQUU7NEJBQ2xCLFdBQVcsQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQzt5QkFDcEU7NkJBQU07NEJBQ0wsV0FBVyxDQUFDLEVBQUUsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO3lCQUNsRTtvQkFDSCxDQUFDLENBQUMsQ0FBQztvQkFFSCwyREFBMkQ7b0JBQzNELElBQUksZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxVQUFVLEVBQUUsQ0FBQztvQkFDbkQsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxFQUFFLEVBQUUsVUFBQSxhQUFhO3dCQUN2QyxJQUFJLGNBQWMsR0FBRyxXQUFXLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDO3dCQUVyRCxpRUFBaUU7d0JBQ2pFLHlEQUF5RDt3QkFDekQsSUFBSSxPQUFPLEdBQUcsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUVoRCx3RUFBd0U7d0JBQ3hFLHlFQUF5RTt3QkFDekUsNkNBQTZDO3dCQUN6QyxJQUFBOzs4REFHa0MsRUFIakMsaUJBQVMsRUFBRSxpQkFBUyxDQUdjO3dCQUV2QyxJQUFJLGVBQWUsR0FBRyxLQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDO3dCQUM1QyxJQUFJLGVBQWUsR0FBRyxLQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDO3dCQUM1QyxJQUFJLFNBQVMsR0FDWCxlQUFlLENBQUMsQ0FBQzs0QkFDZixlQUFlLENBQUMsSUFBSSxDQUFDLENBQUM7NEJBQ3RCLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxDQUFDO3dCQUVoQyxvRUFBb0U7d0JBQ3BFLHNFQUFzRTt3QkFDdEUsb0VBQW9FO3dCQUNwRSxJQUFJLHVCQUF1QixHQUFHLENBQUMsY0FBYyxDQUFDLGVBQWU7NEJBQzNELFdBQVcsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLEdBQUcsTUFBTSxDQUFDLGdCQUFnQixDQUFDO3dCQUV2RCxJQUFBOzsyRkFHK0QsRUFINUQsd0JBQWdCLENBRzZDO3dCQUVwRSwwRUFBMEU7d0JBQzFFLHdFQUF3RTt3QkFDeEUsaUVBQWlFO3dCQUNqRSxJQUFJLGdCQUFnQixHQUNoQixDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDO3dCQUM1RCxJQUFJLGlCQUFpQixHQUFHLGdCQUFnQixHQUFHLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQzt3QkFFdEUsMEVBQTBFO3dCQUMxRSxtRUFBbUU7d0JBQ25FLHFFQUFxRTt3QkFDckUsbUVBQW1FO3dCQUNuRSxJQUFJLGlCQUFpQixHQUFHLElBQUksQ0FBQzt3QkFFN0IsK0NBQStDO3dCQUMvQyxvQ0FBb0M7d0JBQ3BDLDRDQUE0Qzt3QkFDNUMseUVBQXlFO3dCQUN6RSxzRUFBc0U7d0JBQ3RFLElBQUksaUJBQWlCLEdBQUcsS0FBSyxDQUFDO3dCQUM5QixJQUFJLE1BQU0sQ0FBQyxpQkFBaUI7NEJBQ3hCLENBQUMsaUJBQWlCOzRCQUNsQixDQUFDLHVCQUF1Qjs0QkFDeEIsZUFBZSxDQUFDLFFBQVEsRUFBRSxFQUFFOzRCQUU5QixzREFBc0Q7NEJBQ3RELElBQUkscUJBQXFCLEdBQUcsVUFBQSxVQUFVO2dDQUNwQyxJQUFJLGdCQUFnQixHQUNsQixPQUFPLENBQUMsQ0FBQztvQ0FDUCxFQUFFLENBQUMsRUFBRSxVQUFVLEVBQUUsQ0FBQyxFQUFFLFFBQVEsRUFBRSxDQUFDLENBQUM7b0NBQ2hDLEVBQUUsQ0FBQyxFQUFFLFFBQVEsRUFBRSxDQUFDLEVBQUUsVUFBVSxFQUFFLENBQUM7Z0NBQ25DLE9BQ0UsY0FBYyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsQ0FBQzs0QkFDcEQsQ0FBQyxDQUFDOzRCQUVGLGlCQUFpQixHQUFHLHFCQUFxQixDQUFDLFNBQVMsQ0FBQyxDQUFDOzRCQUNyRCxJQUFJLENBQUMsaUJBQWlCLEVBQUU7Z0NBQ3RCLGlCQUFpQixHQUFHLHFCQUFxQixDQUNyQyxpQkFBaUIsQ0FBQyxPQUFPLEVBQUUsU0FBUyxFQUFFLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDOzZCQUM3RDs0QkFFRCxpQkFBaUIsR0FBRyxDQUFDLENBQUMsaUJBQWlCLENBQUM7eUJBQ3pDO3dCQUVELG9FQUFvRTt3QkFDcEUscUVBQXFFO3dCQUNyRSxvRUFBb0U7d0JBQ3BFLCtDQUErQzt3QkFDL0MsRUFBRTt3QkFDRiwwRUFBMEU7d0JBQzFFLDBFQUEwRTt3QkFDMUUsdUVBQXVFO3dCQUN2RSxpQkFBaUI7d0JBQ2pCLEVBQUU7d0JBQ0YseUJBQXlCO3dCQUN6Qix5QkFBeUI7d0JBQ3pCLDBDQUEwQzt3QkFDMUMsMENBQTBDO3dCQUMxQywwQ0FBMEM7d0JBQzFDLDBDQUEwQzt3QkFDMUMsMENBQTBDO3dCQUMxQywwQ0FBMEM7d0JBQzFDLHlCQUF5Qjt3QkFDekIsRUFBRTt3QkFDRixzRUFBc0U7d0JBQ3RFLHlFQUF5RTt3QkFDekUscUNBQXFDO3dCQUNyQyxFQUFFO3dCQUNGLHNFQUFzRTt3QkFDdEUsd0VBQXdFO3dCQUN4RSxxRUFBcUU7d0JBQ3JFLDBFQUEwRTt3QkFDMUUsaUVBQWlFO3dCQUNqRSxFQUFFO3dCQUNGLHFFQUFxRTt3QkFDckUsd0VBQXdFO3dCQUN4RSxvRUFBb0U7d0JBQ3BFLG9FQUFvRTt3QkFDcEUsSUFBSSxTQUFTLEdBQUcsS0FBSyxDQUFDO3dCQUN0QixJQUFJLGlCQUFpQixJQUFJLENBQUMsY0FBYyxDQUFDLGVBQWUsRUFBRTs0QkFDeEQsbUVBQW1FOzRCQUNuRSxrRUFBa0U7NEJBQ2xFLElBQUksb0JBQW9CLEdBQUcsaUJBQWlCLENBQUM7NEJBQzdDLElBQUksWUFBWSxHQUFHLGNBQWMsQ0FBQyxJQUFJLENBQUM7NEJBQ3ZDLE9BQU8sb0JBQW9CLENBQUMsaUJBQWlCLEVBQUU7Z0NBQzdDLG9CQUFvQixHQUFHLG9CQUFvQixDQUFDLGlCQUFpQixDQUFDO2dDQUM5RCxZQUFZLEdBQWMsWUFBWSxDQUFDLFVBQVUsQ0FBQzs2QkFDbkQ7NEJBRUQsdUVBQXVFOzRCQUN2RSxvRUFBb0U7NEJBQ3BFLHlCQUF5Qjs0QkFDekIsSUFBSSxRQUFRLEdBQUcsS0FBSSxDQUFDLFNBQVMsQ0FBQyxzQkFBc0IsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUM7NEJBQ3hFLElBQUksQ0FBQyxHQUFHLG9CQUFvQixDQUFDLFFBQVEsQ0FBQzs0QkFDdEMsU0FBUyxHQUFHLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzt5QkFDM0M7d0JBRUQsaURBQWlEO3dCQUNqRCxpQkFBaUIsR0FBRyxpQkFBaUIsSUFBSSxDQUFDLFNBQVMsQ0FBQzt3QkFFcEQsZ0VBQWdFO3dCQUNoRSxzQkFBc0I7d0JBQ3RCLElBQUksQ0FBQyxpQkFBaUIsRUFBRTs0QkFDdEIsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLElBQUksVUFBVSxDQUNoQyxTQUFTLEVBQ1QsZUFBZSxFQUNmLElBQUksa0JBQWtCLENBQUMsY0FBYyxDQUFDLEVBQ3RDLGNBQWMsQ0FBQyxRQUFRLEVBQ3ZCLE9BQU8sQ0FBQyxDQUFDLENBQUM7NEJBQ2QsT0FBTzt5QkFDUjt3QkFFRCx5RUFBeUU7d0JBRXpFLHlEQUF5RDt3QkFDekQsSUFBSSxtQkFBbUIsR0FBRyxpQkFBaUIsQ0FBQyxPQUFPLEVBQUUsUUFBUSxDQUFDLENBQUM7d0JBQy9ELElBQUksY0FBYyxHQUFHLGlCQUFpQixDQUFDLE9BQU8sRUFBRSxTQUFTLEVBQUUsUUFBUSxDQUFDLENBQUM7d0JBQ3JFLElBQUksb0JBQW9CLEdBQUcsU0FBUyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQzt3QkFDMUQsSUFBSSxDQUFDLG9CQUFvQixFQUFFOzRCQUV6QixnRUFBZ0U7NEJBQ2hFLElBQUksbUJBQW1CLEdBQUcsU0FBUyxDQUFDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDOzRCQUM5RCxJQUFJLENBQUMsbUJBQW1CLEVBQUU7Z0NBQ3hCLElBQUksbUJBQW1CLEdBQWU7b0NBQ3BDLDZCQUE2QjtvQ0FDN0IsSUFBSSxFQUFFLG1CQUFtQjtvQ0FDekIsSUFBSSxFQUFFLFFBQUEsUUFBUSxDQUFDLE1BQU07b0NBQ3JCLDBCQUEwQjtvQ0FDMUIsV0FBVyxFQUFFLEtBQUs7b0NBQ2xCLFdBQVcsRUFBRSxDQUFDO29DQUNkLFVBQVUsRUFBRSxJQUFJO29DQUNoQixLQUFLLEVBQUUsSUFBSTtvQ0FDWCxPQUFPLEVBQUUsUUFBQSxhQUFhLENBQUMsV0FBVztvQ0FDbEMseUJBQXlCO29DQUN6QixPQUFPLEVBQUUsT0FBTztvQ0FDaEIsY0FBYyxFQUFFLEVBQUU7aUNBQ25CLENBQUM7Z0NBQ0YsbUJBQW1CO29DQUNqQixJQUFJLGNBQWMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO2dDQUMxQyxLQUFJLENBQUMsS0FBSyxDQUFDLG1CQUFtQixDQUFDLEdBQUcsbUJBQW1CLENBQUM7Z0NBQ3RELFNBQVMsQ0FBQyxPQUFPLENBQUMsbUJBQW1CLEVBQUUsbUJBQW1CLENBQUMsQ0FBQzs2QkFDN0Q7NEJBRUQsSUFBSSxVQUFVLEdBQWU7Z0NBQzNCLDZCQUE2QjtnQ0FDN0IsSUFBSSxFQUFFLGNBQWM7Z0NBQ3BCLElBQUksRUFBRSxRQUFBLFFBQVEsQ0FBQyxNQUFNO2dDQUNyQiwrQkFBK0I7Z0NBQy9CLFdBQVcsRUFBRSxLQUFLO2dDQUNsQixXQUFXLEVBQUUsQ0FBQztnQ0FDZCxVQUFVLEVBQUUsSUFBSTtnQ0FDaEIsS0FBSyxFQUFFLElBQUk7Z0NBQ1gsT0FBTyxFQUFFLFFBQUEsYUFBYSxDQUFDLFdBQVc7Z0NBQ2xDLHlCQUF5QjtnQ0FDekIsT0FBTyxFQUFFLE9BQU87Z0NBQ2hCLGNBQWMsRUFBRSxFQUFFOzZCQUNuQixDQUFDOzRCQUNGLG9CQUFvQixHQUFHLElBQUksY0FBYyxDQUFDLFVBQVUsQ0FBQyxDQUFDOzRCQUN0RCxLQUFJLENBQUMsS0FBSyxDQUFDLGNBQWMsQ0FBQyxHQUFHLG9CQUFvQixDQUFDOzRCQUNsRCxTQUFTLENBQUMsT0FBTyxDQUFDLGNBQWMsRUFBRSxvQkFBb0IsQ0FBQyxDQUFDOzRCQUV4RCwrREFBK0Q7NEJBQy9ELFNBQVMsQ0FBQyxTQUFTLENBQUMsY0FBYyxFQUFFLG1CQUFtQixDQUFDLENBQUM7NEJBQ3pELG1CQUFtQixDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQzt5QkFDeEM7d0JBRUQsMkNBQTJDO3dCQUMzQyxJQUFJLG9CQUFvQixHQUN0QixJQUFJLGtCQUFrQixDQUFDLGNBQWMsQ0FBQyxDQUFDO3dCQUN6QyxvQkFBb0IsQ0FBQyxpQkFBaUIsR0FBRyxpQkFBaUIsQ0FBQzt3QkFDM0QsT0FBTyxDQUFDLENBQUM7NEJBQ1AsU0FBUyxDQUFDLE9BQU8sQ0FBQyxjQUFjLEVBQUUsU0FBUyxFQUFFLG9CQUFvQixDQUFDLENBQUMsQ0FBQzs0QkFDcEUsU0FBUyxDQUFDLE9BQU8sQ0FBQyxTQUFTLEVBQUUsY0FBYyxFQUFFLG9CQUFvQixDQUFDLENBQUM7b0JBRXZFLENBQUMsQ0FBQyxDQUFDLENBQUMsaUNBQWlDO29CQUVyQywwRUFBMEU7b0JBQzFFLHlFQUF5RTtvQkFDekUsc0RBQXNEO29CQUN0RCxFQUFFO29CQUNGLHdFQUF3RTtvQkFDeEUseUVBQXlFO29CQUN6RSwyQ0FBMkM7b0JBQzNDLEVBQUU7b0JBQ0YscUVBQXFFO29CQUNyRSw0RUFBNEU7b0JBQzVFLHNDQUFzQztvQkFDdEMsRUFBRTtvQkFDRiwrQkFBK0I7b0JBQy9CLCtCQUErQjtvQkFDL0IsK0JBQStCO29CQUMvQiwrQkFBK0I7b0JBQy9CLCtCQUErQjtvQkFDL0IsK0JBQStCO29CQUMvQiwrQkFBK0I7b0JBQy9CLCtCQUErQjtvQkFDL0IsK0JBQStCO29CQUMvQiwrQkFBK0I7b0JBQy9CLCtCQUErQjtvQkFDL0IsK0JBQStCO29CQUMvQiwrQkFBK0I7b0JBQy9CLEVBQUU7b0JBQ0Ysc0VBQXNFO29CQUN0RSxzRUFBc0U7b0JBQ3RFLDJDQUEyQztvQkFDM0MsRUFBRTtvQkFDRix3RUFBd0U7b0JBQ3hFLHdFQUF3RTtvQkFDeEUseUVBQXlFO29CQUN6RSxXQUFXO29CQUNYLEVBQUU7b0JBQ0YseUVBQXlFO29CQUN6RSxtRUFBbUU7b0JBQ25FLHFEQUFxRDtvQkFDckQsRUFBRTtvQkFDRiwrQkFBK0I7b0JBQy9CLCtCQUErQjtvQkFDL0IsK0JBQStCO29CQUMvQiwrQkFBK0I7b0JBQy9CLCtCQUErQjtvQkFDL0IsK0JBQStCO29CQUMvQiwrQkFBK0I7b0JBQy9CLCtCQUErQjtvQkFDL0IsK0JBQStCO29CQUMvQiwrQkFBK0I7b0JBQy9CLCtCQUErQjtvQkFDL0IsK0JBQStCO29CQUMvQiwrQkFBK0I7b0JBQy9CLCtCQUErQjtvQkFDL0IsK0JBQStCO29CQUMvQiwrQkFBK0I7b0JBQy9CLEVBQUU7b0JBQ0YseUVBQXlFO29CQUN6RSx3RUFBd0U7b0JBQ3hFLDJDQUEyQztvQkFDM0MsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksRUFBRSxLQUFLLENBQUMsRUFBRSxVQUFBLE9BQU87d0JBQzNCLElBQUksbUJBQW1CLEdBQUcsaUJBQWlCLENBQUMsT0FBTyxFQUFFLFFBQVEsQ0FBQyxDQUFDO3dCQUMvRCxJQUFJLG1CQUFtQixHQUFHLFNBQVMsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsQ0FBQzt3QkFDOUQsSUFBSSxDQUFDLG1CQUFtQixFQUFFOzRCQUN4QixPQUFPO3lCQUNSO3dCQUNELENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssRUFBRSxFQUFFLFVBQUEsU0FBUzs0QkFDakMsc0VBQXNFOzRCQUN0RSw2Q0FBNkM7NEJBQzdDLElBQUksYUFBYSxHQUFHLFNBQVMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7NEJBQzlDLElBQUksYUFBYSxDQUFDLElBQUksQ0FBQyxJQUFJLEtBQUssUUFBQSxRQUFRLENBQUMsTUFBTSxFQUFFO2dDQUMvQyxPQUFPOzZCQUNSOzRCQUNELElBQUksVUFBVSxHQUFHLE9BQU8sQ0FBQyxDQUFDO2dDQUN4QixDQUFDLFNBQVMsQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7Z0NBQzNDLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsQ0FBQyxNQUFNLENBQUM7NEJBQzFDLElBQUksQ0FBQyxVQUFVLEVBQUU7Z0NBQ2YsT0FBTzs2QkFDUjs0QkFFRCxtRUFBbUU7NEJBQ25FLGtFQUFrRTs0QkFDbEUsdUVBQXVFOzRCQUN2RSxrRUFBa0U7NEJBQ2xFLGtFQUFrRTs0QkFDbEUsSUFBSSxrQkFBa0IsR0FDbEIsaUJBQWlCLENBQUMsT0FBTyxFQUFFLFFBQVEsRUFBRSxtQkFBbUIsQ0FBQyxDQUFDOzRCQUM5RCxJQUFJLG9CQUFvQixHQUFHLFNBQVMsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsQ0FBQzs0QkFDOUQsSUFBSSxDQUFDLG9CQUFvQixFQUFFO2dDQUN6QixJQUFJLFVBQVUsR0FBZTtvQ0FDM0IsNkJBQTZCO29DQUM3QixJQUFJLEVBQUUsa0JBQWtCO29DQUN4QixJQUFJLEVBQUUsUUFBQSxRQUFRLENBQUMsTUFBTTtvQ0FDckIsK0JBQStCO29DQUMvQixXQUFXLEVBQUUsS0FBSztvQ0FDbEIsV0FBVyxFQUFFLENBQUM7b0NBQ2QsVUFBVSxFQUFFLElBQUk7b0NBQ2hCLEtBQUssRUFBRSxJQUFJO29DQUNYLE9BQU8sRUFBRSxRQUFBLGFBQWEsQ0FBQyxXQUFXO29DQUNsQyx5QkFBeUI7b0NBQ3pCLE9BQU8sRUFBRSxPQUFPO29DQUNoQixjQUFjLEVBQUUsRUFBRTtpQ0FDbkIsQ0FBQztnQ0FDRixvQkFBb0IsR0FBRyxJQUFJLGNBQWMsQ0FBQyxVQUFVLENBQUMsQ0FBQztnQ0FDdEQsb0JBQW9CLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQztnQ0FDdkMsS0FBSSxDQUFDLEtBQUssQ0FBQyxrQkFBa0IsQ0FBQyxHQUFHLG9CQUFvQixDQUFDO2dDQUN0RCxTQUFTLENBQUMsT0FBTyxDQUFDLGtCQUFrQixFQUFFLG9CQUFvQixDQUFDLENBQUM7Z0NBQzVELG1CQUFtQixDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztnQ0FDdkMsU0FBUyxDQUFDLFNBQVMsQ0FBQyxrQkFBa0IsRUFBRSxtQkFBbUIsQ0FBQyxDQUFDOzZCQUM5RDs0QkFFRCxnREFBZ0Q7NEJBQ2hELElBQUksc0JBQXNCLEdBQUcsSUFBSSxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsQ0FBQzs0QkFDMUQsc0JBQXNCLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQzs0QkFDekMsc0JBQXNCLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQyxrQ0FBa0M7NEJBQ25FLE9BQU8sQ0FBQyxDQUFDO2dDQUNQLFNBQVMsQ0FBQyxPQUFPLENBQ2Isa0JBQWtCLEVBQUUsU0FBUyxFQUFFLHNCQUFzQixDQUFDLENBQUMsQ0FBQztnQ0FDNUQsU0FBUyxDQUFDLE9BQU8sQ0FDYixTQUFTLEVBQUUsa0JBQWtCLEVBQUUsc0JBQXNCLENBQUMsQ0FBQzt3QkFDL0QsQ0FBQyxDQUFDLENBQUM7b0JBQ0wsQ0FBQyxDQUFDLENBQUM7Z0JBQ0wsQ0FBQztnQkFFRDs7Ozs7OzttQkFPRztnQkFDSywrREFBcUMsR0FBN0MsVUFDSSxTQUFxRDtvQkFEekQsaUJBbUNDO29CQWpDQyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLEVBQUUsRUFBRSxVQUFBLE9BQU87d0JBQy9CLElBQUksUUFBUSxHQUFHLFNBQVMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7d0JBQ3ZDLElBQUksa0JBQWtCLEdBQUcsSUFBSSxrQkFBa0IsQ0FBQyxRQUFRLENBQUMsQ0FBQzt3QkFDMUQsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxRQUFRLENBQUMsWUFBWSxFQUM5QyxVQUFBLFFBQVE7NEJBQ1YsSUFBTSxjQUFjLEdBQUcsUUFBUSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxlQUFlLENBQUMsQ0FBQzs0QkFFbEUsS0FBSyxJQUFJLENBQUMsR0FBRyxjQUFjLENBQUMsTUFBTSxFQUFFLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUU7Z0NBQy9DLElBQU0scUJBQXFCLEdBQUcsY0FBYyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7Z0NBQ3pELElBQU0sSUFBSSxHQUFHLEtBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUM1QixxQkFBcUIsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDO2dDQUMxRCxJQUFJLElBQUksRUFBRTtvQ0FDUixJQUFJLElBQUksQ0FBQyxJQUFJLEtBQUssUUFBQSxRQUFRLENBQUMsRUFBRTt3Q0FDekIsS0FBSSxDQUFDLFNBQVMsQ0FBQyxnQkFBZ0IsQ0FBRSxJQUFlLENBQUMsRUFBRSxDQUFDLEVBQUU7d0NBQ3hELEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxxQkFBcUIsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7NENBQ3JELCtDQUErQzs0Q0FDL0MsSUFBTSxlQUFlLEdBQUcscUJBQXFCO2lEQUN4QyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLGVBQWUsQ0FBQyxDQUFDOzRDQUNoRCxJQUFJLENBQUMsZUFBZSxFQUFFO2dEQUNwQixTQUFTOzZDQUNWOzRDQUVELDhDQUE4Qzs0Q0FDOUMsS0FBSSxDQUFDLGlCQUFpQixDQUFDLGVBQWUsQ0FBQyxDQUFDO3lDQUN6QztxQ0FDRjtvQ0FFRCxtREFBbUQ7b0NBQ25ELE1BQU07aUNBQ1A7NkJBQ0Y7d0JBQ0gsQ0FBQyxDQUFDLENBQUM7b0JBQ0wsQ0FBQyxDQUFDLENBQUM7Z0JBQ0wsQ0FBQztnQkFDSCxzQkFBQztZQUFELENBQUMsQUEvb0NELElBK29DQztZQS9vQ1ksc0JBQWUsa0JBK29DM0IsQ0FBQTtZQUVEOzs7Ozs7O2VBT0c7WUFDSDtnQkFvQ0U7Ozs7Ozs7Ozs7Ozs7bUJBYUc7Z0JBQ0gsb0JBQVksSUFBVSxFQUFFLGNBQThCLEVBQ2xELGtCQUFzQyxFQUFFLElBQW9CLEVBQzVELElBQWE7b0JBQ2YsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUM7b0JBQ2pCLElBQUksQ0FBQyxjQUFjLEdBQUcsY0FBYyxDQUFDO29CQUNyQyxJQUFJLENBQUMsa0JBQWtCLEdBQUcsa0JBQWtCLENBQUM7b0JBQzdDLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDO29CQUMzQixpQ0FBaUM7b0JBQ2pDLElBQUksQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO29CQUNaLElBQUksQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO29CQUNaLElBQUksQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDO29CQUNmLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO29CQUNoQix3RUFBd0U7b0JBQ3hFLGlEQUFpRDtvQkFDakQsSUFBSSxrQkFBa0IsSUFBSSxrQkFBa0IsQ0FBQyxRQUFRLEVBQUU7d0JBQ3JELElBQUksQ0FBQyxDQUFDLEdBQUcsa0JBQWtCLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQzt3QkFDdkMsSUFBSSxDQUFDLENBQUMsR0FBRyxrQkFBa0IsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO3FCQUN4QztvQkFFRCxJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQztvQkFDakIsSUFBSSxDQUFDLE1BQU0sR0FBRyxFQUFFLENBQUM7Z0JBQ25CLENBQUM7Z0JBQ0gsaUJBQUM7WUFBRCxDQUFDLEFBeEVELElBd0VDO1lBeEVZLGlCQUFVLGFBd0V0QixDQUFBO1lBQUEsQ0FBQztZQUVGLElBQVksY0FBc0Q7WUFBbEUsV0FBWSxjQUFjO2dCQUFFLDJEQUFRLENBQUE7Z0JBQUUsMkRBQVEsQ0FBQTtnQkFBRSx5REFBTyxDQUFBO2dCQUFFLDJEQUFRLENBQUE7WUFBQSxDQUFDLEVBQXRELGNBQWMsR0FBZCxxQkFBYyxLQUFkLHFCQUFjLFFBQXdDO1lBQUEsQ0FBQztZQUVuRTs7O2VBR0c7WUFDSDtnQkFhRTtvQkFDRSxJQUFJLENBQUMsSUFBSSxHQUFHLEVBQUUsQ0FBQztvQkFDZixJQUFJLENBQUMsU0FBUyxHQUFHLEVBQUUsQ0FBQztnQkFDdEIsQ0FBQztnQkFFRDs7O21CQUdHO2dCQUNILDZCQUFJLEdBQUosVUFBSyxVQUFzQjtvQkFDekIsSUFBSSxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksSUFBSSxJQUFJLENBQUMsU0FBUyxFQUFFO3dCQUMxQyxPQUFPLENBQUMsNkJBQTZCO3FCQUN0QztvQkFDRCxJQUFJLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDO29CQUU1QyxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQyxjQUFjLEVBQUU7d0JBQzVDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO3dCQUMzQixPQUFPO3FCQUNSO29CQUVELElBQUksY0FBYyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUM7b0JBQ3JELElBQUksY0FBYyxDQUFDLGNBQWMsS0FBSyxjQUFjLENBQUMsUUFBUSxFQUFFO3dCQUM3RCxJQUFJLGNBQVksR0FBaUIsY0FBYyxDQUFDLElBQUksQ0FBQzt3QkFDckQsY0FBWSxDQUFDLGVBQWUsQ0FBQyxFQUFFLGNBQVksQ0FBQyxZQUFZLENBQUMsQ0FBQzt3QkFDMUQsT0FBTztxQkFDUjtvQkFFRCxJQUFJLFlBQVksR0FBRyxJQUFJLEVBQUUsQ0FBQyxLQUFLLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQ3BELElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksVUFBVSxDQUFDLFlBQVksRUFDdEMsSUFBSSxjQUFjLENBQUMsWUFBWSxDQUFDLEVBQUUsSUFBSSxFQUN0QyxjQUFjLENBQUMsUUFBUSxFQUFFLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO2dCQUNqRCxDQUFDO2dCQUNILHFCQUFDO1lBQUQsQ0FBQyxBQTdDRCxJQTZDQztZQTdDWSxxQkFBYyxpQkE2QzFCLENBQUE7WUFFRDs7ZUFFRztZQUNIO2dCQTBJRSx3QkFBWSxJQUFVO29CQUNwQixJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQztvQkFDakIsSUFBSSxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUM7b0JBQ3RCLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxjQUFjLEVBQUUsQ0FBQztvQkFDMUMsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLGNBQWMsRUFBRSxDQUFDO29CQUMzQyw2QkFBNkI7b0JBQzdCLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO29CQUNYLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO29CQUNYLElBQUksQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDO29CQUNmLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO29CQUNoQixJQUFJLENBQUMsVUFBVSxHQUFHLENBQUMsQ0FBQztvQkFDcEIsSUFBSSxDQUFDLFdBQVcsR0FBRyxDQUFDLENBQUM7b0JBRXJCLElBQUksQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDO29CQUV0QiwyQkFBMkI7b0JBQzNCLElBQUksQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDO29CQUV4Qix1QkFBdUI7b0JBQ3ZCLElBQUksQ0FBQyxXQUFXLEdBQUcsQ0FBQyxDQUFDO29CQUNyQixJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztvQkFFaEIsMkJBQTJCO29CQUMzQixJQUFJLENBQUMsV0FBVyxHQUFHLENBQUMsQ0FBQztvQkFDckIsSUFBSSxDQUFDLFVBQVUsR0FBRyxDQUFDLENBQUM7b0JBQ3BCLElBQUksQ0FBQyxXQUFXLEdBQUcsQ0FBQyxDQUFDO29CQUNyQixJQUFJLENBQUMsWUFBWSxHQUFHLENBQUMsQ0FBQztvQkFDdEIsSUFBSSxDQUFDLGFBQWEsR0FBRyxDQUFDLENBQUM7b0JBQ3ZCLElBQUksQ0FBQyxXQUFXLEdBQUcsS0FBSyxDQUFDO29CQUN6QixJQUFJLENBQUMsWUFBWSxHQUFHLEtBQUssQ0FBQztvQkFDMUIsSUFBSSxDQUFDLE9BQU8sR0FBRyxFQUFDLEtBQUssRUFBRSxDQUFDLEVBQUUsTUFBTSxFQUFFLENBQUMsRUFBQyxDQUFDO29CQUVyQyxvRUFBb0U7b0JBQ3BFLElBQUksQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDO29CQUV4QixnRUFBZ0U7b0JBQ2hFLFFBQVE7b0JBQ1IsSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FDbEMsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxlQUFlLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztvQkFFekQsSUFBSSxJQUFJLENBQUMsSUFBSSxLQUFLLFFBQUEsUUFBUSxDQUFDLElBQUk7d0JBQzFCLElBQWlCLENBQUMsa0JBQWtCLEVBQUU7d0JBQ3pDLGlFQUFpRTt3QkFDakUsZ0VBQWdFO3dCQUNoRSw0REFBNEQ7d0JBQzVELDJEQUEyRDt3QkFDM0QsMENBQTBDO3dCQUMxQyxnRUFBZ0U7d0JBQ2hFLGlFQUFpRTt3QkFDakUsZ0VBQWdFO3dCQUNoRSw2QkFBNkI7d0JBQzdCLElBQU0sS0FBSyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLG9CQUFvQixDQUFDLENBQUM7d0JBQzNELElBQUksS0FBSyxFQUFFOzRCQUNULHFFQUFxRTs0QkFDckUsbUJBQW1COzRCQUNuQixJQUFJLENBQUMsV0FBVyxHQUFHLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQzt5QkFDN0I7NkJBQU0sSUFBSSxDQUFDLENBQUMsVUFBVSxDQUNuQixJQUFJLENBQUMsV0FBVyxFQUFFLEVBQUUsQ0FBQyxLQUFLLENBQUMsNEJBQTRCLENBQUMsRUFBRTs0QkFDNUQsb0VBQW9FOzRCQUNwRSxzRUFBc0U7NEJBQ3RFLDRDQUE0Qzs0QkFDNUMsSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FDekMsRUFBRSxDQUFDLEtBQUssQ0FBQyw0QkFBNEIsQ0FBQyxNQUFNLENBQUMsQ0FBQzt5QkFDbkQ7cUJBQ0Y7Z0JBQ0gsQ0FBQztnQkFFRCxpQ0FBUSxHQUFSO29CQUNFLE9BQU8sQ0FBQyxJQUFJLENBQUMsV0FBVyxJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksSUFBSSxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQztnQkFDNUUsQ0FBQztnQkFDSCxxQkFBQztZQUFELENBQUMsQUFoTkQsSUFnTkM7WUFoTlkscUJBQWMsaUJBZ04xQixDQUFBO1lBRUQ7OztlQUdHO1lBQ0g7Z0JBd0RFLDRCQUFZLFFBQWtCO29CQUM1QixJQUFJLENBQUMsUUFBUSxHQUFHLFFBQVEsQ0FBQztvQkFDekIsSUFBSSxDQUFDLGlCQUFpQixHQUFHLElBQUksQ0FBQztvQkFDOUIsSUFBSSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7b0JBQ3hCLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO29CQUNoQixJQUFJLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQztnQkFDMUIsQ0FBQztnQkFDSCx5QkFBQztZQUFELENBQUMsQUEvREQsSUErREM7WUEvRFkseUJBQWtCLHFCQStEOUIsQ0FBQTtZQUVELHlCQUF5QixJQUFvQixFQUFFLFdBQWlCLEVBQzVELHFCQUFxQyxFQUNyQyxJQUF3QixFQUFFLElBQW9CO2dCQUNoRCxJQUFJLFVBQVUsR0FBRyxJQUFJLFVBQVUsQ0FBQyxXQUFXLEVBQUUscUJBQXFCLEVBQUUsSUFBSSxFQUNwRSxJQUFJLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQ2hCLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBQ3RDLENBQUM7WUFFRCwwQkFBMEIsSUFBb0IsRUFBRSxTQUFlLEVBQzNELG1CQUFtQyxFQUFFLElBQXdCLEVBQzdELElBQW9CO2dCQUN0QixJQUFJLFVBQVUsR0FBRyxJQUFJLFVBQVUsQ0FBQyxTQUFTLEVBQUUsbUJBQW1CLEVBQUUsSUFBSSxFQUNoRSxJQUFJLEVBQUUsS0FBSyxDQUFDLENBQUM7Z0JBQ2pCLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBQ3ZDLENBQUM7WUFFRCx1QkFBdUIsS0FBMEMsRUFDN0QsS0FBYTtnQkFDZixDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLEVBQUUsRUFBRSxVQUFBLFFBQVE7b0JBQzVCLElBQUksS0FBSyxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7b0JBQ2pDLEtBQUssQ0FBQyxRQUFRLEdBQUcsS0FBSyxHQUFHLENBQUMsQ0FBQyxDQUFDLHdDQUF3QztvQkFDcEUsSUFBSSxLQUFLLEdBQUcsQ0FBQyxFQUFFO3dCQUNiLFFBQVEsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUU7NEJBQ3ZCLEtBQUssUUFBQSxRQUFRLENBQUMsSUFBSSxDQUFDOzRCQUNuQixLQUFLLFFBQUEsUUFBUSxDQUFDLE1BQU07Z0NBQ2xCLGlCQUFpQixDQUFzQixLQUFLLEVBQUUsS0FBSyxHQUFHLENBQUMsQ0FBQyxDQUFDO2dDQUN6RCxNQUFNOzRCQUNSLHNCQUFzQjt5QkFDdkI7cUJBQ0Y7Z0JBQ0gsQ0FBQyxDQUFDLENBQUM7WUFDTCxDQUFDO1lBQUEsQ0FBQztZQUVGO2dCQUF5Qyx1Q0FBYztnQkFzQnJELDZCQUFZLFNBQW9CLEVBQUUsWUFBbUM7b0JBQXJFLFlBQ0Usa0JBQU0sU0FBUyxDQUFDLFNBYWpCO29CQVpDLElBQUksU0FBUyxHQUFHLFNBQVMsQ0FBQyxTQUFTLENBQUM7b0JBQ3BDLElBQUksRUFBRSxHQUFHLFNBQVMsQ0FBQyxLQUFLLEVBQUUsQ0FBQztvQkFDM0IsWUFBWSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUM7b0JBQzdCLEtBQUksQ0FBQyxTQUFTO3dCQUNWLFFBQUEsV0FBVyxDQUNQLEVBQUUsQ0FBQyxJQUFJLEVBQUUsUUFBQSxTQUFTLENBQUMsSUFBSSxFQUFFLFlBQVksQ0FBQyxDQUFDO29CQUMvQyxLQUFJLENBQUMsWUFBWSxHQUFHLEVBQUMsS0FBSyxFQUFFLENBQUMsRUFBRSxNQUFNLEVBQUUsQ0FBQyxFQUFDLENBQUM7b0JBQzFDLEtBQUksQ0FBQyxhQUFhLEdBQUcsRUFBQyxLQUFLLEVBQUUsQ0FBQyxFQUFFLE1BQU0sRUFBRSxDQUFDLEVBQUMsQ0FBQztvQkFDM0MsS0FBSSxDQUFDLG1CQUFtQixHQUFHLEVBQUMsS0FBSyxFQUFFLENBQUMsRUFBRSxNQUFNLEVBQUUsQ0FBQyxFQUFDLENBQUM7b0JBQ2pELEtBQUksQ0FBQyxpQkFBaUIsR0FBRyxFQUFFLENBQUM7b0JBQzVCLEtBQUksQ0FBQyxrQkFBa0IsR0FBRyxFQUFFLENBQUM7b0JBQzdCLEtBQUksQ0FBQyx1QkFBdUIsR0FBRyxFQUFFLENBQUM7O2dCQUNwQyxDQUFDO2dCQUNILDBCQUFDO1lBQUQsQ0FBQyxBQXJDRCxDQUF5QyxjQUFjLEdBcUN0RDtZQXJDWSwwQkFBbUIsc0JBcUMvQixDQUFBO1lBRUQsMkJBQTJCLFVBQStCLEVBQ3RELEtBQWE7Z0JBQ2YsSUFBSSxVQUFVLENBQUMsU0FBUyxFQUFFO29CQUN4QixhQUFhLENBQUMsVUFBVSxDQUFDLFNBQVMsRUFBRSxLQUFLLENBQUMsQ0FBQztpQkFDNUM7WUFDSCxDQUFDO1lBRUQ7Ozs7OztlQU1HO1lBQ0gsd0JBQ0ksS0FBeUQsRUFDekQsQ0FBUyxFQUFFLENBQVM7Z0JBQ3RCLElBQUksR0FBRyxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ3hCLElBQUksSUFBSSxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ3pCLElBQUksSUFBSSxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO2dCQUU1QixzRUFBc0U7Z0JBQ3RFLG1FQUFtRTtnQkFDbkUsa0NBQWtDO2dCQUNsQyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxPQUFPLEtBQUssUUFBQSxhQUFhLENBQUMsT0FBTztvQkFDMUMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLEtBQUssUUFBQSxhQUFhLENBQUMsT0FBTyxDQUFDO29CQUM3QyxHQUFHLENBQUMsSUFBSSxDQUFDLE9BQU8sS0FBSyxRQUFBLGFBQWEsQ0FBQyxPQUFPO29CQUMxQyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sS0FBSyxRQUFBLGFBQWEsQ0FBQyxPQUFPLEVBQUU7b0JBQy9DLE9BQU87aUJBQ1I7Z0JBRUQsdUJBQXVCO2dCQUN2QixnQkFBZ0IsQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLElBQUksRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLGNBQWMsQ0FBQyxRQUFRLENBQUMsQ0FBQztnQkFDdEUsZUFBZSxDQUFDLElBQUksRUFBRSxHQUFHLENBQUMsSUFBSSxFQUFFLEdBQUcsRUFBRSxJQUFJLEVBQUUsY0FBYyxDQUFDLFFBQVEsQ0FBQyxDQUFDO2dCQUVwRSx1Q0FBdUM7Z0JBQ3ZDLEtBQUssQ0FBQyxVQUFVLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1lBQ3pCLENBQUM7WUFFRDs7Ozs7O2VBTUc7WUFDSCx3QkFBd0IsVUFBK0IsRUFBRSxDQUFTLEVBQzlELFdBQXFCO2dCQUN2QixJQUFJLEtBQUssR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDO2dCQUNqQyxJQUFJLEtBQUssR0FBRyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUMxQixLQUFLLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQztnQkFFMUIsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxFQUFFLFVBQUMsQ0FBQyxFQUFFLEtBQUs7b0JBQ3JDLGNBQWMsQ0FBQyxLQUFLLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO2dCQUM5QixDQUFDLENBQUMsQ0FBQztnQkFFSCxJQUFJLE1BQU0sQ0FBQywyQkFBMkIsSUFBSSxXQUFXLEVBQUU7b0JBQ3JELENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsRUFBRSxVQUFDLENBQUMsRUFBRSxLQUFLO3dCQUNuQyxjQUFjLENBQUMsS0FBSyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztvQkFDOUIsQ0FBQyxDQUFDLENBQUM7aUJBQ0o7Z0JBRUQscUVBQXFFO2dCQUNyRSxJQUFJLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtvQkFDbkMsS0FBSyxDQUFDLElBQUksQ0FBQyxPQUFPLEdBQUcsUUFBQSxhQUFhLENBQUMsT0FBTyxDQUFDO29CQUMzQyxVQUFVLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUMxQyxLQUFLLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDO2lCQUNyQjtZQUNILENBQUM7WUFFRDs7Ozs7O2VBTUc7WUFDSCx1QkFBOEIsVUFBK0IsRUFBRSxDQUFTLEVBQ3BFLFdBQXFCO2dCQUN2QixJQUFJLEtBQUssR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDO2dCQUNqQyxJQUFJLEtBQUssR0FBRyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUMxQixLQUFLLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQztnQkFFekIsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxFQUFFLFVBQUMsQ0FBQyxFQUFFLEtBQUs7b0JBQ25DLGNBQWMsQ0FBQyxLQUFLLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO2dCQUM5QixDQUFDLENBQUMsQ0FBQztnQkFFSCxJQUFJLE1BQU0sQ0FBQywyQkFBMkIsSUFBSSxXQUFXLEVBQUU7b0JBQ3JELENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsRUFBRSxVQUFDLENBQUMsRUFBRSxLQUFLO3dCQUNyQyxjQUFjLENBQUMsS0FBSyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztvQkFDOUIsQ0FBQyxDQUFDLENBQUM7aUJBQ0o7Z0JBRUQscUVBQXFFO2dCQUNyRSxJQUFJLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtvQkFDbkMsS0FBSyxDQUFDLElBQUksQ0FBQyxPQUFPLEdBQUcsUUFBQSxhQUFhLENBQUMsT0FBTyxDQUFDO29CQUMzQyxVQUFVLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN6QyxLQUFLLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDO2lCQUNyQjtZQUNILENBQUM7WUF0QmUsb0JBQWEsZ0JBc0I1QixDQUFBO1lBRUQ7Ozs7O2VBS0c7WUFDSCxtQkFBbUIsSUFBVSxFQUFFLEtBQWU7Z0JBQzVDLElBQUksSUFBSSxDQUFDLElBQUksS0FBSyxRQUFBLFFBQVEsQ0FBQyxFQUFFLEVBQUU7b0JBQzdCLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxLQUFLLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO3dCQUNyQyxJQUFhLElBQUssQ0FBQyxFQUFFLEtBQUssS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFOzRCQUFFLE9BQU8sSUFBSSxDQUFDO3lCQUFFO3FCQUNyRDtpQkFDRjtxQkFBTSxJQUFJLElBQUksQ0FBQyxJQUFJLEtBQUssUUFBQSxRQUFRLENBQUMsSUFBSSxFQUFFO29CQUN0QyxJQUFJLFVBQVUsR0FBYyxJQUFLLENBQUMsU0FBUyxFQUFFLENBQUM7b0JBQzlDLElBQUksVUFBVSxFQUFFO3dCQUNkLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxLQUFLLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFOzRCQUNyQyxJQUFJLFVBQVUsQ0FBQyxFQUFFLEtBQUssS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFO2dDQUFFLE9BQU8sSUFBSSxDQUFDOzZCQUFFO3lCQUNqRDtxQkFDRjtpQkFDRjtnQkFDRCxPQUFPLEtBQUssQ0FBQztZQUNmLENBQUM7WUFFRCwwRUFBMEU7WUFDMUUsK0JBQStCLFVBQStCO2dCQUM1RCxJQUFJLEtBQUssR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDO2dCQUNqQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLEVBQUUsRUFBRSxVQUFBLENBQUM7b0JBQ3JCLElBQUksVUFBVSxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQy9CLElBQUksVUFBVSxDQUFDLElBQUksQ0FBQyxPQUFPLEtBQUssUUFBQSxhQUFhLENBQUMsT0FBTzt3QkFDakQsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsNEJBQTRCLENBQUMsRUFBRTt3QkFDeEQsb0VBQW9FO3dCQUNwRSwwRUFBMEU7d0JBQzFFLDBFQUEwRTt3QkFDMUUsSUFBSSxVQUFVLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNOzRCQUN2QyxVQUFVLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLEVBQUU7NEJBQzFDLGNBQWMsQ0FBQyxVQUFVLEVBQUUsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDO3lCQUNyQzs2QkFBTTs0QkFDTCxhQUFhLENBQUMsVUFBVSxFQUFFLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQzt5QkFDcEM7cUJBQ0Y7Z0JBQ0gsQ0FBQyxDQUFDLENBQUM7WUFDTCxDQUFDO1lBRUQseURBQXlEO1lBQ3pELCtCQUErQixVQUErQjtnQkFDNUQsSUFBSSxLQUFLLEdBQUcsVUFBVSxDQUFDLFNBQVMsQ0FBQztnQkFDakMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxFQUFFLEVBQUUsVUFBQSxDQUFDO29CQUNyQixJQUFJLFVBQVUsR0FBRyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUMvQixJQUFJLFVBQVUsQ0FBQyxJQUFJLENBQUMsT0FBTyxLQUFLLFFBQUEsYUFBYSxDQUFDLFdBQVcsRUFBRTt3QkFDekQsT0FBTztxQkFDUjtvQkFDRCxJQUFJLFNBQVMsQ0FBQyxVQUFVLENBQUMsSUFBSSxFQUFFLE1BQU0sQ0FBQyxlQUFlLENBQUMsRUFBRTt3QkFDdEQsY0FBYyxDQUFDLFVBQVUsRUFBRSxDQUFDLENBQUMsQ0FBQztxQkFDL0I7Z0JBQ0gsQ0FBQyxDQUFDLENBQUM7WUFDTCxDQUFDO1lBRUQsd0RBQXdEO1lBQ3hELGlDQUFpQyxVQUFVO2dCQUN6QyxJQUFJLEtBQUssR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDO2dCQUNqQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLEVBQUUsRUFBRSxVQUFBLENBQUM7b0JBQ3JCLElBQUksVUFBVSxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQy9CLElBQUksVUFBVSxDQUFDLElBQUksQ0FBQyxPQUFPLEtBQUssUUFBQSxhQUFhLENBQUMsV0FBVyxFQUFFO3dCQUN6RCxPQUFPO3FCQUNSO29CQUNELElBQUksU0FBUyxDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUUsTUFBTSxDQUFDLGNBQWMsQ0FBQyxFQUFFO3dCQUNyRCxhQUFhLENBQUMsVUFBVSxFQUFFLENBQUMsQ0FBQyxDQUFDO3FCQUM5QjtnQkFDSCxDQUFDLENBQUMsQ0FBQztZQUNMLENBQUM7WUFFRCw2RUFBNkU7WUFDN0Usa0NBQWtDLFVBQStCO2dCQUMvRCxJQUFJLEtBQUssR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDO2dCQUVqQyw2RUFBNkU7Z0JBQzdFLHVCQUF1QjtnQkFDdkIsSUFBSSxjQUFjLEdBQUcsRUFBRSxDQUFDO2dCQUN4QixJQUFJLGVBQWUsR0FBRyxFQUFFLENBQUM7Z0JBQ3pCLElBQUksY0FBYyxHQUFHLENBQUMsQ0FBQztnQkFDdkIsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxFQUFFLEVBQUUsVUFBQSxXQUFXO29CQUMvQixJQUFJLEtBQUssQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sS0FBSyxRQUFBLGFBQWEsQ0FBQyxXQUFXLEVBQUU7d0JBQ3RFLGdEQUFnRDt3QkFDaEQsT0FBTztxQkFDUjtvQkFFRCx5RUFBeUU7b0JBQ3pFLHVFQUF1RTtvQkFDdkUseUVBQXlFO29CQUN6RSxpRUFBaUU7b0JBQ2pFLElBQUksUUFBUSxHQUNSLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxXQUFXLENBQUMsRUFBRSxVQUFDLFFBQVEsRUFBRSxJQUFJO3dCQUN2RCxJQUFJLFFBQVEsR0FBRyxLQUFLLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxXQUFXLENBQUMsQ0FBQyxRQUFRLENBQUM7d0JBQ3RELE9BQU8sUUFBUSxHQUFHLENBQUMsUUFBUSxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDdkQsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO29CQUNWLElBQUksUUFBUSxLQUFLLENBQUMsSUFBSSxLQUFLLENBQUMsWUFBWSxDQUFDLFdBQVcsQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7d0JBQ2hFLFFBQVEsR0FBRyxLQUFLLENBQUMsWUFBWSxDQUFDLFdBQVcsQ0FBQyxDQUFDLE1BQU0sQ0FBQztxQkFDbkQ7b0JBRUQsSUFBSSxTQUFTLEdBQ1QsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLFdBQVcsQ0FBQyxFQUFFLFVBQUMsU0FBUyxFQUFFLElBQUk7d0JBQ3RELElBQUksUUFBUSxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxDQUFDLFFBQVEsQ0FBQzt3QkFDdEQsT0FBTyxTQUFTLEdBQUcsQ0FBQyxRQUFRLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUN4RCxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7b0JBQ1YsSUFBSSxTQUFTLEtBQUssQ0FBQyxJQUFJLEtBQUssQ0FBQyxVQUFVLENBQUMsV0FBVyxDQUFDLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTt3QkFDL0QsU0FBUyxHQUFHLEtBQUssQ0FBQyxVQUFVLENBQUMsV0FBVyxDQUFDLENBQUMsTUFBTSxDQUFDO3FCQUNsRDtvQkFFRCxrRUFBa0U7b0JBQ2xFLGNBQWMsQ0FBQyxXQUFXLENBQUMsR0FBRyxRQUFRLENBQUM7b0JBQ3ZDLGVBQWUsQ0FBQyxXQUFXLENBQUMsR0FBRyxTQUFTLENBQUM7b0JBQ3pDLGNBQWMsRUFBRSxDQUFDO2dCQUNuQixDQUFDLENBQUMsQ0FBQztnQkFFSCxJQUFJLGNBQWMsR0FBRyxNQUFNLENBQUMseUJBQXlCLEVBQUU7b0JBQ3JELHNEQUFzRDtvQkFDdEQsT0FBTztpQkFDUjtnQkFFRCw0RUFBNEU7Z0JBQzVFLElBQUksYUFBYSxHQUFHLE1BQU0sQ0FBQyxzQkFBc0IsR0FBRyxDQUFDLENBQUM7Z0JBRXRELDZEQUE2RDtnQkFDN0QsSUFBSSxPQUFPLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLENBQUM7Z0JBQ2hELElBQUksT0FBTyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQyxDQUFDO2dCQUNoRCxJQUFJLGdCQUFnQixHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQUMsS0FBSyxFQUFFLEtBQUs7b0JBQ25FLE9BQU8sY0FBYyxDQUFDLEtBQUssQ0FBQyxHQUFHLGNBQWMsQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFDdkQsQ0FBQyxDQUFDLENBQUM7Z0JBQ0gsSUFBSSxVQUFVLEdBQUcsY0FBYyxDQUFDLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7Z0JBQzNELElBQUksVUFBVSxHQUFHLGNBQWMsQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO2dCQUMzRCxJQUFJLGtCQUFrQixHQUFHLFVBQVUsR0FBRyxVQUFVLEdBQUcsVUFBVSxDQUFDO2dCQUM5RCxrREFBa0Q7Z0JBQ2xELGtCQUFrQixHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsa0JBQWtCLEVBQUUsYUFBYSxDQUFDLENBQUM7Z0JBQ2pFLEtBQUssSUFBSSxDQUFDLEdBQUcsY0FBYyxHQUFHLENBQUMsRUFDMUIsY0FBYyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsa0JBQWtCLEVBQUUsQ0FBQyxFQUFFLEVBQUU7b0JBQ2xFLGlDQUFpQztvQkFDakMsYUFBYSxDQUFDLFVBQVUsRUFBRSxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2lCQUNoRDtnQkFFRCxrRUFBa0U7Z0JBQ2xFLElBQUksaUJBQWlCLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBQyxLQUFLLEVBQUUsS0FBSztvQkFDckUsT0FBTyxlQUFlLENBQUMsS0FBSyxDQUFDLEdBQUcsZUFBZSxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUN6RCxDQUFDLENBQUMsQ0FBQztnQkFDSCxJQUFJLFdBQVcsR0FBRyxlQUFlLENBQUMsaUJBQWlCLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztnQkFDOUQsSUFBSSxXQUFXLEdBQUcsZUFBZSxDQUFDLGlCQUFpQixDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7Z0JBQzlELDBFQUEwRTtnQkFDMUUsd0VBQXdFO2dCQUN4RSw2RUFBNkU7Z0JBQzdFLDhFQUE4RTtnQkFDOUUsSUFBSSxtQkFBbUIsR0FBRyxXQUFXLEdBQUcsQ0FBQyxXQUFXLEdBQUcsV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUN4RSxrREFBa0Q7Z0JBQ2xELG1CQUFtQixHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsbUJBQW1CLEVBQUUsYUFBYSxDQUFDLENBQUM7Z0JBQ25FLEtBQUssSUFBSSxDQUFDLEdBQUcsY0FBYyxHQUFHLENBQUMsRUFDMUIsZUFBZSxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsbUJBQW1CLEVBQUUsQ0FBQyxFQUFFLEVBQUU7b0JBQ3JFLElBQUksSUFBSSxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDNUMsSUFBSSxDQUFDLElBQUksSUFBSSxJQUFJLENBQUMsV0FBVyxFQUFFO3dCQUM3Qix1RUFBdUU7d0JBQ3ZFLGdFQUFnRTt3QkFDaEUsMEVBQTBFO3dCQUMxRSxTQUFTO3FCQUNWO29CQUVELHNFQUFzRTtvQkFDdEUsY0FBYyxDQUFDLFVBQVUsRUFBRSxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2lCQUNsRDtZQUNILENBQUM7WUFFRCx1RUFBdUU7WUFDdkUsNEJBQTRCLFVBQStCO2dCQUN6RCxJQUFJLEtBQUssR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDO2dCQUVqQyxpREFBaUQ7Z0JBQ2pELElBQUksR0FBRyxHQUFnRCxFQUFFLENBQUM7Z0JBQzFELENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssRUFBRSxFQUFFLFVBQUEsQ0FBQztvQkFDckIsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLGVBQWUsRUFBRTt3QkFDM0MsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUNwQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7cUJBQ3JDO2dCQUNILENBQUMsQ0FBQyxDQUFDO2dCQUVILHlFQUF5RTtnQkFDekUsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsVUFBQyxLQUFLLEVBQUUsUUFBUTtvQkFDMUIsSUFBSSxLQUFLLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQyxnQkFBZ0IsRUFBRTt3QkFDMUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsVUFBQSxDQUFDLElBQUksT0FBQSxjQUFjLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUEvQixDQUErQixDQUFDLENBQUM7cUJBQ3JEO2dCQUNILENBQUMsQ0FBQyxDQUFDO1lBQ0wsQ0FBQztZQUVEOzs7O2VBSUc7WUFDSCx1QkFBOEIsRUFBVTtnQkFDdEMsSUFBSSxZQUFZLEdBQUcsYUFBYSxDQUFDO2dCQUNqQywyQ0FBMkM7Z0JBQzNDLElBQUksT0FBTyxHQUFHLENBQUMsQ0FBQztnQkFDaEIsSUFBSSxPQUFPLEdBQUcsR0FBRyxDQUFDO2dCQUNsQixJQUFJLFdBQVcsR0FBRyxPQUFPLEdBQUcsT0FBTyxDQUFDO2dCQUNwQyxPQUFPLE9BQU8sR0FBRyxDQUFDLENBQUMsV0FBVyxHQUFHLFlBQVksR0FBRyxFQUFFLENBQUMsR0FBRyxXQUFXLENBQUMsQ0FBQztZQUNyRSxDQUFDO1lBUGUsb0JBQWEsZ0JBTzVCLENBQUE7WUFBQSxDQUFDO1lBRUY7Ozs7Ozs7Ozs7O2VBV0c7WUFDSCw0QkFBNEIsVUFBK0I7Z0JBRXpELHFCQUFxQixDQUFDLFVBQVUsQ0FBQyxDQUFDO2dCQUVsQyxJQUFJLE1BQU0sQ0FBQyxlQUFlLEVBQUU7b0JBQzFCLHFCQUFxQixDQUFDLFVBQVUsQ0FBQyxDQUFDO2lCQUNuQztnQkFFRCwwRUFBMEU7Z0JBQzFFLDZCQUE2QjtnQkFDN0IsSUFBSSxNQUFNLENBQUMsY0FBYyxFQUFFO29CQUN6Qix1QkFBdUIsQ0FBQyxVQUFVLENBQUMsQ0FBQztpQkFDckM7Z0JBRUQsd0JBQXdCLENBQUMsVUFBVSxDQUFDLENBQUM7Z0JBRXJDLElBQUksTUFBTSxDQUFDLGdCQUFnQixFQUFFO29CQUMzQixrQkFBa0IsQ0FBQyxVQUFVLENBQUMsQ0FBQztpQkFDaEM7Z0JBRUQsdUNBQXVDO2dCQUN2QywyRUFBMkU7Z0JBQzNFLDZDQUE2QztnQkFDN0MsMEVBQTBFO2dCQUMxRSx5RUFBeUU7Z0JBQ3pFLDRFQUE0RTtnQkFDNUUsNEVBQTRFO2dCQUM1RSwwQkFBMEI7Z0JBQzFCLHdFQUF3RTtnQkFDeEUsK0RBQStEO2dCQUUvRCxJQUFJLEtBQUssR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDO2dCQUNqQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLEVBQUUsRUFBRSxVQUFBLENBQUM7b0JBQ3JCLElBQUksS0FBSyxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQzFCLElBQUksTUFBTSxHQUFHLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO29CQUN2QyxJQUFJLEtBQUssQ0FBQyxJQUFJLENBQUMsT0FBTyxLQUFLLFFBQUEsYUFBYSxDQUFDLFdBQVcsRUFBRTt3QkFDcEQsT0FBTztxQkFDUjtvQkFDRCxJQUFJLE1BQU0sS0FBSyxDQUFDLEVBQUU7d0JBQ2hCLElBQUksaUJBQWlCLEdBQUcsS0FBSyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQzt3QkFDN0QsSUFBSSxnQkFBZ0IsR0FBRyxLQUFLLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO3dCQUUzRCxJQUFJLEtBQUssQ0FBQyxXQUFXLEVBQUUsRUFBRSxrQkFBa0I7NEJBQ3pDLGtFQUFrRTs0QkFDbEUsOERBQThEOzRCQUM5RCxVQUFVLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDOzRCQUN6QyxLQUFLLENBQUMsSUFBSSxDQUFDLE9BQU8sR0FBRyxRQUFBLGFBQWEsQ0FBQyxPQUFPLENBQUM7NEJBQzNDLEtBQUssQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUM7eUJBQ3JCOzZCQUFNLElBQUksS0FBSyxDQUFDLFlBQVksRUFBRSxFQUFFLGdCQUFnQjs0QkFDL0Msa0VBQWtFOzRCQUNsRSwrREFBK0Q7NEJBQy9ELFVBQVUsQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7NEJBQzFDLEtBQUssQ0FBQyxJQUFJLENBQUMsT0FBTyxHQUFHLFFBQUEsYUFBYSxDQUFDLE9BQU8sQ0FBQzs0QkFDM0MsS0FBSyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQzt5QkFDckI7NkJBQU0sSUFBSSxNQUFNLENBQUMsNENBQTRDLEVBQUU7NEJBQzlELElBQUksaUJBQWlCLElBQUksQ0FBQyxnQkFBZ0IsRUFBRTtnQ0FDMUMsS0FBSyxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsQ0FBQyxxQ0FBcUM7Z0NBQy9ELFVBQVUsQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7Z0NBQ3pDLEtBQUssQ0FBQyxJQUFJLENBQUMsT0FBTyxHQUFHLFFBQUEsYUFBYSxDQUFDLE9BQU8sQ0FBQztnQ0FDM0MsS0FBSyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQzs2QkFDckI7aUNBQU0sSUFBSSxnQkFBZ0IsSUFBSSxDQUFDLGlCQUFpQixFQUFFO2dDQUNqRCxLQUFLLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxDQUFDLG9DQUFvQztnQ0FDL0QsVUFBVSxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztnQ0FDMUMsS0FBSyxDQUFDLElBQUksQ0FBQyxPQUFPLEdBQUcsUUFBQSxhQUFhLENBQUMsT0FBTyxDQUFDO2dDQUMzQyxLQUFLLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDOzZCQUNyQjtpQ0FBTTtnQ0FDTCxtRUFBbUU7Z0NBQ25FLG9EQUFvRDs2QkFDckQ7eUJBQ0Y7cUJBQ0Y7Z0JBQ0gsQ0FBQyxDQUFDLENBQUM7WUFDTCxDQUFDO1lBRUQ7Ozs7Ozs7Ozs7ZUFVRztZQUNILGdDQUNJLEtBQUssRUFBRSxlQUFlLEVBQUUsVUFBa0I7Z0JBQzVDLElBQU0sZUFBZSxHQUFHLFVBQVUsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBRTlDLGtFQUFrRTtnQkFDbEUsSUFBTSxpQkFBaUIsR0FDbkIsZUFBZSxDQUFDLGVBQWUsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxDQUFDO2dCQUNsRSxJQUFJLGlCQUFpQixDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7b0JBQ2xDLGVBQWUsQ0FBQyxlQUFlLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxHQUFHLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxDQUFDO2lCQUNwRTtnQkFFRCxJQUFJLFFBQVEsR0FBRyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ2xDLElBQUksVUFBVSxHQUFHLGVBQWUsQ0FBQyxtQkFBbUIsQ0FBQyxRQUFRLENBQUMsQ0FBQztnQkFDL0QsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLGVBQWUsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7b0JBQy9DLCtCQUErQjtvQkFDL0IsSUFBSSxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksS0FBSyxFQUFFLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxFQUFFLEVBQUU7d0JBQ2pELE1BQU07cUJBQ1A7b0JBQ0QsZUFBZSxDQUFDLGlCQUFpQixDQUFDLFFBQVEsQ0FBQyxDQUFDO29CQUM1QyxVQUFVLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQztvQkFDM0IsS0FBSyxDQUFDLGVBQWUsQ0FBQyxVQUFVLENBQUMsQ0FBQztvQkFDbEMsUUFBUSxJQUFJLEdBQUcsR0FBRyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQ3JDLFVBQVUsR0FBRyxlQUFlLENBQUMsbUJBQW1CLENBQUMsUUFBUSxDQUFDLENBQUM7aUJBQzVEO2dCQUVELE9BQU8sVUFBVSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7WUFDOUIsQ0FBQztZQTFCZSw2QkFBc0IseUJBMEJyQyxDQUFBO1FBRUQsQ0FBQyxFQXB0RWUsTUFBTSxHQUFOLGNBQU0sS0FBTixjQUFNLFFBb3RFckI7SUFBRCxDQUFDLEVBcHRFUyxLQUFLLEdBQUwsUUFBSyxLQUFMLFFBQUssUUFvdEVkO0FBQUQsQ0FBQyxFQXB0RU0sRUFBRSxLQUFGLEVBQUUsUUFvdEVSLENBQUMsK0JBQStCIiwic291cmNlc0NvbnRlbnQiOlsiLyogQ29weXJpZ2h0IDIwMTUgVGhlIFRlbnNvckZsb3cgQXV0aG9ycy4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cblxuTGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlLCBWZXJzaW9uIDIuMCAodGhlICdMaWNlbnNlJyk7XG55b3UgbWF5IG5vdCB1c2UgdGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlIHdpdGggdGhlIExpY2Vuc2UuXG5Zb3UgbWF5IG9idGFpbiBhIGNvcHkgb2YgdGhlIExpY2Vuc2UgYXRcblxuICAgIGh0dHA6Ly93d3cuYXBhY2hlLm9yZy9saWNlbnNlcy9MSUNFTlNFLTIuMFxuXG5Vbmxlc3MgcmVxdWlyZWQgYnkgYXBwbGljYWJsZSBsYXcgb3IgYWdyZWVkIHRvIGluIHdyaXRpbmcsIHNvZnR3YXJlXG5kaXN0cmlidXRlZCB1bmRlciB0aGUgTGljZW5zZSBpcyBkaXN0cmlidXRlZCBvbiBhbiAnQVMgSVMnIEJBU0lTLFxuV0lUSE9VVCBXQVJSQU5USUVTIE9SIENPTkRJVElPTlMgT0YgQU5ZIEtJTkQsIGVpdGhlciBleHByZXNzIG9yIGltcGxpZWQuXG5TZWUgdGhlIExpY2Vuc2UgZm9yIHRoZSBzcGVjaWZpYyBsYW5ndWFnZSBnb3Zlcm5pbmcgcGVybWlzc2lvbnMgYW5kXG5saW1pdGF0aW9ucyB1bmRlciB0aGUgTGljZW5zZS5cbj09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSovXG4vKipcbiAqIFBhY2thZ2UgZm9yIHRoZSBSZW5kZXIgSGllcmFyY2h5IGZvciBUZW5zb3JGbG93IGdyYXBoLlxuICovXG5tb2R1bGUgdGYuZ3JhcGgucmVuZGVyIHtcblxuZXhwb3J0IHR5cGUgUG9pbnQgPSB7eDogbnVtYmVyLCB5OiBudW1iZXJ9O1xuXG4vKipcbiAqIENvbG9yIHBhcmFtZXRlcnMgZm9yIG9wIG5vZGVzLlxuICovXG5leHBvcnQgbGV0IE9wTm9kZUNvbG9ycyA9IHtERUZBVUxUX0ZJTEw6ICcjZmZmZmZmJywgREVGQVVMVF9TVFJPS0U6ICcjYjJiMmIyJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIENPTVBBVElCTEU6ICcjMGY5ZDU4JywgSU5DT01QQVRJQkxFOiAnI2RiNDQzNyd9O1xuXG4vKipcbiAqIENvbG9yIHBhcmFtZXRlcnMgZm9yIG5vZGUgZW5jb2RpbmcuXG4gKiBAdHlwZSB7T2JqZWN0fVxuICovXG5leHBvcnQgbGV0IE1ldGFub2RlQ29sb3JzID0ge1xuICAvKipcbiAgICogRGVmYXVsdCBmaWxsIGFuZCBzdHJva2UgdG8gdXNlIHdoZW4gbm8gb3RoZXIgaW5mb3JtYXRpb24gaXMgYXZhaWxhYmxlLlxuICAgKi9cbiAgREVGQVVMVF9GSUxMOiAnI2Q5ZDlkOScsXG4gIERFRkFVTFRfU1RST0tFOiAnI2E2YTZhNicsXG4gIFNBVFVSQVRJT046IDAuNixcbiAgTElHSFRORVNTOiAwLjg1LFxuICAvKipcbiAgICogTmV1dHJhbCBjb2xvciB0byB1c2Ugd2hlbiB0aGUgbm9kZSBpcyBleHBhbmRlZCAodXNlZCB3aGVuIGNvbG9yaW5nIGJ5XG4gICAqIGNvbXB1dGUgdGltZSwgbWVtb3J5IGFuZCBkZXZpY2UpLlxuICAgKi9cbiAgRVhQQU5ERURfQ09MT1I6ICcjZjBmMGYwJyxcbiAgLyoqXG4gICAqIFN0YW5kYXJkIGh1ZSB2YWx1ZXMgZm9yIG5vZGUgY29sb3IgcGFsZXR0ZS5cbiAgICovXG4gIEhVRVM6IFsyMjAsIDEwMCwgMTgwLCA0MCwgMjAsIDM0MCwgMjYwLCAzMDAsIDE0MCwgNjBdLFxuICBTVFJVQ1RVUkVfUEFMRVRURShpZDogbnVtYmVyLCBsaWdodGVuZWQ/OiBib29sZWFuKSB7XG4gICAgLy8gVGhlIGNvZGUgYmVsb3cgaXMgYSBmbGV4aWJsZSB3YXkgdG8gY29tcHV0YXRpb25hbGx5IGNyZWF0ZSBhIHNldFxuICAgIC8vIG9mIGNvbG9ycyB0aGF0IGdvIHdlbGwgdG9nZXRoZXIuXG4gICAgbGV0IGh1ZXMgPSBNZXRhbm9kZUNvbG9ycy5IVUVTO1xuICAgIGxldCBuID0gaHVlcy5sZW5ndGg7XG4gICAgbGV0IGh1ZSA9IGh1ZXNbaWQgJSBuXTtcbiAgICBsZXQgbSA9IE1hdGguc2luKGh1ZSAqIE1hdGguUEkgLyAzNjApO1xuICAgIGxldCBzYXQgPSBsaWdodGVuZWQgPyAzMCA6IDkwIC0gNjAgKiBtO1xuICAgIGxldCBsaWdodCA9IGxpZ2h0ZW5lZCA/IDk1IDogODA7XG4gICAgcmV0dXJuIGQzLmhzbChodWUsIC4wMSAqIHNhdCwgLjAxICogbGlnaHQpLnRvU3RyaW5nKCk7XG4gIH0sXG4gIERFVklDRV9QQUxFVFRFKGluZGV4OiBudW1iZXIpOiBzdHJpbmcge1xuICAgIHJldHVybiBNZXRhbm9kZUNvbG9ycy5TVFJVQ1RVUkVfUEFMRVRURShpbmRleCk7XG4gIH0sXG4gIFhMQV9DTFVTVEVSX1BBTEVUVEUoaW5kZXg6IG51bWJlcik6IHN0cmluZyB7XG4gICAgcmV0dXJuIE1ldGFub2RlQ29sb3JzLlNUUlVDVFVSRV9QQUxFVFRFKGluZGV4KTtcbiAgfSxcbiAgVU5LTk9XTjogJyNlZWUnLFxuICBHUkFESUVOVF9PVVRMSU5FOiAnIzg4OCdcbn07XG5cbi8qKlxuICogQ29sb3IgcGFyYW1ldGVycyBmb3Igb3Agbm9kZXMuXG4gKi9cbmV4cG9ydCBsZXQgU2VyaWVzTm9kZUNvbG9ycyA9IHtcbiAgREVGQVVMVF9GSUxMOiAnd2hpdGUnLFxuICBERUZBVUxUX1NUUk9LRTogJyNiMmIyYjInXG59O1xuXG5cbi8qKlxuICogRnVuY3Rpb24gdGhhdCBjb21wdXRlcyBlZGdlIHRoaWNrbmVzcyBpbiBwaXhlbHMuXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgRWRnZVRoaWNrbmVzc0Z1bmN0aW9uIHtcbiAgKGVkZ2VEYXRhOiBzY2VuZS5lZGdlLkVkZ2VEYXRhLCBlZGdlQ2xhc3M6IHN0cmluZyk6IG51bWJlcjtcbn1cblxuLyoqXG4gKiBGdW5jdGlvbiB0aGF0IGNvbXB1dGVzIGVkZ2UgbGFiZWwgc3RyaW5ncy4gVGhpcyBmdW5jdGlvbiBhY2NlcHRzIGEgTWV0YWVkZ2UsXG4gKiB3aGljaCBjb3VsZCBhY3R1YWxseSBlbmNhcHN1bGF0ZSBzZXZlcmFsIGJhc2UgZWRnZXMuIEZvciBpbnN0YW5jZSwgc2V2ZXJhbFxuICogYmFzZSBlZGdlcyBtYXkgbWVyZ2UgaW50byBhIHNpbmdsZSBtZXRhZWRnZS5cbiAqXG4gKiBUbyBkZXRlcm1pbmUgd2hldGhlciBhIG1ldGFlZGdlIHJlcHJlc2VudHMgc2V2ZXJhbCBlZGdlcywgY2hlY2sgdGhlIGxlbmd0aCBvZlxuICogaXRzIGJhc2VFZGdlTGlzdCBwcm9wZXJ0eS5cbiAqL1xuZXhwb3J0IGludGVyZmFjZSBFZGdlTGFiZWxGdW5jdGlvbiB7XG4gIChtZXRhZWRnZTogTWV0YWVkZ2UsIHJlbmRlckluZm86IHJlbmRlci5SZW5kZXJHcmFwaEluZm8pOiBzdHJpbmc7XG59XG5cbi8qKlxuICogUGFyYW1ldGVycyB0aGF0IGFmZmVjdCBob3cgdGhlIGdyYXBoIGlzIHJlbmRlcmVkIG9uIHRoZSBzY3JlZW4uXG4gKi9cbmNvbnN0IFBBUkFNUyA9IHtcbiAgLyoqXG4gICAqIFdoZXRoZXIgdG8gZXh0cmFjdCBoaWdoIGRlZ3JlZSBub2RlcyBmcm9tIHRoZSBjb3JlIHBhcnQgb2YgdGhlIGdyYXBoLlxuICAgKi9cbiAgZW5hYmxlRXh0cmFjdGlvbjogdHJ1ZSxcbiAgLyoqXG4gICAqIFRoZSBtaW5pbXVtIG51bWJlciBvZiBub2RlcyBmb3IgYSBncmFwaCB0byBoYXZlIGluIG9yZGVyIGZvciBoaWdoIGluIGFuZFxuICAgKiBvdXQgZGVncmVlIG5vZGVzIHRvIGJlIGV4dHJhY3RlZCBpbiBhdXhpbGlhcnkuIFRoZSBhaW0gaGVyZSBpcyB0byBwcmV2ZW50XG4gICAqIG5vZGVzIGZyb20gYmVpbmcgZXh0cmFjdGVkIGZyb20gc21hbGwgZ3JhcGhzLlxuICAgKi9cbiAgbWluTm9kZUNvdW50Rm9yRXh0cmFjdGlvbjogMTUsXG4gIC8qKlxuICAgKiBUaGUgbWluaW11bSBpbiBvciBvdXQgZGVncmVlIGEgbm9kZSBtdXN0IGhhdmUgaW4gb3JkZXIgdG8gYmUgcG9zc2libHlcbiAgICogZXh0cmFjdGVkLlxuICAgKi9cbiAgbWluRGVncmVlRm9yRXh0cmFjdGlvbjogNSxcbiAgLyoqXG4gICAqIE1heGltdW0gbnVtYmVyIG9mIGNvbnRyb2wgZWRnZXMgYSBub2RlIGNhbiBoYXZlIGJlZm9yZSB0aGV5IGFyZW4ndFxuICAgKiBkaXNwbGF5ZWQuXG4gICAqL1xuICBtYXhDb250cm9sRGVncmVlOiA0LFxuICAvKipcbiAgICogTWF4aW11bSBpbiAoZm9yIG91dGJvdW5kIGJyaWRnZSBwYXRocykgb3Igb3V0IChmb3IgaW5ib3VuZCBicmlkZ2UgcGF0aHMpXG4gICAqIGRlZ3JlZSBvZiBhIG5vZGUgYWxsb3dlZCBmb3IgYSBicmlkZ2UgcGF0aCB0byBiZSByZW5kZXJlZCB0byBpdCBmcm9tIGFcbiAgICogc3ViaGllcmFyY2h5IG9mIG5vZGVzLiBIYXZpbmcgYSBtYXggcHJldmVudHMgaGF2aW5nIHRvbyBtYW55IG5vZGVzIGVtYW5hdGVcbiAgICogZnJvbSBhIHN1YmhpZXJhcmNoeSBhbmQgY3Jvd2RpbmcgdXAuXG4gICAqL1xuICBtYXhCcmlkZ2VQYXRoRGVncmVlOiA0LFxuICAvKipcbiAgICogVHlwZXMgcGF0dGVybnMgZm9yIHByZWRlZmluZWQgb3V0LWV4dHJhY3Qgbm9kZXMsIHdoaWNoIGFyZVxuICAgKiBzaW5rLWxpa2Ugbm9kZXMgdGhhdCB3aWxsIGJlIGV4dHJhY3RlZCBmcm9tIHRoZSBtYWluIGdyYXBoLlxuICAgKi9cbiAgb3V0RXh0cmFjdFR5cGVzOiBbXG4gICAgJ05vT3AnICAvLyBOb09wcyBhcmUgc2luay1saWtlIHVzZWQgZm9yIG1hbmFnaW5nIGNvbnRyb2wgZGVwZW5kZW5jaWVzLlxuICBdLFxuXG4gIC8qKlxuICAgKiBUeXBlcyBwYXR0ZXJucyBmb3IgcHJlZGVmaW5lZCBpbi1leHRyYWN0IG5vZGVzLCB3aGljaCBhcmVcbiAgICogc291cmNlLWxpa2Ugbm9kZXMgdGhhdCB3aWxsIGJlIGV4dHJhY3RlZCBmcm9tIHRoZSBtYWluIGdyYXBoLlxuICAgKi9cbiAgaW5FeHRyYWN0VHlwZXM6IFtdLFxuXG4gIC8qKlxuICAgKiBXaGVuIHJlbW92aW5nIGVkZ2VzIGZyb20gYSBoaWdoIGRlZ3JlZSBub2RlLCByZW1vdmUgYWxsIG9mIGl0cyBlZGdlcyBpZlxuICAgKiBkZXRhY2hBbGxFZGdlc0ZvckhpZ2hEZWdyZWUgaXMgdHJ1ZS4gIE90aGVyd2lzZSByZW1vdmUgYWxsIGluLWVkZ2VzIGlmXG4gICAqIHRoZSBub2RlIGhhcyBoaWdoIGluLWRlZ3JlZSwgb3IgYWxsIG91dC1lZGdlcyBpZiB0aGUgbm9kZSBoYXMgaGlnaFxuICAgKiBvdXQtZGVncmVlLlxuICAgKi9cbiAgZGV0YWNoQWxsRWRnZXNGb3JIaWdoRGVncmVlOiB0cnVlLFxuXG4gIC8qKlxuICAgKiBBZnRlciBleHRyYWN0aW5nIGhpZ2ggaW4vb3V0IGRlZ3JlZSBub2RlcyBhbmQgcHJlZGVmaW5lZFxuICAgKiBzb3VyY2UtbGlrZS9zaW5rLWxpa2UsIGV4dHJhY3QgaXNvbGF0ZWQgbm9kZXMgdG8gdGhlIHNpZGVcbiAgICogaWYgdGhpcyBleHRyYWN0SXNvbGF0ZWROb2Rlc1dpdGhBbm5vdGF0aW9uc09uT25lU2lkZSBpcyB0cnVlLlxuICAgKi9cbiAgZXh0cmFjdElzb2xhdGVkTm9kZXNXaXRoQW5ub3RhdGlvbnNPbk9uZVNpZGU6IHRydWUsXG5cbiAgLyoqXG4gICAqIFdoZXRoZXIgdG8gYWRkIGJyaWRnZSBub2RlcyBhbmQgZWRnZXMgdG8gdGhlIGNvcmUgd2hlbiBidWlsZGluZyB0aGVcbiAgICogc3ViaGllcmFyY2h5IG9mIGFuIGV4cGFuZGVkIG1ldGFub2RlLiBTZWUgYnVpbGRTdWJoaWVyYXJjaHkoKS5cbiAgICovXG4gIGVuYWJsZUJyaWRnZWdyYXBoOiB0cnVlLFxuXG4gIC8qKlxuICAgKiAyIGNvbG9ycywgZm9yIHRoZSBtaW5pbXVtIGFuZCBtYXhpbXVtIHZhbHVlIHJlc3BlY3RpdmVseSwgd2hlbmV2ZXIgd2VcbiAgICogaGF2ZSBhIGdyYWRpZW50IHNjYWxlLlxuICAgKi9cbiAgbWluTWF4Q29sb3JzOiBbJyNmZmY1ZjAnLCAnI2ZiNmE0YSddLFxuXG4gIC8qKlxuICAgKiBNYXhpbXVtIG51bWJlciBvZiBhbm5vdGF0aW9ucyB0byBiZSBkaXNwbGF5ZWQgb24gYSBub2RlIGJlZm9yZSBhblxuICAgKiBlbGxpcHNpcyBpcyB1c2VkLlxuICAgKi9cbiAgbWF4QW5ub3RhdGlvbnM6IDVcbn07XG5cbi8qKlxuICogVGhlIHJlZ3VsYXIgZXhwcmVzc2lvbiB0byB1c2Ugd2hlbiBwYXJzaW5nIGZvciB0aGUgc3RyaW5nIHRoYXQgaXNcbiAqIHVzZWQgdG8gbGFiZWwgYSBmdW5jdGlvbiBub2RlIGluIHRoZSBncmFwaC4gV2Ugc3RyaXAgYXdheSBhIHByZWZpeFxuICogaW5kaWNhdGluZyB0aGF0IHRoZSBub2RlIHJlcHJlc2VudHMgYSBmdW5jdGlvbiBkZWZpbml0aW9uLiBXZSBhbHNvXG4gKiByZW1vdmUgYW4gYXJiaXRyYXJ5IGhleGFkZWNpbWFsIHN1ZmZpeCBhbmQgdGhlIG51bWJlciBmb2xsb3dpbmcgaXRcbiAqIGlmIGl0IGlzIHByZXNlbnQuIFRvIGJlIGNsZWFyLCB3ZSBleHRyYWN0IGZvbyBmcm9tXG4gKiBfX2Z1bmN0aW9uX2xpYnJhcnlfX2Zvb19kZWFkYjAwZl80Mi5cbiAqL1xuY29uc3Qgbm9kZURpc3BsYXlOYW1lUmVnZXggPSBuZXcgUmVnRXhwKFxuICAgICdeKD86JyArIHRmLmdyYXBoLkZVTkNUSU9OX0xJQlJBUllfTk9ERV9QUkVGSVggK1xuICAgICAgICAnKT8oXFxcXHcrKV9bYS16MC05XXs4fSg/Ol9cXFxcZCspPyQnKTtcblxuLyoqXG4gKiBTdG9yZXMgdGhlIHJlbmRlcmluZyBpbmZvcm1hdGlvbiwgc3VjaCBhcyB4IGFuZCB5IGNvb3JkaW5hdGVzLFxuICogZm9yIGVhY2ggbm9kZSBpbiB0aGUgZ3JhcGguXG4gKi9cbmV4cG9ydCBjbGFzcyBSZW5kZXJHcmFwaEluZm8ge1xuICBoaWVyYXJjaHk6IGhpZXJhcmNoeS5IaWVyYXJjaHk7XG4gIHByaXZhdGUgZGlzcGxheWluZ1N0YXRzOiBib29sZWFuO1xuICBwcml2YXRlIGluZGV4OiB7W25vZGVOYW1lOiBzdHJpbmddOiBSZW5kZXJOb2RlSW5mb307XG4gIHByaXZhdGUgcmVuZGVyZWRPcE5hbWVzOiBzdHJpbmdbXTtcbiAgcHJpdmF0ZSBkZXZpY2VDb2xvck1hcDogZDMuU2NhbGVPcmRpbmFsPHN0cmluZywgc3RyaW5nPjtcbiAgcHJpdmF0ZSB4bGFDbHVzdGVyQ29sb3JNYXA6IGQzLlNjYWxlT3JkaW5hbDxzdHJpbmcsIHN0cmluZz47XG4gIHByaXZhdGUgbWVtb3J5VXNhZ2VTY2FsZTogZDMuU2NhbGVMaW5lYXI8c3RyaW5nLCBzdHJpbmc+O1xuICBwcml2YXRlIGNvbXB1dGVUaW1lU2NhbGU6IGQzLlNjYWxlTGluZWFyPHN0cmluZywgc3RyaW5nPjtcbiAgLyoqIFNjYWxlIGZvciB0aGUgdGhpY2tuZXNzIG9mIGVkZ2VzIHdoZW4gdGhlcmUgaXMgbm8gc2hhcGUgaW5mb3JtYXRpb24uICovXG4gIGVkZ2VXaWR0aFNpemVkQmFzZWRTY2FsZTpcbiAgICAgIGQzLlNjYWxlTGluZWFyPG51bWJlciwgbnVtYmVyPiB8IGQzLlNjYWxlUG93ZXI8bnVtYmVyLCBudW1iZXI+O1xuICAvLyBTaW5jZSB0aGUgcmVuZGVyaW5nIGluZm9ybWF0aW9uIGZvciBlYWNoIG5vZGUgaXMgY29uc3RydWN0ZWQgbGF6aWx5LFxuICAvLyB1cG9uIG5vZGUncyBleHBhbnNpb24gYnkgdGhlIHVzZXIsIHdlIGtlZXAgYSBtYXAgYmV0d2VlbiB0aGUgbm9kZSdzIG5hbWVcbiAgLy8gYW5kIHdoZXRoZXIgdGhlIHJlbmRlcmluZyBpbmZvcm1hdGlvbiB3YXMgYWxyZWFkeSBjb25zdHJ1Y3RlZCBmb3IgdGhhdFxuICAvLyBub2RlLlxuICBwcml2YXRlIGhhc1N1YmhpZXJhcmNoeToge1tub2RlTmFtZTogc3RyaW5nXTogYm9vbGVhbn07XG4gIHJvb3Q6IFJlbmRlckdyb3VwTm9kZUluZm87XG4gIHRyYWNlSW5wdXRzOiBCb29sZWFuO1xuICBlZGdlTGFiZWxGdW5jdGlvbjogRWRnZUxhYmVsRnVuY3Rpb247XG4gIC8vIEFuIG9wdGlvbmFsIGZ1bmN0aW9uIHRoYXQgY29tcHV0ZXMgdGhlIHRoaWNrbmVzcyBvZiBhbiBlZGdlIGdpdmVuIGVkZ2VcbiAgLy8gZGF0YS4gSWYgbm90IHByb3ZpZGVkLCBkZWZhdWx0cyB0byBlbmNvZGluZyB0ZW5zb3Igc2l6ZSBpbiB0aGlja25lc3MuXG4gIGVkZ2VXaWR0aEZ1bmN0aW9uOiBFZGdlVGhpY2tuZXNzRnVuY3Rpb247XG5cbiAgY29uc3RydWN0b3IoaGllcmFyY2h5OiBoaWVyYXJjaHkuSGllcmFyY2h5LCBkaXNwbGF5aW5nU3RhdHM6IGJvb2xlYW4pIHtcbiAgICB0aGlzLmhpZXJhcmNoeSA9IGhpZXJhcmNoeTtcbiAgICB0aGlzLmRpc3BsYXlpbmdTdGF0cyA9IGRpc3BsYXlpbmdTdGF0cztcbiAgICB0aGlzLmluZGV4ID0ge307XG4gICAgdGhpcy5yZW5kZXJlZE9wTmFtZXMgPSBbXTtcblxuICAgIHRoaXMuY29tcHV0ZVNjYWxlcygpO1xuICAgIC8vIE1hcHMgbm9kZSBuYW1lIHRvIHdoZXRoZXIgdGhlIHJlbmRlcmluZyBoaWVyYXJjaHkgd2FzIGFscmVhZHlcbiAgICAvLyBjb25zdHJ1Y3RlZC5cbiAgICB0aGlzLmhhc1N1YmhpZXJhcmNoeSA9IHt9O1xuICAgIHRoaXMucm9vdCA9IG5ldyBSZW5kZXJHcm91cE5vZGVJbmZvKGhpZXJhcmNoeS5yb290LCBoaWVyYXJjaHkuZ3JhcGhPcHRpb25zKTtcbiAgICB0aGlzLmluZGV4W2hpZXJhcmNoeS5yb290Lm5hbWVdID0gdGhpcy5yb290O1xuICAgIHRoaXMucmVuZGVyZWRPcE5hbWVzLnB1c2goaGllcmFyY2h5LnJvb3QubmFtZSk7XG4gICAgdGhpcy5idWlsZFN1YmhpZXJhcmNoeShoaWVyYXJjaHkucm9vdC5uYW1lKTtcbiAgICB0aGlzLnJvb3QuZXhwYW5kZWQgPSB0cnVlO1xuICAgIHRoaXMudHJhY2VJbnB1dHMgPSBmYWxzZTtcbiAgfVxuXG4gIGNvbXB1dGVTY2FsZXMoKSB7XG4gICAgdGhpcy5kZXZpY2VDb2xvck1hcCA9IGQzLnNjYWxlT3JkaW5hbDxzdHJpbmc+KClcbiAgICAgICAgLmRvbWFpbih0aGlzLmhpZXJhcmNoeS5kZXZpY2VzKVxuICAgICAgICAucmFuZ2UoXy5tYXAoZDMucmFuZ2UodGhpcy5oaWVyYXJjaHkuZGV2aWNlcy5sZW5ndGgpLFxuICAgICAgICAgICAgICAgICAgICAgTWV0YW5vZGVDb2xvcnMuREVWSUNFX1BBTEVUVEUpKTtcblxuICAgIHRoaXMueGxhQ2x1c3RlckNvbG9yTWFwID1cbiAgICAgICAgZDMuc2NhbGVPcmRpbmFsPHN0cmluZz4oKVxuICAgICAgICAgICAgLmRvbWFpbih0aGlzLmhpZXJhcmNoeS54bGFDbHVzdGVycylcbiAgICAgICAgICAgIC5yYW5nZShfLm1hcChcbiAgICAgICAgICAgICAgICBkMy5yYW5nZSh0aGlzLmhpZXJhcmNoeS54bGFDbHVzdGVycy5sZW5ndGgpLFxuICAgICAgICAgICAgICAgIE1ldGFub2RlQ29sb3JzLlhMQV9DTFVTVEVSX1BBTEVUVEUpKTtcblxuICAgIGxldCB0b3BMZXZlbEdyYXBoID0gdGhpcy5oaWVyYXJjaHkucm9vdC5tZXRhZ3JhcGg7XG4gICAgLy8gRmluZCB0aGUgbWF4aW11bSBtZW1vcnkgdXNhZ2UuIFVzZSAwIGFzIHRoZSBtaW5pbXVtLlxuICAgIGxldCBtYXhNZW1vcnkgPSBkMy5tYXgodG9wTGV2ZWxHcmFwaC5ub2RlcygpLFxuICAgICAgICAobm9kZU5hbWUsIGluZGV4KSA9PiB7XG4gICAgICBsZXQgbm9kZSA9IHRvcExldmVsR3JhcGgubm9kZShub2RlTmFtZSk7XG4gICAgICAvLyBTb21lIG9wcyBkb24ndCBoYXZlIHN0YXRzIGF0IGFsbC5cbiAgICAgIGlmIChub2RlLnN0YXRzICE9IG51bGwpIHtcbiAgICAgICAgcmV0dXJuIG5vZGUuc3RhdHMudG90YWxCeXRlcztcbiAgICAgIH1cbiAgICB9KTtcbiAgICB0aGlzLm1lbW9yeVVzYWdlU2NhbGUgPSBkMy5zY2FsZUxpbmVhcjxzdHJpbmcsIHN0cmluZz4oKVxuICAgICAgICAuZG9tYWluKFswLCBtYXhNZW1vcnldKVxuICAgICAgICAucmFuZ2UoUEFSQU1TLm1pbk1heENvbG9ycyk7XG5cbiAgICAvLyBGaW5kIHRoZSBtYXhpbXVtIGNvbXB1dGUgdGltZS4gVXNlIDAgYXMgdGhlIG1pbmltdW0uXG4gICAgbGV0IG1heENvbXB1dGVUaW1lID0gZDMubWF4KHRvcExldmVsR3JhcGgubm9kZXMoKSxcbiAgICAgICAgKG5vZGVOYW1lLCBpbmRleCkgPT4ge1xuICAgICAgbGV0IG5vZGUgPSB0b3BMZXZlbEdyYXBoLm5vZGUobm9kZU5hbWUpO1xuICAgICAgLy8gU29tZSBvcHMgZG9uJ3QgaGF2ZSBzdGF0cyBhdCBhbGwuXG4gICAgICBpZiAobm9kZS5zdGF0cyAhPSBudWxsKSB7XG4gICAgICAgIHJldHVybiBub2RlLnN0YXRzLmdldFRvdGFsTWljcm9zKCk7XG4gICAgICB9XG4gICAgfSk7XG4gICAgdGhpcy5jb21wdXRlVGltZVNjYWxlID0gZDMuc2NhbGVMaW5lYXI8c3RyaW5nLCBzdHJpbmc+KClcbiAgICAgICAgLmRvbWFpbihbMCwgbWF4Q29tcHV0ZVRpbWVdKVxuICAgICAgICAucmFuZ2UoUEFSQU1TLm1pbk1heENvbG9ycyk7XG5cbiAgICB0aGlzLmVkZ2VXaWR0aFNpemVkQmFzZWRTY2FsZSA9IHRoaXMuaGllcmFyY2h5Lmhhc1NoYXBlSW5mbyA/XG4gICAgICBzY2VuZS5lZGdlLkVER0VfV0lEVEhfU0laRV9CQVNFRF9TQ0FMRSA6XG4gICAgICBkMy5zY2FsZUxpbmVhcigpXG4gICAgICAgIC5kb21haW4oWzEsIHRoaXMuaGllcmFyY2h5Lm1heE1ldGFFZGdlU2l6ZV0pXG4gICAgICAgIC5yYW5nZShbc2NlbmUuZWRnZS5NSU5fRURHRV9XSURUSCwgc2NlbmUuZWRnZS5NQVhfRURHRV9XSURUSF0pO1xuICB9XG5cbiAgLyoqXG4gICAqIEdldCBhIHByZXZpb3VzbHkgY3JlYXRlZCBSZW5kZXJOb2RlSW5mbyBieSBpdHMgbm9kZSBuYW1lLlxuICAgKi9cbiAgZ2V0UmVuZGVyTm9kZUJ5TmFtZShub2RlTmFtZTogc3RyaW5nKTogUmVuZGVyTm9kZUluZm8ge1xuICAgIHJldHVybiB0aGlzLmluZGV4W25vZGVOYW1lXTtcbiAgfVxuXG4gIC8qKlxuICAgKiBHZXQgdGhlIHVuZGVybHlpbmcgbm9kZSBpbiB0aGUgaGllcmFyY2hpY2FsIGdyYXBoIGJ5IGl0cyBuYW1lLlxuICAgKi9cbiAgZ2V0Tm9kZUJ5TmFtZShub2RlTmFtZTogc3RyaW5nKTogTm9kZSB7XG4gICAgcmV0dXJuIHRoaXMuaGllcmFyY2h5Lm5vZGUobm9kZU5hbWUpO1xuICB9XG5cbiAgcHJpdmF0ZSBjb2xvckhpc3RvZ3JhbShcbiAgICAgIGhpc3RvZ3JhbToge1tuYW1lOiBzdHJpbmddOiBudW1iZXJ9LFxuICAgICAgY29sb3JzOiBkMy5TY2FsZU9yZGluYWw8c3RyaW5nLCBzdHJpbmc+KTpcbiAgICAgIEFycmF5PHtjb2xvcjogc3RyaW5nLCBwcm9wb3J0aW9uOiBudW1iZXJ9PiB7XG4gICAgaWYgKE9iamVjdC5rZXlzKGhpc3RvZ3JhbSkubGVuZ3RoID4gMCkge1xuICAgICAgLy8gQ29tcHV0ZSB0aGUgdG90YWwgIyBvZiBpdGVtcy5cbiAgICAgIGNvbnN0IG51bUl0ZW1zID0gXy5zdW0oT2JqZWN0LmtleXMoaGlzdG9ncmFtKS5tYXAoa2V5ID0+IGhpc3RvZ3JhbVtrZXldKSk7XG4gICAgICByZXR1cm4gT2JqZWN0LmtleXMoaGlzdG9ncmFtKS5tYXAoa2V5ID0+ICh7XG4gICAgICAgIGNvbG9yOiBjb2xvcnMoa2V5KSxcbiAgICAgICAgLy8gTm9ybWFsaXplIHRvIGEgcHJvcG9ydGlvbiBvZiB0b3RhbCAjIG9mIGl0ZW1zLlxuICAgICAgICBwcm9wb3J0aW9uOiBoaXN0b2dyYW1ba2V5XSAvIG51bUl0ZW1zLFxuICAgICAgfSkpO1xuICAgIH1cbiAgICBjb25zb2xlLmluZm8oJ25vIHBhaXJzIGZvdW5kIScpO1xuICAgIHJldHVybiBudWxsO1xuICB9XG5cbiAgLyoqXG4gICAqIEdldCBhIHByZXZpb3VzbHkgY3JlYXRlZCBSZW5kZXJOb2RlSW5mbyBmb3IgdGhlIHNwZWNpZmllZCBub2RlIG5hbWUsXG4gICAqIG9yIGNyZWF0ZSBvbmUgaWYgaXQgaGFzbid0IGJlZW4gY3JlYXRlZCB5ZXQuXG4gICAqL1xuICBnZXRPckNyZWF0ZVJlbmRlck5vZGVCeU5hbWUobm9kZU5hbWU6IHN0cmluZyk6IFJlbmRlck5vZGVJbmZvIHtcbiAgICAvLyBQb2x5bWVyIG1heSBpbnZva2UgdGhpcyB3aXRoIG51bGwuXG4gICAgaWYgKCFub2RlTmFtZSkge1xuICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuXG4gICAgaWYgKG5vZGVOYW1lIGluIHRoaXMuaW5kZXgpIHtcbiAgICAgIHJldHVybiB0aGlzLmluZGV4W25vZGVOYW1lXTtcbiAgICB9XG5cbiAgICBsZXQgbm9kZSA9IHRoaXMuaGllcmFyY2h5Lm5vZGUobm9kZU5hbWUpO1xuICAgIC8vIEV4aXQgZWFybHkgaWYgdGhlIG5vZGUgZG9lcyBub3QgZXhpc3QgaW4gdGhlIGhpZXJhcmNoeS4gVGhpcyBjYW4gaGFwcGVuXG4gICAgLy8gd2hlbiBhIGdyYXBoIGlzIHJlbG9hZGVkIHdoaWxlIHRoZSBpbmZvY2FyZCBwb2ludHMgdG8gYSBub2RlIG5vdCB2aXNpYmxlXG4gICAgLy8gYXQgdGhlIHRvcC1sZXZlbC5cbiAgICBpZiAoIW5vZGUpIHtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICBsZXQgcmVuZGVySW5mbyA9IG5vZGUuaXNHcm91cE5vZGUgP1xuICAgICAgICBuZXcgUmVuZGVyR3JvdXBOb2RlSW5mbyg8R3JvdXBOb2RlPm5vZGUsIHRoaXMuaGllcmFyY2h5LmdyYXBoT3B0aW9ucykgOlxuICAgICAgICBuZXcgUmVuZGVyTm9kZUluZm8obm9kZSk7XG4gICAgdGhpcy5pbmRleFtub2RlTmFtZV0gPSByZW5kZXJJbmZvO1xuICAgIHRoaXMucmVuZGVyZWRPcE5hbWVzLnB1c2gobm9kZU5hbWUpO1xuXG4gICAgaWYgKG5vZGUuc3RhdHMpIHtcbiAgICAgIHJlbmRlckluZm8ubWVtb3J5Q29sb3IgPSB0aGlzLm1lbW9yeVVzYWdlU2NhbGUobm9kZS5zdGF0cy50b3RhbEJ5dGVzKTtcbiAgICAgIHJlbmRlckluZm8uY29tcHV0ZVRpbWVDb2xvciA9XG4gICAgICAgICAgdGhpcy5jb21wdXRlVGltZVNjYWxlKG5vZGUuc3RhdHMuZ2V0VG90YWxNaWNyb3MoKSk7XG4gICAgfVxuXG4gICAgLy8gV2Ugb25seSBmYWRlIG5vZGVzIHdoZW4gd2UncmUgZGlzcGxheWluZyBzdGF0cy5cbiAgICByZW5kZXJJbmZvLmlzRmFkZWRPdXQgPSB0aGlzLmRpc3BsYXlpbmdTdGF0cyAmJlxuICAgICAgICAhdGYuZ3JhcGgudXRpbC5oYXNEaXNwbGF5YWJsZU5vZGVTdGF0cyhub2RlLnN0YXRzKTtcblxuICAgIHZhciBkZXZpY2VIaXN0b2dyYW0gPSBudWxsO1xuICAgIHZhciB4bGFDbHVzdGVySGlzdG9ncmFtID0gbnVsbDtcbiAgICB2YXIgb3BDb21wYXRpYmlsaXR5ID0gbnVsbDtcbiAgICBpZiAobm9kZS5pc0dyb3VwTm9kZSkge1xuICAgICAgZGV2aWNlSGlzdG9ncmFtID0gKDxHcm91cE5vZGU+bm9kZSkuZGV2aWNlSGlzdG9ncmFtO1xuICAgICAgeGxhQ2x1c3Rlckhpc3RvZ3JhbSA9ICg8R3JvdXBOb2RlPm5vZGUpLnhsYUNsdXN0ZXJIaXN0b2dyYW07XG4gICAgICBsZXQgY29tcGF0ID0gKDxHcm91cE5vZGU+bm9kZSkuY29tcGF0aWJpbGl0eUhpc3RvZ3JhbS5jb21wYXRpYmxlO1xuICAgICAgbGV0IGluY29tcGF0ID0gKDxHcm91cE5vZGU+bm9kZSkuY29tcGF0aWJpbGl0eUhpc3RvZ3JhbS5pbmNvbXBhdGlibGU7XG4gICAgICBpZiAoY29tcGF0ICE9IDAgfHwgaW5jb21wYXQgIT0gMCkge1xuICAgICAgICBvcENvbXBhdGliaWxpdHkgPSBjb21wYXQgLyAoY29tcGF0ICsgaW5jb21wYXQpO1xuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICBsZXQgZGV2aWNlID0gKDxPcE5vZGU+cmVuZGVySW5mby5ub2RlKS5kZXZpY2U7XG4gICAgICBpZiAoZGV2aWNlKSB7XG4gICAgICAgIGRldmljZUhpc3RvZ3JhbSA9IHtbZGV2aWNlXTogMX07XG4gICAgICB9XG4gICAgICBsZXQgeGxhQ2x1c3RlciA9ICg8T3BOb2RlPnJlbmRlckluZm8ubm9kZSkueGxhQ2x1c3RlcjtcbiAgICAgIGlmICh4bGFDbHVzdGVyKSB7XG4gICAgICAgIHhsYUNsdXN0ZXJIaXN0b2dyYW0gPSB7W3hsYUNsdXN0ZXJdOiAxfTtcbiAgICAgIH1cbiAgICAgIGlmIChyZW5kZXJJbmZvLm5vZGUudHlwZSA9PT0gTm9kZVR5cGUuT1ApIHtcbiAgICAgICAgb3BDb21wYXRpYmlsaXR5ID0gKDxPcE5vZGU+cmVuZGVySW5mby5ub2RlKS5jb21wYXRpYmxlID8gMSA6IDA7XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChkZXZpY2VIaXN0b2dyYW0pIHtcbiAgICAgIHJlbmRlckluZm8uZGV2aWNlQ29sb3JzID1cbiAgICAgICAgICB0aGlzLmNvbG9ySGlzdG9ncmFtKGRldmljZUhpc3RvZ3JhbSwgdGhpcy5kZXZpY2VDb2xvck1hcCk7XG4gICAgfVxuICAgIGlmICh4bGFDbHVzdGVySGlzdG9ncmFtKSB7XG4gICAgICByZW5kZXJJbmZvLnhsYUNsdXN0ZXJDb2xvcnMgPVxuICAgICAgICAgIHRoaXMuY29sb3JIaXN0b2dyYW0oeGxhQ2x1c3Rlckhpc3RvZ3JhbSwgdGhpcy54bGFDbHVzdGVyQ29sb3JNYXApO1xuICAgIH1cbiAgICBpZiAob3BDb21wYXRpYmlsaXR5ICE9IG51bGwpIHtcbiAgICAgIHJlbmRlckluZm8uY29tcGF0aWJpbGl0eUNvbG9ycyA9IFtcbiAgICAgICAge1xuICAgICAgICAgIGNvbG9yOiB0Zi5ncmFwaC5yZW5kZXIuT3BOb2RlQ29sb3JzLkNPTVBBVElCTEUsXG4gICAgICAgICAgcHJvcG9ydGlvbjogb3BDb21wYXRpYmlsaXR5XG4gICAgICAgIH0sXG4gICAgICAgIHtcbiAgICAgICAgICBjb2xvcjogdGYuZ3JhcGgucmVuZGVyLk9wTm9kZUNvbG9ycy5JTkNPTVBBVElCTEUsXG4gICAgICAgICAgcHJvcG9ydGlvbjogMSAtIG9wQ29tcGF0aWJpbGl0eVxuICAgICAgICB9XG4gICAgICBdO1xuICAgIH1cblxuICAgIHJldHVybiB0aGlzLmluZGV4W25vZGVOYW1lXTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm4gdGhlIG5lYXJlc3QgYW5jZXN0b3Igbm9kZSwgaW5jbHVkaW5nIGl0c2VsZiwgdGhhdCBpcyB2aXNpYmxlXG4gICAqIGluIHRoZSB2aXN1YWxpemF0aW9uLiBUaGlzIG1ldGhvZCBpcyB1c2VkIHNvIHRoYXQgd2UgY2FuIHNlbGVjdFxuICAgKiAoaGlnaGxpZ2h0KSBhIG5vZGUgdGhhdCBpc24ndCBkcmF3biB5ZXQsIGJ5IHNlbGVjdGluZyAoaGlnaGxpZ2h0aW5nKVxuICAgKiBpdHMgbmVhcmVzdCBhbmNlc3RvciB0aGF0IGhhcyBiZWVuIGRyYXduLlxuICAgKi9cbiAgZ2V0TmVhcmVzdFZpc2libGVBbmNlc3RvcihuYW1lOiBzdHJpbmcpOiBzdHJpbmcge1xuICAgIGxldCBwYXRoID0gZ2V0SGllcmFyY2hpY2FsUGF0aChuYW1lKTtcbiAgICBsZXQgaSA9IDA7XG4gICAgbGV0IHJlbmRlck5vZGU6IFJlbmRlck5vZGVJbmZvID0gbnVsbDtcbiAgICAvLyBGYWxsdGhyb3VnaC4gSWYgZXZlcnl0aGluZyB3YXMgZXhwYW5kZWQgcmV0dXJuIHRoZSBub2RlLlxuICAgIGxldCBub2RlTmFtZSA9IG5hbWU7XG4gICAgZm9yICg7IGkgPCBwYXRoLmxlbmd0aDsgaSsrKSB7XG4gICAgICBub2RlTmFtZSA9IHBhdGhbaV07XG4gICAgICByZW5kZXJOb2RlID0gdGhpcy5nZXRSZW5kZXJOb2RlQnlOYW1lKG5vZGVOYW1lKTtcbiAgICAgIC8vIE9wIG5vZGVzIGhhdmUgZXhwYW5kZWQgc2V0IHRvIGZhbHNlIGJ5IGRlZmF1bHQuXG4gICAgICBpZiAoIXJlbmRlck5vZGUuZXhwYW5kZWQpIHtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgfVxuXG4gICAgLy8gQ2hlY2sgY2FzZSB3aGVyZSBoaWdobGlnaHRlZCBub2RlIGlzIGFuIGVtYmVkZGVkIG5vZGUgd2hvc2UgcGFyZW50IG5vZGVcbiAgICAvLyBpcyBhbHNvIGl0cyBoaWVyYXJjaGljYWwgcGFyZW50LiBJbiB0aGlzIGNhc2UsIHdlIHdhbnQgdG8gcmV0dXJuIHRoZVxuICAgIC8vIGVtYmVkZGVkIG5vZGUgbmFtZSwgYXMgaXQgaXMgYWxzbyBkaXNwbGF5ZWQgaWYgaXRzIHBhcmVudCBoYXMgYmVlblxuICAgIC8vIGRpc3BsYXllZC5cbiAgICBpZiAoaSA9PSBwYXRoLmxlbmd0aCAtIDIpIHtcbiAgICAgIGxldCBuZXh0TmFtZSA9IHBhdGhbaSArIDFdO1xuICAgICAgaWYgKHJlbmRlck5vZGUuaW5Bbm5vdGF0aW9ucy5ub2RlTmFtZXNbbmV4dE5hbWVdKSB7XG4gICAgICAgIHJldHVybiBuZXh0TmFtZTtcbiAgICAgIH1cblxuICAgICAgaWYgKHJlbmRlck5vZGUub3V0QW5ub3RhdGlvbnMubm9kZU5hbWVzW25leHROYW1lXSkge1xuICAgICAgICByZXR1cm4gbmV4dE5hbWU7XG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIG5vZGVOYW1lO1xuICB9XG5cbiAgLy8gVE9ETzogRGVsZXRlIHRoaXMgYW4gYW55IGNvZGUgaXQgdG91Y2hlcyAoYWxsIGRlcHJlY2F0ZWQpLlxuICBzZXREZXB0aChkZXB0aDogbnVtYmVyKTogdm9pZCB7XG4gICAgc2V0R3JvdXBOb2RlRGVwdGgodGhpcy5yb290LCArZGVwdGgpO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybnMgdHJ1ZSBpZiB0aGUgcmVuZGVyTm9kZSBpcyBhbiBpc29sYXRlZCBub2RlIHdpdGhpbiBpdHMgcGFyZW50IG5vZGUuXG4gICAqL1xuICBpc05vZGVBdXhpbGlhcnkocmVuZGVyTm9kZTogUmVuZGVyTm9kZUluZm8pOiBib29sZWFuIHtcbiAgICBsZXQgcGFyZW50Tm9kZSA9IDxSZW5kZXJHcm91cE5vZGVJbmZvPnRoaXMuZ2V0UmVuZGVyTm9kZUJ5TmFtZShcbiAgICAgIHJlbmRlck5vZGUubm9kZS5wYXJlbnROb2RlLm5hbWUpO1xuICAgIGxldCBmb3VuZCA9IF8uZmluZChwYXJlbnROb2RlLmlzb2xhdGVkSW5FeHRyYWN0LCBub2RlID0+IHtcbiAgICAgIHJldHVybiBub2RlLm5vZGUubmFtZSA9PT0gcmVuZGVyTm9kZS5ub2RlLm5hbWU7XG4gICAgfSk7XG4gICAgaWYgKGZvdW5kKSB7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgZm91bmQgPSBfLmZpbmQocGFyZW50Tm9kZS5pc29sYXRlZE91dEV4dHJhY3QsIG5vZGUgPT4ge1xuICAgICAgcmV0dXJuIG5vZGUubm9kZS5uYW1lID09PSByZW5kZXJOb2RlLm5vZGUubmFtZTtcbiAgICB9KTtcbiAgICByZXR1cm4gISFmb3VuZDtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm5zIGEgbGlzdCBvZiBvcHMgdGhhdCBoYXZlIGJlZW4gcmVuZGVyZWQgc28gZmFyIGZvciB0aGlzIGdyYXBoLiBNb3JlXG4gICAqIG9wcyBtYXkgbGF0ZXIgYmUgcmVuZGVyZWQgaWYgdGhlIHVzZXIgZXhwYW5kcyBub2RlcyBmb3IgaW5zdGFuY2UuIFRoZSBsaXN0XG4gICAqIHJldHVybmVkIGhlcmUgY2FuIG9ubHkgc3RheSB0aGUgc2FtZSBzaXplIG9yIGdyb3cgb24gc3VjY2Vzc2l2ZSBjYWxscy5cbiAgICovXG4gIGdldE5hbWVzT2ZSZW5kZXJlZE9wcygpOiBzdHJpbmdbXSB7XG4gICAgcmV0dXJuIHRoaXMucmVuZGVyZWRPcE5hbWVzO1xuICB9XG5cbiAgLyoqXG4gICAqIENsb25lcyBhbiBvcCBub2RlIGFuZCBhZGRzIGl0IHRvIGEgbWV0YWdyYXBoLiBEb2VzIG5vdGhpbmcgaWYgYW4gb3Agbm9kZVxuICAgKiB3aXRoIHRoZSBzYW1lIG5ldyBuYW1lIGhhcyBhbHJlYWR5IGJlZW4gY3JlYXRlZCB3aXRoaW4gdGhlIG1ldGFncmFwaC4gVGhpc1xuICAgKiBtZXRob2QgaXMgdXNlZCB3aGVuIGR1cGxpY2F0aW5nIGEgbGlicmFyeSBmdW5jdGlvbiB0byBiZSBpbmplY3RlZCB3aXRoaW4gYVxuICAgKiBtZXRhbm9kZSByZXByZXNlbnRpbmcgYSBmdW5jdGlvbiBjYWxsLlxuICAgKiBAcGFyYW0gcGFyZW50TWV0YW5vZGUgVGhlIHBhcmVudCBtZXRhbm9kZSBvbiB3aGljaCB0byBhZGQgdGhlIG5ldyBub2RlLlxuICAgKiBAcGFyYW0gbm9kZSBUaGUgb3Agbm9kZSB0byBjbG9uZS5cbiAgICogQHBhcmFtIG5ld1ByZWZpeCBUaGUgcHJlZml4IHN0cmluZyB0byB1c2UgaW4gbGlldSBvZiB0aGUgb25lIHRoYXQgbWVyZWx5XG4gICAqICAgICBpbmRpY2F0ZXMgdGhhdCB0aGUgbWV0YW5vZGUgcmVwcmVzZW50cyBhIGZ1bmN0aW9uIGRlZmluZWQgaW4gdGhlXG4gICAqICAgICBsaWJyYXJ5LiBUaGlzIHByZWZpeCBzaG91bGQgcmVmbGVjdCBncmFwaCBoaWVyYXJjaHkuXG4gICAqIEByZXR1cm4gVGhlIG5ld2x5IGNyZWF0ZWQgb3Agbm9kZSAodGhlIGNsb25lIG9mIHRoZSBvcmlnaW5hbCkuXG4gICAqL1xuICBwcml2YXRlIGNsb25lQW5kQWRkRnVuY3Rpb25PcE5vZGUoXG4gICAgICBwYXJlbnRNZXRhbm9kZTogTWV0YW5vZGUsXG4gICAgICBsaWJyYXJ5RnVuY3Rpb25Ob2RlTmFtZTogc3RyaW5nLFxuICAgICAgbm9kZTogT3BOb2RlLFxuICAgICAgbmV3UHJlZml4OiBzdHJpbmcpOiBPcE5vZGUge1xuICAgIGNvbnN0IG5ld05hbWUgPSBub2RlLm5hbWUucmVwbGFjZShcbiAgICAgICAgbGlicmFyeUZ1bmN0aW9uTm9kZU5hbWUsIG5ld1ByZWZpeCk7XG4gICAgbGV0IG5ld09wTm9kZSA9IHBhcmVudE1ldGFub2RlLm1ldGFncmFwaC5ub2RlKG5ld05hbWUpO1xuICAgIGlmIChuZXdPcE5vZGUpIHtcbiAgICAgIC8vIFRoaXMgbm9kZSBoYWQgYWxyZWFkeSBiZWVuIGNyZWF0ZWQgYW5kIGFkZGVkIHRvIHRoZSBncmFwaC5cbiAgICAgIHJldHVybiBuZXdPcE5vZGUgYXMgT3BOb2RlO1xuICAgIH1cblxuICAgIC8vIENyZWF0ZSBhIG5ldyBvcCBub2RlLlxuICAgIG5ld09wTm9kZSA9IG5ldyBPcE5vZGVJbXBsKHtcbiAgICAgIG5hbWU6IG5ld05hbWUsXG4gICAgICBpbnB1dDogW10sXG4gICAgICBkZXZpY2U6IG5vZGUuZGV2aWNlLFxuICAgICAgb3A6IG5vZGUub3AsXG4gICAgICBhdHRyOiBfLmNsb25lRGVlcChub2RlLmF0dHIpLFxuICAgIH0pO1xuXG4gICAgLy8gVXBkYXRlIHZhcmlvdXMgcHJvcGVydGllcy5cbiAgICBuZXdPcE5vZGUuY2FyZGluYWxpdHkgPSBub2RlLmNhcmRpbmFsaXR5O1xuICAgIG5ld09wTm9kZS5pbmNsdWRlID0gbm9kZS5pbmNsdWRlO1xuICAgIG5ld09wTm9kZS5vdXRwdXRTaGFwZXMgPSBfLmNsb25lRGVlcChub2RlLm91dHB1dFNoYXBlcyk7XG4gICAgbmV3T3BOb2RlLnhsYUNsdXN0ZXIgPSBub2RlLnhsYUNsdXN0ZXI7XG4gICAgbmV3T3BOb2RlLmZ1bmN0aW9uSW5wdXRJbmRleCA9IG5vZGUuZnVuY3Rpb25JbnB1dEluZGV4O1xuICAgIG5ld09wTm9kZS5mdW5jdGlvbk91dHB1dEluZGV4ID0gbm9kZS5mdW5jdGlvbk91dHB1dEluZGV4O1xuXG4gICAgLy8gVXBkYXRlIHRoZSBpbnB1dHMgb2YgdGhlIG5ldyBub2RlIHRvIHJlZmxlY3QgdGhlIG5ldyBwYXRoLlxuICAgIG5ld09wTm9kZS5pbnB1dHMgPSBub2RlLmlucHV0cy5tYXAobm9ybWFsaXplZElucHV0ID0+IHtcbiAgICAgIGNvbnN0IG5ld05vcm1hbGl6ZWRJbnB1dCA9IF8uY2xvbmUobm9ybWFsaXplZElucHV0KTtcbiAgICAgIG5ld05vcm1hbGl6ZWRJbnB1dC5uYW1lID0gbm9ybWFsaXplZElucHV0Lm5hbWUucmVwbGFjZShcbiAgICAgICAgICBsaWJyYXJ5RnVuY3Rpb25Ob2RlTmFtZSwgbmV3UHJlZml4KTtcbiAgICAgIHJldHVybiBuZXdOb3JtYWxpemVkSW5wdXQ7XG4gICAgfSk7XG5cbiAgICAvLyBBZGQgdGhlIG5ldyBvcCBub2RlIHRvIHRoZSBoaWVyYXJjaHkgYW5kIG1ldGFncmFwaC4gQWxzbyBhZGQgaXQgdG8gaXRzXG4gICAgLy8gcGFyZW50IG1ldGFub2RlLlxuICAgIG5ld09wTm9kZS5wYXJlbnROb2RlID0gcGFyZW50TWV0YW5vZGU7XG4gICAgcGFyZW50TWV0YW5vZGUubWV0YWdyYXBoLnNldE5vZGUobmV3T3BOb2RlLm5hbWUsIG5ld09wTm9kZSk7XG4gICAgdGhpcy5oaWVyYXJjaHkuc2V0Tm9kZShuZXdPcE5vZGUubmFtZSwgbmV3T3BOb2RlKTtcblxuICAgIC8vIFVwZGF0ZSBlbWJlZGRpbmdzLlxuICAgIGNvbnN0IHVwZGF0ZUVtYmVkZGluZ09wTm9kZSA9IGVtYmVkZGluZ05vZGUgPT4ge1xuICAgICAgcmV0dXJuIHRoaXMuY2xvbmVBbmRBZGRGdW5jdGlvbk9wTm9kZShcbiAgICAgICAgICBwYXJlbnRNZXRhbm9kZSwgbGlicmFyeUZ1bmN0aW9uTm9kZU5hbWUsIGVtYmVkZGluZ05vZGUsIG5ld1ByZWZpeCk7XG4gICAgfVxuICAgIG5ld09wTm9kZS5pbkVtYmVkZGluZ3MgPSBub2RlLmluRW1iZWRkaW5ncy5tYXAodXBkYXRlRW1iZWRkaW5nT3BOb2RlKTtcbiAgICBuZXdPcE5vZGUub3V0RW1iZWRkaW5ncyA9IG5vZGUub3V0RW1iZWRkaW5ncy5tYXAodXBkYXRlRW1iZWRkaW5nT3BOb2RlKTtcblxuICAgIHJldHVybiBuZXdPcE5vZGU7XG4gIH1cblxuICAvKipcbiAgICogQ2xvbmVzIGEgTWV0YW5vZGUgdGhhdCByZXByZXNlbnRzIGEgZnVuY3Rpb24gZGVmaW5lZCBpbiB0aGUgZ3JhcGggbGlicmFyeS5cbiAgICogV2UgZHluYW1pY2FsbHkgaW5qZWN0IGEgY2xvbmUgb2YgYSBmdW5jdGlvbiBpbnRvIGEgbWV0YSBncmFwaCB3aGVuIHRoZSB1c2VyXG4gICAqIGV4cGFuZHMgYSBmdW5jdGlvbiBjYWxsLiBXZSBjYW5ub3QgZG8gdGhpcyBhdCB0aGUgYmVnaW5uaW5nIGJlY2F1c2UgdGhlXG4gICAqIGZ1bmN0aW9ucyBtYXkgcmVjdXJzaXZlbHkgY2FsbCB0aGVtc2VsdmVzIG9yIG90aGVyIGZ1bmN0aW9ucy5cbiAgICogQHBhcmFtIG1ldGFncmFwaCBUaGUgbWV0YWdyYXBoIHdlIGFyZSBjdXJyZW50bHkgcmVuZGVyaW5nIHRoZSBzdWItaGllcmFyY2h5XG4gICAqICAgICBmb3IuXG4gICAqIEBwYXJhbSBvcE5vZGVUb1JlcGxhY2UgVGhlIG9wIG5vZGUgaW4gdGhlIGdyYXBoIHRvIHJlcGxhY2Ugd2l0aCBhIG5ld1xuICAgKiAgICAgKGV4cGFuZGFibGUpIG1ldGFub2RlIHRoYXQgdmlzdWFsaXplcyB0aGUgaW5uYXJkcyBvZiBhIGZ1bmN0aW9uLlxuICAgKiBAcGFyYW0gbGlicmFyeU1ldGFub2RlIFRoZSBtZXRhbm9kZSBmb3IgYSBsaWJyYXJ5IGZ1bmN0aW9uIHRvIGNsb25lLlxuICAgKiBAcGFyYW0gb2xkUHJlZml4IFRoZSBvbGQgcHJlZml4IHRvIHJlcGxhY2UgKHRoYXQganVzdCByZWZsZWN0cyBob3cgdGhpc1xuICAgKiAgICAgbm9kZSBpcyBmb3IgYSBsaWJyYXJ5IGZ1bmN0aW9uKS5cbiAgICogQHBhcmFtIG5ld1ByZWZpeCBUaGUgcHJlZml4IHN0cmluZyB0byB1c2UgaW4gbGlldSBvZiB0aGUgb25lIHRoYXQgbWVyZWx5XG4gICAqICAgICBpbmRpY2F0ZXMgdGhhdCB0aGUgbWV0YW5vZGUgcmVwcmVzZW50cyBhIGZ1bmN0aW9uIGRlZmluZWQgaW4gdGhlXG4gICAqICAgICBsaWJyYXJ5LiBUaGlzIHByZWZpeCBzaG91bGQgcmVmbGVjdCBncmFwaCBoaWVyYXJjaHkuXG4gICAqL1xuICBwcml2YXRlIGNsb25lRnVuY3Rpb25MaWJyYXJ5TWV0YW5vZGUoXG4gICAgICBtZXRhZ3JhcGg6IGdyYXBobGliLkdyYXBoPEdyb3VwTm9kZXxPcE5vZGUsIE1ldGFlZGdlPixcbiAgICAgIG9wTm9kZVRvUmVwbGFjZTogT3BOb2RlLFxuICAgICAgbGlicmFyeU1ldGFub2RlOiBNZXRhbm9kZSxcbiAgICAgIG9sZFByZWZpeDogc3RyaW5nLFxuICAgICAgbmV3UHJlZml4OiBzdHJpbmcpOiBNZXRhbm9kZSB7XG4gICAgLy8gTWFrZSBhIG1hcHBpbmcgYmV0d2VlbiBmdW5jdGlvbiBvdXRwdXQgaW5kZXggYW5kIHRoZSBuZXcgbm9kZSBmb3IgdGhlXG4gICAgLy8gb3V0cHV0LlxuICAgIGNvbnN0IGZ1bmN0aW9uT3V0cHV0SW5kZXhUb05vZGUgPSB7fTtcblxuICAgIGNvbnN0IG5ld01ldGFub2RlID0gdGhpcy5jbG9uZUZ1bmN0aW9uTGlicmFyeU1ldGFub2RlSGVscGVyKFxuICAgICAgICBtZXRhZ3JhcGgsXG4gICAgICAgIG9wTm9kZVRvUmVwbGFjZSxcbiAgICAgICAgbGlicmFyeU1ldGFub2RlLFxuICAgICAgICBvbGRQcmVmaXgsXG4gICAgICAgIG5ld1ByZWZpeCxcbiAgICAgICAgZnVuY3Rpb25PdXRwdXRJbmRleFRvTm9kZSk7XG5cbiAgICBpZiAoIV8uaXNFbXB0eShmdW5jdGlvbk91dHB1dEluZGV4VG9Ob2RlKSkge1xuICAgICAgLy8gQWZ0ZXIgd2UgaGF2ZSBjbG9uZWQgdGhlIGVkZ2VzIHdpdGhpbiB0aGUgbWV0YW5vZGUsIHdlIHN0aWxsIG11c3QgYWRkXG4gICAgICAvLyBlZGdlcyB0aGF0IGVtYW5hdGUgb3V0IG9mIG91dHB1dCBvcHMgd2l0aGluIHRoZSBmdW5jdGlvbi5cbiAgICAgIHRoaXMucGF0Y2hFZGdlc0Zyb21GdW5jdGlvbk91dHB1dHMoXG4gICAgICAgICAgb3BOb2RlVG9SZXBsYWNlLCBmdW5jdGlvbk91dHB1dEluZGV4VG9Ob2RlKTtcbiAgICB9XG5cbiAgICByZXR1cm4gbmV3TWV0YW5vZGU7XG4gIH1cblxuICAvKipcbiAgICogQSBoZWxwZXIgc3Vicm91dGluZSB0aGF0IHBlcmZvcm1zIHRoZSBidWxrIG9mIHRoZSBsb2dpYyBmb3JcbiAgICogYGNsb25lRnVuY3Rpb25MaWJyYXJ5TWV0YW5vZGVgLlxuICAgKiBAcGFyYW0gbWV0YWdyYXBoIFRoZSBtZXRhZ3JhcGggd2UgYXJlIGN1cnJlbnRseSByZW5kZXJpbmcgdGhlIHN1Yi1oaWVyYXJjaHlcbiAgICogICAgIGZvci5cbiAgICogQHBhcmFtIG9wTm9kZVRvUmVwbGFjZSBUaGUgb3Agbm9kZSBpbiB0aGUgZ3JhcGggdG8gcmVwbGFjZSB3aXRoIGEgbmV3XG4gICAqICAgICAoZXhwYW5kYWJsZSkgbWV0YW5vZGUgdGhhdCB2aXN1YWxpemVzIHRoZSBpbm5hcmRzIG9mIGEgZnVuY3Rpb24uXG4gICAqIEBwYXJhbSBsaWJyYXJ5TWV0YW5vZGUgVGhlIG1ldGFub2RlIGZvciBhIGxpYnJhcnkgZnVuY3Rpb24gdG8gY2xvbmUuXG4gICAqIEBwYXJhbSBvbGRQcmVmaXggVGhlIG9sZCBwcmVmaXggdG8gcmVwbGFjZSAodGhhdCBqdXN0IHJlZmxlY3RzIGhvdyB0aGlzXG4gICAqICAgICBub2RlIGlzIGZvciBhIGxpYnJhcnkgZnVuY3Rpb24pLlxuICAgKiBAcGFyYW0gbmV3UHJlZml4IFRoZSBwcmVmaXggc3RyaW5nIHRvIHVzZSBpbiBsaWV1IG9mIHRoZSBvbmUgdGhhdCBtZXJlbHlcbiAgICogICAgIGluZGljYXRlcyB0aGF0IHRoZSBtZXRhbm9kZSByZXByZXNlbnRzIGEgZnVuY3Rpb24gZGVmaW5lZCBpbiB0aGVcbiAgICogICAgIGxpYnJhcnkuIFRoaXMgcHJlZml4IHNob3VsZCByZWZsZWN0IGdyYXBoIGhpZXJhcmNoeS5cbiAgICogQHBhcmFtIGZ1bmN0aW9uT3V0cHV0SW5kZXhUb05vZGUgQSBtYXBwaW5nIGJldHdlZW4gZnVuY3Rpb24gb3V0cHV0IGluZGV4XG4gICAqICAgICBhbmQgdGhlIGNvcnJlc3BvbmRpbmcgb3V0cHV0IG5vZGUuIFVzZWQgdG8gY29ubmVjdCBvdXRwdXRzIHdpdGhcbiAgICogICAgIGRlc3RpbmF0aW9ucyBvdXRzaWRlIG9mIHRoZSBmdW5jdGlvbiBtZXRhbm9kZS5cbiAgICovXG4gIHByaXZhdGUgY2xvbmVGdW5jdGlvbkxpYnJhcnlNZXRhbm9kZUhlbHBlcihcbiAgICAgIG1ldGFncmFwaDogZ3JhcGhsaWIuR3JhcGg8R3JvdXBOb2RlfE9wTm9kZSwgTWV0YWVkZ2U+LFxuICAgICAgb3BOb2RlVG9SZXBsYWNlOiBPcE5vZGUsXG4gICAgICBsaWJyYXJ5TWV0YW5vZGU6IE1ldGFub2RlLFxuICAgICAgb2xkUHJlZml4OiBzdHJpbmcsXG4gICAgICBuZXdQcmVmaXg6IHN0cmluZyxcbiAgICAgIGZ1bmN0aW9uT3V0cHV0SW5kZXhUb05vZGU6IHtba2V5OiBzdHJpbmddOiBOb2RlfSk6IE1ldGFub2RlIHtcbiAgICBjb25zdCBuZXdNZXRhbm9kZSA9IHRmLmdyYXBoLmNyZWF0ZU1ldGFub2RlKFxuICAgICAgICBsaWJyYXJ5TWV0YW5vZGUubmFtZS5yZXBsYWNlKG9sZFByZWZpeCwgbmV3UHJlZml4KSk7XG5cbiAgICAvLyBDb3B5IG92ZXIgdmFyaW91cyBwcm9wZXJ0aWVzLlxuICAgIG5ld01ldGFub2RlLmRlcHRoID0gbGlicmFyeU1ldGFub2RlLmRlcHRoO1xuICAgIG5ld01ldGFub2RlLmNhcmRpbmFsaXR5ID0gbGlicmFyeU1ldGFub2RlLmNhcmRpbmFsaXR5O1xuICAgIG5ld01ldGFub2RlLnRlbXBsYXRlSWQgPSBsaWJyYXJ5TWV0YW5vZGUudGVtcGxhdGVJZDtcbiAgICBuZXdNZXRhbm9kZS5vcEhpc3RvZ3JhbSA9IF8uY2xvbmUobGlicmFyeU1ldGFub2RlLm9wSGlzdG9ncmFtKTtcbiAgICBuZXdNZXRhbm9kZS5kZXZpY2VIaXN0b2dyYW0gPSBfLmNsb25lKGxpYnJhcnlNZXRhbm9kZS5kZXZpY2VIaXN0b2dyYW0pO1xuICAgIG5ld01ldGFub2RlLnhsYUNsdXN0ZXJIaXN0b2dyYW0gPVxuICAgICAgICBfLmNsb25lKGxpYnJhcnlNZXRhbm9kZS54bGFDbHVzdGVySGlzdG9ncmFtKTtcbiAgICBuZXdNZXRhbm9kZS5oYXNOb25Db250cm9sRWRnZXMgPSBsaWJyYXJ5TWV0YW5vZGUuaGFzTm9uQ29udHJvbEVkZ2VzO1xuICAgIG5ld01ldGFub2RlLmluY2x1ZGUgPSBsaWJyYXJ5TWV0YW5vZGUuaW5jbHVkZTtcbiAgICBuZXdNZXRhbm9kZS5ub2RlQXR0cmlidXRlcyA9IF8uY2xvbmUobGlicmFyeU1ldGFub2RlLm5vZGVBdHRyaWJ1dGVzKTtcbiAgICBuZXdNZXRhbm9kZS5hc3NvY2lhdGVkRnVuY3Rpb24gPSBsaWJyYXJ5TWV0YW5vZGUuYXNzb2NpYXRlZEZ1bmN0aW9uO1xuXG4gICAgLy8gUmVjdXJzaXZlbHkgZHVwbGljYXRlIHRoZSBjaGlsZHJlbiBub2Rlcy5cbiAgICBfLmVhY2gobGlicmFyeU1ldGFub2RlLm1ldGFncmFwaC5ub2RlcygpLCBub2RlTmFtZSA9PiB7XG4gICAgICBjb25zdCBub2RlID0gbGlicmFyeU1ldGFub2RlLm1ldGFncmFwaC5ub2RlKG5vZGVOYW1lKTtcblxuICAgICAgc3dpdGNoIChub2RlLnR5cGUpIHtcbiAgICAgICAgY2FzZSBOb2RlVHlwZS5NRVRBOlxuICAgICAgICAgIC8vIFJlY3Vyc2l2ZWx5IGR1cGxpY2F0ZSB0aGUgbWV0YW5vZGUuXG4gICAgICAgICAgY29uc3QgbmV3Tm9kZSA9IHRoaXMuY2xvbmVGdW5jdGlvbkxpYnJhcnlNZXRhbm9kZUhlbHBlcihcbiAgICAgICAgICAgICAgbWV0YWdyYXBoLFxuICAgICAgICAgICAgICBvcE5vZGVUb1JlcGxhY2UsXG4gICAgICAgICAgICAgIG5vZGUgYXMgTWV0YW5vZGUsXG4gICAgICAgICAgICAgIG9sZFByZWZpeCxcbiAgICAgICAgICAgICAgbmV3UHJlZml4LFxuICAgICAgICAgICAgICBmdW5jdGlvbk91dHB1dEluZGV4VG9Ob2RlKTtcblxuICAgICAgICAgIC8vIEFkZCB0aGUgbmV3IG5vZGUgdG8gdGhlIGdyYXBoLlxuICAgICAgICAgIG5ld05vZGUucGFyZW50Tm9kZSA9IG5ld01ldGFub2RlO1xuICAgICAgICAgIG5ld01ldGFub2RlLm1ldGFncmFwaC5zZXROb2RlKG5ld05vZGUubmFtZSwgbmV3Tm9kZSk7XG4gICAgICAgICAgdGhpcy5oaWVyYXJjaHkuc2V0Tm9kZShuZXdOb2RlLm5hbWUsIG5ld05vZGUpO1xuICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlIE5vZGVUeXBlLk9QOlxuICAgICAgICAgIC8vIER1cGxpY2F0ZSB0aGUgb3Agbm9kZS5cbiAgICAgICAgICBjb25zdCBuZXdPcE5vZGUgPSB0aGlzLmNsb25lQW5kQWRkRnVuY3Rpb25PcE5vZGUoXG4gICAgICAgICAgICAgIG5ld01ldGFub2RlLCBvbGRQcmVmaXgsIG5vZGUgYXMgT3BOb2RlLCBuZXdQcmVmaXgpO1xuICAgICAgICAgIGlmIChfLmlzTnVtYmVyKG5ld09wTm9kZS5mdW5jdGlvbklucHV0SW5kZXgpKSB7XG4gICAgICAgICAgICAvLyBUaGlzIG5vZGUgcmVwcmVzZW50cyBhbiBpbnB1dF9hcmcgb2YgdGhlIGxpYnJhcnkgZnVuY3Rpb24uIEdpdmVcbiAgICAgICAgICAgIC8vIGl0IGVkZ2VzIHNvIHRoYXQgaXRzIGJyaWRnZSBlZGdlcyBhcmUgY3JlYXRlZCBjb3JyZWN0bHkuXG4gICAgICAgICAgICB0aGlzLnBhdGNoRWRnZXNJbnRvRnVuY3Rpb25JbnB1dHMob3BOb2RlVG9SZXBsYWNlLCBuZXdPcE5vZGUpO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIGlmIChfLmlzTnVtYmVyKG5ld09wTm9kZS5mdW5jdGlvbk91dHB1dEluZGV4KSkge1xuICAgICAgICAgICAgZnVuY3Rpb25PdXRwdXRJbmRleFRvTm9kZVtuZXdPcE5vZGUuZnVuY3Rpb25PdXRwdXRJbmRleF0gPVxuICAgICAgICAgICAgICAgIG5ld09wTm9kZTtcbiAgICAgICAgICB9XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgLy8gVGhpcyBsb2dpYyBzaG91bGQgbmV2ZXIgcnVuIGJlY2F1c2UgdGhlIG1ldGEgZ3JhcGggc2hvdWxkIG9ubHlcbiAgICAgICAgICAvLyBjb250YWluIG1ldGEgYW5kIG9wIG5vZGVzLlxuICAgICAgICAgIGNvbnNvbGUud2FybihcbiAgICAgICAgICAgICAgbm9kZS5uYW1lICsgJyBpcyBvZGRseSBuZWl0aGVyIGEgbWV0YW5vZGUgbm9yIGFuIG9wbm9kZS4nKTtcbiAgICAgIH1cbiAgICB9KTtcblxuICAgIC8vIENsb25lIHRoZSBlZGdlcyB3aXRoaW4gdGhlIGZ1bmN0aW9uIGxpYnJhcnkgbWV0YW5vZGUuXG4gICAgdGhpcy5jbG9uZUxpYnJhcnlNZXRhbm9kZUVkZ2VzKFxuICAgICAgICBsaWJyYXJ5TWV0YW5vZGUsIG5ld01ldGFub2RlLCBvbGRQcmVmaXgsIG5ld1ByZWZpeCk7XG5cbiAgICByZXR1cm4gbmV3TWV0YW5vZGU7XG4gIH1cblxuICAvKipcbiAgICogQ2xvbmVzIHRoZSBlZGdlcyB3aXRoaW4gYGxpYnJhcnlNZXRhbm9kZWAgYW5kIGFkZHMgdGhlbSB0byBgbmV3TWV0YW5vZGVgLlxuICAgKiBUaGUgbmFtZXMgb2YgZWRnZSBzb3VyY2VzIGFuZCBkZXN0aW5hdGlvbnMgaGF2ZSB0aGVpciBwcmVmaXhlcyByZXBsYWNlZFxuICAgKiB3aXRoIG5ldyBwcmVmaXhlcyB0aGF0IHJlZmxlY3QgdGhlaXIgaGllcmFyY2hpY2FsIHBvc2l0aW9ucyBpbiB0aGUgZ3JhcGhcbiAgICogaW5zdGVhZCBvZiB3aXRoaW4gdGhlIGZ1bmN0aW9uIGxpYnJhcnkgdGVtcGxhdGUuIFRoaXMgaXMgYSBzdWJyb3V0aW5lIGZvclxuICAgKiBkeW5hbWljYWxseSBpbmplY3RpbmcgYSBmdW5jdGlvbiBtZXRhbm9kZSBpbnRvIHRoZSBncmFwaC5cbiAgICovXG4gIHByaXZhdGUgY2xvbmVMaWJyYXJ5TWV0YW5vZGVFZGdlcyhcbiAgICAgIGxpYnJhcnlNZXRhbm9kZTogTWV0YW5vZGUsXG4gICAgICBuZXdNZXRhbm9kZTogTWV0YW5vZGUsXG4gICAgICBvbGRQcmVmaXg6IHN0cmluZyxcbiAgICAgIG5ld1ByZWZpeDogc3RyaW5nKSB7XG4gICAgXy5lYWNoKGxpYnJhcnlNZXRhbm9kZS5tZXRhZ3JhcGguZWRnZXMoKSxcbiAgICAgICAgKGVkZ2VPYmplY3Q6IGdyYXBobGliLkVkZ2VPYmplY3QpID0+IHtcbiAgICAgIGNvbnN0IGVkZ2UgPSBsaWJyYXJ5TWV0YW5vZGUubWV0YWdyYXBoLmVkZ2UoZWRnZU9iamVjdCk7XG4gICAgICBjb25zdCBuZXdWID0gZWRnZS52LnJlcGxhY2Uob2xkUHJlZml4LCBuZXdQcmVmaXgpO1xuICAgICAgY29uc3QgbmV3VyA9IGVkZ2Uudy5yZXBsYWNlKG9sZFByZWZpeCwgbmV3UHJlZml4KTtcblxuICAgICAgY29uc3QgbmV3TWV0YUVkZ2UgPSBuZXcgTWV0YWVkZ2VJbXBsKG5ld1YsIG5ld1cpO1xuXG4gICAgICAvLyBEdXBsaWNhdGUgdmFyaW91cyBwcm9wZXJ0aWVzLlxuICAgICAgbmV3TWV0YUVkZ2UuaW5ib3VuZCA9IGVkZ2UuaW5ib3VuZDtcbiAgICAgIG5ld01ldGFFZGdlLm51bVJlZ3VsYXJFZGdlcyA9IGVkZ2UubnVtUmVndWxhckVkZ2VzO1xuICAgICAgbmV3TWV0YUVkZ2UubnVtQ29udHJvbEVkZ2VzID0gZWRnZS5udW1Db250cm9sRWRnZXM7XG4gICAgICBuZXdNZXRhRWRnZS5udW1SZWZFZGdlcyA9IGVkZ2UubnVtUmVmRWRnZXM7XG4gICAgICBuZXdNZXRhRWRnZS50b3RhbFNpemUgPSBlZGdlLnRvdGFsU2l6ZTtcbiAgICAgIGlmIChlZGdlLmJhc2VFZGdlTGlzdCkge1xuICAgICAgICBuZXdNZXRhRWRnZS5iYXNlRWRnZUxpc3QgPSBlZGdlLmJhc2VFZGdlTGlzdC5tYXAoYmFzZUVkZ2UgPT4ge1xuICAgICAgICAgIGNvbnN0IG5ld0Jhc2VFZGdlID0gXy5jbG9uZShiYXNlRWRnZSk7XG4gICAgICAgICAgbmV3QmFzZUVkZ2UudiA9IGJhc2VFZGdlLnYucmVwbGFjZShvbGRQcmVmaXgsIG5ld1ByZWZpeCk7XG4gICAgICAgICAgbmV3QmFzZUVkZ2UudyA9IGJhc2VFZGdlLncucmVwbGFjZShvbGRQcmVmaXgsIG5ld1ByZWZpeCk7XG4gICAgICAgICAgcmV0dXJuIG5ld0Jhc2VFZGdlO1xuICAgICAgICB9KTtcbiAgICAgIH1cblxuICAgICAgLy8gU2V0IHRoZSBkaXJlY3Rpb24gb2YgdGhlIGVkZ2UgYmFzZWQgb24gd2hldGhlciBpdCBpcyBpbmJvdW5kLiBUaGUgZWRnZVxuICAgICAgLy8gaXMgaW5ib3VuZCBpZiBpdHMgZGVzdGluYXRpb24gaXMgd2l0aGluIHRoZSBtZXRhZ3JhcGguXG4gICAgICBpZiAobmV3TWV0YW5vZGUubWV0YWdyYXBoLm5vZGUobmV3VykpIHtcbiAgICAgICAgbmV3TWV0YW5vZGUubWV0YWdyYXBoLnNldEVkZ2UobmV3ViwgbmV3VywgbmV3TWV0YUVkZ2UpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgbmV3TWV0YW5vZGUubWV0YWdyYXBoLnNldEVkZ2UobmV3VywgbmV3ViwgbmV3TWV0YUVkZ2UpO1xuICAgICAgfVxuICAgIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIFdoZW4gYSBtZXRhbm9kZSByZXByZXNlbnRpbmcgYSBmdW5jdGlvbiBpcyBjbG9uZWQgYW5kIHBsYWNlZCBpbnRvIHRoZVxuICAgKiBncmFwaCwgd2UgbXVzdCBjcmVhdGUgZWRnZXMgYmV0d2VlbiBpbnB1dHMgaW50byB0aGUgZnVuY3Rpb24gY2FsbCBhbmQgdGhlXG4gICAqIGlucHV0IG9wcyB3aXRoaW4gdGhlIGZ1bmN0aW9uLiBUaGlzIGZ1bmN0aW9uIHBlcmZvcm1zIHRoYXQgcGF0Y2hpbmcuXG4gICAqL1xuICBwcml2YXRlIHBhdGNoRWRnZXNJbnRvRnVuY3Rpb25JbnB1dHMoXG4gICAgICBvcE5vZGVUb1JlcGxhY2U6IE9wTm9kZSwgbmV3T3BOb2RlOiBPcE5vZGUpIHtcbiAgICAvLyBJZiB0aGUgbGFzdCBmZXcgcmF3IGlucHV0cyBhcmUgdGhlIHNhbWUgbm9kZSwgcHJldmlvdXMgZ3JhcGggbG9naWNcbiAgICAvLyBjb2xsYXBzZXMgdGhlbSBpbnRvIGEgc2luZ2xlIG5vcm1hbGl6ZWQgaW5wdXQuXG4gICAgbGV0IGlucHV0SW5kZXggPSBNYXRoLm1pbihcbiAgICAgICAgbmV3T3BOb2RlLmZ1bmN0aW9uSW5wdXRJbmRleCxcbiAgICAgICAgb3BOb2RlVG9SZXBsYWNlLmlucHV0cy5sZW5ndGggLSAxKTtcbiAgICBsZXQgbmV3SW5wdXQgPSBfLmNsb25lKG9wTm9kZVRvUmVwbGFjZS5pbnB1dHNbaW5wdXRJbmRleF0pO1xuICAgIHdoaWxlIChuZXdJbnB1dC5pc0NvbnRyb2xEZXBlbmRlbmN5KSB7XG4gICAgICAvLyBJZ25vcmUgY29udHJvbCBkZXBlbmRlbmNpZXMgLSB0aGV5IGFyZSBub3QgYXNzaWduZWQgdG9cbiAgICAgIC8vIGlucHV0X2FyZ3MuXG4gICAgICBpbnB1dEluZGV4Kys7XG4gICAgICBuZXdJbnB1dCA9IG9wTm9kZVRvUmVwbGFjZS5pbnB1dHNbaW5wdXRJbmRleF07XG4gICAgfVxuICAgIC8vIENsb25lIHRoZSBub3JtYWxpemVkIGlucHV0IG9iamVjdC5cbiAgICBuZXdPcE5vZGUuaW5wdXRzLnB1c2gobmV3SW5wdXQpO1xuXG4gICAgLy8gVXBkYXRlIHZhbHVlcyBpbiB0aGUgY29ycmVzcG9uZGluZyBlZGdlIGluIHRoZSBoaWdoLWxldmVsXG4gICAgLy8gbWV0YWdyYXBoLlxuICAgIGNvbnN0IG9yaWdpbmFsTWV0YUVkZ2VzID0gdGhpcy5oaWVyYXJjaHkuZ2V0UHJlZGVjZXNzb3JzKFxuICAgICAgICBvcE5vZGVUb1JlcGxhY2UubmFtZSk7XG5cbiAgICAvLyBGaW5kIHRoZSBtZXRhZWRnZSB0aGF0IHRoZSBpbnB1dCBpbmRleCBjb3JyZXNwb25kcyB0by5cbiAgICAvLyBBIG1ldGFlZGdlIG1heSBjb3JyZXNwb25kIHRvIHNldmVyYWwgZWRnZXMuIEZvciBpbnN0YW5jZSxcbiAgICAvLyBhbiBlZGdlIG1heSBlbnRlciBhIHNlcmllcyBub2RlLlxuICAgIGxldCBvcmlnaW5hbE1ldGFFZGdlOiBNZXRhZWRnZTtcbiAgICBsZXQgcmVndWxhckVkZ2VDb3VudCA9IDA7XG4gICAgXy5lYWNoKG9yaWdpbmFsTWV0YUVkZ2VzLnJlZ3VsYXIsIG1ldGFFZGdlID0+IHtcbiAgICAgIHJlZ3VsYXJFZGdlQ291bnQgKz0gbWV0YUVkZ2UubnVtUmVndWxhckVkZ2VzO1xuICAgICAgaWYgKHJlZ3VsYXJFZGdlQ291bnQgPiBpbnB1dEluZGV4KSB7XG4gICAgICAgIG9yaWdpbmFsTWV0YUVkZ2UgPSBtZXRhRWRnZTtcbiAgICAgICAgLy8gVGVybWluYXRlIHRoZSBsb29wLlxuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9XG4gICAgfSk7XG5cbiAgICAvLyBBbHNvIGNoYW5nZSBhbnkgYmFzZSBlZGdlcyB0aGF0IHBvaW50IGludG8gdGhlIG9yaWdpbmFsIG5vZGUgdG9cbiAgICAvLyBwb2ludCB0byB0aGUgaW5wdXQgYXJnIHdpdGhpbiB0aGUgZnVuY3Rpb24uIFRoZXNlIGFyZSB1c2VkIHRvXG4gICAgLy8gbWFrZSBicmlkZ2UgZWRnZXMuXG4gICAgXy5lYWNoKG9yaWdpbmFsTWV0YUVkZ2UuYmFzZUVkZ2VMaXN0LCBlZGdlID0+IHtcbiAgICAgIGlmIChlZGdlLncgPT09IG9wTm9kZVRvUmVwbGFjZS5uYW1lKSB7XG4gICAgICAgIGVkZ2UudyA9IG5ld09wTm9kZS5uYW1lO1xuICAgICAgfVxuICAgICAgaWYgKGVkZ2UudiA9PT0gb3BOb2RlVG9SZXBsYWNlLm5hbWUpIHtcbiAgICAgICAgZWRnZS52ID0gbmV3T3BOb2RlLm5hbWU7XG4gICAgICB9XG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogV2hlbiBhIG1ldGFub2RlIHJlcHJlc2VudGluZyBhIGZ1bmN0aW9uIGlzIGNsb25lZCBhbmQgcGxhY2VkIGludG8gdGhlXG4gICAqIGdyYXBoLCB3ZSBtdXN0IGNyZWF0ZSBlZGdlcyBiZXR3ZWVuIG91dHB1dCBvcHMgd2l0aGluIHRoZSBuZXcgZnVuY3Rpb25cbiAgICogbWV0YW5vZGUgdG8gaXRzIHN1Y2Nlc3NvcnMuIFRoaXMgZnVuY3Rpb24gZG9lcyB0aGF0IGFmdGVyIHNjYW5uaW5nIHRoZVxuICAgKiBzdWNjZXNzb3JzIG9mIHRoZSBmdW5jdGlvbiBjYWxsLlxuICAgKi9cbiAgcHJpdmF0ZSBwYXRjaEVkZ2VzRnJvbUZ1bmN0aW9uT3V0cHV0cyhcbiAgICAgIG9wTm9kZVRvUmVwbGFjZTogT3BOb2RlLFxuICAgICAgZnVuY3Rpb25PdXRwdXRJbmRleFRvRGVzdGluYXRpb25Ob2RlOiB7W2tleTogc3RyaW5nXTogTm9kZX0pIHtcbiAgICAvLyBDb25uZWN0IHRoZSBvdXRwdXRzIG9mIHRoZSBmdW5jdGlvbiB0byBvdGhlciBvcHMuXG4gICAgY29uc3Qgb3JpZ2luYWxNZXRhRWRnZXMgPSB0aGlzLmhpZXJhcmNoeS5nZXRTdWNjZXNzb3JzKFxuICAgICAgICBvcE5vZGVUb1JlcGxhY2UubmFtZSk7XG4gICAgXy5lYWNoKG9yaWdpbmFsTWV0YUVkZ2VzLnJlZ3VsYXIsIChtZXRhZWRnZSkgPT4ge1xuICAgICAgXy5lYWNoKG1ldGFlZGdlLmJhc2VFZGdlTGlzdCwgYmFzZUVkZ2UgPT4ge1xuICAgICAgICAvLyBEZXN0aW5hdGlvbiBub2RlcyB3aXRoaW4gcmVndWxhciBiYXNlIGVkZ2VzIGFyZSBvcCBub2Rlcy5cbiAgICAgICAgY29uc3QgZGVzdGluYXRpb25Ob2RlID0gdGhpcy5oaWVyYXJjaHkubm9kZShiYXNlRWRnZS53KSBhcyBPcE5vZGU7XG4gICAgICAgIF8uZWFjaChkZXN0aW5hdGlvbk5vZGUuaW5wdXRzLCBub3JtYWxpemVkSW5wdXQgPT4ge1xuICAgICAgICAgIC8vIElmIGFuIG91dHB1dCBvZiB0aGUgZnVuY3Rpb24gaXMgYW4gaW5wdXQgaW50byB0aGUgb3AsIG1hcCBpdCBiYWNrXG4gICAgICAgICAgLy8gdG8gdGhlIG91dHB1dCB3aXRoaW4gdGhlIGZ1bmN0aW9uIHNvIGJyaWRnZSBlZGdlcyBhcmUgY29tcHV0ZWQuXG4gICAgICAgICAgaWYgKG5vcm1hbGl6ZWRJbnB1dC5uYW1lID09PSBvcE5vZGVUb1JlcGxhY2UubmFtZSkge1xuICAgICAgICAgICAgLy8gTWFwIHRoZSBvdXRwdXQgdGVuc29yIGluZGV4ICh3aGljaCBpbiB0aGlzIGNhc2UgaXMgZm9yIHN1cmVcbiAgICAgICAgICAgIC8vIG51bWVyaWMgYmVjYXVzZSBpdCBpcyBhbiBvdXRwdXQgb2YgYSBtZXRhbm9kZSkgdG8gdGhlIGNvcnJlY3RcbiAgICAgICAgICAgIC8vIGZ1bmN0aW9uIG91dHB1dC5cbiAgICAgICAgICAgIGNvbnN0IG91dHB1dE5vZGUgPSBmdW5jdGlvbk91dHB1dEluZGV4VG9EZXN0aW5hdGlvbk5vZGVbXG4gICAgICAgICAgICAgICAgbm9ybWFsaXplZElucHV0Lm91dHB1dFRlbnNvcktleV07XG4gICAgICAgICAgICBub3JtYWxpemVkSW5wdXQubmFtZSA9IG91dHB1dE5vZGUubmFtZTtcbiAgICAgICAgICAgIG5vcm1hbGl6ZWRJbnB1dC5vdXRwdXRUZW5zb3JLZXkgPSBiYXNlRWRnZS5vdXRwdXRUZW5zb3JLZXk7XG4gICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgIH0pO1xuXG4gICAgICAvLyBNb2RpZnkgdGhlIGxpc3Qgb2YgYmFzZSBlZGdlcyB0byBwb2ludCBmcm9tIHRoZSBvdXRwdXQgc28gdGhhdCBicmlkZ2VcbiAgICAgIC8vIGVkZ2VzIGFyZSBjb3JyZWN0LlxuICAgICAgXy5lYWNoKG1ldGFlZGdlLmJhc2VFZGdlTGlzdCwgKGJhc2VFZGdlKSA9PiB7XG4gICAgICAgIGJhc2VFZGdlLnYgPVxuICAgICAgICAgICAgZnVuY3Rpb25PdXRwdXRJbmRleFRvRGVzdGluYXRpb25Ob2RlW2Jhc2VFZGdlLm91dHB1dFRlbnNvcktleV0ubmFtZTtcbiAgICAgICAgYmFzZUVkZ2Uub3V0cHV0VGVuc29yS2V5ID0gJzAnO1xuICAgICAgfSk7XG4gICAgfSk7XG4gIH1cblxuICBidWlsZFN1YmhpZXJhcmNoeShub2RlTmFtZTogc3RyaW5nKTogdm9pZCB7XG4gICAgLy8gVGVybWluYXRlIGlmIHRoZSByZW5kZXJpbmcgaGllcmFyY2h5IHdhcyBhbHJlYWR5IGNvbnN0cnVjdGVkXG4gICAgLy8gZm9yIHRoaXMgbm9kZS5cbiAgICBpZiAobm9kZU5hbWUgaW4gdGhpcy5oYXNTdWJoaWVyYXJjaHkpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICAvLyBSZWNvcmQgdGhhdCB3ZSBjb25zdHJ1Y3RlZCB0aGUgcmVuZGVyaW5nIGhpZXJhcmNoeSBmb3IgdGhpcyBub2RlLCBzbyB3ZVxuICAgIC8vIGRvbid0IGNvbnN0cnVjdCBpdCBhbm90aGVyIHRpbWUuXG4gICAgdGhpcy5oYXNTdWJoaWVyYXJjaHlbbm9kZU5hbWVdID0gdHJ1ZTtcblxuICAgIGxldCByZW5kZXJOb2RlSW5mbyA9IHRoaXMuaW5kZXhbbm9kZU5hbWVdO1xuXG4gICAgLy8gSWYgaXQgaXMgbm90IGEgbWV0YSBub2RlIG9yIGEgc2VyaWVzIG5vZGUsIGRvbid0IGRvIGFueXRoaW5nLlxuICAgIGlmIChyZW5kZXJOb2RlSW5mby5ub2RlLnR5cGUgIT09IE5vZGVUeXBlLk1FVEEgJiZcbiAgICAgICAgcmVuZGVyTm9kZUluZm8ubm9kZS50eXBlICE9PSBOb2RlVHlwZS5TRVJJRVMpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICAvLyBBdCB0aGlzIHBvaW50IHdlIGtub3cgdGhlIHJlbmRlcmluZyBpbmZvcm1hdGlvbiBpcyBhYm91dCBhIGdyb3VwIG5vZGUuXG4gICAgbGV0IHJlbmRlckdyb3VwTm9kZUluZm8gPSA8UmVuZGVyR3JvdXBOb2RlSW5mbz4gcmVuZGVyTm9kZUluZm87XG4gICAgbGV0IG1ldGFncmFwaCA9IHJlbmRlckdyb3VwTm9kZUluZm8ubm9kZS5tZXRhZ3JhcGg7XG4gICAgbGV0IGNvcmVHcmFwaCA9IHJlbmRlckdyb3VwTm9kZUluZm8uY29yZUdyYXBoO1xuXG4gICAgY29uc3Qgbm9kZXNUaGF0R290Q2xvbmVkID0gW107XG4gICAgY29uc3QgZnVuY3Rpb25DYWxsTWV0YW5vZGVzVG9BZGQgPSBbXTtcbiAgICBpZiAoIV8uaXNFbXB0eSh0aGlzLmhpZXJhcmNoeS5saWJyYXJ5RnVuY3Rpb25zKSkge1xuICAgICAgLy8gVGhpcyBncmFwaCBoYXMgbGlicmFyeSBmdW5jdGlvbnMuIEFkZCB0aGVtIHRvIHRoZSBjdXJyZW50XG4gICAgICAvLyBzdWItaGllcmFyY2h5IGlmIG5lY2Vzc2FyeS5cbiAgICAgIF8uZWFjaChtZXRhZ3JhcGgubm9kZXMoKSwgY2hpbGROYW1lID0+IHtcbiAgICAgICAgLy8gV2h5IGlzIHRoaXMgc28gb2Z0ZW4gdW5kZWZpbmVkP1xuICAgICAgICBjb25zdCBvcmlnaW5hbE5vZGUgPSBtZXRhZ3JhcGgubm9kZShjaGlsZE5hbWUpIGFzIE9wTm9kZTtcbiAgICAgICAgY29uc3QgbGlicmFyeUZ1bmN0aW9uRGF0YSA9XG4gICAgICAgICAgICB0aGlzLmhpZXJhcmNoeS5saWJyYXJ5RnVuY3Rpb25zW29yaWdpbmFsTm9kZS5vcF07XG4gICAgICAgIGlmICghbGlicmFyeUZ1bmN0aW9uRGF0YSkge1xuICAgICAgICAgIC8vIFRoaXMgbm9kZSBpcyBub3QgYSBmdW5jdGlvbiBjYWxsLlxuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChjaGlsZE5hbWUuaW5kZXhPZih0Zi5ncmFwaC5GVU5DVElPTl9MSUJSQVJZX05PREVfUFJFRklYKSA9PT0gMCkge1xuICAgICAgICAgIC8vIERvIG5vdCByZXBsYWNlIGxpYnJhcnkgZnVuY3Rpb25zIGluIHRoZSBncmFwaC4gVGhlIGxpYnJhcnlcbiAgICAgICAgICAvLyBmdW5jdGlvbnMgc2VydmUgYXMgdGVtcGxhdGVzIGZvciBvdGhlciBub2Rlcy5cbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICAvLyBXZSBsYXRlciByZXBsYWNlIHRoZSBub2RlIHRoYXQgaXMgYSBmdW5jdGlvbiBjYWxsIHdpdGggYSBjb3B5IG9mIHRoZVxuICAgICAgICAvLyBmdW5jdGlvbiBtZXRhZ3JhcGguIFdlIGRvIG5vdCBkbyBzbyBub3cgYmVjYXVzZSB3ZSBhcmUgYWxzbyBsb29waW5nXG4gICAgICAgIC8vIHRocm91Z2ggYWxsIHRoZSBub2Rlcy5cbiAgICAgICAgY29uc3QgY2xvbmVkTWV0YW5vZGUgPSB0aGlzLmNsb25lRnVuY3Rpb25MaWJyYXJ5TWV0YW5vZGUoXG4gICAgICAgICAgICBtZXRhZ3JhcGgsXG4gICAgICAgICAgICBvcmlnaW5hbE5vZGUsXG4gICAgICAgICAgICBsaWJyYXJ5RnVuY3Rpb25EYXRhLm5vZGUsXG4gICAgICAgICAgICBsaWJyYXJ5RnVuY3Rpb25EYXRhLm5vZGUubmFtZSxcbiAgICAgICAgICAgIG9yaWdpbmFsTm9kZS5uYW1lKTtcbiAgICAgICAgbm9kZXNUaGF0R290Q2xvbmVkLnB1c2gob3JpZ2luYWxOb2RlKTtcbiAgICAgICAgZnVuY3Rpb25DYWxsTWV0YW5vZGVzVG9BZGQucHVzaChjbG9uZWRNZXRhbm9kZSk7XG4gICAgICB9KTtcblxuICAgICAgLy8gUGVyZm9ybSBub2RlIHJlcGxhY2VtZW50LlxuICAgICAgXy5lYWNoKGZ1bmN0aW9uQ2FsbE1ldGFub2Rlc1RvQWRkLCAoY2xvbmVkTWV0YW5vZGUsIGkpID0+IHtcbiAgICAgICAgY29uc3Qgb3JpZ2luYWxOb2RlID0gbm9kZXNUaGF0R290Q2xvbmVkW2ldO1xuICAgICAgICBjbG9uZWRNZXRhbm9kZS5wYXJlbnROb2RlID0gb3JpZ2luYWxOb2RlLnBhcmVudE5vZGU7XG4gICAgICAgIG1ldGFncmFwaC5zZXROb2RlKG9yaWdpbmFsTm9kZS5uYW1lLCBjbG9uZWRNZXRhbm9kZSk7XG4gICAgICAgIHRoaXMuaGllcmFyY2h5LnNldE5vZGUob3JpZ2luYWxOb2RlLm5hbWUsIGNsb25lZE1ldGFub2RlKTtcbiAgICAgIH0pO1xuICAgIH1cblxuICAgIC8vIENyZWF0ZSByZW5kZXIgbm9kZXMgdG8gcmVwcmVzZW50IGVhY2ggY2hpbGQgZnJvbSB0aGUgbWV0YWdyYXBoLiBBbHRob3VnaFxuICAgIC8vIHRoZXNlIHdpbGwgaW5pdGlhbGx5IGJlIGFkZGVkIHRvIHRoZSBjb3JlR3JhcGgsIHRoZXkgbWF5IGxhdGVyIGJlXG4gICAgLy8gZXh0cmFjdGVkLiBBbHNvLCBkdWUgdG8gZXh0cmFjdGlvbiwgdGhlIGNvcmVHcmFwaCBtYXkgY29udGFpbiBkaXNqb2ludFxuICAgIC8vIGdyb3VwcyBiZXR3ZWVuIHdoaWNoIHRoZXJlIGlzIG5vIHZpc2libGUgcGF0aCAob3RoZXIgdGhhbiBhbm5vdGF0aW9ucykuXG4gICAgXy5lYWNoKG1ldGFncmFwaC5ub2RlcygpLCBjaGlsZE5hbWUgPT4ge1xuXG4gICAgICBsZXQgY2hpbGRSZW5kZXJJbmZvID0gdGhpcy5nZXRPckNyZWF0ZVJlbmRlck5vZGVCeU5hbWUoY2hpbGROYW1lKTtcbiAgICAgIGxldCBjaGlsZE5vZGUgPSBjaGlsZFJlbmRlckluZm8ubm9kZTtcblxuICAgICAgY29yZUdyYXBoLnNldE5vZGUoY2hpbGROYW1lLCBjaGlsZFJlbmRlckluZm8pO1xuXG4gICAgICBpZiAoIWNoaWxkTm9kZS5pc0dyb3VwTm9kZSkge1xuICAgICAgICBfLmVhY2goKDxPcE5vZGU+Y2hpbGROb2RlKS5pbkVtYmVkZGluZ3MsIGVtYmVkZGluZyA9PiB7XG4gICAgICAgICAgbGV0IHJlbmRlck1ldGFlZGdlSW5mbyA9IG5ldyBSZW5kZXJNZXRhZWRnZUluZm8obnVsbCk7XG4gICAgICAgICAgbGV0IHJlbmRlck5vZGVJbmZvID0gbmV3IFJlbmRlck5vZGVJbmZvKGVtYmVkZGluZyk7XG4gICAgICAgICAgYWRkSW5Bbm5vdGF0aW9uKGNoaWxkUmVuZGVySW5mbywgZW1iZWRkaW5nLCByZW5kZXJOb2RlSW5mbywgcmVuZGVyTWV0YWVkZ2VJbmZvLFxuICAgICAgICAgICAgICBBbm5vdGF0aW9uVHlwZS5DT05TVEFOVCk7XG4gICAgICAgICAgdGhpcy5pbmRleFtlbWJlZGRpbmcubmFtZV0gPSByZW5kZXJOb2RlSW5mbztcbiAgICAgICAgfSk7XG4gICAgICAgIF8uZWFjaCgoPE9wTm9kZT5jaGlsZE5vZGUpLm91dEVtYmVkZGluZ3MsIGVtYmVkZGluZyA9PiB7XG4gICAgICAgICAgbGV0IHJlbmRlck1ldGFlZGdlSW5mbyA9IG5ldyBSZW5kZXJNZXRhZWRnZUluZm8obnVsbCk7XG4gICAgICAgICAgbGV0IHJlbmRlck5vZGVJbmZvID0gbmV3IFJlbmRlck5vZGVJbmZvKGVtYmVkZGluZyk7XG4gICAgICAgICAgYWRkT3V0QW5ub3RhdGlvbihjaGlsZFJlbmRlckluZm8sIGVtYmVkZGluZywgcmVuZGVyTm9kZUluZm8sIHJlbmRlck1ldGFlZGdlSW5mbyxcbiAgICAgICAgICAgICAgQW5ub3RhdGlvblR5cGUuU1VNTUFSWSk7XG4gICAgICAgICAgdGhpcy5pbmRleFtlbWJlZGRpbmcubmFtZV0gPSByZW5kZXJOb2RlSW5mbztcbiAgICAgICAgfSk7XG4gICAgICB9XG5cbiAgICB9KTtcblxuICAgIC8vIEFkZCByZW5kZXIgbWV0YWVkZ2UgaW5mbyBmb3IgZWRnZXMgaW4gdGhlIG1ldGFncmFwaC5cbiAgICBfLmVhY2gobWV0YWdyYXBoLmVkZ2VzKCksIGVkZ2VPYmogPT4ge1xuICAgICAgbGV0IG1ldGFlZGdlID0gbWV0YWdyYXBoLmVkZ2UoZWRnZU9iaik7XG4gICAgICBsZXQgcmVuZGVyTWV0YWVkZ2VJbmZvID0gbmV3IFJlbmRlck1ldGFlZGdlSW5mbyhtZXRhZWRnZSk7XG4gICAgICByZW5kZXJNZXRhZWRnZUluZm8uaXNGYWRlZE91dCA9XG4gICAgICAgICAgdGhpcy5pbmRleFtlZGdlT2JqLnZdLmlzRmFkZWRPdXQgfHwgdGhpcy5pbmRleFtlZGdlT2JqLnddLmlzRmFkZWRPdXQ7XG4gICAgICBjb3JlR3JhcGguc2V0RWRnZShlZGdlT2JqLnYsIGVkZ2VPYmoudywgcmVuZGVyTWV0YWVkZ2VJbmZvKTtcbiAgICB9KTtcblxuICAgIGlmIChQQVJBTVMuZW5hYmxlRXh0cmFjdGlvbiAmJlxuICAgICAgICByZW5kZXJHcm91cE5vZGVJbmZvLm5vZGUudHlwZSA9PT0gTm9kZVR5cGUuTUVUQSkge1xuICAgICAgZXh0cmFjdEhpZ2hEZWdyZWVzKHJlbmRlckdyb3VwTm9kZUluZm8pO1xuICAgIH1cblxuICAgIC8vIElmIHRoZXJlIGFyZSBmdW5jdGlvbnMsIGl0IGlzIHBvc3NpYmxlIGZvciBtZXRhbm9kZXMgdG8gYmUgZHluYW1pY2FsbHlcbiAgICAvLyBhZGRlZCBsYXRlci4gQ29uc3RydWN0IHRoZSBoaWVyYXJjaGllcyBmb3Igbm9kZXMgdGhhdCBhcmUgcHJlZGVjZXNzb3JzIHRvXG4gICAgLy8gbm9kZXMgaW4gdGhlIGN1cnJlbnQgaGllcmFyY2h5IHNvIHRoYXQgZWRnZXMgYXJlIGRyYXduIGNvcnJlY3RseS5cbiAgICBpZiAoIV8uaXNFbXB0eSh0aGlzLmhpZXJhcmNoeS5saWJyYXJ5RnVuY3Rpb25zKSkge1xuICAgICAgdGhpcy5idWlsZFN1YmhpZXJhcmNoaWVzRm9yTmVlZGVkRnVuY3Rpb25zKG1ldGFncmFwaCk7XG4gICAgfVxuXG4gICAgaWYgKG5vZGVOYW1lID09PSB0Zi5ncmFwaC5ST09UX05BTUUpIHtcbiAgICAgIC8vIEFkZCBhbGwgbWV0YW5vZGVzIHJlcHJlc2VudGluZyBsaWJyYXJ5IGZ1bmN0aW9uIHRlbXBsYXRlcyBpbnRvIHRoZVxuICAgICAgLy8gbGlicmFyeSBmdW5jdGlvbiBzY2VuZSBncm91cCBmb3IgdGhlIHJvb3Qgbm9kZS5cbiAgICAgIF8uZm9yT3duKFxuICAgICAgICAgIHRoaXMuaGllcmFyY2h5LmxpYnJhcnlGdW5jdGlvbnMsXG4gICAgICAgICAgKGxpYnJhcnlGdW5jdGlvbkRhdGEsIGZ1bmN0aW9uTmFtZSkgPT4ge1xuICAgICAgICBjb25zdCBub2RlID0gbGlicmFyeUZ1bmN0aW9uRGF0YS5ub2RlO1xuICAgICAgICBjb25zdCBjaGlsZFJlbmRlckluZm8gPSB0aGlzLmdldE9yQ3JlYXRlUmVuZGVyTm9kZUJ5TmFtZShub2RlLm5hbWUpO1xuICAgICAgICByZW5kZXJHcm91cE5vZGVJbmZvLmxpYnJhcnlGdW5jdGlvbnNFeHRyYWN0LnB1c2goY2hpbGRSZW5kZXJJbmZvKTtcblxuICAgICAgICAvLyBEbyBub3QgcmVuZGVyIGZ1bmN0aW9uIGRlZmluaXRpb25zIGluIHRoZSBjb3JlIGdyYXBoLlxuICAgICAgICBjaGlsZFJlbmRlckluZm8ubm9kZS5pbmNsdWRlID0gSW5jbHVzaW9uVHlwZS5FWENMVURFO1xuICAgICAgICBjb3JlR3JhcGgucmVtb3ZlTm9kZShub2RlLm5hbWUpO1xuICAgICAgfSk7XG4gICAgfVxuXG4gICAgLy8gTG9vayB1cCB0aGUgcGFyZW50IG5vZGUncyByZW5kZXIgaW5mb3JtYXRpb24gYW5kIHNob3J0IGNpcmN1aXQgaWYgbm9uZS5cbiAgICBsZXQgcGFyZW50Tm9kZSA9IHJlbmRlckdyb3VwTm9kZUluZm8ubm9kZS5wYXJlbnROb2RlO1xuICAgIGlmICghcGFyZW50Tm9kZSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBsZXQgcGFyZW50Tm9kZUluZm8gPVxuICAgICAgPFJlbmRlckdyb3VwTm9kZUluZm8+IHRoaXMuaW5kZXhbcGFyZW50Tm9kZS5uYW1lXTtcblxuICAgIC8vIFV0aWxpdHkgZnVuY3Rpb24gZm9yIGNvbXB1dGluZyB0aGUgbmFtZSBvZiBhIGJyaWRnZSBub2RlLlxuICAgIGxldCBnZXRCcmlkZ2VOb2RlTmFtZSA9IChpbmJvdW5kLCAuLi5yZXN0KSA9PlxuICAgICAgICByZXN0LmNvbmNhdChbaW5ib3VuZCA/ICdJTicgOiAnT1VUJ10pLmpvaW4oJ35+Jyk7XG5cbiAgICAvLyBCdWlsZCBvdXQgdGhlIGJyaWRnZWdyYXBoLlxuICAgIGxldCBicmlkZ2VncmFwaCA9IHRoaXMuaGllcmFyY2h5LmdldEJyaWRnZWdyYXBoKG5vZGVOYW1lKTtcblxuICAgIC8vIExvb2sgZm9yIHBvcHVsYXIgbm9kZXMgc28gd2UgY2FuIG1ha2UgYW5ub3RhdGlvbnMgaW5zdGVhZCBvZiBwYXRocy5cbiAgICBsZXQgb3RoZXJDb3VudHMgPSB7XG4gICAgICAvLyBDb3VudHMgb2YgZWRnZXMgY29taW5nIElOVE8gb3RoZXIgbm9kZXMgYnkgbmFtZSAob3V0Z29pbmcgZnJvbSBzZWxmKS5cbiAgICAgIGluOiA8e1tub2RlTmFtZTogc3RyaW5nXTogbnVtYmVyfT4ge30sXG4gICAgICAvLyBDb3VudHMgb2YgZWRnZXMgZ29pbmcgT1VUIGZyb20gb3RoZXIgbm9kZXMgYnkgbmFtZSAoY29taW5nIGludG8gc2VsZikuXG4gICAgICBvdXQ6IDx7W25vZGVOYW1lOiBzdHJpbmddOiBudW1iZXJ9PiB7fSxcbiAgICAgIC8vIENvdW50cyBvZiBhbGwgY29udHJvbCBlZGdlcyBpbnZvbHZpbmcgb3RoZXIgbm9kZXMgYnkgbmFtZS5cbiAgICAgIGNvbnRyb2w6IDx7W25vZGVOYW1lOiBzdHJpbmddOiBudW1iZXJ9PiB7fSxcbiAgICB9O1xuICAgIF8uZWFjaChicmlkZ2VncmFwaC5lZGdlcygpLCBlID0+IHtcbiAgICAgIC8vIEFuIGVkZ2UgaXMgaW5ib3VuZCBpZiBpdHMgZGVzdGluYXRpb24gbm9kZSBpcyBpbiB0aGUgbWV0YWdyYXBoLlxuICAgICAgbGV0IGluYm91bmQgPSAhIW1ldGFncmFwaC5ub2RlKGUudyk7XG4gICAgICBsZXQgb3RoZXJOYW1lID0gaW5ib3VuZCA/IGUudiA6IGUudztcbiAgICAgIGxldCBtZXRhZWRnZSA9IGJyaWRnZWdyYXBoLmVkZ2UoZSk7XG4gICAgICBpZiAoIW1ldGFlZGdlLm51bVJlZ3VsYXJFZGdlcykge1xuICAgICAgICBvdGhlckNvdW50cy5jb250cm9sW290aGVyTmFtZV0gPVxuICAgICAgICAgIChvdGhlckNvdW50cy5jb250cm9sW290aGVyTmFtZV0gfHwgMCkgKyAxO1xuICAgICAgfSBlbHNlIGlmIChpbmJvdW5kKSB7XG4gICAgICAgIG90aGVyQ291bnRzLm91dFtvdGhlck5hbWVdID0gKG90aGVyQ291bnRzLm91dFtvdGhlck5hbWVdIHx8IDApICsgMTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIG90aGVyQ291bnRzLmluW290aGVyTmFtZV0gPSAob3RoZXJDb3VudHMuaW5bb3RoZXJOYW1lXSB8fCAwKSArIDE7XG4gICAgICB9XG4gICAgfSk7XG5cbiAgICAvLyBBZGQgYW5ub3RhdGlvbnMgYW5kIGVkZ2VzIGZvciBicmlkZ2VncmFwaCByZWxhdGlvbnNoaXBzLlxuICAgIGxldCBoaWVyYXJjaHlOb2RlTWFwID0gdGhpcy5oaWVyYXJjaHkuZ2V0Tm9kZU1hcCgpO1xuICAgIF8uZWFjaChicmlkZ2VncmFwaC5lZGdlcygpLCBicmlkZ2VFZGdlT2JqID0+IHtcbiAgICAgIGxldCBicmlkZ2VNZXRhZWRnZSA9IGJyaWRnZWdyYXBoLmVkZ2UoYnJpZGdlRWRnZU9iaik7XG5cbiAgICAgIC8vIERldGVybWluZSB3aGV0aGVyIHRoaXMgYnJpZGdlIGVkZ2UgaXMgaW5jb21pbmcgYnkgY2hlY2tpbmcgdGhlXG4gICAgICAvLyBtZXRhZ3JhcGggZm9yIGEgbm9kZSB0aGF0IG1hdGNoZXMgdGhlIGRlc3RpbmF0aW9uIGVuZC5cbiAgICAgIGxldCBpbmJvdW5kID0gISFtZXRhZ3JhcGgubm9kZShicmlkZ2VFZGdlT2JqLncpO1xuXG4gICAgICAvLyBCYXNlZCBvbiB0aGUgZGlyZWN0aW9uIG9mIHRoZSBlZGdlLCBvbmUgZW5kcG9pbnQgd2lsbCBiZSBhbiBpbW1lZGlhdGVcbiAgICAgIC8vIGNoaWxkIG9mIHRoaXMgcmVuZGVyTm9kZUluZm8sIGFuZCB0aGUgb3RoZXIgZW5kcG9pbnQgd2lsbCBiZSBhIHNpYmxpbmdcbiAgICAgIC8vIG9mIHRoZSBwYXJlbnQgKG9yIGFuIGFuY2VzdG9yIGZ1cnRoZXIgdXApLlxuICAgICAgbGV0IFtjaGlsZE5hbWUsIG90aGVyTmFtZV0gPVxuICAgICAgICBpbmJvdW5kID9cbiAgICAgICAgICBbYnJpZGdlRWRnZU9iai53LCBicmlkZ2VFZGdlT2JqLnZdIDpcbiAgICAgICAgICBbYnJpZGdlRWRnZU9iai52LCBicmlkZ2VFZGdlT2JqLnddO1xuXG4gICAgICBsZXQgY2hpbGRSZW5kZXJJbmZvID0gdGhpcy5pbmRleFtjaGlsZE5hbWVdO1xuICAgICAgbGV0IG90aGVyUmVuZGVySW5mbyA9IHRoaXMuaW5kZXhbb3RoZXJOYW1lXTtcbiAgICAgIGxldCBvdGhlck5vZGUgPVxuICAgICAgICBvdGhlclJlbmRlckluZm8gP1xuICAgICAgICAgIG90aGVyUmVuZGVySW5mby5ub2RlIDpcbiAgICAgICAgICBoaWVyYXJjaHlOb2RlTWFwW290aGVyTmFtZV07XG5cbiAgICAgIC8vIERldGVybWluZSB3aGV0aGVyIHRoaXMgZWRnZSBpcyBhIGNvbnRyb2wgZWRnZSBiZXR3ZWVuIG5vZGVzIHdoZXJlXG4gICAgICAvLyBlaXRoZXIgbm9kZSBpcyBoaWdoLWRlZ3JlZSB3aXRoIHJlc3BlY3QgdG8gY29udHJvbCBlZGdlcy4gVGhpcyB3aWxsXG4gICAgICAvLyBiZSBhIHNpZ25hbCB0byBzaG93IGl0IGFzIGFuIGFubm90YXRpb24gaW5zdGVhZCBvZiBhIGJyaWRnZSBlZGdlLlxuICAgICAgbGV0IGlzSGlnaERlZ3JlZUNvbnRyb2xFZGdlID0gIWJyaWRnZU1ldGFlZGdlLm51bVJlZ3VsYXJFZGdlcyAmJlxuICAgICAgICBvdGhlckNvdW50cy5jb250cm9sW290aGVyTmFtZV0gPiBQQVJBTVMubWF4Q29udHJvbERlZ3JlZTtcblxuICAgICAgbGV0IFssIGNoaWxkQW5ub3RhdGlvbnNdID1cbiAgICAgICAgaW5ib3VuZCA/XG4gICAgICAgICAgW3JlbmRlck5vZGVJbmZvLmluQW5ub3RhdGlvbnMsIGNoaWxkUmVuZGVySW5mby5pbkFubm90YXRpb25zXSA6XG4gICAgICAgICAgW3JlbmRlck5vZGVJbmZvLm91dEFubm90YXRpb25zLCBjaGlsZFJlbmRlckluZm8ub3V0QW5ub3RhdGlvbnNdO1xuXG4gICAgICAvLyBEb24ndCByZW5kZXIgYSBicmlkZ2UgcGF0aCBpZiB0aGUgb3RoZXIgbm9kZSBoYXMgaW4gb3Igb3V0IGRlZ3JlZSBhYm92ZVxuICAgICAgLy8gYSB0aHJlc2hvbGQsIGxlc3QgYnJpZGdlIHBhdGhzIGVtYW5hdGluZyBvdXQgb2YgYSBtZXRhZ3JhcGggY3Jvd2QgdXAsXG4gICAgICAvLyBhcyB3YXMgdGhlIGNhc2UgZm9yIHRoZSBGYXRjYXQgTFNUTSBsc3RtXzEgPiBsc3RtXzEgbWV0YWdyYXBoLlxuICAgICAgbGV0IG90aGVyRGVncmVlQ291bnQgPVxuICAgICAgICAgIChpbmJvdW5kID8gb3RoZXJDb3VudHMub3V0IDogb3RoZXJDb3VudHMuaW4pW290aGVyTmFtZV07XG4gICAgICBsZXQgaXNPdGhlckhpZ2hEZWdyZWUgPSBvdGhlckRlZ3JlZUNvdW50ID4gUEFSQU1TLm1heEJyaWRnZVBhdGhEZWdyZWU7XG5cbiAgICAgIC8vIFRoZSBhZGpvaW5pbmcgcmVuZGVyIG1ldGFlZGdlIGluZm8gZnJvbSB0aGUgcGFyZW50J3MgY29yZUdyYXBoLCBpZiBhbnkuXG4gICAgICAvLyBJdCB3aWxsIGVpdGhlciBiZSBhIE1ldGFlZGdlIGludm9sdmluZyB0aGlzIG5vZGUgZGlyZWN0bHksIGlmIGl0XG4gICAgICAvLyBwcmV2aW91c2x5IGNhbWUgZnJvbSBhIG1ldGFncmFwaCwgb3IgaXQnbGwgYmUgYSBNZXRhZWRnZSBpbnZvbHZpbmdcbiAgICAgIC8vIGEgcHJldmlvdXNseSBjcmVhdGVkIGJyaWRnZSBub2RlIHN0YW5kaW5nIGluIGZvciB0aGUgb3RoZXIgbm9kZS5cbiAgICAgIGxldCBhZGpvaW5pbmdNZXRhZWRnZSA9IG51bGw7XG5cbiAgICAgIC8vIFdlIGNhbiBvbmx5IGhvcGUgdG8gcmVuZGVyIGEgYnJpZGdlIHBhdGggaWY6XG4gICAgICAvLyAgLSBicmlkZ2VncmFwaCBwYXRocyBhcmUgZW5hYmxlZCxcbiAgICAgIC8vICAtIHRoZSBvdGhlciBub2RlIGlzIG5vdCB0b28gaGlnaC1kZWdyZWUsXG4gICAgICAvLyAgLSB0aGUgY2hpbGQgaXMgaW4gdGhlIGNvcmUgKG5vdCBleHRyYWN0ZWQgZm9yIGJlaW5nIGhpZ2gtZGVncmVlKSwgYW5kXG4gICAgICAvLyAgLSB0aGVyZSdzIGEgcGF0aCAoaW4gdGhlIHRyYXZlcnNhbCBzZW5zZSkgYmV0d2VlbiBjaGlsZCBhbmQgb3RoZXIuXG4gICAgICBsZXQgY2FuRHJhd0JyaWRnZVBhdGggPSBmYWxzZTtcbiAgICAgIGlmIChQQVJBTVMuZW5hYmxlQnJpZGdlZ3JhcGggJiZcbiAgICAgICAgICAhaXNPdGhlckhpZ2hEZWdyZWUgJiZcbiAgICAgICAgICAhaXNIaWdoRGVncmVlQ29udHJvbEVkZ2UgJiZcbiAgICAgICAgICBjaGlsZFJlbmRlckluZm8uaXNJbkNvcmUoKSkge1xuXG4gICAgICAgIC8vIFV0aWxpdHkgZnVuY3Rpb24gZm9yIGZpbmRpbmcgYW4gYWRqb2luaW5nIG1ldGFlZGdlLlxuICAgICAgICBsZXQgZmluZEFkam9pbmluZ01ldGFlZGdlID0gdGFyZ2V0TmFtZSA9PiB7XG4gICAgICAgICAgbGV0IGFkam9pbmluZ0VkZ2VPYmo6IGdyYXBobGliLkVkZ2VPYmplY3QgPVxuICAgICAgICAgICAgaW5ib3VuZCA/XG4gICAgICAgICAgICAgIHsgdjogdGFyZ2V0TmFtZSwgdzogbm9kZU5hbWUgfSA6XG4gICAgICAgICAgICAgIHsgdjogbm9kZU5hbWUsIHc6IHRhcmdldE5hbWUgfTtcbiAgICAgICAgICByZXR1cm4gPFJlbmRlck1ldGFlZGdlSW5mbz5cbiAgICAgICAgICAgIHBhcmVudE5vZGVJbmZvLmNvcmVHcmFwaC5lZGdlKGFkam9pbmluZ0VkZ2VPYmopO1xuICAgICAgICB9O1xuXG4gICAgICAgIGFkam9pbmluZ01ldGFlZGdlID0gZmluZEFkam9pbmluZ01ldGFlZGdlKG90aGVyTmFtZSk7XG4gICAgICAgIGlmICghYWRqb2luaW5nTWV0YWVkZ2UpIHtcbiAgICAgICAgICBhZGpvaW5pbmdNZXRhZWRnZSA9IGZpbmRBZGpvaW5pbmdNZXRhZWRnZShcbiAgICAgICAgICAgICAgZ2V0QnJpZGdlTm9kZU5hbWUoaW5ib3VuZCwgb3RoZXJOYW1lLCBwYXJlbnROb2RlLm5hbWUpKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGNhbkRyYXdCcmlkZ2VQYXRoID0gISFhZGpvaW5pbmdNZXRhZWRnZTtcbiAgICAgIH1cblxuICAgICAgLy8gQWx0aG91Z2ggZGF0YWZsb3cgZWRnZXMgYXJlIGFjeWNsaWMsIGNvbnRyb2wgZGVwZW5kZW5jeSBlZGdlcyBtYXlcbiAgICAgIC8vIGFjdHVhbGx5IHBvaW50ICdiYWNrd2FyZHMnIGluIHRoZSBncmFwaC4gSWYgdGhpcyBicmlkZ2VNZXRhZWRnZSBpc1xuICAgICAgLy8gYSBjb250cm9sIGRlcGVuZGVuY3ksIHdlIG5lZWQgdG8gZGV0ZXJtaW5lIHdoZXRoZXIgaXQncyBiYWNrd2FyZHNcbiAgICAgIC8vIHBvaW50aW5nIHNvIHRoYXQgd2UgcmVuZGVyIGl0IGFwcHJvcHJpYXRlbHkuXG4gICAgICAvL1xuICAgICAgLy8gRm9yIGluc3RhbmNlLCBzYXkgd2UncmUgcmVuZGVyaW5nIGEgZ3JhcGggd2l0aCBub2RlcyBuYW1lZCBBL0IgYW5kIFovWSxcbiAgICAgIC8vIGFuZCB3ZSdyZSBjdXJyZW50bHkgcmVuZGVyaW5nIHRoZSBicmlkZ2VncmFwaCBmb3IgQS4gRnVydGhlciwgbGV0J3Mgc2F5XG4gICAgICAvLyB0aGF0IHRoZXJlIHdhcyBhbiBvcmlnaW5hbCBCYXNlRWRnZSBmcm9tIEEvQi0+Wi9ZIGFuZCBhIENPTlRST0wgRURHRVxuICAgICAgLy8gZnJvbSBaL1k9PkEvQi5cbiAgICAgIC8vXG4gICAgICAvLyAgICAgKy0tLS0tLS0tLS0tLS0tLS0rXG4gICAgICAvLyAgICAgfCBBICAgICAgICAgICAgICB8XG4gICAgICAvLyAgICAgfCAgKy0tLS0tKyAgICAgICB8ICAgICAgICAgKy0tLS0tLStcbiAgICAgIC8vICAgICB8ICB8IEIgICB8Pi0tLS0tPnw+LS0tLS0tLT58IFogICAgfFxuICAgICAgLy8gICAgIHwgIHwgICAgIHwgICAgICAgfCAgICAgICAgIHwgICAgICB8XG4gICAgICAvLyAgICAgfCAgfCAgICAgfCAgICogICB8ICAgICAgICAgfCAgICAgIHxcbiAgICAgIC8vICAgICB8ICB8ICAgICB8PD09PT09PHw8PT09PT09PTx8ICAgICAgfFxuICAgICAgLy8gICAgIHwgICstLS0tLSsgICAgICAgfCAgICAgICAgICstLS0tLS0rXG4gICAgICAvLyAgICAgKy0tLS0tLS0tLS0tLS0tLS0rXG4gICAgICAvL1xuICAgICAgLy8gV2hlbiB3ZSByZW5kZXIgdGhlIHN1YmhpZXJhcmNoeSBmb3IgTWV0YW5vZGUgQSwgd2UnbGwgY29tZSBhY3Jvc3MgYVxuICAgICAgLy8gY29udHJvbC1vbmx5IE1ldGFlZGdlIGluIHRoZSBicmlkZ2VncmFwaCBmcm9tIFo9PkEvQiAoKikuIFRoZSBxdWVzdGlvblxuICAgICAgLy8gaXMgd2hldGhlciB0aGlzIGVkZ2UgaXMgYmFja3dhcmRzLlxuICAgICAgLy9cbiAgICAgIC8vIFRvIGFuc3dlciB0aGF0IHF1ZXN0aW9uLCB3ZSBmb2xsb3cgdGhlIGNoYWluIG9mIGFkam9pbmluZyBtZXRhZWRnZXNcbiAgICAgIC8vIHVudGlsIHdlIHJlYWNoIHRoZSB0b3Btb3N0IG9uZS4gSW4gdGhpcyBjYXNlLCB0aGF0J3MgdGhlIGNvbnRyb2wtb25seVxuICAgICAgLy8gTWV0YWVkZ2UgWj0+QSBpbiB0aGUgUk9PVCdzIG1ldGFncmFwaC4gV2UgZGV0ZXJtaW5lIHRoYXQgdGhpcyBlZGdlXG4gICAgICAvLyBpcyBiYWNrd2FyZHMgYnkgbG9va2luZyBhdCB0aGUgdG9wb2xvZ2ljYWwgb3JkZXJpbmcgb2YgUk9PVCdzIG1ldGFncmFwaFxuICAgICAgLy8gKHdoaWNoIGlnbm9yZXMgY29udHJvbCBlZGdlcykgYW5kIHNlZWluZyB0aGF0IFogY29tZXMgQUZURVIgQS5cbiAgICAgIC8vXG4gICAgICAvLyBUaGUgcHJvcGVydHkgb2YgYmVpbmcgYmFja3dhcmRzIGlzIGluZGVwZW5kZW50IG9mIHdoZXRoZXIgdGhlIGVkZ2VcbiAgICAgIC8vIGlzIGluYm91bmQgb3Igb3V0Ym91bmQuIEluIHRoZSBwcmVjZWRpbmcgZXhhbXBsZSwgaWYgd2Ugd2VyZSBidWlsZGluZ1xuICAgICAgLy8gdGhlIHN1YmhpZXJhcmNoeSBmb3IgWiwgd2UnZCBmaW5kIGJyaWRnZSBlZGdlIFovWT0+QSwgd2FsayB0byBpdHNcbiAgICAgIC8vIHRvcG1vc3QgYWRqb2luaW5nIG1ldGFlZGdlIFo9PkEgYW5kIGRpc2NvdmVyIHRoYXQgaXQncyBiYWNrd2FyZHMuXG4gICAgICBsZXQgYmFja3dhcmRzID0gZmFsc2U7XG4gICAgICBpZiAoYWRqb2luaW5nTWV0YWVkZ2UgJiYgIWJyaWRnZU1ldGFlZGdlLm51bVJlZ3VsYXJFZGdlcykge1xuICAgICAgICAvLyBGaW5kIHRoZSB0b3AtbW9zdCBhZGpvaW5pbmcgcmVuZGVyIG1ldGFlZGdlIGluZm9ybWF0aW9uLCBhbmQgdGhlXG4gICAgICAgIC8vIEdyb3VwTm9kZSB3aG9zZSBtZXRhZ3JhcGggbXVzdCBjb250YWluIHRoZSBhc3NvY2lhdGVkIG1ldGFlZGdlLlxuICAgICAgICBsZXQgdG9wQWRqb2luaW5nTWV0YWVkZ2UgPSBhZGpvaW5pbmdNZXRhZWRnZTtcbiAgICAgICAgbGV0IHRvcEdyb3VwTm9kZSA9IHBhcmVudE5vZGVJbmZvLm5vZGU7XG4gICAgICAgIHdoaWxlICh0b3BBZGpvaW5pbmdNZXRhZWRnZS5hZGpvaW5pbmdNZXRhZWRnZSkge1xuICAgICAgICAgIHRvcEFkam9pbmluZ01ldGFlZGdlID0gdG9wQWRqb2luaW5nTWV0YWVkZ2UuYWRqb2luaW5nTWV0YWVkZ2U7XG4gICAgICAgICAgdG9wR3JvdXBOb2RlID0gPEdyb3VwTm9kZT50b3BHcm91cE5vZGUucGFyZW50Tm9kZTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIENoZWNrIGFnYWluc3QgdGhlIHRvcG9sb2dpY2FsIG9yZGVyaW5nIGZvciB0aGUgdG9wIG5vZGUuIFRoZSBjdXJyZW50XG4gICAgICAgIC8vIGJyaWRnZSBtZXRhZWRnZSB3ZSdyZSBldmFsdWF0aW5nIGlzIGJhY2t3YXJkcyBpZiBpdHMgc291cmNlIGNvbWVzXG4gICAgICAgIC8vIGFmdGVyIGl0cyBkZXN0aW5hdGlvbi5cbiAgICAgICAgbGV0IG9yZGVyaW5nID0gdGhpcy5oaWVyYXJjaHkuZ2V0VG9wb2xvZ2ljYWxPcmRlcmluZyh0b3BHcm91cE5vZGUubmFtZSk7XG4gICAgICAgIGxldCBlID0gdG9wQWRqb2luaW5nTWV0YWVkZ2UubWV0YWVkZ2U7XG4gICAgICAgIGJhY2t3YXJkcyA9IG9yZGVyaW5nW2Uudl0gPiBvcmRlcmluZ1tlLnddO1xuICAgICAgfVxuXG4gICAgICAvLyBSZW5kZXIgYmFja3dhcmRzIGNvbnRyb2wgZWRnZXMgYXMgYW5ub3RhdGlvbnMuXG4gICAgICBjYW5EcmF3QnJpZGdlUGF0aCA9IGNhbkRyYXdCcmlkZ2VQYXRoICYmICFiYWNrd2FyZHM7XG5cbiAgICAgIC8vIElmIHdlIGNhbid0IG1ha2UgYSBicmlkZ2UgcGF0aCBmb3IgYW55IHJlYXNvbiwgdGhlbiB3ZSBhZGQgYW5cbiAgICAgIC8vIGFubm90YXRpb24gaW5zdGVhZC5cbiAgICAgIGlmICghY2FuRHJhd0JyaWRnZVBhdGgpIHtcbiAgICAgICAgY2hpbGRBbm5vdGF0aW9ucy5wdXNoKG5ldyBBbm5vdGF0aW9uKFxuICAgICAgICAgICAgb3RoZXJOb2RlLFxuICAgICAgICAgICAgb3RoZXJSZW5kZXJJbmZvLFxuICAgICAgICAgICAgbmV3IFJlbmRlck1ldGFlZGdlSW5mbyhicmlkZ2VNZXRhZWRnZSksXG4gICAgICAgICAgICBBbm5vdGF0aW9uVHlwZS5TSE9SVENVVCxcbiAgICAgICAgICAgIGluYm91bmQpKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuXG4gICAgICAvLyBBdCB0aGlzIHBvaW50LCBhbGwgY29uZGl0aW9ucyBoYXZlIGJlZW4gbWV0IGZvciBkcmF3aW5nIGEgYnJpZGdlIHBhdGguXG5cbiAgICAgIC8vIEZpbmQgb3IgY3JlYXRlIHRoZSBJTi9PVVQgbm9kZSByZXByZXNlbnRpbmcgb3RoZXJOb2RlLlxuICAgICAgbGV0IGJyaWRnZUNvbnRhaW5lck5hbWUgPSBnZXRCcmlkZ2VOb2RlTmFtZShpbmJvdW5kLCBub2RlTmFtZSk7XG4gICAgICBsZXQgYnJpZGdlTm9kZU5hbWUgPSBnZXRCcmlkZ2VOb2RlTmFtZShpbmJvdW5kLCBvdGhlck5hbWUsIG5vZGVOYW1lKTtcbiAgICAgIGxldCBicmlkZ2VOb2RlUmVuZGVySW5mbyA9IGNvcmVHcmFwaC5ub2RlKGJyaWRnZU5vZGVOYW1lKTtcbiAgICAgIGlmICghYnJpZGdlTm9kZVJlbmRlckluZm8pIHtcblxuICAgICAgICAvLyBGaW5kIG9yIGNyZWF0ZSB0aGUgZGlyZWN0aW9uYWwgY29udGFpbmVyIGZvciB0aGUgYnJpZGdlIG5vZGUuXG4gICAgICAgIGxldCBicmlkZ2VDb250YWluZXJJbmZvID0gY29yZUdyYXBoLm5vZGUoYnJpZGdlQ29udGFpbmVyTmFtZSk7XG4gICAgICAgIGlmICghYnJpZGdlQ29udGFpbmVySW5mbykge1xuICAgICAgICAgIGxldCBicmlkZ2VDb250YWluZXJOb2RlOiBCcmlkZ2VOb2RlID0ge1xuICAgICAgICAgICAgLy8gSW1wb3J0YW50IG5vZGUgcHJvcGVydGllcy5cbiAgICAgICAgICAgIG5hbWU6IGJyaWRnZUNvbnRhaW5lck5hbWUsXG4gICAgICAgICAgICB0eXBlOiBOb2RlVHlwZS5CUklER0UsXG4gICAgICAgICAgICAvLyBVbnVzZWQgbm9kZSBwcm9wZXJ0aWVzLlxuICAgICAgICAgICAgaXNHcm91cE5vZGU6IGZhbHNlLFxuICAgICAgICAgICAgY2FyZGluYWxpdHk6IDAsXG4gICAgICAgICAgICBwYXJlbnROb2RlOiBudWxsLFxuICAgICAgICAgICAgc3RhdHM6IG51bGwsXG4gICAgICAgICAgICBpbmNsdWRlOiBJbmNsdXNpb25UeXBlLlVOU1BFQ0lGSUVELFxuICAgICAgICAgICAgLy8gQnJpZGdlTm9kZSBwcm9wZXJ0aWVzLlxuICAgICAgICAgICAgaW5ib3VuZDogaW5ib3VuZCxcbiAgICAgICAgICAgIG5vZGVBdHRyaWJ1dGVzOiB7fSxcbiAgICAgICAgICB9O1xuICAgICAgICAgIGJyaWRnZUNvbnRhaW5lckluZm8gPVxuICAgICAgICAgICAgbmV3IFJlbmRlck5vZGVJbmZvKGJyaWRnZUNvbnRhaW5lck5vZGUpO1xuICAgICAgICAgIHRoaXMuaW5kZXhbYnJpZGdlQ29udGFpbmVyTmFtZV0gPSBicmlkZ2VDb250YWluZXJJbmZvO1xuICAgICAgICAgIGNvcmVHcmFwaC5zZXROb2RlKGJyaWRnZUNvbnRhaW5lck5hbWUsIGJyaWRnZUNvbnRhaW5lckluZm8pO1xuICAgICAgICB9XG5cbiAgICAgICAgbGV0IGJyaWRnZU5vZGU6IEJyaWRnZU5vZGUgPSB7XG4gICAgICAgICAgLy8gSW1wb3J0YW50IG5vZGUgcHJvcGVydGllcy5cbiAgICAgICAgICBuYW1lOiBicmlkZ2VOb2RlTmFtZSxcbiAgICAgICAgICB0eXBlOiBOb2RlVHlwZS5CUklER0UsXG4gICAgICAgICAgLy8gVW5pbXBvcnRhbnQgbm9kZSBwcm9wZXJ0aWVzLlxuICAgICAgICAgIGlzR3JvdXBOb2RlOiBmYWxzZSxcbiAgICAgICAgICBjYXJkaW5hbGl0eTogMSxcbiAgICAgICAgICBwYXJlbnROb2RlOiBudWxsLFxuICAgICAgICAgIHN0YXRzOiBudWxsLFxuICAgICAgICAgIGluY2x1ZGU6IEluY2x1c2lvblR5cGUuVU5TUEVDSUZJRUQsXG4gICAgICAgICAgLy8gQnJpZGdlTm9kZSBwcm9wZXJ0aWVzLlxuICAgICAgICAgIGluYm91bmQ6IGluYm91bmQsXG4gICAgICAgICAgbm9kZUF0dHJpYnV0ZXM6IHt9LFxuICAgICAgICB9O1xuICAgICAgICBicmlkZ2VOb2RlUmVuZGVySW5mbyA9IG5ldyBSZW5kZXJOb2RlSW5mbyhicmlkZ2VOb2RlKTtcbiAgICAgICAgdGhpcy5pbmRleFticmlkZ2VOb2RlTmFtZV0gPSBicmlkZ2VOb2RlUmVuZGVySW5mbztcbiAgICAgICAgY29yZUdyYXBoLnNldE5vZGUoYnJpZGdlTm9kZU5hbWUsIGJyaWRnZU5vZGVSZW5kZXJJbmZvKTtcblxuICAgICAgICAvLyBTZXQgYnJpZGdlTm9kZSB0byBiZSBhIGdyYXBobGliIGNoaWxkIG9mIHRoZSBjb250YWluZXIgbm9kZS5cbiAgICAgICAgY29yZUdyYXBoLnNldFBhcmVudChicmlkZ2VOb2RlTmFtZSwgYnJpZGdlQ29udGFpbmVyTmFtZSk7XG4gICAgICAgIGJyaWRnZUNvbnRhaW5lckluZm8ubm9kZS5jYXJkaW5hbGl0eSsrO1xuICAgICAgfVxuXG4gICAgICAvLyBDcmVhdGUgYW5kIGFkZCBhIGJyaWRnZSByZW5kZXIgbWV0YWVkZ2UuXG4gICAgICBsZXQgYnJpZGdlUmVuZGVyTWV0YWVkZ2UgPVxuICAgICAgICBuZXcgUmVuZGVyTWV0YWVkZ2VJbmZvKGJyaWRnZU1ldGFlZGdlKTtcbiAgICAgIGJyaWRnZVJlbmRlck1ldGFlZGdlLmFkam9pbmluZ01ldGFlZGdlID0gYWRqb2luaW5nTWV0YWVkZ2U7XG4gICAgICBpbmJvdW5kID9cbiAgICAgICAgY29yZUdyYXBoLnNldEVkZ2UoYnJpZGdlTm9kZU5hbWUsIGNoaWxkTmFtZSwgYnJpZGdlUmVuZGVyTWV0YWVkZ2UpIDpcbiAgICAgICAgY29yZUdyYXBoLnNldEVkZ2UoY2hpbGROYW1lLCBicmlkZ2VOb2RlTmFtZSwgYnJpZGdlUmVuZGVyTWV0YWVkZ2UpO1xuXG4gICAgfSk7IC8vIEVuZCBfLmVhY2goYnJpZGdlZ3JhcGguZWRnZXMpLlxuXG4gICAgLy8gRm9yIGVhY2ggYnJpZGdlIGNvbnRhaW5lciAoSU4gYW5kL29yIE9VVCksIGFkZCBzdHJ1Y3R1cmFsIGVkZ2VzIGJldHdlZW5cbiAgICAvLyB0ZXJtaW5hbCBub2RlcyBhbmQgdGhhdCBjb250YWluZXIuIEEgdGVybWluYWwgbm9kZSBpcyBvbmUgd2hpY2ggaGFzIG5vXG4gICAgLy8gbm9uLWJyaWRnZSBlZGdlcyBpbiB0aGUgZGlyZWN0aW9uIG9mIHRoZSBjb250YWluZXIuXG4gICAgLy9cbiAgICAvLyBGb3IgZXhhbXBsZSwgY29uc2lkZXIgYSBNZXRhbm9kZSBBIHdoaWNoIGNvbnRhaW5zIHR3byBjaGlsZCBub2RlcyBBL0JcbiAgICAvLyBhbmQgQS9DLiBMZXQncyBzYXkgaXQgaGFzIG9uZSBlZGdlIGluIHRoZSBtZXRhZ3JhcGggZnJvbSBBL0ItPkEvQywgYW5kXG4gICAgLy8gb25lIGVkZ2UgaW4gdGhlIGJyaWRnZWdyYXBoIGZyb20gWi0+QS9DLlxuICAgIC8vXG4gICAgLy8gQXQgdGhpcyBwb2ludCwgd2UndmUgYWRkZWQgYSBjb250YWluZXIgYnJpZGdlIG5vZGUgSU4gdG8gaG91c2UgYWxsXG4gICAgLy8gaW5jb21pbmcgYnJpZGdlIG5vZGVzLiBXZSd2ZSBhbHNvIGFkZGVkIGEgYnJpZGdlIG5vZGUgWicgKHdpdGggcGFyZW50IElOKVxuICAgIC8vIHRvIEEsIGFuZCBhIGJyaWRnZSBlZGdlIGZyb20gWictPkMuXG4gICAgLy9cbiAgICAvLyAgICAgKy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0rXG4gICAgLy8gICAgIHwgQSAgICAgICAgICArLS0tKyAgICAgfFxuICAgIC8vICAgICB8ICAgICstLS0tLS0+fCBDIHwgICAgIHxcbiAgICAvLyAgICAgfCAgICB8ICAgICAgICstLS0rICAgICB8XG4gICAgLy8gICAgIHwgICAgfCAgICAgICAgIF4gICAgICAgfFxuICAgIC8vICAgICB8ICAgIHwgICAgICAgICB8ICAgICAgIHxcbiAgICAvLyAgICAgfCAgICB8ICAgICstLS0tfC0tLS0rICB8XG4gICAgLy8gICAgIHwgICAgfCAgICB8IElOIHwgICAgfCAgfFxuICAgIC8vICAgICB8ICArLS0tKyAgfCAgKy0tLSsgIHwgIHxcbiAgICAvLyAgICAgfCAgfCBCIHwgIHwgIHwgWid8ICB8ICB8XG4gICAgLy8gICAgIHwgICstLS0rICB8ICArLS0tKyAgfCAgfFxuICAgIC8vICAgICB8ICAgICAgICAgKy0tLS0tLS0tLSsgIHxcbiAgICAvLyAgICAgKy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0rXG4gICAgLy9cbiAgICAvLyBXaXRoIG5vIG90aGVyIGhlbHAsIGRhZ3JlIHdvdWxkIGxheSBvdXQgQiBhbmQgWicgb24gdGhlIHNhbWUgbGV2ZWwsXG4gICAgLy8gYmVjYXVzZSBib3RoIG9mIHRoZW0gaGF2ZSBubyBpbmNvbWluZyBlZGdlcy4gSW4gb3RoZXIgd29yZHMsIEIgaXMgYVxuICAgIC8vIHRlcm1pbmFsIG5vZGUgaW4gdGhlIElOQ09NSU5HIGRpcmVjdGlvbi5cbiAgICAvL1xuICAgIC8vIEJ1dCB3ZSB3YW50IHRvIGZvcmNlIGRhZ3JlIHRvIGxheSBvdXQgWicgKGFuZCBldmVyeXRoaW5nIGluIElOKSBsb3dlclxuICAgIC8vIHRoYW4gYWxsIG5vbi1icmlkZ2Ugbm9kZXMsIHNvIHRoYXQgdGhlcmUncyBlbm91Z2ggcm9vbSBmb3IgdGhlIGJyaWRnZVxuICAgIC8vIGVkZ2VzIGFmdGVyIHRoZXkndmUgYmVlbiBhZGp1c3RlZCB0byBtZWV0IHVwIHdpdGggcGF0aHMgY29taW5nIGluIGZyb21cbiAgICAvLyBvdXRzaWRlLlxuICAgIC8vXG4gICAgLy8gVG8gZm9yY2UgWicgKGFuZCBhbGwgb3RoZXIgYnJpZGdlIG5vZGVzKSB0byBiZSBsb3dlc3QgaW4gdGhlIGdyYXBoLCB3ZVxuICAgIC8vIGlkZW50aWZ5IHRlcm1pbmFsIG5vZGVzIGxpa2UgQiBhbmQgZ2l2ZSB0aGVtIHN0cnVjdHVyYWwgZWRnZXMgdG9cbiAgICAvLyBhIG5ldyBzdHJ1Y3R1cmFsIGJyaWRnZSBub2RlIFMgd2hpY2ggd2UgYWRkIHRvIElOLlxuICAgIC8vXG4gICAgLy8gICAgICstLS0tLS0tLS0tLS0tLS0tLS0tLS0tK1xuICAgIC8vICAgICB8IEEgICAgICAgICAgKy0tLSsgICAgIHxcbiAgICAvLyAgICAgfCAgICAgICArLS0tPnwgQyB8ICAgICB8XG4gICAgLy8gICAgIHwgICAgICAgfCAgICArLS0tKyAgICAgfFxuICAgIC8vICAgICB8ICAgICArLS0tKyAgICBeICAgICAgIHxcbiAgICAvLyAgICAgfCAgICAgfCBCIHwgICAgfCAgICAgICB8XG4gICAgLy8gICAgIHwgICAgICstLS0rICAgIHwgICAgICAgfFxuICAgIC8vICAgICB8ICAgICAgIF4gICAgICB8ICAgICAgIHxcbiAgICAvLyAgICAgfCAgICAgICB8ICAgICAgfCAgICAgICB8XG4gICAgLy8gICAgIHwgICstLS0tfC0tLS0tLXwtLS0tKyAgfFxuICAgIC8vICAgICB8ICB8SU4gIHwgICAgICB8ICAgIHwgIHxcbiAgICAvLyAgICAgfCAgfCAgKy0tLSsgICstLS0rICB8ICB8XG4gICAgLy8gICAgIHwgIHwgIHwgUyB8ICB8IFonfCAgfCAgfFxuICAgIC8vICAgICB8ICB8ICArLS0tKyAgKy0tLSsgIHwgIHxcbiAgICAvLyAgICAgfCAgKy0tLS0tLS0tLS0tLS0tLS0rICB8XG4gICAgLy8gICAgICstLS0tLS0tLS0tLS0tLS0tLS0tLS0tK1xuICAgIC8vXG4gICAgLy8gVGhpcyBlbnN1cmVzIHRoYXQgZGFncmUgd2lsbCBsYXkgb3V0IHRoZSBicmlkZ2UgY29udGFpbmVycyBzdHJpY3RseSBhdFxuICAgIC8vIHRoZSBlbmRzIG9mIHRoZSBncmFwaC4gVGhlIHN0cnVjdHVyYWwgZWRnZXMgd2lsbCBuZXZlciBiZSBzZWVuIGluIHRoZVxuICAgIC8vIHZpc3VhbGl6YXRpb24gZXhjZXB0IGFzIGEgZGVidWdnaW5nIGFpZC5cbiAgICBfLmVhY2goW3RydWUsIGZhbHNlXSwgaW5ib3VuZCA9PiB7XG4gICAgICBsZXQgYnJpZGdlQ29udGFpbmVyTmFtZSA9IGdldEJyaWRnZU5vZGVOYW1lKGluYm91bmQsIG5vZGVOYW1lKTtcbiAgICAgIGxldCBicmlkZ2VDb250YWluZXJJbmZvID0gY29yZUdyYXBoLm5vZGUoYnJpZGdlQ29udGFpbmVyTmFtZSk7XG4gICAgICBpZiAoIWJyaWRnZUNvbnRhaW5lckluZm8pIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgXy5lYWNoKGNvcmVHcmFwaC5ub2RlcygpLCBjaGlsZE5hbWUgPT4ge1xuICAgICAgICAvLyBTaG9ydC1jaXJjdWl0IGlmIHRoaXMgY2hpbGQgaXMgYSBicmlkZ2Ugbm9kZSBvciBpdCdzIG5vdCBhIHRlcm1pbmFsXG4gICAgICAgIC8vIG5vZGUgaW4gdGhlIGRpcmVjdGlvbiB3ZSdyZSBpbnRlcmVzdGVkIGluLlxuICAgICAgICBsZXQgY2hpbGROb2RlSW5mbyA9IGNvcmVHcmFwaC5ub2RlKGNoaWxkTmFtZSk7XG4gICAgICAgIGlmIChjaGlsZE5vZGVJbmZvLm5vZGUudHlwZSA9PT0gTm9kZVR5cGUuQlJJREdFKSB7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGxldCBpc1Rlcm1pbmFsID0gaW5ib3VuZCA/XG4gICAgICAgICAgIWNvcmVHcmFwaC5wcmVkZWNlc3NvcnMoY2hpbGROYW1lKS5sZW5ndGggOlxuICAgICAgICAgICFjb3JlR3JhcGguc3VjY2Vzc29ycyhjaGlsZE5hbWUpLmxlbmd0aDtcbiAgICAgICAgaWYgKCFpc1Rlcm1pbmFsKSB7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gRmluZCBvciBjcmVhdGUgYSBicmlkZ2Ugbm9kZSBpbiB0aGUgY29udGFpbmVyIGZvciBhbGwgc3RydWN0dXJhbFxuICAgICAgICAvLyBtZXRhZWRnZXMuIEl0IHdvdWxkIGhhdmUgYmVlbiBuaWNlIHRvIHNraXAgdGhpcyBzdGVwIGFuZCBzaW1wbHlcbiAgICAgICAgLy8gc2V0IGEgbWV0YWVkZ2UgYmV0d2VlbiB0aGUgdGVybWluYWwgbm9kZSBhbmQgdGhlIGNvbnRhaW5lciBub2RlLCBidXRcbiAgICAgICAgLy8gaW4gdGhhdCBjYXNlLCBzb21ldGhpbmcgYWJvdXQgdGhlIGdyYXBoIHVwc2V0cyBkYWdyZS5sYXlvdXQoKSdzXG4gICAgICAgIC8vIGxvbmdlc3RQYXRoIGFsZ29yaXRobSAod2FzIGdldHRpbmcgZXJyb3JzIGR1ZSB0byBhbiB1bmRlZmluZWQpLlxuICAgICAgICBsZXQgc3RydWN0dXJhbE5vZGVOYW1lID1cbiAgICAgICAgICAgIGdldEJyaWRnZU5vZGVOYW1lKGluYm91bmQsIG5vZGVOYW1lLCAnU1RSVUNUVVJBTF9UQVJHRVQnKTtcbiAgICAgICAgbGV0IHN0cnVjdHVyYWxSZW5kZXJJbmZvID0gY29yZUdyYXBoLm5vZGUoc3RydWN0dXJhbE5vZGVOYW1lKTtcbiAgICAgICAgaWYgKCFzdHJ1Y3R1cmFsUmVuZGVySW5mbykge1xuICAgICAgICAgIGxldCBicmlkZ2VOb2RlOiBCcmlkZ2VOb2RlID0ge1xuICAgICAgICAgICAgLy8gSW1wb3J0YW50IE5vZGUgcHJvcGVydGllcy5cbiAgICAgICAgICAgIG5hbWU6IHN0cnVjdHVyYWxOb2RlTmFtZSxcbiAgICAgICAgICAgIHR5cGU6IE5vZGVUeXBlLkJSSURHRSxcbiAgICAgICAgICAgIC8vIFVuaW1wb3J0YW50IE5vZGUgcHJvcGVydGllcy5cbiAgICAgICAgICAgIGlzR3JvdXBOb2RlOiBmYWxzZSxcbiAgICAgICAgICAgIGNhcmRpbmFsaXR5OiAxLFxuICAgICAgICAgICAgcGFyZW50Tm9kZTogbnVsbCxcbiAgICAgICAgICAgIHN0YXRzOiBudWxsLFxuICAgICAgICAgICAgaW5jbHVkZTogSW5jbHVzaW9uVHlwZS5VTlNQRUNJRklFRCxcbiAgICAgICAgICAgIC8vIEJyaWRnZU5vZGUgcHJvcGVydGllcy5cbiAgICAgICAgICAgIGluYm91bmQ6IGluYm91bmQsXG4gICAgICAgICAgICBub2RlQXR0cmlidXRlczoge30sXG4gICAgICAgICAgfTtcbiAgICAgICAgICBzdHJ1Y3R1cmFsUmVuZGVySW5mbyA9IG5ldyBSZW5kZXJOb2RlSW5mbyhicmlkZ2VOb2RlKTtcbiAgICAgICAgICBzdHJ1Y3R1cmFsUmVuZGVySW5mby5zdHJ1Y3R1cmFsID0gdHJ1ZTtcbiAgICAgICAgICB0aGlzLmluZGV4W3N0cnVjdHVyYWxOb2RlTmFtZV0gPSBzdHJ1Y3R1cmFsUmVuZGVySW5mbztcbiAgICAgICAgICBjb3JlR3JhcGguc2V0Tm9kZShzdHJ1Y3R1cmFsTm9kZU5hbWUsIHN0cnVjdHVyYWxSZW5kZXJJbmZvKTtcbiAgICAgICAgICBicmlkZ2VDb250YWluZXJJbmZvLm5vZGUuY2FyZGluYWxpdHkrKztcbiAgICAgICAgICBjb3JlR3JhcGguc2V0UGFyZW50KHN0cnVjdHVyYWxOb2RlTmFtZSwgYnJpZGdlQ29udGFpbmVyTmFtZSk7XG4gICAgICAgIH1cblxuICAgICAgICAvLyBDcmVhdGUgdGhlIHN0cnVjdHVyYWwgTWV0YWVkZ2UgYW5kIGluc2VydCBpdC5cbiAgICAgICAgbGV0IHN0cnVjdHVyYWxNZXRhZWRnZUluZm8gPSBuZXcgUmVuZGVyTWV0YWVkZ2VJbmZvKG51bGwpO1xuICAgICAgICBzdHJ1Y3R1cmFsTWV0YWVkZ2VJbmZvLnN0cnVjdHVyYWwgPSB0cnVlO1xuICAgICAgICBzdHJ1Y3R1cmFsTWV0YWVkZ2VJbmZvLndlaWdodC0tOyAvLyBSZWR1Y2Ugd2VpZ2h0IGZvciBkYWdyZSBsYXlvdXQuXG4gICAgICAgIGluYm91bmQgP1xuICAgICAgICAgIGNvcmVHcmFwaC5zZXRFZGdlKFxuICAgICAgICAgICAgICBzdHJ1Y3R1cmFsTm9kZU5hbWUsIGNoaWxkTmFtZSwgc3RydWN0dXJhbE1ldGFlZGdlSW5mbykgOlxuICAgICAgICAgIGNvcmVHcmFwaC5zZXRFZGdlKFxuICAgICAgICAgICAgICBjaGlsZE5hbWUsIHN0cnVjdHVyYWxOb2RlTmFtZSwgc3RydWN0dXJhbE1ldGFlZGdlSW5mbyk7XG4gICAgICB9KTtcbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBUaGlzIG1ldGhvZCBidWlsZHMgc3ViaGllcmFyY2hpZXMgZm9yIGZ1bmN0aW9uIGNhbGxzIHRoYXQgYXJlIG5lZWRlZCBmb3JcbiAgICogcmVuZGVyaW5nIGVkZ2VzIGluIHRoZSBjdXJyZW50IHN1YmhpZXJhcmNoeSBiZWluZyBidWlsdC5cbiAgICpcbiAgICogV2hlbiBidWlsZGluZyBzdWJoaWVyYXJjaGllcyBmb3IgYSBtZXRhZ3JhcGggTSwgdGhlIHN1YmhpZXJhcmNoaWVzIG9mXG4gICAqIG1ldGFub2RlcyBjb250YWluaW5nIGVuZHBvaW50IG5vZGVzIGZvciBlZGdlcyB3aXRoaW4gbWV0YWdyYXBoIE0gbXVzdFxuICAgKiBhbHJlYWR5IGJlIGJ1aWx0LiBPdGhlcndpc2UsIGJyaWRnZSBlZGdlcyB3aWxsIGJlIG1pc3NpbmcgZnJvbSB0aGUgZ3JhcGguXG4gICAqL1xuICBwcml2YXRlIGJ1aWxkU3ViaGllcmFyY2hpZXNGb3JOZWVkZWRGdW5jdGlvbnMoXG4gICAgICBtZXRhZ3JhcGg6IGdyYXBobGliLkdyYXBoPEdyb3VwTm9kZXxPcE5vZGUsIE1ldGFlZGdlPikge1xuICAgIF8uZWFjaChtZXRhZ3JhcGguZWRnZXMoKSwgZWRnZU9iaiA9PiB7XG4gICAgICBsZXQgbWV0YWVkZ2UgPSBtZXRhZ3JhcGguZWRnZShlZGdlT2JqKTtcbiAgICAgIGxldCByZW5kZXJNZXRhZWRnZUluZm8gPSBuZXcgUmVuZGVyTWV0YWVkZ2VJbmZvKG1ldGFlZGdlKTtcbiAgICAgIF8uZm9yRWFjaChyZW5kZXJNZXRhZWRnZUluZm8ubWV0YWVkZ2UuYmFzZUVkZ2VMaXN0LFxuICAgICAgICAgIGJhc2VFZGdlID0+IHtcbiAgICAgICAgY29uc3Qgc291cmNlUGF0aExpc3QgPSBiYXNlRWRnZS52LnNwbGl0KHRmLmdyYXBoLk5BTUVTUEFDRV9ERUxJTSk7XG5cbiAgICAgICAgZm9yIChsZXQgaSA9IHNvdXJjZVBhdGhMaXN0Lmxlbmd0aDsgaSA+PSAwOyBpLS0pIHtcbiAgICAgICAgICBjb25zdCBmcm9tQmVnaW5uaW5nUGF0aExpc3QgPSBzb3VyY2VQYXRoTGlzdC5zbGljZSgwLCBpKTtcbiAgICAgICAgICBjb25zdCBub2RlID0gdGhpcy5oaWVyYXJjaHkubm9kZShcbiAgICAgICAgICAgICAgZnJvbUJlZ2lubmluZ1BhdGhMaXN0LmpvaW4odGYuZ3JhcGguTkFNRVNQQUNFX0RFTElNKSk7XG4gICAgICAgICAgaWYgKG5vZGUpIHtcbiAgICAgICAgICAgIGlmIChub2RlLnR5cGUgPT09IE5vZGVUeXBlLk9QICYmXG4gICAgICAgICAgICAgICAgdGhpcy5oaWVyYXJjaHkubGlicmFyeUZ1bmN0aW9uc1sobm9kZSBhcyBPcE5vZGUpLm9wXSkge1xuICAgICAgICAgICAgICBmb3IgKGxldCBqID0gMTsgaiA8IGZyb21CZWdpbm5pbmdQYXRoTGlzdC5sZW5ndGg7IGorKykge1xuICAgICAgICAgICAgICAgIC8vIEV4cGFuZCBhbGwgaGllcmFyY2hpZXMgaW5jbHVkaW5nIHRoZSBwYXJlbnQuXG4gICAgICAgICAgICAgICAgY29uc3QgY3VycmVudE5vZGVOYW1lID0gZnJvbUJlZ2lubmluZ1BhdGhMaXN0XG4gICAgICAgICAgICAgICAgICAgIC5zbGljZSgwLCBqKS5qb2luKHRmLmdyYXBoLk5BTUVTUEFDRV9ERUxJTSk7XG4gICAgICAgICAgICAgICAgaWYgKCFjdXJyZW50Tm9kZU5hbWUpIHtcbiAgICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIC8vIEJ1aWxkIHRoZSBoaWVyYXJjaHkgZm9yIHRoaXMgY3VycmVudCBsZXZlbC5cbiAgICAgICAgICAgICAgICB0aGlzLmJ1aWxkU3ViaGllcmFyY2h5KGN1cnJlbnROb2RlTmFtZSk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLy8gTm8gbmVlZCB0byBhbmFseXplIHRoZSBvdGhlciBoaWdoZXIgaGllcmFyY2hpZXMuXG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH0pO1xuICB9XG59XG5cbi8qKlxuICogQSBjbGFzcyBmb3IgcmVuZGVyaW5nIGFubm90YXRpb24gb2JqZWN0IHdoaWNoIGNvbnRhaW5zIGxhYmVsXG4gKiBhYm91dCB0aGUgbm9kZSBlbWJlZGRlZCBhcyBhbm5vdGF0aW9uLCB0eXBlIG9mIGFubm90YXRpb24gYW5kIHRoZSBsb2NhdGlvblxuICogb2YgYm90aCB0aGUgYW5ub3RhdGlvbidzIG5vZGUgYW5kIGVkZ2UuXG4gKlxuICogQW5ub3RhdGlvbiBvYmplY3RzIGluY2x1ZGUgZW1iZWRkZWQgY29uc3RhbnRzLCBlbWJlZGRlZCBzdW1tYXJ5LCBhbmRcbiAqIGVkZ2Ugc2hvcnRjdXRzLlxuICovXG5leHBvcnQgY2xhc3MgQW5ub3RhdGlvbiB7XG4gIG5vZGU6IE5vZGU7XG4gIHJlbmRlck5vZGVJbmZvOiBSZW5kZXJOb2RlSW5mbztcbiAgcmVuZGVyTWV0YWVkZ2VJbmZvOiBSZW5kZXJNZXRhZWRnZUluZm87XG4gIGFubm90YXRpb25UeXBlOiBBbm5vdGF0aW9uVHlwZTtcbiAgLyoqXG4gICAqIENlbnRlciBwb3NpdGlvbiBvZiBhbm5vdGF0aW9uIHJlbGF0aXZlIHRvIHRoZSBob3N0XG4gICAqIG5vZGUncyBjZW50ZXIgeC5cbiAgICovXG4gIGR4OiBudW1iZXI7XG4gIC8qKlxuICAgKiBDZW50ZXIgcG9zaXRpb24gb2YgYW5ub3RhdGlvbiByZWxhdGl2ZSB0byB0aGUgaG9zdFxuICAgKiBub2RlJ3MgY2VudGVyIHkuXG4gICAqL1xuICBkeTogbnVtYmVyO1xuICB3aWR0aDogbnVtYmVyO1xuICBoZWlnaHQ6IG51bWJlcjtcbiAgLyoqXG4gICAqIFRoZSBuYW1lcyBvZiBub2RlcyBvbiBlaXRoZXIgc2lkZSBvZiB0aGlzIGVkZ2UuXG4gICAqL1xuICB2OiBzdHJpbmc7XG4gIHc6IHN0cmluZztcbiAgLyoqXG4gICAqIEEgZmxhZyB3aGV0aGVyIGl0IGlzIGFuIGluLWFubm90YXRpb24gKGlmIHRydWUpIG9yXG4gICAqIG91dC1hbm5vdGF0aW9uICAoaWYgZmFsc2UpLlxuICAgKi9cbiAgaXNJbjogYm9vbGVhbjtcbiAgLyoqIExhYmVsIGhvcml6b250YWwgb2Zmc2V0IGZyb20gdGhlIGVuZCBvZiB0aGUgbm9kZSBzaGFwZSAqL1xuICBsYWJlbE9mZnNldDogbnVtYmVyO1xuICAvKipcbiAgICogQXJyYXkgb2YgcG9pbnRzIGZvciBlZGdlcyBmcm9tIHRoZSBhbm5vdGF0aW9uIHRvIGl0cyBob3N0XG4gICAqIG5vZGUuIEVhY2ggcG9pbnQgY29udGFpbnMgdGhlIHBvaW50IGxvY2F0aW9uLCByZWxhdGl2ZSB0b1xuICAgKiB0aGUgaG9zdCBub2RlJ3MgY2VudGVyLlxuICAgKi9cbiAgcG9pbnRzOiB7ZHg6IG51bWJlciwgZHk6IG51bWJlcn1bXTtcblxuICAvKipcbiAgICogQ3JlYXRlcyBhIG5ldyBBbm5vdGF0aW9uLlxuICAgKlxuICAgKiBAcGFyYW0gbm9kZSBUaGUgdW5kZXJseWluZyBub2RlIHRoaXMgYW5ub3RhdGlvbiBwb2ludHMgdG8uXG4gICAqIEBwYXJhbSByZW5kZXJOb2RlSW5mbyBUaGUgcmVuZGVyIGluZm9ybWF0aW9uIGZvciB0aGUgdW5kZXJseWluZyBub2RlXG4gICAqICAgICB0aGlzIGFubm90YXRpb24gcG9pbnRzIHRvLiBUaGlzIGNhbiBiZSBudWxsIGlmIHRoZSBhbm5vdGF0aW9uXG4gICAqICAgICBkZW5vdGVzIGFuIGVtYmVkZGluZyAoY29uc3RhbnQsIHN1bW1hcnkpLCBpbiB3aGljaCBjYXNlIHdlXG4gICAqICAgICB1c2UgdGhlIG5vZGUgcHJvcGVydHkuXG4gICAqIEBwYXJhbSByZW5kZXJNZXRhZWRnZUluZm8gVGhlIHJlbmRlciBpbmZvcm1hdGlvbiBmb3IgdGhlIGVkZ2UgYXNzb2NpYXRlZFxuICAgKiAgICAgd2l0aCB0aGUgYW5ub3RhdGlvbi5cbiAgICogQHBhcmFtIHR5cGUgVGhlIHR5cGUgb2YgdGhlIGFubm90YXRpb24uXG4gICAqIEBwYXJhbSBpc0luIFRydWUgaWYgaXQgaXMgYW4gaW4tYW5ub3RhdGlvbi4gRmFsc2UgaWYgaXQgaXMgYW5cbiAgICogICAgIG91dC1hbm5vdGF0aW9uLlxuICAgKi9cbiAgY29uc3RydWN0b3Iobm9kZTogTm9kZSwgcmVuZGVyTm9kZUluZm86IFJlbmRlck5vZGVJbmZvLFxuICAgICAgcmVuZGVyTWV0YWVkZ2VJbmZvOiBSZW5kZXJNZXRhZWRnZUluZm8sIHR5cGU6IEFubm90YXRpb25UeXBlLFxuICAgICAgaXNJbjogYm9vbGVhbikge1xuICAgIHRoaXMubm9kZSA9IG5vZGU7XG4gICAgdGhpcy5yZW5kZXJOb2RlSW5mbyA9IHJlbmRlck5vZGVJbmZvO1xuICAgIHRoaXMucmVuZGVyTWV0YWVkZ2VJbmZvID0gcmVuZGVyTWV0YWVkZ2VJbmZvO1xuICAgIHRoaXMuYW5ub3RhdGlvblR5cGUgPSB0eXBlO1xuICAgIC8vIFByb3BlcnRpZXMgc3BlY2lmaWVkIGJ5IGxheW91dFxuICAgIHRoaXMuZHggPSAwO1xuICAgIHRoaXMuZHkgPSAwO1xuICAgIHRoaXMud2lkdGggPSAwO1xuICAgIHRoaXMuaGVpZ2h0ID0gMDtcbiAgICAvLyBQcm9wZXJ0aWVzIG5lZWRlZCBmb3IgZ2VuZXJhdGluZyBhbiBJRCBmb3IgdGhlIGVkZ2UncyBwYXRoIGVsZW1lbnQgaWZcbiAgICAvLyB0aGlzIGFubm90YXRpb24gaXMgYXNzb2NpYXRlZCB3aXRoIGEgbWV0YWVkZ2UuXG4gICAgaWYgKHJlbmRlck1ldGFlZGdlSW5mbyAmJiByZW5kZXJNZXRhZWRnZUluZm8ubWV0YWVkZ2UpIHtcbiAgICAgIHRoaXMudiA9IHJlbmRlck1ldGFlZGdlSW5mby5tZXRhZWRnZS52O1xuICAgICAgdGhpcy53ID0gcmVuZGVyTWV0YWVkZ2VJbmZvLm1ldGFlZGdlLnc7XG4gICAgfVxuXG4gICAgdGhpcy5pc0luID0gaXNJbjtcbiAgICB0aGlzLnBvaW50cyA9IFtdO1xuICB9XG59O1xuXG5leHBvcnQgZW51bSBBbm5vdGF0aW9uVHlwZSB7U0hPUlRDVVQsIENPTlNUQU5ULCBTVU1NQVJZLCBFTExJUFNJU307XG5cbi8qKlxuICogTWFuYWdlcyBhIGxpc3Qgb2YgYW5ub3RhdGlvbnMuIFR3byB3aWxsIGJlIHVzZWQgZm9yIGVhY2hcbiAqIFJlbmRlck5vZGVJbmZvLCBvbmUgZm9yIGluIGFubm90YXRpb25zIGFuZCBvbmUgZm9yIG91dCBhbm5vdGF0aW9ucy5cbiAqL1xuZXhwb3J0IGNsYXNzIEFubm90YXRpb25MaXN0IHtcbiAgLyoqXG4gICAqIExpc3Qgb2YgdmlzdWFsbHkgZHJhd2FibGUgYW5ub3RhdGlvbnMsIG1heSBpbmNsdWRlIGFuIGVsbGlwc2VzIGFubm90YXRpb25cbiAgICogaWYgdGhlIG51bWJlciBhZGRlZCBleGNlZWRzIHRoZSBudW1iZXIgc3BlY2lmaWVkIGJ5IG1heEFubm90YXRpb25zLlxuICAgKi9cbiAgbGlzdDogQW5ub3RhdGlvbltdO1xuXG4gIC8qKlxuICAgKiBTZXQgb2Ygbm9kZXMgd2hpY2ggaGF2ZSBiZWVuIGFkZGVkIGFzIGFubm90YXRpb25zIHRvIHRoaXMgbGlzdCwgc28gd2UgY2FuXG4gICAqIHByZXZlbnQgZHVwbGljYXRlcy5cbiAgICovXG4gIG5vZGVOYW1lczogeyBbbm9kZU5hbWU6IHN0cmluZ106IGJvb2xlYW4gfTtcblxuICBjb25zdHJ1Y3RvcigpIHtcbiAgICB0aGlzLmxpc3QgPSBbXTtcbiAgICB0aGlzLm5vZGVOYW1lcyA9IHt9O1xuICB9XG5cbiAgLyoqXG4gICAqIEFwcGVuZCBhbiBhbm5vdGF0aW9uIHRvIHRoZSBsaXN0LCBvciBhIHN0YW5kLWluIGVsbGlwc2lzIGFubm90YXRpb24gaW5zdGVhZFxuICAgKiBpZiB0aGlzIHdvdWxkIG1ha2UgaXQgdG9vIG1hbnkuXG4gICAqL1xuICBwdXNoKGFubm90YXRpb246IEFubm90YXRpb24pOiB2b2lkIHtcbiAgICBpZiAoYW5ub3RhdGlvbi5ub2RlLm5hbWUgaW4gdGhpcy5ub2RlTmFtZXMpIHtcbiAgICAgIHJldHVybjsgLy8gU2tpcCBkdXBsaWNhdGUgYW5ub3RhdGlvbi5cbiAgICB9XG4gICAgdGhpcy5ub2RlTmFtZXNbYW5ub3RhdGlvbi5ub2RlLm5hbWVdID0gdHJ1ZTtcblxuICAgIGlmICh0aGlzLmxpc3QubGVuZ3RoIDwgUEFSQU1TLm1heEFubm90YXRpb25zKSB7XG4gICAgICB0aGlzLmxpc3QucHVzaChhbm5vdGF0aW9uKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBsZXQgbGFzdEFubm90YXRpb24gPSB0aGlzLmxpc3RbdGhpcy5saXN0Lmxlbmd0aCAtIDFdO1xuICAgIGlmIChsYXN0QW5ub3RhdGlvbi5hbm5vdGF0aW9uVHlwZSA9PT0gQW5ub3RhdGlvblR5cGUuRUxMSVBTSVMpIHtcbiAgICAgIGxldCBlbGxpcHNpc05vZGUgPSA8RWxsaXBzaXNOb2RlPmxhc3RBbm5vdGF0aW9uLm5vZGU7XG4gICAgICBlbGxpcHNpc05vZGUuc2V0TnVtTW9yZU5vZGVzKCsrZWxsaXBzaXNOb2RlLm51bU1vcmVOb2Rlcyk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgbGV0IGVsbGlwc2lzTm9kZSA9IG5ldyB0Zi5ncmFwaC5FbGxpcHNpc05vZGVJbXBsKDEpO1xuICAgIHRoaXMubGlzdC5wdXNoKG5ldyBBbm5vdGF0aW9uKGVsbGlwc2lzTm9kZSxcbiAgICAgICAgbmV3IFJlbmRlck5vZGVJbmZvKGVsbGlwc2lzTm9kZSksIG51bGwsXG4gICAgICAgIEFubm90YXRpb25UeXBlLkVMTElQU0lTLCBhbm5vdGF0aW9uLmlzSW4pKTtcbiAgfVxufVxuXG4vKipcbiAqIENvbnRhaW5zIHJlbmRlcmluZyBpbmZvcm1hdGlvbiBhYm91dCBhIG5vZGUgaW4gdGhlIGhpZXJhcmNoaWNhbCBncmFwaC5cbiAqL1xuZXhwb3J0IGNsYXNzIFJlbmRlck5vZGVJbmZvIHtcbiAgLyoqIFJlZmVyZW5jZSB0byB0aGUgb3JpZ2luYWwgdW5kZXJseWluZyBOb2RlIGZyb20gdGhlIGhpZXJhcmNoaWNhbCBncmFwaC4gKi9cbiAgbm9kZTogTm9kZTtcbiAgLyoqIFdoZXRoZXIgdGhlIG5vZGUgaXMgZXhwYW5kZWQgb3Igbm90LiAqL1xuICBleHBhbmRlZDogYm9vbGVhbjtcbiAgLyoqXG4gICAqIExpc3Qgb2YgcmVuZGVyaW5nIGluZm9ybWF0aW9uIGFib3V0IGluLWFubm90YXRpb25zIGxpa2UgY29uc3RhbnRzIGFuZFxuICAgKiBzaG9ydGN1dHMgdG8gaGlnaC1kZWdyZWUgbm9kZXMuXG4gICAqL1xuICBpbkFubm90YXRpb25zOiBBbm5vdGF0aW9uTGlzdDtcbiAgLyoqXG4gICAqIExpc3Qgb2YgcmVuZGVyaW5nIGluZm9ybWF0aW9uIGFib3V0IG91dC1hbm5vdGF0aW9ucyAoZS5nLiBzdW1tYXJ5IG5vZGVzKVxuICAgKi9cbiAgb3V0QW5ub3RhdGlvbnM6IEFubm90YXRpb25MaXN0O1xuXG4gIC8vIC0tLSBQYXJhbXMgc3BlY2lmaWVkIGJ5IGxheW91dCAtLS0gLy9cblxuICAvKiogQ2VudGVyIHggcG9zaXRpb24gKi9cbiAgeDogbnVtYmVyO1xuICAvKiogQ2VudGVyIHkgcG9zaXRpb24gKi9cbiAgeTogbnVtYmVyO1xuICAvKipcbiAgICogVG90YWwgd2lkdGggb2YgdGhlIG5vZGUncyBzaGFwZSwgaW5jbHVkaW5nIGluLSBhbmQgb3V0LWFubm90YXRpb25zLiBUaGlzXG4gICAqIHByb3BlcnR5IGlzIHVzZWQgYnkgZGFncmUgdG8gbGF5b3V0IHRoZSBncmFwaC5cbiAgICovXG4gIHdpZHRoOiBudW1iZXI7XG4gIC8qKlxuICAgKiBUb3RhbCBoZWlnaHQgb2YgdGhlIG5vZGUncyBzaGFwZSwgaW5jbHVkaW5nIGluLSBhbmQgb3V0LWFubm90YXRpb25zLiBUaGlzXG4gICAqIHByb3BlcnR5IGlzIHVzZWQgYnkgZGFncmUgdG8gbGF5b3V0IHRoZSBncmFwaC5cbiAgICovXG4gIGhlaWdodDogbnVtYmVyO1xuICAvKipcbiAgICogU2l6ZSBvZiB0aGUgbWFpbiBib3ggb2YgdGhlIG5vZGUsIGV4Y2x1ZGluZyBpbi0gYW5kIG91dC1hbm5vdGF0aW9ucy4gVGhpc1xuICAgKiBwcm9wZXJ0eSBpcyB1c2VkIHRvIGRyYXcgdGhlIHJlY3RhbmdsZS9lbGxpcHNlIHNoYXBlIGRlbm90aW5nIHRoZSBub2RlLlxuICAgKi9cbiAgY29yZUJveDoge1xuICAgIHdpZHRoOiBudW1iZXIsXG4gICAgaGVpZ2h0OiBudW1iZXIsXG4gIH07XG5cbiAgLyoqIFdpZHRoIG9mIHRoZSBib3VuZGluZyBib3ggZm9yIGFsbCBpbi1hbm5vdGF0aW9ucy4gKi9cbiAgaW5ib3hXaWR0aDogbnVtYmVyO1xuICAvKiogV2lkdGggb2YgdGhlIGJvdW5kaW5nIGJveCBmb3IgYWxsIG91dC1hbm5vdGF0aW9ucy4gKi9cbiAgb3V0Ym94V2lkdGg6IG51bWJlcjtcbiAgLyoqXG4gICAqIFdoZXRoZXIgdGhlIG5vZGUgc2hvdWxkIGJlIGV4Y2x1ZGVkIGZyb20gdGhlIHNjZW5lLlxuICAgKiBUaGlzIGlzIG9ubHkgdXNlZCB3aGVuIHRoZXJlIGFyZSB0b28gbWFueSBpdGVtcyBpbiBhIHNlcmllcyBzbyB3ZSBvbmx5XG4gICAqIHdhbnQgdG8gaW5jbHVkZSB0b3AgTiBvbmVzLlxuICAgKi9cbiAgLy8gVE9ETzogTm93IHRoYXQgc2VyaWVzIHJlbmRlcmluZyBpcyBub24tcmVjdXJzaXZlLCByZW1vdmUgdGhpcyBhbmRcbiAgLy8gYWxsIGl0cyB1c2VzIGZyb20gdGhlIGNvZGUgYmFzZS5cbiAgZXhjbHVkZWQ6IGJvb2xlYW47XG5cbiAgLy8gLS0tIFBhcmFtcyB1c2VkIGluIGRyYXdpbmcgdGhlIGJyaWRnZSBwYXRocyAtLS0gLy9cblxuICAvKipcbiAgICogQWxsIGJyaWRnZSBub2RlcyBhcmUgbWVhbnQgdG8gYmUgaW52aXNpYmxlLCBidXQgd2hlcmVhcyBtb3N0IHJlcHJlc2VudCBhXG4gICAqIHJlbGF0aW9uc2hpcCBmcm9tIHRoZSB1bmRlcmx5aW5nIGdyYXBoIGhpZXJhcmNoeSwgc29tZSBleGlzdCBzb2xlbHkgZm9yXG4gICAqIGxheW91dCByZWFzb25zLiBTcGVjaWZpY2FsbHksIHRob3NlIGJyaWRnZSBub2RlcyB3aGljaCBoYXZlIG9ubHkgc3RydWN0dXJhbFxuICAgKiByZW5kZXJpbmcgbWV0YWVkZ2VzLlxuICAgKi9cbiAgc3RydWN0dXJhbDogYm9vbGVhbjtcblxuICAvLyAtLS0gUGFyYW1zIGZvciB0aGUgc2l6ZSBvZiB0aGUgbm9kZSBib3ggLS0tIC8vXG5cbiAgLyoqIExhYmVsIHZlcnRpY2FsIG9mZnNldCBmcm9tIHRoZSBjZW50ZXIgb2Ygbm9kZSBzaGFwZSAqL1xuICBsYWJlbE9mZnNldDogbnVtYmVyO1xuICAvKiogUmVjdGFuZ2xlIHJhZGl1cyAoZm9yIG1ha2luZyByb3VuZGVkIHJlY3RhbmdsZSkgKi9cbiAgcmFkaXVzOiBudW1iZXI7XG5cbiAgLy8gLS0tIFBhcmFtcyBmb3IgZXhwYW5kZWQgbm9kZSAtLS0gLy9cblxuICAvKiogTGFiZWwgaGVpZ2h0IGZvciBleHBhbmRlZCBub2RlLiAqL1xuICBsYWJlbEhlaWdodDogbnVtYmVyO1xuICAvLyBQYWRkaW5ncyBiZXR3ZWVuIGlubmVyIHN1YnNjZW5lIGFuZCB0aGUgYm9yZGVyIG9mIHRoZSBleHBhbmRlZCBub2RlLlxuICBwYWRkaW5nVG9wOiBudW1iZXI7XG4gIHBhZGRpbmdMZWZ0OiBudW1iZXI7XG4gIHBhZGRpbmdSaWdodDogbnVtYmVyO1xuICBwYWRkaW5nQm90dG9tOiBudW1iZXI7XG5cbiAgLyoqXG4gICAqIFdoZXRoZXIgYSBub2RlIGlzIGV4dHJhY3RlZCBhcyBzb3VyY2UtbGlrZSAoaGF2aW5nIGhpZ2ggb3V0LWRlZ3JlZSBvclxuICAgKiBtYXRjaGluZyBwcmVkZWZpbmVkIGluLWV4dHJhY3QgcGF0dGVybi4pXG4gICAqL1xuICBpc0luRXh0cmFjdDogYm9vbGVhbjtcbiAgLyoqXG4gICAqIFdoZXRoZXIgYSBub2RlIGlzIGV4dHJhY3RlZCBhcyBzaW5rLWxpa2UgKGhhdmluZyBoaWdoIGluLWRlZ3JlZSBvciBtYXRjaGluZ1xuICAgKiBwcmVkZWZpbmVkIG91dC1leHRyYWN0IHBhdHRlcm4uKVxuICAgKi9cbiAgaXNPdXRFeHRyYWN0OiBib29sZWFuO1xuXG4gIC8qKlxuICAgKiBXaGV0aGVyIGEgbm9kZSByZXByZXNlbnRzIGEgZnVuY3Rpb24gdGVtcGxhdGUgd2l0aGluIHRoZSBsaWJyYXJ5LCBpbiB3aGljaFxuICAgKiBjYXNlIGl0IHNob3VsZCBiZSByZW5kZXJlZCBpbiBhIHNwZWNpYWwgc2NlbmUgZ3JvdXAuXG4gICAqL1xuICBpc0xpYnJhcnlGdW5jdGlvbjogYm9vbGVhbjtcblxuICAvKipcbiAgICogTGlzdCBvZiAoY29sb3IsIHByb3BvcnRpb24pIHR1cGxlcyBiYXNlZCBvbiB0aGUgcHJvcG9ydGlvbiBvZiBkZXZpY2VzIG9mXG4gICAqIGl0cyBjaGlsZHJlbi4gSWYgdGhpcyBub2RlIGlzIGFuIG9wIG5vZGUsIHRoaXMgbGlzdCB3aWxsIGhhdmUgb25seSBvbmVcbiAgICogY29sb3Igd2l0aCBwcm9wb3J0aW9uIDEuMC5cbiAgICovXG4gIGRldmljZUNvbG9yczogQXJyYXk8e2NvbG9yOiBzdHJpbmcsIHByb3BvcnRpb246IG51bWJlcn0+O1xuXG4gIC8qKlxuICAgKiBMaXN0IG9mIChjb2xvciwgcHJvcG9ydGlvbikgdHVwbGVzIGJhc2VkIG9uIHRoZSBwcm9wb3J0aW9uIG9mIHhsYUNsdXN0ZXJzXG4gICAqIG9mIGl0cyBjaGlsZHJlbi4gSWYgdGhpcyBub2RlIGlzIGFuIG9wIG5vZGUsIHRoaXMgbGlzdCB3aWxsIGhhdmUgb25seSBvbmVcbiAgICogY29sb3Igd2l0aCBwcm9wb3J0aW9uIDEuMC5cbiAgICovXG4gIHhsYUNsdXN0ZXJDb2xvcnM6IEFycmF5PHtjb2xvcjogc3RyaW5nLCBwcm9wb3J0aW9uOiBudW1iZXJ9PjtcblxuICAvKipcbiAgICogTGlzdCBvZiAoY29sb3IsIHByb3BvcnRpb24pIHR1cGxlcyBiYXNlZCBvbiB0aGUgcHJvcG9ydGlvbiBvZiBjb21wYXRpYmxlXG4gICAqIG5vZGVzIG9mIGl0cyBjaGlsZHJlbi4gSWYgdGhpcyBub2RlIGlzIGFuIG9wIG5vZGUsIHRoaXMgbGlzdCB3aWxsIGhhdmUgb25seVxuICAgKiBvbmUgY29sb3Igd2l0aCBwcm9wb3J0aW9uIDEuMC5cbiAgICovXG4gIGNvbXBhdGliaWxpdHlDb2xvcnM6IEFycmF5PHtjb2xvcjogc3RyaW5nLCBwcm9wb3J0aW9uOiBudW1iZXJ9PjtcblxuICAvKipcbiAgICogQ29sb3IgYWNjb3JkaW5nIHRvIHRoZSBtZW1vcnkgdXNhZ2Ugb2YgdGhpcyBub2RlLlxuICAgKi9cbiAgbWVtb3J5Q29sb3I6IHN0cmluZztcblxuICAvKipcbiAgICogQ29sb3IgYWNjb3JkaW5nIHRvIHRoZSBjb21wdXRlIHRpbWUgb2YgdGhpcyBub2RlLlxuICAgKi9cbiAgY29tcHV0ZVRpbWVDb2xvcjogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBXaGV0aGVyIHRoaXMgbm9kZSBpcyBmYWRlZCBvdXQuIFVzZWQgd2hlbiBkaXNwbGF5aW5nIHN0YXRzLlxuICAgKi9cbiAgaXNGYWRlZE91dDogYm9vbGVhbjtcblxuICAvKipcbiAgICogVGhlIG5hbWUgc3RyaW5nIHVzZWQgdG8gbGFiZWwgdGhlIG5vZGUgaW4gdGhlIGdyYXBoLlxuICAgKi9cbiAgZGlzcGxheU5hbWU6IHN0cmluZztcblxuICBjb25zdHJ1Y3Rvcihub2RlOiBOb2RlKSB7XG4gICAgdGhpcy5ub2RlID0gbm9kZTtcbiAgICB0aGlzLmV4cGFuZGVkID0gZmFsc2U7XG4gICAgdGhpcy5pbkFubm90YXRpb25zID0gbmV3IEFubm90YXRpb25MaXN0KCk7XG4gICAgdGhpcy5vdXRBbm5vdGF0aW9ucyA9IG5ldyBBbm5vdGF0aW9uTGlzdCgpO1xuICAgIC8vIFBhcmFtcyBzcGVjaWZpZWQgYnkgbGF5b3V0XG4gICAgdGhpcy54ID0gMDtcbiAgICB0aGlzLnkgPSAwO1xuICAgIHRoaXMud2lkdGggPSAwO1xuICAgIHRoaXMuaGVpZ2h0ID0gMDtcbiAgICB0aGlzLmluYm94V2lkdGggPSAwO1xuICAgIHRoaXMub3V0Ym94V2lkdGggPSAwO1xuXG4gICAgdGhpcy5leGNsdWRlZCA9IGZhbHNlO1xuXG4gICAgLy8gUGFyYW1zIGZvciBicmlkZ2UgcGF0aHMuXG4gICAgdGhpcy5zdHJ1Y3R1cmFsID0gZmFsc2U7XG5cbiAgICAvLyBQYXJhbXMgZm9yIG5vZGUgYm94LlxuICAgIHRoaXMubGFiZWxPZmZzZXQgPSAwO1xuICAgIHRoaXMucmFkaXVzID0gMDtcblxuICAgIC8vIFBhcmFtcyBmb3IgZXhwYW5kZWQgbm9kZVxuICAgIHRoaXMubGFiZWxIZWlnaHQgPSAwO1xuICAgIHRoaXMucGFkZGluZ1RvcCA9IDA7XG4gICAgdGhpcy5wYWRkaW5nTGVmdCA9IDA7XG4gICAgdGhpcy5wYWRkaW5nUmlnaHQgPSAwO1xuICAgIHRoaXMucGFkZGluZ0JvdHRvbSA9IDA7XG4gICAgdGhpcy5pc0luRXh0cmFjdCA9IGZhbHNlO1xuICAgIHRoaXMuaXNPdXRFeHRyYWN0ID0gZmFsc2U7XG4gICAgdGhpcy5jb3JlQm94ID0ge3dpZHRoOiAwLCBoZWlnaHQ6IDB9O1xuXG4gICAgLy8gQnkgZGVmYXVsdCwgd2UgZG9uJ3QgZmFkZSBub2RlcyBvdXQuIERlZmF1bHQgdG8gZmFsc2UgZm9yIHNhZmV0eS5cbiAgICB0aGlzLmlzRmFkZWRPdXQgPSBmYWxzZTtcblxuICAgIC8vIE9ubHkgdXNlIHRoZSBwb3J0aW9uIGJleW9uZCB0aGUgbGFzdCBkZWxpbWl0ZXIgYXMgdGhlIGRpc3BsYXlcbiAgICAvLyBuYW1lLlxuICAgIHRoaXMuZGlzcGxheU5hbWUgPSBub2RlLm5hbWUuc3Vic3RyaW5nKFxuICAgICAgICBub2RlLm5hbWUubGFzdEluZGV4T2YodGYuZ3JhcGguTkFNRVNQQUNFX0RFTElNKSArIDEpO1xuXG4gICAgaWYgKG5vZGUudHlwZSA9PT0gTm9kZVR5cGUuTUVUQSAmJlxuICAgICAgICAobm9kZSBhcyBNZXRhbm9kZSkuYXNzb2NpYXRlZEZ1bmN0aW9uKSB7XG4gICAgICAvLyBGdW5jdGlvbiBuYW1lcyBhcmUgc3VmZml4ZWQgd2l0aCBhIGxlbmd0aC04IGhleGFkZWNpbWFsIHN0cmluZ1xuICAgICAgLy8gZm9sbG93ZWQgYnkgYW4gb3B0aW9uYWwgbnVtYmVyLiBXZSByZW1vdmUgdGhhdCBzdWZmaXggYmVjYXVzZVxuICAgICAgLy8gdGhlIHVzZXIgZGlkIG5vdCBnZW5lcmF0ZSB0aGF0IHN1ZmZpeC4gVGhhdCBzdWZmaXggbWVyZWx5XG4gICAgICAvLyBzZXJ2ZXMgdG8gZGlmZmVyZW50aWF0ZSBiZXR3ZWVuIGZ1bmN0aW9ucyB3aXRoIGRpZmZlcmVudFxuICAgICAgLy8gc2lnbmF0dXJlcyBidXQgdGhlIHNhbWUgbmFtZSBvdGhlcndpc2UuXG4gICAgICAvLyBGdXJ0aGVybW9yZSwgd2UgcmVtb3ZlIHRoZSBwcmVmaXggdGhhdCBtZXJlbHkgYXNjZXJ0YWlucyB0aGlzXG4gICAgICAvLyBub2RlIGFzIGEgZnVuY3Rpb24gZGVmaW5pdGlvbi4gVGhlcmUgaXMgbm8gcmVhc29uIGZvciB0aGUgdXNlclxuICAgICAgLy8gdG8gc2VlIHRoYXQgaW4gdGhlIGdyYXBoLCBhcyB0aGUgbm9kZSB3b3VsZCBhbHJlYWR5IGJlIHdpdGhpblxuICAgICAgLy8gdGhlIGZ1bmN0aW9ucyBzY2VuZSBncm91cC5cbiAgICAgIGNvbnN0IG1hdGNoID0gdGhpcy5kaXNwbGF5TmFtZS5tYXRjaChub2RlRGlzcGxheU5hbWVSZWdleCk7XG4gICAgICBpZiAobWF0Y2gpIHtcbiAgICAgICAgLy8gVGhlIGRpc3BsYXkgbmFtZSBoYWQgYmVlbiBzdWNjZXNzZnVsbHkgZXh0cmFjdGVkLiBUaGlzIGlzIHRoZSBtb3N0XG4gICAgICAgIC8vIGNvbW1vbiBzY2VuYXJpby5cbiAgICAgICAgdGhpcy5kaXNwbGF5TmFtZSA9IG1hdGNoWzFdO1xuICAgICAgfSBlbHNlIGlmIChfLnN0YXJ0c1dpdGgoXG4gICAgICAgICAgdGhpcy5kaXNwbGF5TmFtZSwgdGYuZ3JhcGguRlVOQ1RJT05fTElCUkFSWV9OT0RFX1BSRUZJWCkpIHtcbiAgICAgICAgLy8gVGhlIHN0cmluZyBkb2VzIG5vdCBtYXRjaCB0aGUgdXN1YWwgcGF0dGVybiBmb3IgaG93IGZ1bmN0aW9ucyBhcmVcbiAgICAgICAgLy8gbmFtZWQuIEp1c3QgdXNlIHRoZSBlbnRpcmUgc2Vjb25kIHBvcnRpb24gb2YgdGhlIHN0cmluZyBhcyB0aGUgbmFtZVxuICAgICAgICAvLyBpZiB3ZSBjYW4gc3VjY2Vzc2Z1bGx5IHJlbW92ZSB0aGUgcHJlZml4LlxuICAgICAgICB0aGlzLmRpc3BsYXlOYW1lID0gdGhpcy5kaXNwbGF5TmFtZS5zdWJzdHJpbmcoXG4gICAgICAgICAgICB0Zi5ncmFwaC5GVU5DVElPTl9MSUJSQVJZX05PREVfUFJFRklYLmxlbmd0aCk7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgaXNJbkNvcmUoKTogYm9vbGVhbiB7XG4gICAgcmV0dXJuICF0aGlzLmlzSW5FeHRyYWN0ICYmICF0aGlzLmlzT3V0RXh0cmFjdCAmJiAhdGhpcy5pc0xpYnJhcnlGdW5jdGlvbjtcbiAgfVxufVxuXG4vKipcbiAqIENvbnRhaW5zIHJlbmRlcmluZyBpbmZvcm1hdGlvbiBhYm91dCBhIE1ldGFlZGdlIGZyb20gdGhlIHVuZGVybHlpbmdcbiAqIGhpZXJhcmNoaWNhbCBncmFwaC4gSXQgbWF5IGJlIGZyb20gZWl0aGVyIGEgbWV0YWdyYXBoIG9yIGEgYnJpZGdlZ3JhcGguXG4gKi9cbmV4cG9ydCBjbGFzcyBSZW5kZXJNZXRhZWRnZUluZm8ge1xuICAvKipcbiAgICogUmVmZXJlbmNlIHRvIHRoZSBvcmlnaW5hbCB1bmRlcmx5aW5nIE1ldGFlZGdlIGZyb20gdGhlIGhpZXJhcmNoaWNhbCBncmFwaCxcbiAgICogaWYgYW55LiBUaGlzIHdpbGwgYmUgbnVsbCBmb3IgdGhlIGVkZ2VzIHdoaWNoIGNvbm5lY3QgT3BOb2RlcyB0byB0aGVpclxuICAgKiBlbWJlZGRpbmdzLCBmb3IgZXhhbXBsZS5cbiAgICovXG4gIG1ldGFlZGdlOiBNZXRhZWRnZTtcblxuICAvKipcbiAgICogUmVmZXJlbmNlIHRvIHRoZSBhZGpvaW5pbmcgUmVuZGVyTWV0YWVkZ2VJbmZvIGZyb20gdGhlIHBhcmVudCdzXG4gICAqIGNvcmVHcmFwaC4gVGhpcyBpcyB1c2VkIGR1cmluZyBsYXlvdXQgdG8gZGV0ZXJtaW5lIHRoZSBwb2ludCBhdCB3aGljaCB0aGlzXG4gICAqIGVkZ2Ugc2hvdWxkIHRvdWNoIHRoZSBub2RlJ3MgYm91bmRpbmcgYm94LiBUaGlzIHByb3BlcnR5IHdpbGwgYmUgbnVsbCBmb3JcbiAgICogZWRnZXMgd2hpY2ggdGVybWluYXRlIGF0IGEgbm9kZSBvbiBib3RoIGVuZHMgKGFsbCBub24tYnJpZGdlIGVkZ2VzKS5cbiAgICovXG4gIGFkam9pbmluZ01ldGFlZGdlOiBSZW5kZXJNZXRhZWRnZUluZm87XG5cbiAgLyoqXG4gICAqIE1vc3Qgb2YgdGhlIHRpbWUsIGEgUmVuZGVyTWV0YWVkZ2VJbmZvIG9iamVjdCByZXByZXNlbnRzIGEgcmVhbFxuICAgKiBlZGdlIGJldHdlZW4gbm9kZXMgaW4gdGhlIHVuZGVybHlpbmcgZ3JhcGggc3RydWN0dXJlLiBCdXQgc29tZXRpbWVzLCBhblxuICAgKiBlZGdlIG9ubHkgZXhpc3RzIGZvciBsYXlvdXQgcHVycG9zZXMuIFRoZXNlIHN0cnVjdHVyYWwgZWRnZXMgYXJlIGFkZGVkXG4gICAqIGR1cmluZyBidWlsZFN1YmhpZXJhcmNoeSgpIHRvIGZvcmNlIGRhZ3JlLmxheW91dCgpIHRvIHB1dCBicmlkZ2Ugbm9kZXNcbiAgICogYXQgdGhlIGVuZHMgb2YgdGhlIGZsb3cuXG4gICAqIEBzZWUgYnVpbGRTdWJoaWVyYXJjaHkoKVxuICAgKi9cbiAgc3RydWN0dXJhbDogYm9vbGVhbjtcblxuICAvKipcbiAgICogV2VpZ2h0IG9mIHRoZSBlZGdlLCB1c2VkIGJ5IGRhZ3JlIHdoZW4gZGVjaWRpbmcgaG93IGltcG9ydGFudCBhbiBlZGdlIGlzLlxuICAgKiBFZGdlcyB3aXRoIGhpZ2hlciB3ZWlnaHQgYXJlIG1hZGUgc2hvcnRlciBhbmQgc3RyYWlnaHRlci4gVGhlIGRlZmF1bHRcbiAgICogZGFncmUgdXNlcyBpcyAxLlxuICAgKi9cbiAgd2VpZ2h0OiBudW1iZXI7XG5cbiAgLyoqXG4gICAqIFggYW5kIFkgY29vcmRpbmF0ZSBwYWlycyBvZiB0aGUgcG9pbnRzIGluIHRoZSBwYXRoIG9mIHRoZSBlZGdlLlxuICAgKiBAc2VlIHRmLmdyYXBoLm5vZGUuc3Vic2NlbmVBZGp1c3RQYXRoc1xuICAgKi9cbiAgcG9pbnRzOiBQb2ludFtdO1xuXG4gIC8qKlxuICAgKiBEMyBzZWxlY3Rpb24gb2YgdGhlIGdyb3VwIGNvbnRhaW5pbmcgdGhlIHBhdGggdGhhdCBkaXNwbGF5cyB0aGlzIGVkZ2UuXG4gICAqL1xuICBlZGdlR3JvdXA6IGQzLlNlbGVjdGlvbjxSZW5kZXJNZXRhZWRnZUluZm8gJiBhbnksIGFueSwgYW55LCBhbnk+O1xuXG4gIC8qKiBJZCBvZiB0aGUgPG1hcmtlcj4gdXNlZCBhcyBhIHN0YXJ0LW1hcmtlciBmb3IgdGhlIGVkZ2UgcGF0aC4gKi9cbiAgc3RhcnRNYXJrZXJJZDogc3RyaW5nO1xuXG4gIC8qKiBJZCBvZiB0aGUgPG1hcmtlcj4gdXNlZCBhcyBhbiBlbmQtbWFya2VyIGZvciB0aGUgZWRnZSBwYXRoLiAqL1xuICBlbmRNYXJrZXJJZDogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBXaGV0aGVyIHRoaXMgZWRnZSBpcyBmYWRlZCBvdXQuIFVzZWQgZm9yIGZhZGluZyBvdXQgdW51c2VkIGVkZ2VzIHdoZW5cbiAgICogZGlzcGxheWluZyBydW4gc3RhdGlzdGljcy5cbiAgICovXG4gIGlzRmFkZWRPdXQ6IGJvb2xlYW47XG5cbiAgY29uc3RydWN0b3IobWV0YWVkZ2U6IE1ldGFlZGdlKSB7XG4gICAgdGhpcy5tZXRhZWRnZSA9IG1ldGFlZGdlO1xuICAgIHRoaXMuYWRqb2luaW5nTWV0YWVkZ2UgPSBudWxsO1xuICAgIHRoaXMuc3RydWN0dXJhbCA9IGZhbHNlO1xuICAgIHRoaXMud2VpZ2h0ID0gMTtcbiAgICB0aGlzLmlzRmFkZWRPdXQgPSBmYWxzZTtcbiAgfVxufVxuXG5mdW5jdGlvbiBhZGRJbkFubm90YXRpb24obm9kZTogUmVuZGVyTm9kZUluZm8sIHByZWRlY2Vzc29yOiBOb2RlLFxuICAgIHByZWRlY2Vzc29yUmVuZGVySW5mbzogUmVuZGVyTm9kZUluZm8sXG4gICAgZWRnZTogUmVuZGVyTWV0YWVkZ2VJbmZvLCB0eXBlOiBBbm5vdGF0aW9uVHlwZSk6IHZvaWQge1xuICBsZXQgYW5ub3RhdGlvbiA9IG5ldyBBbm5vdGF0aW9uKHByZWRlY2Vzc29yLCBwcmVkZWNlc3NvclJlbmRlckluZm8sIGVkZ2UsXG4gICAgICB0eXBlLCB0cnVlKTtcbiAgbm9kZS5pbkFubm90YXRpb25zLnB1c2goYW5ub3RhdGlvbik7XG59XG5cbmZ1bmN0aW9uIGFkZE91dEFubm90YXRpb24obm9kZTogUmVuZGVyTm9kZUluZm8sIHN1Y2Nlc3NvcjogTm9kZSxcbiAgICBzdWNjZXNzb3JSZW5kZXJJbmZvOiBSZW5kZXJOb2RlSW5mbywgZWRnZTogUmVuZGVyTWV0YWVkZ2VJbmZvLFxuICAgIHR5cGU6IEFubm90YXRpb25UeXBlKTogdm9pZCB7XG4gIGxldCBhbm5vdGF0aW9uID0gbmV3IEFubm90YXRpb24oc3VjY2Vzc29yLCBzdWNjZXNzb3JSZW5kZXJJbmZvLCBlZGdlLFxuICAgICAgdHlwZSwgZmFsc2UpO1xuICBub2RlLm91dEFubm90YXRpb25zLnB1c2goYW5ub3RhdGlvbik7XG59XG5cbmZ1bmN0aW9uIHNldEdyYXBoRGVwdGgoZ3JhcGg6IGdyYXBobGliLkdyYXBoPFJlbmRlck5vZGVJbmZvLCBhbnk+LFxuICAgIGRlcHRoOiBudW1iZXIpIHtcbiAgXy5lYWNoKGdyYXBoLm5vZGVzKCksIG5vZGVOYW1lID0+IHtcbiAgICBsZXQgY2hpbGQgPSBncmFwaC5ub2RlKG5vZGVOYW1lKTtcbiAgICBjaGlsZC5leHBhbmRlZCA9IGRlcHRoID4gMTsgLy8gc2V0IGFsbCBjaGlsZCBvZiBkZXB0aCAxIHRvIGNvbGxhcHNlZFxuICAgIGlmIChkZXB0aCA+IDApIHtcbiAgICAgIHN3aXRjaCAoY2hpbGQubm9kZS50eXBlKSB7XG4gICAgICAgIGNhc2UgTm9kZVR5cGUuTUVUQTpcbiAgICAgICAgY2FzZSBOb2RlVHlwZS5TRVJJRVM6XG4gICAgICAgICAgc2V0R3JvdXBOb2RlRGVwdGgoPFJlbmRlckdyb3VwTm9kZUluZm8+Y2hpbGQsIGRlcHRoIC0gMSk7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIC8vIERvIG5vdGhpbmcgZm9yIGxlYWZcbiAgICAgIH1cbiAgICB9XG4gIH0pO1xufTtcblxuZXhwb3J0IGNsYXNzIFJlbmRlckdyb3VwTm9kZUluZm8gZXh0ZW5kcyBSZW5kZXJOb2RlSW5mbyB7XG4gIG5vZGU6IEdyb3VwTm9kZTtcbiAgLyoqXG4gICAqIFRoZSBjb3JlIGdyYXBoIGlzIGRlcml2ZWQgZnJvbSB0aGUgdW5kZXJseWluZyBub2RlJ3MgbWV0YWdyYXBoLCBtaW51c1xuICAgKiB0aGUgZXh0cmFjdGVkIHNvdXJjZS1saWtlIGFuZCBzaW5rLWxpa2Ugbm9kZXMuXG4gICAqL1xuICBjb3JlR3JhcGg6IGdyYXBobGliLkdyYXBoPFJlbmRlck5vZGVJbmZvLCBSZW5kZXJNZXRhZWRnZUluZm8+O1xuICAvKiogU2l6ZSBvZiB0aGUgYm91bmRpbmcgYm94IGZvciBhIG1ldGFub2RlJ3MgaXNvbGF0ZWQgaW4tZXh0cmFjdCBjaGlsZHJlbi4gKi9cbiAgaW5FeHRyYWN0Qm94OiB7d2lkdGg6IG51bWJlciwgaGVpZ2h0OiBudW1iZXJ9O1xuICAvKipcbiAgICogU2l6ZSBvZiB0aGUgYm91bmRpbmcgYm94IGZvciBhIG1ldGFub2RlJ3MgaXNvbGF0ZWQgb3V0LWV4dHJhY3QgY2hpbGRyZW4uXG4gICAqL1xuICBvdXRFeHRyYWN0Qm94OiB7d2lkdGg6IG51bWJlciwgaGVpZ2h0OiBudW1iZXJ9O1xuICAvKiogU2l6ZSBvZiB0aGUgYm91bmRpbmcgYm94IGZvciB0aGUgZnVuY3Rpb24gbGlicmFyeS4gKi9cbiAgbGlicmFyeUZ1bmN0aW9uc0JveDoge3dpZHRoOiBudW1iZXIsIGhlaWdodDogbnVtYmVyfTtcbiAgLyoqIEFycmF5IG9mIGlzb2xhdGVkIGluLWV4dHJhY3Qgbm9kZXMuICovXG4gIGlzb2xhdGVkSW5FeHRyYWN0OiBSZW5kZXJOb2RlSW5mb1tdO1xuICAvKiogQXJyYXkgb2YgaXNvbGF0ZWQgb3V0LWV4dHJhY3Qgbm9kZXMuICovXG4gIGlzb2xhdGVkT3V0RXh0cmFjdDogUmVuZGVyTm9kZUluZm9bXTtcbiAgLyoqIEFycmF5IG9mIG5vZGVzIHRvIHNob3cgaW4gdGhlIGZ1bmN0aW9uIGxpYnJhcnkgc2NlbmUgZ3JvdXAuICovXG4gIGxpYnJhcnlGdW5jdGlvbnNFeHRyYWN0OiBSZW5kZXJOb2RlSW5mb1tdO1xuXG4gIGNvbnN0cnVjdG9yKGdyb3VwTm9kZTogR3JvdXBOb2RlLCBncmFwaE9wdGlvbnM6IGdyYXBobGliLkdyYXBoT3B0aW9ucykge1xuICAgIHN1cGVyKGdyb3VwTm9kZSk7XG4gICAgbGV0IG1ldGFncmFwaCA9IGdyb3VwTm9kZS5tZXRhZ3JhcGg7XG4gICAgbGV0IGdsID0gbWV0YWdyYXBoLmdyYXBoKCk7XG4gICAgZ3JhcGhPcHRpb25zLmNvbXBvdW5kID0gdHJ1ZTtcbiAgICB0aGlzLmNvcmVHcmFwaCA9XG4gICAgICAgIGNyZWF0ZUdyYXBoPFJlbmRlck5vZGVJbmZvLCBSZW5kZXJNZXRhZWRnZUluZm8+KFxuICAgICAgICAgICAgZ2wubmFtZSwgR3JhcGhUeXBlLkNPUkUsIGdyYXBoT3B0aW9ucyk7XG4gICAgdGhpcy5pbkV4dHJhY3RCb3ggPSB7d2lkdGg6IDAsIGhlaWdodDogMH07XG4gICAgdGhpcy5vdXRFeHRyYWN0Qm94ID0ge3dpZHRoOiAwLCBoZWlnaHQ6IDB9O1xuICAgIHRoaXMubGlicmFyeUZ1bmN0aW9uc0JveCA9IHt3aWR0aDogMCwgaGVpZ2h0OiAwfTtcbiAgICB0aGlzLmlzb2xhdGVkSW5FeHRyYWN0ID0gW107XG4gICAgdGhpcy5pc29sYXRlZE91dEV4dHJhY3QgPSBbXTtcbiAgICB0aGlzLmxpYnJhcnlGdW5jdGlvbnNFeHRyYWN0ID0gW107XG4gIH1cbn1cblxuZnVuY3Rpb24gc2V0R3JvdXBOb2RlRGVwdGgocmVuZGVySW5mbzogUmVuZGVyR3JvdXBOb2RlSW5mbyxcbiAgICBkZXB0aDogbnVtYmVyKTogdm9pZCB7XG4gIGlmIChyZW5kZXJJbmZvLmNvcmVHcmFwaCkge1xuICAgIHNldEdyYXBoRGVwdGgocmVuZGVySW5mby5jb3JlR3JhcGgsIGRlcHRoKTtcbiAgfVxufVxuXG4vKipcbiAqIFJlbW92ZSBhbiBlZGdlIGZyb20gdGhlIGdyYXBoIGFuZCBhZGQgYW5ub3RhdGlvbnMgdG8gYm90aCBlbmRzIG9mIHRoZSBlZGdlLlxuICpcbiAqIEBwYXJhbSBUaGUgY29yZSBncmFwaC5cbiAqIEBwYXJhbSB2IFNvdXJjZSBuYW1lLlxuICogQHBhcmFtIHcgU2luayBuYW1lLlxuICovXG5mdW5jdGlvbiBjcmVhdGVTaG9ydGN1dChcbiAgICBncmFwaDogZ3JhcGhsaWIuR3JhcGg8UmVuZGVyTm9kZUluZm8sIFJlbmRlck1ldGFlZGdlSW5mbz4sXG4gICAgdjogc3RyaW5nLCB3OiBzdHJpbmcpIHtcbiAgbGV0IHNyYyA9IGdyYXBoLm5vZGUodik7XG4gIGxldCBzaW5rID0gZ3JhcGgubm9kZSh3KTtcbiAgbGV0IGVkZ2UgPSBncmFwaC5lZGdlKHYsIHcpO1xuXG4gIC8vIElmIGVpdGhlciBvZiB0aGUgbm9kZXMgaXMgZXhwbGljaXRseSBpbmNsdWRlZCBpbiB0aGUgbWFpbiBncmFwaCBhbmRcbiAgLy8gYm90aCBub2RlcyBhcmUgaW4gdGhlIG1haW4gZ3JhcGggdGhlbiBkbyBub3QgY3JlYXRlIHRoZSBzaG9ydGN1dFxuICAvLyBhbmQgaW5zdGVhZCBrZWVwIHRoZSByZWFsIGVkZ2UuXG4gIGlmICgoc3JjLm5vZGUuaW5jbHVkZSA9PT0gSW5jbHVzaW9uVHlwZS5JTkNMVURFIHx8XG4gICAgICAgc2luay5ub2RlLmluY2x1ZGUgPT09IEluY2x1c2lvblR5cGUuSU5DTFVERSkgJiZcbiAgICAgIHNyYy5ub2RlLmluY2x1ZGUgIT09IEluY2x1c2lvblR5cGUuRVhDTFVERSAmJlxuICAgICAgc2luay5ub2RlLmluY2x1ZGUgIT09IEluY2x1c2lvblR5cGUuRVhDTFVERSkge1xuICAgIHJldHVybjtcbiAgfVxuXG4gIC8vIEFkZCBlYWNoIGFubm90YXRpb24uXG4gIGFkZE91dEFubm90YXRpb24oc3JjLCBzaW5rLm5vZGUsIHNpbmssIGVkZ2UsIEFubm90YXRpb25UeXBlLlNIT1JUQ1VUKTtcbiAgYWRkSW5Bbm5vdGF0aW9uKHNpbmssIHNyYy5ub2RlLCBzcmMsIGVkZ2UsIEFubm90YXRpb25UeXBlLlNIT1JUQ1VUKTtcblxuICAvLyBSZW1vdmUgdGhlIGVkZ2UgZnJvbSB0aGUgY29yZSBncmFwaC5cbiAgZ3JhcGgucmVtb3ZlRWRnZSh2LCB3KTtcbn1cblxuLyoqXG4gKiBSZW1vdmUgZWRnZXMgZnJvbSBhIG5vZGUsIGFuZCBzZXQgaXRzIGlzT3V0RXh0cmFjdCBwcm9wZXJ0eSB0byB0cnVlLFxuICogYW5kIHJlbW92ZSB0aGUgbm9kZSBhbmQgbW92ZSBpdCB0byBpc29sYXRlZE91dEV4dHJhY3QuXG4gKlxuICogSWYgZGV0YWNoQWxsRWRnZXNGb3JIaWdoRGVncmVlIG9yIGZvcmNlRGV0YWNoIGlzIHRydWUsIGV4dHJhY3QgYWxsIG9mIGl0c1xuICogZWRnZXMuIE90aGVyd2lzZSwgb25seSBleHRyYWN0IGFsbCBpbi1lZGdlcy5cbiAqL1xuZnVuY3Rpb24gbWFrZU91dEV4dHJhY3QocmVuZGVyTm9kZTogUmVuZGVyR3JvdXBOb2RlSW5mbywgbjogc3RyaW5nLFxuICAgIGZvcmNlRGV0YWNoPzogYm9vbGVhbikge1xuICBsZXQgZ3JhcGggPSByZW5kZXJOb2RlLmNvcmVHcmFwaDtcbiAgbGV0IGNoaWxkID0gZ3JhcGgubm9kZShuKTtcbiAgY2hpbGQuaXNPdXRFeHRyYWN0ID0gdHJ1ZTtcblxuICBfLmVhY2goZ3JhcGgucHJlZGVjZXNzb3JzKG4pLCAocCwgaW5kZXgpID0+IHtcbiAgICBjcmVhdGVTaG9ydGN1dChncmFwaCwgcCwgbik7XG4gIH0pO1xuXG4gIGlmIChQQVJBTVMuZGV0YWNoQWxsRWRnZXNGb3JIaWdoRGVncmVlIHx8IGZvcmNlRGV0YWNoKSB7XG4gICAgXy5lYWNoKGdyYXBoLnN1Y2Nlc3NvcnMobiksIChzLCBpbmRleCkgPT4ge1xuICAgICAgY3JlYXRlU2hvcnRjdXQoZ3JhcGgsIG4sIHMpO1xuICAgIH0pO1xuICB9XG5cbiAgLy8gUmVtb3ZlIHRoZSBub2RlIGZyb20gdGhlIGNvcmUgZ3JhcGggaWYgaXQgbm8gbG9uZ2VyIGhhcyBuZWlnaGJvcnMuXG4gIGlmIChncmFwaC5uZWlnaGJvcnMobikubGVuZ3RoID09PSAwKSB7XG4gICAgY2hpbGQubm9kZS5pbmNsdWRlID0gSW5jbHVzaW9uVHlwZS5FWENMVURFO1xuICAgIHJlbmRlck5vZGUuaXNvbGF0ZWRPdXRFeHRyYWN0LnB1c2goY2hpbGQpO1xuICAgIGdyYXBoLnJlbW92ZU5vZGUobik7XG4gIH1cbn1cblxuLyoqXG4gKiBSZW1vdmUgZWRnZXMgZnJvbSBhIG5vZGUsIHNldCBpdHMgaXNJbkV4dHJhY3QgcHJvcGVydHkgdG8gdHJ1ZSxcbiAqIGFuZCByZW1vdmUgdGhlIG5vZGUgYW5kIG1vdmUgaXQgdG8gaXNvbGF0ZWRJbkV4dHJhY3QuXG4gKlxuICogSWYgZGV0YWNoQWxsRWRnZXNGb3JIaWdoRGVncmVlIG9yIGZvcmNlRGV0YWNoIGlzIHRydWUsIGV4dHJhY3QgYWxsIG9mIGl0c1xuICogZWRnZXMuIE90aGVyd2lzZSwgb25seSByZW1vdmUgYWxsIG91dC1lZGdlcy5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIG1ha2VJbkV4dHJhY3QocmVuZGVyTm9kZTogUmVuZGVyR3JvdXBOb2RlSW5mbywgbjogc3RyaW5nLFxuICAgIGZvcmNlRGV0YWNoPzogYm9vbGVhbikge1xuICBsZXQgZ3JhcGggPSByZW5kZXJOb2RlLmNvcmVHcmFwaDtcbiAgbGV0IGNoaWxkID0gZ3JhcGgubm9kZShuKTtcbiAgY2hpbGQuaXNJbkV4dHJhY3QgPSB0cnVlO1xuXG4gIF8uZWFjaChncmFwaC5zdWNjZXNzb3JzKG4pLCAocywgaW5kZXgpID0+IHtcbiAgICBjcmVhdGVTaG9ydGN1dChncmFwaCwgbiwgcyk7XG4gIH0pO1xuXG4gIGlmIChQQVJBTVMuZGV0YWNoQWxsRWRnZXNGb3JIaWdoRGVncmVlIHx8IGZvcmNlRGV0YWNoKSB7XG4gICAgXy5lYWNoKGdyYXBoLnByZWRlY2Vzc29ycyhuKSwgKHAsIGluZGV4KSA9PiB7XG4gICAgICBjcmVhdGVTaG9ydGN1dChncmFwaCwgcCwgbik7XG4gICAgfSk7XG4gIH1cblxuICAvLyBSZW1vdmUgdGhlIG5vZGUgZnJvbSB0aGUgY29yZSBncmFwaCBpZiBpdCBubyBsb25nZXIgaGFzIG5laWdoYm9ycy5cbiAgaWYgKGdyYXBoLm5laWdoYm9ycyhuKS5sZW5ndGggPT09IDApIHtcbiAgICBjaGlsZC5ub2RlLmluY2x1ZGUgPSBJbmNsdXNpb25UeXBlLkVYQ0xVREU7XG4gICAgcmVuZGVyTm9kZS5pc29sYXRlZEluRXh0cmFjdC5wdXNoKGNoaWxkKTtcbiAgICBncmFwaC5yZW1vdmVOb2RlKG4pO1xuICB9XG59XG5cbi8qKlxuICogQ2hlY2sgd2hldGhlciB0aGUgbm9kZSdzIHR5cGUgaXMgYSBtZW1iZXIgb2YgdGhlIGdpdmVuIGxpc3Qgb2YgdHlwZXMuXG4gKlxuICogQHBhcmFtIG5vZGUgTm9kZS5cbiAqIEBwYXJhbSB0eXBlcyBMaXN0IG9mIHR5cGUgdG8gbWF0Y2guXG4gKi9cbmZ1bmN0aW9uIGhhc1R5cGVJbihub2RlOiBOb2RlLCB0eXBlczogc3RyaW5nW10pOiBib29sZWFuIHtcbiAgaWYgKG5vZGUudHlwZSA9PT0gTm9kZVR5cGUuT1ApIHtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHR5cGVzLmxlbmd0aDsgaSsrKSB7XG4gICAgICBpZiAoKDxPcE5vZGU+bm9kZSkub3AgPT09IHR5cGVzW2ldKSB7IHJldHVybiB0cnVlOyB9XG4gICAgfVxuICB9IGVsc2UgaWYgKG5vZGUudHlwZSA9PT0gTm9kZVR5cGUuTUVUQSkge1xuICAgIGxldCByb290T3BOb2RlID0gKDxNZXRhbm9kZT5ub2RlKS5nZXRSb290T3AoKTtcbiAgICBpZiAocm9vdE9wTm9kZSkge1xuICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCB0eXBlcy5sZW5ndGg7IGkrKykge1xuICAgICAgICBpZiAocm9vdE9wTm9kZS5vcCA9PT0gdHlwZXNbaV0pIHsgcmV0dXJuIHRydWU7IH1cbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgcmV0dXJuIGZhbHNlO1xufVxuXG4vKiogTW92ZSBub2RlcyB0aGF0IGFyZSBzcGVjaWZpZWQgdG8gYmUgZXhjbHVkZWQgb3V0IG9mIHRoZSBjb3JlIGdyYXBoLiAqL1xuZnVuY3Rpb24gZXh0cmFjdFNwZWNpZmllZE5vZGVzKHJlbmRlck5vZGU6IFJlbmRlckdyb3VwTm9kZUluZm8pIHtcbiAgbGV0IGdyYXBoID0gcmVuZGVyTm9kZS5jb3JlR3JhcGg7XG4gIF8uZWFjaChncmFwaC5ub2RlcygpLCBuID0+IHtcbiAgICBsZXQgcmVuZGVySW5mbyA9IGdyYXBoLm5vZGUobik7XG4gICAgaWYgKHJlbmRlckluZm8ubm9kZS5pbmNsdWRlID09PSBJbmNsdXNpb25UeXBlLkVYQ0xVREUgJiZcbiAgICAgICAgIW4uc3RhcnRzV2l0aCh0Zi5ncmFwaC5GVU5DVElPTl9MSUJSQVJZX05PREVfUFJFRklYKSkge1xuICAgICAgLy8gTW92ZSB0aGUgbm9kZSBpZiB0aGUgbm9kZSBpcyBleGNsdWRlZCBhbmQgbm90IHBhcnQgb2YgdGhlIGxpYnJhcnlcbiAgICAgIC8vIGZ1bmN0aW9uIHNjZW5lIGdyb3VwLCB3aGljaCBjb250YWlucyBub2RlcyB0aGF0IGRvIG5vdCByZXByZXNlbnQgb3BzIGluXG4gICAgICAvLyB0aGUgZ3JhcGggYW5kIHNob3VsZCB0aHVzIG5ldmVyIGhhdmUgaXRzIG5vZGVzIGFkZGVkIHRvIHRoZSBjb3JlIGdyYXBoLlxuICAgICAgaWYgKHJlbmRlck5vZGUuY29yZUdyYXBoLm91dEVkZ2VzKG4pLmxlbmd0aCA+XG4gICAgICAgICAgcmVuZGVyTm9kZS5jb3JlR3JhcGguaW5FZGdlcyhuKS5sZW5ndGgpIHtcbiAgICAgICAgbWFrZU91dEV4dHJhY3QocmVuZGVyTm9kZSwgbiwgdHJ1ZSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBtYWtlSW5FeHRyYWN0KHJlbmRlck5vZGUsIG4sIHRydWUpO1xuICAgICAgfVxuICAgIH1cbiAgfSk7XG59XG5cbi8qKiBSZW1vdmUgZWRnZXMgZnJvbSBwcmUtZGVmaW5lZCBvdXQtZXh0cmFjdCBwYXR0ZXJucyAqL1xuZnVuY3Rpb24gZXh0cmFjdFByZWRlZmluZWRTaW5rKHJlbmRlck5vZGU6IFJlbmRlckdyb3VwTm9kZUluZm8pIHtcbiAgbGV0IGdyYXBoID0gcmVuZGVyTm9kZS5jb3JlR3JhcGg7XG4gIF8uZWFjaChncmFwaC5ub2RlcygpLCBuID0+IHtcbiAgICBsZXQgcmVuZGVySW5mbyA9IGdyYXBoLm5vZGUobik7XG4gICAgaWYgKHJlbmRlckluZm8ubm9kZS5pbmNsdWRlICE9PSBJbmNsdXNpb25UeXBlLlVOU1BFQ0lGSUVEKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGlmIChoYXNUeXBlSW4ocmVuZGVySW5mby5ub2RlLCBQQVJBTVMub3V0RXh0cmFjdFR5cGVzKSkge1xuICAgICAgbWFrZU91dEV4dHJhY3QocmVuZGVyTm9kZSwgbik7XG4gICAgfVxuICB9KTtcbn1cblxuLyoqIFJlbW92ZSBlZGdlcyBmcm9tIHByZS1kZWZpbmVkIGluLWV4dHJhY3QgcGF0dGVybnMgKi9cbmZ1bmN0aW9uIGV4dHJhY3RQcmVkZWZpbmVkU291cmNlKHJlbmRlck5vZGUpIHtcbiAgbGV0IGdyYXBoID0gcmVuZGVyTm9kZS5jb3JlR3JhcGg7XG4gIF8uZWFjaChncmFwaC5ub2RlcygpLCBuID0+IHtcbiAgICBsZXQgcmVuZGVySW5mbyA9IGdyYXBoLm5vZGUobik7XG4gICAgaWYgKHJlbmRlckluZm8ubm9kZS5pbmNsdWRlICE9PSBJbmNsdXNpb25UeXBlLlVOU1BFQ0lGSUVEKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGlmIChoYXNUeXBlSW4ocmVuZGVySW5mby5ub2RlLCBQQVJBTVMuaW5FeHRyYWN0VHlwZXMpKSB7XG4gICAgICBtYWtlSW5FeHRyYWN0KHJlbmRlck5vZGUsIG4pO1xuICAgIH1cbiAgfSk7XG59XG5cbi8qKiBFeHRyYWN0IG5vZGVzIGRlZW1lZCB0byBoYXZlIGVpdGhlciBoaWdoIGluLWRlZ3JlZSBvciBoaWdoIG91dC1kZWdyZWUuICovXG5mdW5jdGlvbiBleHRyYWN0SGlnaEluT3JPdXREZWdyZWUocmVuZGVyTm9kZTogUmVuZGVyR3JvdXBOb2RlSW5mbykge1xuICBsZXQgZ3JhcGggPSByZW5kZXJOb2RlLmNvcmVHcmFwaDtcblxuICAvLyBDcmVhdGUgbWFwcGluZ3MgZnJvbSBub2RlIHRvIGluIGFuZCBvdXQgZGVncmVlcy4gQ291bnQgdGhlIG51bWJlciBvZiB2YWxpZFxuICAvLyBub2RlcyBhbG9uZyB0aGUgd2F5LlxuICBsZXQgbm9kZVRvSW5EZWdyZWUgPSB7fTtcbiAgbGV0IG5vZGVUb091dERlZ3JlZSA9IHt9O1xuICBsZXQgdmFsaWROb2RlQ291bnQgPSAwO1xuICBfLmVhY2goZ3JhcGgubm9kZXMoKSwgY3VycmVudE5vZGUgPT4ge1xuICAgIGlmIChncmFwaC5ub2RlKGN1cnJlbnROb2RlKS5ub2RlLmluY2x1ZGUgIT09IEluY2x1c2lvblR5cGUuVU5TUEVDSUZJRUQpIHtcbiAgICAgIC8vIFRoaXMgbm9kZSBpcyBub3QgaW5jbHVkZWQgaW4gdGhlIGZpcnN0IHBsYWNlLlxuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIC8vIENvdW50IHRoZSBpbiBhbmQgb3V0IGRlZ3JlZXMgYmFzZWQgb24gb25seSByZWd1bGFyIGVkZ2VzLCB1bmxlc3MgdGhlcmVcbiAgICAvLyBhcmUgbm8gcmVndWxhciBlZGdlcywgaW4gd2hpY2ggY2FzZSB1c2UgdGhlIG51bWJlciBvZiBjb250cm9sIGVkZ2VzLlxuICAgIC8vIFRoaXMgaXMgZG9uZSBzbyB0aGF0IGNvbnRyb2wgZWRnZXMgZG9uJ3QgYWZmZWN0IGlmIG5vZGVzIGFyZSBleHRyYWN0ZWRcbiAgICAvLyBmcm9tIHRoZSBjb3JlIGdyYXBoLCB1bmxlc3MgdGhlIG5vZGUgaXMgb25seSB1c2VkIGZvciBjb250cm9sLlxuICAgIGxldCBpbkRlZ3JlZSA9XG4gICAgICAgIF8ucmVkdWNlKGdyYXBoLnByZWRlY2Vzc29ycyhjdXJyZW50Tm9kZSksIChpbkRlZ3JlZSwgcHJlZCkgPT4ge1xuICAgICAgICAgIGxldCBtZXRhZWRnZSA9IGdyYXBoLmVkZ2UocHJlZCwgY3VycmVudE5vZGUpLm1ldGFlZGdlO1xuICAgICAgICAgIHJldHVybiBpbkRlZ3JlZSArIChtZXRhZWRnZS5udW1SZWd1bGFyRWRnZXMgPyAxIDogMCk7XG4gICAgICAgIH0sIDApO1xuICAgIGlmIChpbkRlZ3JlZSA9PT0gMCAmJiBncmFwaC5wcmVkZWNlc3NvcnMoY3VycmVudE5vZGUpLmxlbmd0aCA+IDApIHtcbiAgICAgIGluRGVncmVlID0gZ3JhcGgucHJlZGVjZXNzb3JzKGN1cnJlbnROb2RlKS5sZW5ndGg7XG4gICAgfVxuXG4gICAgbGV0IG91dERlZ3JlZSA9XG4gICAgICAgIF8ucmVkdWNlKGdyYXBoLnN1Y2Nlc3NvcnMoY3VycmVudE5vZGUpLCAob3V0RGVncmVlLCBzdWNjKSA9PiB7XG4gICAgICAgICAgbGV0IG1ldGFlZGdlID0gZ3JhcGguZWRnZShjdXJyZW50Tm9kZSwgc3VjYykubWV0YWVkZ2U7XG4gICAgICAgICAgcmV0dXJuIG91dERlZ3JlZSArIChtZXRhZWRnZS5udW1SZWd1bGFyRWRnZXMgPyAxIDogMCk7XG4gICAgICAgIH0sIDApO1xuICAgIGlmIChvdXREZWdyZWUgPT09IDAgJiYgZ3JhcGguc3VjY2Vzc29ycyhjdXJyZW50Tm9kZSkubGVuZ3RoID4gMCkge1xuICAgICAgb3V0RGVncmVlID0gZ3JhcGguc3VjY2Vzc29ycyhjdXJyZW50Tm9kZSkubGVuZ3RoO1xuICAgIH1cblxuICAgIC8vIFN0b3JlIHRoZSBpbiBhbmQgb3V0IGRlZ3JlZXMgb2YgdGhpcyBub2RlIHRvIGF2b2lkIHJlY29tcHV0aW5nLlxuICAgIG5vZGVUb0luRGVncmVlW2N1cnJlbnROb2RlXSA9IGluRGVncmVlO1xuICAgIG5vZGVUb091dERlZ3JlZVtjdXJyZW50Tm9kZV0gPSBvdXREZWdyZWU7XG4gICAgdmFsaWROb2RlQ291bnQrKztcbiAgfSk7XG5cbiAgaWYgKHZhbGlkTm9kZUNvdW50IDwgUEFSQU1TLm1pbk5vZGVDb3VudEZvckV4dHJhY3Rpb24pIHtcbiAgICAvLyBUaGlzIGdyYXBoIGhhcyBmZXcgbm9kZXMuIERvIG5vdCBleHRyYWN0IGFueSBub2Rlcy5cbiAgICByZXR1cm47XG4gIH1cblxuICAvLyBXZSBvbmx5IGV4dHJhY3QgaWYgdGhlIG5vZGUgaGFzIGEgbWluIGluIG9yIG91dCBkZWdyZWUgZ3JlYXRlciB0aGFuIHRoaXMuXG4gIGxldCBtaW5VcHBlckJvdW5kID0gUEFSQU1TLm1pbkRlZ3JlZUZvckV4dHJhY3Rpb24gLSAxO1xuXG4gIC8vIE1hcmsgZm9yIGV4dHJhY3Rpb24gbm9kZXMgd2l0aCBpbi1kZWdyZWUgPiBRMyArIChRMyAtIFExKS5cbiAgbGV0IHEzSW5kZXggPSBNYXRoLnJvdW5kKHZhbGlkTm9kZUNvdW50ICogMC43NSk7XG4gIGxldCBxMUluZGV4ID0gTWF0aC5yb3VuZCh2YWxpZE5vZGVDb3VudCAqIDAuMjUpO1xuICBsZXQgc29ydGVkQnlJbkRlZ3JlZSA9IE9iamVjdC5rZXlzKG5vZGVUb0luRGVncmVlKS5zb3J0KChub2RlMCwgbm9kZTEpID0+IHtcbiAgICByZXR1cm4gbm9kZVRvSW5EZWdyZWVbbm9kZTBdIC0gbm9kZVRvSW5EZWdyZWVbbm9kZTFdO1xuICB9KTtcbiAgbGV0IGluRGVncmVlUTMgPSBub2RlVG9JbkRlZ3JlZVtzb3J0ZWRCeUluRGVncmVlW3EzSW5kZXhdXTtcbiAgbGV0IGluRGVncmVlUTEgPSBub2RlVG9JbkRlZ3JlZVtzb3J0ZWRCeUluRGVncmVlW3ExSW5kZXhdXTtcbiAgbGV0IGluRGVncmVlVXBwZXJCb3VuZCA9IGluRGVncmVlUTMgKyBpbkRlZ3JlZVEzIC0gaW5EZWdyZWVRMTtcbiAgLy8gT25seSBleHRyYWN0IGlmIHRoZSB1cHBlciBib3VuZCBpcyBoaWdoIGVub3VnaC5cbiAgaW5EZWdyZWVVcHBlckJvdW5kID0gTWF0aC5tYXgoaW5EZWdyZWVVcHBlckJvdW5kLCBtaW5VcHBlckJvdW5kKTtcbiAgZm9yIChsZXQgaSA9IHZhbGlkTm9kZUNvdW50IC0gMTtcbiAgICAgICBub2RlVG9JbkRlZ3JlZVtzb3J0ZWRCeUluRGVncmVlW2ldXSA+IGluRGVncmVlVXBwZXJCb3VuZDsgaS0tKSB7XG4gICAgLy8gRXh0cmFjdCBhIGhpZ2ggaW4tZGVncmVlIG5vZGUuXG4gICAgbWFrZUluRXh0cmFjdChyZW5kZXJOb2RlLCBzb3J0ZWRCeUluRGVncmVlW2ldKTtcbiAgfVxuXG4gIC8vIE1hcmsgZm9yIGV4dHJhY3Rpb24gbm9kZXMgd2l0aCBvdXQtZGVncmVlID4gUTMgKyAoUTMgLSBRMSkgKiA0LlxuICBsZXQgc29ydGVkQnlPdXREZWdyZWUgPSBPYmplY3Qua2V5cyhub2RlVG9PdXREZWdyZWUpLnNvcnQoKG5vZGUwLCBub2RlMSkgPT4ge1xuICAgIHJldHVybiBub2RlVG9PdXREZWdyZWVbbm9kZTBdIC0gbm9kZVRvT3V0RGVncmVlW25vZGUxXTtcbiAgfSk7XG4gIGxldCBvdXREZWdyZWVRMyA9IG5vZGVUb091dERlZ3JlZVtzb3J0ZWRCeU91dERlZ3JlZVtxM0luZGV4XV07XG4gIGxldCBvdXREZWdyZWVRMSA9IG5vZGVUb091dERlZ3JlZVtzb3J0ZWRCeU91dERlZ3JlZVtxMUluZGV4XV07XG4gIC8vIFRoZSB1cHBlciBib3VuZCBmb3IgZXh0cmFjdGluZyBvdXQtZGVncmVlIG5vZGVzIGlzIGhpZ2hlciB0aGFuIHRoYXQgZm9yXG4gIC8vIGV4dHJhY3RpbmcgaW4tZGVncmVlIG9uZXMgKE5vdGUgdGhlIFwiKiA0XCIpIGJlY2F1c2UsIGluIHByYWN0aWNlLCBzb21lXG4gIC8vIGdyYXBocyBsb29rIHdvcnNlIHdpdGggYSBzbWFsbGVyIG91dC1kZWdyZWUgYm91bmQuIEZvciBpbnN0YW5jZSwgYSBzbWFsbGVyXG4gIC8vIG91dC1kZWdyZWUgYm91bmQgcmVtb3ZlcyB0aGUgY29udm9sdXRpb24gbm9kZXMgZnJvbSBjaWZhciAxMCB0cmFpbidzIGdyYXBoLlxuICBsZXQgb3V0RGVncmVlVXBwZXJCb3VuZCA9IG91dERlZ3JlZVEzICsgKG91dERlZ3JlZVEzIC0gb3V0RGVncmVlUTEpICogNDtcbiAgLy8gT25seSBleHRyYWN0IGlmIHRoZSB1cHBlciBib3VuZCBpcyBoaWdoIGVub3VnaC5cbiAgb3V0RGVncmVlVXBwZXJCb3VuZCA9IE1hdGgubWF4KG91dERlZ3JlZVVwcGVyQm91bmQsIG1pblVwcGVyQm91bmQpO1xuICBmb3IgKGxldCBpID0gdmFsaWROb2RlQ291bnQgLSAxO1xuICAgICAgIG5vZGVUb091dERlZ3JlZVtzb3J0ZWRCeU91dERlZ3JlZVtpXV0gPiBvdXREZWdyZWVVcHBlckJvdW5kOyBpLS0pIHtcbiAgICBsZXQgbm9kZSA9IGdyYXBoLm5vZGUoc29ydGVkQnlPdXREZWdyZWVbaV0pO1xuICAgIGlmICghbm9kZSB8fCBub2RlLmlzSW5FeHRyYWN0KSB7XG4gICAgICAvLyBUaGlzIG5vZGUgaGFzIGFscmVhZHkgYmVlbiBleHRyYWN0ZWQgZHVlIHRvIGhpZ2ggaW4tZGVncmVlLiBJdCBtaWdodFxuICAgICAgLy8gaGF2ZSBiZWVuIHJlbW92ZWQgZnJvbSB0aGUgZ3JhcGggaW4gZ2VuZXJhbCAoZHVyaW5nIGluLWRlZ3JlZVxuICAgICAgLy8gZXh0cmFjdGlvbikgZHVlIHRvIGEgbGFjayBvZiBuZWlnaGJvcnMuIERvIG5vdCBleHRyYWN0IHRoaXMgbm9kZSB0d2ljZS5cbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cblxuICAgIC8vIEV4dHJhY3QgYSBoaWdoIG91dC1kZWdyZWUgbm9kZSB0aGF0IGhhcyBub3QgYWxyZWFkeSBiZWVuIGV4dHJhY3RlZC5cbiAgICBtYWtlT3V0RXh0cmFjdChyZW5kZXJOb2RlLCBzb3J0ZWRCeU91dERlZ3JlZVtpXSk7XG4gIH1cbn1cblxuLyoqIFJlbW92ZSBjb250cm9sIGVkZ2VzIGZyb20gbm9kZXMgdGhhdCBoYXZlIHRvbyBtYW55IGNvbnRyb2wgZWRnZXMgKi9cbmZ1bmN0aW9uIHJlbW92ZUNvbnRyb2xFZGdlcyhyZW5kZXJOb2RlOiBSZW5kZXJHcm91cE5vZGVJbmZvKSB7XG4gIGxldCBncmFwaCA9IHJlbmRlck5vZGUuY29yZUdyYXBoO1xuXG4gIC8vIENvbGxlY3QgY29udHJvbCBlZGdlcyBpbnRvIGEgbWFwIGJ5IG5vZGUgbmFtZS5cbiAgbGV0IG1hcCA9IDx7W25vZGVOYW1lOiBzdHJpbmddOiBncmFwaGxpYi5FZGdlT2JqZWN0W119Pnt9O1xuICBfLmVhY2goZ3JhcGguZWRnZXMoKSwgZSA9PiB7XG4gICAgaWYgKCFncmFwaC5lZGdlKGUpLm1ldGFlZGdlLm51bVJlZ3VsYXJFZGdlcykge1xuICAgICAgKG1hcFtlLnZdID0gbWFwW2Uudl0gfHwgW10pLnB1c2goZSk7XG4gICAgICAobWFwW2Uud10gPSBtYXBbZS53XSB8fCBbXSkucHVzaChlKTtcbiAgICB9XG4gIH0pO1xuXG4gIC8vIEZvciBlYWNoIG5vZGUgd2l0aCB0b28gbWFueSBjb250cm9sIGVkZ2VzLCB0dXJuIHRoZW0gaW50byBhbm5vdGF0aW9ucy5cbiAgXy5lYWNoKG1hcCwgKGVkZ2VzLCBub2RlTmFtZSkgPT4ge1xuICAgIGlmIChlZGdlcy5sZW5ndGggPiBQQVJBTVMubWF4Q29udHJvbERlZ3JlZSkge1xuICAgICAgXy5lYWNoKGVkZ2VzLCBlID0+IGNyZWF0ZVNob3J0Y3V0KGdyYXBoLCBlLnYsIGUudykpO1xuICAgIH1cbiAgfSk7XG59XG5cbi8qKlxuICogR2l2ZW4gYW4gaW50ZWdlciwgcGlja3MgYSBodWUgdGhhdCBpcyBmYXIgYXBhcnQgZnJvbSBvdGhlciBjb2xvcnMuXG4gKiBUaGUgZm9ybXVsYSBmb3IgcGlja2luZyBjb2xvciB0aGF0IGF2b2lkIGNvbGxpc2lvbiBpczpcbiAqICAgICBodWUgPSAoY29sb3IgcmFuZ2UgKiBnb2xkZW4gcmF0aW8gKiBpbmRleCkgJSBjb2xvciByYW5nZVxuICovXG5leHBvcnQgZnVuY3Rpb24gbWFwSW5kZXhUb0h1ZShpZDogbnVtYmVyKTogbnVtYmVyIHtcbiAgbGV0IEdPTERFTl9SQVRJTyA9IDEuNjE4MDMzOTg4NzU7XG4gIC8vIEh1ZSBvZiAwIGlzIHJlc2VydmVkIGZvciB0aGUgZ3JheSBub2Rlcy5cbiAgbGV0IE1JTl9IVUUgPSAxO1xuICBsZXQgTUFYX0hVRSA9IDM1OTtcbiAgbGV0IENPTE9SX1JBTkdFID0gTUFYX0hVRSAtIE1JTl9IVUU7XG4gIHJldHVybiBNSU5fSFVFICsgKChDT0xPUl9SQU5HRSAqIEdPTERFTl9SQVRJTyAqIGlkKSAlIENPTE9SX1JBTkdFKTtcbn07XG5cbi8qKlxuICogUmVtb3ZlIGVkZ2VzIGFuZCBhZGQgdG8gYW5ub3RhdGlvbiBpbnN0ZWFkLlxuICpcbiAqIEZvciByb290IG5vZGUsIGNvbnNpZGVyIHByZWRlZmluZWQgdHlwZXMgZm9yIHNvdXJjZSBhbmQgc2luay5cbiAqIFdlIGRvIG5vdCBleHRyYWN0IHByZWRlZmluZWQgdHlwZSBmcm9tIG5vbi1yb290IHNvIHRoYXQgVmFyaWFibGVzIGFuZCB0aGVcbiAqIHNnZCBub2RlIChvcCB0eXBlID0gJ05vT3AnKSBkbyBub3QgZ2V0IGV4dHJhY3QgZnJvbSBpbnNpZGUgb3duIGdyb3VwLlxuICpcbiAqIFRoZSBvcmRlciBvZiBleHRyYWN0aW9uIGlzIGltcG9ydGFudCBoZXJlIGFzIHN3YXBwaW5nIHRoZSBvcmRlciBjYW4gdG90YWxseVxuICogc2NyZXcgdXAgdGhlIGdyYXBoIGxheW91dC5cbiAqXG4gKiBAcGFyYW0ge1JlbmRlci5Ob2RlfSByZW5kZXJOb2RlIE5vZGUgdG8gbWFuaXB1bGF0ZS5cbiAqL1xuZnVuY3Rpb24gZXh0cmFjdEhpZ2hEZWdyZWVzKHJlbmRlck5vZGU6IFJlbmRlckdyb3VwTm9kZUluZm8pIHtcblxuICBleHRyYWN0U3BlY2lmaWVkTm9kZXMocmVuZGVyTm9kZSk7XG5cbiAgaWYgKFBBUkFNUy5vdXRFeHRyYWN0VHlwZXMpIHtcbiAgICBleHRyYWN0UHJlZGVmaW5lZFNpbmsocmVuZGVyTm9kZSk7XG4gIH1cblxuICAvLyBUaGlzIGhhcyB0byBjb21lIGJlZm9yZSBleHRyYWN0IGhpZ2ggaW4tZGVncmVlIHRvIHByb3RlY3QgdGhlIGNvcmUgcGFydFxuICAvLyB0aGF0IHRha2VzIG1hbnkgdmFyaWFibGVzLlxuICBpZiAoUEFSQU1TLmluRXh0cmFjdFR5cGVzKSB7XG4gICAgZXh0cmFjdFByZWRlZmluZWRTb3VyY2UocmVuZGVyTm9kZSk7XG4gIH1cblxuICBleHRyYWN0SGlnaEluT3JPdXREZWdyZWUocmVuZGVyTm9kZSk7XG5cbiAgaWYgKFBBUkFNUy5tYXhDb250cm9sRGVncmVlKSB7XG4gICAgcmVtb3ZlQ29udHJvbEVkZ2VzKHJlbmRlck5vZGUpO1xuICB9XG5cbiAgLy8gRXh0cmFjdCBpc29sYXRlZCBub2Rlcywgd2hpY2ggY2FuIGJlXG4gIC8vICgxKSBzb3VyY2UtbGlrZSBhbmQgc2luay1saWtlIG5vZGVzIHRoYXQgYXJlIG5vdCBvcmlnaW5hbGx5IGlzb2xhdGVkIGJ1dFxuICAvLyAgICAgYmVjb21lIGlzb2xhdGVkIGFmdGVyIGZ1cnRoZXIgcmVtb3ZhbC5cbiAgLy8gKDIpIGlzb2xhdGVkIG5vZGVzIHdpdGggYW5ub3RhdGlvbnMgb24gb25lLXNpZGUuICBUaGVzZSBtaWdodCBiZSBlaXRoZXJcbiAgLy8gICAgIC0gbm9kZXMgdGhhdCBvcmlnaW5hbGx5IGhhdmUgaGlnaCBvdXQtZGVncmVlIGJ1dCBiZWNhdXNlIHdlIHJlbW92ZVxuICAvLyAgICAgICBoaWdoIGluLWRlZ3JlZSBub2RlcyBmaXJzdCwgdGhleSBubyBsb25nZXIgaGF2ZSBoaWdoIGluLWRlZ3JlZSB3aGVuXG4gIC8vICAgICAgIHdlIGNoZWNrLiAgKERldGVjdGluZyBhbGwgaGlnaC1kZWdyZWUgYmVmb3JlIHJlbW92aW5nIGFsc28gbGVhZHMgdG9cbiAgLy8gICAgICAgYW5vdGhlciBwcm9ibGVtLilcbiAgLy8gICAgIC0gbm9kZXMgdGhhdCBkbyBub3QgaGF2ZSBoaWdoIGRlZ3JlZSwgYnV0IHRoZWlyIG5laWdoYm9ycyBhcmUgYWxsXG4gIC8vICAgICAgIGV4dHJhY3RlZCwgc28gaXQgbWlnaHQgbWFrZSBzZW5zZSB0byBleHRyYWN0IHRoZW0gdG9vLlxuXG4gIGxldCBncmFwaCA9IHJlbmRlck5vZGUuY29yZUdyYXBoO1xuICBfLmVhY2goZ3JhcGgubm9kZXMoKSwgbiA9PiB7XG4gICAgbGV0IGNoaWxkID0gZ3JhcGgubm9kZShuKTtcbiAgICBsZXQgZGVncmVlID0gZ3JhcGgubmVpZ2hib3JzKG4pLmxlbmd0aDtcbiAgICBpZiAoY2hpbGQubm9kZS5pbmNsdWRlICE9PSBJbmNsdXNpb25UeXBlLlVOU1BFQ0lGSUVEKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGlmIChkZWdyZWUgPT09IDApIHtcbiAgICAgIGxldCBoYXNPdXRBbm5vdGF0aW9ucyA9IGNoaWxkLm91dEFubm90YXRpb25zLmxpc3QubGVuZ3RoID4gMDtcbiAgICAgIGxldCBoYXNJbkFubm90YXRpb25zID0gY2hpbGQuaW5Bbm5vdGF0aW9ucy5saXN0Lmxlbmd0aCA+IDA7XG5cbiAgICAgIGlmIChjaGlsZC5pc0luRXh0cmFjdCkgeyAvLyBJcyBzb3VyY2UtbGlrZS5cbiAgICAgICAgLy8gVGhpcyBjYXNlIG9ubHkgaGFwcGVucyBpZiBkZXRhY2hBbGxFZGdlc0ZvckhpZ2hEZWdyZWUgaXMgZmFsc2UuXG4gICAgICAgIC8vIChPdGhlcndpc2UgYWxsIHNvdXJjZS1saWtlIG5vZGVzIGFyZSBhbGwgaXNvbGF0ZWQgYWxyZWFkeS4pXG4gICAgICAgIHJlbmRlck5vZGUuaXNvbGF0ZWRJbkV4dHJhY3QucHVzaChjaGlsZCk7XG4gICAgICAgIGNoaWxkLm5vZGUuaW5jbHVkZSA9IEluY2x1c2lvblR5cGUuRVhDTFVERTtcbiAgICAgICAgZ3JhcGgucmVtb3ZlTm9kZShuKTtcbiAgICAgIH0gZWxzZSBpZiAoY2hpbGQuaXNPdXRFeHRyYWN0KSB7IC8vIElzIHNpbmstbGlrZS5cbiAgICAgICAgLy8gVGhpcyBjYXNlIG9ubHkgaGFwcGVucyBpZiBkZXRhY2hBbGxFZGdlc0ZvckhpZ2hEZWdyZWUgaXMgZmFsc2UuXG4gICAgICAgIC8vIC8vIChPdGhlcndpc2UgYWxsIHNpbmstbGlrZSBub2RlcyBhcmUgYWxsIGlzb2xhdGVkIGFscmVhZHkuKVxuICAgICAgICByZW5kZXJOb2RlLmlzb2xhdGVkT3V0RXh0cmFjdC5wdXNoKGNoaWxkKTtcbiAgICAgICAgY2hpbGQubm9kZS5pbmNsdWRlID0gSW5jbHVzaW9uVHlwZS5FWENMVURFO1xuICAgICAgICBncmFwaC5yZW1vdmVOb2RlKG4pO1xuICAgICAgfSBlbHNlIGlmIChQQVJBTVMuZXh0cmFjdElzb2xhdGVkTm9kZXNXaXRoQW5ub3RhdGlvbnNPbk9uZVNpZGUpIHtcbiAgICAgICAgaWYgKGhhc091dEFubm90YXRpb25zICYmICFoYXNJbkFubm90YXRpb25zKSB7XG4gICAgICAgICAgY2hpbGQuaXNJbkV4dHJhY3QgPSB0cnVlOyAvLyBmb3Igb25lcyB3aXRoIGhpZ2ggb3V0LWFubm90YXRpb25zXG4gICAgICAgICAgcmVuZGVyTm9kZS5pc29sYXRlZEluRXh0cmFjdC5wdXNoKGNoaWxkKTtcbiAgICAgICAgICBjaGlsZC5ub2RlLmluY2x1ZGUgPSBJbmNsdXNpb25UeXBlLkVYQ0xVREU7XG4gICAgICAgICAgZ3JhcGgucmVtb3ZlTm9kZShuKTtcbiAgICAgICAgfSBlbHNlIGlmIChoYXNJbkFubm90YXRpb25zICYmICFoYXNPdXRBbm5vdGF0aW9ucykge1xuICAgICAgICAgIGNoaWxkLmlzT3V0RXh0cmFjdCA9IHRydWU7IC8vIGZvciBvbmVzIHdpdGggaGlnaCBpbi1hbm5vdGF0aW9uc1xuICAgICAgICAgIHJlbmRlck5vZGUuaXNvbGF0ZWRPdXRFeHRyYWN0LnB1c2goY2hpbGQpO1xuICAgICAgICAgIGNoaWxkLm5vZGUuaW5jbHVkZSA9IEluY2x1c2lvblR5cGUuRVhDTFVERTtcbiAgICAgICAgICBncmFwaC5yZW1vdmVOb2RlKG4pO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIC8vIGlmIGEgbG93IGRlZ3JlZSBub2RlIGhhcyBib3RoIGluLSAmIG91dC0gYW5ub3RhdGlvbnMsIGRvIG5vdGhpbmdcbiAgICAgICAgICAvLyBiZWNhdXNlIGl0IGlzIHVuY2xlYXIgd2hpY2ggc2lkZSBpdCBzaG91bGQgZ28gdG8uXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH0pO1xufVxuXG4vKipcbiAqIEV4cGFuZHMgbm9kZXMgaW4gdGhlIGdyYXBoIHVudGlsIHRoZSBkZXNpcmVkIG5vZGUgaXMgdmlzaWJsZS5cbiAqXG4gKiBAcGFyYW0gc2NlbmUgVGhlIHNjZW5lIHBvbHltZXIgY29tcG9uZW50LlxuICogQHBhcmFtIHJlbmRlckhpZXJhcmNoeSBUaGUgcmVuZGVyIGhpZXJhcmNoeS5cbiAqIEBwYXJhbSB0ZW5zb3JOYW1lIFRoZSBuYW1lIG9mIGEgdGVuc29yLlxuICogQHJldHVybiBBIHN0cmluZyB0aGF0IGlzIHRoZSBuYW1lIG9mIHRoZSBub2RlIHJlcHJlc2VudGluZyB0aGUgZ2l2ZW4gdGVuc29yLlxuICogICAgIE5vdGUgdGhhdCB0aGUgb3JpZ2luYWwgdGVuc29yIG5hbWUgbWlnaHQgZGlmZmVyIGZyb20gdGhpcyByZXR1cm5lZCBub2RlXG4gKiAgICAgbmFtZS4gU3BlY2lmaWNhbGx5LCBmb3IgaW5zdGFuY2UsIHRoZSB0ZW5zb3IgbmFtZSB1c3VhbGx5IGVuZHMgd2l0aCBhblxuICogICAgIG91dHB1dCBzbG90IGluZGV4IChzdWNoIGFzIDowKSwgd2hpbGUgdGhlIG5vZGUgbmFtZSBsYWNrcyB0aGF0IHN1ZmZpeC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGV4cGFuZFVudGlsTm9kZUlzU2hvd24oXG4gICAgc2NlbmUsIHJlbmRlckhpZXJhcmNoeSwgdGVuc29yTmFtZTogc3RyaW5nKSB7XG4gIGNvbnN0IHNwbGl0VGVuc29yTmFtZSA9IHRlbnNvck5hbWUuc3BsaXQoJy8nKTtcblxuICAvLyBHcmFwaCBuYW1lcyBkbyBub3QgdGFrZSBpbnRvIGFjY291bnQgdGhlIG91dHB1dCBzbG90LiBTdHJpcCBpdC5cbiAgY29uc3QgbGFzdE5vZGVOYW1lTWF0Y2ggPVxuICAgICAgc3BsaXRUZW5zb3JOYW1lW3NwbGl0VGVuc29yTmFtZS5sZW5ndGggLSAxXS5tYXRjaCgvKC4qKTpcXHcrLyk7XG4gIGlmIChsYXN0Tm9kZU5hbWVNYXRjaC5sZW5ndGggPT09IDIpIHtcbiAgICBzcGxpdFRlbnNvck5hbWVbc3BsaXRUZW5zb3JOYW1lLmxlbmd0aCAtIDFdID0gbGFzdE5vZGVOYW1lTWF0Y2hbMV07XG4gIH1cblxuICBsZXQgbm9kZU5hbWUgPSBzcGxpdFRlbnNvck5hbWVbMF07XG4gIGxldCByZW5kZXJOb2RlID0gcmVuZGVySGllcmFyY2h5LmdldFJlbmRlck5vZGVCeU5hbWUobm9kZU5hbWUpO1xuICBmb3IgKGxldCBpID0gMTsgaSA8IHNwbGl0VGVuc29yTmFtZS5sZW5ndGg7IGkrKykge1xuICAgIC8vIE9wIG5vZGVzIGFyZSBub3QgZXhwYW5kYWJsZS5cbiAgICBpZiAocmVuZGVyTm9kZS5ub2RlLnR5cGUgPT09IHRmLmdyYXBoLk5vZGVUeXBlLk9QKSB7XG4gICAgICBicmVhaztcbiAgICB9XG4gICAgcmVuZGVySGllcmFyY2h5LmJ1aWxkU3ViaGllcmFyY2h5KG5vZGVOYW1lKTtcbiAgICByZW5kZXJOb2RlLmV4cGFuZGVkID0gdHJ1ZTtcbiAgICBzY2VuZS5zZXROb2RlRXhwYW5kZWQocmVuZGVyTm9kZSk7XG4gICAgbm9kZU5hbWUgKz0gJy8nICsgc3BsaXRUZW5zb3JOYW1lW2ldO1xuICAgIHJlbmRlck5vZGUgPSByZW5kZXJIaWVyYXJjaHkuZ2V0UmVuZGVyTm9kZUJ5TmFtZShub2RlTmFtZSk7XG4gIH1cblxuICByZXR1cm4gcmVuZGVyTm9kZS5ub2RlLm5hbWU7XG59XG5cbn0gLy8gY2xvc2UgbW9kdWxlIHRmLmdyYXBoLnJlbmRlclxuIl19