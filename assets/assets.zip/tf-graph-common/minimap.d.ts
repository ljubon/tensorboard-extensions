declare module tf.scene {
    class Minimap {
        /** The minimap container. */
        private minimap;
        /** The canvas used for drawing the mini version of the svg. */
        private canvas;
        /** A buffer canvas used for temporary drawing to avoid flickering. */
        private canvasBuffer;
        private download;
        private downloadCanvas;
        /** The minimap svg used for holding the viewpoint rectangle. */
        private minimapSvg;
        /** The rectangle showing the current viewpoint. */
        private viewpoint;
        /**
         * The scale factor for the minimap. The factor is determined automatically
         * so that the minimap doesn't violate the maximum width/height specified
         * in the constructor. The minimap maintains the same aspect ratio as the
         * original svg.
         */
        private scaleMinimap;
        /** The main svg element. */
        private svg;
        /** The svg group used for panning and zooming the main svg. */
        private zoomG;
        /** The zoom behavior of the main svg. */
        private mainZoom;
        /** The maximum width and height for the minimap. */
        private maxWandH;
        /** The last translation vector used in the main svg. */
        private translate;
        /** The last scaling factor used in the main svg. */
        private scaleMain;
        /** The coordinates of the viewpoint rectangle. */
        private viewpointCoord;
        /** The current size of the minimap */
        private minimapSize;
        /** Padding (px) due to the main labels of the graph. */
        private labelPadding;
        /**
         * Constructs a new minimap.
         *
         * @param svg The main svg element.
         * @param zoomG The svg group used for panning and zooming the main svg.
         * @param mainZoom The main zoom behavior.
         * @param minimap The minimap container.
         * @param maxWandH The maximum width/height for the minimap.
         * @param labelPadding Padding in pixels due to the main graph labels.
         */
        constructor(svg: SVGSVGElement, zoomG: SVGGElement, mainZoom: d3.ZoomBehavior<any, any>, minimap: HTMLElement, maxWandH: number, labelPadding: number);
        /**
         * Updates the position and the size of the viewpoint rectangle.
         * It also notifies the main svg about the new panned position.
         */
        private updateViewpoint;
        /**
         * Redraws the minimap. Should be called whenever the main svg
         * was updated (e.g. when a node was expanded).
         */
        update(): void;
        /**
         * Handles changes in zooming/panning. Should be called from the main svg
         * to notify that a zoom/pan was performed and this minimap will update it's
         * viewpoint rectangle.
         *
         * @param translate The translate vector, or none to use the last used one.
         * @param scale The scaling factor, or none to use the last used one.
         */
        zoom(transform?: d3.ZoomTransform): void;
    }
}
