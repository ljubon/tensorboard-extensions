declare namespace tf_backend {
    type RunToTag = {
        [run: string]: string[];
    };
    interface Datum {
        wall_time: Date;
        step: number;
    }
    interface DebuggerNumericsAlertReport {
        device_name: string;
        tensor_name: string;
        first_timestamp: number;
        nan_event_count: number;
        neg_inf_event_count: number;
        pos_inf_event_count: number;
    }
    type DebuggerNumericsAlertReportResponse = DebuggerNumericsAlertReport[];
    const TYPES: any[];
    /** Given a RunToTag, return sorted array of all runs */
    function getRunsNamed(r: RunToTag): string[];
    /** Given a RunToTag, return array of all tags (sorted + dedup'd) */
    function getTags(r: RunToTag): string[];
    /**
     * Given a RunToTag and an array of runs, return every tag that appears for
     * at least one run.
     * Sorted, deduplicated.
     */
    function filterTags(r: RunToTag, runs: string[]): string[];
}
