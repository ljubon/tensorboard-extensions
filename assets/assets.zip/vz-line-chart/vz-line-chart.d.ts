declare namespace vz_line_chart {
    /**
     * An interface that describes a fill area to visualize. The fill area is
     * visualized with a less intense version of the color for a given series.
     */
    interface FillArea {
        lowerAccessor: Plottable.IAccessor<number>;
        higherAccessor: Plottable.IAccessor<number>;
    }
}
