declare namespace vz_sorting {
    /**
     * Compares tag names asciinumerically broken into components.
     *
     * <p>This is the comparison function used for sorting most string values in
     * TensorBoard. Unlike the standard asciibetical comparator, this function
     * knows that 'a10b' > 'a2b'. Fixed point and engineering notation are
     * supported. This function also splits the input by slash and underscore to
     * perform array comparison. Therefore it knows that 'a/a' < 'a+/a' even
     * though '+' < '/' in the ASCII table.
     */
    function compareTagNames(a: any, b: string): number;
}
