var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
/* Copyright 2018 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
var vz_line_chart2;
(function (vz_line_chart2) {
    var NodeName;
    (function (NodeName) {
        NodeName["GROUP"] = "G";
        NodeName["DIV"] = "DIV";
        NodeName["SVG"] = "SVG";
        NodeName["TEXT"] = "TEXT";
    })(NodeName || (NodeName = {}));
    var PlottableExporter = /** @class */ (function () {
        function PlottableExporter(rootEl) {
            this.uniqueId = 0;
            this.root = rootEl;
        }
        PlottableExporter.prototype.exportAsString = function () {
            var convertedNodes = this.convert(this.root);
            if (!convertedNodes)
                return '';
            var svg = this.createRootSvg();
            svg.appendChild(convertedNodes);
            return svg.outerHTML;
        };
        PlottableExporter.prototype.createUniqueId = function (prefix) {
            return prefix + "_" + this.uniqueId++;
        };
        PlottableExporter.prototype.getSize = function () {
            return this.root.getBoundingClientRect();
        };
        PlottableExporter.prototype.createRootSvg = function () {
            var svg = document.createElement('svg');
            var rect = this.getSize();
            // case on `viewBox` is sensitive.
            svg.setAttributeNS('svg', 'viewBox', "0 0 " + rect.width + " " + rect.height);
            svg.setAttribute('xmlns', 'http://www.w3.org/2000/svg');
            return svg;
        };
        PlottableExporter.prototype.convert = function (node) {
            var _this = this;
            var newNode = null;
            var nodeName = node.nodeName.toUpperCase();
            if (node.nodeType == Node.ELEMENT_NODE &&
                (nodeName == NodeName.DIV || nodeName == NodeName.SVG)) {
                newNode = document.createElement(NodeName.GROUP);
                var style = window.getComputedStyle(node);
                var left = parseInt(style.left, 10);
                var top_1 = parseInt(style.top, 10);
                if (left || top_1) {
                    var clipId = this.createUniqueId('clip');
                    newNode.setAttribute('transform', "translate(" + left + ", " + top_1 + ")");
                    newNode.setAttribute('clip-path', "url(#" + clipId + ")");
                    var width = parseInt(style.width, 10);
                    var height = parseInt(style.height, 10);
                    var rect = document.createElement('rect');
                    rect.setAttribute('width', String(width));
                    rect.setAttribute('height', String(height));
                    var clipPath = document.createElementNS('svg', 'clipPath');
                    clipPath.id = clipId;
                    clipPath.appendChild(rect);
                    newNode.appendChild(clipPath);
                }
            }
            else {
                newNode = node.cloneNode();
            }
            Array.from(node.childNodes)
                .map(function (node) { return _this.convert(node); })
                .filter(Boolean)
                .forEach(function (el) { return newNode.appendChild(el); });
            // Remove empty grouping. They add too much noise.
            var shouldOmit = (newNode.nodeName.toUpperCase() == NodeName.GROUP &&
                !newNode.hasChildNodes()) || this.shouldOmitNode(node);
            if (shouldOmit)
                return null;
            return this.stripClass(this.transferStyle(node, newNode));
        };
        PlottableExporter.prototype.stripClass = function (node) {
            if (node.nodeType == Node.ELEMENT_NODE) {
                node.removeAttribute('class');
            }
            return node;
        };
        PlottableExporter.prototype.transferStyle = function (origNode, node) {
            if (node.nodeType != Node.ELEMENT_NODE)
                return node;
            var el = node;
            var nodeName = node.nodeName.toUpperCase();
            var style = window.getComputedStyle(origNode);
            if (nodeName == NodeName.TEXT) {
                Object.assign(el.style, {
                    fontFamily: style.fontFamily,
                    fontSize: style.fontSize,
                    fontWeight: style.fontWeight,
                });
            }
            if (nodeName != NodeName.GROUP) {
                el.setAttribute('fill', style.fill);
                el.setAttribute('stroke', style.stroke);
                el.setAttribute('stroke-width', style.strokeWidth);
            }
            if (style.opacity != '1')
                el.setAttribute('opacity', style.opacity);
            return node;
        };
        PlottableExporter.prototype.shouldOmitNode = function (node) {
            return false;
        };
        return PlottableExporter;
    }());
    vz_line_chart2.PlottableExporter = PlottableExporter;
    var LineChartExporter = /** @class */ (function (_super) {
        __extends(LineChartExporter, _super);
        function LineChartExporter() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        LineChartExporter.prototype.shouldOmitNode = function (node) {
            // Scatter plot is useful for tooltip. Tooltip is meaningless in the
            // exported svg.
            if (node.nodeType == Node.ELEMENT_NODE) {
                return node.classList.contains('scatter-plot');
            }
            return false;
        };
        return LineChartExporter;
    }(PlottableExporter));
    vz_line_chart2.LineChartExporter = LineChartExporter;
})(vz_line_chart2 || (vz_line_chart2 = {}));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibGluZS1jaGFydC1leHBvcnRlci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImxpbmUtY2hhcnQtZXhwb3J0ZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztBQUFBOzs7Ozs7Ozs7Ozs7O2dGQWFnRjtBQUNoRixJQUFVLGNBQWMsQ0FvSXZCO0FBcElELFdBQVUsY0FBYztJQUV4QixJQUFLLFFBS0o7SUFMRCxXQUFLLFFBQVE7UUFDWCx1QkFBVyxDQUFBO1FBQ1gsdUJBQVcsQ0FBQTtRQUNYLHVCQUFXLENBQUE7UUFDWCx5QkFBYSxDQUFBO0lBQ2YsQ0FBQyxFQUxJLFFBQVEsS0FBUixRQUFRLFFBS1o7SUFFRDtRQUlFLDJCQUFZLE1BQWU7WUFGbkIsYUFBUSxHQUFXLENBQUMsQ0FBQztZQUczQixJQUFJLENBQUMsSUFBSSxHQUFHLE1BQU0sQ0FBQztRQUNyQixDQUFDO1FBRU0sMENBQWMsR0FBckI7WUFDRSxJQUFNLGNBQWMsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUMvQyxJQUFJLENBQUMsY0FBYztnQkFBRSxPQUFPLEVBQUUsQ0FBQztZQUMvQixJQUFNLEdBQUcsR0FBRyxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7WUFDakMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxjQUFjLENBQUMsQ0FBQztZQUNoQyxPQUFPLEdBQUcsQ0FBQyxTQUFTLENBQUM7UUFDdkIsQ0FBQztRQUVPLDBDQUFjLEdBQXRCLFVBQXVCLE1BQWM7WUFDbkMsT0FBVSxNQUFNLFNBQUksSUFBSSxDQUFDLFFBQVEsRUFBSSxDQUFDO1FBQ3hDLENBQUM7UUFFTyxtQ0FBTyxHQUFmO1lBQ0UsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLHFCQUFxQixFQUFFLENBQUM7UUFDM0MsQ0FBQztRQUVPLHlDQUFhLEdBQXJCO1lBQ0UsSUFBTSxHQUFHLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUMxQyxJQUFNLElBQUksR0FBRyxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7WUFFNUIsa0NBQWtDO1lBQ2xDLEdBQUcsQ0FBQyxjQUFjLENBQUMsS0FBSyxFQUFFLFNBQVMsRUFBRSxTQUFPLElBQUksQ0FBQyxLQUFLLFNBQUksSUFBSSxDQUFDLE1BQVEsQ0FBQyxDQUFDO1lBQ3pFLEdBQUcsQ0FBQyxZQUFZLENBQUMsT0FBTyxFQUFFLDRCQUE0QixDQUFDLENBQUM7WUFDeEQsT0FBTyxHQUFHLENBQUM7UUFDYixDQUFDO1FBRU8sbUNBQU8sR0FBZixVQUFnQixJQUFVO1lBQTFCLGlCQXVDQztZQXRDQyxJQUFJLE9BQU8sR0FBRyxJQUFJLENBQUM7WUFDbkIsSUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUM3QyxJQUFJLElBQUksQ0FBQyxRQUFRLElBQUksSUFBSSxDQUFDLFlBQVk7Z0JBQ2xDLENBQUMsUUFBUSxJQUFJLFFBQVEsQ0FBQyxHQUFHLElBQUksUUFBUSxJQUFJLFFBQVEsQ0FBQyxHQUFHLENBQUMsRUFBRTtnQkFDMUQsT0FBTyxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUNqRCxJQUFNLEtBQUssR0FBRyxNQUFNLENBQUMsZ0JBQWdCLENBQUMsSUFBZSxDQUFDLENBQUM7Z0JBQ3ZELElBQU0sSUFBSSxHQUFHLFFBQVEsQ0FBQyxLQUFLLENBQUMsSUFBSSxFQUFFLEVBQUUsQ0FBQyxDQUFDO2dCQUN0QyxJQUFNLEtBQUcsR0FBRyxRQUFRLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxFQUFFLENBQUMsQ0FBQztnQkFDcEMsSUFBSSxJQUFJLElBQUksS0FBRyxFQUFFO29CQUNmLElBQU0sTUFBTSxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLENBQUM7b0JBQzNDLE9BQU8sQ0FBQyxZQUFZLENBQUMsV0FBVyxFQUFFLGVBQWEsSUFBSSxVQUFLLEtBQUcsTUFBRyxDQUFDLENBQUM7b0JBQ2hFLE9BQU8sQ0FBQyxZQUFZLENBQUMsV0FBVyxFQUFFLFVBQVEsTUFBTSxNQUFHLENBQUMsQ0FBQztvQkFDckQsSUFBTSxLQUFLLEdBQUcsUUFBUSxDQUFDLEtBQUssQ0FBQyxLQUFLLEVBQUUsRUFBRSxDQUFDLENBQUM7b0JBQ3hDLElBQU0sTUFBTSxHQUFHLFFBQVEsQ0FBQyxLQUFLLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxDQUFDO29CQUMxQyxJQUFNLElBQUksR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUM1QyxJQUFJLENBQUMsWUFBWSxDQUFDLE9BQU8sRUFBRSxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztvQkFDMUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxRQUFRLEVBQUUsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7b0JBQzVDLElBQU0sUUFBUSxHQUFHLFFBQVEsQ0FBQyxlQUFlLENBQUMsS0FBSyxFQUFFLFVBQVUsQ0FBQyxDQUFDO29CQUM3RCxRQUFRLENBQUMsRUFBRSxHQUFHLE1BQU0sQ0FBQztvQkFDckIsUUFBUSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQztvQkFDM0IsT0FBTyxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsQ0FBQztpQkFDL0I7YUFDRjtpQkFBTTtnQkFDTCxPQUFPLEdBQUcsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO2FBQzVCO1lBQ0QsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDO2lCQUN0QixHQUFHLENBQUMsVUFBQSxJQUFJLElBQUksT0FBQSxLQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxFQUFsQixDQUFrQixDQUFDO2lCQUMvQixNQUFNLENBQUMsT0FBTyxDQUFDO2lCQUNmLE9BQU8sQ0FBQyxVQUFBLEVBQUUsSUFBSSxPQUFBLE9BQU8sQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDLEVBQXZCLENBQXVCLENBQUMsQ0FBQztZQUU1QyxrREFBa0Q7WUFDbEQsSUFBTSxVQUFVLEdBQUcsQ0FDYixPQUFPLENBQUMsUUFBUSxDQUFDLFdBQVcsRUFBRSxJQUFJLFFBQVEsQ0FBQyxLQUFLO2dCQUNoRCxDQUFDLE9BQU8sQ0FBQyxhQUFhLEVBQUUsQ0FDekIsSUFBSSxJQUFJLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxDQUFDO1lBRW5DLElBQUksVUFBVTtnQkFBRSxPQUFPLElBQUksQ0FBQztZQUM1QixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLENBQUMsQ0FBQztRQUM1RCxDQUFDO1FBRU8sc0NBQVUsR0FBbEIsVUFBbUIsSUFBVTtZQUMzQixJQUFJLElBQUksQ0FBQyxRQUFRLElBQUksSUFBSSxDQUFDLFlBQVksRUFBRTtnQkFDckMsSUFBZ0IsQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDLENBQUM7YUFDNUM7WUFDRCxPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7UUFFTyx5Q0FBYSxHQUFyQixVQUFzQixRQUFjLEVBQUUsSUFBVTtZQUM5QyxJQUFJLElBQUksQ0FBQyxRQUFRLElBQUksSUFBSSxDQUFDLFlBQVk7Z0JBQUUsT0FBTyxJQUFJLENBQUM7WUFDcEQsSUFBTSxFQUFFLEdBQUcsSUFBbUIsQ0FBQztZQUMvQixJQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLFdBQVcsRUFBRSxDQUFDO1lBQzdDLElBQU0sS0FBSyxHQUFHLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxRQUF1QixDQUFDLENBQUM7WUFFL0QsSUFBSSxRQUFRLElBQUksUUFBUSxDQUFDLElBQUksRUFBRTtnQkFDN0IsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsS0FBSyxFQUFFO29CQUN0QixVQUFVLEVBQUUsS0FBSyxDQUFDLFVBQVU7b0JBQzVCLFFBQVEsRUFBRSxLQUFLLENBQUMsUUFBUTtvQkFDeEIsVUFBVSxFQUFFLEtBQUssQ0FBQyxVQUFVO2lCQUM3QixDQUFDLENBQUM7YUFDSjtZQUVELElBQUksUUFBUSxJQUFJLFFBQVEsQ0FBQyxLQUFLLEVBQUU7Z0JBQzlCLEVBQUUsQ0FBQyxZQUFZLENBQUMsTUFBTSxFQUFFLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDcEMsRUFBRSxDQUFDLFlBQVksQ0FBQyxRQUFRLEVBQUUsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDO2dCQUN4QyxFQUFFLENBQUMsWUFBWSxDQUFDLGNBQWMsRUFBRSxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUM7YUFDcEQ7WUFFRCxJQUFJLEtBQUssQ0FBQyxPQUFPLElBQUksR0FBRztnQkFBRSxFQUFFLENBQUMsWUFBWSxDQUFDLFNBQVMsRUFBRSxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUM7WUFFcEUsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO1FBRVMsMENBQWMsR0FBeEIsVUFBeUIsSUFBVTtZQUNqQyxPQUFPLEtBQUssQ0FBQztRQUNmLENBQUM7UUFDSCx3QkFBQztJQUFELENBQUMsQUE5R0QsSUE4R0M7SUE5R1ksZ0NBQWlCLG9CQThHN0IsQ0FBQTtJQUVEO1FBQXVDLHFDQUFpQjtRQUF4RDs7UUFTQSxDQUFDO1FBUkMsMENBQWMsR0FBZCxVQUFlLElBQVU7WUFDdkIsb0VBQW9FO1lBQ3BFLGdCQUFnQjtZQUNoQixJQUFJLElBQUksQ0FBQyxRQUFRLElBQUksSUFBSSxDQUFDLFlBQVksRUFBRTtnQkFDdEMsT0FBUSxJQUFnQixDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsY0FBYyxDQUFDLENBQUM7YUFDN0Q7WUFDRCxPQUFPLEtBQUssQ0FBQztRQUNmLENBQUM7UUFDSCx3QkFBQztJQUFELENBQUMsQUFURCxDQUF1QyxpQkFBaUIsR0FTdkQ7SUFUWSxnQ0FBaUIsb0JBUzdCLENBQUE7QUFFRCxDQUFDLEVBcElTLGNBQWMsS0FBZCxjQUFjLFFBb0l2QiIsInNvdXJjZXNDb250ZW50IjpbIi8qIENvcHlyaWdodCAyMDE4IFRoZSBUZW5zb3JGbG93IEF1dGhvcnMuIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG5cbkxpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSBcIkxpY2Vuc2VcIik7XG55b3UgbWF5IG5vdCB1c2UgdGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlIHdpdGggdGhlIExpY2Vuc2UuXG5Zb3UgbWF5IG9idGFpbiBhIGNvcHkgb2YgdGhlIExpY2Vuc2UgYXRcblxuICAgIGh0dHA6Ly93d3cuYXBhY2hlLm9yZy9saWNlbnNlcy9MSUNFTlNFLTIuMFxuXG5Vbmxlc3MgcmVxdWlyZWQgYnkgYXBwbGljYWJsZSBsYXcgb3IgYWdyZWVkIHRvIGluIHdyaXRpbmcsIHNvZnR3YXJlXG5kaXN0cmlidXRlZCB1bmRlciB0aGUgTGljZW5zZSBpcyBkaXN0cmlidXRlZCBvbiBhbiBcIkFTIElTXCIgQkFTSVMsXG5XSVRIT1VUIFdBUlJBTlRJRVMgT1IgQ09ORElUSU9OUyBPRiBBTlkgS0lORCwgZWl0aGVyIGV4cHJlc3Mgb3IgaW1wbGllZC5cblNlZSB0aGUgTGljZW5zZSBmb3IgdGhlIHNwZWNpZmljIGxhbmd1YWdlIGdvdmVybmluZyBwZXJtaXNzaW9ucyBhbmRcbmxpbWl0YXRpb25zIHVuZGVyIHRoZSBMaWNlbnNlLlxuPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09Ki9cbm5hbWVzcGFjZSB2el9saW5lX2NoYXJ0MiB7XG5cbmVudW0gTm9kZU5hbWUge1xuICBHUk9VUCA9ICdHJyxcbiAgRElWID0gJ0RJVicsXG4gIFNWRyA9ICdTVkcnLFxuICBURVhUID0gJ1RFWFQnLFxufVxuXG5leHBvcnQgY2xhc3MgUGxvdHRhYmxlRXhwb3J0ZXIge1xuICBwcml2YXRlIHJvb3Q6IEVsZW1lbnQ7XG4gIHByaXZhdGUgdW5pcXVlSWQ6IG51bWJlciA9IDA7XG5cbiAgY29uc3RydWN0b3Iocm9vdEVsOiBFbGVtZW50KSB7XG4gICAgdGhpcy5yb290ID0gcm9vdEVsO1xuICB9XG5cbiAgcHVibGljIGV4cG9ydEFzU3RyaW5nKCk6IHN0cmluZyB7XG4gICAgY29uc3QgY29udmVydGVkTm9kZXMgPSB0aGlzLmNvbnZlcnQodGhpcy5yb290KTtcbiAgICBpZiAoIWNvbnZlcnRlZE5vZGVzKSByZXR1cm4gJyc7XG4gICAgY29uc3Qgc3ZnID0gdGhpcy5jcmVhdGVSb290U3ZnKCk7XG4gICAgc3ZnLmFwcGVuZENoaWxkKGNvbnZlcnRlZE5vZGVzKTtcbiAgICByZXR1cm4gc3ZnLm91dGVySFRNTDtcbiAgfVxuXG4gIHByaXZhdGUgY3JlYXRlVW5pcXVlSWQocHJlZml4OiBzdHJpbmcpOiBzdHJpbmcge1xuICAgIHJldHVybiBgJHtwcmVmaXh9XyR7dGhpcy51bmlxdWVJZCsrfWA7XG4gIH1cblxuICBwcml2YXRlIGdldFNpemUoKTogRE9NUmVjdCB8IENsaWVudFJlY3Qge1xuICAgIHJldHVybiB0aGlzLnJvb3QuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gIH1cblxuICBwcml2YXRlIGNyZWF0ZVJvb3RTdmcoKTogRWxlbWVudCB7XG4gICAgY29uc3Qgc3ZnID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3ZnJyk7XG4gICAgY29uc3QgcmVjdCA9IHRoaXMuZ2V0U2l6ZSgpO1xuXG4gICAgLy8gY2FzZSBvbiBgdmlld0JveGAgaXMgc2Vuc2l0aXZlLlxuICAgIHN2Zy5zZXRBdHRyaWJ1dGVOUygnc3ZnJywgJ3ZpZXdCb3gnLCBgMCAwICR7cmVjdC53aWR0aH0gJHtyZWN0LmhlaWdodH1gKTtcbiAgICBzdmcuc2V0QXR0cmlidXRlKCd4bWxucycsICdodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZycpO1xuICAgIHJldHVybiBzdmc7XG4gIH1cblxuICBwcml2YXRlIGNvbnZlcnQobm9kZTogTm9kZSk6IE5vZGUgfCBudWxsIHtcbiAgICBsZXQgbmV3Tm9kZSA9IG51bGw7XG4gICAgY29uc3Qgbm9kZU5hbWUgPSBub2RlLm5vZGVOYW1lLnRvVXBwZXJDYXNlKCk7XG4gICAgaWYgKG5vZGUubm9kZVR5cGUgPT0gTm9kZS5FTEVNRU5UX05PREUgJiZcbiAgICAgICAgKG5vZGVOYW1lID09IE5vZGVOYW1lLkRJViB8fCBub2RlTmFtZSA9PSBOb2RlTmFtZS5TVkcpKSB7XG4gICAgICBuZXdOb2RlID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChOb2RlTmFtZS5HUk9VUCk7XG4gICAgICBjb25zdCBzdHlsZSA9IHdpbmRvdy5nZXRDb21wdXRlZFN0eWxlKG5vZGUgYXMgRWxlbWVudCk7XG4gICAgICBjb25zdCBsZWZ0ID0gcGFyc2VJbnQoc3R5bGUubGVmdCwgMTApO1xuICAgICAgY29uc3QgdG9wID0gcGFyc2VJbnQoc3R5bGUudG9wLCAxMCk7XG4gICAgICBpZiAobGVmdCB8fCB0b3ApIHtcbiAgICAgICAgY29uc3QgY2xpcElkID0gdGhpcy5jcmVhdGVVbmlxdWVJZCgnY2xpcCcpO1xuICAgICAgICBuZXdOb2RlLnNldEF0dHJpYnV0ZSgndHJhbnNmb3JtJywgYHRyYW5zbGF0ZSgke2xlZnR9LCAke3RvcH0pYCk7XG4gICAgICAgIG5ld05vZGUuc2V0QXR0cmlidXRlKCdjbGlwLXBhdGgnLCBgdXJsKCMke2NsaXBJZH0pYCk7XG4gICAgICAgIGNvbnN0IHdpZHRoID0gcGFyc2VJbnQoc3R5bGUud2lkdGgsIDEwKTtcbiAgICAgICAgY29uc3QgaGVpZ2h0ID0gcGFyc2VJbnQoc3R5bGUuaGVpZ2h0LCAxMCk7XG4gICAgICAgIGNvbnN0IHJlY3QgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdyZWN0Jyk7XG4gICAgICAgIHJlY3Quc2V0QXR0cmlidXRlKCd3aWR0aCcsIFN0cmluZyh3aWR0aCkpO1xuICAgICAgICByZWN0LnNldEF0dHJpYnV0ZSgnaGVpZ2h0JywgU3RyaW5nKGhlaWdodCkpO1xuICAgICAgICBjb25zdCBjbGlwUGF0aCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnROUygnc3ZnJywgJ2NsaXBQYXRoJyk7XG4gICAgICAgIGNsaXBQYXRoLmlkID0gY2xpcElkO1xuICAgICAgICBjbGlwUGF0aC5hcHBlbmRDaGlsZChyZWN0KTtcbiAgICAgICAgbmV3Tm9kZS5hcHBlbmRDaGlsZChjbGlwUGF0aCk7XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIG5ld05vZGUgPSBub2RlLmNsb25lTm9kZSgpO1xuICAgIH1cbiAgICBBcnJheS5mcm9tKG5vZGUuY2hpbGROb2RlcylcbiAgICAgICAgLm1hcChub2RlID0+IHRoaXMuY29udmVydChub2RlKSlcbiAgICAgICAgLmZpbHRlcihCb29sZWFuKVxuICAgICAgICAuZm9yRWFjaChlbCA9PiBuZXdOb2RlLmFwcGVuZENoaWxkKGVsKSk7XG5cbiAgICAvLyBSZW1vdmUgZW1wdHkgZ3JvdXBpbmcuIFRoZXkgYWRkIHRvbyBtdWNoIG5vaXNlLlxuICAgIGNvbnN0IHNob3VsZE9taXQgPSAoXG4gICAgICAgICAgbmV3Tm9kZS5ub2RlTmFtZS50b1VwcGVyQ2FzZSgpID09IE5vZGVOYW1lLkdST1VQICYmXG4gICAgICAgICAgIW5ld05vZGUuaGFzQ2hpbGROb2RlcygpXG4gICAgICAgICkgfHwgdGhpcy5zaG91bGRPbWl0Tm9kZShub2RlKTtcblxuICAgIGlmIChzaG91bGRPbWl0KSByZXR1cm4gbnVsbDtcbiAgICByZXR1cm4gdGhpcy5zdHJpcENsYXNzKHRoaXMudHJhbnNmZXJTdHlsZShub2RlLCBuZXdOb2RlKSk7XG4gIH1cblxuICBwcml2YXRlIHN0cmlwQ2xhc3Mobm9kZTogTm9kZSk6IE5vZGUge1xuICAgIGlmIChub2RlLm5vZGVUeXBlID09IE5vZGUuRUxFTUVOVF9OT0RFKSB7XG4gICAgICAobm9kZSBhcyBFbGVtZW50KS5yZW1vdmVBdHRyaWJ1dGUoJ2NsYXNzJyk7XG4gICAgfVxuICAgIHJldHVybiBub2RlO1xuICB9XG5cbiAgcHJpdmF0ZSB0cmFuc2ZlclN0eWxlKG9yaWdOb2RlOiBOb2RlLCBub2RlOiBOb2RlKTogTm9kZSB7XG4gICAgaWYgKG5vZGUubm9kZVR5cGUgIT0gTm9kZS5FTEVNRU5UX05PREUpIHJldHVybiBub2RlO1xuICAgIGNvbnN0IGVsID0gbm9kZSBhcyBIVE1MRWxlbWVudDtcbiAgICBjb25zdCBub2RlTmFtZSA9IG5vZGUubm9kZU5hbWUudG9VcHBlckNhc2UoKTtcbiAgICBjb25zdCBzdHlsZSA9IHdpbmRvdy5nZXRDb21wdXRlZFN0eWxlKG9yaWdOb2RlIGFzIEhUTUxFbGVtZW50KTtcblxuICAgIGlmIChub2RlTmFtZSA9PSBOb2RlTmFtZS5URVhUKSB7XG4gICAgICBPYmplY3QuYXNzaWduKGVsLnN0eWxlLCB7XG4gICAgICAgIGZvbnRGYW1pbHk6IHN0eWxlLmZvbnRGYW1pbHksXG4gICAgICAgIGZvbnRTaXplOiBzdHlsZS5mb250U2l6ZSxcbiAgICAgICAgZm9udFdlaWdodDogc3R5bGUuZm9udFdlaWdodCxcbiAgICAgIH0pO1xuICAgIH1cblxuICAgIGlmIChub2RlTmFtZSAhPSBOb2RlTmFtZS5HUk9VUCkge1xuICAgICAgZWwuc2V0QXR0cmlidXRlKCdmaWxsJywgc3R5bGUuZmlsbCk7XG4gICAgICBlbC5zZXRBdHRyaWJ1dGUoJ3N0cm9rZScsIHN0eWxlLnN0cm9rZSk7XG4gICAgICBlbC5zZXRBdHRyaWJ1dGUoJ3N0cm9rZS13aWR0aCcsIHN0eWxlLnN0cm9rZVdpZHRoKTtcbiAgICB9XG5cbiAgICBpZiAoc3R5bGUub3BhY2l0eSAhPSAnMScpIGVsLnNldEF0dHJpYnV0ZSgnb3BhY2l0eScsIHN0eWxlLm9wYWNpdHkpO1xuXG4gICAgcmV0dXJuIG5vZGU7XG4gIH1cblxuICBwcm90ZWN0ZWQgc2hvdWxkT21pdE5vZGUobm9kZTogTm9kZSk6IGJvb2xlYW4ge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxufVxuXG5leHBvcnQgY2xhc3MgTGluZUNoYXJ0RXhwb3J0ZXIgZXh0ZW5kcyBQbG90dGFibGVFeHBvcnRlciB7XG4gIHNob3VsZE9taXROb2RlKG5vZGU6IE5vZGUpOiBib29sZWFuIHtcbiAgICAvLyBTY2F0dGVyIHBsb3QgaXMgdXNlZnVsIGZvciB0b29sdGlwLiBUb29sdGlwIGlzIG1lYW5pbmdsZXNzIGluIHRoZVxuICAgIC8vIGV4cG9ydGVkIHN2Zy5cbiAgICBpZiAobm9kZS5ub2RlVHlwZSA9PSBOb2RlLkVMRU1FTlRfTk9ERSkge1xuICAgICAgcmV0dXJuIChub2RlIGFzIEVsZW1lbnQpLmNsYXNzTGlzdC5jb250YWlucygnc2NhdHRlci1wbG90Jyk7XG4gICAgfVxuICAgIHJldHVybiBmYWxzZTtcbiAgfVxufVxuXG59XG4iXX0=