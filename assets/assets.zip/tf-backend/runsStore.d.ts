declare namespace tf_backend {
    class RunsStore extends BaseStore {
        private _runs;
        load(): Promise<void>;
        /**
         * Get the current list of runs. If no data is available, this will be
         * an empty array (i.e., there is no distinction between "no runs" and
         * "no runs yet").
         */
        getRuns(): string[];
    }
    const runsStore: RunsStore;
}
