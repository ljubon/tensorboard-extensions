var __assign = (this && this.__assign) || Object.assign || function(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
        s = arguments[i];
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
            t[p] = s[p];
    }
    return t;
};
/* Copyright 2015 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
var tf_storage;
(function (tf_storage) {
    var _a, _b, _c, _d;
    /**
     * A keyword that users cannot use, since TensorBoard uses this to store info
     * about the active tab.
     */
    tf_storage.TAB = '__tab__';
    /**
     * The name of the property for users to set on a Polymer component
     * in order for its stored properties to be stored in the URI unambiguously.
     * (No need to set this if you want multiple instances of the component to
     * share URI state)
     *
     * Example:
     * <my-component disambiguator="0"></my-component>
     *
     * The disambiguator should be set to any unique value so that multiple
     * instances of the component can store properties in URI storage.
     *
     * Because it's hard to dereference this variable in HTML property bindings,
     * it is NOT safe to change the disambiguator string without find+replace
     * across the codebase.
     */
    tf_storage.DISAMBIGUATOR = 'disambiguator';
    _a = makeBindings(function (x) { return x; }, function (x) { return x; }), tf_storage.getString = _a.get, tf_storage.setString = _a.set, tf_storage.getStringInitializer = _a.getInitializer, tf_storage.getStringObserver = _a.getObserver, tf_storage.disposeStringBinding = _a.disposeBinding;
    _b = makeBindings(function (s) { return (s === 'true' ? true : s === 'false' ? false : undefined); }, function (b) { return b.toString(); }), tf_storage.getBoolean = _b.get, tf_storage.setBoolean = _b.set, tf_storage.getBooleanInitializer = _b.getInitializer, tf_storage.getBooleanObserver = _b.getObserver, tf_storage.disposeBooleanBinding = _b.disposeBinding;
    _c = makeBindings(function (s) { return +s; }, function (n) { return n.toString(); }), tf_storage.getNumber = _c.get, tf_storage.setNumber = _c.set, tf_storage.getNumberInitializer = _c.getInitializer, tf_storage.getNumberObserver = _c.getObserver, tf_storage.disposeNumberBinding = _c.disposeBinding;
    _d = makeBindings(function (s) { return JSON.parse(atob(s)); }, function (o) { return btoa(JSON.stringify(o)); }), tf_storage.getObject = _d.get, tf_storage.setObject = _d.set, tf_storage.getObjectInitializer = _d.getInitializer, tf_storage.getObjectObserver = _d.getObserver, tf_storage.disposeObjectBinding = _d.disposeBinding;
    function makeBindings(fromString, toString) {
        var hashListeners = [];
        var storageListeners = [];
        function get(key, options) {
            if (options === void 0) { options = {}; }
            var defaultValue = options.defaultValue, _a = options.useLocalStorage, useLocalStorage = _a === void 0 ? false : _a;
            var value = useLocalStorage ?
                window.localStorage.getItem(key) :
                componentToDict(readComponent())[key];
            return value == undefined ? _.cloneDeep(defaultValue) : fromString(value);
        }
        function set(key, value, options) {
            if (options === void 0) { options = {}; }
            var defaultValue = options.defaultValue, _a = options.useLocalStorage, useLocalStorage = _a === void 0 ? false : _a, _b = options.useLocationReplace, useLocationReplace = _b === void 0 ? false : _b;
            var stringValue = toString(value);
            if (useLocalStorage) {
                window.localStorage.setItem(key, stringValue);
                // Because of listeners.ts:[1], we need to manually notify all UI elements
                // listening to storage within the tab of a change.
                tf_storage.fireStorageChanged();
            }
            else if (!_.isEqual(value, get(key, { useLocalStorage: useLocalStorage }))) {
                if (_.isEqual(value, defaultValue)) {
                    unsetFromURI(key);
                }
                else {
                    var items = componentToDict(readComponent());
                    items[key] = stringValue;
                    writeComponent(dictToComponent(items), useLocationReplace);
                }
            }
        }
        /**
         * Returns a function that can be used on a `value` declaration to a Polymer
         * property. It updates the `polymerProperty` when storage changes -- i.e.,
         * when `useLocalStorage`, it listens to storage change from another tab and
         * when `useLocalStorage=false`, it listens to hashchange.
         */
        function getInitializer(key, options) {
            var fullOptions = __assign({ defaultValue: options.defaultValue, polymerProperty: key, useLocalStorage: false }, options);
            return function () {
                var _this = this;
                var uriStorageName = getURIStorageName(this, key);
                // setComponentValue will be called every time the underlying storage
                // changes and is responsible for ensuring that new state will propagate
                // to the component with specified property. It is important that this
                // function does not re-assign needlessly, to avoid Polymer observer
                // churn.
                var setComponentValue = function () {
                    var storedValue = get(uriStorageName, fullOptions);
                    var currentValue = _this[fullOptions.polymerProperty];
                    if (!_.isEqual(storedValue, currentValue)) {
                        _this[fullOptions.polymerProperty] = storedValue;
                    }
                };
                var addListener = fullOptions.useLocalStorage ?
                    tf_storage.addStorageListener :
                    tf_storage.addHashListener;
                // TODO(stephanwlee): When using fakeHash, it _should not_ listen to the
                //                    window.hashchange.
                var listenKey = addListener(function () { return setComponentValue(); });
                if (fullOptions.useLocalStorage) {
                    storageListeners.push(listenKey);
                }
                else {
                    hashListeners.push(listenKey);
                }
                // Set the value on the property.
                setComponentValue();
                return this[fullOptions.polymerProperty];
            };
        }
        function disposeBinding() {
            hashListeners.forEach(function (key) { return tf_storage.removeHashListenerByKey(key); });
            storageListeners.forEach(function (key) { return tf_storage.removeStorageListenerByKey(key); });
        }
        function getObserver(key, options) {
            var fullOptions = __assign({ defaultValue: options.defaultValue, polymerProperty: key, useLocalStorage: false }, options);
            return function () {
                var uriStorageName = getURIStorageName(this, key);
                var newVal = this[fullOptions.polymerProperty];
                set(uriStorageName, newVal, fullOptions);
            };
        }
        return { get: get, set: set, getInitializer: getInitializer, getObserver: getObserver, disposeBinding: disposeBinding };
    }
    tf_storage.makeBindings = makeBindings;
    /**
     * Get a unique storage name for a (Polymer component, propertyName) tuple.
     *
     * DISAMBIGUATOR must be set on the component, if other components use the
     * same propertyName.
     */
    function getURIStorageName(component, propertyName) {
        var d = component[tf_storage.DISAMBIGUATOR];
        var components = d == null ? [propertyName] : [d, propertyName];
        return components.join('.');
    }
    /**
     * Read component from URI (e.g. returns "events&runPrefix=train*").
     */
    function readComponent() {
        return tf_globals.useHash() ? window.location.hash.slice(1) : tf_globals.getFakeHash();
    }
    /**
     * Write component to URI.
     */
    function writeComponent(component, useLocationReplace) {
        if (useLocationReplace === void 0) { useLocationReplace = false; }
        if (tf_globals.useHash()) {
            if (useLocationReplace) {
                window.location.replace('#' + component);
            }
            else {
                window.location.hash = component;
            }
        }
        else {
            tf_globals.setFakeHash(component);
        }
    }
    /**
     * Convert dictionary of strings into a URI Component.
     * All key value entries get added as key value pairs in the component,
     * with the exception of a key with the TAB value, which if present
     * gets prepended to the URI Component string for backwards compatibility
     * reasons.
     */
    function dictToComponent(items) {
        var component = '';
        // Add the tab name e.g. 'events', 'images', 'histograms' as a prefix
        // for backwards compatbility.
        if (items[tf_storage.TAB] !== undefined) {
            component += items[tf_storage.TAB];
        }
        // Join other strings with &key=value notation
        var nonTab = Object.keys(items)
            .map(function (key) { return [key, items[key]]; })
            .filter(function (pair) { return pair[0] !== tf_storage.TAB; })
            .map(function (pair) {
            return encodeURIComponent(pair[0]) + '=' +
                encodeURIComponent(pair[1]);
        })
            .join('&');
        return nonTab.length > 0 ? (component + '&' + nonTab) : component;
    }
    /**
     * Convert a URI Component into a dictionary of strings.
     * Component should consist of key-value pairs joined by a delimiter
     * with the exception of the tabName.
     * Returns dict consisting of all key-value pairs and
     * dict[TAB] = tabName
     */
    function componentToDict(component) {
        var items = {};
        var tokens = component.split('&');
        tokens.forEach(function (token) {
            var kv = token.split('=');
            // Special backwards compatibility for URI components like #scalars.
            if (kv.length === 1) {
                items[tf_storage.TAB] = kv[0];
            }
            else if (kv.length === 2) {
                items[decodeURIComponent(kv[0])] = decodeURIComponent(kv[1]);
            }
        });
        return items;
    }
    /**
     * Delete a key from the URI.
     */
    function unsetFromURI(key) {
        var items = componentToDict(readComponent());
        delete items[key];
        writeComponent(dictToComponent(items));
    }
})(tf_storage || (tf_storage = {})); // namespace tf_storage
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RvcmFnZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbInN0b3JhZ2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBQTs7Ozs7Ozs7Ozs7OztnRkFhZ0Y7QUFDaEYsSUFBVSxVQUFVLENBNFNuQjtBQTVTRCxXQUFVLFVBQVU7O0lBYXBCOzs7T0FHRztJQUNVLGNBQUcsR0FBRyxTQUFTLENBQUM7SUFFN0I7Ozs7Ozs7Ozs7Ozs7OztPQWVHO0lBQ1Usd0JBQWEsR0FBRyxlQUFlLENBQUM7SUFFaEMseUVBTW1CLEVBTDlCLDZCQUFjLEVBQ2QsNkJBQWMsRUFDZCxtREFBb0MsRUFDcEMsNkNBQThCLEVBQzlCLG1EQUFvQyxDQUNMO0lBRXBCLDRJQVFPLEVBUGxCLDhCQUFlLEVBQ2YsOEJBQWUsRUFDZixvREFBcUMsRUFDckMsOENBQStCLEVBQy9CLG9EQUFxQyxDQUdsQjtJQUVSLHFGQVFPLEVBUGxCLDZCQUFjLEVBQ2QsNkJBQWMsRUFDZCxtREFBb0MsRUFDcEMsNkNBQThCLEVBQzlCLG1EQUFvQyxDQUdqQjtJQUVSLGlIQVFrQixFQVA3Qiw2QkFBYyxFQUNkLDZCQUFjLEVBQ2QsbURBQW9DLEVBQ3BDLDZDQUE4QixFQUM5QixtREFBb0MsQ0FHTjtJQWlCaEMsc0JBQWdDLFVBQXlCLEVBQUUsUUFBdUI7UUFPaEYsSUFBTSxhQUFhLEdBQUcsRUFBRSxDQUFDO1FBQ3pCLElBQU0sZ0JBQWdCLEdBQUcsRUFBRSxDQUFDO1FBRTVCLGFBQWEsR0FBVyxFQUFFLE9BQStCO1lBQS9CLHdCQUFBLEVBQUEsWUFBK0I7WUFFckQsSUFBQSxtQ0FBWSxFQUNaLDRCQUF1QixFQUF2Qiw0Q0FBdUIsQ0FDYjtZQUNaLElBQU0sS0FBSyxHQUFHLGVBQWUsQ0FBQyxDQUFDO2dCQUM3QixNQUFNLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO2dCQUNsQyxlQUFlLENBQUMsYUFBYSxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUN4QyxPQUFPLEtBQUssSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUM1RSxDQUFDO1FBRUQsYUFBYSxHQUFXLEVBQUUsS0FBUSxFQUFFLE9BQThCO1lBQTlCLHdCQUFBLEVBQUEsWUFBOEI7WUFFOUQsSUFBQSxtQ0FBWSxFQUNaLDRCQUF1QixFQUF2Qiw0Q0FBdUIsRUFDdkIsK0JBQTBCLEVBQTFCLCtDQUEwQixDQUNoQjtZQUNaLElBQU0sV0FBVyxHQUFHLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUNwQyxJQUFJLGVBQWUsRUFBRTtnQkFDbkIsTUFBTSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsR0FBRyxFQUFFLFdBQVcsQ0FBQyxDQUFDO2dCQUM5QywwRUFBMEU7Z0JBQzFFLG1EQUFtRDtnQkFDbkQsV0FBQSxrQkFBa0IsRUFBRSxDQUFDO2FBQ3RCO2lCQUFNLElBQUksQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSxHQUFHLENBQUMsR0FBRyxFQUFFLEVBQUMsZUFBZSxpQkFBQSxFQUFDLENBQUMsQ0FBQyxFQUFFO2dCQUN6RCxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLFlBQVksQ0FBQyxFQUFFO29CQUNsQyxZQUFZLENBQUMsR0FBRyxDQUFDLENBQUM7aUJBQ25CO3FCQUFNO29CQUNMLElBQU0sS0FBSyxHQUFHLGVBQWUsQ0FBQyxhQUFhLEVBQUUsQ0FBQyxDQUFDO29CQUMvQyxLQUFLLENBQUMsR0FBRyxDQUFDLEdBQUcsV0FBVyxDQUFDO29CQUN6QixjQUFjLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxFQUFFLGtCQUFrQixDQUFDLENBQUM7aUJBQzVEO2FBQ0Y7UUFDSCxDQUFDO1FBRUQ7Ozs7O1dBS0c7UUFDSCx3QkFBd0IsR0FBVyxFQUFFLE9BQTBCO1lBQzdELElBQU0sV0FBVyxjQUNmLFlBQVksRUFBRSxPQUFPLENBQUMsWUFBWSxFQUNsQyxlQUFlLEVBQUUsR0FBRyxFQUNwQixlQUFlLEVBQUUsS0FBSyxJQUNuQixPQUFPLENBQ1gsQ0FBQztZQUNGLE9BQU87Z0JBQUEsaUJBK0JOO2dCQTlCQyxJQUFNLGNBQWMsR0FBRyxpQkFBaUIsQ0FBQyxJQUFJLEVBQUUsR0FBRyxDQUFDLENBQUM7Z0JBQ3BELHFFQUFxRTtnQkFDckUsd0VBQXdFO2dCQUN4RSxzRUFBc0U7Z0JBQ3RFLG9FQUFvRTtnQkFDcEUsU0FBUztnQkFDVCxJQUFNLGlCQUFpQixHQUFHO29CQUN4QixJQUFNLFdBQVcsR0FBRyxHQUFHLENBQUMsY0FBYyxFQUFFLFdBQVcsQ0FBQyxDQUFDO29CQUNyRCxJQUFNLFlBQVksR0FBRyxLQUFJLENBQUMsV0FBVyxDQUFDLGVBQWUsQ0FBQyxDQUFDO29CQUN2RCxJQUFJLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxXQUFXLEVBQUUsWUFBWSxDQUFDLEVBQUU7d0JBQ3pDLEtBQUksQ0FBQyxXQUFXLENBQUMsZUFBZSxDQUFDLEdBQUcsV0FBVyxDQUFDO3FCQUNqRDtnQkFDSCxDQUFDLENBQUM7Z0JBRUYsSUFBTSxXQUFXLEdBQUcsV0FBVyxDQUFDLGVBQWUsQ0FBQyxDQUFDO29CQUM3QyxXQUFBLGtCQUFrQixDQUFDLENBQUM7b0JBQ3BCLFdBQUEsZUFBZSxDQUFDO2dCQUVwQix3RUFBd0U7Z0JBQ3hFLHdDQUF3QztnQkFDeEMsSUFBTSxTQUFTLEdBQUcsV0FBVyxDQUFDLGNBQU0sT0FBQSxpQkFBaUIsRUFBRSxFQUFuQixDQUFtQixDQUFDLENBQUM7Z0JBQ3pELElBQUksV0FBVyxDQUFDLGVBQWUsRUFBRTtvQkFDL0IsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO2lCQUNsQztxQkFBTTtvQkFDTCxhQUFhLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO2lCQUMvQjtnQkFFRCxpQ0FBaUM7Z0JBQ2pDLGlCQUFpQixFQUFFLENBQUM7Z0JBQ3BCLE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQyxlQUFlLENBQUMsQ0FBQztZQUMzQyxDQUFDLENBQUM7UUFDSixDQUFDO1FBRUQ7WUFDRSxhQUFhLENBQUMsT0FBTyxDQUFDLFVBQUEsR0FBRyxJQUFJLE9BQUEsV0FBQSx1QkFBdUIsQ0FBQyxHQUFHLENBQUMsRUFBNUIsQ0FBNEIsQ0FBQyxDQUFDO1lBQzNELGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxVQUFBLEdBQUcsSUFBSSxPQUFBLFdBQUEsMEJBQTBCLENBQUMsR0FBRyxDQUFDLEVBQS9CLENBQStCLENBQUMsQ0FBQztRQUNuRSxDQUFDO1FBRUQscUJBQXFCLEdBQVcsRUFBRSxPQUEwQjtZQUMxRCxJQUFNLFdBQVcsY0FDZixZQUFZLEVBQUUsT0FBTyxDQUFDLFlBQVksRUFDbEMsZUFBZSxFQUFFLEdBQUcsRUFDcEIsZUFBZSxFQUFFLEtBQUssSUFDbkIsT0FBTyxDQUNYLENBQUM7WUFDRixPQUFPO2dCQUNMLElBQU0sY0FBYyxHQUFHLGlCQUFpQixDQUFDLElBQUksRUFBRSxHQUFHLENBQUMsQ0FBQztnQkFDcEQsSUFBTSxNQUFNLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxlQUFlLENBQUMsQ0FBQztnQkFDakQsR0FBRyxDQUFDLGNBQWMsRUFBRSxNQUFNLEVBQUUsV0FBVyxDQUFDLENBQUM7WUFDM0MsQ0FBQyxDQUFDO1FBQ0osQ0FBQztRQUVELE9BQU8sRUFBQyxHQUFHLEtBQUEsRUFBRSxHQUFHLEtBQUEsRUFBRSxjQUFjLGdCQUFBLEVBQUUsV0FBVyxhQUFBLEVBQUUsY0FBYyxnQkFBQSxFQUFDLENBQUM7SUFDakUsQ0FBQztJQS9HZSx1QkFBWSxlQStHM0IsQ0FBQTtJQUVEOzs7OztPQUtHO0lBQ0gsMkJBQ0ksU0FBYSxFQUFFLFlBQW9CO1FBQ3JDLElBQU0sQ0FBQyxHQUFHLFNBQVMsQ0FBQyxXQUFBLGFBQWEsQ0FBQyxDQUFDO1FBQ25DLElBQU0sVUFBVSxHQUFHLENBQUMsSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLFlBQVksQ0FBQyxDQUFDO1FBQ2xFLE9BQU8sVUFBVSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztJQUM5QixDQUFDO0lBR0Q7O09BRUc7SUFDSDtRQUNFLE9BQU8sVUFBVSxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxXQUFXLEVBQUUsQ0FBQztJQUN6RixDQUFDO0lBRUQ7O09BRUc7SUFDSCx3QkFBd0IsU0FBaUIsRUFBRSxrQkFBMEI7UUFBMUIsbUNBQUEsRUFBQSwwQkFBMEI7UUFDbkUsSUFBSSxVQUFVLENBQUMsT0FBTyxFQUFFLEVBQUU7WUFDeEIsSUFBSSxrQkFBa0IsRUFBRTtnQkFDdEIsTUFBTSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsR0FBRyxHQUFHLFNBQVMsQ0FBQyxDQUFDO2FBQzFDO2lCQUFNO2dCQUNMLE1BQU0sQ0FBQyxRQUFRLENBQUMsSUFBSSxHQUFHLFNBQVMsQ0FBQzthQUNsQztTQUNGO2FBQU07WUFDTCxVQUFVLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxDQUFDO1NBQ25DO0lBQ0gsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILHlCQUF5QixLQUFpQjtRQUN4QyxJQUFJLFNBQVMsR0FBRyxFQUFFLENBQUM7UUFFbkIscUVBQXFFO1FBQ3JFLDhCQUE4QjtRQUM5QixJQUFJLEtBQUssQ0FBQyxXQUFBLEdBQUcsQ0FBQyxLQUFLLFNBQVMsRUFBRTtZQUM1QixTQUFTLElBQUksS0FBSyxDQUFDLFdBQUEsR0FBRyxDQUFDLENBQUM7U0FDekI7UUFFRCw4Q0FBOEM7UUFDOUMsSUFBTSxNQUFNLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUM7YUFDNUIsR0FBRyxDQUFDLFVBQUEsR0FBRyxJQUFJLE9BQUEsQ0FBQyxHQUFHLEVBQUUsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQWpCLENBQWlCLENBQUM7YUFDN0IsTUFBTSxDQUFDLFVBQUMsSUFBSSxJQUFNLE9BQUEsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLFdBQUEsR0FBRyxFQUFmLENBQWUsQ0FBQzthQUNsQyxHQUFHLENBQUMsVUFBQyxJQUFJO1lBQ1QsT0FBTyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHO2dCQUNwQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUNqQyxDQUFDLENBQUM7YUFDRCxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7UUFFZixPQUFPLE1BQU0sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsR0FBRyxHQUFHLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQztJQUNwRSxDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0gseUJBQXlCLFNBQWlCO1FBQ3hDLElBQU0sS0FBSyxHQUFHLEVBQWdCLENBQUM7UUFFL0IsSUFBTSxNQUFNLEdBQUcsU0FBUyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUNwQyxNQUFNLENBQUMsT0FBTyxDQUFDLFVBQUMsS0FBSztZQUNuQixJQUFNLEVBQUUsR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQzVCLG9FQUFvRTtZQUNwRSxJQUFJLEVBQUUsQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO2dCQUNuQixLQUFLLENBQUMsV0FBQSxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFDcEI7aUJBQU0sSUFBSSxFQUFFLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtnQkFDMUIsS0FBSyxDQUFDLGtCQUFrQixDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsa0JBQWtCLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFDOUQ7UUFDSCxDQUFDLENBQUMsQ0FBQztRQUNILE9BQU8sS0FBSyxDQUFDO0lBQ2YsQ0FBQztJQUVEOztPQUVHO0lBQ0gsc0JBQXNCLEdBQUc7UUFDdkIsSUFBTSxLQUFLLEdBQUcsZUFBZSxDQUFDLGFBQWEsRUFBRSxDQUFDLENBQUM7UUFDL0MsT0FBTyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDbEIsY0FBYyxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO0lBQ3pDLENBQUM7QUFFRCxDQUFDLEVBNVNTLFVBQVUsS0FBVixVQUFVLFFBNFNuQixDQUFFLHVCQUF1QiIsInNvdXJjZXNDb250ZW50IjpbIi8qIENvcHlyaWdodCAyMDE1IFRoZSBUZW5zb3JGbG93IEF1dGhvcnMuIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG5cbkxpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSBcIkxpY2Vuc2VcIik7XG55b3UgbWF5IG5vdCB1c2UgdGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlIHdpdGggdGhlIExpY2Vuc2UuXG5Zb3UgbWF5IG9idGFpbiBhIGNvcHkgb2YgdGhlIExpY2Vuc2UgYXRcblxuICAgIGh0dHA6Ly93d3cuYXBhY2hlLm9yZy9saWNlbnNlcy9MSUNFTlNFLTIuMFxuXG5Vbmxlc3MgcmVxdWlyZWQgYnkgYXBwbGljYWJsZSBsYXcgb3IgYWdyZWVkIHRvIGluIHdyaXRpbmcsIHNvZnR3YXJlXG5kaXN0cmlidXRlZCB1bmRlciB0aGUgTGljZW5zZSBpcyBkaXN0cmlidXRlZCBvbiBhbiBcIkFTIElTXCIgQkFTSVMsXG5XSVRIT1VUIFdBUlJBTlRJRVMgT1IgQ09ORElUSU9OUyBPRiBBTlkgS0lORCwgZWl0aGVyIGV4cHJlc3Mgb3IgaW1wbGllZC5cblNlZSB0aGUgTGljZW5zZSBmb3IgdGhlIHNwZWNpZmljIGxhbmd1YWdlIGdvdmVybmluZyBwZXJtaXNzaW9ucyBhbmRcbmxpbWl0YXRpb25zIHVuZGVyIHRoZSBMaWNlbnNlLlxuPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09Ki9cbm5hbWVzcGFjZSB0Zl9zdG9yYWdlIHtcblxuLyoqXG4gKiBUaGUgU3RvcmFnZSBNb2R1bGUgcHJvdmlkZXMgc3RvcmFnZSBmb3IgcGVyc2lzdGluZyBzdGF0ZSBpbiBVUkkgb3JcbiAqIGxvY2FsU3RvcmFnZS5cbiAqXG4gKiBXaGVuIHVzaW5nIFVSSSBhcyB0aGUgc3RvcmFnZSBtZWNoYW5pc20sIGl0IGdlbmVyYXRlcyBVUkkgY29tcG9uZW50cyBsaWtlOlxuICogI2V2ZW50cyZydW5QcmVmaXg9dHJhaW4qLlxuICogSXQgYWxzbyBhbGxvd3Mgc2F2aW5nIHRoZSB2YWx1ZXMgdG8gbG9jYWxTdG9yYWdlIGZvciBub24tbm9pc3kgYW5kIGxhcmdlclxuICogZGF0YSBwZXJzaXN0ZW5jZS5cbiAqL1xudHlwZSBTdHJpbmdEaWN0ID0ge1trZXk6IHN0cmluZ106IHN0cmluZ307XG5cbi8qKlxuICogQSBrZXl3b3JkIHRoYXQgdXNlcnMgY2Fubm90IHVzZSwgc2luY2UgVGVuc29yQm9hcmQgdXNlcyB0aGlzIHRvIHN0b3JlIGluZm9cbiAqIGFib3V0IHRoZSBhY3RpdmUgdGFiLlxuICovXG5leHBvcnQgY29uc3QgVEFCID0gJ19fdGFiX18nO1xuXG4vKipcbiAqIFRoZSBuYW1lIG9mIHRoZSBwcm9wZXJ0eSBmb3IgdXNlcnMgdG8gc2V0IG9uIGEgUG9seW1lciBjb21wb25lbnRcbiAqIGluIG9yZGVyIGZvciBpdHMgc3RvcmVkIHByb3BlcnRpZXMgdG8gYmUgc3RvcmVkIGluIHRoZSBVUkkgdW5hbWJpZ3VvdXNseS5cbiAqIChObyBuZWVkIHRvIHNldCB0aGlzIGlmIHlvdSB3YW50IG11bHRpcGxlIGluc3RhbmNlcyBvZiB0aGUgY29tcG9uZW50IHRvXG4gKiBzaGFyZSBVUkkgc3RhdGUpXG4gKlxuICogRXhhbXBsZTpcbiAqIDxteS1jb21wb25lbnQgZGlzYW1iaWd1YXRvcj1cIjBcIj48L215LWNvbXBvbmVudD5cbiAqXG4gKiBUaGUgZGlzYW1iaWd1YXRvciBzaG91bGQgYmUgc2V0IHRvIGFueSB1bmlxdWUgdmFsdWUgc28gdGhhdCBtdWx0aXBsZVxuICogaW5zdGFuY2VzIG9mIHRoZSBjb21wb25lbnQgY2FuIHN0b3JlIHByb3BlcnRpZXMgaW4gVVJJIHN0b3JhZ2UuXG4gKlxuICogQmVjYXVzZSBpdCdzIGhhcmQgdG8gZGVyZWZlcmVuY2UgdGhpcyB2YXJpYWJsZSBpbiBIVE1MIHByb3BlcnR5IGJpbmRpbmdzLFxuICogaXQgaXMgTk9UIHNhZmUgdG8gY2hhbmdlIHRoZSBkaXNhbWJpZ3VhdG9yIHN0cmluZyB3aXRob3V0IGZpbmQrcmVwbGFjZVxuICogYWNyb3NzIHRoZSBjb2RlYmFzZS5cbiAqL1xuZXhwb3J0IGNvbnN0IERJU0FNQklHVUFUT1IgPSAnZGlzYW1iaWd1YXRvcic7XG5cbmV4cG9ydCBjb25zdCB7XG4gIGdldDogZ2V0U3RyaW5nLFxuICBzZXQ6IHNldFN0cmluZyxcbiAgZ2V0SW5pdGlhbGl6ZXI6IGdldFN0cmluZ0luaXRpYWxpemVyLFxuICBnZXRPYnNlcnZlcjogZ2V0U3RyaW5nT2JzZXJ2ZXIsXG4gIGRpc3Bvc2VCaW5kaW5nOiBkaXNwb3NlU3RyaW5nQmluZGluZyxcbn0gPSBtYWtlQmluZGluZ3MoeCA9PiB4LCB4ID0+IHgpO1xuXG5leHBvcnQgY29uc3Qge1xuICBnZXQ6IGdldEJvb2xlYW4sXG4gIHNldDogc2V0Qm9vbGVhbixcbiAgZ2V0SW5pdGlhbGl6ZXI6IGdldEJvb2xlYW5Jbml0aWFsaXplcixcbiAgZ2V0T2JzZXJ2ZXI6IGdldEJvb2xlYW5PYnNlcnZlcixcbiAgZGlzcG9zZUJpbmRpbmc6IGRpc3Bvc2VCb29sZWFuQmluZGluZyxcbn0gPSBtYWtlQmluZGluZ3MoXG4gIHMgPT4gKHMgPT09ICd0cnVlJyA/IHRydWU6IHMgPT09ICdmYWxzZScgPyBmYWxzZSA6IHVuZGVmaW5lZCksXG4gIGIgPT4gYi50b1N0cmluZygpKTtcblxuZXhwb3J0IGNvbnN0IHtcbiAgZ2V0OiBnZXROdW1iZXIsXG4gIHNldDogc2V0TnVtYmVyLFxuICBnZXRJbml0aWFsaXplcjogZ2V0TnVtYmVySW5pdGlhbGl6ZXIsXG4gIGdldE9ic2VydmVyOiBnZXROdW1iZXJPYnNlcnZlcixcbiAgZGlzcG9zZUJpbmRpbmc6IGRpc3Bvc2VOdW1iZXJCaW5kaW5nLFxufSA9IG1ha2VCaW5kaW5ncyhcbiAgcyA9PiArcyxcbiAgbiA9PiBuLnRvU3RyaW5nKCkpO1xuXG5leHBvcnQgY29uc3Qge1xuICBnZXQ6IGdldE9iamVjdCxcbiAgc2V0OiBzZXRPYmplY3QsXG4gIGdldEluaXRpYWxpemVyOiBnZXRPYmplY3RJbml0aWFsaXplcixcbiAgZ2V0T2JzZXJ2ZXI6IGdldE9iamVjdE9ic2VydmVyLFxuICBkaXNwb3NlQmluZGluZzogZGlzcG9zZU9iamVjdEJpbmRpbmcsXG59ID0gbWFrZUJpbmRpbmdzKFxuICBzID0+IEpTT04ucGFyc2UoYXRvYihzKSksXG4gIG8gPT4gYnRvYShKU09OLnN0cmluZ2lmeShvKSkpO1xuXG5leHBvcnQgaW50ZXJmYWNlIFN0b3JhZ2VPcHRpb25zPFQ+IHtcbiAgZGVmYXVsdFZhbHVlPzogVDtcbiAgdXNlTG9jYWxTdG9yYWdlPzogYm9vbGVhbjtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBBdXRvU3RvcmFnZU9wdGlvbnM8VD4gZXh0ZW5kcyBTdG9yYWdlT3B0aW9uczxUPiB7XG4gIHBvbHltZXJQcm9wZXJ0eT86IHN0cmluZyxcbn1cblxuZXhwb3J0IGludGVyZmFjZSBTZXR0ZXJPcHRpb25zPFQ+IGV4dGVuZHMgU3RvcmFnZU9wdGlvbnM8VD4ge1xuICBkZWZhdWx0VmFsdWU/OiBUO1xuICB1c2VMb2NhbFN0b3JhZ2U/OiBib29sZWFuO1xuICB1c2VMb2NhdGlvblJlcGxhY2U/OiBib29sZWFuO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gbWFrZUJpbmRpbmdzPFQ+KGZyb21TdHJpbmc6IChzdHJpbmcpID0+IFQsIHRvU3RyaW5nOiAoVCkgPT4gc3RyaW5nKToge1xuICAgIGdldDogKGtleTogc3RyaW5nLCBvcHRpb24/OiBTdG9yYWdlT3B0aW9uczxUPikgPT4gVCxcbiAgICBzZXQ6IChrZXk6IHN0cmluZywgdmFsdWU6IFQsIG9wdGlvbj86IFNldHRlck9wdGlvbnM8VD4pID0+IHZvaWQsXG4gICAgZ2V0SW5pdGlhbGl6ZXI6IChrZXk6IHN0cmluZywgb3B0aW9uczogQXV0b1N0b3JhZ2VPcHRpb25zPFQ+KSA9PiBGdW5jdGlvbixcbiAgICBnZXRPYnNlcnZlcjogKGtleTogc3RyaW5nLCBvcHRpb25zOiBBdXRvU3RvcmFnZU9wdGlvbnM8VD4pID0+IEZ1bmN0aW9uLFxuICAgIGRpc3Bvc2VCaW5kaW5nOiAoKSA9PiB2b2lkLFxufSB7XG4gIGNvbnN0IGhhc2hMaXN0ZW5lcnMgPSBbXTtcbiAgY29uc3Qgc3RvcmFnZUxpc3RlbmVycyA9IFtdO1xuXG4gIGZ1bmN0aW9uIGdldChrZXk6IHN0cmluZywgb3B0aW9uczogU3RvcmFnZU9wdGlvbnM8VD4gPSB7fSk6IFQge1xuICAgIGNvbnN0IHtcbiAgICAgIGRlZmF1bHRWYWx1ZSxcbiAgICAgIHVzZUxvY2FsU3RvcmFnZSA9IGZhbHNlLFxuICAgIH0gPSBvcHRpb25zO1xuICAgIGNvbnN0IHZhbHVlID0gdXNlTG9jYWxTdG9yYWdlID9cbiAgICAgIHdpbmRvdy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbShrZXkpIDpcbiAgICAgIGNvbXBvbmVudFRvRGljdChyZWFkQ29tcG9uZW50KCkpW2tleV07XG4gICAgcmV0dXJuIHZhbHVlID09IHVuZGVmaW5lZCA/IF8uY2xvbmVEZWVwKGRlZmF1bHRWYWx1ZSkgOiBmcm9tU3RyaW5nKHZhbHVlKTtcbiAgfVxuXG4gIGZ1bmN0aW9uIHNldChrZXk6IHN0cmluZywgdmFsdWU6IFQsIG9wdGlvbnM6IFNldHRlck9wdGlvbnM8VD4gPSB7fSk6IHZvaWQge1xuICAgIGNvbnN0IHtcbiAgICAgIGRlZmF1bHRWYWx1ZSxcbiAgICAgIHVzZUxvY2FsU3RvcmFnZSA9IGZhbHNlLFxuICAgICAgdXNlTG9jYXRpb25SZXBsYWNlID0gZmFsc2UsXG4gICAgfSA9IG9wdGlvbnM7XG4gICAgY29uc3Qgc3RyaW5nVmFsdWUgPSB0b1N0cmluZyh2YWx1ZSk7XG4gICAgaWYgKHVzZUxvY2FsU3RvcmFnZSkge1xuICAgICAgd2luZG93LmxvY2FsU3RvcmFnZS5zZXRJdGVtKGtleSwgc3RyaW5nVmFsdWUpO1xuICAgICAgLy8gQmVjYXVzZSBvZiBsaXN0ZW5lcnMudHM6WzFdLCB3ZSBuZWVkIHRvIG1hbnVhbGx5IG5vdGlmeSBhbGwgVUkgZWxlbWVudHNcbiAgICAgIC8vIGxpc3RlbmluZyB0byBzdG9yYWdlIHdpdGhpbiB0aGUgdGFiIG9mIGEgY2hhbmdlLlxuICAgICAgZmlyZVN0b3JhZ2VDaGFuZ2VkKCk7XG4gICAgfSBlbHNlIGlmICghXy5pc0VxdWFsKHZhbHVlLCBnZXQoa2V5LCB7dXNlTG9jYWxTdG9yYWdlfSkpKSB7XG4gICAgICBpZiAoXy5pc0VxdWFsKHZhbHVlLCBkZWZhdWx0VmFsdWUpKSB7XG4gICAgICAgIHVuc2V0RnJvbVVSSShrZXkpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY29uc3QgaXRlbXMgPSBjb21wb25lbnRUb0RpY3QocmVhZENvbXBvbmVudCgpKTtcbiAgICAgICAgaXRlbXNba2V5XSA9IHN0cmluZ1ZhbHVlO1xuICAgICAgICB3cml0ZUNvbXBvbmVudChkaWN0VG9Db21wb25lbnQoaXRlbXMpLCB1c2VMb2NhdGlvblJlcGxhY2UpO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm5zIGEgZnVuY3Rpb24gdGhhdCBjYW4gYmUgdXNlZCBvbiBhIGB2YWx1ZWAgZGVjbGFyYXRpb24gdG8gYSBQb2x5bWVyXG4gICAqIHByb3BlcnR5LiBJdCB1cGRhdGVzIHRoZSBgcG9seW1lclByb3BlcnR5YCB3aGVuIHN0b3JhZ2UgY2hhbmdlcyAtLSBpLmUuLFxuICAgKiB3aGVuIGB1c2VMb2NhbFN0b3JhZ2VgLCBpdCBsaXN0ZW5zIHRvIHN0b3JhZ2UgY2hhbmdlIGZyb20gYW5vdGhlciB0YWIgYW5kXG4gICAqIHdoZW4gYHVzZUxvY2FsU3RvcmFnZT1mYWxzZWAsIGl0IGxpc3RlbnMgdG8gaGFzaGNoYW5nZS5cbiAgICovXG4gIGZ1bmN0aW9uIGdldEluaXRpYWxpemVyKGtleTogc3RyaW5nLCBvcHRpb25zOiBTdG9yYWdlT3B0aW9uczxUPik6IEZ1bmN0aW9uIHtcbiAgICBjb25zdCBmdWxsT3B0aW9ucyA9IHtcbiAgICAgIGRlZmF1bHRWYWx1ZTogb3B0aW9ucy5kZWZhdWx0VmFsdWUsXG4gICAgICBwb2x5bWVyUHJvcGVydHk6IGtleSxcbiAgICAgIHVzZUxvY2FsU3RvcmFnZTogZmFsc2UsXG4gICAgICAuLi5vcHRpb25zLFxuICAgIH07XG4gICAgcmV0dXJuIGZ1bmN0aW9uKCkge1xuICAgICAgY29uc3QgdXJpU3RvcmFnZU5hbWUgPSBnZXRVUklTdG9yYWdlTmFtZSh0aGlzLCBrZXkpO1xuICAgICAgLy8gc2V0Q29tcG9uZW50VmFsdWUgd2lsbCBiZSBjYWxsZWQgZXZlcnkgdGltZSB0aGUgdW5kZXJseWluZyBzdG9yYWdlXG4gICAgICAvLyBjaGFuZ2VzIGFuZCBpcyByZXNwb25zaWJsZSBmb3IgZW5zdXJpbmcgdGhhdCBuZXcgc3RhdGUgd2lsbCBwcm9wYWdhdGVcbiAgICAgIC8vIHRvIHRoZSBjb21wb25lbnQgd2l0aCBzcGVjaWZpZWQgcHJvcGVydHkuIEl0IGlzIGltcG9ydGFudCB0aGF0IHRoaXNcbiAgICAgIC8vIGZ1bmN0aW9uIGRvZXMgbm90IHJlLWFzc2lnbiBuZWVkbGVzc2x5LCB0byBhdm9pZCBQb2x5bWVyIG9ic2VydmVyXG4gICAgICAvLyBjaHVybi5cbiAgICAgIGNvbnN0IHNldENvbXBvbmVudFZhbHVlID0gKCkgPT4ge1xuICAgICAgICBjb25zdCBzdG9yZWRWYWx1ZSA9IGdldCh1cmlTdG9yYWdlTmFtZSwgZnVsbE9wdGlvbnMpO1xuICAgICAgICBjb25zdCBjdXJyZW50VmFsdWUgPSB0aGlzW2Z1bGxPcHRpb25zLnBvbHltZXJQcm9wZXJ0eV07XG4gICAgICAgIGlmICghXy5pc0VxdWFsKHN0b3JlZFZhbHVlLCBjdXJyZW50VmFsdWUpKSB7XG4gICAgICAgICAgdGhpc1tmdWxsT3B0aW9ucy5wb2x5bWVyUHJvcGVydHldID0gc3RvcmVkVmFsdWU7XG4gICAgICAgIH1cbiAgICAgIH07XG5cbiAgICAgIGNvbnN0IGFkZExpc3RlbmVyID0gZnVsbE9wdGlvbnMudXNlTG9jYWxTdG9yYWdlID9cbiAgICAgICAgICBhZGRTdG9yYWdlTGlzdGVuZXIgOlxuICAgICAgICAgIGFkZEhhc2hMaXN0ZW5lcjtcblxuICAgICAgLy8gVE9ETyhzdGVwaGFud2xlZSk6IFdoZW4gdXNpbmcgZmFrZUhhc2gsIGl0IF9zaG91bGQgbm90XyBsaXN0ZW4gdG8gdGhlXG4gICAgICAvLyAgICAgICAgICAgICAgICAgICAgd2luZG93Lmhhc2hjaGFuZ2UuXG4gICAgICBjb25zdCBsaXN0ZW5LZXkgPSBhZGRMaXN0ZW5lcigoKSA9PiBzZXRDb21wb25lbnRWYWx1ZSgpKTtcbiAgICAgIGlmIChmdWxsT3B0aW9ucy51c2VMb2NhbFN0b3JhZ2UpIHtcbiAgICAgICAgc3RvcmFnZUxpc3RlbmVycy5wdXNoKGxpc3RlbktleSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBoYXNoTGlzdGVuZXJzLnB1c2gobGlzdGVuS2V5KTtcbiAgICAgIH1cblxuICAgICAgLy8gU2V0IHRoZSB2YWx1ZSBvbiB0aGUgcHJvcGVydHkuXG4gICAgICBzZXRDb21wb25lbnRWYWx1ZSgpO1xuICAgICAgcmV0dXJuIHRoaXNbZnVsbE9wdGlvbnMucG9seW1lclByb3BlcnR5XTtcbiAgICB9O1xuICB9XG5cbiAgZnVuY3Rpb24gZGlzcG9zZUJpbmRpbmcoKSB7XG4gICAgaGFzaExpc3RlbmVycy5mb3JFYWNoKGtleSA9PiByZW1vdmVIYXNoTGlzdGVuZXJCeUtleShrZXkpKTtcbiAgICBzdG9yYWdlTGlzdGVuZXJzLmZvckVhY2goa2V5ID0+IHJlbW92ZVN0b3JhZ2VMaXN0ZW5lckJ5S2V5KGtleSkpO1xuICB9XG5cbiAgZnVuY3Rpb24gZ2V0T2JzZXJ2ZXIoa2V5OiBzdHJpbmcsIG9wdGlvbnM6IFN0b3JhZ2VPcHRpb25zPFQ+KTogRnVuY3Rpb24ge1xuICAgIGNvbnN0IGZ1bGxPcHRpb25zID0ge1xuICAgICAgZGVmYXVsdFZhbHVlOiBvcHRpb25zLmRlZmF1bHRWYWx1ZSxcbiAgICAgIHBvbHltZXJQcm9wZXJ0eToga2V5LFxuICAgICAgdXNlTG9jYWxTdG9yYWdlOiBmYWxzZSxcbiAgICAgIC4uLm9wdGlvbnMsXG4gICAgfTtcbiAgICByZXR1cm4gZnVuY3Rpb24oKSB7XG4gICAgICBjb25zdCB1cmlTdG9yYWdlTmFtZSA9IGdldFVSSVN0b3JhZ2VOYW1lKHRoaXMsIGtleSk7XG4gICAgICBjb25zdCBuZXdWYWwgPSB0aGlzW2Z1bGxPcHRpb25zLnBvbHltZXJQcm9wZXJ0eV07XG4gICAgICBzZXQodXJpU3RvcmFnZU5hbWUsIG5ld1ZhbCwgZnVsbE9wdGlvbnMpO1xuICAgIH07XG4gIH1cblxuICByZXR1cm4ge2dldCwgc2V0LCBnZXRJbml0aWFsaXplciwgZ2V0T2JzZXJ2ZXIsIGRpc3Bvc2VCaW5kaW5nfTtcbn1cblxuLyoqXG4gKiBHZXQgYSB1bmlxdWUgc3RvcmFnZSBuYW1lIGZvciBhIChQb2x5bWVyIGNvbXBvbmVudCwgcHJvcGVydHlOYW1lKSB0dXBsZS5cbiAqXG4gKiBESVNBTUJJR1VBVE9SIG11c3QgYmUgc2V0IG9uIHRoZSBjb21wb25lbnQsIGlmIG90aGVyIGNvbXBvbmVudHMgdXNlIHRoZVxuICogc2FtZSBwcm9wZXJ0eU5hbWUuXG4gKi9cbmZ1bmN0aW9uIGdldFVSSVN0b3JhZ2VOYW1lKFxuICAgIGNvbXBvbmVudDoge30sIHByb3BlcnR5TmFtZTogc3RyaW5nKTogc3RyaW5nIHtcbiAgY29uc3QgZCA9IGNvbXBvbmVudFtESVNBTUJJR1VBVE9SXTtcbiAgY29uc3QgY29tcG9uZW50cyA9IGQgPT0gbnVsbCA/IFtwcm9wZXJ0eU5hbWVdIDogW2QsIHByb3BlcnR5TmFtZV07XG4gIHJldHVybiBjb21wb25lbnRzLmpvaW4oJy4nKTtcbn1cblxuXG4vKipcbiAqIFJlYWQgY29tcG9uZW50IGZyb20gVVJJIChlLmcuIHJldHVybnMgXCJldmVudHMmcnVuUHJlZml4PXRyYWluKlwiKS5cbiAqL1xuZnVuY3Rpb24gcmVhZENvbXBvbmVudCgpOiBzdHJpbmcge1xuICByZXR1cm4gdGZfZ2xvYmFscy51c2VIYXNoKCkgPyB3aW5kb3cubG9jYXRpb24uaGFzaC5zbGljZSgxKSA6IHRmX2dsb2JhbHMuZ2V0RmFrZUhhc2goKTtcbn1cblxuLyoqXG4gKiBXcml0ZSBjb21wb25lbnQgdG8gVVJJLlxuICovXG5mdW5jdGlvbiB3cml0ZUNvbXBvbmVudChjb21wb25lbnQ6IHN0cmluZywgdXNlTG9jYXRpb25SZXBsYWNlID0gZmFsc2UpIHtcbiAgaWYgKHRmX2dsb2JhbHMudXNlSGFzaCgpKSB7XG4gICAgaWYgKHVzZUxvY2F0aW9uUmVwbGFjZSkge1xuICAgICAgd2luZG93LmxvY2F0aW9uLnJlcGxhY2UoJyMnICsgY29tcG9uZW50KTtcbiAgICB9IGVsc2Uge1xuICAgICAgd2luZG93LmxvY2F0aW9uLmhhc2ggPSBjb21wb25lbnQ7XG4gICAgfVxuICB9IGVsc2Uge1xuICAgIHRmX2dsb2JhbHMuc2V0RmFrZUhhc2goY29tcG9uZW50KTtcbiAgfVxufVxuXG4vKipcbiAqIENvbnZlcnQgZGljdGlvbmFyeSBvZiBzdHJpbmdzIGludG8gYSBVUkkgQ29tcG9uZW50LlxuICogQWxsIGtleSB2YWx1ZSBlbnRyaWVzIGdldCBhZGRlZCBhcyBrZXkgdmFsdWUgcGFpcnMgaW4gdGhlIGNvbXBvbmVudCxcbiAqIHdpdGggdGhlIGV4Y2VwdGlvbiBvZiBhIGtleSB3aXRoIHRoZSBUQUIgdmFsdWUsIHdoaWNoIGlmIHByZXNlbnRcbiAqIGdldHMgcHJlcGVuZGVkIHRvIHRoZSBVUkkgQ29tcG9uZW50IHN0cmluZyBmb3IgYmFja3dhcmRzIGNvbXBhdGliaWxpdHlcbiAqIHJlYXNvbnMuXG4gKi9cbmZ1bmN0aW9uIGRpY3RUb0NvbXBvbmVudChpdGVtczogU3RyaW5nRGljdCk6IHN0cmluZyB7XG4gIGxldCBjb21wb25lbnQgPSAnJztcblxuICAvLyBBZGQgdGhlIHRhYiBuYW1lIGUuZy4gJ2V2ZW50cycsICdpbWFnZXMnLCAnaGlzdG9ncmFtcycgYXMgYSBwcmVmaXhcbiAgLy8gZm9yIGJhY2t3YXJkcyBjb21wYXRiaWxpdHkuXG4gIGlmIChpdGVtc1tUQUJdICE9PSB1bmRlZmluZWQpIHtcbiAgICBjb21wb25lbnQgKz0gaXRlbXNbVEFCXTtcbiAgfVxuXG4gIC8vIEpvaW4gb3RoZXIgc3RyaW5ncyB3aXRoICZrZXk9dmFsdWUgbm90YXRpb25cbiAgY29uc3Qgbm9uVGFiID0gT2JqZWN0LmtleXMoaXRlbXMpXG4gICAgICAubWFwKGtleSA9PiBba2V5LCBpdGVtc1trZXldXSlcbiAgICAgIC5maWx0ZXIoKHBhaXIpID0+ICBwYWlyWzBdICE9PSBUQUIpXG4gICAgICAubWFwKChwYWlyKSA9PiB7XG4gICAgICAgcmV0dXJuIGVuY29kZVVSSUNvbXBvbmVudChwYWlyWzBdKSArICc9JyArXG4gICAgICAgICAgIGVuY29kZVVSSUNvbXBvbmVudChwYWlyWzFdKTtcbiAgICAgIH0pXG4gICAgICAuam9pbignJicpO1xuXG4gIHJldHVybiBub25UYWIubGVuZ3RoID4gMCA/IChjb21wb25lbnQgKyAnJicgKyBub25UYWIpIDogY29tcG9uZW50O1xufVxuXG4vKipcbiAqIENvbnZlcnQgYSBVUkkgQ29tcG9uZW50IGludG8gYSBkaWN0aW9uYXJ5IG9mIHN0cmluZ3MuXG4gKiBDb21wb25lbnQgc2hvdWxkIGNvbnNpc3Qgb2Yga2V5LXZhbHVlIHBhaXJzIGpvaW5lZCBieSBhIGRlbGltaXRlclxuICogd2l0aCB0aGUgZXhjZXB0aW9uIG9mIHRoZSB0YWJOYW1lLlxuICogUmV0dXJucyBkaWN0IGNvbnNpc3Rpbmcgb2YgYWxsIGtleS12YWx1ZSBwYWlycyBhbmRcbiAqIGRpY3RbVEFCXSA9IHRhYk5hbWVcbiAqL1xuZnVuY3Rpb24gY29tcG9uZW50VG9EaWN0KGNvbXBvbmVudDogc3RyaW5nKTogU3RyaW5nRGljdCB7XG4gIGNvbnN0IGl0ZW1zID0ge30gYXMgU3RyaW5nRGljdDtcblxuICBjb25zdCB0b2tlbnMgPSBjb21wb25lbnQuc3BsaXQoJyYnKTtcbiAgdG9rZW5zLmZvckVhY2goKHRva2VuKSA9PiB7XG4gICAgY29uc3Qga3YgPSB0b2tlbi5zcGxpdCgnPScpO1xuICAgIC8vIFNwZWNpYWwgYmFja3dhcmRzIGNvbXBhdGliaWxpdHkgZm9yIFVSSSBjb21wb25lbnRzIGxpa2UgI3NjYWxhcnMuXG4gICAgaWYgKGt2Lmxlbmd0aCA9PT0gMSkge1xuICAgICAgaXRlbXNbVEFCXSA9IGt2WzBdO1xuICAgIH0gZWxzZSBpZiAoa3YubGVuZ3RoID09PSAyKSB7XG4gICAgICBpdGVtc1tkZWNvZGVVUklDb21wb25lbnQoa3ZbMF0pXSA9IGRlY29kZVVSSUNvbXBvbmVudChrdlsxXSk7XG4gICAgfVxuICB9KTtcbiAgcmV0dXJuIGl0ZW1zO1xufVxuXG4vKipcbiAqIERlbGV0ZSBhIGtleSBmcm9tIHRoZSBVUkkuXG4gKi9cbmZ1bmN0aW9uIHVuc2V0RnJvbVVSSShrZXkpIHtcbiAgY29uc3QgaXRlbXMgPSBjb21wb25lbnRUb0RpY3QocmVhZENvbXBvbmVudCgpKTtcbiAgZGVsZXRlIGl0ZW1zW2tleV07XG4gIHdyaXRlQ29tcG9uZW50KGRpY3RUb0NvbXBvbmVudChpdGVtcykpO1xufVxuXG59ICAvLyBuYW1lc3BhY2UgdGZfc3RvcmFnZVxuIl19