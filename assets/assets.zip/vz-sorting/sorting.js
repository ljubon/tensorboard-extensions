/* Copyright 2016 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
var vz_sorting;
(function (vz_sorting) {
    /**
     * Compares tag names asciinumerically broken into components.
     *
     * <p>This is the comparison function used for sorting most string values in
     * TensorBoard. Unlike the standard asciibetical comparator, this function
     * knows that 'a10b' > 'a2b'. Fixed point and engineering notation are
     * supported. This function also splits the input by slash and underscore to
     * perform array comparison. Therefore it knows that 'a/a' < 'a+/a' even
     * though '+' < '/' in the ASCII table.
     */
    function compareTagNames(a, b) {
        var ai = 0;
        var bi = 0;
        while (true) {
            if (ai === a.length) {
                return bi === b.length ? 0 : -1;
            }
            if (bi === b.length) {
                return 1;
            }
            if (isDigit(a[ai]) && isDigit(b[bi])) {
                var ais = ai;
                var bis = bi;
                ai = consumeNumber(a, ai + 1);
                bi = consumeNumber(b, bi + 1);
                var an = parseFloat(a.slice(ais, ai));
                var bn = parseFloat(b.slice(bis, bi));
                if (an < bn) {
                    return -1;
                }
                if (an > bn) {
                    return 1;
                }
                continue;
            }
            if (isBreak(a[ai])) {
                if (!isBreak(b[bi])) {
                    return -1;
                }
            }
            else if (isBreak(b[bi])) {
                return 1;
            }
            else if (a[ai] < b[bi]) {
                return -1;
            }
            else if (a[ai] > b[bi]) {
                return 1;
            }
            ai++;
            bi++;
        }
    }
    vz_sorting.compareTagNames = compareTagNames;
    function consumeNumber(s, i) {
        var State;
        (function (State) {
            State[State["NATURAL"] = 0] = "NATURAL";
            State[State["REAL"] = 1] = "REAL";
            State[State["EXPONENT_SIGN"] = 2] = "EXPONENT_SIGN";
            State[State["EXPONENT"] = 3] = "EXPONENT";
        })(State || (State = {}));
        var state = State.NATURAL;
        for (; i < s.length; i++) {
            if (state === State.NATURAL) {
                if (s[i] === '.') {
                    state = State.REAL;
                }
                else if (s[i] === 'e' || s[i] === 'E') {
                    state = State.EXPONENT_SIGN;
                }
                else if (!isDigit(s[i])) {
                    break;
                }
            }
            else if (state === State.REAL) {
                if (s[i] === 'e' || s[i] === 'E') {
                    state = State.EXPONENT_SIGN;
                }
                else if (!isDigit(s[i])) {
                    break;
                }
            }
            else if (state === State.EXPONENT_SIGN) {
                if (isDigit(s[i]) || s[i] === '+' || s[i] === '-') {
                    state = State.EXPONENT;
                }
                else {
                    break;
                }
            }
            else if (state === State.EXPONENT) {
                if (!isDigit(s[i])) {
                    break;
                }
            }
        }
        return i;
    }
    function isDigit(c) {
        return '0' <= c && c <= '9';
    }
    function isBreak(c) {
        // TODO(@jart): Remove underscore when people stop using it like a slash.
        return c === '/' || c === '_' || isDigit(c);
    }
})(vz_sorting || (vz_sorting = {})); // namespace vz_sorting
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic29ydGluZy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbInNvcnRpbmcudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7Ozs7Ozs7Z0ZBYWdGO0FBQ2hGLElBQVUsVUFBVSxDQStGbkI7QUEvRkQsV0FBVSxVQUFVO0lBRXBCOzs7Ozs7Ozs7T0FTRztJQUNILHlCQUFnQyxDQUFDLEVBQUUsQ0FBUztRQUMxQyxJQUFJLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDWCxJQUFJLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDWCxPQUFPLElBQUksRUFBRTtZQUNYLElBQUksRUFBRSxLQUFLLENBQUMsQ0FBQyxNQUFNLEVBQUU7Z0JBQ25CLE9BQU8sRUFBRSxLQUFLLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFDakM7WUFDRCxJQUFJLEVBQUUsS0FBSyxDQUFDLENBQUMsTUFBTSxFQUFFO2dCQUNuQixPQUFPLENBQUMsQ0FBQzthQUNWO1lBQ0QsSUFBSSxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFO2dCQUNwQyxJQUFNLEdBQUcsR0FBRyxFQUFFLENBQUM7Z0JBQ2YsSUFBTSxHQUFHLEdBQUcsRUFBRSxDQUFDO2dCQUNmLEVBQUUsR0FBRyxhQUFhLENBQUMsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQztnQkFDOUIsRUFBRSxHQUFHLGFBQWEsQ0FBQyxDQUFDLEVBQUUsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDO2dCQUM5QixJQUFNLEVBQUUsR0FBRyxVQUFVLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQztnQkFDeEMsSUFBTSxFQUFFLEdBQUcsVUFBVSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUM7Z0JBQ3hDLElBQUksRUFBRSxHQUFHLEVBQUUsRUFBRTtvQkFDWCxPQUFPLENBQUMsQ0FBQyxDQUFDO2lCQUNYO2dCQUNELElBQUksRUFBRSxHQUFHLEVBQUUsRUFBRTtvQkFDWCxPQUFPLENBQUMsQ0FBQztpQkFDVjtnQkFDRCxTQUFTO2FBQ1Y7WUFDRCxJQUFJLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRTtnQkFDbEIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRTtvQkFDbkIsT0FBTyxDQUFDLENBQUMsQ0FBQztpQkFDWDthQUNGO2lCQUFNLElBQUksT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFO2dCQUN6QixPQUFPLENBQUMsQ0FBQzthQUNWO2lCQUFNLElBQUksQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRTtnQkFDeEIsT0FBTyxDQUFDLENBQUMsQ0FBQzthQUNYO2lCQUFNLElBQUksQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRTtnQkFDeEIsT0FBTyxDQUFDLENBQUM7YUFDVjtZQUNELEVBQUUsRUFBRSxDQUFDO1lBQ0wsRUFBRSxFQUFFLENBQUM7U0FDTjtJQUNILENBQUM7SUF2Q2UsMEJBQWUsa0JBdUM5QixDQUFBO0lBRUQsdUJBQXVCLENBQVMsRUFBRSxDQUFTO1FBQ3pDLElBQUssS0FBZ0Q7UUFBckQsV0FBSyxLQUFLO1lBQUcsdUNBQU8sQ0FBQTtZQUFFLGlDQUFJLENBQUE7WUFBRSxtREFBYSxDQUFBO1lBQUUseUNBQVEsQ0FBQTtRQUFDLENBQUMsRUFBaEQsS0FBSyxLQUFMLEtBQUssUUFBMkM7UUFDckQsSUFBSSxLQUFLLEdBQUcsS0FBSyxDQUFDLE9BQU8sQ0FBQztRQUMxQixPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQ3hCLElBQUksS0FBSyxLQUFLLEtBQUssQ0FBQyxPQUFPLEVBQUU7Z0JBQzNCLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsRUFBRTtvQkFDaEIsS0FBSyxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUM7aUJBQ3BCO3FCQUFNLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxFQUFFO29CQUN2QyxLQUFLLEdBQUcsS0FBSyxDQUFDLGFBQWEsQ0FBQztpQkFDN0I7cUJBQU0sSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRTtvQkFDekIsTUFBTTtpQkFDUDthQUNGO2lCQUFNLElBQUksS0FBSyxLQUFLLEtBQUssQ0FBQyxJQUFJLEVBQUU7Z0JBQy9CLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxFQUFFO29CQUNoQyxLQUFLLEdBQUcsS0FBSyxDQUFDLGFBQWEsQ0FBQztpQkFDN0I7cUJBQU0sSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRTtvQkFDekIsTUFBTTtpQkFDUDthQUNGO2lCQUFNLElBQUksS0FBSyxLQUFLLEtBQUssQ0FBQyxhQUFhLEVBQUU7Z0JBQ3hDLElBQUksT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsRUFBRTtvQkFDakQsS0FBSyxHQUFHLEtBQUssQ0FBQyxRQUFRLENBQUM7aUJBQ3hCO3FCQUFNO29CQUNMLE1BQU07aUJBQ1A7YUFDRjtpQkFBTSxJQUFJLEtBQUssS0FBSyxLQUFLLENBQUMsUUFBUSxFQUFFO2dCQUNuQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFO29CQUNsQixNQUFNO2lCQUNQO2FBQ0Y7U0FDRjtRQUNELE9BQU8sQ0FBQyxDQUFDO0lBQ1gsQ0FBQztJQUVELGlCQUFpQixDQUFTO1FBQ3hCLE9BQU8sR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksR0FBRyxDQUFDO0lBQzlCLENBQUM7SUFFRCxpQkFBaUIsQ0FBUztRQUN4Qix5RUFBeUU7UUFDekUsT0FBTyxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQzlDLENBQUM7QUFFRCxDQUFDLEVBL0ZTLFVBQVUsS0FBVixVQUFVLFFBK0ZuQixDQUFFLHVCQUF1QiIsInNvdXJjZXNDb250ZW50IjpbIi8qIENvcHlyaWdodCAyMDE2IFRoZSBUZW5zb3JGbG93IEF1dGhvcnMuIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG5cbkxpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSBcIkxpY2Vuc2VcIik7XG55b3UgbWF5IG5vdCB1c2UgdGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlIHdpdGggdGhlIExpY2Vuc2UuXG5Zb3UgbWF5IG9idGFpbiBhIGNvcHkgb2YgdGhlIExpY2Vuc2UgYXRcblxuICAgIGh0dHA6Ly93d3cuYXBhY2hlLm9yZy9saWNlbnNlcy9MSUNFTlNFLTIuMFxuXG5Vbmxlc3MgcmVxdWlyZWQgYnkgYXBwbGljYWJsZSBsYXcgb3IgYWdyZWVkIHRvIGluIHdyaXRpbmcsIHNvZnR3YXJlXG5kaXN0cmlidXRlZCB1bmRlciB0aGUgTGljZW5zZSBpcyBkaXN0cmlidXRlZCBvbiBhbiBcIkFTIElTXCIgQkFTSVMsXG5XSVRIT1VUIFdBUlJBTlRJRVMgT1IgQ09ORElUSU9OUyBPRiBBTlkgS0lORCwgZWl0aGVyIGV4cHJlc3Mgb3IgaW1wbGllZC5cblNlZSB0aGUgTGljZW5zZSBmb3IgdGhlIHNwZWNpZmljIGxhbmd1YWdlIGdvdmVybmluZyBwZXJtaXNzaW9ucyBhbmRcbmxpbWl0YXRpb25zIHVuZGVyIHRoZSBMaWNlbnNlLlxuPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09Ki9cbm5hbWVzcGFjZSB2el9zb3J0aW5nIHtcblxuLyoqXG4gKiBDb21wYXJlcyB0YWcgbmFtZXMgYXNjaWludW1lcmljYWxseSBicm9rZW4gaW50byBjb21wb25lbnRzLlxuICpcbiAqIDxwPlRoaXMgaXMgdGhlIGNvbXBhcmlzb24gZnVuY3Rpb24gdXNlZCBmb3Igc29ydGluZyBtb3N0IHN0cmluZyB2YWx1ZXMgaW5cbiAqIFRlbnNvckJvYXJkLiBVbmxpa2UgdGhlIHN0YW5kYXJkIGFzY2lpYmV0aWNhbCBjb21wYXJhdG9yLCB0aGlzIGZ1bmN0aW9uXG4gKiBrbm93cyB0aGF0ICdhMTBiJyA+ICdhMmInLiBGaXhlZCBwb2ludCBhbmQgZW5naW5lZXJpbmcgbm90YXRpb24gYXJlXG4gKiBzdXBwb3J0ZWQuIFRoaXMgZnVuY3Rpb24gYWxzbyBzcGxpdHMgdGhlIGlucHV0IGJ5IHNsYXNoIGFuZCB1bmRlcnNjb3JlIHRvXG4gKiBwZXJmb3JtIGFycmF5IGNvbXBhcmlzb24uIFRoZXJlZm9yZSBpdCBrbm93cyB0aGF0ICdhL2EnIDwgJ2ErL2EnIGV2ZW5cbiAqIHRob3VnaCAnKycgPCAnLycgaW4gdGhlIEFTQ0lJIHRhYmxlLlxuICovXG5leHBvcnQgZnVuY3Rpb24gY29tcGFyZVRhZ05hbWVzKGEsIGI6IHN0cmluZyk6IG51bWJlciB7XG4gIGxldCBhaSA9IDA7XG4gIGxldCBiaSA9IDA7XG4gIHdoaWxlICh0cnVlKSB7XG4gICAgaWYgKGFpID09PSBhLmxlbmd0aCkge1xuICAgICAgcmV0dXJuIGJpID09PSBiLmxlbmd0aCA/IDAgOiAtMTtcbiAgICB9XG4gICAgaWYgKGJpID09PSBiLmxlbmd0aCkge1xuICAgICAgcmV0dXJuIDE7XG4gICAgfVxuICAgIGlmIChpc0RpZ2l0KGFbYWldKSAmJiBpc0RpZ2l0KGJbYmldKSkge1xuICAgICAgY29uc3QgYWlzID0gYWk7XG4gICAgICBjb25zdCBiaXMgPSBiaTtcbiAgICAgIGFpID0gY29uc3VtZU51bWJlcihhLCBhaSArIDEpO1xuICAgICAgYmkgPSBjb25zdW1lTnVtYmVyKGIsIGJpICsgMSk7XG4gICAgICBjb25zdCBhbiA9IHBhcnNlRmxvYXQoYS5zbGljZShhaXMsIGFpKSk7XG4gICAgICBjb25zdCBibiA9IHBhcnNlRmxvYXQoYi5zbGljZShiaXMsIGJpKSk7XG4gICAgICBpZiAoYW4gPCBibikge1xuICAgICAgICByZXR1cm4gLTE7XG4gICAgICB9XG4gICAgICBpZiAoYW4gPiBibikge1xuICAgICAgICByZXR1cm4gMTtcbiAgICAgIH1cbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBpZiAoaXNCcmVhayhhW2FpXSkpIHtcbiAgICAgIGlmICghaXNCcmVhayhiW2JpXSkpIHtcbiAgICAgICAgcmV0dXJuIC0xO1xuICAgICAgfVxuICAgIH0gZWxzZSBpZiAoaXNCcmVhayhiW2JpXSkpIHtcbiAgICAgIHJldHVybiAxO1xuICAgIH0gZWxzZSBpZiAoYVthaV0gPCBiW2JpXSkge1xuICAgICAgcmV0dXJuIC0xO1xuICAgIH0gZWxzZSBpZiAoYVthaV0gPiBiW2JpXSkge1xuICAgICAgcmV0dXJuIDE7XG4gICAgfVxuICAgIGFpKys7XG4gICAgYmkrKztcbiAgfVxufVxuXG5mdW5jdGlvbiBjb25zdW1lTnVtYmVyKHM6IHN0cmluZywgaTogbnVtYmVyKTogbnVtYmVyIHtcbiAgZW51bSBTdGF0ZSB7IE5BVFVSQUwsIFJFQUwsIEVYUE9ORU5UX1NJR04sIEVYUE9ORU5UIH1cbiAgbGV0IHN0YXRlID0gU3RhdGUuTkFUVVJBTDtcbiAgZm9yICg7IGkgPCBzLmxlbmd0aDsgaSsrKSB7XG4gICAgaWYgKHN0YXRlID09PSBTdGF0ZS5OQVRVUkFMKSB7XG4gICAgICBpZiAoc1tpXSA9PT0gJy4nKSB7XG4gICAgICAgIHN0YXRlID0gU3RhdGUuUkVBTDtcbiAgICAgIH0gZWxzZSBpZiAoc1tpXSA9PT0gJ2UnIHx8IHNbaV0gPT09ICdFJykge1xuICAgICAgICBzdGF0ZSA9IFN0YXRlLkVYUE9ORU5UX1NJR047XG4gICAgICB9IGVsc2UgaWYgKCFpc0RpZ2l0KHNbaV0pKSB7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgIH0gZWxzZSBpZiAoc3RhdGUgPT09IFN0YXRlLlJFQUwpIHtcbiAgICAgIGlmIChzW2ldID09PSAnZScgfHwgc1tpXSA9PT0gJ0UnKSB7XG4gICAgICAgIHN0YXRlID0gU3RhdGUuRVhQT05FTlRfU0lHTjtcbiAgICAgIH0gZWxzZSBpZiAoIWlzRGlnaXQoc1tpXSkpIHtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgfSBlbHNlIGlmIChzdGF0ZSA9PT0gU3RhdGUuRVhQT05FTlRfU0lHTikge1xuICAgICAgaWYgKGlzRGlnaXQoc1tpXSkgfHwgc1tpXSA9PT0gJysnIHx8IHNbaV0gPT09ICctJykge1xuICAgICAgICBzdGF0ZSA9IFN0YXRlLkVYUE9ORU5UO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgfSBlbHNlIGlmIChzdGF0ZSA9PT0gU3RhdGUuRVhQT05FTlQpIHtcbiAgICAgIGlmICghaXNEaWdpdChzW2ldKSkge1xuICAgICAgICBicmVhaztcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgcmV0dXJuIGk7XG59XG5cbmZ1bmN0aW9uIGlzRGlnaXQoYzogc3RyaW5nKTogYm9vbGVhbiB7XG4gIHJldHVybiAnMCcgPD0gYyAmJiBjIDw9ICc5Jztcbn1cblxuZnVuY3Rpb24gaXNCcmVhayhjOiBzdHJpbmcpOiBib29sZWFuIHtcbiAgLy8gVE9ETyhAamFydCk6IFJlbW92ZSB1bmRlcnNjb3JlIHdoZW4gcGVvcGxlIHN0b3AgdXNpbmcgaXQgbGlrZSBhIHNsYXNoLlxuICByZXR1cm4gYyA9PT0gJy8nIHx8IGMgPT09ICdfJyB8fCBpc0RpZ2l0KGMpO1xufVxuXG59ICAvLyBuYW1lc3BhY2Ugdnpfc29ydGluZ1xuIl19