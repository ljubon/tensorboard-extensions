declare namespace tf_dashboard_common {
    /**
     * @polymerBehavior
     */
    const ArrayUpdateHelper: {
        updateArrayProp(prop: string, value: any[], getKey: (item: any, ind: number) => string): void;
    };
}
