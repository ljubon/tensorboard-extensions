/* Copyright 2016 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
var tf_globals;
(function (tf_globals) {
    // If true, TensorBoard stores its hash in the URI state.
    // If false, tab switching in TensorBoard will not update location hash,
    // because hash updates interfere with wct_tests.
    var _useHash = false;
    function setUseHash(shouldUseHash) {
        _useHash = shouldUseHash;
    }
    tf_globals.setUseHash = setUseHash;
    function useHash() {
        return _useHash;
    }
    tf_globals.useHash = useHash;
    var _fakeHash = '';
    function setFakeHash(h) {
        _fakeHash = h;
    }
    tf_globals.setFakeHash = setFakeHash;
    function getFakeHash() {
        return _fakeHash;
    }
    tf_globals.getFakeHash = getFakeHash;
    function getEnableDataSelector() {
        return new URLSearchParams(window.location.search).has('EnableDataSelector');
    }
    tf_globals.getEnableDataSelector = getEnableDataSelector;
})(tf_globals || (tf_globals = {})); // namespace tf_globals
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ2xvYmFscy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImdsb2JhbHMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7Ozs7Ozs7Z0ZBYWdGO0FBQ2hGLElBQVUsVUFBVSxDQTZCbkI7QUE3QkQsV0FBVSxVQUFVO0lBRXBCLHlEQUF5RDtJQUN6RCx3RUFBd0U7SUFDeEUsaURBQWlEO0lBQ2pELElBQUksUUFBUSxHQUFHLEtBQUssQ0FBQztJQUVyQixvQkFBMkIsYUFBc0I7UUFDL0MsUUFBUSxHQUFHLGFBQWEsQ0FBQztJQUMzQixDQUFDO0lBRmUscUJBQVUsYUFFekIsQ0FBQTtJQUVEO1FBQ0UsT0FBTyxRQUFRLENBQUM7SUFDbEIsQ0FBQztJQUZlLGtCQUFPLFVBRXRCLENBQUE7SUFFRCxJQUFJLFNBQVMsR0FBRyxFQUFFLENBQUM7SUFFbkIscUJBQTRCLENBQVM7UUFDbkMsU0FBUyxHQUFHLENBQUMsQ0FBQztJQUNoQixDQUFDO0lBRmUsc0JBQVcsY0FFMUIsQ0FBQTtJQUVEO1FBQ0UsT0FBTyxTQUFTLENBQUM7SUFDbkIsQ0FBQztJQUZlLHNCQUFXLGNBRTFCLENBQUE7SUFFRDtRQUNFLE9BQU8sSUFBSSxlQUFlLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMsb0JBQW9CLENBQUMsQ0FBQztJQUMvRSxDQUFDO0lBRmUsZ0NBQXFCLHdCQUVwQyxDQUFBO0FBRUQsQ0FBQyxFQTdCUyxVQUFVLEtBQVYsVUFBVSxRQTZCbkIsQ0FBRSx1QkFBdUIiLCJzb3VyY2VzQ29udGVudCI6WyIvKiBDb3B5cmlnaHQgMjAxNiBUaGUgVGVuc29yRmxvdyBBdXRob3JzLiBBbGwgUmlnaHRzIFJlc2VydmVkLlxuXG5MaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UsIFZlcnNpb24gMi4wICh0aGUgXCJMaWNlbnNlXCIpO1xueW91IG1heSBub3QgdXNlIHRoaXMgZmlsZSBleGNlcHQgaW4gY29tcGxpYW5jZSB3aXRoIHRoZSBMaWNlbnNlLlxuWW91IG1heSBvYnRhaW4gYSBjb3B5IG9mIHRoZSBMaWNlbnNlIGF0XG5cbiAgICBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcblxuVW5sZXNzIHJlcXVpcmVkIGJ5IGFwcGxpY2FibGUgbGF3IG9yIGFncmVlZCB0byBpbiB3cml0aW5nLCBzb2Z0d2FyZVxuZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIExpY2Vuc2UgaXMgZGlzdHJpYnV0ZWQgb24gYW4gXCJBUyBJU1wiIEJBU0lTLFxuV0lUSE9VVCBXQVJSQU5USUVTIE9SIENPTkRJVElPTlMgT0YgQU5ZIEtJTkQsIGVpdGhlciBleHByZXNzIG9yIGltcGxpZWQuXG5TZWUgdGhlIExpY2Vuc2UgZm9yIHRoZSBzcGVjaWZpYyBsYW5ndWFnZSBnb3Zlcm5pbmcgcGVybWlzc2lvbnMgYW5kXG5saW1pdGF0aW9ucyB1bmRlciB0aGUgTGljZW5zZS5cbj09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSovXG5uYW1lc3BhY2UgdGZfZ2xvYmFscyB7XG5cbi8vIElmIHRydWUsIFRlbnNvckJvYXJkIHN0b3JlcyBpdHMgaGFzaCBpbiB0aGUgVVJJIHN0YXRlLlxuLy8gSWYgZmFsc2UsIHRhYiBzd2l0Y2hpbmcgaW4gVGVuc29yQm9hcmQgd2lsbCBub3QgdXBkYXRlIGxvY2F0aW9uIGhhc2gsXG4vLyBiZWNhdXNlIGhhc2ggdXBkYXRlcyBpbnRlcmZlcmUgd2l0aCB3Y3RfdGVzdHMuXG5sZXQgX3VzZUhhc2ggPSBmYWxzZTtcblxuZXhwb3J0IGZ1bmN0aW9uIHNldFVzZUhhc2goc2hvdWxkVXNlSGFzaDogYm9vbGVhbik6IHZvaWQge1xuICBfdXNlSGFzaCA9IHNob3VsZFVzZUhhc2g7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiB1c2VIYXNoKCk6IGJvb2xlYW4ge1xuICByZXR1cm4gX3VzZUhhc2g7XG59XG5cbmxldCBfZmFrZUhhc2ggPSAnJztcblxuZXhwb3J0IGZ1bmN0aW9uIHNldEZha2VIYXNoKGg6IHN0cmluZykge1xuICBfZmFrZUhhc2ggPSBoO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gZ2V0RmFrZUhhc2goKSB7XG4gIHJldHVybiBfZmFrZUhhc2g7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBnZXRFbmFibGVEYXRhU2VsZWN0b3IoKTogYm9vbGVhbiB7XG4gIHJldHVybiBuZXcgVVJMU2VhcmNoUGFyYW1zKHdpbmRvdy5sb2NhdGlvbi5zZWFyY2gpLmhhcygnRW5hYmxlRGF0YVNlbGVjdG9yJyk7XG59XG5cbn0gIC8vIG5hbWVzcGFjZSB0Zl9nbG9iYWxzXG4iXX0=