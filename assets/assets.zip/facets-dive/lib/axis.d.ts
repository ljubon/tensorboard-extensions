/**
 * @license
 * Copyright 2017 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @fileoverview Axis class for rendering an axis on the side of a cell.
 */
import { BoundedObject, Side } from './bounded-object';
import { Cell } from './grid';
/**
 * Thickness in pixels of the stroke used in drawing axes.
 */
export declare const AXIS_STROKE_PX = 1.2;
/**
 * Length in pixels of the axis's wing nubs.
 */
export declare const AXIS_WING_LENGTH_PX = 6;
/**
 * Amount of space in pixels to leave between the cell's content and the axis.
 */
export declare const AXIS_OFFSET_PX = 4;
/**
 * Amount of space in pixels to leave between an axis and the next cell.
 */
export declare const AXIS_MARGIN_PX = 14;
/**
 * Axis objects are bound to create axis lines (paths).
 */
export declare class Axis extends BoundedObject {
    /**
     * Whether this axis is on the left or bottom side of the cell.
     */
    side: Side;
    /**
     * The grid cell to which this axis is attached.
     */
    cell: Cell;
    /**
     * Create the Axis object by capturing the selected Side and Cell, then pre-
     * compute the minimum scale at which this axis should be visible based on
     * the presence of nearby neighboring cells.
     */
    constructor(side: Side, cell: Cell);
    /**
     * Return the scaled stroke width for this axis.
     */
    strokeWidth(scale: number): number;
    /**
     * Return the SVG path string (d attribute) it should follow in world
     * coordinates at the specified scale.
     */
    path(scale: number): string;
    /**
     * Return a uniquely identifiable string for this axis based on its side and
     * the cell to which it's attached.
     */
    key(): string;
}
