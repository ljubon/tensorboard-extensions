/* Copyright 2015 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
var tf_color_scale;
(function (tf_color_scale) {
    // Example usage:
    // runs = ["train", "test", "test1", "test2"]
    // ccs = new ColorScale();
    // ccs.domain(runs);
    // ccs.getColor("train");
    // ccs.getColor("test1");
    var ColorScale = /** @class */ (function () {
        /**
         * Creates a color scale with optional custom palette.
         * @param {Array<string>} palette The color palette to use, as an
         *   Array of hex strings. Defaults to the standard palette.
         */
        function ColorScale(palette) {
            if (palette === void 0) { palette = tf_color_scale.standard; }
            this.palette = palette;
            this.identifiers = d3.map();
        }
        /**
         * Set the domain of strings.
         * @param {Array<string>} strings - An array of possible strings to use as the
         *     domain for your scale.
         */
        ColorScale.prototype.setDomain = function (strings) {
            var _this = this;
            this.identifiers = d3.map();
            strings.forEach(function (s, i) {
                _this.identifiers.set(s, _this.palette[i % _this.palette.length]);
            });
            return this;
        };
        /**
         * Use the color scale to transform an element in the domain into a color.
         * @param {string} The input string to map to a color.
         * @return {string} The color corresponding to that input string.
         * @throws Will error if input string is not in the scale's domain.
         */
        ColorScale.prototype.getColor = function (s) {
            if (!this.identifiers.has(s)) {
                throw new Error("String " + s + " was not in the domain.");
            }
            return this.identifiers.get(s);
        };
        return ColorScale;
    }());
    tf_color_scale.ColorScale = ColorScale;
    /**
     * A color scale of a domain from a store.  Automatically updated when the store
     * emits a change.
     */
    function createAutoUpdateColorScale(store, getDomain) {
        var colorScale = new ColorScale();
        function updateRunsColorScale() {
            colorScale.setDomain(getDomain());
        }
        store.addListener(updateRunsColorScale);
        updateRunsColorScale();
        return function (domain) { return colorScale.getColor(domain); };
    }
    tf_color_scale.runsColorScale = createAutoUpdateColorScale(tf_backend.runsStore, function () { return tf_backend.runsStore.getRuns(); });
    tf_color_scale.experimentsColorScale = createAutoUpdateColorScale(tf_backend.experimentsStore, function () {
        return tf_backend.experimentsStore.getExperiments().map(function (_a) {
            var name = _a.name;
            return name;
        });
    });
})(tf_color_scale || (tf_color_scale = {})); // tf_color_scale
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29sb3JTY2FsZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImNvbG9yU2NhbGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7Ozs7Ozs7Z0ZBYWdGO0FBQ2hGLElBQVUsY0FBYyxDQXVFdkI7QUF2RUQsV0FBVSxjQUFjO0lBRXhCLGlCQUFpQjtJQUNqQiw2Q0FBNkM7SUFDN0MsMEJBQTBCO0lBQzFCLG9CQUFvQjtJQUNwQix5QkFBeUI7SUFDekIseUJBQXlCO0lBRXpCO1FBR0U7Ozs7V0FJRztRQUNILG9CQUNxQixPQUE0QjtZQUE1Qix3QkFBQSxFQUFBLFVBQW9CLHVCQUFRO1lBQTVCLFlBQU8sR0FBUCxPQUFPLENBQXFCO1lBUnpDLGdCQUFXLEdBQUcsRUFBRSxDQUFDLEdBQUcsRUFBRSxDQUFDO1FBUXFCLENBQUM7UUFFckQ7Ozs7V0FJRztRQUNJLDhCQUFTLEdBQWhCLFVBQWlCLE9BQWlCO1lBQWxDLGlCQU1DO1lBTEMsSUFBSSxDQUFDLFdBQVcsR0FBRyxFQUFFLENBQUMsR0FBRyxFQUFFLENBQUM7WUFDNUIsT0FBTyxDQUFDLE9BQU8sQ0FBQyxVQUFDLENBQUMsRUFBRSxDQUFDO2dCQUNuQixLQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsS0FBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLEdBQUcsS0FBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO1lBQ2pFLENBQUMsQ0FBQyxDQUFDO1lBQ0gsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO1FBRUQ7Ozs7O1dBS0c7UUFDSSw2QkFBUSxHQUFmLFVBQWdCLENBQVM7WUFDdkIsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFO2dCQUM1QixNQUFNLElBQUksS0FBSyxDQUFDLFlBQVUsQ0FBQyw0QkFBeUIsQ0FBQyxDQUFDO2FBQ3ZEO1lBQ0QsT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQVcsQ0FBQztRQUMzQyxDQUFDO1FBQ0gsaUJBQUM7SUFBRCxDQUFDLEFBcENELElBb0NDO0lBcENZLHlCQUFVLGFBb0N0QixDQUFBO0lBRUQ7OztPQUdHO0lBQ0gsb0NBQ0ksS0FBMkIsRUFDM0IsU0FBeUI7UUFDM0IsSUFBTSxVQUFVLEdBQUcsSUFBSSxVQUFVLEVBQUUsQ0FBQztRQUNwQztZQUNFLFVBQVUsQ0FBQyxTQUFTLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQztRQUNwQyxDQUFDO1FBQ0QsS0FBSyxDQUFDLFdBQVcsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO1FBQ3hDLG9CQUFvQixFQUFFLENBQUM7UUFDdkIsT0FBTyxVQUFDLE1BQU0sSUFBSyxPQUFBLFVBQVUsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLEVBQTNCLENBQTJCLENBQUM7SUFDakQsQ0FBQztJQUVZLDZCQUFjLEdBQUcsMEJBQTBCLENBQ3BELFVBQVUsQ0FBQyxTQUFTLEVBQUUsY0FBTSxPQUFBLFVBQVUsQ0FBQyxTQUFTLENBQUMsT0FBTyxFQUFFLEVBQTlCLENBQThCLENBQUMsQ0FBQztJQUVuRCxvQ0FBcUIsR0FBRywwQkFBMEIsQ0FDM0QsVUFBVSxDQUFDLGdCQUFnQixFQUFFO1FBQzNCLE9BQU8sVUFBVSxDQUFDLGdCQUFnQixDQUFDLGNBQWMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxVQUFDLEVBQU07Z0JBQUwsY0FBSTtZQUFNLE9BQUEsSUFBSTtRQUFKLENBQUksQ0FBQyxDQUFDO0lBQzVFLENBQUMsQ0FBQyxDQUFDO0FBRVAsQ0FBQyxFQXZFUyxjQUFjLEtBQWQsY0FBYyxRQXVFdkIsQ0FBRSxpQkFBaUIiLCJzb3VyY2VzQ29udGVudCI6WyIvKiBDb3B5cmlnaHQgMjAxNSBUaGUgVGVuc29yRmxvdyBBdXRob3JzLiBBbGwgUmlnaHRzIFJlc2VydmVkLlxuXG5MaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UsIFZlcnNpb24gMi4wICh0aGUgXCJMaWNlbnNlXCIpO1xueW91IG1heSBub3QgdXNlIHRoaXMgZmlsZSBleGNlcHQgaW4gY29tcGxpYW5jZSB3aXRoIHRoZSBMaWNlbnNlLlxuWW91IG1heSBvYnRhaW4gYSBjb3B5IG9mIHRoZSBMaWNlbnNlIGF0XG5cbiAgICBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcblxuVW5sZXNzIHJlcXVpcmVkIGJ5IGFwcGxpY2FibGUgbGF3IG9yIGFncmVlZCB0byBpbiB3cml0aW5nLCBzb2Z0d2FyZVxuZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIExpY2Vuc2UgaXMgZGlzdHJpYnV0ZWQgb24gYW4gXCJBUyBJU1wiIEJBU0lTLFxuV0lUSE9VVCBXQVJSQU5USUVTIE9SIENPTkRJVElPTlMgT0YgQU5ZIEtJTkQsIGVpdGhlciBleHByZXNzIG9yIGltcGxpZWQuXG5TZWUgdGhlIExpY2Vuc2UgZm9yIHRoZSBzcGVjaWZpYyBsYW5ndWFnZSBnb3Zlcm5pbmcgcGVybWlzc2lvbnMgYW5kXG5saW1pdGF0aW9ucyB1bmRlciB0aGUgTGljZW5zZS5cbj09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSovXG5uYW1lc3BhY2UgdGZfY29sb3Jfc2NhbGUge1xuXG4vLyBFeGFtcGxlIHVzYWdlOlxuLy8gcnVucyA9IFtcInRyYWluXCIsIFwidGVzdFwiLCBcInRlc3QxXCIsIFwidGVzdDJcIl1cbi8vIGNjcyA9IG5ldyBDb2xvclNjYWxlKCk7XG4vLyBjY3MuZG9tYWluKHJ1bnMpO1xuLy8gY2NzLmdldENvbG9yKFwidHJhaW5cIik7XG4vLyBjY3MuZ2V0Q29sb3IoXCJ0ZXN0MVwiKTtcblxuZXhwb3J0IGNsYXNzIENvbG9yU2NhbGUge1xuICBwcml2YXRlIGlkZW50aWZpZXJzID0gZDMubWFwKCk7XG5cbiAgLyoqXG4gICAqIENyZWF0ZXMgYSBjb2xvciBzY2FsZSB3aXRoIG9wdGlvbmFsIGN1c3RvbSBwYWxldHRlLlxuICAgKiBAcGFyYW0ge0FycmF5PHN0cmluZz59IHBhbGV0dGUgVGhlIGNvbG9yIHBhbGV0dGUgdG8gdXNlLCBhcyBhblxuICAgKiAgIEFycmF5IG9mIGhleCBzdHJpbmdzLiBEZWZhdWx0cyB0byB0aGUgc3RhbmRhcmQgcGFsZXR0ZS5cbiAgICovXG4gIGNvbnN0cnVjdG9yKFxuICAgICAgcHJpdmF0ZSByZWFkb25seSBwYWxldHRlOiBzdHJpbmdbXSA9IHN0YW5kYXJkKSB7fVxuXG4gIC8qKlxuICAgKiBTZXQgdGhlIGRvbWFpbiBvZiBzdHJpbmdzLlxuICAgKiBAcGFyYW0ge0FycmF5PHN0cmluZz59IHN0cmluZ3MgLSBBbiBhcnJheSBvZiBwb3NzaWJsZSBzdHJpbmdzIHRvIHVzZSBhcyB0aGVcbiAgICogICAgIGRvbWFpbiBmb3IgeW91ciBzY2FsZS5cbiAgICovXG4gIHB1YmxpYyBzZXREb21haW4oc3RyaW5nczogc3RyaW5nW10pOiB0aGlzIHtcbiAgICB0aGlzLmlkZW50aWZpZXJzID0gZDMubWFwKCk7XG4gICAgc3RyaW5ncy5mb3JFYWNoKChzLCBpKSA9PiB7XG4gICAgICB0aGlzLmlkZW50aWZpZXJzLnNldChzLCB0aGlzLnBhbGV0dGVbaSAlIHRoaXMucGFsZXR0ZS5sZW5ndGhdKTtcbiAgICB9KTtcbiAgICByZXR1cm4gdGhpcztcbiAgfVxuXG4gIC8qKlxuICAgKiBVc2UgdGhlIGNvbG9yIHNjYWxlIHRvIHRyYW5zZm9ybSBhbiBlbGVtZW50IGluIHRoZSBkb21haW4gaW50byBhIGNvbG9yLlxuICAgKiBAcGFyYW0ge3N0cmluZ30gVGhlIGlucHV0IHN0cmluZyB0byBtYXAgdG8gYSBjb2xvci5cbiAgICogQHJldHVybiB7c3RyaW5nfSBUaGUgY29sb3IgY29ycmVzcG9uZGluZyB0byB0aGF0IGlucHV0IHN0cmluZy5cbiAgICogQHRocm93cyBXaWxsIGVycm9yIGlmIGlucHV0IHN0cmluZyBpcyBub3QgaW4gdGhlIHNjYWxlJ3MgZG9tYWluLlxuICAgKi9cbiAgcHVibGljIGdldENvbG9yKHM6IHN0cmluZyk6IHN0cmluZyB7XG4gICAgaWYgKCF0aGlzLmlkZW50aWZpZXJzLmhhcyhzKSkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKGBTdHJpbmcgJHtzfSB3YXMgbm90IGluIHRoZSBkb21haW4uYCk7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLmlkZW50aWZpZXJzLmdldChzKSBhcyBzdHJpbmc7XG4gIH1cbn1cblxuLyoqXG4gKiBBIGNvbG9yIHNjYWxlIG9mIGEgZG9tYWluIGZyb20gYSBzdG9yZS4gIEF1dG9tYXRpY2FsbHkgdXBkYXRlZCB3aGVuIHRoZSBzdG9yZVxuICogZW1pdHMgYSBjaGFuZ2UuXG4gKi9cbmZ1bmN0aW9uIGNyZWF0ZUF1dG9VcGRhdGVDb2xvclNjYWxlKFxuICAgIHN0b3JlOiB0Zl9iYWNrZW5kLkJhc2VTdG9yZSxcbiAgICBnZXREb21haW46ICgpID0+IHN0cmluZ1tdKTogKHJ1bk5hbWU6IHN0cmluZykgPT4gc3RyaW5nIHtcbiAgY29uc3QgY29sb3JTY2FsZSA9IG5ldyBDb2xvclNjYWxlKCk7XG4gIGZ1bmN0aW9uIHVwZGF0ZVJ1bnNDb2xvclNjYWxlKCk6IHZvaWQge1xuICAgIGNvbG9yU2NhbGUuc2V0RG9tYWluKGdldERvbWFpbigpKTtcbiAgfVxuICBzdG9yZS5hZGRMaXN0ZW5lcih1cGRhdGVSdW5zQ29sb3JTY2FsZSk7XG4gIHVwZGF0ZVJ1bnNDb2xvclNjYWxlKCk7XG4gIHJldHVybiAoZG9tYWluKSA9PiBjb2xvclNjYWxlLmdldENvbG9yKGRvbWFpbik7XG59XG5cbmV4cG9ydCBjb25zdCBydW5zQ29sb3JTY2FsZSA9IGNyZWF0ZUF1dG9VcGRhdGVDb2xvclNjYWxlKFxuICAgIHRmX2JhY2tlbmQucnVuc1N0b3JlLCAoKSA9PiB0Zl9iYWNrZW5kLnJ1bnNTdG9yZS5nZXRSdW5zKCkpO1xuXG5leHBvcnQgY29uc3QgZXhwZXJpbWVudHNDb2xvclNjYWxlID0gY3JlYXRlQXV0b1VwZGF0ZUNvbG9yU2NhbGUoXG4gICAgdGZfYmFja2VuZC5leHBlcmltZW50c1N0b3JlLCAoKSA9PiB7XG4gICAgICByZXR1cm4gdGZfYmFja2VuZC5leHBlcmltZW50c1N0b3JlLmdldEV4cGVyaW1lbnRzKCkubWFwKCh7bmFtZX0pID0+IG5hbWUpO1xuICAgIH0pO1xuXG59ICAvLyB0Zl9jb2xvcl9zY2FsZVxuIl19