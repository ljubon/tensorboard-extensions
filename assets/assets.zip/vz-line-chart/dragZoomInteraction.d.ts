declare namespace vz_line_chart {
    class DragZoomLayer extends Plottable.Components.SelectionBoxLayer {
        private _dragInteraction;
        private _doubleClickInteraction;
        private easeFn;
        private _animationTime;
        private onStart;
        private onEnd;
        private unzoomMethod;
        /**
         * Constructs a SelectionBoxLayer with an attached DragInteraction and
         * ClickInteraction. On drag, it triggers an animated zoom into the box
         * that was dragged. On double click, it zooms back out to the original
         * view, before any zooming.
         * The zoom animation uses an easing function (default
         * d3.ease('cubic-in-out')) and is customizable.
         * Usage: Construct the selection box layer and attach x and y scales,
         * and then add the layer over the plot you are zooming on using a
         * Component Group.
         * TODO(@dandelionmane) - merge this into Plottable
         */
        constructor(xScale: Plottable.QuantitativeScale<number | {
            valueOf(): number;
        }>, yScale: Plottable.QuantitativeScale<number | {
            valueOf(): number;
        }>, unzoomMethod: Function);
        /**
         * Register a method that calls when the DragZoom interaction starts.
         */
        interactionStart(cb: Function): void;
        /**
         * Register a method that calls when the DragZoom interaction ends.
         */
        interactionEnd(cb: Function): void;
        /**
         * Returns backing drag interaction. Useful for customization to the
         * interaction.
         */
        dragInteraction(): Plottable.Interactions.Drag;
        private setupCallbacks;
        animationTime(): number;
        animationTime(animationTime: number): DragZoomLayer;
        /**
         * Set the easing function, which determines how the zoom interpolates
         * over time.
         */
        ease(fn: (t: number) => number): DragZoomLayer;
        private zoom;
        private unzoom;
        private isZooming;
        private interpolateZoom;
    }
}
