/* Copyright 2018 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the 'License');
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an 'AS IS' BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
import BytesList from 'goog:proto.tensorflow.BytesList';
import Example from 'goog:proto.tensorflow.Example';
import Feature from 'goog:proto.tensorflow.Feature';
import FeatureList from 'goog:proto.tensorflow.FeatureList';
import FeatureLists from 'goog:proto.tensorflow.FeatureLists';
import Features from 'goog:proto.tensorflow.Features';
import FloatList from 'goog:proto.tensorflow.FloatList';
import Int64List from 'goog:proto.tensorflow.Int64List';
import SequenceExample from 'goog:proto.tensorflow.SequenceExample';
var vz_example_viewer;
(function (vz_example_viewer) {
    var INT_FEATURE_NAME = 'int';
    var FLOAT_FEATURE_NAME = 'float';
    var BASE_64_IMAGE_ENCODING_PREFIX = 'base64,';
    var LEGEND_WIDTH_PX = 260;
    var LEGEND_HEIGHT_PX = 20;
    var CHANGE_CALLBACK_TIMER_DELAY_MS = 1000;
    var clipSaliencyRatio = .95;
    // Colors for the saliency color scale.
    var posSaliencyColor = '#0f0';
    var negSaliencyColor = '#f00';
    var neutralSaliencyColor = '#e8eaed';
    var COLOR_INTERPOLATOR = d3.interpolateRgb;
    // Regex to find bytes features that are encoded images. Follows the guide at
    // go/tf-example.
    var IMG_FEATURE_REGEX = /^image\/([^\/]+\/)*encoded$/;
    // Corresponds to a length of a Uint8Array of size 250MB. Above this size we
    // will not decode a bytes list into a string.
    var MAX_BYTES_LIST_LENGTH = 1024 * 1024 * 250 / 8;
    // The max ratio to blend saliency map colors with a grayscaled version of an
    // image feature, to create a visually-useful saliency mask on an image.
    var IMG_SALIENCY_MAX_COLOR_RATIO = 0.5;
    // String returned when a decoded string feature is too large to display.
    var MAX_STRING_INDICATION = 'String too large to display';
    // D3 zoom extent range for image zooming.
    var ZOOM_EXTENT = [1, 20];
    var DEFAULT_WINDOW_WIDTH = 256;
    var DEFAULT_WINDOW_CENTER = 128;
    Polymer({
        is: 'vz-example-viewer',
        properties: {
            example: { type: Object },
            serializedExample: { type: String, observer: 'updateExample' },
            serializedSeqExample: { type: String, observer: 'updateSeqExample' },
            json: { type: Object, observer: 'createExamplesFromJson' },
            saliency: { type: Object, value: {} },
            saliencyJsonString: { type: String, observer: 'haveSaliencyJson' },
            readonly: { type: Boolean, value: false },
            seqNumber: { type: Number, value: 0, observer: 'newSeqNum' },
            isSequence: Boolean,
            changeCallbackTimer: Number,
            ignoreChange: Boolean,
            minSal: { type: Number, value: 0 },
            maxSal: { type: Number, value: 0 },
            showSaliency: { type: Boolean, value: true },
            imageInfo: { type: Object, value: {} },
            windowWidth: { type: Number, value: DEFAULT_WINDOW_WIDTH },
            windowCenter: { type: Number, value: DEFAULT_WINDOW_CENTER },
            saliencyCutoff: { type: Number, value: 0 },
            hasImage: { type: Boolean, value: true },
            allowImageControls: { type: Boolean, value: false },
            imageScalePercentage: { type: Number, value: 100 },
            features: { type: Object, computed: 'getFeatures(example)' },
            featuresList: { type: Object, computed: 'getFeaturesList(features, compareFeatures)' },
            seqFeatures: { type: Object, computed: 'getSeqFeatures(example)' },
            seqFeaturesList: { type: Object, computed: 'getFeaturesList(seqFeatures, compareSeqFeatures)' },
            maxSeqNumber: { type: Number, computed: 'getMaxSeqNumber(seqFeaturesList)' },
            colors: { type: Object, computed: 'getColors(saliency)', observer: 'createLegend' },
            displayMode: { type: String, value: 'grid' },
            featureSearchValue: { type: String, value: '', notify: true },
            filteredFeaturesList: { type: Object, computed: 'getFilteredFeaturesList(featuresList, featureSearchValue, saliency)' },
            filteredSeqFeaturesList: { type: Object, computed: 'getFilteredFeaturesList(seqFeaturesList, featureSearchValue, saliency)' },
            focusedFeatureName: String,
            focusedFeatureValueIndex: Number,
            focusedSeqNumber: Number,
            showDeleteValueButton: { type: Boolean, value: false },
            expandedFeatures: { type: Object, value: {} },
            expandAllFeatures: { type: Boolean, value: false },
            zeroIndex: { type: Number, value: 0 },
            compareJson: { type: Object, observer: 'createCompareExamplesFromJson' },
            compareExample: { type: Object },
            compareFeatures: {
                type: Object,
                computed: 'getFeatures(compareExample)',
                observer: 'updateCompareMode'
            },
            compareSeqFeatures: {
                type: Object,
                computed: 'getSeqFeatures(compareExample)',
                observer: 'updateCompareMode'
            },
            compareMode: Boolean,
            compareImageInfo: { type: Object, value: {} },
            compareTitle: String,
        },
        observers: [
            'haveSaliency(filteredFeaturesList, saliency, colors, showSaliency, saliencyCutoff)',
            'seqSaliency(seqNumber, seqFeaturesList, saliency, colors, showSaliency, saliencyCutoff)',
        ],
        isExpanded: function (featName, expandAllFeatures) {
            return this.expandAllFeatures ||
                this.sanitizeFeature(featName) in this.expandedFeatures;
        },
        updateExample: function () {
            this.deserializeExample(this.serializedExample, Example.deserializeBinary);
        },
        // tslint:disable-next-line:no-unused-variable called as observer
        updateSeqExample: function () {
            this.deserializeExample(this.serializedSeqExample, SequenceExample.deserializeBinary);
        },
        /* Helper method to encode a string into a typed array. */
        stringToUint8Array: function (str) {
            return new window.TextEncoder().encode(str);
        },
        deserializeExample: function (serializedProto, deserializer) {
            // If ignoreChange is set then do not deserialized a newly set serialized
            // example, which would cause the entire visualization to re-render.
            if (this.ignoreChange) {
                return;
            }
            var bytes = this.decodedStringToCharCodes(atob(serializedProto));
            this.example = deserializer(bytes);
        },
        /** A computed map of all standard features in an example. */
        getFeatures: function (example) {
            // Reset our maps of image information when a new example is supplied.
            this.imageInfo = {};
            this.hasImage = false;
            if (example == null) {
                return new Map([]);
            }
            if (example instanceof Example) {
                this.isSequence = false;
                if (!example.hasFeatures()) {
                    example.setFeatures(new Features());
                }
                return example.getFeatures().getFeatureMap();
            }
            else {
                this.isSequence = true;
                if (!example.hasContext()) {
                    example.setContext(new Features());
                }
                return example.getContext().getFeatureMap();
            }
        },
        /**
         * A computed list of all standard features in an example, for driving the
         * display.
         */
        getFeaturesList: function (features, compareFeatures) {
            var featuresList = [];
            var featureSet = {};
            var it = features.keys();
            if (it) {
                var next = it.next();
                while (!next.done) {
                    featuresList.push({ name: next.value, feature: features.get(next.value) });
                    featureSet[next.value] = true;
                    next = it.next();
                }
            }
            it = compareFeatures.keys();
            if (it) {
                var next = it.next();
                while (!next.done) {
                    if (next.value in featureSet) {
                        next = it.next();
                        continue;
                    }
                    featuresList.push({ name: next.value, feature: compareFeatures.get(next.value) });
                    featureSet[next.value] = true;
                    next = it.next();
                }
            }
            return featuresList;
        },
        /** A computed map of all sequence features in an example. */
        getSeqFeatures: function (example) {
            if (example == null || example instanceof Example) {
                return new Map([]);
            }
            return this.example
                .getFeatureLists().getFeatureListMap();
        },
        getFilteredFeaturesList: function (featureList, searchValue, saliency) {
            var _this = this;
            var filtered = featureList;
            var checkSal = saliency && Object.keys(saliency).length > 0;
            // Create a dict of feature names to the total absolute saliency of all
            // its feature values, to sort features with the most salienct features at
            // the top.
            var saliencyTotals = checkSal ? Object.assign.apply(Object, [{}].concat(Object.keys(saliency).map(function (name) {
                var _a;
                return (_a = {}, _a[name] = typeof saliency[name] == 'number' ?
                    Math.abs(saliency[name]) :
                    saliency[name].reduce(function (total, cur) {
                        return Math.abs(total) + Math.abs(cur);
                    }, 0), _a);
            }))) :
                {};
            if (searchValue != '') {
                var re_1 = new RegExp(searchValue, 'i');
                filtered = featureList.filter(function (feature) { return re_1.test(feature.name); });
            }
            var sorted = filtered.sort(function (a, b) {
                if (_this.isImage(a.name) && !_this.isImage(b.name)) {
                    return -1;
                }
                else if (_this.isImage(b.name) && !_this.isImage(a.name)) {
                    return 1;
                }
                else {
                    if (checkSal) {
                        if (a.name in saliency && !(b.name in saliency)) {
                            return -1;
                        }
                        else if (b.name in saliency && !(a.name in saliency)) {
                            return 1;
                        }
                        else {
                            var diff = saliencyTotals[b.name] - saliencyTotals[a.name];
                            if (diff != 0) {
                                return diff;
                            }
                        }
                    }
                    return a.name.localeCompare(b.name);
                }
            });
            return sorted;
        },
        /**
         * Returns the maximum sequence length in the sequence example, or -1 if
         * there are no sequences.
         */
        getMaxSeqNumber: function () {
            var max = -1;
            for (var _i = 0, _a = this.seqFeaturesList; _i < _a.length; _i++) {
                var feat = _a[_i];
                var list = feat.feature;
                if (list && list.getFeatureList().length - 1 > max) {
                    max = list.getFeatureList().length - 1;
                }
            }
            return max;
        },
        haveSaliencyJson: function () {
            this.saliency = JSON.parse(this.saliencyJsonString);
        },
        getColors: function () {
            var _a;
            _a = this.getMinMaxSaliency(this.saliency), this.minSal = _a[0], this.maxSal = _a[1];
            return d3.scaleLinear()
                .domain([this.minSal, 0, this.maxSal])
                .interpolate(COLOR_INTERPOLATOR)
                .clamp(true)
                .range([
                negSaliencyColor, neutralSaliencyColor,
                posSaliencyColor
            ]);
        },
        selectAll: function (query) {
            return d3.selectAll(Polymer.dom(this.root).querySelectorAll(query));
        },
        haveSaliency: function () {
            var _this = this;
            if (!this.filteredFeaturesList || !this.saliency ||
                Object.keys(this.saliency).length === 0 || !this.colors) {
                return;
            }
            // TODO(jwexler): Find a way to do this without requestAnimationFrame.
            // If the inputs for the features have yet to be rendered, wait to
            // perform this processing. There should be inputs for all non-image
            // features.
            if (this.selectAll('input.value-pill').size() <
                (this.filteredFeaturesList.length - Object.keys(this.imageInfo).length)) {
                requestAnimationFrame(function () { return _this.haveSaliency(); });
                return;
            }
            // Reset all backgrounds to the neutral color.
            this.selectAll('.value-pill').style('background', neutralSaliencyColor);
            var _loop_1 = function (feat) {
                var val = this_1.saliency[feat.name];
                // If there is no saliency information for the feature, do not color it.
                if (!val) {
                    return "continue";
                }
                var colorFn = Array.isArray(val) ?
                    function (d, i) { return _this.getColorForSaliency(val[i]); } :
                    function () { return _this.getColorForSaliency(val); };
                this_1.selectAll("input." + this_1.sanitizeFeature(feat.name) + ".value-pill")
                    .style('background', this_1.showSaliency ? colorFn : function () { return neutralSaliencyColor; });
                // Color the "more feature values" button with the most extreme saliency
                // of any of the feature values hidden behind the button.
                if (Array.isArray(val)) {
                    var valArray = val;
                    var moreButton = this_1.selectAll("paper-button." + this_1.sanitizeFeature(feat.name) + ".value-pill");
                    var mostExtremeSal_1 = 0;
                    for (var i = 1; i < valArray.length; i++) {
                        if (Math.abs(valArray[i]) > Math.abs(mostExtremeSal_1)) {
                            mostExtremeSal_1 = valArray[i];
                        }
                    }
                    moreButton.style('background', this_1.showSaliency ?
                        function () { return _this.getColorForSaliency(mostExtremeSal_1); } :
                        function () { return neutralSaliencyColor; });
                }
            };
            var this_1 = this;
            // Color the text of each input element of each feature according to the
            // provided saliency information.
            for (var _i = 0, _a = this.filteredFeaturesList; _i < _a.length; _i++) {
                var feat = _a[_i];
                _loop_1(feat);
            }
        },
        /**
         * Updates the saliency coloring of the sequential features when the current
         * sequence number changes.
         */
        newSeqNum: function () {
            this.seqSaliency();
        },
        seqSaliency: function () {
            var _this = this;
            if (!this.seqFeaturesList || !this.saliency ||
                Object.keys(this.saliency).length === 0 || !this.colors) {
                return;
            }
            // TODO(jwexler): Find a way to do this without requestAnimationFrame.
            // If the paper-inputs for the features have yet to be rendered, wait to
            // perform this processing.
            if (this.selectAll('.value input').size() < this.seqFeaturesList.length) {
                requestAnimationFrame(function () { return _this.seqSaliency(); });
                return;
            }
            var _loop_2 = function (feat) {
                var vals = this_2.saliency[feat.name];
                // If there is no saliency information for the feature, do not color it.
                if (!vals) {
                    return "continue";
                }
                var val = vals[this_2.seqNumber];
                var colorFn = Array.isArray(val) ?
                    function (d, i) { return _this.getColorForSaliency(val[i]); } :
                    function () { return _this.getColorForSaliency(val); };
                this_2.selectAll("." + this_2.sanitizeFeature(feat.name) + " input")
                    .style('color', this_2.showSaliency ? colorFn : function () { return 'black'; });
            };
            var this_2 = this;
            // Color the text of each input element of each feature according to the
            // provided saliency information for the current sequence number.
            for (var _i = 0, _a = this.seqFeaturesList; _i < _a.length; _i++) {
                var feat = _a[_i];
                _loop_2(feat);
            }
        },
        /**
         * Returns a list of the min and max saliency values, clipped by the
         * saliency ratio.
         */
        getMinMaxSaliency: function (saliency) {
            var min = Infinity;
            var max = -Infinity;
            var checkSaliencies = function (saliencies) {
                if (Array.isArray(saliencies)) {
                    for (var _i = 0, saliencies_1 = saliencies; _i < saliencies_1.length; _i++) {
                        var s = saliencies_1[_i];
                        checkSaliencies(s);
                    }
                }
                else {
                    if (saliencies < min) {
                        min = saliencies;
                    }
                    if (saliencies > max) {
                        max = saliencies;
                    }
                }
            };
            for (var feat in saliency) {
                if (saliency.hasOwnProperty(feat)) {
                    checkSaliencies(saliency[feat]);
                }
            }
            min = Math.min(0, min) * clipSaliencyRatio;
            max = Math.max(0, max) * clipSaliencyRatio;
            return [min, max];
        },
        /**
         * Returns a list of the feature values for a feature. If keepBytes is true
         * then return the raw bytes. Otherwise convert them to a readable string.
         */
        getFeatureValues: function (feature, keepBytes, isImage, compareValues) {
            var _this = this;
            var feat = compareValues ?
                this.compareFeatures.get(feature) :
                this.features.get(feature);
            if (!feat) {
                return [];
            }
            if (feat.getBytesList()) {
                if (!keepBytes) {
                    var vals = feat.getBytesList().getValueList_asU8().map(function (u8array) { return _this.decodeBytesListString(u8array, isImage); });
                    return vals;
                }
                return feat.getBytesList().getValueList().slice();
            }
            else if (feat.getInt64List()) {
                return feat.getInt64List().getValueList().slice();
            }
            else if (feat.getFloatList()) {
                return feat.getFloatList().getValueList().slice();
            }
            return [];
        },
        /**
         * Returns a list of the feature values for a the compared example for
         * a feature.
         */
        getCompareFeatureValues: function (feature, keepBytes, isImage) {
            return this.getFeatureValues(feature, keepBytes, isImage, true);
        },
        /** Returns the first feature value for a feature. */
        getFirstFeatureValue: function (feature) {
            return this.getFeatureValues(feature)[0];
        },
        /** Returns the first feature value for a compared example for a feature. */
        getFirstCompareFeatureValue: function (feature) {
            return this.getCompareFeatureValues(feature)[0];
        },
        /** Returns if a feature has more than one feature value. */
        featureHasMultipleValues: function (feature) {
            return this.getFeatureValues(feature).length > 1;
        },
        /**
         * Returns if a feature has more than one feature value in the compared
         * example.
         */
        compareFeatureHasMultipleValues: function (feature) {
            return this.getCompareFeatureValues(feature).length > 1;
        },
        /**
         * Returns a list of the sequence feature values for a feature for a given
         * sequence number. If keepBytes is true then return the raw bytes. Otherwise
         * convert them to a readable string.
         */
        getSeqFeatureValues: function (feature, seqNum, keepBytes, isImage, compareValues) {
            var _this = this;
            var featlistholder = compareValues ?
                this.compareSeqFeatures.get(feature) :
                this.seqFeatures.get(feature);
            if (!featlistholder) {
                return [];
            }
            var featlist = featlistholder.getFeatureList();
            // It is possible that there are features that do not have sequence lengths
            // as long as the longest sequence length in the example.  In this case,
            // show an empty feature value list for that feature.
            if (!featlist || featlist.length <= seqNum) {
                return [];
            }
            var feat = featlist[seqNum];
            if (!feat) {
                return [];
            }
            if (feat.getBytesList()) {
                if (!keepBytes) {
                    return feat.getBytesList().getValueList_asU8().map(function (u8array) { return _this.decodeBytesListString(u8array, isImage); });
                }
                return feat.getBytesList().getValueList();
            }
            else if (feat.getInt64List()) {
                return feat.getInt64List().getValueList();
            }
            else if (feat.getFloatList()) {
                return feat.getFloatList().getValueList();
            }
            return [];
        },
        /**
         * Returns a list of the sequence feature values for a feature for a given
         * sequence number of the compared example.
         */
        getCompareSeqFeatureValues: function (feature, seqNum, keepBytes, isImage) {
            return this.getSeqFeatureValues(feature, seqNum, keepBytes, isImage, true);
        },
        /** Returns the first feature value for a sequence feature. */
        getFirstSeqFeatureValue: function (feature, seqNum) {
            return this.getSeqFeatureValues(feature, seqNum)[0];
        },
        /** Returns the first feature value for the compared example for a feature. */
        getFirstSeqCompareFeatureValue: function (feature, seqNum) {
            return this.getCompareSeqFeatureValues(feature, seqNum)[0];
        },
        /** Returns if a sequence feature has more than one feature value. */
        seqFeatureHasMultipleValues: function (feature, seqNum) {
            return this.getSeqFeatureValues(feature, seqNum).length > 1;
        },
        /**
         * Returns if a sequence feature has more than one feature value in the
         * compared example.
         */
        compareSeqFeatureHasMultipleValues: function (feature, seqNum) {
            return this.getCompareSeqFeatureValues(feature, seqNum).length > 1;
        },
        /**
         * Decodes a list of bytes into a readable string, treating the bytes as
         * unicode char codes. If singleByteChars is true, then treat each byte as its
         * own char, which is necessary for image strings and serialized protos.
         * Returns an empty string for arrays over 250MB in size, which should not
         * be an issue in practice with tf.Examples.
         */
        decodeBytesListString: function (bytes, singleByteChars) {
            if (bytes.length > MAX_BYTES_LIST_LENGTH) {
                return MAX_STRING_INDICATION;
            }
            return singleByteChars ? this.decodeBytesListToString(bytes) :
                new window.TextDecoder().decode(bytes);
        },
        isBytesFeature: function (feature) {
            var feat = this.features.get(feature);
            if (feat) {
                if (feat.hasBytesList()) {
                    return true;
                }
            }
            var seqfeat = this.seqFeatures.get(feature);
            if (seqfeat) {
                if (seqfeat.getFeatureList()[0].hasBytesList()) {
                    return true;
                }
            }
            return false;
        },
        /**
         * Gets the allowed input type for a feature value, according to its
         * feature type.
         */
        getInputType: function (feature) {
            var feat = this.features.get(feature);
            if (feat) {
                if (feat.getInt64List() || feat.getFloatList()) {
                    return 'number';
                }
            }
            var seqfeat = this.seqFeatures.get(feature);
            if (seqfeat) {
                if (seqfeat.getFeatureList()[0].getInt64List() ||
                    seqfeat.getFeatureList()[0].getFloatList()) {
                    return 'number';
                }
            }
            return 'text';
        },
        /**
         * Returns the feature object from the provided json attribute for a given
         * feature name.
         */
        getJsonFeature: function (feat) {
            if (!this.json) {
                return null;
            }
            if (this.json.features && this.json.features.feature) {
                var jsonFeature = this.json.features.feature[feat];
                if (jsonFeature) {
                    return jsonFeature;
                }
            }
            if (this.json.context && this.json.context.feature) {
                var jsonFeature = this.json.context.feature[feat];
                if (jsonFeature) {
                    return jsonFeature;
                }
            }
            if (this.json.featureLists && this.json.featureLists.featureList) {
                return this.json.featureLists.featureList[feat];
            }
            return null;
        },
        /**
         * Returns the value list from the provided json attribute for a given
         * feature name and sequence number (when the feature is sequential). The
         * sequence number should be NaN for non-sequential features.
         */
        getJsonValueList: function (feat, seqNum) {
            // Get the feature object for the feature name provided.
            var feature = this.getJsonFeature(feat);
            if (!feature) {
                return null;
            }
            // If a sequential feature, get the feature entry for the given sequence
            // number.
            if (!isNaN(seqNum)) {
                feature = feature.feature[seqNum];
            }
            var valueList = feature.bytesList || feature.int64List || feature.floatList;
            return valueList ? valueList.value : null;
        },
        /**
         * From an event, finds the feature, value list index and sequence number
         * that the event corresponds to.
         */
        getDataFromEvent: function (event) {
            var elem = event.target;
            // Get the control that contains the event target. The control will have its
            // data-feature attribute set.
            while (elem.dataFeature == null) {
                if (!elem.parentElement) {
                    throw new Error('Could not find ancestor control element');
                }
                elem = elem.parentElement;
            }
            return {
                feature: elem.dataFeature,
                valueIndex: elem.dataIndex,
                seqNum: elem.dataSeqNum
            };
        },
        /** Gets the Feature object corresponding to the provided DataFromControl. */
        getFeatureFromData: function (data) {
            // If there is no sequence number, then it is a standard feature, not a
            // sequential feature.
            if (isNaN(data.seqNum)) {
                return this.features.get(data.feature);
            }
            else {
                var featureLists = this.seqFeatures.get(data.feature);
                if (!featureLists) {
                    return undefined;
                }
                var featureList = featureLists.getFeatureList();
                if (!featureList) {
                    return undefined;
                }
                return featureList[data.seqNum];
            }
        },
        /** Gets the value list corresponding to the provided DataFromControl. */
        getValueListFromData: function (data) {
            // If there is no sequence number, then it is a standard feature, not a
            // sequential feature.
            if (isNaN(data.seqNum)) {
                return this.getFeatureValues(data.feature, true);
            }
            else {
                return this.getSeqFeatureValues(data.feature, data.seqNum, true);
            }
        },
        /** Sets the value list on the provided feature. */
        setFeatureValues: function (feat, values) {
            var bytesList = feat.getBytesList();
            var int64List = feat.getInt64List();
            var floatList = feat.getFloatList();
            if (bytesList) {
                bytesList.setValueList(values);
            }
            else if (int64List) {
                int64List.setValueList(values);
            }
            else if (floatList) {
                floatList.setValueList(values);
            }
        },
        /**
         * When a feature value changes from a paper-input, updates the example proto
         * appropriately.
         */
        onValueChanged: function (event) {
            var inputControl = event.target;
            var data = this.getDataFromEvent(event);
            var feat = this.getFeatureFromData(data);
            var values = this.getValueListFromData(data);
            if (feat) {
                if (this.isBytesFeature(data.feature)) {
                    // For string features, convert the string into the char code array
                    // for storage in the proto.
                    var cc = this.stringToUint8Array(inputControl.value);
                    // tslint:disable-next-line:no-any cast due to tf.Example typing.
                    values[data.valueIndex] = cc;
                    // If the example was provided as json, update the byteslist in the
                    // json with the base64 encoded string. For non-bytes features we don't
                    // need this separate json update as the proto value list is the same
                    // as the json value list for that case (shallow copy). The byteslist
                    // case is different as the json base64 encoded string is converted to
                    // a list of bytes, one per character.
                    var jsonList = this.getJsonValueList(data.feature, data.seqNum);
                    if (jsonList) {
                        jsonList[data.valueIndex] = btoa(inputControl.value);
                    }
                }
                else {
                    values[data.valueIndex] = +inputControl.value;
                    var jsonList = this.getJsonValueList(data.feature, data.seqNum);
                    if (jsonList) {
                        jsonList[data.valueIndex] = +inputControl.value;
                    }
                }
                this.setFeatureValues(feat, values);
                this.exampleChanged();
            }
        },
        onInputFocus: function (event) {
            var inputControl = event.target;
            var data = this.getDataFromEvent(event);
            this.focusedFeatureName = data.feature;
            this.focusedFeatureValueIndex = data.valueIndex;
            this.focusedSeqNumber = data.seqNum;
            this.$.deletevalue.style.top = (inputControl.getBoundingClientRect().top -
                this.getBoundingClientRect().top - 25) + 'px';
            this.$.deletevalue.style.right = (this.getBoundingClientRect().right -
                inputControl.getBoundingClientRect().right + 30) + 'px';
            this.showDeleteValueButton = true;
        },
        onInputBlur: function (event) {
            this.showDeleteValueButton = false;
        },
        /**
         * When a feature is deleted, updates the example proto appropriately.
         */
        deleteFeature: function (event) {
            var data = this.getDataFromEvent(event);
            if (this.features.del) {
                this.features.del(data.feature);
            }
            if (this.seqFeatures.del) {
                this.seqFeatures.del(data.feature);
            }
            this.deleteJsonFeature(data.feature);
            this.exampleChanged();
            this.refreshExampleViewer();
        },
        /**
         * Helper method to delete a feature from the JSON version of the example,
         * if the example was provided as JSON.
         */
        deleteJsonFeature: function (feature) {
            if (this.json) {
                if (this.json.features && this.json.features.feature) {
                    delete this.json.features.feature[feature];
                }
                if (this.json.context && this.json.context.feature) {
                    delete this.json.context.feature[feature];
                }
                if (this.json.featureLists && this.json.featureLists.featureList) {
                    delete this.json.featureLists.featureList[feature];
                }
            }
        },
        /**
         * When a feature value is deleted, updates the example proto appropriately.
         */
        deleteValue: function (event) {
            var data = this.getDataFromEvent(event);
            var feat = this.getFeatureFromData(data);
            var values = this.getValueListFromData(data);
            if (feat) {
                if (this.isBytesFeature(data.feature)) {
                    // If the example was provided as json, update the byteslist in the
                    // json. For non-bytes features we don't need this separate json update
                    // as the proto value list is the same as the json value list for that
                    // case (shallow copy). The byteslist case is different as the json
                    // base64 encoded string is converted to a list of bytes, one per
                    // character.
                    var jsonList = this.getJsonValueList(data.feature, data.seqNum);
                    if (jsonList) {
                        jsonList.splice(data.valueIndex, 1);
                    }
                }
                values.splice(data.valueIndex, 1);
                this.setFeatureValues(feat, values);
                this.exampleChanged();
                this.refreshExampleViewer();
            }
        },
        openAddFeatureDialog: function () {
            this.$.addFeatureDialog.open();
        },
        /**
         * When a feature is added, updates the example proto appropriately.
         */
        addFeature: function (event) {
            if (!this.json) {
                return;
            }
            var feat = new Feature();
            // tslint:disable-next-line:no-any Using arbitary json.
            var jsonFeat;
            if (this.newFeatureType === INT_FEATURE_NAME) {
                var valueList = [];
                var ints = new FloatList();
                ints.setValueList(valueList);
                feat.setInt64List(ints);
                jsonFeat = { int64List: { value: valueList } };
            }
            else if (this.newFeatureType === FLOAT_FEATURE_NAME) {
                var valueList = [];
                var floats = new FloatList();
                floats.setValueList(valueList);
                feat.setFloatList(floats);
                jsonFeat = { floatList: { value: valueList } };
            }
            else {
                var valueList = [];
                var bytes = new BytesList();
                bytes.setValueList(valueList);
                feat.setBytesList(bytes);
                jsonFeat = { bytesList: { value: valueList } };
            }
            this.features.set(this.newFeatureName, feat);
            this.addJsonFeature(this.newFeatureName, jsonFeat);
            this.newFeatureName = '';
            this.exampleChanged();
            this.refreshExampleViewer();
        },
        /**
         * Helper method to add a feature to the JSON version of the example,
         * if the example was provided as JSON.
         */
        // tslint:disable-next-line:no-any Using arbitary json.
        addJsonFeature: function (feature, jsonFeat) {
            if (this.json && this.json.features && this.json.features.feature) {
                this.json.features.feature[feature] = jsonFeat;
            }
            else if (this.json && this.json.context && this.json.context.feature) {
                this.json.context.feature[feature] = jsonFeat;
            }
        },
        /**
         * When a feature value is added, updates the example proto appropriately.
         */
        addValue: function (event) {
            var data = this.getDataFromEvent(event);
            var feat = this.getFeatureFromData(data);
            var values = this.getValueListFromData(data);
            if (feat) {
                if (this.isBytesFeature(data.feature)) {
                    values.push('');
                }
                else {
                    values.push(0);
                }
                this.setFeatureValues(feat, values);
                this.exampleChanged();
                this.refreshExampleViewer();
            }
        },
        /**
         * Refreshes the example viewer so that it correctly shows the updated
         * example.
         */
        refreshExampleViewer: function () {
            var _this = this;
            // In order for iron-lists to be properly updated based on proto changes,
            // need to bind the example to another (blank) example, and then back the
            // the proper example after that change has been processed.
            // TODO(jwexler): Find better way to update the visuals on proto changes.
            var temp = this.example;
            this.ignoreChange = true;
            this.example = new Example();
            this.ignoreChange = false;
            setTimeout(function () {
                _this.example = temp;
                _this.haveSaliency();
            }, 0);
        },
        exampleChanged: function () {
            // Fire example-change event.
            this.fire('example-change', { example: this.example });
            // This change is performed after a delay in order to debounce rapid updates
            // to a text/number field, as serialization can take some time and freeze
            // the visualization temporarily.
            clearTimeout(this.changeCallbackTimer);
            this.changeCallbackTimer = setTimeout(this.changeCallback.bind(this), CHANGE_CALLBACK_TIMER_DELAY_MS);
        },
        changeCallback: function () {
            // To update the serialized example, we need to ensure we ignore parsing
            // of the updated serialized example back to an example object as they
            // already match and this would cause a lot of unnecessary processing,
            // leading to long freezes in the visualization.
            this.ignoreChange = true;
            if (this.isSequence && this.serializedSeqExample) {
                this.serializedSeqExample = btoa(this.decodeBytesListString(this.example.serializeBinary(), true));
            }
            else if (this.serializedExample) {
                this.serializedExample = btoa(this.decodeBytesListString(this.example.serializeBinary(), true));
            }
            this.ignoreChange = false;
        },
        getInputPillClass: function (feat, displayMode) {
            return this.sanitizeFeature(feat) + ' value-pill' +
                (displayMode == 'grid' ? ' value-pill-grid' : ' value-pill-stacked');
        },
        getCompareInputClass: function (feat, displayMode, index) {
            var str = 'value-compare' +
                (displayMode == 'grid' ? ' value-pill-grid' : ' value-pill-stacked');
            if (index != null) {
                var values = this.getFeatureValues(feat, true);
                var compValues = this.getCompareFeatureValues(feat, true);
                if (index >= values.length || index >= compValues.length ||
                    values[index] != compValues[index]) {
                    str += ' value-different';
                }
                else {
                    str += ' value-same';
                }
            }
            return str;
        },
        getSeqCompareInputClass: function (feat, displayMode, seqNumber, index) {
            var str = 'value-compare' +
                (displayMode == 'grid' ? ' value-pill-grid' : ' value-pill-stacked');
            if (index != null) {
                var values = this.getSeqFeatureValues(feat, seqNumber, true);
                var compValues = this.getCompareSeqFeatureValues(feat, seqNumber, true);
                if (index >= values.length || index >= compValues.length ||
                    values[index] != compValues[index]) {
                    str += ' value-different';
                }
                else {
                    str += ' value-same';
                }
            }
            return str;
        },
        /**
         * Replaces non-standard chars in feature names with underscores so they can
         * be used in css classes/ids.
         */
        sanitizeFeature: function (feat) {
            var sanitized = feat;
            if (!feat.match(/^[A-Za-z].*$/)) {
                sanitized = '_' + feat;
            }
            return sanitized.replace(/[\/\.\#]/g, '_');
        },
        isSeqExample: function (maxSeqNumber) {
            return maxSeqNumber >= 0;
        },
        shouldShowSaliencyLegend: function (saliency) {
            return saliency && Object.keys(saliency).length > 0;
        },
        // tslint:disable-next-line:no-unused-variable called as computed property
        getSaliencyControlsHolderClass: function (saliency) {
            return this.shouldShowSaliencyLegend(saliency) ?
                'saliency-controls-holder' :
                'hide-saliency-controls';
        },
        /** Creates an svg legend for the saliency color mapping. */
        createLegend: function () {
            d3.select(this.$.saliencyLegend).selectAll('*').remove();
            var legendSvg = d3.select(this.$.saliencyLegend).append('g');
            var gradient = legendSvg.append('defs')
                .append('linearGradient')
                .attr('id', 'vzexampleviewergradient')
                .attr("x1", "0%")
                .attr("y1", "0%")
                .attr("x2", "100%")
                .attr("y2", "0%")
                .attr('spreadMethod', 'pad');
            var linspace = function (start, end, n) {
                var out = [];
                var delta = (end - start) / (n - 1);
                var i = 0;
                while (i < (n - 1)) {
                    out.push(start + (i * delta));
                    i++;
                }
                out.push(end);
                return out;
            };
            // Create the correct color scale for the legend depending on minimum
            // and maximum saliency for this example.
            var scale = [];
            if (this.minSal < 0) {
                scale.push(negSaliencyColor);
            }
            scale.push(neutralSaliencyColor);
            if (this.maxSal > 0) {
                scale.push(posSaliencyColor);
            }
            // Creates an array of [pct, colour] pairs as stop
            // values for legend
            var pct = linspace(0, 100, scale.length).map(function (d) {
                return Math.round(d) + '%';
            });
            var colourPct = d3.zip(pct, scale);
            colourPct.forEach(function (d) {
                gradient.append('stop')
                    .attr('offset', d[0])
                    .attr('stop-color', d[1])
                    .attr('stop-opacity', 1);
            });
            legendSvg.append('rect')
                .attr('x1', 0)
                .attr('y1', 0)
                .attr('width', LEGEND_WIDTH_PX)
                .attr('height', LEGEND_HEIGHT_PX)
                .style('fill', 'url(#vzexampleviewergradient)');
            var legendScale = d3.scaleLinear().domain([this.minSal, this.maxSal]).range([
                0, LEGEND_WIDTH_PX
            ]);
            var legendAxis = d3.axisBottom(legendScale);
            legendSvg.append('g')
                .attr('class', 'legend axis')
                .attr('transform', "translate(0," + LEGEND_HEIGHT_PX + ")")
                .call(legendAxis);
        },
        isImage: function (feat) {
            return IMG_FEATURE_REGEX.test(feat);
        },
        /**
         * Returns the data URI src for a feature value that is an encoded image.
         */
        getImageSrc: function (feat) {
            this.setupOnloadCallback(feat);
            return this.getImageSrcForData(feat, this.getFeatureValues(feat, false, true)[0]);
        },
        /**
         * Returns the data URI src for a feature value that is an encoded image, for
         * the compared example.
         */
        getCompareImageSrc: function (feat) {
            this.setupOnloadCallback(feat, true);
            return this.getImageSrcForData(feat, this.getCompareFeatureValues(feat, false, true)[0], true);
        },
        /**
         * Returns the data URI src for a sequence feature value that is an encoded
         * image.
         */
        getSeqImageSrc: function (feat, seqNum) {
            this.setupOnloadCallback(feat);
            return this.getImageSrcForData(feat, this.getSeqFeatureValues(feat, seqNum, false, true)[0]);
        },
        /**
         * Returns the data URI src for a sequence feature value that is an encoded
         * image, for the compared example.
         */
        getCompareSeqImageSrc: function (feat, seqNum) {
            this.setupOnloadCallback(feat, true);
            return this.getImageSrcForData(feat, this.getCompareSeqFeatureValues(feat, seqNum, false, true)[0], true);
        },
        /**
         * On the next frame, sets the onload callback for the image for the given
         * feature. This is delayed until the next frame to ensure the img element
         * is rendered before setting up the onload function.
         */
        setupOnloadCallback: function (feat, compare) {
            var _this = this;
            requestAnimationFrame(function () {
                var img = _this.$$('#' + _this.getImageId(feat, compare));
                img.onload = _this.getOnLoadForImage(feat, img, compare);
            });
        },
        /** Helper method used by getImageSrc and getSeqImageSrc. */
        getImageSrcForData: function (feat, imageData, compare) {
            // Get the format of the encoded image, according to the feature name
            // specified by go/tf-example. Defaults to jpeg as specified in the doc.
            var regExResult = IMG_FEATURE_REGEX.exec(feat);
            if (regExResult == null) {
                return null;
            }
            var featureMiddle = regExResult[1] || '';
            var formatVals = compare ?
                this.getCompareFeatureValues('image' + featureMiddle + '/format', false) :
                this.getFeatureValues('image' + featureMiddle + '/format', false);
            var format = 'jpeg';
            if (formatVals.length > 0) {
                format = formatVals[0].toLowerCase();
            }
            var src = 'data:image/' + format + ';base64,';
            // Encode the image data in base64.
            src = src + btoa(decodeURIComponent(encodeURIComponent(imageData)));
            return src;
        },
        /** Returns the length of an iterator. */
        getIterLength: function (it) {
            var len = 0;
            if (it) {
                var next = it.next();
                while (!next.done) {
                    len++;
                    next = it.next();
                }
            }
            return len;
        },
        /**
         * Updates the compare mode based off of the compared example.
         */
        updateCompareMode: function () {
            var compareMode = false;
            if ((this.compareFeatures &&
                this.getIterLength(this.compareFeatures.keys()) > 0) ||
                (this.compareSeqFeatures &&
                    this.getIterLength(this.compareSeqFeatures.keys()) > 0)) {
                compareMode = true;
            }
            this.compareMode = compareMode;
        },
        /**
         * Creates tf.Example or tf.SequenceExample jspb object from json. Useful when
         * this is embedded into a OnePlatform app that sends protos as json.
         */
        createExamplesFromJson: function (json) {
            this.example = this.createExamplesFromJsonHelper(json);
            this.compareJson = {};
        },
        /**
         * Creates compared tf.Example or tf.SequenceExample jspb object from json.
         * Useful when this is embedded into a OnePlatform app that sends protos as
         * json.
         */
        createCompareExamplesFromJson: function (json) {
            if (!json) {
                return;
            }
            this.compareExample = this.createExamplesFromJsonHelper(json);
        },
        createExamplesFromJsonHelper: function (json) {
            if (!json) {
                return null;
            }
            // If the provided json is a json string, parse it into an object.
            if (typeof this.json === 'string') {
                json = JSON.parse(this.json);
            }
            if (json.features) {
                var ex = new Example();
                ex.setFeatures(this.parseFeatures(json.features));
                return ex;
            }
            else if (json.context || json.featureLists) {
                var seqex = new SequenceExample();
                if (json.context) {
                    seqex.setContext(this.parseFeatures(json.context));
                }
                if (json.featureLists) {
                    seqex.setFeatureLists(this.parseFeatureLists(json.featureLists));
                }
                return seqex;
            }
            else {
                return new Example();
            }
        },
        // tslint:disable-next-line:no-any Parsing arbitary json.
        parseFeatures: function (features) {
            var feats = new Features();
            for (var fname in features.feature) {
                if (features.feature.hasOwnProperty(fname)) {
                    var featentry = features.feature[fname];
                    feats.getFeatureMap().set(fname, this.parseFeature(featentry, this.isImage(fname)));
                }
            }
            return feats;
        },
        // tslint:disable-next-line:no-any Parsing arbitary json.
        parseFeatureLists: function (features) {
            var feats = new FeatureLists();
            for (var fname in features.featureList) {
                if (features.featureList.hasOwnProperty(fname)) {
                    var featlistentry = features.featureList[fname];
                    var featList = new FeatureList();
                    var featureList = [];
                    for (var featentry in featlistentry.feature) {
                        if (featlistentry.feature.hasOwnProperty(featentry)) {
                            var feat = featlistentry.feature[featentry];
                            featureList.push(this.parseFeature(feat, this.isImage(fname)));
                        }
                    }
                    featList.setFeatureList(featureList);
                    feats.getFeatureListMap().set(fname, featList);
                }
            }
            return feats;
        },
        // tslint:disable-next-line:no-any Parsing arbitary json.
        parseFeature: function (featentry, isImage) {
            var feat = new Feature();
            if (featentry.floatList) {
                var floats = new FloatList();
                floats.setValueList(featentry.floatList.value);
                feat.setFloatList(floats);
            }
            else if (featentry.bytesList) {
                // Json byteslist entries are base64.  The JSPB generated Feature class
                // will marshall this to U8 automatically.
                var bytes = new BytesList();
                if (featentry.bytesList.value) {
                    bytes.setValueList(featentry.bytesList.value);
                }
                feat.setBytesList(bytes);
            }
            else if (featentry.int64List) {
                var ints = new Int64List();
                ints.setValueList(featentry.int64List.value);
                feat.setInt64List(ints);
            }
            return feat;
        },
        getImageId: function (feat, compare) {
            if (compare) {
                return this.getCompareImageId(feat);
            }
            return this.sanitizeFeature(feat) + '_image';
        },
        getCanvasId: function (feat, compare) {
            if (compare) {
                return this.getCompareCanvasId(feat);
            }
            return this.sanitizeFeature(feat) + '_canvas';
        },
        getImageCardId: function (feat, compare) {
            if (compare) {
                return this.getCompareImageCardId(feat);
            }
            return this.sanitizeFeature(feat) + '_card';
        },
        getCompareImageId: function (feat) {
            return this.sanitizeFeature(feat) + '_image_compare';
        },
        getCompareCanvasId: function (feat) {
            return this.sanitizeFeature(feat) + '_canvas_compare';
        },
        getCompareImageCardId: function (feat) {
            return this.sanitizeFeature(feat) + '_card_compare';
        },
        getFeatureDialogId: function (feat) {
            return this.sanitizeFeature(feat) + '_dialog';
        },
        featureMoreClicked: function (event) {
            var button = event.srcElement.parentElement;
            var feature = button.dataFeature;
            var dialog = this.$$('#' + this.sanitizeFeature(feature) + '_dialog');
            dialog.positionTarget = button;
            dialog.open();
        },
        expandFeature: function (event) {
            var feature = event.srcElement.dataFeature;
            this.set('expandedFeatures.' + this.sanitizeFeature(feature), true);
            this.refreshExampleViewer();
        },
        decodedStringToCharCodes: function (str) {
            var cc = new Uint8Array(str.length);
            for (var i = 0; i < str.length; ++i) {
                cc[i] = str.charCodeAt(i);
            }
            return cc;
        },
        handleImageUpload: function (event) {
            this.handleFileSelect(event, this);
        },
        // Handle upload image paper button click by delegating to appropriate
        // paper-input file chooser.
        uploadImageClicked: function (event) {
            var data = this.getDataFromEvent(event);
            var inputs = Polymer.dom(this.root).querySelectorAll('paper-input');
            var inputElem = null;
            for (var i = 0; i < inputs.length; i++) {
                if (inputs[i].dataFeature == data.feature) {
                    inputElem = inputs[i];
                    break;
                }
            }
            if (inputElem) {
                inputElem.querySelector('input').click();
            }
        },
        // Handle file select for image replacement.
        handleFileSelect: function (event, self) {
            event.stopPropagation();
            event.preventDefault();
            var reader = new FileReader();
            var eventAny = event;
            var files = eventAny.dataTransfer ? eventAny.dataTransfer.files : eventAny.target.files;
            if (files.length === 0) {
                return;
            }
            reader.addEventListener('load', function () {
                // Get the image data from the loaded image and convert to a char
                // code array for use in the features value list.
                var index = +reader.result.indexOf(BASE_64_IMAGE_ENCODING_PREFIX) +
                    BASE_64_IMAGE_ENCODING_PREFIX.length;
                var encodedImageData = reader.result.substring(index);
                var cc = self.decodedStringToCharCodes(atob(encodedImageData));
                var data = self.getDataFromEvent(event);
                var feat = self.getFeatureFromData(data);
                var values = self.getValueListFromData(data);
                if (feat) {
                    // Replace the old image data in the feature value list with the new
                    // image data.
                    // tslint:disable-next-line:no-any cast due to tf.Example typing.
                    values[0] = cc;
                    feat.getBytesList().setValueList(values);
                    // If the example was provided as json, update the byteslist in the
                    // json with the base64 encoded string.
                    var jsonList = self.getJsonValueList(data.feature, data.seqNum);
                    if (jsonList) {
                        jsonList[0] = encodedImageData;
                    }
                    // Load the image data into an image element to begin the process
                    // of rendering that image to a canvas for display.
                    var img_1 = new Image();
                    self.addImageElement(data.feature, img_1);
                    img_1.addEventListener('load', function () {
                        // Runs the apppriate onload processing for the new image.
                        self.getOnLoadForImage(data.feature, img_1);
                        // If the example contains appropriately-named features describing
                        // the image width and height then update those feature values for
                        // the new image width and height.
                        var featureMiddle = IMG_FEATURE_REGEX.exec(data.feature)[1] || '';
                        var widthFeature = 'image' + featureMiddle + '/width';
                        var heightFeature = 'image' + featureMiddle + '/height';
                        var widths = self.getFeatureValues(widthFeature, false);
                        var heights = self.getFeatureValues(heightFeature, false);
                        if (widths.length > 0) {
                            widths[0] = +img_1.width;
                            self.features.get(widthFeature).getInt64List().setValueList(widths);
                        }
                        if (heights.length > 0) {
                            heights[0] = +img_1.height;
                            self.features.get(heightFeature).getInt64List().setValueList(heights);
                        }
                        self.exampleChanged();
                    });
                    img_1.src = reader.result;
                }
            }, false);
            // Read the image file as a data URL.
            reader.readAsDataURL(files[0]);
        },
        // Add drag-and-drop image replacement behavior to the canvas.
        addDragDropBehaviorToCanvas: function (canvas) {
            var self = this;
            // Handle drag event for drag-and-drop image replacement.
            function handleDragOver(event) {
                event.stopPropagation();
                event.preventDefault();
                event.dataTransfer.dropEffect = 'copy';
            }
            function handleFileSelect(event) {
                self.handleFileSelect(event, self);
            }
            if (!this.readonly && canvas) {
                canvas.addEventListener('dragover', handleDragOver, false);
                canvas.addEventListener('drop', handleFileSelect, false);
            }
        },
        /**
         * Returns an onload function for an img element. The function draws the image
         * to the appropriate canvas element and adds the saliency information to the
         * canvas if it exists.
         */
        getOnLoadForImage: function (feat, image, compare) {
            var _this = this;
            var f = function (feat, image, compare) {
                var canvas = _this.$$('#' + _this.getCanvasId(feat, compare));
                if (!compare) {
                    _this.addDragDropBehaviorToCanvas(canvas);
                }
                if (image && canvas) {
                    // Draw the image to the canvas and size the canvas.
                    // Set d3.zoom on the canvas to enable zooming and scaling interactions.
                    var context_1 = canvas.getContext('2d');
                    var imageScaleFactor = _this.imageScalePercentage / 100;
                    // If not using image controls then scale the image to match the
                    // available width in the container, considering padding.
                    if (!_this.allowImageControls) {
                        var holder = _this.$$('#' +
                            _this.getImageCardId(feat, compare)).parentElement;
                        var cardWidthForScaling = holder.getBoundingClientRect().width / 2;
                        if (cardWidthForScaling > 16) {
                            cardWidthForScaling -= 16;
                        }
                        if (cardWidthForScaling < image.width) {
                            imageScaleFactor = cardWidthForScaling / image.width;
                        }
                    }
                    canvas.width = image.width * imageScaleFactor;
                    canvas.height = image.height * imageScaleFactor;
                    var transformFn_1 = function (transform) {
                        context_1.save();
                        context_1.clearRect(0, 0, canvas.width, canvas.height);
                        context_1.translate(transform.x, transform.y);
                        context_1.scale(transform.k, transform.k);
                        _this.renderImageOnCanvas(context_1, canvas.width, canvas.height, feat, compare);
                        context_1.restore();
                    };
                    var zoom = function () {
                        var transform = d3.event.transform;
                        _this.addImageTransform(feat, transform, compare);
                        transformFn_1(d3.event.transform);
                    };
                    var d3zoom_1 = d3.zoom().scaleExtent(ZOOM_EXTENT).on('zoom', zoom);
                    d3.select(canvas).call(d3zoom_1).on('dblclick.zoom', function () { return d3.select(canvas).call(d3zoom_1.transform, d3.zoomIdentity); });
                    context_1.save();
                    context_1.scale(imageScaleFactor, imageScaleFactor);
                    context_1.drawImage(image, 0, 0);
                    context_1.restore();
                    _this.setImageDatum(context_1, canvas.width, canvas.height, feat, compare);
                    _this.renderImageOnCanvas(context_1, canvas.width, canvas.height, feat, compare);
                    if (compare) {
                        if (_this.compareImageInfo[feat].transform) {
                            transformFn_1(_this.compareImageInfo[feat].transform);
                        }
                    }
                    else {
                        if (_this.imageInfo[feat].transform) {
                            transformFn_1(_this.imageInfo[feat].transform);
                        }
                    }
                }
                else {
                    // If the image and canvas are not yet rendered, wait to perform this
                    // processing.
                    requestAnimationFrame(function () { return f(feat, image, compare); });
                }
            };
            this.addImageElement(feat, image, compare);
            this.addImageOnLoad(feat, f, compare);
            return f.apply(this, [feat, image, compare]);
        },
        addImageOnLoad: function (feat, onload, compare) {
            this.hasImage = true;
            if (compare) {
                if (!this.compareImageInfo[feat]) {
                    this.compareImageInfo[feat] = {};
                }
                this.compareImageInfo[feat].onload = onload;
            }
            else {
                if (!this.imageInfo[feat]) {
                    this.imageInfo[feat] = {};
                }
                this.imageInfo[feat].onload = onload;
            }
        },
        addImageData: function (feat, imageData, compare) {
            if (compare) {
                if (!this.compareImageInfo[feat]) {
                    this.compareImageInfo[feat] = {};
                }
                this.compareImageInfo[feat].imageData = imageData;
            }
            else {
                if (!this.imageInfo[feat]) {
                    this.imageInfo[feat] = {};
                }
                this.imageInfo[feat].imageData = imageData;
            }
        },
        addImageElement: function (feat, image, compare) {
            if (compare) {
                if (!this.compareImageInfo[feat]) {
                    this.compareImageInfo[feat] = {};
                }
                this.compareImageInfo[feat].imageElement = image;
            }
            else {
                if (!this.imageInfo[feat]) {
                    this.imageInfo[feat] = {};
                }
                this.imageInfo[feat].imageElement = image;
            }
        },
        addImageGrayscaleData: function (feat, imageGrayscaleData) {
            if (!this.imageInfo[feat]) {
                this.imageInfo[feat] = {};
            }
            this.imageInfo[feat].imageGrayscaleData = imageGrayscaleData;
        },
        addImageTransform: function (feat, transform, compare) {
            if (compare) {
                if (!this.compareImageInfo[feat]) {
                    this.compareImageInfo[feat] = {};
                }
                this.compareImageInfo[feat].transform = transform;
            }
            else {
                if (!this.imageInfo[feat]) {
                    this.imageInfo[feat] = {};
                }
                this.imageInfo[feat].transform = transform;
            }
        },
        /**
         * Saves the Uint8ClampedArray image data for an image feature, both for the
         * raw image, and for the image with an applied saliency mask if there is
         * saliency information for the image feature.
         */
        setImageDatum: function (context, width, height, feat, compare) {
            if (!width || !height) {
                return;
            }
            var contextData = context.getImageData(0, 0, width, height);
            var imageData = Uint8ClampedArray.from(contextData.data);
            this.addImageData(feat, imageData, compare);
            if (!this.saliency || !this.showSaliency || !this.saliency[feat] ||
                compare) {
                return;
            }
            // Grayscale the image for later use with a saliency mask.
            var salData = Uint8ClampedArray.from(imageData);
            for (var i = 0; i < imageData.length; i += 4) {
                // Average pixel color value for grayscaling the pixel.
                var avg = (imageData[i] + imageData[i + 1] + imageData[i + 2]) / 3;
                salData[i] = avg;
                salData[i + 1] = avg;
                salData[i + 2] = avg;
            }
            this.addImageGrayscaleData(feat, salData);
        },
        /** Updates image data pixels based on windowing parameters. */
        contrastImage: function (d, windowWidth, windowCenter) {
            // See https://www.dabsoft.ch/dicom/3/C.11.2.1.2/ for algorithm description.
            var contrastScale = d3.scaleLinear()
                .domain([
                windowCenter - .5 - (windowWidth / 2),
                windowCenter - .5 + ((windowWidth - 1) / 2)
            ])
                .clamp(true)
                .range([0, 255]);
            for (var i = 0; i < d.length; i++) {
                // Skip alpha channel.
                if (i % 4 !== 3) {
                    d[i] = contrastScale(d[i]);
                }
            }
        },
        /**
         * Returns true if the saliency value provided is higher than the
         * saliency cutoff, under which saliency values aren't displayed.
         */
        showSaliencyForValue: function (salVal) {
            var salExtremeToCompare = salVal >= 0 ? this.maxSal : this.minSal;
            return Math.abs(salVal) >=
                (Math.abs(salExtremeToCompare) * this.saliencyCutoff / 100.);
        },
        /** Returns the color to display for a given saliency value. */
        getColorForSaliency: function (salVal) {
            if (!this.showSaliencyForValue(salVal)) {
                return neutralSaliencyColor;
            }
            else {
                return this.colors(salVal);
            }
        },
        /** Adjusts image data pixels to overlay the saliency mask. */
        addSaliencyToImage: function (d, sal) {
            // If provided an array of SaliencyValue then get the correct saliency map
            // for the currently selected sequence number.
            if (Array.isArray(sal) && sal.length > 0 && Array.isArray(sal[0])) {
                sal = sal[this.seqNumber];
            }
            // Grayscale the image and combine the colored pixels based on saliency at
            // that pixel. This loop examines each pixel, each of which consists of 4
            // values (r, g, b, a) in the data array.
            // Calculate the adjustment factor in order to index into the correct
            // saliency value for each pixel given that the image may have been scaled,
            // meaning that the canvas image data array would not have a one-to-one
            // correspondence with the per-original-image-pixel saliency data.
            var salScaleAdjustment = 1 / Math.pow(this.imageScalePercentage / 100, 2);
            for (var i = 0; i < d.length; i += 4) {
                // Get the saliency value for the pixel. If the saliency map contains only
                // a single value for the image, use it for all pixels.
                var salVal = 0;
                var salIndex = Math.floor(i / 4 * salScaleAdjustment);
                if (Array.isArray(sal)) {
                    if (sal.length > salIndex) {
                        salVal = sal[salIndex];
                    }
                    else {
                        salVal = 0;
                    }
                }
                else {
                    salVal = sal;
                }
                // Blend the grayscale pixel with the saliency mask color for the pixel
                // to get the final r, g, b values for the pixel.
                var ratioToSaliencyExtreme = this.showSaliencyForValue(salVal) ?
                    (salVal >= 0 ? this.maxSal === 0 ? 0 : salVal / this.maxSal :
                        salVal / this.minSal) :
                    0;
                var blendRatio = IMG_SALIENCY_MAX_COLOR_RATIO * ratioToSaliencyExtreme;
                var _a = d3.rgb(salVal > 0 ? posSaliencyColor : negSaliencyColor), r = _a.r, g = _a.g, b = _a.b;
                d[i] = d[i] * (1 - blendRatio) + r * blendRatio;
                d[i + 1] = d[i + 1] * (1 - blendRatio) + g * blendRatio;
                d[i + 2] = d[i + 2] * (1 - blendRatio) + b * blendRatio;
            }
        },
        renderImageOnCanvas: function (context, width, height, feat, compare) {
            if (!width || !height) {
                return;
            }
            // Set the correct image data array.
            var id = context.getImageData(0, 0, width, height);
            if (compare) {
                id.data.set(this.compareImageInfo[feat].imageData);
            }
            else {
                id.data.set(this.saliency && this.showSaliency && this.saliency[feat] ?
                    this.imageInfo[feat].imageGrayscaleData :
                    this.imageInfo[feat].imageData);
            }
            // Adjust the contrast and add saliency mask if neccessary.
            if (this.windowWidth !== DEFAULT_WINDOW_WIDTH ||
                this.windowCenter !== DEFAULT_WINDOW_CENTER) {
                this.contrastImage(id.data, this.windowWidth, this.windowCenter);
            }
            if (!compare && this.saliency && this.showSaliency && this.saliency[feat]) {
                this.addSaliencyToImage(id.data, this.saliency[feat]);
            }
            // Draw the image data to an in-memory canvas and then draw that to the
            // on-screen canvas as an image. This allows for the zoom/translate logic
            // to function correctly. If the image data is directly applied to the
            // on-screen canvas then the zoom/translate does not apply correctly.
            var inMemoryCanvas = document.createElement('canvas');
            inMemoryCanvas.width = width;
            inMemoryCanvas.height = height;
            var inMemoryContext = inMemoryCanvas.getContext('2d');
            inMemoryContext.putImageData(id, 0, 0);
            context.clearRect(0, 0, width, height);
            context.drawImage(inMemoryCanvas, 0, 0);
        },
        showSalCheckboxChange: function () {
            this.showSaliency = this.$.salCheckbox.checked;
        },
        /**
         * If any image settings changes then call onload for each image to redraw the
         * image on the canvas.
         */
        updateImages: function () {
            for (var feat in this.imageInfo) {
                if (this.imageInfo.hasOwnProperty(feat)) {
                    this.imageInfo[feat].onload(feat, this.imageInfo[feat].imageElement);
                }
            }
        },
        shouldShowImageControls: function (hasImage, allowImageControls) {
            return hasImage && allowImageControls;
        },
        /**
         * Only enable the add feature button when a name has been specified.
         */
        shouldEnableAddFeature: function (featureName) {
            return featureName.length > 0;
        },
        getDeleteValueButtonClass: function (readonly, showDeleteValueButton) {
            return readonly || !showDeleteValueButton ? 'delete-value-button delete-value-button-hidden' : 'delete-value-button';
        },
        getDeleteFeatureButtonClass: function (readonly) {
            return readonly ? 'hide-controls' : 'delete-feature-button';
        },
        getAddValueButtonClass: function (readonly) {
            return readonly ? 'hide-controls' : 'add-value-button';
        },
        getAddFeatureButtonClass: function (readonly) {
            return readonly ? 'hide-controls' : 'add-feature-button';
        },
        getUploadImageClass: function (readonly) {
            return readonly ? 'hide-controls' : 'upload-image-button';
        },
        /**
         * Decodes a list of bytes into a readable string, treating the bytes as
         * unicode char codes.
         */
        decodeBytesListToString: function (bytes) {
            // Decode strings in 16K chunks to avoid stack error with use of
            // fromCharCode.apply.
            var decodeChunkBytes = 16 * 1024;
            var res = '';
            var i = 0;
            // Decode in chunks to avoid stack error with use of fromCharCode.apply.
            for (i = 0; i < bytes.length / decodeChunkBytes; i++) {
                res += String.fromCharCode.apply(null, bytes.slice(i * decodeChunkBytes, (i + 1) * decodeChunkBytes));
            }
            res += String.fromCharCode.apply(null, bytes.slice(i * decodeChunkBytes));
            return res;
        },
    });
})(vz_example_viewer || (vz_example_viewer = {}));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidnotZXhhbXBsZS12aWV3ZXIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJ2ei1leGFtcGxlLXZpZXdlci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7Ozs7Ozs7OztnRkFhZ0Y7QUFFaEYsT0FBTyxTQUFTLE1BQU0saUNBQWlDLENBQUM7QUFDeEQsT0FBTyxPQUFPLE1BQU0sK0JBQStCLENBQUM7QUFDcEQsT0FBTyxPQUFPLE1BQU0sK0JBQStCLENBQUM7QUFDcEQsT0FBTyxXQUFXLE1BQU0sbUNBQW1DLENBQUM7QUFDNUQsT0FBTyxZQUFZLE1BQU0sb0NBQW9DLENBQUM7QUFDOUQsT0FBTyxRQUFRLE1BQU0sZ0NBQWdDLENBQUM7QUFDdEQsT0FBTyxTQUFTLE1BQU0saUNBQWlDLENBQUM7QUFDeEQsT0FBTyxTQUFTLE1BQU0saUNBQWlDLENBQUM7QUFDeEQsT0FBTyxlQUFlLE1BQU0sdUNBQXVDLENBQUM7QUFFcEUsSUFBVSxpQkFBaUIsQ0FxM0QxQjtBQXIzREQsV0FBVSxpQkFBaUI7SUFxRDNCLElBQU0sZ0JBQWdCLEdBQUcsS0FBSyxDQUFDO0lBQy9CLElBQU0sa0JBQWtCLEdBQUcsT0FBTyxDQUFDO0lBQ25DLElBQU0sNkJBQTZCLEdBQUcsU0FBUyxDQUFDO0lBQ2hELElBQU0sZUFBZSxHQUFHLEdBQUcsQ0FBQztJQUM1QixJQUFNLGdCQUFnQixHQUFHLEVBQUUsQ0FBQztJQUM1QixJQUFNLDhCQUE4QixHQUFHLElBQUksQ0FBQztJQUM1QyxJQUFNLGlCQUFpQixHQUFHLEdBQUcsQ0FBQztJQUU5Qix1Q0FBdUM7SUFDdkMsSUFBTSxnQkFBZ0IsR0FBRyxNQUFNLENBQUM7SUFDaEMsSUFBTSxnQkFBZ0IsR0FBRyxNQUFNLENBQUM7SUFDaEMsSUFBTSxvQkFBb0IsR0FBRyxTQUFTLENBQUM7SUFHdkMsSUFBTSxrQkFBa0IsR0FBRyxFQUFFLENBQUMsY0FBYyxDQUFDO0lBRTdDLDZFQUE2RTtJQUM3RSxpQkFBaUI7SUFDakIsSUFBTSxpQkFBaUIsR0FBRyw2QkFBNkIsQ0FBQztJQUV4RCw0RUFBNEU7SUFDNUUsOENBQThDO0lBQzlDLElBQU0scUJBQXFCLEdBQUcsSUFBSSxHQUFHLElBQUksR0FBRyxHQUFHLEdBQUcsQ0FBQyxDQUFDO0lBRXBELDZFQUE2RTtJQUM3RSx3RUFBd0U7SUFDeEUsSUFBTSw0QkFBNEIsR0FBRyxHQUFHLENBQUM7SUFFekMseUVBQXlFO0lBQ3pFLElBQU0scUJBQXFCLEdBQUcsNkJBQTZCLENBQUM7SUFFNUQsMENBQTBDO0lBQzFDLElBQU0sV0FBVyxHQUFxQixDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztJQUU5QyxJQUFNLG9CQUFvQixHQUFHLEdBQUcsQ0FBQztJQUNqQyxJQUFNLHFCQUFxQixHQUFHLEdBQUcsQ0FBQztJQUVsQyxPQUFPLENBQUM7UUFDTixFQUFFLEVBQUUsbUJBQW1CO1FBQ3ZCLFVBQVUsRUFBRTtZQUNWLE9BQU8sRUFBRSxFQUFDLElBQUksRUFBRSxNQUFNLEVBQUM7WUFDdkIsaUJBQWlCLEVBQUUsRUFBQyxJQUFJLEVBQUUsTUFBTSxFQUFFLFFBQVEsRUFBRSxlQUFlLEVBQUM7WUFDNUQsb0JBQW9CLEVBQUUsRUFBQyxJQUFJLEVBQUUsTUFBTSxFQUFFLFFBQVEsRUFBRSxrQkFBa0IsRUFBQztZQUNsRSxJQUFJLEVBQUUsRUFBQyxJQUFJLEVBQUUsTUFBTSxFQUFFLFFBQVEsRUFBRSx3QkFBd0IsRUFBQztZQUN4RCxRQUFRLEVBQUUsRUFBQyxJQUFJLEVBQUUsTUFBTSxFQUFFLEtBQUssRUFBRSxFQUFFLEVBQUM7WUFDbkMsa0JBQWtCLEVBQUUsRUFBQyxJQUFJLEVBQUUsTUFBTSxFQUFFLFFBQVEsRUFBRSxrQkFBa0IsRUFBQztZQUNoRSxRQUFRLEVBQUUsRUFBQyxJQUFJLEVBQUUsT0FBTyxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUM7WUFDdkMsU0FBUyxFQUFFLEVBQUMsSUFBSSxFQUFFLE1BQU0sRUFBRSxLQUFLLEVBQUUsQ0FBQyxFQUFFLFFBQVEsRUFBRSxXQUFXLEVBQUM7WUFDMUQsVUFBVSxFQUFFLE9BQU87WUFDbkIsbUJBQW1CLEVBQUUsTUFBTTtZQUMzQixZQUFZLEVBQUUsT0FBTztZQUNyQixNQUFNLEVBQUUsRUFBQyxJQUFJLEVBQUUsTUFBTSxFQUFFLEtBQUssRUFBRSxDQUFDLEVBQUM7WUFDaEMsTUFBTSxFQUFFLEVBQUMsSUFBSSxFQUFFLE1BQU0sRUFBRSxLQUFLLEVBQUUsQ0FBQyxFQUFDO1lBQ2hDLFlBQVksRUFBRSxFQUFDLElBQUksRUFBRSxPQUFPLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBQztZQUMxQyxTQUFTLEVBQUUsRUFBQyxJQUFJLEVBQUUsTUFBTSxFQUFFLEtBQUssRUFBRSxFQUFFLEVBQUM7WUFDcEMsV0FBVyxFQUFFLEVBQUMsSUFBSSxFQUFFLE1BQU0sRUFBRSxLQUFLLEVBQUUsb0JBQW9CLEVBQUM7WUFDeEQsWUFBWSxFQUFFLEVBQUMsSUFBSSxFQUFFLE1BQU0sRUFBRSxLQUFLLEVBQUUscUJBQXFCLEVBQUM7WUFDMUQsY0FBYyxFQUFFLEVBQUMsSUFBSSxFQUFFLE1BQU0sRUFBRSxLQUFLLEVBQUUsQ0FBQyxFQUFDO1lBQ3hDLFFBQVEsRUFBRSxFQUFDLElBQUksRUFBRSxPQUFPLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBQztZQUN0QyxrQkFBa0IsRUFBRSxFQUFDLElBQUksRUFBRSxPQUFPLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBQztZQUNqRCxvQkFBb0IsRUFBRSxFQUFDLElBQUksRUFBRSxNQUFNLEVBQUUsS0FBSyxFQUFFLEdBQUcsRUFBQztZQUNoRCxRQUFRLEVBQUUsRUFBQyxJQUFJLEVBQUUsTUFBTSxFQUFFLFFBQVEsRUFBRSxzQkFBc0IsRUFBQztZQUMxRCxZQUFZLEVBQUUsRUFBQyxJQUFJLEVBQUUsTUFBTSxFQUFFLFFBQVEsRUFBRSw0Q0FBNEMsRUFBQztZQUNwRixXQUFXLEVBQUUsRUFBQyxJQUFJLEVBQUUsTUFBTSxFQUFFLFFBQVEsRUFBRSx5QkFBeUIsRUFBQztZQUNoRSxlQUFlLEVBQUUsRUFBQyxJQUFJLEVBQUUsTUFBTSxFQUFFLFFBQVEsRUFBRSxrREFBa0QsRUFBQztZQUM3RixZQUFZLEVBQUUsRUFBQyxJQUFJLEVBQUUsTUFBTSxFQUFFLFFBQVEsRUFBRSxrQ0FBa0MsRUFBQztZQUMxRSxNQUFNLEVBQUUsRUFBQyxJQUFJLEVBQUUsTUFBTSxFQUFFLFFBQVEsRUFBRSxxQkFBcUIsRUFBRSxRQUFRLEVBQUUsY0FBYyxFQUFDO1lBQ2pGLFdBQVcsRUFBRSxFQUFDLElBQUksRUFBRSxNQUFNLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBQztZQUMxQyxrQkFBa0IsRUFBRSxFQUFDLElBQUksRUFBRSxNQUFNLEVBQUUsS0FBSyxFQUFFLEVBQUUsRUFBRSxNQUFNLEVBQUUsSUFBSSxFQUFDO1lBQzNELG9CQUFvQixFQUFFLEVBQUMsSUFBSSxFQUFFLE1BQU0sRUFBRSxRQUFRLEVBQUUscUVBQXFFLEVBQUM7WUFDckgsdUJBQXVCLEVBQUUsRUFBQyxJQUFJLEVBQUUsTUFBTSxFQUFFLFFBQVEsRUFBRSx3RUFBd0UsRUFBQztZQUMzSCxrQkFBa0IsRUFBRSxNQUFNO1lBQzFCLHdCQUF3QixFQUFFLE1BQU07WUFDaEMsZ0JBQWdCLEVBQUUsTUFBTTtZQUN4QixxQkFBcUIsRUFBRSxFQUFDLElBQUksRUFBRSxPQUFPLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBQztZQUNwRCxnQkFBZ0IsRUFBRSxFQUFDLElBQUksRUFBRSxNQUFNLEVBQUUsS0FBSyxFQUFFLEVBQUUsRUFBQztZQUMzQyxpQkFBaUIsRUFBRSxFQUFDLElBQUksRUFBRSxPQUFPLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBQztZQUNoRCxTQUFTLEVBQUUsRUFBQyxJQUFJLEVBQUUsTUFBTSxFQUFFLEtBQUssRUFBRSxDQUFDLEVBQUM7WUFDbkMsV0FBVyxFQUFFLEVBQUMsSUFBSSxFQUFFLE1BQU0sRUFBRSxRQUFRLEVBQUUsK0JBQStCLEVBQUM7WUFDdEUsY0FBYyxFQUFFLEVBQUMsSUFBSSxFQUFFLE1BQU0sRUFBQztZQUM5QixlQUFlLEVBQUU7Z0JBQ2YsSUFBSSxFQUFFLE1BQU07Z0JBQ1osUUFBUSxFQUFFLDZCQUE2QjtnQkFDdkMsUUFBUSxFQUFFLG1CQUFtQjthQUM5QjtZQUNELGtCQUFrQixFQUFFO2dCQUNsQixJQUFJLEVBQUUsTUFBTTtnQkFDWixRQUFRLEVBQUUsZ0NBQWdDO2dCQUMxQyxRQUFRLEVBQUUsbUJBQW1CO2FBQzlCO1lBQ0QsV0FBVyxFQUFFLE9BQU87WUFDcEIsZ0JBQWdCLEVBQUUsRUFBQyxJQUFJLEVBQUUsTUFBTSxFQUFFLEtBQUssRUFBRSxFQUFFLEVBQUM7WUFDM0MsWUFBWSxFQUFFLE1BQU07U0FDckI7UUFDRCxTQUFTLEVBQUU7WUFDVCxvRkFBb0Y7WUFDcEYseUZBQXlGO1NBQzFGO1FBRUQsVUFBVSxFQUFFLFVBQVMsUUFBZ0IsRUFBRSxpQkFBMEI7WUFDL0QsT0FBTyxJQUFJLENBQUMsaUJBQWlCO2dCQUN6QixJQUFJLENBQUMsZUFBZSxDQUFDLFFBQVEsQ0FBQyxJQUFJLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQztRQUM5RCxDQUFDO1FBRUQsYUFBYSxFQUFFO1lBQ2IsSUFBSSxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxPQUFPLENBQUMsaUJBQWlCLENBQUMsQ0FBQztRQUM3RSxDQUFDO1FBRUQsaUVBQWlFO1FBQ2pFLGdCQUFnQixFQUFFO1lBQ2hCLElBQUksQ0FBQyxrQkFBa0IsQ0FDbkIsSUFBSSxDQUFDLG9CQUFvQixFQUFFLGVBQWUsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO1FBQ3BFLENBQUM7UUFFRCwwREFBMEQ7UUFDMUQsa0JBQWtCLEVBQUUsVUFBUyxHQUFXO1lBQ3RDLE9BQU8sSUFBSyxNQUFjLENBQUMsV0FBVyxFQUFFLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQ3ZELENBQUM7UUFFRCxrQkFBa0IsRUFBRSxVQUNoQixlQUF1QixFQUN2QixZQUE0RDtZQUM5RCx5RUFBeUU7WUFDekUsb0VBQW9FO1lBQ3BFLElBQUksSUFBSSxDQUFDLFlBQVksRUFBRTtnQkFDckIsT0FBTzthQUNSO1lBQ0QsSUFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLHdCQUF3QixDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDO1lBQ25FLElBQUksQ0FBQyxPQUFPLEdBQUcsWUFBWSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ3JDLENBQUM7UUFFRCw2REFBNkQ7UUFDN0QsV0FBVyxFQUFFLFVBQVMsT0FBZ0M7WUFDcEQsc0VBQXNFO1lBQ3RFLElBQUksQ0FBQyxTQUFTLEdBQUcsRUFBRSxDQUFDO1lBQ3BCLElBQUksQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDO1lBRXRCLElBQUksT0FBTyxJQUFJLElBQUksRUFBRTtnQkFDbkIsT0FBTyxJQUFJLEdBQUcsQ0FBc0IsRUFBRSxDQUFDLENBQUM7YUFDekM7WUFDRCxJQUFJLE9BQU8sWUFBWSxPQUFPLEVBQUU7Z0JBQzlCLElBQUksQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDO2dCQUN4QixJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRSxFQUFFO29CQUMxQixPQUFPLENBQUMsV0FBVyxDQUFDLElBQUksUUFBUSxFQUFFLENBQUMsQ0FBQztpQkFDckM7Z0JBQ0QsT0FBTyxPQUFPLENBQUMsV0FBVyxFQUFHLENBQUMsYUFBYSxFQUFFLENBQUM7YUFDL0M7aUJBQU07Z0JBQ0wsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUM7Z0JBQ3ZCLElBQUksQ0FBQyxPQUFPLENBQUMsVUFBVSxFQUFFLEVBQUU7b0JBQ3pCLE9BQU8sQ0FBQyxVQUFVLENBQUMsSUFBSSxRQUFRLEVBQUUsQ0FBQyxDQUFDO2lCQUNwQztnQkFDRCxPQUFPLE9BQU8sQ0FBQyxVQUFVLEVBQUcsQ0FBQyxhQUFhLEVBQUUsQ0FBQzthQUM5QztRQUNILENBQUM7UUFFRDs7O1dBR0c7UUFDSCxlQUFlLEVBQUUsVUFBUyxRQUFhLEVBQUUsZUFBb0I7WUFDM0QsSUFBTSxZQUFZLEdBQXFCLEVBQUUsQ0FBQztZQUMxQyxJQUFNLFVBQVUsR0FBNkIsRUFBRSxDQUFDO1lBQ2hELElBQUksRUFBRSxHQUFHLFFBQVEsQ0FBQyxJQUFJLEVBQUUsQ0FBQztZQUN6QixJQUFJLEVBQUUsRUFBRTtnQkFDTixJQUFJLElBQUksR0FBRyxFQUFFLENBQUMsSUFBSSxFQUFFLENBQUM7Z0JBQ3JCLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFO29CQUNqQixZQUFZLENBQUMsSUFBSSxDQUNiLEVBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxLQUFLLEVBQUUsT0FBTyxFQUFFLFFBQVEsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBRSxFQUFDLENBQUMsQ0FBQztvQkFDNUQsVUFBVSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxJQUFJLENBQUM7b0JBQzlCLElBQUksR0FBRyxFQUFFLENBQUMsSUFBSSxFQUFFLENBQUM7aUJBQ2xCO2FBQ0Y7WUFDRCxFQUFFLEdBQUcsZUFBZSxDQUFDLElBQUksRUFBRSxDQUFDO1lBQzVCLElBQUksRUFBRSxFQUFFO2dCQUNOLElBQUksSUFBSSxHQUFHLEVBQUUsQ0FBQyxJQUFJLEVBQUUsQ0FBQztnQkFDckIsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUU7b0JBQ2pCLElBQUksSUFBSSxDQUFDLEtBQUssSUFBSSxVQUFVLEVBQUU7d0JBQzVCLElBQUksR0FBRyxFQUFFLENBQUMsSUFBSSxFQUFFLENBQUM7d0JBQ2pCLFNBQVM7cUJBQ1Y7b0JBQ0QsWUFBWSxDQUFDLElBQUksQ0FDYixFQUFDLElBQUksRUFBRSxJQUFJLENBQUMsS0FBSyxFQUFFLE9BQU8sRUFBRSxlQUFlLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUUsRUFBQyxDQUFDLENBQUM7b0JBQ25FLFVBQVUsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsSUFBSSxDQUFDO29CQUM5QixJQUFJLEdBQUcsRUFBRSxDQUFDLElBQUksRUFBRSxDQUFDO2lCQUNsQjthQUNGO1lBQ0QsT0FBTyxZQUFZLENBQUM7UUFDdEIsQ0FBQztRQUVELDZEQUE2RDtRQUM3RCxjQUFjLEVBQUUsVUFBUyxPQUFnQztZQUN2RCxJQUFJLE9BQU8sSUFBSSxJQUFJLElBQUksT0FBTyxZQUFZLE9BQU8sRUFBRTtnQkFDakQsT0FBTyxJQUFJLEdBQUcsQ0FBc0IsRUFBRSxDQUFDLENBQUM7YUFDekM7WUFDRCxPQUFRLElBQUksQ0FBQyxPQUEyQjtpQkFDbkMsZUFBZSxFQUFHLENBQUMsaUJBQWlCLEVBQUUsQ0FBQztRQUM5QyxDQUFDO1FBRUQsdUJBQXVCLEVBQUUsVUFBUyxXQUE2QixFQUMzRCxXQUFtQixFQUFFLFFBQXFCO1lBRHJCLGlCQXlDeEI7WUF2Q0MsSUFBSSxRQUFRLEdBQUcsV0FBVyxDQUFDO1lBQzNCLElBQU0sUUFBUSxHQUFHLFFBQVEsSUFBSSxNQUFNLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7WUFDOUQsdUVBQXVFO1lBQ3ZFLDBFQUEwRTtZQUMxRSxXQUFXO1lBQ1gsSUFBTSxjQUFjLEdBQUcsUUFBUSxDQUFDLENBQUMsQ0FDNUIsTUFBTSxDQUFDLE1BQU0sT0FBYixNQUFNLEdBQVEsRUFBRSxTQUFLLE1BQU0sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsR0FBRyxDQUM1QyxVQUFBLElBQUk7O2dCQUFJLE9BQUEsVUFBRSxHQUFDLElBQUksSUFBRyxPQUFPLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxRQUFRLENBQUMsQ0FBQztvQkFDMUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFXLENBQUMsQ0FBQyxDQUFDO29CQUNuQyxRQUFRLENBQUMsSUFBSSxDQUFtQixDQUFDLE1BQU0sQ0FBQyxVQUFDLEtBQUssRUFBRSxHQUFHO3dCQUNoRCxPQUFBLElBQUksQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUM7b0JBQS9CLENBQStCLEVBQUcsQ0FBQyxDQUFDLEtBQUU7WUFIN0MsQ0FHNkMsQ0FBQyxHQUFFLENBQUM7Z0JBQ2hELEVBQUUsQ0FBQztZQUVuQixJQUFJLFdBQVcsSUFBSSxFQUFFLEVBQUU7Z0JBQ3JCLElBQU0sSUFBRSxHQUFHLElBQUksTUFBTSxDQUFDLFdBQVcsRUFBRSxHQUFHLENBQUMsQ0FBQztnQkFDeEMsUUFBUSxHQUFHLFdBQVcsQ0FBQyxNQUFNLENBQUMsVUFBQSxPQUFPLElBQUksT0FBQSxJQUFFLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsRUFBckIsQ0FBcUIsQ0FBQyxDQUFDO2FBQ2pFO1lBQ0QsSUFBTSxNQUFNLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxVQUFDLENBQUMsRUFBRSxDQUFDO2dCQUNoQyxJQUFJLEtBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUU7b0JBQ2pELE9BQU8sQ0FBQyxDQUFDLENBQUM7aUJBQ1g7cUJBQU0sSUFBSSxLQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFO29CQUN4RCxPQUFPLENBQUMsQ0FBQztpQkFDVjtxQkFBTTtvQkFDTCxJQUFJLFFBQVEsRUFBRTt3QkFDWixJQUFJLENBQUMsQ0FBQyxJQUFJLElBQUksUUFBUSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxJQUFJLFFBQVEsQ0FBQyxFQUFFOzRCQUMvQyxPQUFPLENBQUMsQ0FBQyxDQUFDO3lCQUNYOzZCQUFNLElBQUksQ0FBQyxDQUFDLElBQUksSUFBSSxRQUFRLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLElBQUksUUFBUSxDQUFDLEVBQUU7NEJBQ3RELE9BQU8sQ0FBQyxDQUFDO3lCQUNWOzZCQUFNOzRCQUNMLElBQU0sSUFBSSxHQUFHLGNBQWMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsY0FBYyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQzs0QkFDN0QsSUFBSSxJQUFJLElBQUksQ0FBQyxFQUFFO2dDQUNiLE9BQU8sSUFBSSxDQUFDOzZCQUNiO3lCQUNGO3FCQUNGO29CQUNELE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO2lCQUNyQztZQUNILENBQUMsQ0FBQyxDQUFDO1lBQ0gsT0FBTyxNQUFNLENBQUM7UUFDaEIsQ0FBQztRQUVEOzs7V0FHRztRQUNILGVBQWUsRUFBRTtZQUNmLElBQUksR0FBRyxHQUFHLENBQUMsQ0FBQyxDQUFDO1lBQ2IsS0FBbUIsVUFBb0IsRUFBcEIsS0FBQSxJQUFJLENBQUMsZUFBZSxFQUFwQixjQUFvQixFQUFwQixJQUFvQixFQUFFO2dCQUFwQyxJQUFNLElBQUksU0FBQTtnQkFDYixJQUFNLElBQUksR0FBRyxJQUFJLENBQUMsT0FBc0IsQ0FBQztnQkFDekMsSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDLE1BQU0sR0FBRyxDQUFDLEdBQUcsR0FBRyxFQUFFO29CQUNsRCxHQUFHLEdBQUcsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7aUJBQ3hDO2FBQ0Y7WUFDRCxPQUFPLEdBQUcsQ0FBQztRQUNiLENBQUM7UUFFRCxnQkFBZ0IsRUFBRTtZQUNoQixJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLENBQUM7UUFDdEQsQ0FBQztRQUVELFNBQVMsRUFBRTs7WUFDVCwwQ0FBa0UsRUFBakUsbUJBQVcsRUFBRSxtQkFBVyxDQUEwQztZQUVuRSxPQUFPLEVBQUUsQ0FBQyxXQUFXLEVBQVU7aUJBQzFCLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztpQkFDckMsV0FBVyxDQUFDLGtCQUFrQixDQUFDO2lCQUMvQixLQUFLLENBQUMsSUFBSSxDQUFDO2lCQUNYLEtBQUssQ0FBQztnQkFDTCxnQkFBZ0IsRUFBRSxvQkFBb0I7Z0JBQ3RDLGdCQUFnQjthQUNqQixDQUFDLENBQUM7UUFDVCxDQUFDO1FBRUQsU0FBUyxFQUFFLFVBQVMsS0FBYTtZQUMvQixPQUFPLEVBQUUsQ0FBQyxTQUFTLENBQ2pCLE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLGdCQUFnQixDQUFDLEtBQUssQ0FBUSxDQUFDLENBQUM7UUFDM0QsQ0FBQztRQUVELFlBQVksRUFBRTtZQUFBLGlCQW1EYjtZQWxEQyxJQUFJLENBQUMsSUFBSSxDQUFDLG9CQUFvQixJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVE7Z0JBQzVDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLE1BQU0sS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFO2dCQUMzRCxPQUFPO2FBQ1I7WUFFRCxzRUFBc0U7WUFDdEUsa0VBQWtFO1lBQ2xFLG9FQUFvRTtZQUNwRSxZQUFZO1lBQ1osSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLGtCQUFrQixDQUFDLENBQUMsSUFBSSxFQUFFO2dCQUN6QyxDQUFDLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsTUFBTSxDQUFDLEVBQUU7Z0JBQzNFLHFCQUFxQixDQUFDLGNBQU0sT0FBQSxLQUFJLENBQUMsWUFBWSxFQUFFLEVBQW5CLENBQW1CLENBQUMsQ0FBQztnQkFDakQsT0FBTzthQUNSO1lBRUQsOENBQThDO1lBQzlDLElBQUksQ0FBQyxTQUFTLENBQUMsYUFBYSxDQUFDLENBQUMsS0FBSyxDQUFDLFlBQVksRUFBRSxvQkFBb0IsQ0FBQyxDQUFDO29DQUc3RCxJQUFJO2dCQUNiLElBQU0sR0FBRyxHQUFHLE9BQUssUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQWtCLENBQUM7Z0JBQ3RELHdFQUF3RTtnQkFDeEUsSUFBSSxDQUFDLEdBQUcsRUFBRTs7aUJBRVQ7Z0JBQ0QsSUFBTSxPQUFPLEdBQUcsS0FBSyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO29CQUNoQyxVQUFDLENBQUssRUFBRSxDQUFTLElBQUssT0FBQSxLQUFJLENBQUMsbUJBQW1CLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQWhDLENBQWdDLENBQUMsQ0FBQztvQkFDeEQsY0FBTSxPQUFBLEtBQUksQ0FBQyxtQkFBbUIsQ0FBQyxHQUFHLENBQUMsRUFBN0IsQ0FBNkIsQ0FBQztnQkFDeEMsT0FBSyxTQUFTLENBQ1IsV0FBUyxPQUFLLGVBQWUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLGdCQUFhLENBQUM7cUJBQ3ZELEtBQUssQ0FBQyxZQUFZLEVBQ2YsT0FBSyxZQUFZLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsY0FBTSxPQUFBLG9CQUFvQixFQUFwQixDQUFvQixDQUFDLENBQUM7Z0JBRWxFLHdFQUF3RTtnQkFDeEUseURBQXlEO2dCQUN6RCxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEVBQUU7b0JBQ3RCLElBQU0sUUFBUSxHQUFHLEdBQW9CLENBQUM7b0JBQ3RDLElBQU0sVUFBVSxHQUFHLE9BQUssU0FBUyxDQUMvQixrQkFBZ0IsT0FBSyxlQUFlLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxnQkFBYSxDQUFDLENBQUM7b0JBQ2hFLElBQUksZ0JBQWMsR0FBRyxDQUFDLENBQUM7b0JBQ3ZCLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxRQUFRLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO3dCQUN4QyxJQUFJLElBQUksQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxnQkFBYyxDQUFDLEVBQUU7NEJBQ3BELGdCQUFjLEdBQUcsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO3lCQUM5QjtxQkFDRjtvQkFDRCxVQUFVLENBQUMsS0FBSyxDQUFDLFlBQVksRUFBRSxPQUFLLFlBQVksQ0FBQyxDQUFDO3dCQUM5QyxjQUFNLE9BQUEsS0FBSSxDQUFDLG1CQUFtQixDQUFDLGdCQUFjLENBQUMsRUFBeEMsQ0FBd0MsQ0FBQyxDQUFDO3dCQUNoRCxjQUFNLE9BQUEsb0JBQW9CLEVBQXBCLENBQW9CLENBQUMsQ0FBQztpQkFDakM7WUFDSCxDQUFDOztZQWhDRCx3RUFBd0U7WUFDeEUsaUNBQWlDO1lBQ2pDLEtBQW1CLFVBQXlCLEVBQXpCLEtBQUEsSUFBSSxDQUFDLG9CQUFvQixFQUF6QixjQUF5QixFQUF6QixJQUF5QjtnQkFBdkMsSUFBTSxJQUFJLFNBQUE7d0JBQUosSUFBSTthQThCZDtRQUNILENBQUM7UUFFRDs7O1dBR0c7UUFDSCxTQUFTLEVBQUU7WUFDVCxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDckIsQ0FBQztRQUVELFdBQVcsRUFBRTtZQUFBLGlCQStCWjtZQTlCQyxJQUFJLENBQUMsSUFBSSxDQUFDLGVBQWUsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRO2dCQUN2QyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxNQUFNLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRTtnQkFDM0QsT0FBTzthQUNSO1lBQ0Qsc0VBQXNFO1lBQ3RFLHdFQUF3RTtZQUN4RSwyQkFBMkI7WUFDM0IsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQyxDQUFDLElBQUksRUFBRSxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsTUFBTSxFQUFFO2dCQUN2RSxxQkFBcUIsQ0FBQyxjQUFNLE9BQUEsS0FBSSxDQUFDLFdBQVcsRUFBRSxFQUFsQixDQUFrQixDQUFDLENBQUM7Z0JBQ2hELE9BQU87YUFDUjtvQ0FJVSxJQUFJO2dCQUNiLElBQU0sSUFBSSxHQUFvQixPQUFLLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFvQixDQUFDO2dCQUMxRSx3RUFBd0U7Z0JBQ3hFLElBQUksQ0FBQyxJQUFJLEVBQUU7O2lCQUVWO2dCQUNELElBQU0sR0FBRyxHQUFHLElBQUksQ0FBQyxPQUFLLFNBQVMsQ0FBQyxDQUFDO2dCQUVqQyxJQUFNLE9BQU8sR0FBRyxLQUFLLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7b0JBQ2hDLFVBQUMsQ0FBSyxFQUFFLENBQVMsSUFBSyxPQUFBLEtBQUksQ0FBQyxtQkFBbUIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBaEMsQ0FBZ0MsQ0FBQyxDQUFDO29CQUN4RCxjQUFNLE9BQUEsS0FBSSxDQUFDLG1CQUFtQixDQUFDLEdBQUcsQ0FBQyxFQUE3QixDQUE2QixDQUFDO2dCQUV4QyxPQUFLLFNBQVMsQ0FDUixNQUFJLE9BQUssZUFBZSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBUSxDQUFDO3FCQUM3QyxLQUFLLENBQUMsT0FBTyxFQUFFLE9BQUssWUFBWSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLGNBQU0sT0FBQSxPQUFPLEVBQVAsQ0FBTyxDQUFDLENBQUM7WUFDbkUsQ0FBQzs7WUFqQkQsd0VBQXdFO1lBQ3hFLGlFQUFpRTtZQUNqRSxLQUFtQixVQUFvQixFQUFwQixLQUFBLElBQUksQ0FBQyxlQUFlLEVBQXBCLGNBQW9CLEVBQXBCLElBQW9CO2dCQUFsQyxJQUFNLElBQUksU0FBQTt3QkFBSixJQUFJO2FBZWQ7UUFDSCxDQUFDO1FBRUQ7OztXQUdHO1FBQ0gsaUJBQWlCLEVBQUUsVUFBUyxRQUFxQjtZQUMvQyxJQUFJLEdBQUcsR0FBRyxRQUFRLENBQUM7WUFDbkIsSUFBSSxHQUFHLEdBQUcsQ0FBQyxRQUFRLENBQUM7WUFFcEIsSUFBTSxlQUFlLEdBQUcsVUFBQyxVQUF5QztnQkFDaEUsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQyxFQUFFO29CQUM3QixLQUFnQixVQUFVLEVBQVYseUJBQVUsRUFBVix3QkFBVSxFQUFWLElBQVUsRUFBRTt3QkFBdkIsSUFBTSxDQUFDLG1CQUFBO3dCQUNWLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQztxQkFDcEI7aUJBQ0Y7cUJBQU07b0JBQ0wsSUFBSSxVQUFVLEdBQUcsR0FBRyxFQUFFO3dCQUNwQixHQUFHLEdBQUcsVUFBVSxDQUFDO3FCQUNsQjtvQkFDRCxJQUFJLFVBQVUsR0FBRyxHQUFHLEVBQUU7d0JBQ3BCLEdBQUcsR0FBRyxVQUFVLENBQUM7cUJBQ2xCO2lCQUNGO1lBQ0gsQ0FBQyxDQUFDO1lBQ0YsS0FBSyxJQUFNLElBQUksSUFBSSxRQUFRLEVBQUU7Z0JBQzNCLElBQUksUUFBUSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsRUFBRTtvQkFDakMsZUFBZSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO2lCQUNqQzthQUNGO1lBQ0QsR0FBRyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxHQUFHLGlCQUFpQixDQUFDO1lBQzNDLEdBQUcsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsR0FBRyxpQkFBaUIsQ0FBQztZQUMzQyxPQUFPLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBQ3BCLENBQUM7UUFFRDs7O1dBR0c7UUFDSCxnQkFBZ0IsRUFBRSxVQUNkLE9BQWUsRUFBRSxTQUFtQixFQUNwQyxPQUFpQixFQUFFLGFBQXVCO1lBRjVCLGlCQXNCakI7WUFuQkMsSUFBTSxJQUFJLEdBQUcsYUFBYSxDQUFDLENBQUM7Z0JBQzFCLElBQUksQ0FBQyxlQUFlLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7Z0JBQ25DLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQzdCLElBQUksQ0FBQyxJQUFJLEVBQUU7Z0JBQ1QsT0FBTyxFQUFFLENBQUM7YUFDWDtZQUNELElBQUksSUFBSSxDQUFDLFlBQVksRUFBRSxFQUFFO2dCQUN2QixJQUFJLENBQUMsU0FBUyxFQUFFO29CQUNkLElBQU0sSUFBSSxHQUFHLElBQUksQ0FBQyxZQUFZLEVBQUcsQ0FBQyxpQkFBaUIsRUFBRSxDQUFDLEdBQUcsQ0FDckQsVUFBQSxPQUFPLElBQUksT0FBQSxLQUFJLENBQUMscUJBQXFCLENBQUMsT0FBTyxFQUFFLE9BQU8sQ0FBQyxFQUE1QyxDQUE0QyxDQUFDLENBQUM7b0JBQzdELE9BQU8sSUFBSSxDQUFDO2lCQUNiO2dCQUNELE9BQU8sSUFBSSxDQUFDLFlBQVksRUFBRyxDQUFDLFlBQVksRUFBRSxDQUFDLEtBQUssRUFBRSxDQUFDO2FBQ3BEO2lCQUFNLElBQUksSUFBSSxDQUFDLFlBQVksRUFBRSxFQUFFO2dCQUM5QixPQUFPLElBQUksQ0FBQyxZQUFZLEVBQUcsQ0FBQyxZQUFZLEVBQUUsQ0FBQyxLQUFLLEVBQUUsQ0FBQzthQUNwRDtpQkFBTSxJQUFJLElBQUksQ0FBQyxZQUFZLEVBQUUsRUFBRTtnQkFDOUIsT0FBTyxJQUFJLENBQUMsWUFBWSxFQUFHLENBQUMsWUFBWSxFQUFFLENBQUMsS0FBSyxFQUFFLENBQUM7YUFDcEQ7WUFDRCxPQUFPLEVBQUUsQ0FBQztRQUNaLENBQUM7UUFFRDs7O1dBR0c7UUFDSCx1QkFBdUIsRUFBRSxVQUN2QixPQUFlLEVBQUUsU0FBbUIsRUFDcEMsT0FBaUI7WUFDbkIsT0FBTyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxFQUFFLFNBQVMsRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDbEUsQ0FBQztRQUVDLHFEQUFxRDtRQUNyRCxvQkFBb0IsRUFBRSxVQUFTLE9BQWU7WUFDNUMsT0FBTyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDM0MsQ0FBQztRQUVELDRFQUE0RTtRQUM1RSwyQkFBMkIsRUFBRSxVQUFTLE9BQWU7WUFDbkQsT0FBTyxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDbEQsQ0FBQztRQUVELDREQUE0RDtRQUM1RCx3QkFBd0IsRUFBRSxVQUFTLE9BQWU7WUFDaEQsT0FBTyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztRQUNuRCxDQUFDO1FBRUQ7OztXQUdHO1FBQ0gsK0JBQStCLEVBQUUsVUFBUyxPQUFlO1lBQ3ZELE9BQU8sSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7UUFDMUQsQ0FBQztRQUVEOzs7O1dBSUc7UUFDSCxtQkFBbUIsRUFBRSxVQUNqQixPQUFlLEVBQUUsTUFBYyxFQUFFLFNBQW1CLEVBQUUsT0FBaUIsRUFDdkUsYUFBdUI7WUFGTixpQkFnQ3BCO1lBN0JDLElBQU0sY0FBYyxHQUFHLGFBQWEsQ0FBQyxDQUFDO2dCQUNsQyxJQUFJLENBQUMsa0JBQW1CLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7Z0JBQ3ZDLElBQUksQ0FBQyxXQUFZLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQ25DLElBQUksQ0FBQyxjQUFjLEVBQUU7Z0JBQ25CLE9BQU8sRUFBRSxDQUFDO2FBQ1g7WUFDRCxJQUFNLFFBQVEsR0FBRyxjQUFjLENBQUMsY0FBYyxFQUFFLENBQUM7WUFDakQsMkVBQTJFO1lBQzNFLHdFQUF3RTtZQUN4RSxxREFBcUQ7WUFDckQsSUFBSSxDQUFDLFFBQVEsSUFBSSxRQUFRLENBQUMsTUFBTSxJQUFJLE1BQU0sRUFBRTtnQkFDMUMsT0FBTyxFQUFFLENBQUM7YUFDWDtZQUNELElBQU0sSUFBSSxHQUFHLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUM5QixJQUFJLENBQUMsSUFBSSxFQUFFO2dCQUNULE9BQU8sRUFBRSxDQUFDO2FBQ1g7WUFDRCxJQUFJLElBQUksQ0FBQyxZQUFZLEVBQUUsRUFBRTtnQkFDdkIsSUFBSSxDQUFDLFNBQVMsRUFBRTtvQkFDZCxPQUFPLElBQUksQ0FBQyxZQUFZLEVBQUcsQ0FBQyxpQkFBaUIsRUFBRSxDQUFDLEdBQUcsQ0FDL0MsVUFBQSxPQUFPLElBQUksT0FBQSxLQUFJLENBQUMscUJBQXFCLENBQUMsT0FBTyxFQUFFLE9BQU8sQ0FBQyxFQUE1QyxDQUE0QyxDQUFDLENBQUM7aUJBQzlEO2dCQUNELE9BQU8sSUFBSSxDQUFDLFlBQVksRUFBRyxDQUFDLFlBQVksRUFBRSxDQUFDO2FBQzVDO2lCQUFNLElBQUksSUFBSSxDQUFDLFlBQVksRUFBRSxFQUFFO2dCQUM5QixPQUFPLElBQUksQ0FBQyxZQUFZLEVBQUcsQ0FBQyxZQUFZLEVBQUUsQ0FBQzthQUM1QztpQkFBTSxJQUFJLElBQUksQ0FBQyxZQUFZLEVBQUUsRUFBRTtnQkFDOUIsT0FBTyxJQUFJLENBQUMsWUFBWSxFQUFHLENBQUMsWUFBWSxFQUFFLENBQUM7YUFDNUM7WUFDRCxPQUFPLEVBQUUsQ0FBQztRQUNaLENBQUM7UUFFRDs7O1dBR0c7UUFDSCwwQkFBMEIsRUFBRSxVQUN4QixPQUFlLEVBQUUsTUFBYyxFQUFHLFNBQW1CLEVBQ3JELE9BQWlCO1lBQ25CLE9BQU8sSUFBSSxDQUFDLG1CQUFtQixDQUFDLE9BQU8sRUFBRSxNQUFNLEVBQUUsU0FBUyxFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUMsQ0FBQztRQUM3RSxDQUFDO1FBRUQsOERBQThEO1FBQzlELHVCQUF1QixFQUFFLFVBQVMsT0FBZSxFQUFFLE1BQWM7WUFDL0QsT0FBTyxJQUFJLENBQUMsbUJBQW1CLENBQUMsT0FBTyxFQUFFLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3RELENBQUM7UUFFRCw4RUFBOEU7UUFDOUUsOEJBQThCLEVBQUUsVUFBUyxPQUFlLEVBQUUsTUFBYztZQUN0RSxPQUFPLElBQUksQ0FBQywwQkFBMEIsQ0FBQyxPQUFPLEVBQUUsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDN0QsQ0FBQztRQUVELHFFQUFxRTtRQUNyRSwyQkFBMkIsRUFBRSxVQUFTLE9BQWUsRUFBRSxNQUFjO1lBQ25FLE9BQU8sSUFBSSxDQUFDLG1CQUFtQixDQUFDLE9BQU8sRUFBRSxNQUFNLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO1FBQzlELENBQUM7UUFFRDs7O1dBR0c7UUFDSCxrQ0FBa0MsRUFBRSxVQUNoQyxPQUFlLEVBQUUsTUFBYztZQUNqQyxPQUFPLElBQUksQ0FBQywwQkFBMEIsQ0FBQyxPQUFPLEVBQUUsTUFBTSxDQUFDLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztRQUNyRSxDQUFDO1FBRUQ7Ozs7OztXQU1HO1FBQ0gscUJBQXFCLEVBQUUsVUFDbkIsS0FBaUIsRUFBRSxlQUF5QjtZQUM5QyxJQUFJLEtBQUssQ0FBQyxNQUFNLEdBQUcscUJBQXFCLEVBQUU7Z0JBQ3hDLE9BQU8scUJBQXFCLENBQUM7YUFDOUI7WUFDRCxPQUFPLGVBQWUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLHVCQUF1QixDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7Z0JBQ3JDLElBQUssTUFBYyxDQUFDLFdBQVcsRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUMzRSxDQUFDO1FBRUQsY0FBYyxFQUFFLFVBQVMsT0FBZTtZQUN0QyxJQUFNLElBQUksR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUN4QyxJQUFJLElBQUksRUFBRTtnQkFDUixJQUFJLElBQUksQ0FBQyxZQUFZLEVBQUUsRUFBRTtvQkFDdkIsT0FBTyxJQUFJLENBQUM7aUJBQ2I7YUFDRjtZQUNELElBQU0sT0FBTyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQzlDLElBQUksT0FBTyxFQUFFO2dCQUNYLElBQUksT0FBTyxDQUFDLGNBQWMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksRUFBRSxFQUFFO29CQUM5QyxPQUFPLElBQUksQ0FBQztpQkFDYjthQUNGO1lBQ0QsT0FBTyxLQUFLLENBQUM7UUFDZixDQUFDO1FBRUQ7OztXQUdHO1FBQ0gsWUFBWSxFQUFFLFVBQVMsT0FBZTtZQUNwQyxJQUFNLElBQUksR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUN4QyxJQUFJLElBQUksRUFBRTtnQkFDUixJQUFJLElBQUksQ0FBQyxZQUFZLEVBQUUsSUFBSSxJQUFJLENBQUMsWUFBWSxFQUFFLEVBQUU7b0JBQzlDLE9BQU8sUUFBUSxDQUFBO2lCQUNoQjthQUNGO1lBQ0QsSUFBTSxPQUFPLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUM7WUFDOUMsSUFBSSxPQUFPLEVBQUU7Z0JBQ1gsSUFBSSxPQUFPLENBQUMsY0FBYyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxFQUFFO29CQUMxQyxPQUFPLENBQUMsY0FBYyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxFQUFFLEVBQUU7b0JBQzlDLE9BQU8sUUFBUSxDQUFDO2lCQUNqQjthQUNGO1lBQ0QsT0FBTyxNQUFNLENBQUM7UUFDaEIsQ0FBQztRQUVEOzs7V0FHRztRQUNILGNBQWMsRUFBRSxVQUFTLElBQVk7WUFDbkMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUU7Z0JBQ2QsT0FBTyxJQUFJLENBQUM7YUFDYjtZQUVELElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsT0FBTyxFQUFFO2dCQUNwRCxJQUFNLFdBQVcsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7Z0JBQ3JELElBQUksV0FBVyxFQUFFO29CQUNmLE9BQU8sV0FBVyxDQUFDO2lCQUNwQjthQUNGO1lBQ0QsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLEVBQUU7Z0JBQ2xELElBQU0sV0FBVyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDcEQsSUFBSSxXQUFXLEVBQUU7b0JBQ2YsT0FBTyxXQUFXLENBQUM7aUJBQ3BCO2FBQ0Y7WUFDRCxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLFdBQVcsRUFBRTtnQkFDaEUsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUM7YUFDakQ7WUFDRCxPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7UUFFRDs7OztXQUlHO1FBQ0gsZ0JBQWdCLEVBQUUsVUFBUyxJQUFZLEVBQUUsTUFBYztZQUNyRCx3REFBd0Q7WUFDeEQsSUFBSSxPQUFPLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUN4QyxJQUFJLENBQUMsT0FBTyxFQUFFO2dCQUNaLE9BQU8sSUFBSSxDQUFDO2FBQ2I7WUFFRCx3RUFBd0U7WUFDeEUsVUFBVTtZQUNWLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEVBQUU7Z0JBQ2xCLE9BQU8sR0FBRyxPQUFPLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDO2FBQ25DO1lBRUQsSUFBTSxTQUFTLEdBQ1gsT0FBTyxDQUFDLFNBQVMsSUFBSSxPQUFPLENBQUMsU0FBUyxJQUFJLE9BQU8sQ0FBQyxTQUFTLENBQUM7WUFDaEUsT0FBTyxTQUFTLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztRQUM1QyxDQUFDO1FBRUQ7OztXQUdHO1FBQ0gsZ0JBQWdCLEVBQUUsVUFBUyxLQUFZO1lBQ3JDLElBQUksSUFBSSxHQUFHLEtBQUssQ0FBQyxNQUE2QixDQUFDO1lBQy9DLDRFQUE0RTtZQUM1RSw4QkFBOEI7WUFDOUIsT0FBTyxJQUFJLENBQUMsV0FBVyxJQUFJLElBQUksRUFBRTtnQkFDL0IsSUFBSSxDQUFDLElBQUksQ0FBQyxhQUFhLEVBQUU7b0JBQ3ZCLE1BQU0sSUFBSSxLQUFLLENBQUMseUNBQXlDLENBQUMsQ0FBQztpQkFDNUQ7Z0JBQ0QsSUFBSSxHQUFHLElBQUksQ0FBQyxhQUFvQyxDQUFDO2FBQ2xEO1lBQ0QsT0FBTztnQkFDTCxPQUFPLEVBQUUsSUFBSSxDQUFDLFdBQVc7Z0JBQ3pCLFVBQVUsRUFBRSxJQUFJLENBQUMsU0FBUztnQkFDMUIsTUFBTSxFQUFFLElBQUksQ0FBQyxVQUFVO2FBQ3hCLENBQUM7UUFDSixDQUFDO1FBRUQsNkVBQTZFO1FBQzdFLGtCQUFrQixFQUFFLFVBQVMsSUFBcUI7WUFDaEQsdUVBQXVFO1lBQ3ZFLHNCQUFzQjtZQUN0QixJQUFJLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUU7Z0JBQ3RCLE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO2FBQ3hDO2lCQUFNO2dCQUNMLElBQU0sWUFBWSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztnQkFDeEQsSUFBSSxDQUFDLFlBQVksRUFBRTtvQkFDakIsT0FBTyxTQUFTLENBQUM7aUJBQ2xCO2dCQUNELElBQU0sV0FBVyxHQUFHLFlBQVksQ0FBQyxjQUFjLEVBQUUsQ0FBQztnQkFDbEQsSUFBSSxDQUFDLFdBQVcsRUFBRTtvQkFDaEIsT0FBTyxTQUFTLENBQUM7aUJBQ2xCO2dCQUNELE9BQU8sV0FBVyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQzthQUNqQztRQUNILENBQUM7UUFFRCx5RUFBeUU7UUFDekUsb0JBQW9CLEVBQUUsVUFBUyxJQUFxQjtZQUNsRCx1RUFBdUU7WUFDdkUsc0JBQXNCO1lBQ3RCLElBQUksS0FBSyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRTtnQkFDdEIsT0FBTyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsQ0FBQzthQUNsRDtpQkFBTTtnQkFDTCxPQUFPLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLENBQUM7YUFDbEU7UUFDSCxDQUFDO1FBRUQsbURBQW1EO1FBQ25ELGdCQUFnQixFQUFFLFVBQVMsSUFBYSxFQUFFLE1BQTRCO1lBQ3BFLElBQU0sU0FBUyxHQUFHLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztZQUN0QyxJQUFNLFNBQVMsR0FBRyxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7WUFDdEMsSUFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1lBQ3RDLElBQUksU0FBUyxFQUFFO2dCQUNiLFNBQVMsQ0FBQyxZQUFZLENBQUUsTUFBbUIsQ0FBQyxDQUFDO2FBQzlDO2lCQUFNLElBQUksU0FBUyxFQUFFO2dCQUNwQixTQUFTLENBQUMsWUFBWSxDQUFFLE1BQW1CLENBQUMsQ0FBQzthQUM5QztpQkFBTSxJQUFJLFNBQVMsRUFBRTtnQkFDcEIsU0FBUyxDQUFDLFlBQVksQ0FBRSxNQUFtQixDQUFDLENBQUM7YUFDOUM7UUFDSCxDQUFDO1FBRUQ7OztXQUdHO1FBQ0gsY0FBYyxFQUFFLFVBQVMsS0FBWTtZQUNuQyxJQUFNLFlBQVksR0FBRyxLQUFLLENBQUMsTUFBMEIsQ0FBQztZQUN0RCxJQUFNLElBQUksR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDMUMsSUFBTSxJQUFJLEdBQUcsSUFBSSxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxDQUFDO1lBQzNDLElBQU0sTUFBTSxHQUFHLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUUvQyxJQUFJLElBQUksRUFBRTtnQkFDUixJQUFJLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxFQUFFO29CQUNyQyxtRUFBbUU7b0JBQ25FLDRCQUE0QjtvQkFFNUIsSUFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLGtCQUFrQixDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkQsaUVBQWlFO29CQUNqRSxNQUFNLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLEVBQVMsQ0FBQztvQkFFcEMsbUVBQW1FO29CQUNuRSx1RUFBdUU7b0JBQ3ZFLHFFQUFxRTtvQkFDckUscUVBQXFFO29CQUNyRSxzRUFBc0U7b0JBQ3RFLHNDQUFzQztvQkFDdEMsSUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUNsRSxJQUFJLFFBQVEsRUFBRTt3QkFDWixRQUFRLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLENBQUM7cUJBQ3REO2lCQUNGO3FCQUFNO29CQUNMLE1BQU0sQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDO29CQUM5QyxJQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7b0JBQ2xFLElBQUksUUFBUSxFQUFFO3dCQUNaLFFBQVEsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDO3FCQUNqRDtpQkFDRjtnQkFDRCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxFQUFFLE1BQU0sQ0FBQyxDQUFDO2dCQUNwQyxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7YUFDdkI7UUFDSCxDQUFDO1FBRUQsWUFBWSxFQUFFLFVBQVMsS0FBWTtZQUNqQyxJQUFNLFlBQVksR0FBRyxLQUFLLENBQUMsTUFBMEIsQ0FBQztZQUN0RCxJQUFNLElBQUksR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDMUMsSUFBSSxDQUFDLGtCQUFrQixHQUFHLElBQUksQ0FBQyxPQUFPLENBQUM7WUFDdkMsSUFBSSxDQUFDLHdCQUF3QixHQUFHLElBQUksQ0FBQyxVQUFVLENBQUM7WUFDaEQsSUFBSSxDQUFDLGdCQUFnQixHQUFHLElBQUksQ0FBQyxNQUFNLENBQUM7WUFDcEMsSUFBSSxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLEdBQUcsR0FBRyxDQUM3QixZQUFZLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxHQUFHO2dCQUN4QyxJQUFJLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxHQUFHLEdBQUUsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDO1lBQy9DLElBQUksQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxLQUFLLEdBQUcsQ0FDL0IsSUFBSSxDQUFDLHFCQUFxQixFQUFFLENBQUMsS0FBSztnQkFDbEMsWUFBWSxDQUFDLHFCQUFxQixFQUFFLENBQUMsS0FBSyxHQUFHLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQztZQUMxRCxJQUFJLENBQUMscUJBQXFCLEdBQUcsSUFBSSxDQUFDO1FBRXBDLENBQUM7UUFHRCxXQUFXLEVBQUUsVUFBUyxLQUFZO1lBQ2hDLElBQUksQ0FBQyxxQkFBcUIsR0FBRyxLQUFLLENBQUM7UUFDckMsQ0FBQztRQUVEOztXQUVHO1FBQ0gsYUFBYSxFQUFFLFVBQVMsS0FBWTtZQUNsQyxJQUFNLElBQUksR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDMUMsSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsRUFBRTtnQkFDckIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO2FBQ2pDO1lBQ0QsSUFBSSxJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsRUFBRTtnQkFDeEIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO2FBQ3BDO1lBQ0QsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUNyQyxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7WUFDdEIsSUFBSSxDQUFDLG9CQUFvQixFQUFFLENBQUM7UUFDOUIsQ0FBQztRQUVEOzs7V0FHRztRQUNILGlCQUFpQixFQUFFLFVBQVMsT0FBZTtZQUN6QyxJQUFJLElBQUksQ0FBQyxJQUFJLEVBQUU7Z0JBQ2IsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLEVBQUU7b0JBQ3BELE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDO2lCQUM1QztnQkFDRCxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sRUFBRTtvQkFDbEQsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUM7aUJBQzNDO2dCQUNELElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxZQUFZLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsV0FBVyxFQUFFO29CQUNoRSxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsQ0FBQztpQkFDcEQ7YUFDRjtRQUNILENBQUM7UUFFRDs7V0FFRztRQUNILFdBQVcsRUFBRSxVQUFTLEtBQVk7WUFDaEMsSUFBTSxJQUFJLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQzFDLElBQU0sSUFBSSxHQUFHLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUMzQyxJQUFNLE1BQU0sR0FBRyxJQUFJLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLENBQUM7WUFFL0MsSUFBSSxJQUFJLEVBQUU7Z0JBQ1IsSUFBSSxJQUFJLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsRUFBRTtvQkFDckMsbUVBQW1FO29CQUNuRSx1RUFBdUU7b0JBQ3ZFLHNFQUFzRTtvQkFDdEUsbUVBQW1FO29CQUNuRSxpRUFBaUU7b0JBQ2pFLGFBQWE7b0JBQ2IsSUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUNsRSxJQUFJLFFBQVEsRUFBRTt3QkFDWixRQUFRLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQyxDQUFDLENBQUM7cUJBQ3JDO2lCQUNGO2dCQUNELE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDLENBQUMsQ0FBQztnQkFDbEMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksRUFBRSxNQUFNLENBQUMsQ0FBQztnQkFDcEMsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO2dCQUN0QixJQUFJLENBQUMsb0JBQW9CLEVBQUUsQ0FBQzthQUM3QjtRQUNILENBQUM7UUFFRCxvQkFBb0IsRUFBRTtZQUNwQixJQUFJLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLElBQUksRUFBRSxDQUFDO1FBQ2pDLENBQUM7UUFFRDs7V0FFRztRQUNILFVBQVUsRUFBRSxVQUFTLEtBQVk7WUFDL0IsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUU7Z0JBQ2QsT0FBTzthQUNSO1lBRUQsSUFBTSxJQUFJLEdBQUcsSUFBSSxPQUFPLEVBQUUsQ0FBQztZQUMzQix1REFBdUQ7WUFDdkQsSUFBSSxRQUFhLENBQUM7WUFDbEIsSUFBSSxJQUFJLENBQUMsY0FBYyxLQUFLLGdCQUFnQixFQUFFO2dCQUM1QyxJQUFNLFNBQVMsR0FBYSxFQUFFLENBQUM7Z0JBQy9CLElBQU0sSUFBSSxHQUFHLElBQUksU0FBUyxFQUFFLENBQUM7Z0JBQzdCLElBQUksQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLENBQUM7Z0JBQzdCLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUM7Z0JBQ3hCLFFBQVEsR0FBRyxFQUFDLFNBQVMsRUFBRSxFQUFDLEtBQUssRUFBRSxTQUFTLEVBQUMsRUFBQyxDQUFDO2FBQzVDO2lCQUFNLElBQUksSUFBSSxDQUFDLGNBQWMsS0FBSyxrQkFBa0IsRUFBRTtnQkFDckQsSUFBTSxTQUFTLEdBQWEsRUFBRSxDQUFDO2dCQUMvQixJQUFNLE1BQU0sR0FBRyxJQUFJLFNBQVMsRUFBRSxDQUFDO2dCQUMvQixNQUFNLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxDQUFDO2dCQUMvQixJQUFJLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxDQUFDO2dCQUMxQixRQUFRLEdBQUcsRUFBQyxTQUFTLEVBQUUsRUFBQyxLQUFLLEVBQUUsU0FBUyxFQUFDLEVBQUMsQ0FBQzthQUM1QztpQkFBTTtnQkFDTCxJQUFNLFNBQVMsR0FBYSxFQUFFLENBQUM7Z0JBQy9CLElBQU0sS0FBSyxHQUFHLElBQUksU0FBUyxFQUFFLENBQUM7Z0JBQzlCLEtBQUssQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLENBQUM7Z0JBQzlCLElBQUksQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQ3pCLFFBQVEsR0FBRyxFQUFDLFNBQVMsRUFBRSxFQUFDLEtBQUssRUFBRSxTQUFTLEVBQUMsRUFBQyxDQUFDO2FBQzVDO1lBQ0QsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLGNBQWMsRUFBRSxJQUFJLENBQUMsQ0FBQztZQUM3QyxJQUFJLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxjQUFjLEVBQUUsUUFBUSxDQUFDLENBQUM7WUFDbkQsSUFBSSxDQUFDLGNBQWMsR0FBRyxFQUFFLENBQUM7WUFDekIsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO1lBQ3RCLElBQUksQ0FBQyxvQkFBb0IsRUFBRSxDQUFDO1FBQzlCLENBQUM7UUFFRDs7O1dBR0c7UUFDSCx1REFBdUQ7UUFDdkQsY0FBYyxFQUFFLFVBQVMsT0FBZSxFQUFFLFFBQWE7WUFDckQsSUFBSSxJQUFJLENBQUMsSUFBSSxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLE9BQU8sRUFBRTtnQkFDakUsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxHQUFHLFFBQVEsQ0FBQzthQUNoRDtpQkFBTSxJQUFJLElBQUksQ0FBQyxJQUFJLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxFQUFFO2dCQUN0RSxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLEdBQUcsUUFBUSxDQUFDO2FBQy9DO1FBQ0gsQ0FBQztRQUVEOztXQUVHO1FBQ0gsUUFBUSxFQUFFLFVBQVMsS0FBWTtZQUM3QixJQUFNLElBQUksR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDMUMsSUFBTSxJQUFJLEdBQUcsSUFBSSxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxDQUFDO1lBQzNDLElBQU0sTUFBTSxHQUFHLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUUvQyxJQUFJLElBQUksRUFBRTtnQkFDUixJQUFJLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxFQUFFO29CQUNyQyxNQUFNLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO2lCQUNqQjtxQkFBTTtvQkFDTCxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO2lCQUNoQjtnQkFDRCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxFQUFFLE1BQU0sQ0FBQyxDQUFDO2dCQUNwQyxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7Z0JBQ3RCLElBQUksQ0FBQyxvQkFBb0IsRUFBRSxDQUFDO2FBQzdCO1FBQ0gsQ0FBQztRQUVEOzs7V0FHRztRQUNILG9CQUFvQixFQUFFO1lBQUEsaUJBYXJCO1lBWkMseUVBQXlFO1lBQ3pFLHlFQUF5RTtZQUN6RSwyREFBMkQ7WUFDM0QseUVBQXlFO1lBQ3pFLElBQU0sSUFBSSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUM7WUFDMUIsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUM7WUFDekIsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLE9BQU8sRUFBRSxDQUFDO1lBQzdCLElBQUksQ0FBQyxZQUFZLEdBQUcsS0FBSyxDQUFDO1lBQzFCLFVBQVUsQ0FBQztnQkFDVCxLQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQztnQkFDcEIsS0FBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1lBQ3RCLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUNSLENBQUM7UUFFRCxjQUFjLEVBQUU7WUFDZCw2QkFBNkI7WUFDN0IsSUFBSSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxFQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQztZQUVyRCw0RUFBNEU7WUFDNUUseUVBQXlFO1lBQ3pFLGlDQUFpQztZQUNqQyxZQUFZLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLENBQUM7WUFDdkMsSUFBSSxDQUFDLG1CQUFtQixHQUFHLFVBQVUsQ0FDakMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsOEJBQThCLENBQUMsQ0FBQztRQUN0RSxDQUFDO1FBRUQsY0FBYyxFQUFFO1lBQ2Qsd0VBQXdFO1lBQ3hFLHNFQUFzRTtZQUN0RSxzRUFBc0U7WUFDdEUsZ0RBQWdEO1lBQ2hELElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDO1lBQ3pCLElBQUksSUFBSSxDQUFDLFVBQVUsSUFBSSxJQUFJLENBQUMsb0JBQW9CLEVBQUU7Z0JBQ2hELElBQUksQ0FBQyxvQkFBb0IsR0FBRyxJQUFJLENBQzVCLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGVBQWUsRUFBRSxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUM7YUFDdkU7aUJBQU0sSUFBSSxJQUFJLENBQUMsaUJBQWlCLEVBQUU7Z0JBQ2pDLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxJQUFJLENBQ3pCLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGVBQWUsRUFBRSxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUM7YUFDdkU7WUFDRCxJQUFJLENBQUMsWUFBWSxHQUFHLEtBQUssQ0FBQztRQUM1QixDQUFDO1FBRUQsaUJBQWlCLEVBQUUsVUFBUyxJQUFZLEVBQUUsV0FBbUI7WUFDM0QsT0FBTyxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxHQUFHLGFBQWE7Z0JBQzdDLENBQUMsV0FBVyxJQUFJLE1BQU0sQ0FBQyxDQUFDLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLHFCQUFxQixDQUFDLENBQUM7UUFDM0UsQ0FBQztRQUVELG9CQUFvQixFQUFFLFVBQVMsSUFBWSxFQUFFLFdBQW1CLEVBQzVELEtBQWM7WUFDaEIsSUFBSSxHQUFHLEdBQUcsZUFBZTtnQkFDckIsQ0FBQyxXQUFXLElBQUksTUFBTSxDQUFDLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMscUJBQXFCLENBQUMsQ0FBQztZQUN6RSxJQUFJLEtBQUssSUFBSSxJQUFJLEVBQUU7Z0JBQ2pCLElBQU0sTUFBTSxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQ2pELElBQU0sVUFBVSxHQUFHLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQzVELElBQUksS0FBSyxJQUFJLE1BQU0sQ0FBQyxNQUFNLElBQUksS0FBSyxJQUFJLFVBQVUsQ0FBQyxNQUFNO29CQUNwRCxNQUFNLENBQUMsS0FBSyxDQUFDLElBQUksVUFBVSxDQUFDLEtBQUssQ0FBQyxFQUFFO29CQUN0QyxHQUFHLElBQUksa0JBQWtCLENBQUE7aUJBQzFCO3FCQUFNO29CQUNMLEdBQUcsSUFBSSxhQUFhLENBQUM7aUJBQ3RCO2FBQ0Y7WUFDRCxPQUFPLEdBQUcsQ0FBQztRQUNiLENBQUM7UUFFRCx1QkFBdUIsRUFBRSxVQUFTLElBQVksRUFBRSxXQUFtQixFQUMvRCxTQUFpQixFQUFFLEtBQWM7WUFDbkMsSUFBSSxHQUFHLEdBQUcsZUFBZTtnQkFDckIsQ0FBQyxXQUFXLElBQUksTUFBTSxDQUFDLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMscUJBQXFCLENBQUMsQ0FBQztZQUN6RSxJQUFJLEtBQUssSUFBSSxJQUFJLEVBQUU7Z0JBQ2pCLElBQU0sTUFBTSxHQUFHLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLEVBQUUsU0FBUyxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUMvRCxJQUFNLFVBQVUsR0FBRyxJQUFJLENBQUMsMEJBQTBCLENBQUMsSUFBSSxFQUFFLFNBQVMsRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDMUUsSUFBSSxLQUFLLElBQUksTUFBTSxDQUFDLE1BQU0sSUFBSSxLQUFLLElBQUksVUFBVSxDQUFDLE1BQU07b0JBQ3BELE1BQU0sQ0FBQyxLQUFLLENBQUMsSUFBSSxVQUFVLENBQUMsS0FBSyxDQUFDLEVBQUU7b0JBQ3RDLEdBQUcsSUFBSSxrQkFBa0IsQ0FBQTtpQkFDMUI7cUJBQU07b0JBQ0wsR0FBRyxJQUFJLGFBQWEsQ0FBQztpQkFDdEI7YUFDRjtZQUNELE9BQU8sR0FBRyxDQUFDO1FBQ2IsQ0FBQztRQUVEOzs7V0FHRztRQUNILGVBQWUsRUFBRSxVQUFTLElBQVk7WUFDckMsSUFBSSxTQUFTLEdBQUcsSUFBSSxDQUFDO1lBQ3BCLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLGNBQWMsQ0FBQyxFQUFFO2dCQUMvQixTQUFTLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQzthQUN4QjtZQUNELE9BQU8sU0FBUyxDQUFDLE9BQU8sQ0FBQyxXQUFXLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDN0MsQ0FBQztRQUVELFlBQVksRUFBRSxVQUFTLFlBQW9CO1lBQ3pDLE9BQU8sWUFBWSxJQUFJLENBQUMsQ0FBQztRQUMzQixDQUFDO1FBRUQsd0JBQXdCLEVBQUUsVUFBUyxRQUFxQjtZQUN0RCxPQUFPLFFBQVEsSUFBSSxNQUFNLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7UUFDdEQsQ0FBQztRQUVELDBFQUEwRTtRQUMxRSw4QkFBOEIsWUFBQyxRQUFxQjtZQUNsRCxPQUFPLElBQUksQ0FBQyx3QkFBd0IsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO2dCQUM1QywwQkFBMEIsQ0FBQyxDQUFDO2dCQUM1Qix3QkFBd0IsQ0FBQztRQUMvQixDQUFDO1FBRUQsNERBQTREO1FBQzVELFlBQVksRUFBRTtZQUNaLEVBQUUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxFQUFFLENBQUM7WUFDekQsSUFBTSxTQUFTLEdBQUcsRUFBRSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUMvRCxJQUFNLFFBQVEsR0FBRyxTQUFTLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQztpQkFDcEMsTUFBTSxDQUFDLGdCQUFnQixDQUFDO2lCQUN4QixJQUFJLENBQUMsSUFBSSxFQUFFLHlCQUF5QixDQUFDO2lCQUNyQyxJQUFJLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQztpQkFDaEIsSUFBSSxDQUFDLElBQUksRUFBRSxJQUFJLENBQUM7aUJBQ2hCLElBQUksQ0FBQyxJQUFJLEVBQUUsTUFBTSxDQUFDO2lCQUNsQixJQUFJLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQztpQkFDaEIsSUFBSSxDQUFDLGNBQWMsRUFBRSxLQUFLLENBQUMsQ0FBQztZQUVqQyxJQUFNLFFBQVEsR0FBRyxVQUFDLEtBQWEsRUFBRSxHQUFXLEVBQUUsQ0FBUztnQkFDckQsSUFBTSxHQUFHLEdBQUcsRUFBRSxDQUFDO2dCQUNmLElBQU0sS0FBSyxHQUFHLENBQUMsR0FBRyxHQUFHLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO2dCQUN0QyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQ1YsT0FBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUU7b0JBQ2YsR0FBRyxDQUFDLElBQUksQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQztvQkFDOUIsQ0FBQyxFQUFFLENBQUM7aUJBQ1A7Z0JBQ0QsR0FBRyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDZCxPQUFPLEdBQUcsQ0FBQztZQUNiLENBQUMsQ0FBQztZQUVGLHFFQUFxRTtZQUNyRSx5Q0FBeUM7WUFDekMsSUFBTSxLQUFLLEdBQWEsRUFBRSxDQUFDO1lBQzNCLElBQUksSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7Z0JBQ25CLEtBQUssQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsQ0FBQzthQUM5QjtZQUNELEtBQUssQ0FBQyxJQUFJLENBQUMsb0JBQW9CLENBQUMsQ0FBQztZQUNqQyxJQUFJLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO2dCQUNuQixLQUFLLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLENBQUM7YUFDOUI7WUFDRCxrREFBa0Q7WUFDbEQsb0JBQW9CO1lBQ3BCLElBQU0sR0FBRyxHQUFHLFFBQVEsQ0FBQyxDQUFDLEVBQUUsR0FBRyxFQUFFLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMsVUFBQyxDQUFTO2dCQUNyRCxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDO1lBQy9CLENBQUMsQ0FBQyxDQUFDO1lBRUgsSUFBTSxTQUFTLEdBQUcsRUFBRSxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFFckMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxVQUFDLENBQVc7Z0JBQzFCLFFBQVEsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO3FCQUNsQixJQUFJLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztxQkFDcEIsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7cUJBQ3hCLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQyxDQUFDLENBQUM7WUFDakMsQ0FBQyxDQUFDLENBQUM7WUFFSCxTQUFTLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQztpQkFDbkIsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDLENBQUM7aUJBQ2IsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDLENBQUM7aUJBQ2IsSUFBSSxDQUFDLE9BQU8sRUFBRSxlQUFlLENBQUM7aUJBQzlCLElBQUksQ0FBQyxRQUFRLEVBQUUsZ0JBQWdCLENBQUM7aUJBQ2hDLEtBQUssQ0FBQyxNQUFNLEVBQUUsK0JBQStCLENBQUMsQ0FBQztZQUVwRCxJQUFNLFdBQVcsR0FDYixFQUFFLENBQUMsV0FBVyxFQUFFLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7Z0JBQ3hELENBQUMsRUFBRSxlQUFlO2FBQ25CLENBQUMsQ0FBQztZQUVQLElBQU0sVUFBVSxHQUFHLEVBQUUsQ0FBQyxVQUFVLENBQUMsV0FBVyxDQUFDLENBQUM7WUFFOUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7aUJBQ2hCLElBQUksQ0FBQyxPQUFPLEVBQUUsYUFBYSxDQUFDO2lCQUM1QixJQUFJLENBQUMsV0FBVyxFQUFFLGlCQUFlLGdCQUFnQixNQUFHLENBQUM7aUJBQ3JELElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUN4QixDQUFDO1FBRUQsT0FBTyxFQUFFLFVBQVMsSUFBWTtZQUM1QixPQUFPLGlCQUFpQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUN0QyxDQUFDO1FBRUQ7O1dBRUc7UUFDSCxXQUFXLEVBQUUsVUFBUyxJQUFZO1lBQ2hDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUMvQixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FDMUIsSUFBSSxFQUFFLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLEVBQUUsS0FBSyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBVyxDQUFDLENBQUM7UUFDbkUsQ0FBQztRQUVEOzs7V0FHRztRQUNILGtCQUFrQixFQUFFLFVBQVMsSUFBWTtZQUN2QyxJQUFJLENBQUMsbUJBQW1CLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDO1lBQ3JDLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUMxQixJQUFJLEVBQUUsSUFBSSxDQUFDLHVCQUF1QixDQUFDLElBQUksRUFBRSxLQUFLLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFXLEVBQ2xFLElBQUksQ0FBQyxDQUFDO1FBQ1osQ0FBQztRQUVEOzs7V0FHRztRQUNILGNBQWMsRUFBRSxVQUFTLElBQVksRUFBRSxNQUFjO1lBQ25ELElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUMvQixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FDMUIsSUFBSSxFQUFFLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLEVBQUUsTUFBTSxFQUFFLEtBQUssRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQVcsQ0FBQyxDQUFDO1FBQzlFLENBQUM7UUFFRDs7O1dBR0c7UUFDSCxxQkFBcUIsRUFBRSxVQUFTLElBQVksRUFBRSxNQUFjO1lBQzFELElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLENBQUM7WUFDckMsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQzFCLElBQUksRUFBRSxJQUFJLENBQUMsMEJBQTBCLENBQ25DLElBQUksRUFBRSxNQUFNLEVBQUUsS0FBSyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBVyxFQUN6QyxJQUFJLENBQUMsQ0FBQztRQUNaLENBQUM7UUFFRDs7OztXQUlHO1FBQ0gsbUJBQW1CLEVBQUUsVUFBUyxJQUFZLEVBQUUsT0FBaUI7WUFBeEMsaUJBTXBCO1lBTEMscUJBQXFCLENBQUM7Z0JBQ3BCLElBQU0sR0FBRyxHQUFHLEtBQUksQ0FBQyxFQUFFLENBQ2pCLEdBQUcsR0FBRyxLQUFJLENBQUMsVUFBVSxDQUFDLElBQUksRUFBRSxPQUFPLENBQUMsQ0FBcUIsQ0FBQztnQkFDNUQsR0FBRyxDQUFDLE1BQU0sR0FBRyxLQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxFQUFFLEdBQUcsRUFBRSxPQUFPLENBQUMsQ0FBQztZQUMxRCxDQUFDLENBQUMsQ0FBQztRQUNMLENBQUM7UUFFRCw0REFBNEQ7UUFDNUQsa0JBQWtCLEVBQUUsVUFBUyxJQUFZLEVBQUUsU0FBaUIsRUFDeEQsT0FBaUI7WUFDbkIscUVBQXFFO1lBQ3JFLHdFQUF3RTtZQUN4RSxJQUFNLFdBQVcsR0FBRyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDakQsSUFBSSxXQUFXLElBQUksSUFBSSxFQUFFO2dCQUN2QixPQUFPLElBQUksQ0FBQzthQUNiO1lBQ0QsSUFBTSxhQUFhLEdBQUcsV0FBVyxDQUFDLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQztZQUMzQyxJQUFNLFVBQVUsR0FBRyxPQUFPLENBQUMsQ0FBQztnQkFDeEIsSUFBSSxDQUFDLHVCQUF1QixDQUMxQixPQUFPLEdBQUcsYUFBYSxHQUFHLFNBQVMsRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDO2dCQUMvQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxHQUFHLGFBQWEsR0FBRyxTQUFTLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFDdEUsSUFBSSxNQUFNLEdBQUcsTUFBTSxDQUFDO1lBQ3BCLElBQUksVUFBVSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7Z0JBQ3ZCLE1BQU0sR0FBSSxVQUFVLENBQUMsQ0FBQyxDQUFZLENBQUMsV0FBVyxFQUFFLENBQUM7YUFDcEQ7WUFDRCxJQUFJLEdBQUcsR0FBRyxhQUFhLEdBQUcsTUFBTSxHQUFHLFVBQVUsQ0FBQztZQUU5QyxtQ0FBbUM7WUFDbkMsR0FBRyxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsa0JBQWtCLENBQUMsa0JBQWtCLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3BFLE9BQU8sR0FBRyxDQUFDO1FBQ2IsQ0FBQztRQUVELHlDQUF5QztRQUN6QyxhQUFhLEVBQUUsVUFBUyxFQUFPO1lBQzdCLElBQUksR0FBRyxHQUFHLENBQUMsQ0FBQztZQUNaLElBQUksRUFBRSxFQUFFO2dCQUNOLElBQUksSUFBSSxHQUFHLEVBQUUsQ0FBQyxJQUFJLEVBQUUsQ0FBQztnQkFDckIsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUU7b0JBQ2pCLEdBQUcsRUFBRSxDQUFDO29CQUNOLElBQUksR0FBRyxFQUFFLENBQUMsSUFBSSxFQUFFLENBQUM7aUJBQ2xCO2FBQ0Y7WUFDRCxPQUFPLEdBQUcsQ0FBQztRQUNiLENBQUM7UUFFRDs7V0FFRztRQUNILGlCQUFpQixFQUFFO1lBQ2pCLElBQUksV0FBVyxHQUFHLEtBQUssQ0FBQztZQUN4QixJQUFJLENBQUMsSUFBSSxDQUFDLGVBQWU7Z0JBQ3BCLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDckQsQ0FBQyxJQUFJLENBQUMsa0JBQWtCO29CQUN4QixJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFO2dCQUN2RCxXQUFXLEdBQUcsSUFBSSxDQUFDO2FBQ3hCO1lBQ0QsSUFBSSxDQUFDLFdBQVcsR0FBRyxXQUFXLENBQUM7UUFDakMsQ0FBQztRQUVEOzs7V0FHRztRQUNILHNCQUFzQixFQUFFLFVBQVMsSUFBWTtZQUMzQyxJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyw0QkFBNEIsQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUN2RCxJQUFJLENBQUMsV0FBVyxHQUFHLEVBQUUsQ0FBQztRQUN4QixDQUFDO1FBRUQ7Ozs7V0FJRztRQUNILDZCQUE2QixFQUFFLFVBQVMsSUFBWTtZQUNsRCxJQUFJLENBQUMsSUFBSSxFQUFFO2dCQUNULE9BQU87YUFDUjtZQUNELElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLDRCQUE0QixDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ2hFLENBQUM7UUFFRCw0QkFBNEIsRUFBRSxVQUFTLElBQVM7WUFDOUMsSUFBSSxDQUFDLElBQUksRUFBRTtnQkFDVCxPQUFPLElBQUksQ0FBQzthQUNiO1lBQ0Qsa0VBQWtFO1lBQ2xFLElBQUksT0FBTyxJQUFJLENBQUMsSUFBSSxLQUFLLFFBQVEsRUFBRTtnQkFDakMsSUFBSSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQzlCO1lBQ0QsSUFBSSxJQUFJLENBQUMsUUFBUSxFQUFFO2dCQUNqQixJQUFNLEVBQUUsR0FBRyxJQUFJLE9BQU8sRUFBRSxDQUFDO2dCQUN6QixFQUFFLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7Z0JBQ2xELE9BQU8sRUFBRSxDQUFDO2FBQ1g7aUJBQU0sSUFBSSxJQUFJLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxZQUFZLEVBQUU7Z0JBQzVDLElBQU0sS0FBSyxHQUFHLElBQUksZUFBZSxFQUFFLENBQUM7Z0JBQ3BDLElBQUksSUFBSSxDQUFDLE9BQU8sRUFBRTtvQkFDaEIsS0FBSyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO2lCQUNwRDtnQkFDRCxJQUFJLElBQUksQ0FBQyxZQUFZLEVBQUU7b0JBQ3JCLEtBQUssQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDO2lCQUNsRTtnQkFDRCxPQUFPLEtBQUssQ0FBQzthQUNkO2lCQUFNO2dCQUNMLE9BQU8sSUFBSSxPQUFPLEVBQUUsQ0FBQzthQUN0QjtRQUNILENBQUM7UUFFRCx5REFBeUQ7UUFDekQsYUFBYSxFQUFFLFVBQVMsUUFBYTtZQUNuQyxJQUFNLEtBQUssR0FBRyxJQUFJLFFBQVEsRUFBRSxDQUFDO1lBQzdCLEtBQUssSUFBTSxLQUFLLElBQUksUUFBUSxDQUFDLE9BQU8sRUFBRTtnQkFDcEMsSUFBSSxRQUFRLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsRUFBRTtvQkFDMUMsSUFBTSxTQUFTLEdBQUcsUUFBUSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDMUMsS0FBSyxDQUFDLGFBQWEsRUFBRSxDQUFDLEdBQUcsQ0FDckIsS0FBSyxFQUFFLElBQUksQ0FBQyxZQUFZLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO2lCQUMvRDthQUNGO1lBQ0QsT0FBTyxLQUFLLENBQUM7UUFDZixDQUFDO1FBRUQseURBQXlEO1FBQ3pELGlCQUFpQixFQUFFLFVBQVMsUUFBYTtZQUN2QyxJQUFNLEtBQUssR0FBRyxJQUFJLFlBQVksRUFBRSxDQUFDO1lBQ2pDLEtBQUssSUFBTSxLQUFLLElBQUksUUFBUSxDQUFDLFdBQVcsRUFBRTtnQkFDeEMsSUFBSSxRQUFRLENBQUMsV0FBVyxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsRUFBRTtvQkFDOUMsSUFBTSxhQUFhLEdBQUcsUUFBUSxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDbEQsSUFBTSxRQUFRLEdBQUcsSUFBSSxXQUFXLEVBQUUsQ0FBQztvQkFDbkMsSUFBTSxXQUFXLEdBQWMsRUFBRSxDQUFDO29CQUNsQyxLQUFLLElBQU0sU0FBUyxJQUFJLGFBQWEsQ0FBQyxPQUFPLEVBQUU7d0JBQzdDLElBQUksYUFBYSxDQUFDLE9BQU8sQ0FBQyxjQUFjLENBQUMsU0FBUyxDQUFDLEVBQUU7NEJBQ25ELElBQU0sSUFBSSxHQUFHLGFBQWEsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUM7NEJBQzlDLFdBQVcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7eUJBQ2hFO3FCQUNGO29CQUNELFFBQVEsQ0FBQyxjQUFjLENBQUMsV0FBVyxDQUFDLENBQUM7b0JBQ3JDLEtBQUssQ0FBQyxpQkFBaUIsRUFBRSxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsUUFBUSxDQUFDLENBQUM7aUJBQ2hEO2FBQ0Y7WUFDRCxPQUFPLEtBQUssQ0FBQztRQUNmLENBQUM7UUFFRCx5REFBeUQ7UUFDekQsWUFBWSxFQUFFLFVBQVMsU0FBYyxFQUFFLE9BQWdCO1lBQ3JELElBQU0sSUFBSSxHQUFHLElBQUksT0FBTyxFQUFFLENBQUM7WUFDM0IsSUFBSSxTQUFTLENBQUMsU0FBUyxFQUFFO2dCQUN2QixJQUFNLE1BQU0sR0FBRyxJQUFJLFNBQVMsRUFBRSxDQUFDO2dCQUMvQixNQUFNLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQy9DLElBQUksQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLENBQUM7YUFDM0I7aUJBQU0sSUFBSSxTQUFTLENBQUMsU0FBUyxFQUFFO2dCQUM5Qix1RUFBdUU7Z0JBQ3ZFLDBDQUEwQztnQkFDMUMsSUFBTSxLQUFLLEdBQUcsSUFBSSxTQUFTLEVBQUUsQ0FBQztnQkFDOUIsSUFBSSxTQUFTLENBQUMsU0FBUyxDQUFDLEtBQUssRUFBRTtvQkFDN0IsS0FBSyxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDO2lCQUMvQztnQkFDRCxJQUFJLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxDQUFDO2FBQzFCO2lCQUFNLElBQUksU0FBUyxDQUFDLFNBQVMsRUFBRTtnQkFDOUIsSUFBTSxJQUFJLEdBQUcsSUFBSSxTQUFTLEVBQUUsQ0FBQztnQkFDN0IsSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUM3QyxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQ3pCO1lBQ0QsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO1FBRUQsVUFBVSxFQUFFLFVBQVMsSUFBWSxFQUFFLE9BQWlCO1lBQ2xELElBQUksT0FBTyxFQUFFO2dCQUNYLE9BQU8sSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxDQUFDO2FBQ3JDO1lBQ0QsT0FBTyxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxHQUFHLFFBQVEsQ0FBQztRQUMvQyxDQUFDO1FBRUQsV0FBVyxFQUFFLFVBQVMsSUFBWSxFQUFFLE9BQWlCO1lBQ25ELElBQUksT0FBTyxFQUFFO2dCQUNYLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxDQUFDO2FBQ3RDO1lBQ0QsT0FBTyxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxHQUFHLFNBQVMsQ0FBQztRQUNoRCxDQUFDO1FBRUQsY0FBYyxFQUFFLFVBQVMsSUFBWSxFQUFFLE9BQWlCO1lBQ3RELElBQUksT0FBTyxFQUFFO2dCQUNYLE9BQU8sSUFBSSxDQUFDLHFCQUFxQixDQUFDLElBQUksQ0FBQyxDQUFDO2FBQ3pDO1lBQ0QsT0FBTyxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxHQUFHLE9BQU8sQ0FBQztRQUM5QyxDQUFDO1FBRUQsaUJBQWlCLEVBQUUsVUFBUyxJQUFZO1lBQ3RDLE9BQU8sSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsR0FBRyxnQkFBZ0IsQ0FBQztRQUN2RCxDQUFDO1FBRUQsa0JBQWtCLEVBQUUsVUFBUyxJQUFZO1lBQ3ZDLE9BQU8sSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsR0FBRyxpQkFBaUIsQ0FBQztRQUN4RCxDQUFDO1FBRUQscUJBQXFCLEVBQUUsVUFBUyxJQUFZO1lBQzFDLE9BQU8sSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsR0FBRyxlQUFlLENBQUM7UUFDdEQsQ0FBQztRQUVELGtCQUFrQixFQUFFLFVBQVMsSUFBWTtZQUN2QyxPQUFPLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLEdBQUcsU0FBUyxDQUFDO1FBQ2hELENBQUM7UUFFRCxrQkFBa0IsRUFBRSxVQUFTLEtBQVk7WUFDdkMsSUFBTSxNQUFNLEdBQUcsS0FBSyxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUM7WUFDOUMsSUFBTSxPQUFPLEdBQUksTUFBYyxDQUFDLFdBQVcsQ0FBQztZQUM1QyxJQUFNLE1BQU0sR0FBRyxJQUFJLENBQUMsRUFBRSxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQyxHQUFHLFNBQVMsQ0FBQyxDQUFDO1lBQ3hFLE1BQU0sQ0FBQyxjQUFjLEdBQUcsTUFBTSxDQUFDO1lBQy9CLE1BQU0sQ0FBQyxJQUFJLEVBQUUsQ0FBQztRQUNoQixDQUFDO1FBRUQsYUFBYSxFQUFFLFVBQVMsS0FBWTtZQUNsQyxJQUFNLE9BQU8sR0FBSSxLQUFLLENBQUMsVUFBa0IsQ0FBQyxXQUFXLENBQUM7WUFDdEQsSUFBSSxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDO1lBQ3BFLElBQUksQ0FBQyxvQkFBb0IsRUFBRSxDQUFDO1FBQzlCLENBQUM7UUFFRCx3QkFBd0IsRUFBRSxVQUFTLEdBQVc7WUFDNUMsSUFBTSxFQUFFLEdBQUcsSUFBSSxVQUFVLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQ3RDLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxHQUFHLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxFQUFFO2dCQUNuQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUMzQjtZQUNELE9BQU8sRUFBRSxDQUFDO1FBQ1osQ0FBQztRQUdELGlCQUFpQixFQUFFLFVBQVMsS0FBWTtZQUN0QyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxDQUFBO1FBQ3BDLENBQUM7UUFFRCxzRUFBc0U7UUFDdEUsNEJBQTRCO1FBQzVCLGtCQUFrQixFQUFFLFVBQVMsS0FBWTtZQUN2QyxJQUFNLElBQUksR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDMUMsSUFBTSxNQUFNLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsZ0JBQWdCLENBQUMsYUFBYSxDQUFDLENBQUM7WUFDdEUsSUFBSSxTQUFTLEdBQUcsSUFBSSxDQUFDO1lBQ3JCLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxNQUFNLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO2dCQUN0QyxJQUFLLE1BQU0sQ0FBQyxDQUFDLENBQVMsQ0FBQyxXQUFXLElBQUksSUFBSSxDQUFDLE9BQU8sRUFBRTtvQkFDbEQsU0FBUyxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDdEIsTUFBTTtpQkFDUDthQUNGO1lBQ0QsSUFBSSxTQUFTLEVBQUU7Z0JBQ2IsU0FBUyxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLEVBQUUsQ0FBQzthQUMxQztRQUNILENBQUM7UUFFRCw0Q0FBNEM7UUFDNUMsZ0JBQWdCLEVBQUUsVUFBUyxLQUFZLEVBQUUsSUFBUztZQUNoRCxLQUFLLENBQUMsZUFBZSxFQUFFLENBQUM7WUFDeEIsS0FBSyxDQUFDLGNBQWMsRUFBRSxDQUFDO1lBQ3ZCLElBQU0sTUFBTSxHQUFHLElBQUksVUFBVSxFQUFFLENBQUM7WUFDaEMsSUFBTSxRQUFRLEdBQUcsS0FBWSxDQUFDO1lBQzlCLElBQU0sS0FBSyxHQUFHLFFBQVEsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQztZQUMxRixJQUFJLEtBQUssQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO2dCQUN0QixPQUFPO2FBQ1I7WUFDRCxNQUFNLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxFQUFFO2dCQUM5QixpRUFBaUU7Z0JBQ2pFLGlEQUFpRDtnQkFDakQsSUFBTSxLQUFLLEdBQUcsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyw2QkFBNkIsQ0FBQztvQkFDL0QsNkJBQTZCLENBQUMsTUFBTSxDQUFDO2dCQUN6QyxJQUFNLGdCQUFnQixHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUN4RCxJQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsd0JBQXdCLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQztnQkFFakUsSUFBTSxJQUFJLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUMxQyxJQUFNLElBQUksR0FBRyxJQUFJLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLENBQUM7Z0JBQzNDLElBQU0sTUFBTSxHQUFHLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDL0MsSUFBSSxJQUFJLEVBQUU7b0JBQ1Isb0VBQW9FO29CQUNwRSxjQUFjO29CQUNkLGlFQUFpRTtvQkFDakUsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHLEVBQVMsQ0FBQztvQkFDdEIsSUFBSSxDQUFDLFlBQVksRUFBRyxDQUFDLFlBQVksQ0FBRSxNQUFtQixDQUFDLENBQUM7b0JBRXhELG1FQUFtRTtvQkFDbkUsdUNBQXVDO29CQUN2QyxJQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7b0JBQ2xFLElBQUksUUFBUSxFQUFFO3dCQUNaLFFBQVEsQ0FBQyxDQUFDLENBQUMsR0FBRyxnQkFBZ0IsQ0FBQztxQkFDaEM7b0JBRUQsaUVBQWlFO29CQUNqRSxtREFBbUQ7b0JBQ25ELElBQU0sS0FBRyxHQUFHLElBQUksS0FBSyxFQUFFLENBQUM7b0JBQ3hCLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxLQUFHLENBQUMsQ0FBQztvQkFDeEMsS0FBRyxDQUFDLGdCQUFnQixDQUFDLE1BQU0sRUFBRTt3QkFDM0IsMERBQTBEO3dCQUMxRCxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxLQUFHLENBQUMsQ0FBQzt3QkFFMUMsa0VBQWtFO3dCQUNsRSxrRUFBa0U7d0JBQ2xFLGtDQUFrQzt3QkFDbEMsSUFBTSxhQUFhLEdBQ2YsaUJBQWlCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7d0JBQ25ELElBQU0sWUFBWSxHQUFHLE9BQU8sR0FBRyxhQUFhLEdBQUcsUUFBUSxDQUFDO3dCQUN4RCxJQUFNLGFBQWEsR0FBRyxPQUFPLEdBQUcsYUFBYSxHQUFHLFNBQVMsQ0FBQzt3QkFDMUQsSUFBTSxNQUFNLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFlBQVksRUFBRSxLQUFLLENBQUMsQ0FBQzt3QkFDMUQsSUFBTSxPQUFPLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGFBQWEsRUFBRSxLQUFLLENBQUMsQ0FBQzt3QkFDNUQsSUFBSSxNQUFNLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTs0QkFDckIsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBRyxDQUFDLEtBQUssQ0FBQzs0QkFDdkIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFFLENBQUMsWUFBWSxFQUFHLENBQUMsWUFBWSxDQUN4RCxNQUFtQixDQUFDLENBQUM7eUJBQzNCO3dCQUNELElBQUksT0FBTyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7NEJBQ3RCLE9BQU8sQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUcsQ0FBQyxNQUFNLENBQUM7NEJBQ3pCLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBRSxDQUFDLFlBQVksRUFBRyxDQUFDLFlBQVksQ0FDekQsT0FBb0IsQ0FBQyxDQUFDO3lCQUM1Qjt3QkFDRCxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7b0JBQ3hCLENBQUMsQ0FBQyxDQUFDO29CQUNILEtBQUcsQ0FBQyxHQUFHLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQztpQkFDekI7WUFDSCxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFFVixxQ0FBcUM7WUFDckMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUNqQyxDQUFDO1FBRUQsOERBQThEO1FBQzlELDJCQUEyQixFQUFFLFVBQVMsTUFBbUI7WUFDdkQsSUFBTSxJQUFJLEdBQUcsSUFBSSxDQUFDO1lBRWxCLHlEQUF5RDtZQUN6RCx3QkFBd0IsS0FBZ0I7Z0JBQ3RDLEtBQUssQ0FBQyxlQUFlLEVBQUUsQ0FBQztnQkFDeEIsS0FBSyxDQUFDLGNBQWMsRUFBRSxDQUFDO2dCQUN2QixLQUFLLENBQUMsWUFBWSxDQUFDLFVBQVUsR0FBRyxNQUFNLENBQUM7WUFDekMsQ0FBQztZQUVELDBCQUEwQixLQUFnQjtnQkFDeEMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsQ0FBQTtZQUNwQyxDQUFDO1lBRUQsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLElBQUksTUFBTSxFQUFFO2dCQUM1QixNQUFNLENBQUMsZ0JBQWdCLENBQUMsVUFBVSxFQUFFLGNBQWMsRUFBRSxLQUFLLENBQUMsQ0FBQztnQkFDM0QsTUFBTSxDQUFDLGdCQUFnQixDQUFDLE1BQU0sRUFBRSxnQkFBZ0IsRUFBRSxLQUFLLENBQUMsQ0FBQzthQUMxRDtRQUNILENBQUM7UUFFRDs7OztXQUlHO1FBQ0gsaUJBQWlCLEVBQUUsVUFBUyxJQUFZLEVBQUUsS0FBdUIsRUFDN0QsT0FBaUI7WUFERixpQkEyRWxCO1lBekVDLElBQU0sQ0FBQyxHQUFHLFVBQUMsSUFBWSxFQUFFLEtBQXVCLEVBQUUsT0FBaUI7Z0JBQ2pFLElBQU0sTUFBTSxHQUFHLEtBQUksQ0FBQyxFQUFFLENBQ3BCLEdBQUcsR0FBRyxLQUFJLENBQUMsV0FBVyxDQUFDLElBQUksRUFBRSxPQUFPLENBQUMsQ0FBc0IsQ0FBQztnQkFDOUQsSUFBSSxDQUFDLE9BQU8sRUFBRTtvQkFDWixLQUFJLENBQUMsMkJBQTJCLENBQUMsTUFBTSxDQUFDLENBQUM7aUJBQzFDO2dCQUVELElBQUksS0FBSyxJQUFJLE1BQU0sRUFBRTtvQkFDbkIsb0RBQW9EO29CQUNwRCx3RUFBd0U7b0JBQ3hFLElBQU0sU0FBTyxHQUFHLE1BQU0sQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFFLENBQUM7b0JBQ3pDLElBQUksZ0JBQWdCLEdBQUcsS0FBSSxDQUFDLG9CQUFvQixHQUFHLEdBQUcsQ0FBQztvQkFFdkQsZ0VBQWdFO29CQUNoRSx5REFBeUQ7b0JBQ3pELElBQUksQ0FBQyxLQUFJLENBQUMsa0JBQWtCLEVBQUU7d0JBQzVCLElBQU0sTUFBTSxHQUFHLEtBQUksQ0FBQyxFQUFFLENBQ3BCLEdBQUc7NEJBQ0gsS0FBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLENBQUMsQ0FBQyxhQUE0QixDQUFDO3dCQUNuRSxJQUFJLG1CQUFtQixHQUFHLE1BQU0sQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUM7d0JBQ25FLElBQUksbUJBQW1CLEdBQUcsRUFBRSxFQUFFOzRCQUM1QixtQkFBbUIsSUFBSSxFQUFFLENBQUM7eUJBQzNCO3dCQUNELElBQUksbUJBQW1CLEdBQUcsS0FBSyxDQUFDLEtBQUssRUFBRTs0QkFDckMsZ0JBQWdCLEdBQUcsbUJBQW1CLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQzt5QkFDdEQ7cUJBQ0Y7b0JBQ0QsTUFBTSxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUMsS0FBSyxHQUFHLGdCQUFnQixDQUFDO29CQUM5QyxNQUFNLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQyxNQUFNLEdBQUcsZ0JBQWdCLENBQUM7b0JBQ2hELElBQU0sYUFBVyxHQUFHLFVBQUMsU0FBMkI7d0JBQzlDLFNBQU8sQ0FBQyxJQUFJLEVBQUUsQ0FBQzt3QkFDZixTQUFPLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsTUFBTSxDQUFDLEtBQUssRUFBRSxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUM7d0JBQ3JELFNBQU8sQ0FBQyxTQUFTLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQzVDLFNBQU8sQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQ3hDLEtBQUksQ0FBQyxtQkFBbUIsQ0FBQyxTQUFPLEVBQUUsTUFBTSxDQUFDLEtBQUssRUFBRSxNQUFNLENBQUMsTUFBTSxFQUFFLElBQUksRUFDakUsT0FBTyxDQUFDLENBQUM7d0JBQ1gsU0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDO29CQUNwQixDQUFDLENBQUM7b0JBQ0YsSUFBTSxJQUFJLEdBQUc7d0JBQ1gsSUFBTSxTQUFTLEdBQUcsRUFBRSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUM7d0JBQ3JDLEtBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLEVBQUUsU0FBUyxFQUFFLE9BQU8sQ0FBQyxDQUFDO3dCQUNqRCxhQUFXLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQztvQkFDbEMsQ0FBQyxDQUFDO29CQUNGLElBQU0sUUFBTSxHQUFHLEVBQUUsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxXQUFXLENBQUMsV0FBVyxDQUFDLENBQUMsRUFBRSxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsQ0FBQztvQkFDbkUsRUFBRSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBTSxDQUFDLENBQUMsRUFBRSxDQUM3QixlQUFlLEVBQ2YsY0FBTSxPQUFBLEVBQUUsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQU0sQ0FBQyxTQUFTLEVBQUUsRUFBRSxDQUFDLFlBQVksQ0FBQyxFQUF6RCxDQUF5RCxDQUFDLENBQUM7b0JBRXJFLFNBQU8sQ0FBQyxJQUFJLEVBQUUsQ0FBQztvQkFDZixTQUFPLENBQUMsS0FBSyxDQUFDLGdCQUFnQixFQUFFLGdCQUFnQixDQUFDLENBQUM7b0JBQ2xELFNBQU8sQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztvQkFDL0IsU0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDO29CQUNsQixLQUFJLENBQUMsYUFBYSxDQUFDLFNBQU8sRUFBRSxNQUFNLENBQUMsS0FBSyxFQUFFLE1BQU0sQ0FBQyxNQUFNLEVBQUUsSUFBSSxFQUFFLE9BQU8sQ0FBQyxDQUFDO29CQUN4RSxLQUFJLENBQUMsbUJBQW1CLENBQUMsU0FBTyxFQUFFLE1BQU0sQ0FBQyxLQUFLLEVBQUUsTUFBTSxDQUFDLE1BQU0sRUFBRSxJQUFJLEVBQ2pFLE9BQU8sQ0FBQyxDQUFDO29CQUNYLElBQUksT0FBTyxFQUFFO3dCQUNYLElBQUksS0FBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxDQUFDLFNBQVMsRUFBRTs0QkFDekMsYUFBVyxDQUFDLEtBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsQ0FBQyxTQUFVLENBQUMsQ0FBQzt5QkFDckQ7cUJBQ0Y7eUJBQU07d0JBQ0wsSUFBSSxLQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDLFNBQVMsRUFBRTs0QkFDbEMsYUFBVyxDQUFDLEtBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUMsU0FBVSxDQUFDLENBQUM7eUJBQzlDO3FCQUNGO2lCQUNGO3FCQUFNO29CQUNMLHFFQUFxRTtvQkFDckUsY0FBYztvQkFDZCxxQkFBcUIsQ0FBQyxjQUFNLE9BQUEsQ0FBQyxDQUFDLElBQUksRUFBRSxLQUFLLEVBQUUsT0FBTyxDQUFDLEVBQXZCLENBQXVCLENBQUMsQ0FBQztpQkFDdEQ7WUFDSCxDQUFDLENBQUM7WUFDRixJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksRUFBRSxLQUFLLEVBQUUsT0FBTyxDQUFDLENBQUM7WUFDM0MsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1lBQ3RDLE9BQU8sQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQyxJQUFJLEVBQUUsS0FBSyxFQUFFLE9BQU8sQ0FBQyxDQUFDLENBQUM7UUFDL0MsQ0FBQztRQUVELGNBQWMsRUFBRSxVQUFTLElBQVksRUFBRSxNQUFzQixFQUN6RCxPQUFpQjtZQUNuQixJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQztZQUNyQixJQUFJLE9BQU8sRUFBRTtnQkFDWCxJQUFJLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxFQUFFO29CQUNoQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDO2lCQUNqQztnQkFDRCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQzthQUM5QztpQkFBTTtnQkFDTCxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsRUFBRTtvQkFDMUIsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUM7aUJBQzFCO2dCQUNELElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQzthQUN0QztRQUNILENBQUM7UUFFRCxZQUFZLEVBQUUsVUFBUyxJQUFZLEVBQUUsU0FBNEIsRUFDN0QsT0FBaUI7WUFDbkIsSUFBSSxPQUFPLEVBQUU7Z0JBQ1gsSUFBSSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsRUFBRTtvQkFDaEMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQztpQkFDakM7Z0JBQ0QsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxDQUFDLFNBQVMsR0FBRyxTQUFTLENBQUM7YUFDcEQ7aUJBQU07Z0JBQ0wsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLEVBQUU7b0JBQzFCLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDO2lCQUMxQjtnQkFDRCxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDLFNBQVMsR0FBRyxTQUFTLENBQUM7YUFDNUM7UUFDSCxDQUFDO1FBRUQsZUFBZSxFQUFFLFVBQVMsSUFBWSxFQUFFLEtBQXVCLEVBQzNELE9BQWlCO1lBQ25CLElBQUksT0FBTyxFQUFFO2dCQUNYLElBQUksQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLEVBQUU7b0JBQ2hDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUM7aUJBQ2xDO2dCQUNELElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsQ0FBQyxZQUFZLEdBQUcsS0FBSyxDQUFDO2FBQ2xEO2lCQUFNO2dCQUNMLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxFQUFFO29CQUN6QixJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQztpQkFDM0I7Z0JBQ0QsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxZQUFZLEdBQUcsS0FBSyxDQUFDO2FBQzNDO1FBQ0gsQ0FBQztRQUVELHFCQUFxQixFQUFFLFVBQ25CLElBQVksRUFBRSxrQkFBcUM7WUFDckQsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLEVBQUU7Z0JBQ3pCLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDO2FBQzNCO1lBQ0QsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxrQkFBa0IsR0FBRyxrQkFBa0IsQ0FBQztRQUMvRCxDQUFDO1FBRUQsaUJBQWlCLEVBQUUsVUFBUyxJQUFZLEVBQUUsU0FBMkIsRUFDakUsT0FBaUI7WUFDbkIsSUFBSSxPQUFPLEVBQUU7Z0JBQ1gsSUFBSSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsRUFBRTtvQkFDaEMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQztpQkFDbEM7Z0JBQ0QsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxDQUFDLFNBQVMsR0FBRyxTQUFTLENBQUM7YUFDbkQ7aUJBQU07Z0JBQ0wsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLEVBQUU7b0JBQ3pCLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDO2lCQUMzQjtnQkFDRCxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDLFNBQVMsR0FBRyxTQUFTLENBQUM7YUFDNUM7UUFDSCxDQUFDO1FBRUQ7Ozs7V0FJRztRQUNILGFBQWEsRUFBRSxVQUNYLE9BQWlDLEVBQUUsS0FBYSxFQUFFLE1BQWMsRUFDaEUsSUFBWSxFQUFFLE9BQWlCO1lBQ2pDLElBQUksQ0FBQyxLQUFLLElBQUksQ0FBQyxNQUFNLEVBQUU7Z0JBQ3JCLE9BQU87YUFDUjtZQUNELElBQU0sV0FBVyxHQUFHLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxLQUFLLEVBQUUsTUFBTSxDQUFDLENBQUM7WUFDOUQsSUFBTSxTQUFTLEdBQUcsaUJBQWlCLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUMzRCxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksRUFBRSxTQUFTLEVBQUUsT0FBTyxDQUFDLENBQUM7WUFFNUMsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUM7Z0JBQzVELE9BQU8sRUFBRTtnQkFDWCxPQUFPO2FBQ1I7WUFFRCwwREFBMEQ7WUFDMUQsSUFBTSxPQUFPLEdBQUcsaUJBQWlCLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBQ2xELEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxTQUFTLENBQUMsTUFBTSxFQUFFLENBQUMsSUFBSSxDQUFDLEVBQUU7Z0JBQzVDLHVEQUF1RDtnQkFDdkQsSUFBTSxHQUFHLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEdBQUcsU0FBUyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxTQUFTLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUNyRSxPQUFPLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDO2dCQUNqQixPQUFPLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQztnQkFDckIsT0FBTyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUM7YUFDdEI7WUFDRCxJQUFJLENBQUMscUJBQXFCLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBQzVDLENBQUM7UUFFRCwrREFBK0Q7UUFDL0QsYUFBYSxFQUFFLFVBQ1gsQ0FBb0IsRUFBRSxXQUFtQixFQUFFLFlBQW9CO1lBQ2pFLDRFQUE0RTtZQUM1RSxJQUFNLGFBQWEsR0FBRyxFQUFFLENBQUMsV0FBVyxFQUFVO2lCQUNuQixNQUFNLENBQUM7Z0JBQ04sWUFBWSxHQUFHLEVBQUUsR0FBRyxDQUFDLFdBQVcsR0FBRyxDQUFDLENBQUM7Z0JBQ3JDLFlBQVksR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDLFdBQVcsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7YUFDNUMsQ0FBQztpQkFDRCxLQUFLLENBQUMsSUFBSSxDQUFDO2lCQUNYLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDO1lBQzNDLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO2dCQUNqQyxzQkFBc0I7Z0JBQ3RCLElBQUksQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLEVBQUU7b0JBQ2YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztpQkFDNUI7YUFDRjtRQUNILENBQUM7UUFFRDs7O1dBR0c7UUFDSCxvQkFBb0IsRUFBRSxVQUFTLE1BQWM7WUFDM0MsSUFBTSxtQkFBbUIsR0FBRyxNQUFNLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDO1lBQ3BFLE9BQU8sSUFBSSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUM7Z0JBQ25CLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsQ0FBQyxHQUFHLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLENBQUM7UUFDbkUsQ0FBQztRQUVELCtEQUErRDtRQUMvRCxtQkFBbUIsRUFBRSxVQUFTLE1BQWM7WUFDMUMsSUFBSSxDQUFDLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxNQUFNLENBQUMsRUFBRTtnQkFDdEMsT0FBTyxvQkFBb0IsQ0FBQzthQUM3QjtpQkFBTTtnQkFDTCxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUM7YUFDNUI7UUFDSCxDQUFDO1FBRUQsOERBQThEO1FBQzlELGtCQUFrQixFQUFFLFVBQ2hCLENBQW9CLEVBQUUsR0FBa0M7WUFDMUQsMEVBQTBFO1lBQzFFLDhDQUE4QztZQUM5QyxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLElBQUksR0FBRyxDQUFDLE1BQU0sR0FBRyxDQUFDLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRTtnQkFDakUsR0FBRyxHQUFHLEdBQUcsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7YUFDM0I7WUFFRCwwRUFBMEU7WUFDMUUseUVBQXlFO1lBQ3pFLHlDQUF5QztZQUV6QyxxRUFBcUU7WUFDckUsMkVBQTJFO1lBQzNFLHVFQUF1RTtZQUN2RSxrRUFBa0U7WUFDbEUsSUFBTSxrQkFBa0IsR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsb0JBQW9CLEdBQUcsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDO1lBRTVFLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxFQUFFLENBQUMsSUFBSSxDQUFDLEVBQUU7Z0JBQ3BDLDBFQUEwRTtnQkFDMUUsdURBQXVEO2dCQUN2RCxJQUFJLE1BQU0sR0FBRyxDQUFDLENBQUM7Z0JBQ2YsSUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLGtCQUFrQixDQUFDLENBQUM7Z0JBQ3hELElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsRUFBRTtvQkFDdEIsSUFBSSxHQUFHLENBQUMsTUFBTSxHQUFHLFFBQVEsRUFBRTt3QkFDekIsTUFBTSxHQUFHLEdBQUcsQ0FBQyxRQUFRLENBQVcsQ0FBQztxQkFDbEM7eUJBQU07d0JBQ0wsTUFBTSxHQUFHLENBQUMsQ0FBQztxQkFDWjtpQkFDRjtxQkFBTTtvQkFDTCxNQUFNLEdBQUcsR0FBYSxDQUFDO2lCQUN4QjtnQkFFRCx1RUFBdUU7Z0JBQ3ZFLGlEQUFpRDtnQkFDakQsSUFBTSxzQkFBc0IsR0FBRyxJQUFJLENBQUMsb0JBQW9CLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztvQkFDOUQsQ0FBQyxNQUFNLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO3dCQUM5QyxNQUFNLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7b0JBQ3RDLENBQUMsQ0FBQztnQkFDTixJQUFNLFVBQVUsR0FDWiw0QkFBNEIsR0FBRyxzQkFBc0IsQ0FBQztnQkFFcEQsSUFBQSw2REFDc0QsRUFEckQsUUFBQyxFQUFFLFFBQUMsRUFBRSxRQUFDLENBQytDO2dCQUM3RCxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLFVBQVUsQ0FBQyxHQUFHLENBQUMsR0FBRyxVQUFVLENBQUM7Z0JBQ2hELENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxVQUFVLENBQUMsR0FBRyxDQUFDLEdBQUcsVUFBVSxDQUFDO2dCQUN4RCxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsVUFBVSxDQUFDLEdBQUcsQ0FBQyxHQUFHLFVBQVUsQ0FBQzthQUN6RDtRQUNILENBQUM7UUFFRCxtQkFBbUIsRUFBRSxVQUNqQixPQUFpQyxFQUFFLEtBQWEsRUFBRSxNQUFjLEVBQ2hFLElBQVksRUFBRSxPQUFpQjtZQUNqQyxJQUFJLENBQUMsS0FBSyxJQUFJLENBQUMsTUFBTSxFQUFFO2dCQUNyQixPQUFPO2FBQ1I7WUFDRCxvQ0FBb0M7WUFDcEMsSUFBTSxFQUFFLEdBQUcsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEtBQUssRUFBRSxNQUFNLENBQUMsQ0FBQztZQUNyRCxJQUFJLE9BQU8sRUFBRTtnQkFDWCxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLENBQUMsU0FBVSxDQUFDLENBQUE7YUFDcEQ7aUJBQU07Z0JBQ1AsRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQ1AsSUFBSSxDQUFDLFFBQVEsSUFBSSxJQUFJLENBQUMsWUFBWSxJQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztvQkFDdkQsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxrQkFBbUIsQ0FBQyxDQUFDO29CQUMxQyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDLFNBQVUsQ0FBQyxDQUFDO2FBQ3hDO1lBRUQsMkRBQTJEO1lBQzNELElBQUksSUFBSSxDQUFDLFdBQVcsS0FBSyxvQkFBb0I7Z0JBQ3pDLElBQUksQ0FBQyxZQUFZLEtBQUsscUJBQXFCLEVBQUU7Z0JBQy9DLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRSxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQzthQUNsRTtZQUNELElBQUksQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLFFBQVEsSUFBSSxJQUFJLENBQUMsWUFBWSxJQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEVBQUU7Z0JBQ3pFLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxFQUFFLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQzthQUN2RDtZQUVELHVFQUF1RTtZQUN2RSx5RUFBeUU7WUFDekUsc0VBQXNFO1lBQ3RFLHFFQUFxRTtZQUNyRSxJQUFNLGNBQWMsR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQ3hELGNBQWMsQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDO1lBQzdCLGNBQWMsQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDO1lBQy9CLElBQU0sZUFBZSxHQUFHLGNBQWMsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFFLENBQUM7WUFDekQsZUFBZSxDQUFDLFlBQVksQ0FBQyxFQUFFLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1lBRXZDLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxLQUFLLEVBQUUsTUFBTSxDQUFDLENBQUM7WUFDdkMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxjQUFjLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQzFDLENBQUM7UUFFRCxxQkFBcUIsRUFBRTtZQUNyQixJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQztRQUNqRCxDQUFDO1FBRUQ7OztXQUdHO1FBQ0gsWUFBWSxFQUFFO1lBQ1osS0FBSyxJQUFNLElBQUksSUFBSSxJQUFJLENBQUMsU0FBUyxFQUFFO2dCQUNqQyxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxFQUFFO29CQUN2QyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU8sQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxZQUFhLENBQUMsQ0FBQztpQkFDeEU7YUFDRjtRQUNILENBQUM7UUFFRCx1QkFBdUIsRUFBRSxVQUNyQixRQUFpQixFQUFFLGtCQUEyQjtZQUNoRCxPQUFPLFFBQVEsSUFBSSxrQkFBa0IsQ0FBQztRQUN4QyxDQUFDO1FBRUQ7O1dBRUc7UUFDSCxzQkFBc0IsRUFBRSxVQUFTLFdBQW1CO1lBQ2xELE9BQU8sV0FBVyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7UUFDaEMsQ0FBQztRQUVELHlCQUF5QixFQUFFLFVBQVMsUUFBaUIsRUFBRSxxQkFBOEI7WUFDbkYsT0FBTyxRQUFRLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLENBQUMsZ0RBQWdELENBQUMsQ0FBQyxDQUFDLHFCQUFxQixDQUFDO1FBQ3ZILENBQUM7UUFFRCwyQkFBMkIsRUFBRSxVQUFTLFFBQWlCO1lBQ3JELE9BQU8sUUFBUSxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLHVCQUF1QixDQUFDO1FBQzlELENBQUM7UUFFRCxzQkFBc0IsRUFBRSxVQUFTLFFBQWlCO1lBQ2hELE9BQU8sUUFBUSxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLGtCQUFrQixDQUFDO1FBQ3pELENBQUM7UUFFRCx3QkFBd0IsRUFBRSxVQUFTLFFBQWlCO1lBQ2xELE9BQU8sUUFBUSxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLG9CQUFvQixDQUFDO1FBQzNELENBQUM7UUFFRCxtQkFBbUIsRUFBRSxVQUFTLFFBQWlCO1lBQzdDLE9BQU8sUUFBUSxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLHFCQUFxQixDQUFDO1FBQzVELENBQUM7UUFFRDs7O1dBR0c7UUFDSCx1QkFBdUIsRUFBRSxVQUFTLEtBQWlCO1lBQ2pELGdFQUFnRTtZQUNoRSxzQkFBc0I7WUFDdEIsSUFBTSxnQkFBZ0IsR0FBRyxFQUFFLEdBQUcsSUFBSSxDQUFDO1lBQ25DLElBQUksR0FBRyxHQUFHLEVBQUUsQ0FBQztZQUNiLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUNWLHdFQUF3RTtZQUN4RSxLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEtBQUssQ0FBQyxNQUFNLEdBQUcsZ0JBQWdCLEVBQUUsQ0FBQyxFQUFFLEVBQUU7Z0JBQ3BELEdBQUcsSUFBSSxNQUFNLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FDNUIsSUFBSSxFQUFFLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLGdCQUFnQixFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLGdCQUFnQixDQUFDLENBQUMsQ0FBQzthQUMxRTtZQUNELEdBQUcsSUFBSSxNQUFNLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxJQUFJLEVBQUUsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDO1lBQzFFLE9BQU8sR0FBRyxDQUFDO1FBQ2IsQ0FBQztLQUNGLENBQUMsQ0FBQztBQUVILENBQUMsRUFyM0RTLGlCQUFpQixLQUFqQixpQkFBaUIsUUFxM0QxQiIsInNvdXJjZXNDb250ZW50IjpbIi8qIENvcHlyaWdodCAyMDE4IFRoZSBUZW5zb3JGbG93IEF1dGhvcnMuIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG5cbkxpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSAnTGljZW5zZScpO1xueW91IG1heSBub3QgdXNlIHRoaXMgZmlsZSBleGNlcHQgaW4gY29tcGxpYW5jZSB3aXRoIHRoZSBMaWNlbnNlLlxuWW91IG1heSBvYnRhaW4gYSBjb3B5IG9mIHRoZSBMaWNlbnNlIGF0XG5cbiAgICBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcblxuVW5sZXNzIHJlcXVpcmVkIGJ5IGFwcGxpY2FibGUgbGF3IG9yIGFncmVlZCB0byBpbiB3cml0aW5nLCBzb2Z0d2FyZVxuZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIExpY2Vuc2UgaXMgZGlzdHJpYnV0ZWQgb24gYW4gJ0FTIElTJyBCQVNJUyxcbldJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWSBLSU5ELCBlaXRoZXIgZXhwcmVzcyBvciBpbXBsaWVkLlxuU2VlIHRoZSBMaWNlbnNlIGZvciB0aGUgc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nIHBlcm1pc3Npb25zIGFuZFxubGltaXRhdGlvbnMgdW5kZXIgdGhlIExpY2Vuc2UuXG49PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0qL1xuXG5pbXBvcnQgQnl0ZXNMaXN0IGZyb20gJ2dvb2c6cHJvdG8udGVuc29yZmxvdy5CeXRlc0xpc3QnO1xuaW1wb3J0IEV4YW1wbGUgZnJvbSAnZ29vZzpwcm90by50ZW5zb3JmbG93LkV4YW1wbGUnO1xuaW1wb3J0IEZlYXR1cmUgZnJvbSAnZ29vZzpwcm90by50ZW5zb3JmbG93LkZlYXR1cmUnO1xuaW1wb3J0IEZlYXR1cmVMaXN0IGZyb20gJ2dvb2c6cHJvdG8udGVuc29yZmxvdy5GZWF0dXJlTGlzdCc7XG5pbXBvcnQgRmVhdHVyZUxpc3RzIGZyb20gJ2dvb2c6cHJvdG8udGVuc29yZmxvdy5GZWF0dXJlTGlzdHMnO1xuaW1wb3J0IEZlYXR1cmVzIGZyb20gJ2dvb2c6cHJvdG8udGVuc29yZmxvdy5GZWF0dXJlcyc7XG5pbXBvcnQgRmxvYXRMaXN0IGZyb20gJ2dvb2c6cHJvdG8udGVuc29yZmxvdy5GbG9hdExpc3QnO1xuaW1wb3J0IEludDY0TGlzdCBmcm9tICdnb29nOnByb3RvLnRlbnNvcmZsb3cuSW50NjRMaXN0JztcbmltcG9ydCBTZXF1ZW5jZUV4YW1wbGUgZnJvbSAnZ29vZzpwcm90by50ZW5zb3JmbG93LlNlcXVlbmNlRXhhbXBsZSc7XG5cbm5hbWVzcGFjZSB2el9leGFtcGxlX3ZpZXdlciB7XG5cbi8vIFNhbGllbmN5TWFwIGlzIGEgbWFwIG9mIGZlYXR1cmUgbmFtZXMgdG8gc2FsaWVuY3kgdmFsdWVzIGZvciB0aGVpciBmZWF0dXJlXG4vLyB2YWx1ZXMuIFRoZSBzYWxpZW5jeSBjYW4gYmUgYSBzaW5nbGUgbnVtYmVyIGZvciBhbGwgdmFsdWVzIGluIGEgZmVhdHVyZSB2YWx1ZVxuLy8gbGlzdCwgb3IgYSBudW1iZXIgcGVyIHZhbHVlLiBGb3Igc2VxdWVuY2UgZXhhbXBsZXMsIHRoZXJlIGlzIHNhbGllbmN5XG4vLyBpbmZvcm1hdGlvbiBmb3IgZWFjaCBzZXF1ZW5jZSBudW1iZXIgaW4gdGhlIGV4YW1wbGUuXG4vLyBUT0RPKGp3ZXhsZXIpOiBTdHJlbmd0aGVuIHRoZSBkaWZmZXJlbmNlIGJldHdlZW4gYXJyYXkgb2YgU2FsaWVuY3lWYWx1ZXMgYW5kXG4vLyBhcnJheXMgb2YgbnVtYmVycyBpbiBhIFNhbGllbmN5VmFsdWUuXG5leHBvcnQgdHlwZSBTYWxpZW5jeVZhbHVlID0gbnVtYmVyfG51bWJlcltdO1xuZXhwb3J0IHR5cGUgU2FsaWVuY3lNYXAgPSB7W2ZlYXR1cmU6IHN0cmluZ106IFNhbGllbmN5VmFsdWV8U2FsaWVuY3lWYWx1ZVtdfTtcblxuLy8gQSBoZWxwZXIgaW50ZXJmYWNlIHRoYXQgdHJhY2tzIGEgZmVhdHVyZSdzIHZhbHVlcyBhbmQgaXRzIG5hbWUuXG5leHBvcnQgaW50ZXJmYWNlIE5hbWVBbmRGZWF0dXJlIHtcbiAgbmFtZTogc3RyaW5nO1xuICBmZWF0dXJlOiBGZWF0dXJlfEZlYXR1cmVMaXN0O1xufVxuXG5leHBvcnQgdHlwZSBPbmxvYWRGdW5jdGlvbiA9IChmZWF0OiBzdHJpbmcsIGltYWdlOiBIVE1MSW1hZ2VFbGVtZW50KSA9PiB2b2lkO1xuLy8gSW5mb3JtYXRpb24gYWJvdXQgYSBzaW5nbGUgaW1hZ2UgZmVhdHVyZS5cbmludGVyZmFjZSBJbWFnZUluZm9ybWF0aW9uIHtcbiAgLy8gaW1hZ2Ugb25sb2FkIGZ1bmN0aW9uLCBmb3IgcmUtY2FsbGluZyB3aGVuIHNhbGllbmN5IHNldHRpbmcgY2hhbmdlcy5cbiAgb25sb2FkPzogT25sb2FkRnVuY3Rpb247XG4gIC8vIFJhdyBJbWFnZURhdGEgYXJyYXlzIGZvciB0aGUgaW1hZ2UuIE9uZSBmb3IgdGhlIG9yaWdpbmFsIGltYWdlLCBvbmUgZm9yIHRoZVxuICAvLyBncmF5c2NhbGUgaW1hZ2UsIHRvIGJlIG92ZXJsYWlkIHdpdGggYSBzYWxpZW5jeSBtYXNrLlxuICBpbWFnZURhdGE/OiBVaW50OENsYW1wZWRBcnJheTtcbiAgaW1hZ2VHcmF5c2NhbGVEYXRhPzogVWludDhDbGFtcGVkQXJyYXk7XG5cbiAgLy8gVGhlIGltYWdlIGVsZW1lbnQgdGhhdCBpbml0aWFsbHkgbG9hZHMgdGhlIGltYWdlIGRhdGEgZm9yIHRoZSBmZWF0dXJlLlxuICBpbWFnZUVsZW1lbnQ/OiBIVE1MSW1hZ2VFbGVtZW50O1xuXG4gIC8vIEN1cnJlbnRseSBhcHBsaWVkIHRyYW5zZm9ybSB0byB0aGUgaW1hZ2UuXG4gIHRyYW5zZm9ybT86IGQzLlpvb21UcmFuc2Zvcm07XG59XG5cbi8vIEluZm9ybWF0aW9uIHN0b3JlZCBpbiBkYXRhIGF0dHJpYnV0ZXMgb2YgY29udHJvbHMgaW4gdGhlIHZpc3VhbGl6YXRpb24uXG5pbnRlcmZhY2UgRGF0YUZyb21Db250cm9sIHtcbiAgLy8gVGhlIGZlYXR1cmUgYmVpbmcgYWx0ZXJlZCBieSB0aGlzIGNvbnRyb2wuXG4gIGZlYXR1cmU6IHN0cmluZztcbiAgLy8gVGhlIGluZGV4IG9mIHRoZSB2YWx1ZSBpbiB0aGUgdmFsdWUgbGlzdCBiZWluZyBhbHRlcmVkIGJ5IHRoaXMgY29udHJvbC5cbiAgdmFsdWVJbmRleDogbnVtYmVyO1xuICAvLyBUaGUgc2VxdWVuY2UgbnVtYmVyIG9mIHRoZSB2YWx1ZSBsaXN0IGJlaW5nIGFsdGVyZWQgYnkgdGhpcyBjb250cm9sLlxuICBzZXFOdW06IG51bWJlcjtcbn1cblxuLy8gSFRNTEVsZW1lbnQgd2l0aCBib3VuZCBkYXRhIGF0dHJpYnV0ZXMgdG8gdHJhY2sgZmVhdHVyZSB2YWx1ZSBpbmZvcm1hdGlvbi5cbmludGVyZmFjZSBIVE1MRWxlbWVudFdpdGhEYXRhIGV4dGVuZHMgSFRNTEVsZW1lbnQge1xuICBkYXRhRmVhdHVyZTogc3RyaW5nO1xuICBkYXRhSW5kZXg6IG51bWJlcjtcbiAgZGF0YVNlcU51bTogbnVtYmVyO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIEhUTUxEaWFsb2dFbGVtZW50IGV4dGVuZHMgSFRNTEVsZW1lbnQgeyBvcGVuOiAoKSA9PiB2b2lkOyB9XG5cbmNvbnN0IElOVF9GRUFUVVJFX05BTUUgPSAnaW50JztcbmNvbnN0IEZMT0FUX0ZFQVRVUkVfTkFNRSA9ICdmbG9hdCc7XG5jb25zdCBCQVNFXzY0X0lNQUdFX0VOQ09ESU5HX1BSRUZJWCA9ICdiYXNlNjQsJztcbmNvbnN0IExFR0VORF9XSURUSF9QWCA9IDI2MDtcbmNvbnN0IExFR0VORF9IRUlHSFRfUFggPSAyMDtcbmNvbnN0IENIQU5HRV9DQUxMQkFDS19USU1FUl9ERUxBWV9NUyA9IDEwMDA7XG5jb25zdCBjbGlwU2FsaWVuY3lSYXRpbyA9IC45NTtcblxuLy8gQ29sb3JzIGZvciB0aGUgc2FsaWVuY3kgY29sb3Igc2NhbGUuXG5jb25zdCBwb3NTYWxpZW5jeUNvbG9yID0gJyMwZjAnO1xuY29uc3QgbmVnU2FsaWVuY3lDb2xvciA9ICcjZjAwJztcbmNvbnN0IG5ldXRyYWxTYWxpZW5jeUNvbG9yID0gJyNlOGVhZWQnO1xuXG5cbmNvbnN0IENPTE9SX0lOVEVSUE9MQVRPUiA9IGQzLmludGVycG9sYXRlUmdiO1xuXG4vLyBSZWdleCB0byBmaW5kIGJ5dGVzIGZlYXR1cmVzIHRoYXQgYXJlIGVuY29kZWQgaW1hZ2VzLiBGb2xsb3dzIHRoZSBndWlkZSBhdFxuLy8gZ28vdGYtZXhhbXBsZS5cbmNvbnN0IElNR19GRUFUVVJFX1JFR0VYID0gL15pbWFnZVxcLyhbXlxcL10rXFwvKSplbmNvZGVkJC87XG5cbi8vIENvcnJlc3BvbmRzIHRvIGEgbGVuZ3RoIG9mIGEgVWludDhBcnJheSBvZiBzaXplIDI1ME1CLiBBYm92ZSB0aGlzIHNpemUgd2Vcbi8vIHdpbGwgbm90IGRlY29kZSBhIGJ5dGVzIGxpc3QgaW50byBhIHN0cmluZy5cbmNvbnN0IE1BWF9CWVRFU19MSVNUX0xFTkdUSCA9IDEwMjQgKiAxMDI0ICogMjUwIC8gODtcblxuLy8gVGhlIG1heCByYXRpbyB0byBibGVuZCBzYWxpZW5jeSBtYXAgY29sb3JzIHdpdGggYSBncmF5c2NhbGVkIHZlcnNpb24gb2YgYW5cbi8vIGltYWdlIGZlYXR1cmUsIHRvIGNyZWF0ZSBhIHZpc3VhbGx5LXVzZWZ1bCBzYWxpZW5jeSBtYXNrIG9uIGFuIGltYWdlLlxuY29uc3QgSU1HX1NBTElFTkNZX01BWF9DT0xPUl9SQVRJTyA9IDAuNTtcblxuLy8gU3RyaW5nIHJldHVybmVkIHdoZW4gYSBkZWNvZGVkIHN0cmluZyBmZWF0dXJlIGlzIHRvbyBsYXJnZSB0byBkaXNwbGF5LlxuY29uc3QgTUFYX1NUUklOR19JTkRJQ0FUSU9OID0gJ1N0cmluZyB0b28gbGFyZ2UgdG8gZGlzcGxheSc7XG5cbi8vIEQzIHpvb20gZXh0ZW50IHJhbmdlIGZvciBpbWFnZSB6b29taW5nLlxuY29uc3QgWk9PTV9FWFRFTlQ6IFtudW1iZXIsIG51bWJlcl0gPSBbMSwgMjBdO1xuXG5jb25zdCBERUZBVUxUX1dJTkRPV19XSURUSCA9IDI1NjtcbmNvbnN0IERFRkFVTFRfV0lORE9XX0NFTlRFUiA9IDEyODtcblxuUG9seW1lcih7XG4gIGlzOiAndnotZXhhbXBsZS12aWV3ZXInLFxuICBwcm9wZXJ0aWVzOiB7XG4gICAgZXhhbXBsZToge3R5cGU6IE9iamVjdH0sXG4gICAgc2VyaWFsaXplZEV4YW1wbGU6IHt0eXBlOiBTdHJpbmcsIG9ic2VydmVyOiAndXBkYXRlRXhhbXBsZSd9LFxuICAgIHNlcmlhbGl6ZWRTZXFFeGFtcGxlOiB7dHlwZTogU3RyaW5nLCBvYnNlcnZlcjogJ3VwZGF0ZVNlcUV4YW1wbGUnfSxcbiAgICBqc29uOiB7dHlwZTogT2JqZWN0LCBvYnNlcnZlcjogJ2NyZWF0ZUV4YW1wbGVzRnJvbUpzb24nfSxcbiAgICBzYWxpZW5jeToge3R5cGU6IE9iamVjdCwgdmFsdWU6IHt9fSxcbiAgICBzYWxpZW5jeUpzb25TdHJpbmc6IHt0eXBlOiBTdHJpbmcsIG9ic2VydmVyOiAnaGF2ZVNhbGllbmN5SnNvbid9LFxuICAgIHJlYWRvbmx5OiB7dHlwZTogQm9vbGVhbiwgdmFsdWU6IGZhbHNlfSxcbiAgICBzZXFOdW1iZXI6IHt0eXBlOiBOdW1iZXIsIHZhbHVlOiAwLCBvYnNlcnZlcjogJ25ld1NlcU51bSd9LFxuICAgIGlzU2VxdWVuY2U6IEJvb2xlYW4sXG4gICAgY2hhbmdlQ2FsbGJhY2tUaW1lcjogTnVtYmVyLFxuICAgIGlnbm9yZUNoYW5nZTogQm9vbGVhbixcbiAgICBtaW5TYWw6IHt0eXBlOiBOdW1iZXIsIHZhbHVlOiAwfSxcbiAgICBtYXhTYWw6IHt0eXBlOiBOdW1iZXIsIHZhbHVlOiAwfSxcbiAgICBzaG93U2FsaWVuY3k6IHt0eXBlOiBCb29sZWFuLCB2YWx1ZTogdHJ1ZX0sXG4gICAgaW1hZ2VJbmZvOiB7dHlwZTogT2JqZWN0LCB2YWx1ZToge319LFxuICAgIHdpbmRvd1dpZHRoOiB7dHlwZTogTnVtYmVyLCB2YWx1ZTogREVGQVVMVF9XSU5ET1dfV0lEVEh9LFxuICAgIHdpbmRvd0NlbnRlcjoge3R5cGU6IE51bWJlciwgdmFsdWU6IERFRkFVTFRfV0lORE9XX0NFTlRFUn0sXG4gICAgc2FsaWVuY3lDdXRvZmY6IHt0eXBlOiBOdW1iZXIsIHZhbHVlOiAwfSxcbiAgICBoYXNJbWFnZToge3R5cGU6IEJvb2xlYW4sIHZhbHVlOiB0cnVlfSxcbiAgICBhbGxvd0ltYWdlQ29udHJvbHM6IHt0eXBlOiBCb29sZWFuLCB2YWx1ZTogZmFsc2V9LFxuICAgIGltYWdlU2NhbGVQZXJjZW50YWdlOiB7dHlwZTogTnVtYmVyLCB2YWx1ZTogMTAwfSxcbiAgICBmZWF0dXJlczoge3R5cGU6IE9iamVjdCwgY29tcHV0ZWQ6ICdnZXRGZWF0dXJlcyhleGFtcGxlKSd9LFxuICAgIGZlYXR1cmVzTGlzdDoge3R5cGU6IE9iamVjdCwgY29tcHV0ZWQ6ICdnZXRGZWF0dXJlc0xpc3QoZmVhdHVyZXMsIGNvbXBhcmVGZWF0dXJlcyknfSxcbiAgICBzZXFGZWF0dXJlczoge3R5cGU6IE9iamVjdCwgY29tcHV0ZWQ6ICdnZXRTZXFGZWF0dXJlcyhleGFtcGxlKSd9LFxuICAgIHNlcUZlYXR1cmVzTGlzdDoge3R5cGU6IE9iamVjdCwgY29tcHV0ZWQ6ICdnZXRGZWF0dXJlc0xpc3Qoc2VxRmVhdHVyZXMsIGNvbXBhcmVTZXFGZWF0dXJlcyknfSxcbiAgICBtYXhTZXFOdW1iZXI6IHt0eXBlOiBOdW1iZXIsIGNvbXB1dGVkOiAnZ2V0TWF4U2VxTnVtYmVyKHNlcUZlYXR1cmVzTGlzdCknfSxcbiAgICBjb2xvcnM6IHt0eXBlOiBPYmplY3QsIGNvbXB1dGVkOiAnZ2V0Q29sb3JzKHNhbGllbmN5KScsIG9ic2VydmVyOiAnY3JlYXRlTGVnZW5kJ30sXG4gICAgZGlzcGxheU1vZGU6IHt0eXBlOiBTdHJpbmcsIHZhbHVlOiAnZ3JpZCd9LFxuICAgIGZlYXR1cmVTZWFyY2hWYWx1ZToge3R5cGU6IFN0cmluZywgdmFsdWU6ICcnLCBub3RpZnk6IHRydWV9LFxuICAgIGZpbHRlcmVkRmVhdHVyZXNMaXN0OiB7dHlwZTogT2JqZWN0LCBjb21wdXRlZDogJ2dldEZpbHRlcmVkRmVhdHVyZXNMaXN0KGZlYXR1cmVzTGlzdCwgZmVhdHVyZVNlYXJjaFZhbHVlLCBzYWxpZW5jeSknfSxcbiAgICBmaWx0ZXJlZFNlcUZlYXR1cmVzTGlzdDoge3R5cGU6IE9iamVjdCwgY29tcHV0ZWQ6ICdnZXRGaWx0ZXJlZEZlYXR1cmVzTGlzdChzZXFGZWF0dXJlc0xpc3QsIGZlYXR1cmVTZWFyY2hWYWx1ZSwgc2FsaWVuY3kpJ30sXG4gICAgZm9jdXNlZEZlYXR1cmVOYW1lOiBTdHJpbmcsXG4gICAgZm9jdXNlZEZlYXR1cmVWYWx1ZUluZGV4OiBOdW1iZXIsXG4gICAgZm9jdXNlZFNlcU51bWJlcjogTnVtYmVyLFxuICAgIHNob3dEZWxldGVWYWx1ZUJ1dHRvbjoge3R5cGU6IEJvb2xlYW4sIHZhbHVlOiBmYWxzZX0sXG4gICAgZXhwYW5kZWRGZWF0dXJlczoge3R5cGU6IE9iamVjdCwgdmFsdWU6IHt9fSxcbiAgICBleHBhbmRBbGxGZWF0dXJlczoge3R5cGU6IEJvb2xlYW4sIHZhbHVlOiBmYWxzZX0sXG4gICAgemVyb0luZGV4OiB7dHlwZTogTnVtYmVyLCB2YWx1ZTogMH0sXG4gICAgY29tcGFyZUpzb246IHt0eXBlOiBPYmplY3QsIG9ic2VydmVyOiAnY3JlYXRlQ29tcGFyZUV4YW1wbGVzRnJvbUpzb24nfSxcbiAgICBjb21wYXJlRXhhbXBsZToge3R5cGU6IE9iamVjdH0sXG4gICAgY29tcGFyZUZlYXR1cmVzOiB7XG4gICAgICB0eXBlOiBPYmplY3QsXG4gICAgICBjb21wdXRlZDogJ2dldEZlYXR1cmVzKGNvbXBhcmVFeGFtcGxlKScsXG4gICAgICBvYnNlcnZlcjogJ3VwZGF0ZUNvbXBhcmVNb2RlJ1xuICAgIH0sXG4gICAgY29tcGFyZVNlcUZlYXR1cmVzOiB7XG4gICAgICB0eXBlOiBPYmplY3QsXG4gICAgICBjb21wdXRlZDogJ2dldFNlcUZlYXR1cmVzKGNvbXBhcmVFeGFtcGxlKScsXG4gICAgICBvYnNlcnZlcjogJ3VwZGF0ZUNvbXBhcmVNb2RlJ1xuICAgIH0sXG4gICAgY29tcGFyZU1vZGU6IEJvb2xlYW4sXG4gICAgY29tcGFyZUltYWdlSW5mbzoge3R5cGU6IE9iamVjdCwgdmFsdWU6IHt9fSxcbiAgICBjb21wYXJlVGl0bGU6IFN0cmluZyxcbiAgfSxcbiAgb2JzZXJ2ZXJzOiBbXG4gICAgJ2hhdmVTYWxpZW5jeShmaWx0ZXJlZEZlYXR1cmVzTGlzdCwgc2FsaWVuY3ksIGNvbG9ycywgc2hvd1NhbGllbmN5LCBzYWxpZW5jeUN1dG9mZiknLFxuICAgICdzZXFTYWxpZW5jeShzZXFOdW1iZXIsIHNlcUZlYXR1cmVzTGlzdCwgc2FsaWVuY3ksIGNvbG9ycywgc2hvd1NhbGllbmN5LCBzYWxpZW5jeUN1dG9mZiknLFxuICBdLFxuXG4gIGlzRXhwYW5kZWQ6IGZ1bmN0aW9uKGZlYXROYW1lOiBzdHJpbmcsIGV4cGFuZEFsbEZlYXR1cmVzOiBib29sZWFuKSB7XG4gICAgcmV0dXJuIHRoaXMuZXhwYW5kQWxsRmVhdHVyZXMgfHxcbiAgICAgICAgdGhpcy5zYW5pdGl6ZUZlYXR1cmUoZmVhdE5hbWUpIGluIHRoaXMuZXhwYW5kZWRGZWF0dXJlcztcbiAgfSxcblxuICB1cGRhdGVFeGFtcGxlOiBmdW5jdGlvbigpIHtcbiAgICB0aGlzLmRlc2VyaWFsaXplRXhhbXBsZSh0aGlzLnNlcmlhbGl6ZWRFeGFtcGxlLCBFeGFtcGxlLmRlc2VyaWFsaXplQmluYXJ5KTtcbiAgfSxcblxuICAvLyB0c2xpbnQ6ZGlzYWJsZS1uZXh0LWxpbmU6bm8tdW51c2VkLXZhcmlhYmxlIGNhbGxlZCBhcyBvYnNlcnZlclxuICB1cGRhdGVTZXFFeGFtcGxlOiBmdW5jdGlvbigpIHtcbiAgICB0aGlzLmRlc2VyaWFsaXplRXhhbXBsZShcbiAgICAgICAgdGhpcy5zZXJpYWxpemVkU2VxRXhhbXBsZSwgU2VxdWVuY2VFeGFtcGxlLmRlc2VyaWFsaXplQmluYXJ5KTtcbiAgfSxcblxuICAvKiBIZWxwZXIgbWV0aG9kIHRvIGVuY29kZSBhIHN0cmluZyBpbnRvIGEgdHlwZWQgYXJyYXkuICovXG4gIHN0cmluZ1RvVWludDhBcnJheTogZnVuY3Rpb24oc3RyOiBzdHJpbmcpIHtcbiAgICByZXR1cm4gbmV3ICh3aW5kb3cgYXMgYW55KS5UZXh0RW5jb2RlcigpLmVuY29kZShzdHIpO1xuICB9LFxuXG4gIGRlc2VyaWFsaXplRXhhbXBsZTogZnVuY3Rpb24oXG4gICAgICBzZXJpYWxpemVkUHJvdG86IHN0cmluZyxcbiAgICAgIGRlc2VyaWFsaXplcjogKGFycjogVWludDhBcnJheSkgPT4gRXhhbXBsZSB8IFNlcXVlbmNlRXhhbXBsZSkge1xuICAgIC8vIElmIGlnbm9yZUNoYW5nZSBpcyBzZXQgdGhlbiBkbyBub3QgZGVzZXJpYWxpemVkIGEgbmV3bHkgc2V0IHNlcmlhbGl6ZWRcbiAgICAvLyBleGFtcGxlLCB3aGljaCB3b3VsZCBjYXVzZSB0aGUgZW50aXJlIHZpc3VhbGl6YXRpb24gdG8gcmUtcmVuZGVyLlxuICAgIGlmICh0aGlzLmlnbm9yZUNoYW5nZSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBieXRlcyA9IHRoaXMuZGVjb2RlZFN0cmluZ1RvQ2hhckNvZGVzKGF0b2Ioc2VyaWFsaXplZFByb3RvKSk7XG4gICAgdGhpcy5leGFtcGxlID0gZGVzZXJpYWxpemVyKGJ5dGVzKTtcbiAgfSxcblxuICAvKiogQSBjb21wdXRlZCBtYXAgb2YgYWxsIHN0YW5kYXJkIGZlYXR1cmVzIGluIGFuIGV4YW1wbGUuICovXG4gIGdldEZlYXR1cmVzOiBmdW5jdGlvbihleGFtcGxlOiBFeGFtcGxlfFNlcXVlbmNlRXhhbXBsZSkge1xuICAgIC8vIFJlc2V0IG91ciBtYXBzIG9mIGltYWdlIGluZm9ybWF0aW9uIHdoZW4gYSBuZXcgZXhhbXBsZSBpcyBzdXBwbGllZC5cbiAgICB0aGlzLmltYWdlSW5mbyA9IHt9O1xuICAgIHRoaXMuaGFzSW1hZ2UgPSBmYWxzZTtcblxuICAgIGlmIChleGFtcGxlID09IG51bGwpIHtcbiAgICAgIHJldHVybiBuZXcgTWFwPHN0cmluZywgRmVhdHVyZUxpc3Q+KFtdKTtcbiAgICB9XG4gICAgaWYgKGV4YW1wbGUgaW5zdGFuY2VvZiBFeGFtcGxlKSB7XG4gICAgICB0aGlzLmlzU2VxdWVuY2UgPSBmYWxzZTtcbiAgICAgIGlmICghZXhhbXBsZS5oYXNGZWF0dXJlcygpKSB7XG4gICAgICAgIGV4YW1wbGUuc2V0RmVhdHVyZXMobmV3IEZlYXR1cmVzKCkpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIGV4YW1wbGUuZ2V0RmVhdHVyZXMoKSEuZ2V0RmVhdHVyZU1hcCgpO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLmlzU2VxdWVuY2UgPSB0cnVlO1xuICAgICAgaWYgKCFleGFtcGxlLmhhc0NvbnRleHQoKSkge1xuICAgICAgICBleGFtcGxlLnNldENvbnRleHQobmV3IEZlYXR1cmVzKCkpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIGV4YW1wbGUuZ2V0Q29udGV4dCgpIS5nZXRGZWF0dXJlTWFwKCk7XG4gICAgfVxuICB9LFxuXG4gIC8qKlxuICAgKiBBIGNvbXB1dGVkIGxpc3Qgb2YgYWxsIHN0YW5kYXJkIGZlYXR1cmVzIGluIGFuIGV4YW1wbGUsIGZvciBkcml2aW5nIHRoZVxuICAgKiBkaXNwbGF5LlxuICAgKi9cbiAgZ2V0RmVhdHVyZXNMaXN0OiBmdW5jdGlvbihmZWF0dXJlczogYW55LCBjb21wYXJlRmVhdHVyZXM6IGFueSkge1xuICAgIGNvbnN0IGZlYXR1cmVzTGlzdDogTmFtZUFuZEZlYXR1cmVbXSA9IFtdO1xuICAgIGNvbnN0IGZlYXR1cmVTZXQ6IHtba2V5OiBzdHJpbmddOiBib29sZWFufSA9IHt9O1xuICAgIGxldCBpdCA9IGZlYXR1cmVzLmtleXMoKTtcbiAgICBpZiAoaXQpIHtcbiAgICAgIGxldCBuZXh0ID0gaXQubmV4dCgpO1xuICAgICAgd2hpbGUgKCFuZXh0LmRvbmUpIHtcbiAgICAgICAgZmVhdHVyZXNMaXN0LnB1c2goXG4gICAgICAgICAgICB7bmFtZTogbmV4dC52YWx1ZSwgZmVhdHVyZTogZmVhdHVyZXMuZ2V0KG5leHQudmFsdWUpIX0pO1xuICAgICAgICBmZWF0dXJlU2V0W25leHQudmFsdWVdID0gdHJ1ZTtcbiAgICAgICAgbmV4dCA9IGl0Lm5leHQoKTtcbiAgICAgIH1cbiAgICB9XG4gICAgaXQgPSBjb21wYXJlRmVhdHVyZXMua2V5cygpO1xuICAgIGlmIChpdCkge1xuICAgICAgbGV0IG5leHQgPSBpdC5uZXh0KCk7XG4gICAgICB3aGlsZSAoIW5leHQuZG9uZSkge1xuICAgICAgICBpZiAobmV4dC52YWx1ZSBpbiBmZWF0dXJlU2V0KSB7XG4gICAgICAgICAgbmV4dCA9IGl0Lm5leHQoKTtcbiAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgfVxuICAgICAgICBmZWF0dXJlc0xpc3QucHVzaChcbiAgICAgICAgICAgIHtuYW1lOiBuZXh0LnZhbHVlLCBmZWF0dXJlOiBjb21wYXJlRmVhdHVyZXMuZ2V0KG5leHQudmFsdWUpIX0pO1xuICAgICAgICBmZWF0dXJlU2V0W25leHQudmFsdWVdID0gdHJ1ZTtcbiAgICAgICAgbmV4dCA9IGl0Lm5leHQoKTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIGZlYXR1cmVzTGlzdDtcbiAgfSxcblxuICAvKiogQSBjb21wdXRlZCBtYXAgb2YgYWxsIHNlcXVlbmNlIGZlYXR1cmVzIGluIGFuIGV4YW1wbGUuICovXG4gIGdldFNlcUZlYXR1cmVzOiBmdW5jdGlvbihleGFtcGxlOiBFeGFtcGxlfFNlcXVlbmNlRXhhbXBsZSkge1xuICAgIGlmIChleGFtcGxlID09IG51bGwgfHwgZXhhbXBsZSBpbnN0YW5jZW9mIEV4YW1wbGUpIHtcbiAgICAgIHJldHVybiBuZXcgTWFwPHN0cmluZywgRmVhdHVyZUxpc3Q+KFtdKTtcbiAgICB9XG4gICAgcmV0dXJuICh0aGlzLmV4YW1wbGUgYXMgU2VxdWVuY2VFeGFtcGxlKVxuICAgICAgICAuZ2V0RmVhdHVyZUxpc3RzKCkhLmdldEZlYXR1cmVMaXN0TWFwKCk7XG4gIH0sXG5cbiAgZ2V0RmlsdGVyZWRGZWF0dXJlc0xpc3Q6IGZ1bmN0aW9uKGZlYXR1cmVMaXN0OiBOYW1lQW5kRmVhdHVyZVtdLFxuICAgICAgc2VhcmNoVmFsdWU6IHN0cmluZywgc2FsaWVuY3k6IFNhbGllbmN5TWFwKSB7XG4gICAgbGV0IGZpbHRlcmVkID0gZmVhdHVyZUxpc3Q7XG4gICAgY29uc3QgY2hlY2tTYWwgPSBzYWxpZW5jeSAmJiBPYmplY3Qua2V5cyhzYWxpZW5jeSkubGVuZ3RoID4gMDtcbiAgICAvLyBDcmVhdGUgYSBkaWN0IG9mIGZlYXR1cmUgbmFtZXMgdG8gdGhlIHRvdGFsIGFic29sdXRlIHNhbGllbmN5IG9mIGFsbFxuICAgIC8vIGl0cyBmZWF0dXJlIHZhbHVlcywgdG8gc29ydCBmZWF0dXJlcyB3aXRoIHRoZSBtb3N0IHNhbGllbmN0IGZlYXR1cmVzIGF0XG4gICAgLy8gdGhlIHRvcC5cbiAgICBjb25zdCBzYWxpZW5jeVRvdGFscyA9IGNoZWNrU2FsID9cbiAgICAgICAgIE9iamVjdC5hc3NpZ24oe30sIC4uLk9iamVjdC5rZXlzKHNhbGllbmN5KS5tYXAoXG4gICAgICAgICAgIG5hbWUgPT4gKHtbbmFtZV06IHR5cGVvZiBzYWxpZW5jeVtuYW1lXSA9PSAnbnVtYmVyJyA/XG4gICAgICAgICAgICAgICAgICAgICAgTWF0aC5hYnMoc2FsaWVuY3lbbmFtZV0gYXMgbnVtYmVyKSA6XG4gICAgICAgICAgICAgICAgICAgICAgKHNhbGllbmN5W25hbWVdIGFzIEFycmF5PG51bWJlcj4pLnJlZHVjZSgodG90YWwsIGN1cikgPT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgTWF0aC5hYnModG90YWwpICsgTWF0aC5hYnMoY3VyKSAsIDApfSkpKSA6XG4gICAgICAgICAgICAgICAgICAgIHt9O1xuXG4gICAgaWYgKHNlYXJjaFZhbHVlICE9ICcnKSB7XG4gICAgICBjb25zdCByZSA9IG5ldyBSZWdFeHAoc2VhcmNoVmFsdWUsICdpJyk7XG4gICAgICBmaWx0ZXJlZCA9IGZlYXR1cmVMaXN0LmZpbHRlcihmZWF0dXJlID0+IHJlLnRlc3QoZmVhdHVyZS5uYW1lKSk7XG4gICAgfVxuICAgIGNvbnN0IHNvcnRlZCA9IGZpbHRlcmVkLnNvcnQoKGEsIGIpID0+IHtcbiAgICAgIGlmICh0aGlzLmlzSW1hZ2UoYS5uYW1lKSAmJiAhdGhpcy5pc0ltYWdlKGIubmFtZSkpIHtcbiAgICAgICAgcmV0dXJuIC0xO1xuICAgICAgfSBlbHNlIGlmICh0aGlzLmlzSW1hZ2UoYi5uYW1lKSAmJiAhdGhpcy5pc0ltYWdlKGEubmFtZSkpIHtcbiAgICAgICAgcmV0dXJuIDE7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBpZiAoY2hlY2tTYWwpIHtcbiAgICAgICAgICBpZiAoYS5uYW1lIGluIHNhbGllbmN5ICYmICEoYi5uYW1lIGluIHNhbGllbmN5KSkge1xuICAgICAgICAgICAgcmV0dXJuIC0xO1xuICAgICAgICAgIH0gZWxzZSBpZiAoYi5uYW1lIGluIHNhbGllbmN5ICYmICEoYS5uYW1lIGluIHNhbGllbmN5KSkge1xuICAgICAgICAgICAgcmV0dXJuIDE7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGNvbnN0IGRpZmYgPSBzYWxpZW5jeVRvdGFsc1tiLm5hbWVdIC0gc2FsaWVuY3lUb3RhbHNbYS5uYW1lXTtcbiAgICAgICAgICAgIGlmIChkaWZmICE9IDApIHtcbiAgICAgICAgICAgICAgcmV0dXJuIGRpZmY7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBhLm5hbWUubG9jYWxlQ29tcGFyZShiLm5hbWUpO1xuICAgICAgfVxuICAgIH0pO1xuICAgIHJldHVybiBzb3J0ZWQ7XG4gIH0sXG5cbiAgLyoqXG4gICAqIFJldHVybnMgdGhlIG1heGltdW0gc2VxdWVuY2UgbGVuZ3RoIGluIHRoZSBzZXF1ZW5jZSBleGFtcGxlLCBvciAtMSBpZlxuICAgKiB0aGVyZSBhcmUgbm8gc2VxdWVuY2VzLlxuICAgKi9cbiAgZ2V0TWF4U2VxTnVtYmVyOiBmdW5jdGlvbigpIHtcbiAgICBsZXQgbWF4ID0gLTE7XG4gICAgZm9yIChjb25zdCBmZWF0IG9mIHRoaXMuc2VxRmVhdHVyZXNMaXN0KSB7XG4gICAgICBjb25zdCBsaXN0ID0gZmVhdC5mZWF0dXJlIGFzIEZlYXR1cmVMaXN0O1xuICAgICAgaWYgKGxpc3QgJiYgbGlzdC5nZXRGZWF0dXJlTGlzdCgpLmxlbmd0aCAtIDEgPiBtYXgpIHtcbiAgICAgICAgbWF4ID0gbGlzdC5nZXRGZWF0dXJlTGlzdCgpLmxlbmd0aCAtIDE7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiBtYXg7XG4gIH0sXG5cbiAgaGF2ZVNhbGllbmN5SnNvbjogZnVuY3Rpb24oKSB7XG4gICAgdGhpcy5zYWxpZW5jeSA9IEpTT04ucGFyc2UodGhpcy5zYWxpZW5jeUpzb25TdHJpbmcpO1xuICB9LFxuXG4gIGdldENvbG9yczogZnVuY3Rpb24oKSB7XG4gICAgW3RoaXMubWluU2FsLCB0aGlzLm1heFNhbF0gPSB0aGlzLmdldE1pbk1heFNhbGllbmN5KHRoaXMuc2FsaWVuY3kpO1xuXG4gICAgcmV0dXJuIGQzLnNjYWxlTGluZWFyPHN0cmluZz4oKVxuICAgICAgICAuZG9tYWluKFt0aGlzLm1pblNhbCwgMCwgdGhpcy5tYXhTYWxdKVxuICAgICAgICAuaW50ZXJwb2xhdGUoQ09MT1JfSU5URVJQT0xBVE9SKVxuICAgICAgICAuY2xhbXAodHJ1ZSlcbiAgICAgICAgLnJhbmdlKFtcbiAgICAgICAgICBuZWdTYWxpZW5jeUNvbG9yLCBuZXV0cmFsU2FsaWVuY3lDb2xvcixcbiAgICAgICAgICBwb3NTYWxpZW5jeUNvbG9yXG4gICAgICAgIF0pO1xuICB9LFxuXG4gIHNlbGVjdEFsbDogZnVuY3Rpb24ocXVlcnk6IHN0cmluZykge1xuICAgIHJldHVybiBkMy5zZWxlY3RBbGwoXG4gICAgICBQb2x5bWVyLmRvbSh0aGlzLnJvb3QpLnF1ZXJ5U2VsZWN0b3JBbGwocXVlcnkpIGFzIGFueSk7XG4gIH0sXG5cbiAgaGF2ZVNhbGllbmN5OiBmdW5jdGlvbigpIHtcbiAgICBpZiAoIXRoaXMuZmlsdGVyZWRGZWF0dXJlc0xpc3QgfHwgIXRoaXMuc2FsaWVuY3kgfHxcbiAgICAgICAgT2JqZWN0LmtleXModGhpcy5zYWxpZW5jeSkubGVuZ3RoID09PSAwIHx8ICF0aGlzLmNvbG9ycykge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIC8vIFRPRE8oandleGxlcik6IEZpbmQgYSB3YXkgdG8gZG8gdGhpcyB3aXRob3V0IHJlcXVlc3RBbmltYXRpb25GcmFtZS5cbiAgICAvLyBJZiB0aGUgaW5wdXRzIGZvciB0aGUgZmVhdHVyZXMgaGF2ZSB5ZXQgdG8gYmUgcmVuZGVyZWQsIHdhaXQgdG9cbiAgICAvLyBwZXJmb3JtIHRoaXMgcHJvY2Vzc2luZy4gVGhlcmUgc2hvdWxkIGJlIGlucHV0cyBmb3IgYWxsIG5vbi1pbWFnZVxuICAgIC8vIGZlYXR1cmVzLlxuICAgIGlmICh0aGlzLnNlbGVjdEFsbCgnaW5wdXQudmFsdWUtcGlsbCcpLnNpemUoKSA8XG4gICAgICAgICh0aGlzLmZpbHRlcmVkRmVhdHVyZXNMaXN0Lmxlbmd0aCAtIE9iamVjdC5rZXlzKHRoaXMuaW1hZ2VJbmZvKS5sZW5ndGgpKSB7XG4gICAgICByZXF1ZXN0QW5pbWF0aW9uRnJhbWUoKCkgPT4gdGhpcy5oYXZlU2FsaWVuY3koKSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgLy8gUmVzZXQgYWxsIGJhY2tncm91bmRzIHRvIHRoZSBuZXV0cmFsIGNvbG9yLlxuICAgIHRoaXMuc2VsZWN0QWxsKCcudmFsdWUtcGlsbCcpLnN0eWxlKCdiYWNrZ3JvdW5kJywgbmV1dHJhbFNhbGllbmN5Q29sb3IpO1xuICAgIC8vIENvbG9yIHRoZSB0ZXh0IG9mIGVhY2ggaW5wdXQgZWxlbWVudCBvZiBlYWNoIGZlYXR1cmUgYWNjb3JkaW5nIHRvIHRoZVxuICAgIC8vIHByb3ZpZGVkIHNhbGllbmN5IGluZm9ybWF0aW9uLlxuICAgIGZvciAoY29uc3QgZmVhdCBvZiB0aGlzLmZpbHRlcmVkRmVhdHVyZXNMaXN0KSB7XG4gICAgICBjb25zdCB2YWwgPSB0aGlzLnNhbGllbmN5W2ZlYXQubmFtZV0gYXMgU2FsaWVuY3lWYWx1ZTtcbiAgICAgIC8vIElmIHRoZXJlIGlzIG5vIHNhbGllbmN5IGluZm9ybWF0aW9uIGZvciB0aGUgZmVhdHVyZSwgZG8gbm90IGNvbG9yIGl0LlxuICAgICAgaWYgKCF2YWwpIHtcbiAgICAgICAgY29udGludWU7XG4gICAgICB9XG4gICAgICBjb25zdCBjb2xvckZuID0gQXJyYXkuaXNBcnJheSh2YWwpID9cbiAgICAgICAgICAoZDoge30sIGk6IG51bWJlcikgPT4gdGhpcy5nZXRDb2xvckZvclNhbGllbmN5KHZhbFtpXSkgOlxuICAgICAgICAgICgpID0+IHRoaXMuZ2V0Q29sb3JGb3JTYWxpZW5jeSh2YWwpO1xuICAgICAgdGhpcy5zZWxlY3RBbGwoXG4gICAgICAgICAgICBgaW5wdXQuJHt0aGlzLnNhbml0aXplRmVhdHVyZShmZWF0Lm5hbWUpfS52YWx1ZS1waWxsYClcbiAgICAgICAgICAuc3R5bGUoJ2JhY2tncm91bmQnLFxuICAgICAgICAgICAgICB0aGlzLnNob3dTYWxpZW5jeSA/IGNvbG9yRm4gOiAoKSA9PiBuZXV0cmFsU2FsaWVuY3lDb2xvcik7XG5cbiAgICAgIC8vIENvbG9yIHRoZSBcIm1vcmUgZmVhdHVyZSB2YWx1ZXNcIiBidXR0b24gd2l0aCB0aGUgbW9zdCBleHRyZW1lIHNhbGllbmN5XG4gICAgICAvLyBvZiBhbnkgb2YgdGhlIGZlYXR1cmUgdmFsdWVzIGhpZGRlbiBiZWhpbmQgdGhlIGJ1dHRvbi5cbiAgICAgIGlmIChBcnJheS5pc0FycmF5KHZhbCkpIHtcbiAgICAgICAgY29uc3QgdmFsQXJyYXkgPSB2YWwgYXMgQXJyYXk8bnVtYmVyPjtcbiAgICAgICAgY29uc3QgbW9yZUJ1dHRvbiA9IHRoaXMuc2VsZWN0QWxsKFxuICAgICAgICAgIGBwYXBlci1idXR0b24uJHt0aGlzLnNhbml0aXplRmVhdHVyZShmZWF0Lm5hbWUpfS52YWx1ZS1waWxsYCk7XG4gICAgICAgIGxldCBtb3N0RXh0cmVtZVNhbCA9IDA7XG4gICAgICAgIGZvciAobGV0IGkgPSAxOyBpIDwgdmFsQXJyYXkubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICBpZiAoTWF0aC5hYnModmFsQXJyYXlbaV0pID4gTWF0aC5hYnMobW9zdEV4dHJlbWVTYWwpKSB7XG4gICAgICAgICAgICBtb3N0RXh0cmVtZVNhbCA9IHZhbEFycmF5W2ldO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBtb3JlQnV0dG9uLnN0eWxlKCdiYWNrZ3JvdW5kJywgdGhpcy5zaG93U2FsaWVuY3kgP1xuICAgICAgICAgICAgKCkgPT4gdGhpcy5nZXRDb2xvckZvclNhbGllbmN5KG1vc3RFeHRyZW1lU2FsKSA6XG4gICAgICAgICAgICAoKSA9PiBuZXV0cmFsU2FsaWVuY3lDb2xvcik7XG4gICAgICB9XG4gICAgfVxuICB9LFxuXG4gIC8qKlxuICAgKiBVcGRhdGVzIHRoZSBzYWxpZW5jeSBjb2xvcmluZyBvZiB0aGUgc2VxdWVudGlhbCBmZWF0dXJlcyB3aGVuIHRoZSBjdXJyZW50XG4gICAqIHNlcXVlbmNlIG51bWJlciBjaGFuZ2VzLlxuICAgKi9cbiAgbmV3U2VxTnVtOiBmdW5jdGlvbigpIHtcbiAgICB0aGlzLnNlcVNhbGllbmN5KCk7XG4gIH0sXG5cbiAgc2VxU2FsaWVuY3k6IGZ1bmN0aW9uKCkge1xuICAgIGlmICghdGhpcy5zZXFGZWF0dXJlc0xpc3QgfHwgIXRoaXMuc2FsaWVuY3kgfHxcbiAgICAgICAgT2JqZWN0LmtleXModGhpcy5zYWxpZW5jeSkubGVuZ3RoID09PSAwIHx8ICF0aGlzLmNvbG9ycykge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICAvLyBUT0RPKGp3ZXhsZXIpOiBGaW5kIGEgd2F5IHRvIGRvIHRoaXMgd2l0aG91dCByZXF1ZXN0QW5pbWF0aW9uRnJhbWUuXG4gICAgLy8gSWYgdGhlIHBhcGVyLWlucHV0cyBmb3IgdGhlIGZlYXR1cmVzIGhhdmUgeWV0IHRvIGJlIHJlbmRlcmVkLCB3YWl0IHRvXG4gICAgLy8gcGVyZm9ybSB0aGlzIHByb2Nlc3NpbmcuXG4gICAgaWYgKHRoaXMuc2VsZWN0QWxsKCcudmFsdWUgaW5wdXQnKS5zaXplKCkgPCB0aGlzLnNlcUZlYXR1cmVzTGlzdC5sZW5ndGgpIHtcbiAgICAgIHJlcXVlc3RBbmltYXRpb25GcmFtZSgoKSA9PiB0aGlzLnNlcVNhbGllbmN5KCkpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIC8vIENvbG9yIHRoZSB0ZXh0IG9mIGVhY2ggaW5wdXQgZWxlbWVudCBvZiBlYWNoIGZlYXR1cmUgYWNjb3JkaW5nIHRvIHRoZVxuICAgIC8vIHByb3ZpZGVkIHNhbGllbmN5IGluZm9ybWF0aW9uIGZvciB0aGUgY3VycmVudCBzZXF1ZW5jZSBudW1iZXIuXG4gICAgZm9yIChjb25zdCBmZWF0IG9mIHRoaXMuc2VxRmVhdHVyZXNMaXN0KSB7XG4gICAgICBjb25zdCB2YWxzOiBTYWxpZW5jeVZhbHVlW10gPSB0aGlzLnNhbGllbmN5W2ZlYXQubmFtZV0gYXMgU2FsaWVuY3lWYWx1ZVtdO1xuICAgICAgLy8gSWYgdGhlcmUgaXMgbm8gc2FsaWVuY3kgaW5mb3JtYXRpb24gZm9yIHRoZSBmZWF0dXJlLCBkbyBub3QgY29sb3IgaXQuXG4gICAgICBpZiAoIXZhbHMpIHtcbiAgICAgICAgY29udGludWU7XG4gICAgICB9XG4gICAgICBjb25zdCB2YWwgPSB2YWxzW3RoaXMuc2VxTnVtYmVyXTtcblxuICAgICAgY29uc3QgY29sb3JGbiA9IEFycmF5LmlzQXJyYXkodmFsKSA/XG4gICAgICAgICAgKGQ6IHt9LCBpOiBudW1iZXIpID0+IHRoaXMuZ2V0Q29sb3JGb3JTYWxpZW5jeSh2YWxbaV0pIDpcbiAgICAgICAgICAoKSA9PiB0aGlzLmdldENvbG9yRm9yU2FsaWVuY3kodmFsKTtcblxuICAgICAgdGhpcy5zZWxlY3RBbGwoXG4gICAgICAgICAgICBgLiR7dGhpcy5zYW5pdGl6ZUZlYXR1cmUoZmVhdC5uYW1lKX0gaW5wdXRgKVxuICAgICAgICAgIC5zdHlsZSgnY29sb3InLCB0aGlzLnNob3dTYWxpZW5jeSA/IGNvbG9yRm4gOiAoKSA9PiAnYmxhY2snKTtcbiAgICB9XG4gIH0sXG5cbiAgLyoqXG4gICAqIFJldHVybnMgYSBsaXN0IG9mIHRoZSBtaW4gYW5kIG1heCBzYWxpZW5jeSB2YWx1ZXMsIGNsaXBwZWQgYnkgdGhlXG4gICAqIHNhbGllbmN5IHJhdGlvLlxuICAgKi9cbiAgZ2V0TWluTWF4U2FsaWVuY3k6IGZ1bmN0aW9uKHNhbGllbmN5OiBTYWxpZW5jeU1hcCkge1xuICAgIGxldCBtaW4gPSBJbmZpbml0eTtcbiAgICBsZXQgbWF4ID0gLUluZmluaXR5O1xuXG4gICAgY29uc3QgY2hlY2tTYWxpZW5jaWVzID0gKHNhbGllbmNpZXM6IFNhbGllbmN5VmFsdWV8U2FsaWVuY3lWYWx1ZVtdKSA9PiB7XG4gICAgICBpZiAoQXJyYXkuaXNBcnJheShzYWxpZW5jaWVzKSkge1xuICAgICAgICBmb3IgKGNvbnN0IHMgb2Ygc2FsaWVuY2llcykge1xuICAgICAgICAgIGNoZWNrU2FsaWVuY2llcyhzKTtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgaWYgKHNhbGllbmNpZXMgPCBtaW4pIHtcbiAgICAgICAgICBtaW4gPSBzYWxpZW5jaWVzO1xuICAgICAgICB9XG4gICAgICAgIGlmIChzYWxpZW5jaWVzID4gbWF4KSB7XG4gICAgICAgICAgbWF4ID0gc2FsaWVuY2llcztcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH07XG4gICAgZm9yIChjb25zdCBmZWF0IGluIHNhbGllbmN5KSB7XG4gICAgICBpZiAoc2FsaWVuY3kuaGFzT3duUHJvcGVydHkoZmVhdCkpIHtcbiAgICAgICAgY2hlY2tTYWxpZW5jaWVzKHNhbGllbmN5W2ZlYXRdKTtcbiAgICAgIH1cbiAgICB9XG4gICAgbWluID0gTWF0aC5taW4oMCwgbWluKSAqIGNsaXBTYWxpZW5jeVJhdGlvO1xuICAgIG1heCA9IE1hdGgubWF4KDAsIG1heCkgKiBjbGlwU2FsaWVuY3lSYXRpbztcbiAgICByZXR1cm4gW21pbiwgbWF4XTtcbiAgfSxcblxuICAvKipcbiAgICogUmV0dXJucyBhIGxpc3Qgb2YgdGhlIGZlYXR1cmUgdmFsdWVzIGZvciBhIGZlYXR1cmUuIElmIGtlZXBCeXRlcyBpcyB0cnVlXG4gICAqIHRoZW4gcmV0dXJuIHRoZSByYXcgYnl0ZXMuIE90aGVyd2lzZSBjb252ZXJ0IHRoZW0gdG8gYSByZWFkYWJsZSBzdHJpbmcuXG4gICAqL1xuICBnZXRGZWF0dXJlVmFsdWVzOiBmdW5jdGlvbihcbiAgICAgIGZlYXR1cmU6IHN0cmluZywga2VlcEJ5dGVzPzogYm9vbGVhbixcbiAgICAgIGlzSW1hZ2U/OiBib29sZWFuLCBjb21wYXJlVmFsdWVzPzogYm9vbGVhbik6IEFycmF5PHN0cmluZ3xudW1iZXI+IHtcbiAgICBjb25zdCBmZWF0ID0gY29tcGFyZVZhbHVlcyA/XG4gICAgICB0aGlzLmNvbXBhcmVGZWF0dXJlcy5nZXQoZmVhdHVyZSkgOlxuICAgICAgdGhpcy5mZWF0dXJlcy5nZXQoZmVhdHVyZSk7XG4gICAgaWYgKCFmZWF0KSB7XG4gICAgICByZXR1cm4gW107XG4gICAgfVxuICAgIGlmIChmZWF0LmdldEJ5dGVzTGlzdCgpKSB7XG4gICAgICBpZiAoIWtlZXBCeXRlcykge1xuICAgICAgICBjb25zdCB2YWxzID0gZmVhdC5nZXRCeXRlc0xpc3QoKSEuZ2V0VmFsdWVMaXN0X2FzVTgoKS5tYXAoXG4gICAgICAgICAgICB1OGFycmF5ID0+IHRoaXMuZGVjb2RlQnl0ZXNMaXN0U3RyaW5nKHU4YXJyYXksIGlzSW1hZ2UpKTtcbiAgICAgICAgcmV0dXJuIHZhbHM7XG4gICAgICB9XG4gICAgICByZXR1cm4gZmVhdC5nZXRCeXRlc0xpc3QoKSEuZ2V0VmFsdWVMaXN0KCkuc2xpY2UoKTtcbiAgICB9IGVsc2UgaWYgKGZlYXQuZ2V0SW50NjRMaXN0KCkpIHtcbiAgICAgIHJldHVybiBmZWF0LmdldEludDY0TGlzdCgpIS5nZXRWYWx1ZUxpc3QoKS5zbGljZSgpO1xuICAgIH0gZWxzZSBpZiAoZmVhdC5nZXRGbG9hdExpc3QoKSkge1xuICAgICAgcmV0dXJuIGZlYXQuZ2V0RmxvYXRMaXN0KCkhLmdldFZhbHVlTGlzdCgpLnNsaWNlKCk7XG4gICAgfVxuICAgIHJldHVybiBbXTtcbiAgfSxcblxuICAvKipcbiAgICogUmV0dXJucyBhIGxpc3Qgb2YgdGhlIGZlYXR1cmUgdmFsdWVzIGZvciBhIHRoZSBjb21wYXJlZCBleGFtcGxlIGZvclxuICAgKiBhIGZlYXR1cmUuXG4gICAqL1xuICBnZXRDb21wYXJlRmVhdHVyZVZhbHVlczogZnVuY3Rpb24oXG4gICAgZmVhdHVyZTogc3RyaW5nLCBrZWVwQnl0ZXM/OiBib29sZWFuLFxuICAgIGlzSW1hZ2U/OiBib29sZWFuKTogQXJyYXk8c3RyaW5nfG51bWJlcj4ge1xuICByZXR1cm4gdGhpcy5nZXRGZWF0dXJlVmFsdWVzKGZlYXR1cmUsIGtlZXBCeXRlcywgaXNJbWFnZSwgdHJ1ZSk7XG59LFxuXG4gIC8qKiBSZXR1cm5zIHRoZSBmaXJzdCBmZWF0dXJlIHZhbHVlIGZvciBhIGZlYXR1cmUuICovXG4gIGdldEZpcnN0RmVhdHVyZVZhbHVlOiBmdW5jdGlvbihmZWF0dXJlOiBzdHJpbmcpIHtcbiAgICByZXR1cm4gdGhpcy5nZXRGZWF0dXJlVmFsdWVzKGZlYXR1cmUpWzBdO1xuICB9LFxuXG4gIC8qKiBSZXR1cm5zIHRoZSBmaXJzdCBmZWF0dXJlIHZhbHVlIGZvciBhIGNvbXBhcmVkIGV4YW1wbGUgZm9yIGEgZmVhdHVyZS4gKi9cbiAgZ2V0Rmlyc3RDb21wYXJlRmVhdHVyZVZhbHVlOiBmdW5jdGlvbihmZWF0dXJlOiBzdHJpbmcpIHtcbiAgICByZXR1cm4gdGhpcy5nZXRDb21wYXJlRmVhdHVyZVZhbHVlcyhmZWF0dXJlKVswXTtcbiAgfSxcblxuICAvKiogUmV0dXJucyBpZiBhIGZlYXR1cmUgaGFzIG1vcmUgdGhhbiBvbmUgZmVhdHVyZSB2YWx1ZS4gKi9cbiAgZmVhdHVyZUhhc011bHRpcGxlVmFsdWVzOiBmdW5jdGlvbihmZWF0dXJlOiBzdHJpbmcpIHtcbiAgICByZXR1cm4gdGhpcy5nZXRGZWF0dXJlVmFsdWVzKGZlYXR1cmUpLmxlbmd0aCA+IDE7XG4gIH0sXG5cbiAgLyoqXG4gICAqIFJldHVybnMgaWYgYSBmZWF0dXJlIGhhcyBtb3JlIHRoYW4gb25lIGZlYXR1cmUgdmFsdWUgaW4gdGhlIGNvbXBhcmVkXG4gICAqIGV4YW1wbGUuXG4gICAqL1xuICBjb21wYXJlRmVhdHVyZUhhc011bHRpcGxlVmFsdWVzOiBmdW5jdGlvbihmZWF0dXJlOiBzdHJpbmcpIHtcbiAgICByZXR1cm4gdGhpcy5nZXRDb21wYXJlRmVhdHVyZVZhbHVlcyhmZWF0dXJlKS5sZW5ndGggPiAxO1xuICB9LFxuXG4gIC8qKlxuICAgKiBSZXR1cm5zIGEgbGlzdCBvZiB0aGUgc2VxdWVuY2UgZmVhdHVyZSB2YWx1ZXMgZm9yIGEgZmVhdHVyZSBmb3IgYSBnaXZlblxuICAgKiBzZXF1ZW5jZSBudW1iZXIuIElmIGtlZXBCeXRlcyBpcyB0cnVlIHRoZW4gcmV0dXJuIHRoZSByYXcgYnl0ZXMuIE90aGVyd2lzZVxuICAgKiBjb252ZXJ0IHRoZW0gdG8gYSByZWFkYWJsZSBzdHJpbmcuXG4gICAqL1xuICBnZXRTZXFGZWF0dXJlVmFsdWVzOiBmdW5jdGlvbihcbiAgICAgIGZlYXR1cmU6IHN0cmluZywgc2VxTnVtOiBudW1iZXIsIGtlZXBCeXRlcz86IGJvb2xlYW4sIGlzSW1hZ2U/OiBib29sZWFuLFxuICAgICAgY29tcGFyZVZhbHVlcz86IGJvb2xlYW4pIHtcbiAgICBjb25zdCBmZWF0bGlzdGhvbGRlciA9IGNvbXBhcmVWYWx1ZXMgP1xuICAgICAgICB0aGlzLmNvbXBhcmVTZXFGZWF0dXJlcyEuZ2V0KGZlYXR1cmUpIDpcbiAgICAgICAgdGhpcy5zZXFGZWF0dXJlcyEuZ2V0KGZlYXR1cmUpO1xuICAgIGlmICghZmVhdGxpc3Rob2xkZXIpIHtcbiAgICAgIHJldHVybiBbXTtcbiAgICB9XG4gICAgY29uc3QgZmVhdGxpc3QgPSBmZWF0bGlzdGhvbGRlci5nZXRGZWF0dXJlTGlzdCgpO1xuICAgIC8vIEl0IGlzIHBvc3NpYmxlIHRoYXQgdGhlcmUgYXJlIGZlYXR1cmVzIHRoYXQgZG8gbm90IGhhdmUgc2VxdWVuY2UgbGVuZ3Roc1xuICAgIC8vIGFzIGxvbmcgYXMgdGhlIGxvbmdlc3Qgc2VxdWVuY2UgbGVuZ3RoIGluIHRoZSBleGFtcGxlLiAgSW4gdGhpcyBjYXNlLFxuICAgIC8vIHNob3cgYW4gZW1wdHkgZmVhdHVyZSB2YWx1ZSBsaXN0IGZvciB0aGF0IGZlYXR1cmUuXG4gICAgaWYgKCFmZWF0bGlzdCB8fCBmZWF0bGlzdC5sZW5ndGggPD0gc2VxTnVtKSB7XG4gICAgICByZXR1cm4gW107XG4gICAgfVxuICAgIGNvbnN0IGZlYXQgPSBmZWF0bGlzdFtzZXFOdW1dO1xuICAgIGlmICghZmVhdCkge1xuICAgICAgcmV0dXJuIFtdO1xuICAgIH1cbiAgICBpZiAoZmVhdC5nZXRCeXRlc0xpc3QoKSkge1xuICAgICAgaWYgKCFrZWVwQnl0ZXMpIHtcbiAgICAgICAgcmV0dXJuIGZlYXQuZ2V0Qnl0ZXNMaXN0KCkhLmdldFZhbHVlTGlzdF9hc1U4KCkubWFwKFxuICAgICAgICAgICAgdThhcnJheSA9PiB0aGlzLmRlY29kZUJ5dGVzTGlzdFN0cmluZyh1OGFycmF5LCBpc0ltYWdlKSk7XG4gICAgICB9XG4gICAgICByZXR1cm4gZmVhdC5nZXRCeXRlc0xpc3QoKSEuZ2V0VmFsdWVMaXN0KCk7XG4gICAgfSBlbHNlIGlmIChmZWF0LmdldEludDY0TGlzdCgpKSB7XG4gICAgICByZXR1cm4gZmVhdC5nZXRJbnQ2NExpc3QoKSEuZ2V0VmFsdWVMaXN0KCk7XG4gICAgfSBlbHNlIGlmIChmZWF0LmdldEZsb2F0TGlzdCgpKSB7XG4gICAgICByZXR1cm4gZmVhdC5nZXRGbG9hdExpc3QoKSEuZ2V0VmFsdWVMaXN0KCk7XG4gICAgfVxuICAgIHJldHVybiBbXTtcbiAgfSxcblxuICAvKipcbiAgICogUmV0dXJucyBhIGxpc3Qgb2YgdGhlIHNlcXVlbmNlIGZlYXR1cmUgdmFsdWVzIGZvciBhIGZlYXR1cmUgZm9yIGEgZ2l2ZW5cbiAgICogc2VxdWVuY2UgbnVtYmVyIG9mIHRoZSBjb21wYXJlZCBleGFtcGxlLlxuICAgKi9cbiAgZ2V0Q29tcGFyZVNlcUZlYXR1cmVWYWx1ZXM6IGZ1bmN0aW9uKFxuICAgICAgZmVhdHVyZTogc3RyaW5nLCBzZXFOdW06IG51bWJlciwgIGtlZXBCeXRlcz86IGJvb2xlYW4sXG4gICAgICBpc0ltYWdlPzogYm9vbGVhbik6IEFycmF5PHN0cmluZ3xudW1iZXI+IHtcbiAgICByZXR1cm4gdGhpcy5nZXRTZXFGZWF0dXJlVmFsdWVzKGZlYXR1cmUsIHNlcU51bSwga2VlcEJ5dGVzLCBpc0ltYWdlLCB0cnVlKTtcbiAgfSxcblxuICAvKiogUmV0dXJucyB0aGUgZmlyc3QgZmVhdHVyZSB2YWx1ZSBmb3IgYSBzZXF1ZW5jZSBmZWF0dXJlLiAqL1xuICBnZXRGaXJzdFNlcUZlYXR1cmVWYWx1ZTogZnVuY3Rpb24oZmVhdHVyZTogc3RyaW5nLCBzZXFOdW06IG51bWJlcikge1xuICAgIHJldHVybiB0aGlzLmdldFNlcUZlYXR1cmVWYWx1ZXMoZmVhdHVyZSwgc2VxTnVtKVswXTtcbiAgfSxcblxuICAvKiogUmV0dXJucyB0aGUgZmlyc3QgZmVhdHVyZSB2YWx1ZSBmb3IgdGhlIGNvbXBhcmVkIGV4YW1wbGUgZm9yIGEgZmVhdHVyZS4gKi9cbiAgZ2V0Rmlyc3RTZXFDb21wYXJlRmVhdHVyZVZhbHVlOiBmdW5jdGlvbihmZWF0dXJlOiBzdHJpbmcsIHNlcU51bTogbnVtYmVyKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0Q29tcGFyZVNlcUZlYXR1cmVWYWx1ZXMoZmVhdHVyZSwgc2VxTnVtKVswXTtcbiAgfSxcblxuICAvKiogUmV0dXJucyBpZiBhIHNlcXVlbmNlIGZlYXR1cmUgaGFzIG1vcmUgdGhhbiBvbmUgZmVhdHVyZSB2YWx1ZS4gKi9cbiAgc2VxRmVhdHVyZUhhc011bHRpcGxlVmFsdWVzOiBmdW5jdGlvbihmZWF0dXJlOiBzdHJpbmcsIHNlcU51bTogbnVtYmVyKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0U2VxRmVhdHVyZVZhbHVlcyhmZWF0dXJlLCBzZXFOdW0pLmxlbmd0aCA+IDE7XG4gIH0sXG5cbiAgLyoqXG4gICAqIFJldHVybnMgaWYgYSBzZXF1ZW5jZSBmZWF0dXJlIGhhcyBtb3JlIHRoYW4gb25lIGZlYXR1cmUgdmFsdWUgaW4gdGhlXG4gICAqIGNvbXBhcmVkIGV4YW1wbGUuXG4gICAqL1xuICBjb21wYXJlU2VxRmVhdHVyZUhhc011bHRpcGxlVmFsdWVzOiBmdW5jdGlvbihcbiAgICAgIGZlYXR1cmU6IHN0cmluZywgc2VxTnVtOiBudW1iZXIpIHtcbiAgICByZXR1cm4gdGhpcy5nZXRDb21wYXJlU2VxRmVhdHVyZVZhbHVlcyhmZWF0dXJlLCBzZXFOdW0pLmxlbmd0aCA+IDE7XG4gIH0sXG5cbiAgLyoqXG4gICAqIERlY29kZXMgYSBsaXN0IG9mIGJ5dGVzIGludG8gYSByZWFkYWJsZSBzdHJpbmcsIHRyZWF0aW5nIHRoZSBieXRlcyBhc1xuICAgKiB1bmljb2RlIGNoYXIgY29kZXMuIElmIHNpbmdsZUJ5dGVDaGFycyBpcyB0cnVlLCB0aGVuIHRyZWF0IGVhY2ggYnl0ZSBhcyBpdHNcbiAgICogb3duIGNoYXIsIHdoaWNoIGlzIG5lY2Vzc2FyeSBmb3IgaW1hZ2Ugc3RyaW5ncyBhbmQgc2VyaWFsaXplZCBwcm90b3MuXG4gICAqIFJldHVybnMgYW4gZW1wdHkgc3RyaW5nIGZvciBhcnJheXMgb3ZlciAyNTBNQiBpbiBzaXplLCB3aGljaCBzaG91bGQgbm90XG4gICAqIGJlIGFuIGlzc3VlIGluIHByYWN0aWNlIHdpdGggdGYuRXhhbXBsZXMuXG4gICAqL1xuICBkZWNvZGVCeXRlc0xpc3RTdHJpbmc6IGZ1bmN0aW9uKFxuICAgICAgYnl0ZXM6IFVpbnQ4QXJyYXksIHNpbmdsZUJ5dGVDaGFycz86IGJvb2xlYW4pIHtcbiAgICBpZiAoYnl0ZXMubGVuZ3RoID4gTUFYX0JZVEVTX0xJU1RfTEVOR1RIKSB7XG4gICAgICByZXR1cm4gTUFYX1NUUklOR19JTkRJQ0FUSU9OO1xuICAgIH1cbiAgICByZXR1cm4gc2luZ2xlQnl0ZUNoYXJzID8gdGhpcy5kZWNvZGVCeXRlc0xpc3RUb1N0cmluZyhieXRlcykgOlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuZXcgKHdpbmRvdyBhcyBhbnkpLlRleHREZWNvZGVyKCkuZGVjb2RlKGJ5dGVzKTtcbiAgfSxcblxuICBpc0J5dGVzRmVhdHVyZTogZnVuY3Rpb24oZmVhdHVyZTogc3RyaW5nKSB7XG4gICAgY29uc3QgZmVhdCA9IHRoaXMuZmVhdHVyZXMuZ2V0KGZlYXR1cmUpO1xuICAgIGlmIChmZWF0KSB7XG4gICAgICBpZiAoZmVhdC5oYXNCeXRlc0xpc3QoKSkge1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgIH1cbiAgICB9XG4gICAgY29uc3Qgc2VxZmVhdCA9IHRoaXMuc2VxRmVhdHVyZXMuZ2V0KGZlYXR1cmUpO1xuICAgIGlmIChzZXFmZWF0KSB7XG4gICAgICBpZiAoc2VxZmVhdC5nZXRGZWF0dXJlTGlzdCgpWzBdLmhhc0J5dGVzTGlzdCgpKSB7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gZmFsc2U7XG4gIH0sXG5cbiAgLyoqXG4gICAqIEdldHMgdGhlIGFsbG93ZWQgaW5wdXQgdHlwZSBmb3IgYSBmZWF0dXJlIHZhbHVlLCBhY2NvcmRpbmcgdG8gaXRzXG4gICAqIGZlYXR1cmUgdHlwZS5cbiAgICovXG4gIGdldElucHV0VHlwZTogZnVuY3Rpb24oZmVhdHVyZTogc3RyaW5nKSB7XG4gICAgY29uc3QgZmVhdCA9IHRoaXMuZmVhdHVyZXMuZ2V0KGZlYXR1cmUpO1xuICAgIGlmIChmZWF0KSB7XG4gICAgICBpZiAoZmVhdC5nZXRJbnQ2NExpc3QoKSB8fCBmZWF0LmdldEZsb2F0TGlzdCgpKSB7XG4gICAgICAgIHJldHVybiAnbnVtYmVyJ1xuICAgICAgfVxuICAgIH1cbiAgICBjb25zdCBzZXFmZWF0ID0gdGhpcy5zZXFGZWF0dXJlcy5nZXQoZmVhdHVyZSk7XG4gICAgaWYgKHNlcWZlYXQpIHtcbiAgICAgIGlmIChzZXFmZWF0LmdldEZlYXR1cmVMaXN0KClbMF0uZ2V0SW50NjRMaXN0KCkgfHxcbiAgICAgICAgICBzZXFmZWF0LmdldEZlYXR1cmVMaXN0KClbMF0uZ2V0RmxvYXRMaXN0KCkpIHtcbiAgICAgICAgcmV0dXJuICdudW1iZXInO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gJ3RleHQnO1xuICB9LFxuXG4gIC8qKlxuICAgKiBSZXR1cm5zIHRoZSBmZWF0dXJlIG9iamVjdCBmcm9tIHRoZSBwcm92aWRlZCBqc29uIGF0dHJpYnV0ZSBmb3IgYSBnaXZlblxuICAgKiBmZWF0dXJlIG5hbWUuXG4gICAqL1xuICBnZXRKc29uRmVhdHVyZTogZnVuY3Rpb24oZmVhdDogc3RyaW5nKSB7XG4gICAgaWYgKCF0aGlzLmpzb24pIHtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cblxuICAgIGlmICh0aGlzLmpzb24uZmVhdHVyZXMgJiYgdGhpcy5qc29uLmZlYXR1cmVzLmZlYXR1cmUpIHtcbiAgICAgIGNvbnN0IGpzb25GZWF0dXJlID0gdGhpcy5qc29uLmZlYXR1cmVzLmZlYXR1cmVbZmVhdF07XG4gICAgICBpZiAoanNvbkZlYXR1cmUpIHtcbiAgICAgICAgcmV0dXJuIGpzb25GZWF0dXJlO1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAodGhpcy5qc29uLmNvbnRleHQgJiYgdGhpcy5qc29uLmNvbnRleHQuZmVhdHVyZSkge1xuICAgICAgY29uc3QganNvbkZlYXR1cmUgPSB0aGlzLmpzb24uY29udGV4dC5mZWF0dXJlW2ZlYXRdO1xuICAgICAgaWYgKGpzb25GZWF0dXJlKSB7XG4gICAgICAgIHJldHVybiBqc29uRmVhdHVyZTtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKHRoaXMuanNvbi5mZWF0dXJlTGlzdHMgJiYgdGhpcy5qc29uLmZlYXR1cmVMaXN0cy5mZWF0dXJlTGlzdCkge1xuICAgICAgcmV0dXJuIHRoaXMuanNvbi5mZWF0dXJlTGlzdHMuZmVhdHVyZUxpc3RbZmVhdF07XG4gICAgfVxuICAgIHJldHVybiBudWxsO1xuICB9LFxuXG4gIC8qKlxuICAgKiBSZXR1cm5zIHRoZSB2YWx1ZSBsaXN0IGZyb20gdGhlIHByb3ZpZGVkIGpzb24gYXR0cmlidXRlIGZvciBhIGdpdmVuXG4gICAqIGZlYXR1cmUgbmFtZSBhbmQgc2VxdWVuY2UgbnVtYmVyICh3aGVuIHRoZSBmZWF0dXJlIGlzIHNlcXVlbnRpYWwpLiBUaGVcbiAgICogc2VxdWVuY2UgbnVtYmVyIHNob3VsZCBiZSBOYU4gZm9yIG5vbi1zZXF1ZW50aWFsIGZlYXR1cmVzLlxuICAgKi9cbiAgZ2V0SnNvblZhbHVlTGlzdDogZnVuY3Rpb24oZmVhdDogc3RyaW5nLCBzZXFOdW06IG51bWJlcikge1xuICAgIC8vIEdldCB0aGUgZmVhdHVyZSBvYmplY3QgZm9yIHRoZSBmZWF0dXJlIG5hbWUgcHJvdmlkZWQuXG4gICAgbGV0IGZlYXR1cmUgPSB0aGlzLmdldEpzb25GZWF0dXJlKGZlYXQpO1xuICAgIGlmICghZmVhdHVyZSkge1xuICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuXG4gICAgLy8gSWYgYSBzZXF1ZW50aWFsIGZlYXR1cmUsIGdldCB0aGUgZmVhdHVyZSBlbnRyeSBmb3IgdGhlIGdpdmVuIHNlcXVlbmNlXG4gICAgLy8gbnVtYmVyLlxuICAgIGlmICghaXNOYU4oc2VxTnVtKSkge1xuICAgICAgZmVhdHVyZSA9IGZlYXR1cmUuZmVhdHVyZVtzZXFOdW1dO1xuICAgIH1cblxuICAgIGNvbnN0IHZhbHVlTGlzdCA9XG4gICAgICAgIGZlYXR1cmUuYnl0ZXNMaXN0IHx8IGZlYXR1cmUuaW50NjRMaXN0IHx8IGZlYXR1cmUuZmxvYXRMaXN0O1xuICAgIHJldHVybiB2YWx1ZUxpc3QgPyB2YWx1ZUxpc3QudmFsdWUgOiBudWxsO1xuICB9LFxuXG4gIC8qKlxuICAgKiBGcm9tIGFuIGV2ZW50LCBmaW5kcyB0aGUgZmVhdHVyZSwgdmFsdWUgbGlzdCBpbmRleCBhbmQgc2VxdWVuY2UgbnVtYmVyXG4gICAqIHRoYXQgdGhlIGV2ZW50IGNvcnJlc3BvbmRzIHRvLlxuICAgKi9cbiAgZ2V0RGF0YUZyb21FdmVudDogZnVuY3Rpb24oZXZlbnQ6IEV2ZW50KTogRGF0YUZyb21Db250cm9sIHtcbiAgICBsZXQgZWxlbSA9IGV2ZW50LnRhcmdldCBhcyBIVE1MRWxlbWVudFdpdGhEYXRhO1xuICAgIC8vIEdldCB0aGUgY29udHJvbCB0aGF0IGNvbnRhaW5zIHRoZSBldmVudCB0YXJnZXQuIFRoZSBjb250cm9sIHdpbGwgaGF2ZSBpdHNcbiAgICAvLyBkYXRhLWZlYXR1cmUgYXR0cmlidXRlIHNldC5cbiAgICB3aGlsZSAoZWxlbS5kYXRhRmVhdHVyZSA9PSBudWxsKSB7XG4gICAgICBpZiAoIWVsZW0ucGFyZW50RWxlbWVudCkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0NvdWxkIG5vdCBmaW5kIGFuY2VzdG9yIGNvbnRyb2wgZWxlbWVudCcpO1xuICAgICAgfVxuICAgICAgZWxlbSA9IGVsZW0ucGFyZW50RWxlbWVudCBhcyBIVE1MRWxlbWVudFdpdGhEYXRhO1xuICAgIH1cbiAgICByZXR1cm4ge1xuICAgICAgZmVhdHVyZTogZWxlbS5kYXRhRmVhdHVyZSxcbiAgICAgIHZhbHVlSW5kZXg6IGVsZW0uZGF0YUluZGV4LFxuICAgICAgc2VxTnVtOiBlbGVtLmRhdGFTZXFOdW1cbiAgICB9O1xuICB9LFxuXG4gIC8qKiBHZXRzIHRoZSBGZWF0dXJlIG9iamVjdCBjb3JyZXNwb25kaW5nIHRvIHRoZSBwcm92aWRlZCBEYXRhRnJvbUNvbnRyb2wuICovXG4gIGdldEZlYXR1cmVGcm9tRGF0YTogZnVuY3Rpb24oZGF0YTogRGF0YUZyb21Db250cm9sKTogRmVhdHVyZXx1bmRlZmluZWQge1xuICAgIC8vIElmIHRoZXJlIGlzIG5vIHNlcXVlbmNlIG51bWJlciwgdGhlbiBpdCBpcyBhIHN0YW5kYXJkIGZlYXR1cmUsIG5vdCBhXG4gICAgLy8gc2VxdWVudGlhbCBmZWF0dXJlLlxuICAgIGlmIChpc05hTihkYXRhLnNlcU51bSkpIHtcbiAgICAgIHJldHVybiB0aGlzLmZlYXR1cmVzLmdldChkYXRhLmZlYXR1cmUpO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25zdCBmZWF0dXJlTGlzdHMgPSB0aGlzLnNlcUZlYXR1cmVzLmdldChkYXRhLmZlYXR1cmUpO1xuICAgICAgaWYgKCFmZWF0dXJlTGlzdHMpIHtcbiAgICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGZlYXR1cmVMaXN0ID0gZmVhdHVyZUxpc3RzLmdldEZlYXR1cmVMaXN0KCk7XG4gICAgICBpZiAoIWZlYXR1cmVMaXN0KSB7XG4gICAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgICB9XG4gICAgICByZXR1cm4gZmVhdHVyZUxpc3RbZGF0YS5zZXFOdW1dO1xuICAgIH1cbiAgfSxcblxuICAvKiogR2V0cyB0aGUgdmFsdWUgbGlzdCBjb3JyZXNwb25kaW5nIHRvIHRoZSBwcm92aWRlZCBEYXRhRnJvbUNvbnRyb2wuICovXG4gIGdldFZhbHVlTGlzdEZyb21EYXRhOiBmdW5jdGlvbihkYXRhOiBEYXRhRnJvbUNvbnRyb2wpOiBBcnJheTxzdHJpbmd8bnVtYmVyPiB7XG4gICAgLy8gSWYgdGhlcmUgaXMgbm8gc2VxdWVuY2UgbnVtYmVyLCB0aGVuIGl0IGlzIGEgc3RhbmRhcmQgZmVhdHVyZSwgbm90IGFcbiAgICAvLyBzZXF1ZW50aWFsIGZlYXR1cmUuXG4gICAgaWYgKGlzTmFOKGRhdGEuc2VxTnVtKSkge1xuICAgICAgcmV0dXJuIHRoaXMuZ2V0RmVhdHVyZVZhbHVlcyhkYXRhLmZlYXR1cmUsIHRydWUpO1xuICAgIH0gZWxzZSB7XG4gICAgICByZXR1cm4gdGhpcy5nZXRTZXFGZWF0dXJlVmFsdWVzKGRhdGEuZmVhdHVyZSwgZGF0YS5zZXFOdW0sIHRydWUpO1xuICAgIH1cbiAgfSxcblxuICAvKiogU2V0cyB0aGUgdmFsdWUgbGlzdCBvbiB0aGUgcHJvdmlkZWQgZmVhdHVyZS4gKi9cbiAgc2V0RmVhdHVyZVZhbHVlczogZnVuY3Rpb24oZmVhdDogRmVhdHVyZSwgdmFsdWVzOiBBcnJheTxzdHJpbmd8bnVtYmVyPikge1xuICAgIGNvbnN0IGJ5dGVzTGlzdCA9IGZlYXQuZ2V0Qnl0ZXNMaXN0KCk7XG4gICAgY29uc3QgaW50NjRMaXN0ID0gZmVhdC5nZXRJbnQ2NExpc3QoKTtcbiAgICBjb25zdCBmbG9hdExpc3QgPSBmZWF0LmdldEZsb2F0TGlzdCgpO1xuICAgIGlmIChieXRlc0xpc3QpIHtcbiAgICAgIGJ5dGVzTGlzdC5zZXRWYWx1ZUxpc3QoKHZhbHVlcyBhcyBzdHJpbmdbXSkpO1xuICAgIH0gZWxzZSBpZiAoaW50NjRMaXN0KSB7XG4gICAgICBpbnQ2NExpc3Quc2V0VmFsdWVMaXN0KCh2YWx1ZXMgYXMgbnVtYmVyW10pKTtcbiAgICB9IGVsc2UgaWYgKGZsb2F0TGlzdCkge1xuICAgICAgZmxvYXRMaXN0LnNldFZhbHVlTGlzdCgodmFsdWVzIGFzIG51bWJlcltdKSk7XG4gICAgfVxuICB9LFxuXG4gIC8qKlxuICAgKiBXaGVuIGEgZmVhdHVyZSB2YWx1ZSBjaGFuZ2VzIGZyb20gYSBwYXBlci1pbnB1dCwgdXBkYXRlcyB0aGUgZXhhbXBsZSBwcm90b1xuICAgKiBhcHByb3ByaWF0ZWx5LlxuICAgKi9cbiAgb25WYWx1ZUNoYW5nZWQ6IGZ1bmN0aW9uKGV2ZW50OiBFdmVudCkge1xuICAgIGNvbnN0IGlucHV0Q29udHJvbCA9IGV2ZW50LnRhcmdldCBhcyBIVE1MSW5wdXRFbGVtZW50O1xuICAgIGNvbnN0IGRhdGEgPSB0aGlzLmdldERhdGFGcm9tRXZlbnQoZXZlbnQpO1xuICAgIGNvbnN0IGZlYXQgPSB0aGlzLmdldEZlYXR1cmVGcm9tRGF0YShkYXRhKTtcbiAgICBjb25zdCB2YWx1ZXMgPSB0aGlzLmdldFZhbHVlTGlzdEZyb21EYXRhKGRhdGEpO1xuXG4gICAgaWYgKGZlYXQpIHtcbiAgICAgIGlmICh0aGlzLmlzQnl0ZXNGZWF0dXJlKGRhdGEuZmVhdHVyZSkpIHtcbiAgICAgICAgLy8gRm9yIHN0cmluZyBmZWF0dXJlcywgY29udmVydCB0aGUgc3RyaW5nIGludG8gdGhlIGNoYXIgY29kZSBhcnJheVxuICAgICAgICAvLyBmb3Igc3RvcmFnZSBpbiB0aGUgcHJvdG8uXG5cbiAgICAgICAgY29uc3QgY2MgPSB0aGlzLnN0cmluZ1RvVWludDhBcnJheShpbnB1dENvbnRyb2wudmFsdWUpO1xuICAgICAgICAvLyB0c2xpbnQ6ZGlzYWJsZS1uZXh0LWxpbmU6bm8tYW55IGNhc3QgZHVlIHRvIHRmLkV4YW1wbGUgdHlwaW5nLlxuICAgICAgICB2YWx1ZXNbZGF0YS52YWx1ZUluZGV4XSA9IGNjIGFzIGFueTtcblxuICAgICAgICAvLyBJZiB0aGUgZXhhbXBsZSB3YXMgcHJvdmlkZWQgYXMganNvbiwgdXBkYXRlIHRoZSBieXRlc2xpc3QgaW4gdGhlXG4gICAgICAgIC8vIGpzb24gd2l0aCB0aGUgYmFzZTY0IGVuY29kZWQgc3RyaW5nLiBGb3Igbm9uLWJ5dGVzIGZlYXR1cmVzIHdlIGRvbid0XG4gICAgICAgIC8vIG5lZWQgdGhpcyBzZXBhcmF0ZSBqc29uIHVwZGF0ZSBhcyB0aGUgcHJvdG8gdmFsdWUgbGlzdCBpcyB0aGUgc2FtZVxuICAgICAgICAvLyBhcyB0aGUganNvbiB2YWx1ZSBsaXN0IGZvciB0aGF0IGNhc2UgKHNoYWxsb3cgY29weSkuIFRoZSBieXRlc2xpc3RcbiAgICAgICAgLy8gY2FzZSBpcyBkaWZmZXJlbnQgYXMgdGhlIGpzb24gYmFzZTY0IGVuY29kZWQgc3RyaW5nIGlzIGNvbnZlcnRlZCB0b1xuICAgICAgICAvLyBhIGxpc3Qgb2YgYnl0ZXMsIG9uZSBwZXIgY2hhcmFjdGVyLlxuICAgICAgICBjb25zdCBqc29uTGlzdCA9IHRoaXMuZ2V0SnNvblZhbHVlTGlzdChkYXRhLmZlYXR1cmUsIGRhdGEuc2VxTnVtKTtcbiAgICAgICAgaWYgKGpzb25MaXN0KSB7XG4gICAgICAgICAganNvbkxpc3RbZGF0YS52YWx1ZUluZGV4XSA9IGJ0b2EoaW5wdXRDb250cm9sLnZhbHVlKTtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdmFsdWVzW2RhdGEudmFsdWVJbmRleF0gPSAraW5wdXRDb250cm9sLnZhbHVlO1xuICAgICAgICBjb25zdCBqc29uTGlzdCA9IHRoaXMuZ2V0SnNvblZhbHVlTGlzdChkYXRhLmZlYXR1cmUsIGRhdGEuc2VxTnVtKTtcbiAgICAgICAgaWYgKGpzb25MaXN0KSB7XG4gICAgICAgICAganNvbkxpc3RbZGF0YS52YWx1ZUluZGV4XSA9ICtpbnB1dENvbnRyb2wudmFsdWU7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHRoaXMuc2V0RmVhdHVyZVZhbHVlcyhmZWF0LCB2YWx1ZXMpO1xuICAgICAgdGhpcy5leGFtcGxlQ2hhbmdlZCgpO1xuICAgIH1cbiAgfSxcblxuICBvbklucHV0Rm9jdXM6IGZ1bmN0aW9uKGV2ZW50OiBFdmVudCkge1xuICAgIGNvbnN0IGlucHV0Q29udHJvbCA9IGV2ZW50LnRhcmdldCBhcyBIVE1MSW5wdXRFbGVtZW50O1xuICAgIGNvbnN0IGRhdGEgPSB0aGlzLmdldERhdGFGcm9tRXZlbnQoZXZlbnQpO1xuICAgIHRoaXMuZm9jdXNlZEZlYXR1cmVOYW1lID0gZGF0YS5mZWF0dXJlO1xuICAgIHRoaXMuZm9jdXNlZEZlYXR1cmVWYWx1ZUluZGV4ID0gZGF0YS52YWx1ZUluZGV4O1xuICAgIHRoaXMuZm9jdXNlZFNlcU51bWJlciA9IGRhdGEuc2VxTnVtO1xuICAgIHRoaXMuJC5kZWxldGV2YWx1ZS5zdHlsZS50b3AgPSAoXG4gICAgICBpbnB1dENvbnRyb2wuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkudG9wIC1cbiAgICAgIHRoaXMuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkudG9wLSAyNSkgKyAncHgnO1xuICAgIHRoaXMuJC5kZWxldGV2YWx1ZS5zdHlsZS5yaWdodCA9IChcbiAgICAgIHRoaXMuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkucmlnaHQgLVxuICAgICAgaW5wdXRDb250cm9sLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLnJpZ2h0ICsgMzApICsgJ3B4JztcbiAgICB0aGlzLnNob3dEZWxldGVWYWx1ZUJ1dHRvbiA9IHRydWU7XG5cbiAgfSxcblxuXG4gIG9uSW5wdXRCbHVyOiBmdW5jdGlvbihldmVudDogRXZlbnQpIHtcbiAgICB0aGlzLnNob3dEZWxldGVWYWx1ZUJ1dHRvbiA9IGZhbHNlO1xuICB9LFxuXG4gIC8qKlxuICAgKiBXaGVuIGEgZmVhdHVyZSBpcyBkZWxldGVkLCB1cGRhdGVzIHRoZSBleGFtcGxlIHByb3RvIGFwcHJvcHJpYXRlbHkuXG4gICAqL1xuICBkZWxldGVGZWF0dXJlOiBmdW5jdGlvbihldmVudDogRXZlbnQpIHtcbiAgICBjb25zdCBkYXRhID0gdGhpcy5nZXREYXRhRnJvbUV2ZW50KGV2ZW50KTtcbiAgICBpZiAodGhpcy5mZWF0dXJlcy5kZWwpIHtcbiAgICAgIHRoaXMuZmVhdHVyZXMuZGVsKGRhdGEuZmVhdHVyZSk7XG4gICAgfVxuICAgIGlmICh0aGlzLnNlcUZlYXR1cmVzLmRlbCkge1xuICAgICAgdGhpcy5zZXFGZWF0dXJlcy5kZWwoZGF0YS5mZWF0dXJlKTtcbiAgICB9XG4gICAgdGhpcy5kZWxldGVKc29uRmVhdHVyZShkYXRhLmZlYXR1cmUpO1xuICAgIHRoaXMuZXhhbXBsZUNoYW5nZWQoKTtcbiAgICB0aGlzLnJlZnJlc2hFeGFtcGxlVmlld2VyKCk7XG4gIH0sXG5cbiAgLyoqXG4gICAqIEhlbHBlciBtZXRob2QgdG8gZGVsZXRlIGEgZmVhdHVyZSBmcm9tIHRoZSBKU09OIHZlcnNpb24gb2YgdGhlIGV4YW1wbGUsXG4gICAqIGlmIHRoZSBleGFtcGxlIHdhcyBwcm92aWRlZCBhcyBKU09OLlxuICAgKi9cbiAgZGVsZXRlSnNvbkZlYXR1cmU6IGZ1bmN0aW9uKGZlYXR1cmU6IHN0cmluZykge1xuICAgIGlmICh0aGlzLmpzb24pIHtcbiAgICAgIGlmICh0aGlzLmpzb24uZmVhdHVyZXMgJiYgdGhpcy5qc29uLmZlYXR1cmVzLmZlYXR1cmUpIHtcbiAgICAgICAgZGVsZXRlIHRoaXMuanNvbi5mZWF0dXJlcy5mZWF0dXJlW2ZlYXR1cmVdO1xuICAgICAgfVxuICAgICAgaWYgKHRoaXMuanNvbi5jb250ZXh0ICYmIHRoaXMuanNvbi5jb250ZXh0LmZlYXR1cmUpIHtcbiAgICAgICAgZGVsZXRlIHRoaXMuanNvbi5jb250ZXh0LmZlYXR1cmVbZmVhdHVyZV07XG4gICAgICB9XG4gICAgICBpZiAodGhpcy5qc29uLmZlYXR1cmVMaXN0cyAmJiB0aGlzLmpzb24uZmVhdHVyZUxpc3RzLmZlYXR1cmVMaXN0KSB7XG4gICAgICAgIGRlbGV0ZSB0aGlzLmpzb24uZmVhdHVyZUxpc3RzLmZlYXR1cmVMaXN0W2ZlYXR1cmVdO1xuICAgICAgfVxuICAgIH1cbiAgfSxcblxuICAvKipcbiAgICogV2hlbiBhIGZlYXR1cmUgdmFsdWUgaXMgZGVsZXRlZCwgdXBkYXRlcyB0aGUgZXhhbXBsZSBwcm90byBhcHByb3ByaWF0ZWx5LlxuICAgKi9cbiAgZGVsZXRlVmFsdWU6IGZ1bmN0aW9uKGV2ZW50OiBFdmVudCkge1xuICAgIGNvbnN0IGRhdGEgPSB0aGlzLmdldERhdGFGcm9tRXZlbnQoZXZlbnQpO1xuICAgIGNvbnN0IGZlYXQgPSB0aGlzLmdldEZlYXR1cmVGcm9tRGF0YShkYXRhKTtcbiAgICBjb25zdCB2YWx1ZXMgPSB0aGlzLmdldFZhbHVlTGlzdEZyb21EYXRhKGRhdGEpO1xuXG4gICAgaWYgKGZlYXQpIHtcbiAgICAgIGlmICh0aGlzLmlzQnl0ZXNGZWF0dXJlKGRhdGEuZmVhdHVyZSkpIHtcbiAgICAgICAgLy8gSWYgdGhlIGV4YW1wbGUgd2FzIHByb3ZpZGVkIGFzIGpzb24sIHVwZGF0ZSB0aGUgYnl0ZXNsaXN0IGluIHRoZVxuICAgICAgICAvLyBqc29uLiBGb3Igbm9uLWJ5dGVzIGZlYXR1cmVzIHdlIGRvbid0IG5lZWQgdGhpcyBzZXBhcmF0ZSBqc29uIHVwZGF0ZVxuICAgICAgICAvLyBhcyB0aGUgcHJvdG8gdmFsdWUgbGlzdCBpcyB0aGUgc2FtZSBhcyB0aGUganNvbiB2YWx1ZSBsaXN0IGZvciB0aGF0XG4gICAgICAgIC8vIGNhc2UgKHNoYWxsb3cgY29weSkuIFRoZSBieXRlc2xpc3QgY2FzZSBpcyBkaWZmZXJlbnQgYXMgdGhlIGpzb25cbiAgICAgICAgLy8gYmFzZTY0IGVuY29kZWQgc3RyaW5nIGlzIGNvbnZlcnRlZCB0byBhIGxpc3Qgb2YgYnl0ZXMsIG9uZSBwZXJcbiAgICAgICAgLy8gY2hhcmFjdGVyLlxuICAgICAgICBjb25zdCBqc29uTGlzdCA9IHRoaXMuZ2V0SnNvblZhbHVlTGlzdChkYXRhLmZlYXR1cmUsIGRhdGEuc2VxTnVtKTtcbiAgICAgICAgaWYgKGpzb25MaXN0KSB7XG4gICAgICAgICAganNvbkxpc3Quc3BsaWNlKGRhdGEudmFsdWVJbmRleCwgMSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHZhbHVlcy5zcGxpY2UoZGF0YS52YWx1ZUluZGV4LCAxKTtcbiAgICAgIHRoaXMuc2V0RmVhdHVyZVZhbHVlcyhmZWF0LCB2YWx1ZXMpO1xuICAgICAgdGhpcy5leGFtcGxlQ2hhbmdlZCgpO1xuICAgICAgdGhpcy5yZWZyZXNoRXhhbXBsZVZpZXdlcigpO1xuICAgIH1cbiAgfSxcblxuICBvcGVuQWRkRmVhdHVyZURpYWxvZzogZnVuY3Rpb24oKSB7XG4gICAgdGhpcy4kLmFkZEZlYXR1cmVEaWFsb2cub3BlbigpO1xuICB9LFxuXG4gIC8qKlxuICAgKiBXaGVuIGEgZmVhdHVyZSBpcyBhZGRlZCwgdXBkYXRlcyB0aGUgZXhhbXBsZSBwcm90byBhcHByb3ByaWF0ZWx5LlxuICAgKi9cbiAgYWRkRmVhdHVyZTogZnVuY3Rpb24oZXZlbnQ6IEV2ZW50KSB7XG4gICAgaWYgKCF0aGlzLmpzb24pIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBjb25zdCBmZWF0ID0gbmV3IEZlYXR1cmUoKTtcbiAgICAvLyB0c2xpbnQ6ZGlzYWJsZS1uZXh0LWxpbmU6bm8tYW55IFVzaW5nIGFyYml0YXJ5IGpzb24uXG4gICAgbGV0IGpzb25GZWF0OiBhbnk7XG4gICAgaWYgKHRoaXMubmV3RmVhdHVyZVR5cGUgPT09IElOVF9GRUFUVVJFX05BTUUpIHtcbiAgICAgIGNvbnN0IHZhbHVlTGlzdDogbnVtYmVyW10gPSBbXTtcbiAgICAgIGNvbnN0IGludHMgPSBuZXcgRmxvYXRMaXN0KCk7XG4gICAgICBpbnRzLnNldFZhbHVlTGlzdCh2YWx1ZUxpc3QpO1xuICAgICAgZmVhdC5zZXRJbnQ2NExpc3QoaW50cyk7XG4gICAgICBqc29uRmVhdCA9IHtpbnQ2NExpc3Q6IHt2YWx1ZTogdmFsdWVMaXN0fX07XG4gICAgfSBlbHNlIGlmICh0aGlzLm5ld0ZlYXR1cmVUeXBlID09PSBGTE9BVF9GRUFUVVJFX05BTUUpIHtcbiAgICAgIGNvbnN0IHZhbHVlTGlzdDogbnVtYmVyW10gPSBbXTtcbiAgICAgIGNvbnN0IGZsb2F0cyA9IG5ldyBGbG9hdExpc3QoKTtcbiAgICAgIGZsb2F0cy5zZXRWYWx1ZUxpc3QodmFsdWVMaXN0KTtcbiAgICAgIGZlYXQuc2V0RmxvYXRMaXN0KGZsb2F0cyk7XG4gICAgICBqc29uRmVhdCA9IHtmbG9hdExpc3Q6IHt2YWx1ZTogdmFsdWVMaXN0fX07XG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbnN0IHZhbHVlTGlzdDogc3RyaW5nW10gPSBbXTtcbiAgICAgIGNvbnN0IGJ5dGVzID0gbmV3IEJ5dGVzTGlzdCgpO1xuICAgICAgYnl0ZXMuc2V0VmFsdWVMaXN0KHZhbHVlTGlzdCk7XG4gICAgICBmZWF0LnNldEJ5dGVzTGlzdChieXRlcyk7XG4gICAgICBqc29uRmVhdCA9IHtieXRlc0xpc3Q6IHt2YWx1ZTogdmFsdWVMaXN0fX07XG4gICAgfVxuICAgIHRoaXMuZmVhdHVyZXMuc2V0KHRoaXMubmV3RmVhdHVyZU5hbWUsIGZlYXQpO1xuICAgIHRoaXMuYWRkSnNvbkZlYXR1cmUodGhpcy5uZXdGZWF0dXJlTmFtZSwganNvbkZlYXQpO1xuICAgIHRoaXMubmV3RmVhdHVyZU5hbWUgPSAnJztcbiAgICB0aGlzLmV4YW1wbGVDaGFuZ2VkKCk7XG4gICAgdGhpcy5yZWZyZXNoRXhhbXBsZVZpZXdlcigpO1xuICB9LFxuXG4gIC8qKlxuICAgKiBIZWxwZXIgbWV0aG9kIHRvIGFkZCBhIGZlYXR1cmUgdG8gdGhlIEpTT04gdmVyc2lvbiBvZiB0aGUgZXhhbXBsZSxcbiAgICogaWYgdGhlIGV4YW1wbGUgd2FzIHByb3ZpZGVkIGFzIEpTT04uXG4gICAqL1xuICAvLyB0c2xpbnQ6ZGlzYWJsZS1uZXh0LWxpbmU6bm8tYW55IFVzaW5nIGFyYml0YXJ5IGpzb24uXG4gIGFkZEpzb25GZWF0dXJlOiBmdW5jdGlvbihmZWF0dXJlOiBzdHJpbmcsIGpzb25GZWF0OiBhbnkpIHtcbiAgICBpZiAodGhpcy5qc29uICYmIHRoaXMuanNvbi5mZWF0dXJlcyAmJiB0aGlzLmpzb24uZmVhdHVyZXMuZmVhdHVyZSkge1xuICAgICAgdGhpcy5qc29uLmZlYXR1cmVzLmZlYXR1cmVbZmVhdHVyZV0gPSBqc29uRmVhdDtcbiAgICB9IGVsc2UgaWYgKHRoaXMuanNvbiAmJiB0aGlzLmpzb24uY29udGV4dCAmJiB0aGlzLmpzb24uY29udGV4dC5mZWF0dXJlKSB7XG4gICAgICB0aGlzLmpzb24uY29udGV4dC5mZWF0dXJlW2ZlYXR1cmVdID0ganNvbkZlYXQ7XG4gICAgfVxuICB9LFxuXG4gIC8qKlxuICAgKiBXaGVuIGEgZmVhdHVyZSB2YWx1ZSBpcyBhZGRlZCwgdXBkYXRlcyB0aGUgZXhhbXBsZSBwcm90byBhcHByb3ByaWF0ZWx5LlxuICAgKi9cbiAgYWRkVmFsdWU6IGZ1bmN0aW9uKGV2ZW50OiBFdmVudCkge1xuICAgIGNvbnN0IGRhdGEgPSB0aGlzLmdldERhdGFGcm9tRXZlbnQoZXZlbnQpO1xuICAgIGNvbnN0IGZlYXQgPSB0aGlzLmdldEZlYXR1cmVGcm9tRGF0YShkYXRhKTtcbiAgICBjb25zdCB2YWx1ZXMgPSB0aGlzLmdldFZhbHVlTGlzdEZyb21EYXRhKGRhdGEpO1xuXG4gICAgaWYgKGZlYXQpIHtcbiAgICAgIGlmICh0aGlzLmlzQnl0ZXNGZWF0dXJlKGRhdGEuZmVhdHVyZSkpIHtcbiAgICAgICAgdmFsdWVzLnB1c2goJycpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdmFsdWVzLnB1c2goMCk7XG4gICAgICB9XG4gICAgICB0aGlzLnNldEZlYXR1cmVWYWx1ZXMoZmVhdCwgdmFsdWVzKTtcbiAgICAgIHRoaXMuZXhhbXBsZUNoYW5nZWQoKTtcbiAgICAgIHRoaXMucmVmcmVzaEV4YW1wbGVWaWV3ZXIoKTtcbiAgICB9XG4gIH0sXG5cbiAgLyoqXG4gICAqIFJlZnJlc2hlcyB0aGUgZXhhbXBsZSB2aWV3ZXIgc28gdGhhdCBpdCBjb3JyZWN0bHkgc2hvd3MgdGhlIHVwZGF0ZWRcbiAgICogZXhhbXBsZS5cbiAgICovXG4gIHJlZnJlc2hFeGFtcGxlVmlld2VyOiBmdW5jdGlvbigpIHtcbiAgICAvLyBJbiBvcmRlciBmb3IgaXJvbi1saXN0cyB0byBiZSBwcm9wZXJseSB1cGRhdGVkIGJhc2VkIG9uIHByb3RvIGNoYW5nZXMsXG4gICAgLy8gbmVlZCB0byBiaW5kIHRoZSBleGFtcGxlIHRvIGFub3RoZXIgKGJsYW5rKSBleGFtcGxlLCBhbmQgdGhlbiBiYWNrIHRoZVxuICAgIC8vIHRoZSBwcm9wZXIgZXhhbXBsZSBhZnRlciB0aGF0IGNoYW5nZSBoYXMgYmVlbiBwcm9jZXNzZWQuXG4gICAgLy8gVE9ETyhqd2V4bGVyKTogRmluZCBiZXR0ZXIgd2F5IHRvIHVwZGF0ZSB0aGUgdmlzdWFscyBvbiBwcm90byBjaGFuZ2VzLlxuICAgIGNvbnN0IHRlbXAgPSB0aGlzLmV4YW1wbGU7XG4gICAgdGhpcy5pZ25vcmVDaGFuZ2UgPSB0cnVlO1xuICAgIHRoaXMuZXhhbXBsZSA9IG5ldyBFeGFtcGxlKCk7XG4gICAgdGhpcy5pZ25vcmVDaGFuZ2UgPSBmYWxzZTtcbiAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgIHRoaXMuZXhhbXBsZSA9IHRlbXA7XG4gICAgICB0aGlzLmhhdmVTYWxpZW5jeSgpO1xuICAgIH0sIDApO1xuICB9LFxuXG4gIGV4YW1wbGVDaGFuZ2VkOiBmdW5jdGlvbigpIHtcbiAgICAvLyBGaXJlIGV4YW1wbGUtY2hhbmdlIGV2ZW50LlxuICAgIHRoaXMuZmlyZSgnZXhhbXBsZS1jaGFuZ2UnLCB7ZXhhbXBsZTogdGhpcy5leGFtcGxlfSk7XG5cbiAgICAvLyBUaGlzIGNoYW5nZSBpcyBwZXJmb3JtZWQgYWZ0ZXIgYSBkZWxheSBpbiBvcmRlciB0byBkZWJvdW5jZSByYXBpZCB1cGRhdGVzXG4gICAgLy8gdG8gYSB0ZXh0L251bWJlciBmaWVsZCwgYXMgc2VyaWFsaXphdGlvbiBjYW4gdGFrZSBzb21lIHRpbWUgYW5kIGZyZWV6ZVxuICAgIC8vIHRoZSB2aXN1YWxpemF0aW9uIHRlbXBvcmFyaWx5LlxuICAgIGNsZWFyVGltZW91dCh0aGlzLmNoYW5nZUNhbGxiYWNrVGltZXIpO1xuICAgIHRoaXMuY2hhbmdlQ2FsbGJhY2tUaW1lciA9IHNldFRpbWVvdXQoXG4gICAgICAgIHRoaXMuY2hhbmdlQ2FsbGJhY2suYmluZCh0aGlzKSwgQ0hBTkdFX0NBTExCQUNLX1RJTUVSX0RFTEFZX01TKTtcbiAgfSxcblxuICBjaGFuZ2VDYWxsYmFjazogZnVuY3Rpb24oKSB7XG4gICAgLy8gVG8gdXBkYXRlIHRoZSBzZXJpYWxpemVkIGV4YW1wbGUsIHdlIG5lZWQgdG8gZW5zdXJlIHdlIGlnbm9yZSBwYXJzaW5nXG4gICAgLy8gb2YgdGhlIHVwZGF0ZWQgc2VyaWFsaXplZCBleGFtcGxlIGJhY2sgdG8gYW4gZXhhbXBsZSBvYmplY3QgYXMgdGhleVxuICAgIC8vIGFscmVhZHkgbWF0Y2ggYW5kIHRoaXMgd291bGQgY2F1c2UgYSBsb3Qgb2YgdW5uZWNlc3NhcnkgcHJvY2Vzc2luZyxcbiAgICAvLyBsZWFkaW5nIHRvIGxvbmcgZnJlZXplcyBpbiB0aGUgdmlzdWFsaXphdGlvbi5cbiAgICB0aGlzLmlnbm9yZUNoYW5nZSA9IHRydWU7XG4gICAgaWYgKHRoaXMuaXNTZXF1ZW5jZSAmJiB0aGlzLnNlcmlhbGl6ZWRTZXFFeGFtcGxlKSB7XG4gICAgICB0aGlzLnNlcmlhbGl6ZWRTZXFFeGFtcGxlID0gYnRvYShcbiAgICAgICAgICB0aGlzLmRlY29kZUJ5dGVzTGlzdFN0cmluZyh0aGlzLmV4YW1wbGUuc2VyaWFsaXplQmluYXJ5KCksIHRydWUpKTtcbiAgICB9IGVsc2UgaWYgKHRoaXMuc2VyaWFsaXplZEV4YW1wbGUpIHtcbiAgICAgIHRoaXMuc2VyaWFsaXplZEV4YW1wbGUgPSBidG9hKFxuICAgICAgICAgIHRoaXMuZGVjb2RlQnl0ZXNMaXN0U3RyaW5nKHRoaXMuZXhhbXBsZS5zZXJpYWxpemVCaW5hcnkoKSwgdHJ1ZSkpO1xuICAgIH1cbiAgICB0aGlzLmlnbm9yZUNoYW5nZSA9IGZhbHNlO1xuICB9LFxuXG4gIGdldElucHV0UGlsbENsYXNzOiBmdW5jdGlvbihmZWF0OiBzdHJpbmcsIGRpc3BsYXlNb2RlOiBzdHJpbmcpIHtcbiAgICByZXR1cm4gdGhpcy5zYW5pdGl6ZUZlYXR1cmUoZmVhdCkgKyAnIHZhbHVlLXBpbGwnICtcbiAgICAgICAgKGRpc3BsYXlNb2RlID09ICdncmlkJyA/ICcgdmFsdWUtcGlsbC1ncmlkJyA6ICcgdmFsdWUtcGlsbC1zdGFja2VkJyk7XG4gIH0sXG5cbiAgZ2V0Q29tcGFyZUlucHV0Q2xhc3M6IGZ1bmN0aW9uKGZlYXQ6IHN0cmluZywgZGlzcGxheU1vZGU6IHN0cmluZyxcbiAgICAgIGluZGV4PzogbnVtYmVyKSB7XG4gICAgbGV0IHN0ciA9ICd2YWx1ZS1jb21wYXJlJyArXG4gICAgICAgIChkaXNwbGF5TW9kZSA9PSAnZ3JpZCcgPyAnIHZhbHVlLXBpbGwtZ3JpZCcgOiAnIHZhbHVlLXBpbGwtc3RhY2tlZCcpO1xuICAgIGlmIChpbmRleCAhPSBudWxsKSB7XG4gICAgICBjb25zdCB2YWx1ZXMgPSB0aGlzLmdldEZlYXR1cmVWYWx1ZXMoZmVhdCwgdHJ1ZSk7XG4gICAgICBjb25zdCBjb21wVmFsdWVzID0gdGhpcy5nZXRDb21wYXJlRmVhdHVyZVZhbHVlcyhmZWF0LCB0cnVlKTtcbiAgICAgIGlmIChpbmRleCA+PSB2YWx1ZXMubGVuZ3RoIHx8IGluZGV4ID49IGNvbXBWYWx1ZXMubGVuZ3RoIHx8XG4gICAgICAgICAgdmFsdWVzW2luZGV4XSAhPSBjb21wVmFsdWVzW2luZGV4XSkge1xuICAgICAgICBzdHIgKz0gJyB2YWx1ZS1kaWZmZXJlbnQnXG4gICAgICB9IGVsc2Uge1xuICAgICAgICBzdHIgKz0gJyB2YWx1ZS1zYW1lJztcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHN0cjtcbiAgfSxcblxuICBnZXRTZXFDb21wYXJlSW5wdXRDbGFzczogZnVuY3Rpb24oZmVhdDogc3RyaW5nLCBkaXNwbGF5TW9kZTogc3RyaW5nLFxuICAgICAgc2VxTnVtYmVyOiBudW1iZXIsIGluZGV4PzogbnVtYmVyKSB7XG4gICAgbGV0IHN0ciA9ICd2YWx1ZS1jb21wYXJlJyArXG4gICAgICAgIChkaXNwbGF5TW9kZSA9PSAnZ3JpZCcgPyAnIHZhbHVlLXBpbGwtZ3JpZCcgOiAnIHZhbHVlLXBpbGwtc3RhY2tlZCcpO1xuICAgIGlmIChpbmRleCAhPSBudWxsKSB7XG4gICAgICBjb25zdCB2YWx1ZXMgPSB0aGlzLmdldFNlcUZlYXR1cmVWYWx1ZXMoZmVhdCwgc2VxTnVtYmVyLCB0cnVlKTtcbiAgICAgIGNvbnN0IGNvbXBWYWx1ZXMgPSB0aGlzLmdldENvbXBhcmVTZXFGZWF0dXJlVmFsdWVzKGZlYXQsIHNlcU51bWJlciwgdHJ1ZSk7XG4gICAgICBpZiAoaW5kZXggPj0gdmFsdWVzLmxlbmd0aCB8fCBpbmRleCA+PSBjb21wVmFsdWVzLmxlbmd0aCB8fFxuICAgICAgICAgIHZhbHVlc1tpbmRleF0gIT0gY29tcFZhbHVlc1tpbmRleF0pIHtcbiAgICAgICAgc3RyICs9ICcgdmFsdWUtZGlmZmVyZW50J1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgc3RyICs9ICcgdmFsdWUtc2FtZSc7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiBzdHI7XG4gIH0sXG5cbiAgLyoqXG4gICAqIFJlcGxhY2VzIG5vbi1zdGFuZGFyZCBjaGFycyBpbiBmZWF0dXJlIG5hbWVzIHdpdGggdW5kZXJzY29yZXMgc28gdGhleSBjYW5cbiAgICogYmUgdXNlZCBpbiBjc3MgY2xhc3Nlcy9pZHMuXG4gICAqL1xuICBzYW5pdGl6ZUZlYXR1cmU6IGZ1bmN0aW9uKGZlYXQ6IHN0cmluZykge1xuICAgbGV0IHNhbml0aXplZCA9IGZlYXQ7XG4gICAgaWYgKCFmZWF0Lm1hdGNoKC9eW0EtWmEtel0uKiQvKSkge1xuICAgICAgc2FuaXRpemVkID0gJ18nICsgZmVhdDtcbiAgICB9XG4gICAgcmV0dXJuIHNhbml0aXplZC5yZXBsYWNlKC9bXFwvXFwuXFwjXS9nLCAnXycpO1xuICB9LFxuXG4gIGlzU2VxRXhhbXBsZTogZnVuY3Rpb24obWF4U2VxTnVtYmVyOiBudW1iZXIpIHtcbiAgICByZXR1cm4gbWF4U2VxTnVtYmVyID49IDA7XG4gIH0sXG5cbiAgc2hvdWxkU2hvd1NhbGllbmN5TGVnZW5kOiBmdW5jdGlvbihzYWxpZW5jeTogU2FsaWVuY3lNYXApIHtcbiAgICByZXR1cm4gc2FsaWVuY3kgJiYgT2JqZWN0LmtleXMoc2FsaWVuY3kpLmxlbmd0aCA+IDA7XG4gIH0sXG5cbiAgLy8gdHNsaW50OmRpc2FibGUtbmV4dC1saW5lOm5vLXVudXNlZC12YXJpYWJsZSBjYWxsZWQgYXMgY29tcHV0ZWQgcHJvcGVydHlcbiAgZ2V0U2FsaWVuY3lDb250cm9sc0hvbGRlckNsYXNzKHNhbGllbmN5OiBTYWxpZW5jeU1hcCkge1xuICAgIHJldHVybiB0aGlzLnNob3VsZFNob3dTYWxpZW5jeUxlZ2VuZChzYWxpZW5jeSkgP1xuICAgICAgICAnc2FsaWVuY3ktY29udHJvbHMtaG9sZGVyJyA6XG4gICAgICAgICdoaWRlLXNhbGllbmN5LWNvbnRyb2xzJztcbiAgfSxcblxuICAvKiogQ3JlYXRlcyBhbiBzdmcgbGVnZW5kIGZvciB0aGUgc2FsaWVuY3kgY29sb3IgbWFwcGluZy4gKi9cbiAgY3JlYXRlTGVnZW5kOiBmdW5jdGlvbigpIHtcbiAgICBkMy5zZWxlY3QodGhpcy4kLnNhbGllbmN5TGVnZW5kKS5zZWxlY3RBbGwoJyonKS5yZW1vdmUoKTtcbiAgICBjb25zdCBsZWdlbmRTdmcgPSBkMy5zZWxlY3QodGhpcy4kLnNhbGllbmN5TGVnZW5kKS5hcHBlbmQoJ2cnKTtcbiAgICBjb25zdCBncmFkaWVudCA9IGxlZ2VuZFN2Zy5hcHBlbmQoJ2RlZnMnKVxuICAgICAgICAuYXBwZW5kKCdsaW5lYXJHcmFkaWVudCcpXG4gICAgICAgIC5hdHRyKCdpZCcsICd2emV4YW1wbGV2aWV3ZXJncmFkaWVudCcpXG4gICAgICAgIC5hdHRyKFwieDFcIiwgXCIwJVwiKVxuICAgICAgICAuYXR0cihcInkxXCIsIFwiMCVcIilcbiAgICAgICAgLmF0dHIoXCJ4MlwiLCBcIjEwMCVcIilcbiAgICAgICAgLmF0dHIoXCJ5MlwiLCBcIjAlXCIpXG4gICAgICAgIC5hdHRyKCdzcHJlYWRNZXRob2QnLCAncGFkJyk7XG5cbiAgICBjb25zdCBsaW5zcGFjZSA9IChzdGFydDogbnVtYmVyLCBlbmQ6IG51bWJlciwgbjogbnVtYmVyKSA9PiB7XG4gICAgICBjb25zdCBvdXQgPSBbXTtcbiAgICAgIGNvbnN0IGRlbHRhID0gKGVuZCAtIHN0YXJ0KSAvIChuIC0gMSk7XG4gICAgICBsZXQgaSA9IDA7XG4gICAgICB3aGlsZShpIDwgKG4gLSAxKSkge1xuICAgICAgICAgIG91dC5wdXNoKHN0YXJ0ICsgKGkgKiBkZWx0YSkpO1xuICAgICAgICAgIGkrKztcbiAgICAgIH1cbiAgICAgIG91dC5wdXNoKGVuZCk7XG4gICAgICByZXR1cm4gb3V0O1xuICAgIH07XG5cbiAgICAvLyBDcmVhdGUgdGhlIGNvcnJlY3QgY29sb3Igc2NhbGUgZm9yIHRoZSBsZWdlbmQgZGVwZW5kaW5nIG9uIG1pbmltdW1cbiAgICAvLyBhbmQgbWF4aW11bSBzYWxpZW5jeSBmb3IgdGhpcyBleGFtcGxlLlxuICAgIGNvbnN0IHNjYWxlOiBzdHJpbmdbXSA9IFtdO1xuICAgIGlmICh0aGlzLm1pblNhbCA8IDApIHtcbiAgICAgIHNjYWxlLnB1c2gobmVnU2FsaWVuY3lDb2xvcik7XG4gICAgfVxuICAgIHNjYWxlLnB1c2gobmV1dHJhbFNhbGllbmN5Q29sb3IpO1xuICAgIGlmICh0aGlzLm1heFNhbCA+IDApIHtcbiAgICAgIHNjYWxlLnB1c2gocG9zU2FsaWVuY3lDb2xvcik7XG4gICAgfVxuICAgIC8vIENyZWF0ZXMgYW4gYXJyYXkgb2YgW3BjdCwgY29sb3VyXSBwYWlycyBhcyBzdG9wXG4gICAgLy8gdmFsdWVzIGZvciBsZWdlbmRcbiAgICBjb25zdCBwY3QgPSBsaW5zcGFjZSgwLCAxMDAsIHNjYWxlLmxlbmd0aCkubWFwKChkOiBudW1iZXIpID0+IHtcbiAgICAgICAgcmV0dXJuIE1hdGgucm91bmQoZCkgKyAnJSc7XG4gICAgfSk7XG5cbiAgICBjb25zdCBjb2xvdXJQY3QgPSBkMy56aXAocGN0LCBzY2FsZSk7XG5cbiAgICBjb2xvdXJQY3QuZm9yRWFjaCgoZDogc3RyaW5nW10pID0+IHtcbiAgICAgICAgZ3JhZGllbnQuYXBwZW5kKCdzdG9wJylcbiAgICAgICAgICAgIC5hdHRyKCdvZmZzZXQnLCBkWzBdKVxuICAgICAgICAgICAgLmF0dHIoJ3N0b3AtY29sb3InLCBkWzFdKVxuICAgICAgICAgICAgLmF0dHIoJ3N0b3Atb3BhY2l0eScsIDEpO1xuICAgIH0pO1xuXG4gICAgbGVnZW5kU3ZnLmFwcGVuZCgncmVjdCcpXG4gICAgICAgIC5hdHRyKCd4MScsIDApXG4gICAgICAgIC5hdHRyKCd5MScsIDApXG4gICAgICAgIC5hdHRyKCd3aWR0aCcsIExFR0VORF9XSURUSF9QWClcbiAgICAgICAgLmF0dHIoJ2hlaWdodCcsIExFR0VORF9IRUlHSFRfUFgpXG4gICAgICAgIC5zdHlsZSgnZmlsbCcsICd1cmwoI3Z6ZXhhbXBsZXZpZXdlcmdyYWRpZW50KScpO1xuXG4gICAgY29uc3QgbGVnZW5kU2NhbGUgPVxuICAgICAgICBkMy5zY2FsZUxpbmVhcigpLmRvbWFpbihbdGhpcy5taW5TYWwsIHRoaXMubWF4U2FsXSkucmFuZ2UoW1xuICAgICAgICAgIDAsIExFR0VORF9XSURUSF9QWFxuICAgICAgICBdKTtcblxuICAgIGNvbnN0IGxlZ2VuZEF4aXMgPSBkMy5heGlzQm90dG9tKGxlZ2VuZFNjYWxlKTtcblxuICAgIGxlZ2VuZFN2Zy5hcHBlbmQoJ2cnKVxuICAgICAgICAuYXR0cignY2xhc3MnLCAnbGVnZW5kIGF4aXMnKVxuICAgICAgICAuYXR0cigndHJhbnNmb3JtJywgYHRyYW5zbGF0ZSgwLCR7TEVHRU5EX0hFSUdIVF9QWH0pYClcbiAgICAgICAgLmNhbGwobGVnZW5kQXhpcyk7XG4gIH0sXG5cbiAgaXNJbWFnZTogZnVuY3Rpb24oZmVhdDogc3RyaW5nKSB7XG4gICAgcmV0dXJuIElNR19GRUFUVVJFX1JFR0VYLnRlc3QoZmVhdCk7XG4gIH0sXG5cbiAgLyoqXG4gICAqIFJldHVybnMgdGhlIGRhdGEgVVJJIHNyYyBmb3IgYSBmZWF0dXJlIHZhbHVlIHRoYXQgaXMgYW4gZW5jb2RlZCBpbWFnZS5cbiAgICovXG4gIGdldEltYWdlU3JjOiBmdW5jdGlvbihmZWF0OiBzdHJpbmcpIHtcbiAgICB0aGlzLnNldHVwT25sb2FkQ2FsbGJhY2soZmVhdCk7XG4gICAgcmV0dXJuIHRoaXMuZ2V0SW1hZ2VTcmNGb3JEYXRhKFxuICAgICAgICBmZWF0LCB0aGlzLmdldEZlYXR1cmVWYWx1ZXMoZmVhdCwgZmFsc2UsIHRydWUpWzBdIGFzIHN0cmluZyk7XG4gIH0sXG5cbiAgLyoqXG4gICAqIFJldHVybnMgdGhlIGRhdGEgVVJJIHNyYyBmb3IgYSBmZWF0dXJlIHZhbHVlIHRoYXQgaXMgYW4gZW5jb2RlZCBpbWFnZSwgZm9yXG4gICAqIHRoZSBjb21wYXJlZCBleGFtcGxlLlxuICAgKi9cbiAgZ2V0Q29tcGFyZUltYWdlU3JjOiBmdW5jdGlvbihmZWF0OiBzdHJpbmcpIHtcbiAgICB0aGlzLnNldHVwT25sb2FkQ2FsbGJhY2soZmVhdCwgdHJ1ZSk7XG4gICAgcmV0dXJuIHRoaXMuZ2V0SW1hZ2VTcmNGb3JEYXRhKFxuICAgICAgICBmZWF0LCB0aGlzLmdldENvbXBhcmVGZWF0dXJlVmFsdWVzKGZlYXQsIGZhbHNlLCB0cnVlKVswXSBhcyBzdHJpbmcsXG4gICAgICAgIHRydWUpO1xuICB9LFxuXG4gIC8qKlxuICAgKiBSZXR1cm5zIHRoZSBkYXRhIFVSSSBzcmMgZm9yIGEgc2VxdWVuY2UgZmVhdHVyZSB2YWx1ZSB0aGF0IGlzIGFuIGVuY29kZWRcbiAgICogaW1hZ2UuXG4gICAqL1xuICBnZXRTZXFJbWFnZVNyYzogZnVuY3Rpb24oZmVhdDogc3RyaW5nLCBzZXFOdW06IG51bWJlcikge1xuICAgIHRoaXMuc2V0dXBPbmxvYWRDYWxsYmFjayhmZWF0KTtcbiAgICByZXR1cm4gdGhpcy5nZXRJbWFnZVNyY0ZvckRhdGEoXG4gICAgICAgIGZlYXQsIHRoaXMuZ2V0U2VxRmVhdHVyZVZhbHVlcyhmZWF0LCBzZXFOdW0sIGZhbHNlLCB0cnVlKVswXSBhcyBzdHJpbmcpO1xuICB9LFxuXG4gIC8qKlxuICAgKiBSZXR1cm5zIHRoZSBkYXRhIFVSSSBzcmMgZm9yIGEgc2VxdWVuY2UgZmVhdHVyZSB2YWx1ZSB0aGF0IGlzIGFuIGVuY29kZWRcbiAgICogaW1hZ2UsIGZvciB0aGUgY29tcGFyZWQgZXhhbXBsZS5cbiAgICovXG4gIGdldENvbXBhcmVTZXFJbWFnZVNyYzogZnVuY3Rpb24oZmVhdDogc3RyaW5nLCBzZXFOdW06IG51bWJlcikge1xuICAgIHRoaXMuc2V0dXBPbmxvYWRDYWxsYmFjayhmZWF0LCB0cnVlKTtcbiAgICByZXR1cm4gdGhpcy5nZXRJbWFnZVNyY0ZvckRhdGEoXG4gICAgICAgIGZlYXQsIHRoaXMuZ2V0Q29tcGFyZVNlcUZlYXR1cmVWYWx1ZXMoXG4gICAgICAgICAgZmVhdCwgc2VxTnVtLCBmYWxzZSwgdHJ1ZSlbMF0gYXMgc3RyaW5nLFxuICAgICAgICB0cnVlKTtcbiAgfSxcblxuICAvKipcbiAgICogT24gdGhlIG5leHQgZnJhbWUsIHNldHMgdGhlIG9ubG9hZCBjYWxsYmFjayBmb3IgdGhlIGltYWdlIGZvciB0aGUgZ2l2ZW5cbiAgICogZmVhdHVyZS4gVGhpcyBpcyBkZWxheWVkIHVudGlsIHRoZSBuZXh0IGZyYW1lIHRvIGVuc3VyZSB0aGUgaW1nIGVsZW1lbnRcbiAgICogaXMgcmVuZGVyZWQgYmVmb3JlIHNldHRpbmcgdXAgdGhlIG9ubG9hZCBmdW5jdGlvbi5cbiAgICovXG4gIHNldHVwT25sb2FkQ2FsbGJhY2s6IGZ1bmN0aW9uKGZlYXQ6IHN0cmluZywgY29tcGFyZT86IGJvb2xlYW4pIHtcbiAgICByZXF1ZXN0QW5pbWF0aW9uRnJhbWUoKCkgPT4ge1xuICAgICAgY29uc3QgaW1nID0gdGhpcy4kJChcbiAgICAgICAgJyMnICsgdGhpcy5nZXRJbWFnZUlkKGZlYXQsIGNvbXBhcmUpKSBhcyBIVE1MSW1hZ2VFbGVtZW50O1xuICAgICAgaW1nLm9ubG9hZCA9IHRoaXMuZ2V0T25Mb2FkRm9ySW1hZ2UoZmVhdCwgaW1nLCBjb21wYXJlKTtcbiAgICB9KTtcbiAgfSxcblxuICAvKiogSGVscGVyIG1ldGhvZCB1c2VkIGJ5IGdldEltYWdlU3JjIGFuZCBnZXRTZXFJbWFnZVNyYy4gKi9cbiAgZ2V0SW1hZ2VTcmNGb3JEYXRhOiBmdW5jdGlvbihmZWF0OiBzdHJpbmcsIGltYWdlRGF0YTogc3RyaW5nLFxuICAgICAgY29tcGFyZT86IGJvb2xlYW4pIHtcbiAgICAvLyBHZXQgdGhlIGZvcm1hdCBvZiB0aGUgZW5jb2RlZCBpbWFnZSwgYWNjb3JkaW5nIHRvIHRoZSBmZWF0dXJlIG5hbWVcbiAgICAvLyBzcGVjaWZpZWQgYnkgZ28vdGYtZXhhbXBsZS4gRGVmYXVsdHMgdG8ganBlZyBhcyBzcGVjaWZpZWQgaW4gdGhlIGRvYy5cbiAgICBjb25zdCByZWdFeFJlc3VsdCA9IElNR19GRUFUVVJFX1JFR0VYLmV4ZWMoZmVhdCk7XG4gICAgaWYgKHJlZ0V4UmVzdWx0ID09IG51bGwpIHtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICBjb25zdCBmZWF0dXJlTWlkZGxlID0gcmVnRXhSZXN1bHRbMV0gfHwgJyc7XG4gICAgY29uc3QgZm9ybWF0VmFscyA9IGNvbXBhcmUgP1xuICAgICAgICB0aGlzLmdldENvbXBhcmVGZWF0dXJlVmFsdWVzKFxuICAgICAgICAgICdpbWFnZScgKyBmZWF0dXJlTWlkZGxlICsgJy9mb3JtYXQnLCBmYWxzZSkgOlxuICAgICAgICB0aGlzLmdldEZlYXR1cmVWYWx1ZXMoJ2ltYWdlJyArIGZlYXR1cmVNaWRkbGUgKyAnL2Zvcm1hdCcsIGZhbHNlKTtcbiAgICBsZXQgZm9ybWF0ID0gJ2pwZWcnO1xuICAgIGlmIChmb3JtYXRWYWxzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgZm9ybWF0ID0gKGZvcm1hdFZhbHNbMF0gYXMgc3RyaW5nKS50b0xvd2VyQ2FzZSgpO1xuICAgIH1cbiAgICBsZXQgc3JjID0gJ2RhdGE6aW1hZ2UvJyArIGZvcm1hdCArICc7YmFzZTY0LCc7XG5cbiAgICAvLyBFbmNvZGUgdGhlIGltYWdlIGRhdGEgaW4gYmFzZTY0LlxuICAgIHNyYyA9IHNyYyArIGJ0b2EoZGVjb2RlVVJJQ29tcG9uZW50KGVuY29kZVVSSUNvbXBvbmVudChpbWFnZURhdGEpKSk7XG4gICAgcmV0dXJuIHNyYztcbiAgfSxcblxuICAvKiogUmV0dXJucyB0aGUgbGVuZ3RoIG9mIGFuIGl0ZXJhdG9yLiAqL1xuICBnZXRJdGVyTGVuZ3RoOiBmdW5jdGlvbihpdDogYW55KSB7XG4gICAgbGV0IGxlbiA9IDA7XG4gICAgaWYgKGl0KSB7XG4gICAgICBsZXQgbmV4dCA9IGl0Lm5leHQoKTtcbiAgICAgIHdoaWxlICghbmV4dC5kb25lKSB7XG4gICAgICAgIGxlbisrO1xuICAgICAgICBuZXh0ID0gaXQubmV4dCgpO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gbGVuO1xuICB9LFxuXG4gIC8qKlxuICAgKiBVcGRhdGVzIHRoZSBjb21wYXJlIG1vZGUgYmFzZWQgb2ZmIG9mIHRoZSBjb21wYXJlZCBleGFtcGxlLlxuICAgKi9cbiAgdXBkYXRlQ29tcGFyZU1vZGU6IGZ1bmN0aW9uKCkge1xuICAgIGxldCBjb21wYXJlTW9kZSA9IGZhbHNlO1xuICAgIGlmICgodGhpcy5jb21wYXJlRmVhdHVyZXMgJiZcbiAgICAgICAgIHRoaXMuZ2V0SXRlckxlbmd0aCh0aGlzLmNvbXBhcmVGZWF0dXJlcy5rZXlzKCkpID4gMCkgfHxcbiAgICAgICAgKHRoaXMuY29tcGFyZVNlcUZlYXR1cmVzICYmXG4gICAgICAgIHRoaXMuZ2V0SXRlckxlbmd0aCh0aGlzLmNvbXBhcmVTZXFGZWF0dXJlcy5rZXlzKCkpID4gMCkpIHtcbiAgICAgICAgICBjb21wYXJlTW9kZSA9IHRydWU7XG4gICAgfVxuICAgIHRoaXMuY29tcGFyZU1vZGUgPSBjb21wYXJlTW9kZTtcbiAgfSxcblxuICAvKipcbiAgICogQ3JlYXRlcyB0Zi5FeGFtcGxlIG9yIHRmLlNlcXVlbmNlRXhhbXBsZSBqc3BiIG9iamVjdCBmcm9tIGpzb24uIFVzZWZ1bCB3aGVuXG4gICAqIHRoaXMgaXMgZW1iZWRkZWQgaW50byBhIE9uZVBsYXRmb3JtIGFwcCB0aGF0IHNlbmRzIHByb3RvcyBhcyBqc29uLlxuICAgKi9cbiAgY3JlYXRlRXhhbXBsZXNGcm9tSnNvbjogZnVuY3Rpb24oanNvbjogc3RyaW5nKSB7XG4gICAgdGhpcy5leGFtcGxlID0gdGhpcy5jcmVhdGVFeGFtcGxlc0Zyb21Kc29uSGVscGVyKGpzb24pO1xuICAgIHRoaXMuY29tcGFyZUpzb24gPSB7fTtcbiAgfSxcblxuICAvKipcbiAgICogQ3JlYXRlcyBjb21wYXJlZCB0Zi5FeGFtcGxlIG9yIHRmLlNlcXVlbmNlRXhhbXBsZSBqc3BiIG9iamVjdCBmcm9tIGpzb24uXG4gICAqIFVzZWZ1bCB3aGVuIHRoaXMgaXMgZW1iZWRkZWQgaW50byBhIE9uZVBsYXRmb3JtIGFwcCB0aGF0IHNlbmRzIHByb3RvcyBhc1xuICAgKiBqc29uLlxuICAgKi9cbiAgY3JlYXRlQ29tcGFyZUV4YW1wbGVzRnJvbUpzb246IGZ1bmN0aW9uKGpzb246IHN0cmluZykge1xuICAgIGlmICghanNvbikge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB0aGlzLmNvbXBhcmVFeGFtcGxlID0gdGhpcy5jcmVhdGVFeGFtcGxlc0Zyb21Kc29uSGVscGVyKGpzb24pO1xuICB9LFxuXG4gIGNyZWF0ZUV4YW1wbGVzRnJvbUpzb25IZWxwZXI6IGZ1bmN0aW9uKGpzb246IGFueSkge1xuICAgIGlmICghanNvbikge1xuICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICAgIC8vIElmIHRoZSBwcm92aWRlZCBqc29uIGlzIGEganNvbiBzdHJpbmcsIHBhcnNlIGl0IGludG8gYW4gb2JqZWN0LlxuICAgIGlmICh0eXBlb2YgdGhpcy5qc29uID09PSAnc3RyaW5nJykge1xuICAgICAganNvbiA9IEpTT04ucGFyc2UodGhpcy5qc29uKTtcbiAgICB9XG4gICAgaWYgKGpzb24uZmVhdHVyZXMpIHtcbiAgICAgIGNvbnN0IGV4ID0gbmV3IEV4YW1wbGUoKTtcbiAgICAgIGV4LnNldEZlYXR1cmVzKHRoaXMucGFyc2VGZWF0dXJlcyhqc29uLmZlYXR1cmVzKSk7XG4gICAgICByZXR1cm4gZXg7XG4gICAgfSBlbHNlIGlmIChqc29uLmNvbnRleHQgfHwganNvbi5mZWF0dXJlTGlzdHMpIHtcbiAgICAgIGNvbnN0IHNlcWV4ID0gbmV3IFNlcXVlbmNlRXhhbXBsZSgpO1xuICAgICAgaWYgKGpzb24uY29udGV4dCkge1xuICAgICAgICBzZXFleC5zZXRDb250ZXh0KHRoaXMucGFyc2VGZWF0dXJlcyhqc29uLmNvbnRleHQpKTtcbiAgICAgIH1cbiAgICAgIGlmIChqc29uLmZlYXR1cmVMaXN0cykge1xuICAgICAgICBzZXFleC5zZXRGZWF0dXJlTGlzdHModGhpcy5wYXJzZUZlYXR1cmVMaXN0cyhqc29uLmZlYXR1cmVMaXN0cykpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHNlcWV4O1xuICAgIH0gZWxzZSB7XG4gICAgICByZXR1cm4gbmV3IEV4YW1wbGUoKTtcbiAgICB9XG4gIH0sXG5cbiAgLy8gdHNsaW50OmRpc2FibGUtbmV4dC1saW5lOm5vLWFueSBQYXJzaW5nIGFyYml0YXJ5IGpzb24uXG4gIHBhcnNlRmVhdHVyZXM6IGZ1bmN0aW9uKGZlYXR1cmVzOiBhbnkpIHtcbiAgICBjb25zdCBmZWF0cyA9IG5ldyBGZWF0dXJlcygpO1xuICAgIGZvciAoY29uc3QgZm5hbWUgaW4gZmVhdHVyZXMuZmVhdHVyZSkge1xuICAgICAgaWYgKGZlYXR1cmVzLmZlYXR1cmUuaGFzT3duUHJvcGVydHkoZm5hbWUpKSB7XG4gICAgICAgIGNvbnN0IGZlYXRlbnRyeSA9IGZlYXR1cmVzLmZlYXR1cmVbZm5hbWVdO1xuICAgICAgICBmZWF0cy5nZXRGZWF0dXJlTWFwKCkuc2V0KFxuICAgICAgICAgICAgZm5hbWUsIHRoaXMucGFyc2VGZWF0dXJlKGZlYXRlbnRyeSwgdGhpcy5pc0ltYWdlKGZuYW1lKSkpO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gZmVhdHM7XG4gIH1cbixcbiAgLy8gdHNsaW50OmRpc2FibGUtbmV4dC1saW5lOm5vLWFueSBQYXJzaW5nIGFyYml0YXJ5IGpzb24uXG4gIHBhcnNlRmVhdHVyZUxpc3RzOiBmdW5jdGlvbihmZWF0dXJlczogYW55KSB7XG4gICAgY29uc3QgZmVhdHMgPSBuZXcgRmVhdHVyZUxpc3RzKCk7XG4gICAgZm9yIChjb25zdCBmbmFtZSBpbiBmZWF0dXJlcy5mZWF0dXJlTGlzdCkge1xuICAgICAgaWYgKGZlYXR1cmVzLmZlYXR1cmVMaXN0Lmhhc093blByb3BlcnR5KGZuYW1lKSkge1xuICAgICAgICBjb25zdCBmZWF0bGlzdGVudHJ5ID0gZmVhdHVyZXMuZmVhdHVyZUxpc3RbZm5hbWVdO1xuICAgICAgICBjb25zdCBmZWF0TGlzdCA9IG5ldyBGZWF0dXJlTGlzdCgpO1xuICAgICAgICBjb25zdCBmZWF0dXJlTGlzdDogRmVhdHVyZVtdID0gW107XG4gICAgICAgIGZvciAoY29uc3QgZmVhdGVudHJ5IGluIGZlYXRsaXN0ZW50cnkuZmVhdHVyZSkge1xuICAgICAgICAgIGlmIChmZWF0bGlzdGVudHJ5LmZlYXR1cmUuaGFzT3duUHJvcGVydHkoZmVhdGVudHJ5KSkge1xuICAgICAgICAgICAgY29uc3QgZmVhdCA9IGZlYXRsaXN0ZW50cnkuZmVhdHVyZVtmZWF0ZW50cnldO1xuICAgICAgICAgICAgZmVhdHVyZUxpc3QucHVzaCh0aGlzLnBhcnNlRmVhdHVyZShmZWF0LCB0aGlzLmlzSW1hZ2UoZm5hbWUpKSk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGZlYXRMaXN0LnNldEZlYXR1cmVMaXN0KGZlYXR1cmVMaXN0KTtcbiAgICAgICAgZmVhdHMuZ2V0RmVhdHVyZUxpc3RNYXAoKS5zZXQoZm5hbWUsIGZlYXRMaXN0KTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIGZlYXRzO1xuICB9LFxuXG4gIC8vIHRzbGludDpkaXNhYmxlLW5leHQtbGluZTpuby1hbnkgUGFyc2luZyBhcmJpdGFyeSBqc29uLlxuICBwYXJzZUZlYXR1cmU6IGZ1bmN0aW9uKGZlYXRlbnRyeTogYW55LCBpc0ltYWdlOiBib29sZWFuKSB7XG4gICAgY29uc3QgZmVhdCA9IG5ldyBGZWF0dXJlKCk7XG4gICAgaWYgKGZlYXRlbnRyeS5mbG9hdExpc3QpIHtcbiAgICAgIGNvbnN0IGZsb2F0cyA9IG5ldyBGbG9hdExpc3QoKTtcbiAgICAgIGZsb2F0cy5zZXRWYWx1ZUxpc3QoZmVhdGVudHJ5LmZsb2F0TGlzdC52YWx1ZSk7XG4gICAgICBmZWF0LnNldEZsb2F0TGlzdChmbG9hdHMpO1xuICAgIH0gZWxzZSBpZiAoZmVhdGVudHJ5LmJ5dGVzTGlzdCkge1xuICAgICAgLy8gSnNvbiBieXRlc2xpc3QgZW50cmllcyBhcmUgYmFzZTY0LiAgVGhlIEpTUEIgZ2VuZXJhdGVkIEZlYXR1cmUgY2xhc3NcbiAgICAgIC8vIHdpbGwgbWFyc2hhbGwgdGhpcyB0byBVOCBhdXRvbWF0aWNhbGx5LlxuICAgICAgY29uc3QgYnl0ZXMgPSBuZXcgQnl0ZXNMaXN0KCk7XG4gICAgICBpZiAoZmVhdGVudHJ5LmJ5dGVzTGlzdC52YWx1ZSkge1xuICAgICAgICBieXRlcy5zZXRWYWx1ZUxpc3QoZmVhdGVudHJ5LmJ5dGVzTGlzdC52YWx1ZSk7XG4gICAgICB9XG4gICAgICBmZWF0LnNldEJ5dGVzTGlzdChieXRlcyk7XG4gICAgfSBlbHNlIGlmIChmZWF0ZW50cnkuaW50NjRMaXN0KSB7XG4gICAgICBjb25zdCBpbnRzID0gbmV3IEludDY0TGlzdCgpO1xuICAgICAgaW50cy5zZXRWYWx1ZUxpc3QoZmVhdGVudHJ5LmludDY0TGlzdC52YWx1ZSk7XG4gICAgICBmZWF0LnNldEludDY0TGlzdChpbnRzKTtcbiAgICB9XG4gICAgcmV0dXJuIGZlYXQ7XG4gIH0sXG5cbiAgZ2V0SW1hZ2VJZDogZnVuY3Rpb24oZmVhdDogc3RyaW5nLCBjb21wYXJlPzogYm9vbGVhbikge1xuICAgIGlmIChjb21wYXJlKSB7XG4gICAgICByZXR1cm4gdGhpcy5nZXRDb21wYXJlSW1hZ2VJZChmZWF0KTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMuc2FuaXRpemVGZWF0dXJlKGZlYXQpICsgJ19pbWFnZSc7XG4gIH0sXG5cbiAgZ2V0Q2FudmFzSWQ6IGZ1bmN0aW9uKGZlYXQ6IHN0cmluZywgY29tcGFyZT86IGJvb2xlYW4pIHtcbiAgICBpZiAoY29tcGFyZSkge1xuICAgICAgcmV0dXJuIHRoaXMuZ2V0Q29tcGFyZUNhbnZhc0lkKGZlYXQpO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5zYW5pdGl6ZUZlYXR1cmUoZmVhdCkgKyAnX2NhbnZhcyc7XG4gIH0sXG5cbiAgZ2V0SW1hZ2VDYXJkSWQ6IGZ1bmN0aW9uKGZlYXQ6IHN0cmluZywgY29tcGFyZT86IGJvb2xlYW4pIHtcbiAgICBpZiAoY29tcGFyZSkge1xuICAgICAgcmV0dXJuIHRoaXMuZ2V0Q29tcGFyZUltYWdlQ2FyZElkKGZlYXQpO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5zYW5pdGl6ZUZlYXR1cmUoZmVhdCkgKyAnX2NhcmQnO1xuICB9LFxuXG4gIGdldENvbXBhcmVJbWFnZUlkOiBmdW5jdGlvbihmZWF0OiBzdHJpbmcpIHtcbiAgICByZXR1cm4gdGhpcy5zYW5pdGl6ZUZlYXR1cmUoZmVhdCkgKyAnX2ltYWdlX2NvbXBhcmUnO1xuICB9LFxuXG4gIGdldENvbXBhcmVDYW52YXNJZDogZnVuY3Rpb24oZmVhdDogc3RyaW5nKSB7XG4gICAgcmV0dXJuIHRoaXMuc2FuaXRpemVGZWF0dXJlKGZlYXQpICsgJ19jYW52YXNfY29tcGFyZSc7XG4gIH0sXG5cbiAgZ2V0Q29tcGFyZUltYWdlQ2FyZElkOiBmdW5jdGlvbihmZWF0OiBzdHJpbmcpIHtcbiAgICByZXR1cm4gdGhpcy5zYW5pdGl6ZUZlYXR1cmUoZmVhdCkgKyAnX2NhcmRfY29tcGFyZSc7XG4gIH0sXG5cbiAgZ2V0RmVhdHVyZURpYWxvZ0lkOiBmdW5jdGlvbihmZWF0OiBzdHJpbmcpIHtcbiAgICByZXR1cm4gdGhpcy5zYW5pdGl6ZUZlYXR1cmUoZmVhdCkgKyAnX2RpYWxvZyc7XG4gIH0sXG5cbiAgZmVhdHVyZU1vcmVDbGlja2VkOiBmdW5jdGlvbihldmVudDogRXZlbnQpIHtcbiAgICBjb25zdCBidXR0b24gPSBldmVudC5zcmNFbGVtZW50LnBhcmVudEVsZW1lbnQ7XG4gICAgY29uc3QgZmVhdHVyZSA9IChidXR0b24gYXMgYW55KS5kYXRhRmVhdHVyZTtcbiAgICBjb25zdCBkaWFsb2cgPSB0aGlzLiQkKCcjJyArIHRoaXMuc2FuaXRpemVGZWF0dXJlKGZlYXR1cmUpICsgJ19kaWFsb2cnKTtcbiAgICBkaWFsb2cucG9zaXRpb25UYXJnZXQgPSBidXR0b247XG4gICAgZGlhbG9nLm9wZW4oKTtcbiAgfSxcblxuICBleHBhbmRGZWF0dXJlOiBmdW5jdGlvbihldmVudDogRXZlbnQpIHtcbiAgICBjb25zdCBmZWF0dXJlID0gKGV2ZW50LnNyY0VsZW1lbnQgYXMgYW55KS5kYXRhRmVhdHVyZTtcbiAgICB0aGlzLnNldCgnZXhwYW5kZWRGZWF0dXJlcy4nICsgdGhpcy5zYW5pdGl6ZUZlYXR1cmUoZmVhdHVyZSksIHRydWUpO1xuICAgIHRoaXMucmVmcmVzaEV4YW1wbGVWaWV3ZXIoKTtcbiAgfSxcblxuICBkZWNvZGVkU3RyaW5nVG9DaGFyQ29kZXM6IGZ1bmN0aW9uKHN0cjogc3RyaW5nKTogVWludDhBcnJheSB7XG4gICAgY29uc3QgY2MgPSBuZXcgVWludDhBcnJheShzdHIubGVuZ3RoKTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHN0ci5sZW5ndGg7ICsraSkge1xuICAgICAgY2NbaV0gPSBzdHIuY2hhckNvZGVBdChpKTtcbiAgICB9XG4gICAgcmV0dXJuIGNjO1xuICB9LFxuXG5cbiAgaGFuZGxlSW1hZ2VVcGxvYWQ6IGZ1bmN0aW9uKGV2ZW50OiBFdmVudCkge1xuICAgIHRoaXMuaGFuZGxlRmlsZVNlbGVjdChldmVudCwgdGhpcylcbiAgfSxcblxuICAvLyBIYW5kbGUgdXBsb2FkIGltYWdlIHBhcGVyIGJ1dHRvbiBjbGljayBieSBkZWxlZ2F0aW5nIHRvIGFwcHJvcHJpYXRlXG4gIC8vIHBhcGVyLWlucHV0IGZpbGUgY2hvb3Nlci5cbiAgdXBsb2FkSW1hZ2VDbGlja2VkOiBmdW5jdGlvbihldmVudDogRXZlbnQpIHtcbiAgICBjb25zdCBkYXRhID0gdGhpcy5nZXREYXRhRnJvbUV2ZW50KGV2ZW50KTtcbiAgICBjb25zdCBpbnB1dHMgPSBQb2x5bWVyLmRvbSh0aGlzLnJvb3QpLnF1ZXJ5U2VsZWN0b3JBbGwoJ3BhcGVyLWlucHV0Jyk7XG4gICAgbGV0IGlucHV0RWxlbSA9IG51bGw7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBpbnB1dHMubGVuZ3RoOyBpKyspIHtcbiAgICAgIGlmICgoaW5wdXRzW2ldIGFzIGFueSkuZGF0YUZlYXR1cmUgPT0gZGF0YS5mZWF0dXJlKSB7XG4gICAgICAgIGlucHV0RWxlbSA9IGlucHV0c1tpXTtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChpbnB1dEVsZW0pIHtcbiAgICAgIGlucHV0RWxlbS5xdWVyeVNlbGVjdG9yKCdpbnB1dCcpLmNsaWNrKCk7XG4gICAgfVxuICB9LFxuXG4gIC8vIEhhbmRsZSBmaWxlIHNlbGVjdCBmb3IgaW1hZ2UgcmVwbGFjZW1lbnQuXG4gIGhhbmRsZUZpbGVTZWxlY3Q6IGZ1bmN0aW9uKGV2ZW50OiBFdmVudCwgc2VsZjogYW55KSB7XG4gICAgZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICBjb25zdCByZWFkZXIgPSBuZXcgRmlsZVJlYWRlcigpO1xuICAgIGNvbnN0IGV2ZW50QW55ID0gZXZlbnQgYXMgYW55O1xuICAgIGNvbnN0IGZpbGVzID0gZXZlbnRBbnkuZGF0YVRyYW5zZmVyID8gZXZlbnRBbnkuZGF0YVRyYW5zZmVyLmZpbGVzIDogZXZlbnRBbnkudGFyZ2V0LmZpbGVzO1xuICAgIGlmIChmaWxlcy5sZW5ndGggPT09IDApIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgcmVhZGVyLmFkZEV2ZW50TGlzdGVuZXIoJ2xvYWQnLCAoKSA9PiB7XG4gICAgICAvLyBHZXQgdGhlIGltYWdlIGRhdGEgZnJvbSB0aGUgbG9hZGVkIGltYWdlIGFuZCBjb252ZXJ0IHRvIGEgY2hhclxuICAgICAgLy8gY29kZSBhcnJheSBmb3IgdXNlIGluIHRoZSBmZWF0dXJlcyB2YWx1ZSBsaXN0LlxuICAgICAgY29uc3QgaW5kZXggPSArcmVhZGVyLnJlc3VsdC5pbmRleE9mKEJBU0VfNjRfSU1BR0VfRU5DT0RJTkdfUFJFRklYKSArXG4gICAgICAgICAgQkFTRV82NF9JTUFHRV9FTkNPRElOR19QUkVGSVgubGVuZ3RoO1xuICAgICAgY29uc3QgZW5jb2RlZEltYWdlRGF0YSA9IHJlYWRlci5yZXN1bHQuc3Vic3RyaW5nKGluZGV4KTtcbiAgICAgIGNvbnN0IGNjID0gc2VsZi5kZWNvZGVkU3RyaW5nVG9DaGFyQ29kZXMoYXRvYihlbmNvZGVkSW1hZ2VEYXRhKSk7XG5cbiAgICAgIGNvbnN0IGRhdGEgPSBzZWxmLmdldERhdGFGcm9tRXZlbnQoZXZlbnQpO1xuICAgICAgY29uc3QgZmVhdCA9IHNlbGYuZ2V0RmVhdHVyZUZyb21EYXRhKGRhdGEpO1xuICAgICAgY29uc3QgdmFsdWVzID0gc2VsZi5nZXRWYWx1ZUxpc3RGcm9tRGF0YShkYXRhKTtcbiAgICAgIGlmIChmZWF0KSB7XG4gICAgICAgIC8vIFJlcGxhY2UgdGhlIG9sZCBpbWFnZSBkYXRhIGluIHRoZSBmZWF0dXJlIHZhbHVlIGxpc3Qgd2l0aCB0aGUgbmV3XG4gICAgICAgIC8vIGltYWdlIGRhdGEuXG4gICAgICAgIC8vIHRzbGludDpkaXNhYmxlLW5leHQtbGluZTpuby1hbnkgY2FzdCBkdWUgdG8gdGYuRXhhbXBsZSB0eXBpbmcuXG4gICAgICAgIHZhbHVlc1swXSA9IGNjIGFzIGFueTtcbiAgICAgICAgZmVhdC5nZXRCeXRlc0xpc3QoKSEuc2V0VmFsdWVMaXN0KCh2YWx1ZXMgYXMgc3RyaW5nW10pKTtcblxuICAgICAgICAvLyBJZiB0aGUgZXhhbXBsZSB3YXMgcHJvdmlkZWQgYXMganNvbiwgdXBkYXRlIHRoZSBieXRlc2xpc3QgaW4gdGhlXG4gICAgICAgIC8vIGpzb24gd2l0aCB0aGUgYmFzZTY0IGVuY29kZWQgc3RyaW5nLlxuICAgICAgICBjb25zdCBqc29uTGlzdCA9IHNlbGYuZ2V0SnNvblZhbHVlTGlzdChkYXRhLmZlYXR1cmUsIGRhdGEuc2VxTnVtKTtcbiAgICAgICAgaWYgKGpzb25MaXN0KSB7XG4gICAgICAgICAganNvbkxpc3RbMF0gPSBlbmNvZGVkSW1hZ2VEYXRhO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gTG9hZCB0aGUgaW1hZ2UgZGF0YSBpbnRvIGFuIGltYWdlIGVsZW1lbnQgdG8gYmVnaW4gdGhlIHByb2Nlc3NcbiAgICAgICAgLy8gb2YgcmVuZGVyaW5nIHRoYXQgaW1hZ2UgdG8gYSBjYW52YXMgZm9yIGRpc3BsYXkuXG4gICAgICAgIGNvbnN0IGltZyA9IG5ldyBJbWFnZSgpO1xuICAgICAgICBzZWxmLmFkZEltYWdlRWxlbWVudChkYXRhLmZlYXR1cmUsIGltZyk7XG4gICAgICAgIGltZy5hZGRFdmVudExpc3RlbmVyKCdsb2FkJywgKCkgPT4ge1xuICAgICAgICAgIC8vIFJ1bnMgdGhlIGFwcHByaWF0ZSBvbmxvYWQgcHJvY2Vzc2luZyBmb3IgdGhlIG5ldyBpbWFnZS5cbiAgICAgICAgICBzZWxmLmdldE9uTG9hZEZvckltYWdlKGRhdGEuZmVhdHVyZSwgaW1nKTtcblxuICAgICAgICAgIC8vIElmIHRoZSBleGFtcGxlIGNvbnRhaW5zIGFwcHJvcHJpYXRlbHktbmFtZWQgZmVhdHVyZXMgZGVzY3JpYmluZ1xuICAgICAgICAgIC8vIHRoZSBpbWFnZSB3aWR0aCBhbmQgaGVpZ2h0IHRoZW4gdXBkYXRlIHRob3NlIGZlYXR1cmUgdmFsdWVzIGZvclxuICAgICAgICAgIC8vIHRoZSBuZXcgaW1hZ2Ugd2lkdGggYW5kIGhlaWdodC5cbiAgICAgICAgICBjb25zdCBmZWF0dXJlTWlkZGxlID1cbiAgICAgICAgICAgICAgSU1HX0ZFQVRVUkVfUkVHRVguZXhlYyhkYXRhLmZlYXR1cmUpIVsxXSB8fCAnJztcbiAgICAgICAgICBjb25zdCB3aWR0aEZlYXR1cmUgPSAnaW1hZ2UnICsgZmVhdHVyZU1pZGRsZSArICcvd2lkdGgnO1xuICAgICAgICAgIGNvbnN0IGhlaWdodEZlYXR1cmUgPSAnaW1hZ2UnICsgZmVhdHVyZU1pZGRsZSArICcvaGVpZ2h0JztcbiAgICAgICAgICBjb25zdCB3aWR0aHMgPSBzZWxmLmdldEZlYXR1cmVWYWx1ZXMod2lkdGhGZWF0dXJlLCBmYWxzZSk7XG4gICAgICAgICAgY29uc3QgaGVpZ2h0cyA9IHNlbGYuZ2V0RmVhdHVyZVZhbHVlcyhoZWlnaHRGZWF0dXJlLCBmYWxzZSk7XG4gICAgICAgICAgaWYgKHdpZHRocy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICB3aWR0aHNbMF0gPSAraW1nLndpZHRoO1xuICAgICAgICAgICAgc2VsZi5mZWF0dXJlcy5nZXQod2lkdGhGZWF0dXJlKSEuZ2V0SW50NjRMaXN0KCkhLnNldFZhbHVlTGlzdChcbiAgICAgICAgICAgICAgICAod2lkdGhzIGFzIG51bWJlcltdKSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGlmIChoZWlnaHRzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgIGhlaWdodHNbMF0gPSAraW1nLmhlaWdodDtcbiAgICAgICAgICAgIHNlbGYuZmVhdHVyZXMuZ2V0KGhlaWdodEZlYXR1cmUpIS5nZXRJbnQ2NExpc3QoKSEuc2V0VmFsdWVMaXN0KFxuICAgICAgICAgICAgICAgIChoZWlnaHRzIGFzIG51bWJlcltdKSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIHNlbGYuZXhhbXBsZUNoYW5nZWQoKTtcbiAgICAgICAgfSk7XG4gICAgICAgIGltZy5zcmMgPSByZWFkZXIucmVzdWx0O1xuICAgICAgfVxuICAgIH0sIGZhbHNlKTtcblxuICAgIC8vIFJlYWQgdGhlIGltYWdlIGZpbGUgYXMgYSBkYXRhIFVSTC5cbiAgICByZWFkZXIucmVhZEFzRGF0YVVSTChmaWxlc1swXSk7XG4gIH0sXG5cbiAgLy8gQWRkIGRyYWctYW5kLWRyb3AgaW1hZ2UgcmVwbGFjZW1lbnQgYmVoYXZpb3IgdG8gdGhlIGNhbnZhcy5cbiAgYWRkRHJhZ0Ryb3BCZWhhdmlvclRvQ2FudmFzOiBmdW5jdGlvbihjYW52YXM6IEhUTUxFbGVtZW50KSB7XG4gICAgY29uc3Qgc2VsZiA9IHRoaXM7XG5cbiAgICAvLyBIYW5kbGUgZHJhZyBldmVudCBmb3IgZHJhZy1hbmQtZHJvcCBpbWFnZSByZXBsYWNlbWVudC5cbiAgICBmdW5jdGlvbiBoYW5kbGVEcmFnT3ZlcihldmVudDogRHJhZ0V2ZW50KSB7XG4gICAgICBldmVudC5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG4gICAgICBldmVudC5kYXRhVHJhbnNmZXIuZHJvcEVmZmVjdCA9ICdjb3B5JztcbiAgICB9XG5cbiAgICBmdW5jdGlvbiBoYW5kbGVGaWxlU2VsZWN0KGV2ZW50OiBEcmFnRXZlbnQpIHtcbiAgICAgIHNlbGYuaGFuZGxlRmlsZVNlbGVjdChldmVudCwgc2VsZilcbiAgICB9XG5cbiAgICBpZiAoIXRoaXMucmVhZG9ubHkgJiYgY2FudmFzKSB7XG4gICAgICBjYW52YXMuYWRkRXZlbnRMaXN0ZW5lcignZHJhZ292ZXInLCBoYW5kbGVEcmFnT3ZlciwgZmFsc2UpO1xuICAgICAgY2FudmFzLmFkZEV2ZW50TGlzdGVuZXIoJ2Ryb3AnLCBoYW5kbGVGaWxlU2VsZWN0LCBmYWxzZSk7XG4gICAgfVxuICB9LFxuXG4gIC8qKlxuICAgKiBSZXR1cm5zIGFuIG9ubG9hZCBmdW5jdGlvbiBmb3IgYW4gaW1nIGVsZW1lbnQuIFRoZSBmdW5jdGlvbiBkcmF3cyB0aGUgaW1hZ2VcbiAgICogdG8gdGhlIGFwcHJvcHJpYXRlIGNhbnZhcyBlbGVtZW50IGFuZCBhZGRzIHRoZSBzYWxpZW5jeSBpbmZvcm1hdGlvbiB0byB0aGVcbiAgICogY2FudmFzIGlmIGl0IGV4aXN0cy5cbiAgICovXG4gIGdldE9uTG9hZEZvckltYWdlOiBmdW5jdGlvbihmZWF0OiBzdHJpbmcsIGltYWdlOiBIVE1MSW1hZ2VFbGVtZW50LFxuICAgICAgY29tcGFyZT86IGJvb2xlYW4pIHtcbiAgICBjb25zdCBmID0gKGZlYXQ6IHN0cmluZywgaW1hZ2U6IEhUTUxJbWFnZUVsZW1lbnQsIGNvbXBhcmU/OiBib29sZWFuKSA9PiB7XG4gICAgICBjb25zdCBjYW52YXMgPSB0aGlzLiQkKFxuICAgICAgICAnIycgKyB0aGlzLmdldENhbnZhc0lkKGZlYXQsIGNvbXBhcmUpKSBhcyBIVE1MQ2FudmFzRWxlbWVudDtcbiAgICAgIGlmICghY29tcGFyZSkge1xuICAgICAgICB0aGlzLmFkZERyYWdEcm9wQmVoYXZpb3JUb0NhbnZhcyhjYW52YXMpO1xuICAgICAgfVxuXG4gICAgICBpZiAoaW1hZ2UgJiYgY2FudmFzKSB7XG4gICAgICAgIC8vIERyYXcgdGhlIGltYWdlIHRvIHRoZSBjYW52YXMgYW5kIHNpemUgdGhlIGNhbnZhcy5cbiAgICAgICAgLy8gU2V0IGQzLnpvb20gb24gdGhlIGNhbnZhcyB0byBlbmFibGUgem9vbWluZyBhbmQgc2NhbGluZyBpbnRlcmFjdGlvbnMuXG4gICAgICAgIGNvbnN0IGNvbnRleHQgPSBjYW52YXMuZ2V0Q29udGV4dCgnMmQnKSE7XG4gICAgICAgIGxldCBpbWFnZVNjYWxlRmFjdG9yID0gdGhpcy5pbWFnZVNjYWxlUGVyY2VudGFnZSAvIDEwMDtcblxuICAgICAgICAvLyBJZiBub3QgdXNpbmcgaW1hZ2UgY29udHJvbHMgdGhlbiBzY2FsZSB0aGUgaW1hZ2UgdG8gbWF0Y2ggdGhlXG4gICAgICAgIC8vIGF2YWlsYWJsZSB3aWR0aCBpbiB0aGUgY29udGFpbmVyLCBjb25zaWRlcmluZyBwYWRkaW5nLlxuICAgICAgICBpZiAoIXRoaXMuYWxsb3dJbWFnZUNvbnRyb2xzKSB7XG4gICAgICAgICAgY29uc3QgaG9sZGVyID0gdGhpcy4kJChcbiAgICAgICAgICAgICcjJyArXG4gICAgICAgICAgICB0aGlzLmdldEltYWdlQ2FyZElkKGZlYXQsIGNvbXBhcmUpKS5wYXJlbnRFbGVtZW50IGFzIEhUTUxFbGVtZW50O1xuICAgICAgICAgIGxldCBjYXJkV2lkdGhGb3JTY2FsaW5nID0gaG9sZGVyLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLndpZHRoIC8gMjtcbiAgICAgICAgICBpZiAoY2FyZFdpZHRoRm9yU2NhbGluZyA+IDE2KSB7XG4gICAgICAgICAgICBjYXJkV2lkdGhGb3JTY2FsaW5nIC09IDE2O1xuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAoY2FyZFdpZHRoRm9yU2NhbGluZyA8IGltYWdlLndpZHRoKSB7XG4gICAgICAgICAgICBpbWFnZVNjYWxlRmFjdG9yID0gY2FyZFdpZHRoRm9yU2NhbGluZyAvIGltYWdlLndpZHRoO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBjYW52YXMud2lkdGggPSBpbWFnZS53aWR0aCAqIGltYWdlU2NhbGVGYWN0b3I7XG4gICAgICAgIGNhbnZhcy5oZWlnaHQgPSBpbWFnZS5oZWlnaHQgKiBpbWFnZVNjYWxlRmFjdG9yO1xuICAgICAgICBjb25zdCB0cmFuc2Zvcm1GbiA9ICh0cmFuc2Zvcm06IGQzLlpvb21UcmFuc2Zvcm0pID0+IHtcbiAgICAgICAgICBjb250ZXh0LnNhdmUoKTtcbiAgICAgICAgICBjb250ZXh0LmNsZWFyUmVjdCgwLCAwLCBjYW52YXMud2lkdGgsIGNhbnZhcy5oZWlnaHQpO1xuICAgICAgICAgIGNvbnRleHQudHJhbnNsYXRlKHRyYW5zZm9ybS54LCB0cmFuc2Zvcm0ueSk7XG4gICAgICAgICAgY29udGV4dC5zY2FsZSh0cmFuc2Zvcm0uaywgdHJhbnNmb3JtLmspO1xuICAgICAgICAgIHRoaXMucmVuZGVySW1hZ2VPbkNhbnZhcyhjb250ZXh0LCBjYW52YXMud2lkdGgsIGNhbnZhcy5oZWlnaHQsIGZlYXQsXG4gICAgICAgICAgICBjb21wYXJlKTtcbiAgICAgICAgICBjb250ZXh0LnJlc3RvcmUoKTtcbiAgICAgICAgfTtcbiAgICAgICAgY29uc3Qgem9vbSA9ICgpID0+IHtcbiAgICAgICAgICBjb25zdCB0cmFuc2Zvcm0gPSBkMy5ldmVudC50cmFuc2Zvcm07XG4gICAgICAgICAgdGhpcy5hZGRJbWFnZVRyYW5zZm9ybShmZWF0LCB0cmFuc2Zvcm0sIGNvbXBhcmUpO1xuICAgICAgICAgIHRyYW5zZm9ybUZuKGQzLmV2ZW50LnRyYW5zZm9ybSk7XG4gICAgICAgIH07XG4gICAgICAgIGNvbnN0IGQzem9vbSA9IGQzLnpvb20oKS5zY2FsZUV4dGVudChaT09NX0VYVEVOVCkub24oJ3pvb20nLCB6b29tKTtcbiAgICAgICAgZDMuc2VsZWN0KGNhbnZhcykuY2FsbChkM3pvb20pLm9uKFxuICAgICAgICAgICAgJ2RibGNsaWNrLnpvb20nLFxuICAgICAgICAgICAgKCkgPT4gZDMuc2VsZWN0KGNhbnZhcykuY2FsbChkM3pvb20udHJhbnNmb3JtLCBkMy56b29tSWRlbnRpdHkpKTtcblxuICAgICAgICBjb250ZXh0LnNhdmUoKTtcbiAgICAgICAgY29udGV4dC5zY2FsZShpbWFnZVNjYWxlRmFjdG9yLCBpbWFnZVNjYWxlRmFjdG9yKTtcbiAgICAgICAgY29udGV4dC5kcmF3SW1hZ2UoaW1hZ2UsIDAsIDApO1xuICAgICAgICBjb250ZXh0LnJlc3RvcmUoKTtcbiAgICAgICAgdGhpcy5zZXRJbWFnZURhdHVtKGNvbnRleHQsIGNhbnZhcy53aWR0aCwgY2FudmFzLmhlaWdodCwgZmVhdCwgY29tcGFyZSk7XG4gICAgICAgIHRoaXMucmVuZGVySW1hZ2VPbkNhbnZhcyhjb250ZXh0LCBjYW52YXMud2lkdGgsIGNhbnZhcy5oZWlnaHQsIGZlYXQsXG4gICAgICAgICAgY29tcGFyZSk7XG4gICAgICAgIGlmIChjb21wYXJlKSB7XG4gICAgICAgICAgaWYgKHRoaXMuY29tcGFyZUltYWdlSW5mb1tmZWF0XS50cmFuc2Zvcm0pIHtcbiAgICAgICAgICAgIHRyYW5zZm9ybUZuKHRoaXMuY29tcGFyZUltYWdlSW5mb1tmZWF0XS50cmFuc2Zvcm0hKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgaWYgKHRoaXMuaW1hZ2VJbmZvW2ZlYXRdLnRyYW5zZm9ybSkge1xuICAgICAgICAgICAgdHJhbnNmb3JtRm4odGhpcy5pbWFnZUluZm9bZmVhdF0udHJhbnNmb3JtISk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICAvLyBJZiB0aGUgaW1hZ2UgYW5kIGNhbnZhcyBhcmUgbm90IHlldCByZW5kZXJlZCwgd2FpdCB0byBwZXJmb3JtIHRoaXNcbiAgICAgICAgLy8gcHJvY2Vzc2luZy5cbiAgICAgICAgcmVxdWVzdEFuaW1hdGlvbkZyYW1lKCgpID0+IGYoZmVhdCwgaW1hZ2UsIGNvbXBhcmUpKTtcbiAgICAgIH1cbiAgICB9O1xuICAgIHRoaXMuYWRkSW1hZ2VFbGVtZW50KGZlYXQsIGltYWdlLCBjb21wYXJlKTtcbiAgICB0aGlzLmFkZEltYWdlT25Mb2FkKGZlYXQsIGYsIGNvbXBhcmUpO1xuICAgIHJldHVybiBmLmFwcGx5KHRoaXMsIFtmZWF0LCBpbWFnZSwgY29tcGFyZV0pO1xuICB9LFxuXG4gIGFkZEltYWdlT25Mb2FkOiBmdW5jdGlvbihmZWF0OiBzdHJpbmcsIG9ubG9hZDogT25sb2FkRnVuY3Rpb24sXG4gICAgICBjb21wYXJlPzogYm9vbGVhbikge1xuICAgIHRoaXMuaGFzSW1hZ2UgPSB0cnVlO1xuICAgIGlmIChjb21wYXJlKSB7XG4gICAgICBpZiAoIXRoaXMuY29tcGFyZUltYWdlSW5mb1tmZWF0XSkge1xuICAgICAgICB0aGlzLmNvbXBhcmVJbWFnZUluZm9bZmVhdF0gPSB7fTtcbiAgICAgICB9XG4gICAgICAgdGhpcy5jb21wYXJlSW1hZ2VJbmZvW2ZlYXRdLm9ubG9hZCA9IG9ubG9hZDtcbiAgICB9IGVsc2Uge1xuICAgICAgaWYgKCF0aGlzLmltYWdlSW5mb1tmZWF0XSkge1xuICAgICAgIHRoaXMuaW1hZ2VJbmZvW2ZlYXRdID0ge307XG4gICAgICB9XG4gICAgICB0aGlzLmltYWdlSW5mb1tmZWF0XS5vbmxvYWQgPSBvbmxvYWQ7XG4gICAgfVxuICB9LFxuXG4gIGFkZEltYWdlRGF0YTogZnVuY3Rpb24oZmVhdDogc3RyaW5nLCBpbWFnZURhdGE6IFVpbnQ4Q2xhbXBlZEFycmF5LFxuICAgICAgY29tcGFyZT86IGJvb2xlYW4pIHtcbiAgICBpZiAoY29tcGFyZSkge1xuICAgICAgaWYgKCF0aGlzLmNvbXBhcmVJbWFnZUluZm9bZmVhdF0pIHtcbiAgICAgICAgdGhpcy5jb21wYXJlSW1hZ2VJbmZvW2ZlYXRdID0ge307XG4gICAgICAgfVxuICAgICAgIHRoaXMuY29tcGFyZUltYWdlSW5mb1tmZWF0XS5pbWFnZURhdGEgPSBpbWFnZURhdGE7XG4gICAgfSBlbHNlIHtcbiAgICAgIGlmICghdGhpcy5pbWFnZUluZm9bZmVhdF0pIHtcbiAgICAgICB0aGlzLmltYWdlSW5mb1tmZWF0XSA9IHt9O1xuICAgICAgfVxuICAgICAgdGhpcy5pbWFnZUluZm9bZmVhdF0uaW1hZ2VEYXRhID0gaW1hZ2VEYXRhO1xuICAgIH1cbiAgfSxcblxuICBhZGRJbWFnZUVsZW1lbnQ6IGZ1bmN0aW9uKGZlYXQ6IHN0cmluZywgaW1hZ2U6IEhUTUxJbWFnZUVsZW1lbnQsXG4gICAgICBjb21wYXJlPzogYm9vbGVhbikge1xuICAgIGlmIChjb21wYXJlKSB7XG4gICAgICBpZiAoIXRoaXMuY29tcGFyZUltYWdlSW5mb1tmZWF0XSkge1xuICAgICAgICB0aGlzLmNvbXBhcmVJbWFnZUluZm9bZmVhdF0gPSB7fTtcbiAgICAgIH1cbiAgICAgIHRoaXMuY29tcGFyZUltYWdlSW5mb1tmZWF0XS5pbWFnZUVsZW1lbnQgPSBpbWFnZTtcbiAgICB9IGVsc2Uge1xuICAgICAgaWYgKCF0aGlzLmltYWdlSW5mb1tmZWF0XSkge1xuICAgICAgICB0aGlzLmltYWdlSW5mb1tmZWF0XSA9IHt9O1xuICAgICAgfVxuICAgICAgdGhpcy5pbWFnZUluZm9bZmVhdF0uaW1hZ2VFbGVtZW50ID0gaW1hZ2U7XG4gICAgfVxuICB9LFxuXG4gIGFkZEltYWdlR3JheXNjYWxlRGF0YTogZnVuY3Rpb24oXG4gICAgICBmZWF0OiBzdHJpbmcsIGltYWdlR3JheXNjYWxlRGF0YTogVWludDhDbGFtcGVkQXJyYXkpIHtcbiAgICBpZiAoIXRoaXMuaW1hZ2VJbmZvW2ZlYXRdKSB7XG4gICAgICB0aGlzLmltYWdlSW5mb1tmZWF0XSA9IHt9O1xuICAgIH1cbiAgICB0aGlzLmltYWdlSW5mb1tmZWF0XS5pbWFnZUdyYXlzY2FsZURhdGEgPSBpbWFnZUdyYXlzY2FsZURhdGE7XG4gIH0sXG5cbiAgYWRkSW1hZ2VUcmFuc2Zvcm06IGZ1bmN0aW9uKGZlYXQ6IHN0cmluZywgdHJhbnNmb3JtOiBkMy5ab29tVHJhbnNmb3JtLFxuICAgICAgY29tcGFyZT86IGJvb2xlYW4pIHtcbiAgICBpZiAoY29tcGFyZSkge1xuICAgICAgaWYgKCF0aGlzLmNvbXBhcmVJbWFnZUluZm9bZmVhdF0pIHtcbiAgICAgICAgdGhpcy5jb21wYXJlSW1hZ2VJbmZvW2ZlYXRdID0ge307XG4gICAgICB9XG4gICAgICB0aGlzLmNvbXBhcmVJbWFnZUluZm9bZmVhdF0udHJhbnNmb3JtID0gdHJhbnNmb3JtO1xuICAgIH0gZWxzZSB7XG4gICAgICBpZiAoIXRoaXMuaW1hZ2VJbmZvW2ZlYXRdKSB7XG4gICAgICAgIHRoaXMuaW1hZ2VJbmZvW2ZlYXRdID0ge307XG4gICAgICB9XG4gICAgICB0aGlzLmltYWdlSW5mb1tmZWF0XS50cmFuc2Zvcm0gPSB0cmFuc2Zvcm07XG4gICAgfVxuICB9LFxuXG4gIC8qKlxuICAgKiBTYXZlcyB0aGUgVWludDhDbGFtcGVkQXJyYXkgaW1hZ2UgZGF0YSBmb3IgYW4gaW1hZ2UgZmVhdHVyZSwgYm90aCBmb3IgdGhlXG4gICAqIHJhdyBpbWFnZSwgYW5kIGZvciB0aGUgaW1hZ2Ugd2l0aCBhbiBhcHBsaWVkIHNhbGllbmN5IG1hc2sgaWYgdGhlcmUgaXNcbiAgICogc2FsaWVuY3kgaW5mb3JtYXRpb24gZm9yIHRoZSBpbWFnZSBmZWF0dXJlLlxuICAgKi9cbiAgc2V0SW1hZ2VEYXR1bTogZnVuY3Rpb24oXG4gICAgICBjb250ZXh0OiBDYW52YXNSZW5kZXJpbmdDb250ZXh0MkQsIHdpZHRoOiBudW1iZXIsIGhlaWdodDogbnVtYmVyLFxuICAgICAgZmVhdDogc3RyaW5nLCBjb21wYXJlPzogYm9vbGVhbikge1xuICAgIGlmICghd2lkdGggfHwgIWhlaWdodCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBjb250ZXh0RGF0YSA9IGNvbnRleHQuZ2V0SW1hZ2VEYXRhKDAsIDAsIHdpZHRoLCBoZWlnaHQpO1xuICAgIGNvbnN0IGltYWdlRGF0YSA9IFVpbnQ4Q2xhbXBlZEFycmF5LmZyb20oY29udGV4dERhdGEuZGF0YSk7XG4gICAgdGhpcy5hZGRJbWFnZURhdGEoZmVhdCwgaW1hZ2VEYXRhLCBjb21wYXJlKTtcblxuICAgIGlmICghdGhpcy5zYWxpZW5jeSB8fCAhdGhpcy5zaG93U2FsaWVuY3kgfHwgIXRoaXMuc2FsaWVuY3lbZmVhdF0gfHxcbiAgICAgICAgY29tcGFyZSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIC8vIEdyYXlzY2FsZSB0aGUgaW1hZ2UgZm9yIGxhdGVyIHVzZSB3aXRoIGEgc2FsaWVuY3kgbWFzay5cbiAgICBjb25zdCBzYWxEYXRhID0gVWludDhDbGFtcGVkQXJyYXkuZnJvbShpbWFnZURhdGEpO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgaW1hZ2VEYXRhLmxlbmd0aDsgaSArPSA0KSB7XG4gICAgICAvLyBBdmVyYWdlIHBpeGVsIGNvbG9yIHZhbHVlIGZvciBncmF5c2NhbGluZyB0aGUgcGl4ZWwuXG4gICAgICBjb25zdCBhdmcgPSAoaW1hZ2VEYXRhW2ldICsgaW1hZ2VEYXRhW2kgKyAxXSArIGltYWdlRGF0YVtpICsgMl0pIC8gMztcbiAgICAgIHNhbERhdGFbaV0gPSBhdmc7XG4gICAgICBzYWxEYXRhW2kgKyAxXSA9IGF2ZztcbiAgICAgIHNhbERhdGFbaSArIDJdID0gYXZnO1xuICAgIH1cbiAgICB0aGlzLmFkZEltYWdlR3JheXNjYWxlRGF0YShmZWF0LCBzYWxEYXRhKTtcbiAgfSxcblxuICAvKiogVXBkYXRlcyBpbWFnZSBkYXRhIHBpeGVscyBiYXNlZCBvbiB3aW5kb3dpbmcgcGFyYW1ldGVycy4gKi9cbiAgY29udHJhc3RJbWFnZTogZnVuY3Rpb24oXG4gICAgICBkOiBVaW50OENsYW1wZWRBcnJheSwgd2luZG93V2lkdGg6IG51bWJlciwgd2luZG93Q2VudGVyOiBudW1iZXIpIHtcbiAgICAvLyBTZWUgaHR0cHM6Ly93d3cuZGFic29mdC5jaC9kaWNvbS8zL0MuMTEuMi4xLjIvIGZvciBhbGdvcml0aG0gZGVzY3JpcHRpb24uXG4gICAgY29uc3QgY29udHJhc3RTY2FsZSA9IGQzLnNjYWxlTGluZWFyPG51bWJlcj4oKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLmRvbWFpbihbXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHdpbmRvd0NlbnRlciAtIC41IC0gKHdpbmRvd1dpZHRoIC8gMiksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHdpbmRvd0NlbnRlciAtIC41ICsgKCh3aW5kb3dXaWR0aCAtIDEpIC8gMilcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF0pXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuY2xhbXAodHJ1ZSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5yYW5nZShbMCwgMjU1XSk7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBkLmxlbmd0aDsgaSsrKSB7XG4gICAgICAvLyBTa2lwIGFscGhhIGNoYW5uZWwuXG4gICAgICBpZiAoaSAlIDQgIT09IDMpIHtcbiAgICAgICAgZFtpXSA9IGNvbnRyYXN0U2NhbGUoZFtpXSk7XG4gICAgICB9XG4gICAgfVxuICB9LFxuXG4gIC8qKlxuICAgKiBSZXR1cm5zIHRydWUgaWYgdGhlIHNhbGllbmN5IHZhbHVlIHByb3ZpZGVkIGlzIGhpZ2hlciB0aGFuIHRoZVxuICAgKiBzYWxpZW5jeSBjdXRvZmYsIHVuZGVyIHdoaWNoIHNhbGllbmN5IHZhbHVlcyBhcmVuJ3QgZGlzcGxheWVkLlxuICAgKi9cbiAgc2hvd1NhbGllbmN5Rm9yVmFsdWU6IGZ1bmN0aW9uKHNhbFZhbDogbnVtYmVyKSB7XG4gICAgY29uc3Qgc2FsRXh0cmVtZVRvQ29tcGFyZSA9IHNhbFZhbCA+PSAwID8gdGhpcy5tYXhTYWwgOiB0aGlzLm1pblNhbDtcbiAgICByZXR1cm4gTWF0aC5hYnMoc2FsVmFsKSA+PVxuICAgICAgICAoTWF0aC5hYnMoc2FsRXh0cmVtZVRvQ29tcGFyZSkgKiB0aGlzLnNhbGllbmN5Q3V0b2ZmIC8gMTAwLik7XG4gIH0sXG5cbiAgLyoqIFJldHVybnMgdGhlIGNvbG9yIHRvIGRpc3BsYXkgZm9yIGEgZ2l2ZW4gc2FsaWVuY3kgdmFsdWUuICovXG4gIGdldENvbG9yRm9yU2FsaWVuY3k6IGZ1bmN0aW9uKHNhbFZhbDogbnVtYmVyKSB7XG4gICAgaWYgKCF0aGlzLnNob3dTYWxpZW5jeUZvclZhbHVlKHNhbFZhbCkpIHtcbiAgICAgIHJldHVybiBuZXV0cmFsU2FsaWVuY3lDb2xvcjtcbiAgICB9IGVsc2Uge1xuICAgICAgcmV0dXJuIHRoaXMuY29sb3JzKHNhbFZhbCk7XG4gICAgfVxuICB9LFxuXG4gIC8qKiBBZGp1c3RzIGltYWdlIGRhdGEgcGl4ZWxzIHRvIG92ZXJsYXkgdGhlIHNhbGllbmN5IG1hc2suICovXG4gIGFkZFNhbGllbmN5VG9JbWFnZTogZnVuY3Rpb24oXG4gICAgICBkOiBVaW50OENsYW1wZWRBcnJheSwgc2FsOiBTYWxpZW5jeVZhbHVlfFNhbGllbmN5VmFsdWVbXSkge1xuICAgIC8vIElmIHByb3ZpZGVkIGFuIGFycmF5IG9mIFNhbGllbmN5VmFsdWUgdGhlbiBnZXQgdGhlIGNvcnJlY3Qgc2FsaWVuY3kgbWFwXG4gICAgLy8gZm9yIHRoZSBjdXJyZW50bHkgc2VsZWN0ZWQgc2VxdWVuY2UgbnVtYmVyLlxuICAgIGlmIChBcnJheS5pc0FycmF5KHNhbCkgJiYgc2FsLmxlbmd0aCA+IDAgJiYgQXJyYXkuaXNBcnJheShzYWxbMF0pKSB7XG4gICAgICBzYWwgPSBzYWxbdGhpcy5zZXFOdW1iZXJdO1xuICAgIH1cblxuICAgIC8vIEdyYXlzY2FsZSB0aGUgaW1hZ2UgYW5kIGNvbWJpbmUgdGhlIGNvbG9yZWQgcGl4ZWxzIGJhc2VkIG9uIHNhbGllbmN5IGF0XG4gICAgLy8gdGhhdCBwaXhlbC4gVGhpcyBsb29wIGV4YW1pbmVzIGVhY2ggcGl4ZWwsIGVhY2ggb2Ygd2hpY2ggY29uc2lzdHMgb2YgNFxuICAgIC8vIHZhbHVlcyAociwgZywgYiwgYSkgaW4gdGhlIGRhdGEgYXJyYXkuXG5cbiAgICAvLyBDYWxjdWxhdGUgdGhlIGFkanVzdG1lbnQgZmFjdG9yIGluIG9yZGVyIHRvIGluZGV4IGludG8gdGhlIGNvcnJlY3RcbiAgICAvLyBzYWxpZW5jeSB2YWx1ZSBmb3IgZWFjaCBwaXhlbCBnaXZlbiB0aGF0IHRoZSBpbWFnZSBtYXkgaGF2ZSBiZWVuIHNjYWxlZCxcbiAgICAvLyBtZWFuaW5nIHRoYXQgdGhlIGNhbnZhcyBpbWFnZSBkYXRhIGFycmF5IHdvdWxkIG5vdCBoYXZlIGEgb25lLXRvLW9uZVxuICAgIC8vIGNvcnJlc3BvbmRlbmNlIHdpdGggdGhlIHBlci1vcmlnaW5hbC1pbWFnZS1waXhlbCBzYWxpZW5jeSBkYXRhLlxuICAgIGNvbnN0IHNhbFNjYWxlQWRqdXN0bWVudCA9IDEgLyBNYXRoLnBvdyh0aGlzLmltYWdlU2NhbGVQZXJjZW50YWdlIC8gMTAwLCAyKTtcblxuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgZC5sZW5ndGg7IGkgKz0gNCkge1xuICAgICAgLy8gR2V0IHRoZSBzYWxpZW5jeSB2YWx1ZSBmb3IgdGhlIHBpeGVsLiBJZiB0aGUgc2FsaWVuY3kgbWFwIGNvbnRhaW5zIG9ubHlcbiAgICAgIC8vIGEgc2luZ2xlIHZhbHVlIGZvciB0aGUgaW1hZ2UsIHVzZSBpdCBmb3IgYWxsIHBpeGVscy5cbiAgICAgIGxldCBzYWxWYWwgPSAwO1xuICAgICAgY29uc3Qgc2FsSW5kZXggPSBNYXRoLmZsb29yKGkgLyA0ICogc2FsU2NhbGVBZGp1c3RtZW50KTtcbiAgICAgIGlmIChBcnJheS5pc0FycmF5KHNhbCkpIHtcbiAgICAgICAgaWYgKHNhbC5sZW5ndGggPiBzYWxJbmRleCkge1xuICAgICAgICAgIHNhbFZhbCA9IHNhbFtzYWxJbmRleF0gYXMgbnVtYmVyO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHNhbFZhbCA9IDA7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHNhbFZhbCA9IHNhbCBhcyBudW1iZXI7XG4gICAgICB9XG5cbiAgICAgIC8vIEJsZW5kIHRoZSBncmF5c2NhbGUgcGl4ZWwgd2l0aCB0aGUgc2FsaWVuY3kgbWFzayBjb2xvciBmb3IgdGhlIHBpeGVsXG4gICAgICAvLyB0byBnZXQgdGhlIGZpbmFsIHIsIGcsIGIgdmFsdWVzIGZvciB0aGUgcGl4ZWwuXG4gICAgICBjb25zdCByYXRpb1RvU2FsaWVuY3lFeHRyZW1lID0gdGhpcy5zaG93U2FsaWVuY3lGb3JWYWx1ZShzYWxWYWwpID9cbiAgICAgICAgICAoc2FsVmFsID49IDAgPyB0aGlzLm1heFNhbCA9PT0gMCA/IDAgOiBzYWxWYWwgLyB0aGlzLm1heFNhbCA6XG4gICAgICAgICAgICAgICAgICAgICAgICAgc2FsVmFsIC8gdGhpcy5taW5TYWwpIDpcbiAgICAgICAgICAwO1xuICAgICAgY29uc3QgYmxlbmRSYXRpbyA9XG4gICAgICAgICAgSU1HX1NBTElFTkNZX01BWF9DT0xPUl9SQVRJTyAqIHJhdGlvVG9TYWxpZW5jeUV4dHJlbWU7XG5cbiAgICAgIGNvbnN0IHtyLCBnLCBifSA9XG4gICAgICAgICAgZDMucmdiKHNhbFZhbCA+IDAgPyBwb3NTYWxpZW5jeUNvbG9yIDogbmVnU2FsaWVuY3lDb2xvcik7XG4gICAgICBkW2ldID0gZFtpXSAqICgxIC0gYmxlbmRSYXRpbykgKyByICogYmxlbmRSYXRpbztcbiAgICAgIGRbaSArIDFdID0gZFtpICsgMV0gKiAoMSAtIGJsZW5kUmF0aW8pICsgZyAqIGJsZW5kUmF0aW87XG4gICAgICBkW2kgKyAyXSA9IGRbaSArIDJdICogKDEgLSBibGVuZFJhdGlvKSArIGIgKiBibGVuZFJhdGlvO1xuICAgIH1cbiAgfSxcblxuICByZW5kZXJJbWFnZU9uQ2FudmFzOiBmdW5jdGlvbihcbiAgICAgIGNvbnRleHQ6IENhbnZhc1JlbmRlcmluZ0NvbnRleHQyRCwgd2lkdGg6IG51bWJlciwgaGVpZ2h0OiBudW1iZXIsXG4gICAgICBmZWF0OiBzdHJpbmcsIGNvbXBhcmU/OiBib29sZWFuKSB7XG4gICAgaWYgKCF3aWR0aCB8fCAhaGVpZ2h0KSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIC8vIFNldCB0aGUgY29ycmVjdCBpbWFnZSBkYXRhIGFycmF5LlxuICAgIGNvbnN0IGlkID0gY29udGV4dC5nZXRJbWFnZURhdGEoMCwgMCwgd2lkdGgsIGhlaWdodCk7XG4gICAgaWYgKGNvbXBhcmUpIHtcbiAgICAgIGlkLmRhdGEuc2V0KHRoaXMuY29tcGFyZUltYWdlSW5mb1tmZWF0XS5pbWFnZURhdGEhKVxuICAgIH0gZWxzZSB7XG4gICAgaWQuZGF0YS5zZXQoXG4gICAgICAgIHRoaXMuc2FsaWVuY3kgJiYgdGhpcy5zaG93U2FsaWVuY3kgJiYgdGhpcy5zYWxpZW5jeVtmZWF0XSA/XG4gICAgICAgICAgICB0aGlzLmltYWdlSW5mb1tmZWF0XS5pbWFnZUdyYXlzY2FsZURhdGEhIDpcbiAgICAgICAgICAgIHRoaXMuaW1hZ2VJbmZvW2ZlYXRdLmltYWdlRGF0YSEpO1xuICAgIH1cblxuICAgIC8vIEFkanVzdCB0aGUgY29udHJhc3QgYW5kIGFkZCBzYWxpZW5jeSBtYXNrIGlmIG5lY2Nlc3NhcnkuXG4gICAgaWYgKHRoaXMud2luZG93V2lkdGggIT09IERFRkFVTFRfV0lORE9XX1dJRFRIIHx8XG4gICAgICAgIHRoaXMud2luZG93Q2VudGVyICE9PSBERUZBVUxUX1dJTkRPV19DRU5URVIpIHtcbiAgICAgIHRoaXMuY29udHJhc3RJbWFnZShpZC5kYXRhLCB0aGlzLndpbmRvd1dpZHRoLCB0aGlzLndpbmRvd0NlbnRlcik7XG4gICAgfVxuICAgIGlmICghY29tcGFyZSAmJiB0aGlzLnNhbGllbmN5ICYmIHRoaXMuc2hvd1NhbGllbmN5ICYmIHRoaXMuc2FsaWVuY3lbZmVhdF0pIHtcbiAgICAgIHRoaXMuYWRkU2FsaWVuY3lUb0ltYWdlKGlkLmRhdGEsIHRoaXMuc2FsaWVuY3lbZmVhdF0pO1xuICAgIH1cblxuICAgIC8vIERyYXcgdGhlIGltYWdlIGRhdGEgdG8gYW4gaW4tbWVtb3J5IGNhbnZhcyBhbmQgdGhlbiBkcmF3IHRoYXQgdG8gdGhlXG4gICAgLy8gb24tc2NyZWVuIGNhbnZhcyBhcyBhbiBpbWFnZS4gVGhpcyBhbGxvd3MgZm9yIHRoZSB6b29tL3RyYW5zbGF0ZSBsb2dpY1xuICAgIC8vIHRvIGZ1bmN0aW9uIGNvcnJlY3RseS4gSWYgdGhlIGltYWdlIGRhdGEgaXMgZGlyZWN0bHkgYXBwbGllZCB0byB0aGVcbiAgICAvLyBvbi1zY3JlZW4gY2FudmFzIHRoZW4gdGhlIHpvb20vdHJhbnNsYXRlIGRvZXMgbm90IGFwcGx5IGNvcnJlY3RseS5cbiAgICBjb25zdCBpbk1lbW9yeUNhbnZhcyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2NhbnZhcycpO1xuICAgIGluTWVtb3J5Q2FudmFzLndpZHRoID0gd2lkdGg7XG4gICAgaW5NZW1vcnlDYW52YXMuaGVpZ2h0ID0gaGVpZ2h0O1xuICAgIGNvbnN0IGluTWVtb3J5Q29udGV4dCA9IGluTWVtb3J5Q2FudmFzLmdldENvbnRleHQoJzJkJykhO1xuICAgIGluTWVtb3J5Q29udGV4dC5wdXRJbWFnZURhdGEoaWQsIDAsIDApO1xuXG4gICAgY29udGV4dC5jbGVhclJlY3QoMCwgMCwgd2lkdGgsIGhlaWdodCk7XG4gICAgY29udGV4dC5kcmF3SW1hZ2UoaW5NZW1vcnlDYW52YXMsIDAsIDApO1xuICB9LFxuXG4gIHNob3dTYWxDaGVja2JveENoYW5nZTogZnVuY3Rpb24oKSB7XG4gICAgdGhpcy5zaG93U2FsaWVuY3kgPSB0aGlzLiQuc2FsQ2hlY2tib3guY2hlY2tlZDtcbiAgfSxcblxuICAvKipcbiAgICogSWYgYW55IGltYWdlIHNldHRpbmdzIGNoYW5nZXMgdGhlbiBjYWxsIG9ubG9hZCBmb3IgZWFjaCBpbWFnZSB0byByZWRyYXcgdGhlXG4gICAqIGltYWdlIG9uIHRoZSBjYW52YXMuXG4gICAqL1xuICB1cGRhdGVJbWFnZXM6IGZ1bmN0aW9uKCkge1xuICAgIGZvciAoY29uc3QgZmVhdCBpbiB0aGlzLmltYWdlSW5mbykge1xuICAgICAgaWYgKHRoaXMuaW1hZ2VJbmZvLmhhc093blByb3BlcnR5KGZlYXQpKSB7XG4gICAgICAgIHRoaXMuaW1hZ2VJbmZvW2ZlYXRdLm9ubG9hZCEoZmVhdCwgdGhpcy5pbWFnZUluZm9bZmVhdF0uaW1hZ2VFbGVtZW50ISk7XG4gICAgICB9XG4gICAgfVxuICB9LFxuXG4gIHNob3VsZFNob3dJbWFnZUNvbnRyb2xzOiBmdW5jdGlvbihcbiAgICAgIGhhc0ltYWdlOiBib29sZWFuLCBhbGxvd0ltYWdlQ29udHJvbHM6IGJvb2xlYW4pIHtcbiAgICByZXR1cm4gaGFzSW1hZ2UgJiYgYWxsb3dJbWFnZUNvbnRyb2xzO1xuICB9LFxuXG4gIC8qKlxuICAgKiBPbmx5IGVuYWJsZSB0aGUgYWRkIGZlYXR1cmUgYnV0dG9uIHdoZW4gYSBuYW1lIGhhcyBiZWVuIHNwZWNpZmllZC5cbiAgICovXG4gIHNob3VsZEVuYWJsZUFkZEZlYXR1cmU6IGZ1bmN0aW9uKGZlYXR1cmVOYW1lOiBzdHJpbmcpIHtcbiAgICByZXR1cm4gZmVhdHVyZU5hbWUubGVuZ3RoID4gMDtcbiAgfSxcblxuICBnZXREZWxldGVWYWx1ZUJ1dHRvbkNsYXNzOiBmdW5jdGlvbihyZWFkb25seTogYm9vbGVhbiwgc2hvd0RlbGV0ZVZhbHVlQnV0dG9uOiBib29sZWFuKSB7XG4gICAgcmV0dXJuIHJlYWRvbmx5IHx8ICFzaG93RGVsZXRlVmFsdWVCdXR0b24gPyAnZGVsZXRlLXZhbHVlLWJ1dHRvbiBkZWxldGUtdmFsdWUtYnV0dG9uLWhpZGRlbicgOiAnZGVsZXRlLXZhbHVlLWJ1dHRvbic7XG4gIH0sXG5cbiAgZ2V0RGVsZXRlRmVhdHVyZUJ1dHRvbkNsYXNzOiBmdW5jdGlvbihyZWFkb25seTogYm9vbGVhbikge1xuICAgIHJldHVybiByZWFkb25seSA/ICdoaWRlLWNvbnRyb2xzJyA6ICdkZWxldGUtZmVhdHVyZS1idXR0b24nO1xuICB9LFxuXG4gIGdldEFkZFZhbHVlQnV0dG9uQ2xhc3M6IGZ1bmN0aW9uKHJlYWRvbmx5OiBib29sZWFuKSB7XG4gICAgcmV0dXJuIHJlYWRvbmx5ID8gJ2hpZGUtY29udHJvbHMnIDogJ2FkZC12YWx1ZS1idXR0b24nO1xuICB9LFxuXG4gIGdldEFkZEZlYXR1cmVCdXR0b25DbGFzczogZnVuY3Rpb24ocmVhZG9ubHk6IGJvb2xlYW4pIHtcbiAgICByZXR1cm4gcmVhZG9ubHkgPyAnaGlkZS1jb250cm9scycgOiAnYWRkLWZlYXR1cmUtYnV0dG9uJztcbiAgfSxcblxuICBnZXRVcGxvYWRJbWFnZUNsYXNzOiBmdW5jdGlvbihyZWFkb25seTogYm9vbGVhbikge1xuICAgIHJldHVybiByZWFkb25seSA/ICdoaWRlLWNvbnRyb2xzJyA6ICd1cGxvYWQtaW1hZ2UtYnV0dG9uJztcbiAgfSxcblxuICAvKipcbiAgICogRGVjb2RlcyBhIGxpc3Qgb2YgYnl0ZXMgaW50byBhIHJlYWRhYmxlIHN0cmluZywgdHJlYXRpbmcgdGhlIGJ5dGVzIGFzXG4gICAqIHVuaWNvZGUgY2hhciBjb2Rlcy5cbiAgICovXG4gIGRlY29kZUJ5dGVzTGlzdFRvU3RyaW5nOiBmdW5jdGlvbihieXRlczogVWludDhBcnJheSkge1xuICAgIC8vIERlY29kZSBzdHJpbmdzIGluIDE2SyBjaHVua3MgdG8gYXZvaWQgc3RhY2sgZXJyb3Igd2l0aCB1c2Ugb2ZcbiAgICAvLyBmcm9tQ2hhckNvZGUuYXBwbHkuXG4gICAgY29uc3QgZGVjb2RlQ2h1bmtCeXRlcyA9IDE2ICogMTAyNDtcbiAgICBsZXQgcmVzID0gJyc7XG4gICAgbGV0IGkgPSAwO1xuICAgIC8vIERlY29kZSBpbiBjaHVua3MgdG8gYXZvaWQgc3RhY2sgZXJyb3Igd2l0aCB1c2Ugb2YgZnJvbUNoYXJDb2RlLmFwcGx5LlxuICAgIGZvciAoaSA9IDA7IGkgPCBieXRlcy5sZW5ndGggLyBkZWNvZGVDaHVua0J5dGVzOyBpKyspIHtcbiAgICAgIHJlcyArPSBTdHJpbmcuZnJvbUNoYXJDb2RlLmFwcGx5KFxuICAgICAgICAgIG51bGwsIGJ5dGVzLnNsaWNlKGkgKiBkZWNvZGVDaHVua0J5dGVzLCAoaSArIDEpICogZGVjb2RlQ2h1bmtCeXRlcykpO1xuICAgIH1cbiAgICByZXMgKz0gU3RyaW5nLmZyb21DaGFyQ29kZS5hcHBseShudWxsLCBieXRlcy5zbGljZShpICogZGVjb2RlQ2h1bmtCeXRlcykpO1xuICAgIHJldHVybiByZXM7XG4gIH0sXG59KTtcblxufVxuIl19