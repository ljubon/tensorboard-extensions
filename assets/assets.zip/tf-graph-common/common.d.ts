/**
 * @fileoverview Common interfaces for the tensorflow graph visualizer.
 */
declare module tf {
    /**
     * Tracks task progress. Each task being passed a progress tracker needs
     * to call the below-defined methods to notify the caller about the gradual
     * progress of the task.
     */
    interface ProgressTracker {
        updateProgress(incrementValue: number): void;
        setMessage(msg: string): void;
        reportError(msg: string, err: Error): void;
    }
}
