declare namespace tf_backend {
    /**
     * A query parameter value can either be a string or a list of strings.
     * A string `"foo"` is encoded as `key=foo`; a list `["foo", "bar"]` is
     * encoded as `key=foo&key=bar`.
     */
    type QueryValue = string | string[];
    type QueryParams = {
        [key: string]: QueryValue;
    };
    /**
     * Add query parameters to a URL. Values will be URL-encoded. The URL
     * may or may not already have query parameters. For convenience,
     * parameters whose value is `undefined` will be dropped.
     *
     * For example, the following expressions are equivalent:
     *
     *     addParams("http://foo", {a: "1", b: ["2", "3+4"], c: "5"})
     *     addParams("http://foo?a=1", {b: ["2", "3+4"], c: "5", d: undefined})
     *     "http://foo?a=1&b=2&b=3%2B4&c=5"
     *
     * @deprecated If used with `router.pluginRoute`, please use the queryParams
     * argument.
     */
    function addParams(baseURL: string, params: QueryParams): string;
}
