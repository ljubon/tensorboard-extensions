/**
 * @fileoverview Interfaces that parallel proto definitions in
 * third_party/tensorflow/core/framework/...
 *     graph.proto
 *     step_stats.proto
 * These should stay in sync.
 *
 * When adding a repeated field to this file, make sure to update the
 * GRAPH_REPEATED_FIELDS and METADATA_REPEATED_FIELDS lists within parser.ts.
 * Otherwise, the parser has no way of differentiating between a field with a
 * certain value and a repeated field that has only 1 occurence, resulting in
 * subtle bugs.
 */
declare module tf.graph.proto {
    /**
     * TensorFlow node definition as defined in the graph.proto file.
     */
    interface NodeDef {
        /** Name of the node */
        name: string;
        /** List of nodes that are inputs for this node. */
        input: string[];
        /** The name of the device where the computation will run. */
        device: string;
        /** The name of the operation associated with this node. */
        op: string;
        /** List of attributes that describe/modify the operation. */
        attr: {
            key: string;
            value: Object;
        }[];
    }
    /**
     * Describes a version of TensorFlow.
     */
    interface VersionDef {
        producer: number;
        min_consumer: number;
        bad_consumers: number[];
    }
    /**
     * Specifies an argument. An argument is either an input or an output of a
     * function. There are thus 2 types of arguments: input_args and output_args.
     * Nodes outside a function call connect to arguments. The graph explorer
     * creates nodes for all arguments within a function.
     */
    interface ArgDef {
        name: string;
        type: string;
    }
    /**
     * Describes the signature of a function - its name, inputs, and outputs.
     */
    interface OpDef {
        name: string;
        input_arg: ArgDef[];
        output_arg: ArgDef[];
    }
    /**
     * Describes a single function within the library.
     */
    interface FunctionDef {
        signature: OpDef;
        node_def: NodeDef[];
    }
    /**
     * Describes a library of functions that may be composed throughout the graph.
     */
    interface FunctionDefLibraryDef {
        function: FunctionDef[];
    }
    /**
     * TensorFlow graph definition as defined in the graph.proto file.
     */
    interface GraphDef {
        node: NodeDef[];
        versions: VersionDef[];
        library: FunctionDefLibraryDef;
    }
    /**
     * Generic graph as defined in the graph_explorer.proto file.
     */
    interface GenericGraph {
        /** List of nodes in the graph */
        node: GenericNode[];
        /** List of nodes in the graph */
        edge: GenericEdge[];
        /** List of attributes that describe/modify the operation. */
        attr: Array<{
            [key: string]: any;
        }>;
    }
    /**
     * GenericEdge corresponds to the Edge message in graph_explorer.proto.
     */
    interface GenericEdge {
        /** Name of the source node. */
        source: string;
        /** Name of the target node. */
        target: string;
        /** Attributes of the edge. */
        edge_attr: Array<{
            [key: string]: any;
        }>;
    }
    /**
     * GenericNode corresponds to the Node message in graph_explorer.proto.
     */
    interface GenericNode {
        /** Name of the node */
        name: string;
        /** Attributes of a leaf node or leaf nodes within a metanode. */
        node_attr: Array<{
            [key: string]: any;
        }>;
        /** Attributes of a metanode. */
        metanode_attr: Array<{
            [key: string]: any;
        }>;
    }
    /**
     * TensorFlow stats file definition as defined in the stats proto file.
     */
    interface StepStats {
        dev_stats: {
            device: string;
            node_stats: NodeExecStats[];
        }[];
    }
    /**
     * TensorFlow stats for a node as defined in the step_stats proto file.
     */
    interface NodeExecStats {
        node_name: string;
        all_start_micros: number;
        op_start_rel_micros: number;
        op_end_rel_micros: number;
        all_end_rel_micros: number;
        memory: {
            allocator_name: string;
            total_bytes: number;
            peak_bytes: number;
        }[];
        /** Output sizes recorded for a single execution of a graph node */
        output: NodeOutput[];
        timeline_label: string;
        scheduled_micros: string;
        thread_id: string;
    }
    /**
     * Description for the output tensor(s) of an operation in the graph as
     * defined in the step_stats.proto file.
     */
    interface NodeOutput {
        slot: number;
        tensor_description: {
            /** Data type of tensor elements */
            dtype: string;
            /** Shape of the tensor */
            shape: {
                /**
                 * Dimensions of the tensor, such as [{name: 'input', size: 30},
                 * {name: 'output', size: 40}] for a 30 x 40 2D tensor.  The names
                 * are optional. The order of entries in 'dim' matters: It indicates
                 * the layout of the values in the tensor in-memory representation.
                 */
                dim: {
                    /** Size of the tensor in that dimension */
                    size: number;
                    /** Optional name of the tensor dimension */
                    name?: string;
                }[];
            };
            /** Information about the size and allocator used for the data */
            allocation_description: {
                /** Total number of bytes requested */
                requested_bytes: number;
                /** Total number of bytes allocated, if known */
                allocated_bytes?: number;
                /** Name of the allocator used */
                allocator_name: string;
            };
        };
    }
}
