declare namespace vz_line_chart2 {
    class PlottableExporter {
        private root;
        private uniqueId;
        constructor(rootEl: Element);
        exportAsString(): string;
        private createUniqueId;
        private getSize;
        private createRootSvg;
        private convert;
        private stripClass;
        private transferStyle;
        protected shouldOmitNode(node: Node): boolean;
    }
    class LineChartExporter extends PlottableExporter {
        shouldOmitNode(node: Node): boolean;
    }
}
