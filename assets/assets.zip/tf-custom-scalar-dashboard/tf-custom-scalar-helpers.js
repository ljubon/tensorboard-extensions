/* Copyright 2017 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the 'License');
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an 'AS IS' BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
var tf_custom_scalar_dashboard;
(function (tf_custom_scalar_dashboard) {
    /**
     * A class that represents a data series for a custom scalars chart.
     */
    var DataSeries = /** @class */ (function () {
        function DataSeries(run, tag, name, scalarData, symbol) {
            this.run = run;
            this.tag = tag;
            this.name = name;
            this.scalarData = scalarData;
            this.symbol = symbol;
        }
        DataSeries.prototype.getName = function () {
            return this.name;
        };
        DataSeries.prototype.setData = function (scalarData) {
            this.scalarData = scalarData;
        };
        DataSeries.prototype.getData = function () {
            return this.scalarData;
        };
        DataSeries.prototype.getRun = function () {
            return this.run;
        };
        DataSeries.prototype.getTag = function () {
            return this.tag;
        };
        DataSeries.prototype.getSymbol = function () {
            return this.symbol;
        };
        return DataSeries;
    }());
    tf_custom_scalar_dashboard.DataSeries = DataSeries;
    function generateDataSeriesName(run, tag) {
        return tag + " (" + run + ")";
    }
    tf_custom_scalar_dashboard.generateDataSeriesName = generateDataSeriesName;
    /**
     * A color scale that wraps the usual color scale that relies on runs. This
     * particular color scale parses the run from a series name and defers to that
     * former color scale.
     */
    var DataSeriesColorScale = /** @class */ (function () {
        function DataSeriesColorScale(runBasedColorScale) {
            this.runBasedColorScale = runBasedColorScale;
        }
        /**
         * Obtains the correct color based on the run.
         * @param {string} dataSeries
         * @return {string} The color.
         */
        DataSeriesColorScale.prototype.scale = function (dataSeries) {
            return this.runBasedColorScale.scale(this.parseRunName(dataSeries));
        };
        /**
         * Parses the run name from a data series string. Returns the empty string if
         * parsing fails.
         */
        DataSeriesColorScale.prototype.parseRunName = function (dataSeries) {
            var match = dataSeries.match(/\((.*)\)$/);
            if (!match) {
                // No match found.
                return '';
            }
            return match[1];
        };
        return DataSeriesColorScale;
    }());
    tf_custom_scalar_dashboard.DataSeriesColorScale = DataSeriesColorScale;
})(tf_custom_scalar_dashboard || (tf_custom_scalar_dashboard = {})); // namespace tf_custom_scalar_dashboard
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGYtY3VzdG9tLXNjYWxhci1oZWxwZXJzLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsidGYtY3VzdG9tLXNjYWxhci1oZWxwZXJzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7Ozs7Ozs7Ozs7O2dGQWFnRjtBQUNoRixJQUFVLDBCQUEwQixDQTZIbkM7QUE3SEQsV0FBVSwwQkFBMEI7SUF1Q3BDOztPQUVHO0lBQ0g7UUFPRSxvQkFBWSxHQUFXLEVBQ1gsR0FBVyxFQUNYLElBQVksRUFDWixVQUEwQyxFQUMxQyxNQUF3QztZQUNsRCxJQUFJLENBQUMsR0FBRyxHQUFHLEdBQUcsQ0FBQztZQUNmLElBQUksQ0FBQyxHQUFHLEdBQUcsR0FBRyxDQUFDO1lBQ2YsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUM7WUFDakIsSUFBSSxDQUFDLFVBQVUsR0FBRyxVQUFVLENBQUM7WUFDN0IsSUFBSSxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUM7UUFDdkIsQ0FBQztRQUVELDRCQUFPLEdBQVA7WUFDRSxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUM7UUFDbkIsQ0FBQztRQUVELDRCQUFPLEdBQVAsVUFBUSxVQUEwQztZQUNoRCxJQUFJLENBQUMsVUFBVSxHQUFHLFVBQVUsQ0FBQztRQUMvQixDQUFDO1FBRUQsNEJBQU8sR0FBUDtZQUNFLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQztRQUN6QixDQUFDO1FBRUQsMkJBQU0sR0FBTjtZQUNFLE9BQU8sSUFBSSxDQUFDLEdBQUcsQ0FBQztRQUNsQixDQUFDO1FBRUQsMkJBQU0sR0FBTjtZQUNFLE9BQU8sSUFBSSxDQUFDLEdBQUcsQ0FBQztRQUNsQixDQUFDO1FBRUQsOEJBQVMsR0FBVDtZQUNFLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQztRQUNyQixDQUFDO1FBQ0gsaUJBQUM7SUFBRCxDQUFDLEFBMUNELElBMENDO0lBMUNZLHFDQUFVLGFBMEN0QixDQUFBO0lBRUQsZ0NBQXVDLEdBQVcsRUFBRSxHQUFXO1FBQzdELE9BQVUsR0FBRyxVQUFLLEdBQUcsTUFBRyxDQUFDO0lBQzNCLENBQUM7SUFGZSxpREFBc0IseUJBRXJDLENBQUE7SUFFRDs7OztPQUlHO0lBQ0g7UUFHRSw4QkFBWSxrQkFBMEM7WUFDcEQsSUFBSSxDQUFDLGtCQUFrQixHQUFHLGtCQUFrQixDQUFDO1FBQy9DLENBQUM7UUFFRDs7OztXQUlHO1FBQ0gsb0NBQUssR0FBTCxVQUFNLFVBQWtCO1lBQ3RCLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUM7UUFDdEUsQ0FBQztRQUVEOzs7V0FHRztRQUNLLDJDQUFZLEdBQXBCLFVBQXFCLFVBQWtCO1lBQ3JDLElBQU0sS0FBSyxHQUFHLFVBQVUsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUM7WUFDNUMsSUFBSSxDQUFDLEtBQUssRUFBRTtnQkFDVixrQkFBa0I7Z0JBQ2xCLE9BQU8sRUFBRSxDQUFDO2FBQ1g7WUFDRCxPQUFPLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUNsQixDQUFDO1FBQ0gsMkJBQUM7SUFBRCxDQUFDLEFBNUJELElBNEJDO0lBNUJZLCtDQUFvQix1QkE0QmhDLENBQUE7QUFFRCxDQUFDLEVBN0hTLDBCQUEwQixLQUExQiwwQkFBMEIsUUE2SG5DLENBQUUsdUNBQXVDIiwic291cmNlc0NvbnRlbnQiOlsiLyogQ29weXJpZ2h0IDIwMTcgVGhlIFRlbnNvckZsb3cgQXV0aG9ycy4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cblxuTGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlLCBWZXJzaW9uIDIuMCAodGhlICdMaWNlbnNlJyk7XG55b3UgbWF5IG5vdCB1c2UgdGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlIHdpdGggdGhlIExpY2Vuc2UuXG5Zb3UgbWF5IG9idGFpbiBhIGNvcHkgb2YgdGhlIExpY2Vuc2UgYXRcblxuICAgIGh0dHA6Ly93d3cuYXBhY2hlLm9yZy9saWNlbnNlcy9MSUNFTlNFLTIuMFxuXG5Vbmxlc3MgcmVxdWlyZWQgYnkgYXBwbGljYWJsZSBsYXcgb3IgYWdyZWVkIHRvIGluIHdyaXRpbmcsIHNvZnR3YXJlXG5kaXN0cmlidXRlZCB1bmRlciB0aGUgTGljZW5zZSBpcyBkaXN0cmlidXRlZCBvbiBhbiAnQVMgSVMnIEJBU0lTLFxuV0lUSE9VVCBXQVJSQU5USUVTIE9SIENPTkRJVElPTlMgT0YgQU5ZIEtJTkQsIGVpdGhlciBleHByZXNzIG9yIGltcGxpZWQuXG5TZWUgdGhlIExpY2Vuc2UgZm9yIHRoZSBzcGVjaWZpYyBsYW5ndWFnZSBnb3Zlcm5pbmcgcGVybWlzc2lvbnMgYW5kXG5saW1pdGF0aW9ucyB1bmRlciB0aGUgTGljZW5zZS5cbj09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSovXG5uYW1lc3BhY2UgdGZfY3VzdG9tX3NjYWxhcl9kYXNoYm9hcmQge1xuXG5leHBvcnQgaW50ZXJmYWNlIEN1c3RvbVNjYWxhclJlc3BvbnNlIHtcbiAgcmVnZXhfdmFsaWQ6IGJvb2xlYW47XG5cbiAgLy8gTWFwcyB0YWcgbmFtZSB0byBhIGxpc3Qgb2Ygc2NhbGFyIGRhdGEuXG4gIHRhZ190b19ldmVudHM6IHtba2V5OiBzdHJpbmddOiB2el9jaGFydF9oZWxwZXJzLlNjYWxhckRhdHVtW119O1xufVxuXG4vKipcbiAqIEEgY2hhcnQgZW5jYXBzdWxhdGVzIGRhdGEgb24gYSBzaW5nbGUgY2hhcnQuXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ2hhcnQge1xuICAvLyBBIHRpdGxlIGZvciB0aGUgY2hhcnQuIElmIG5vdCBwcm92aWRlZCwgYSBjb21tYS1zZXBhcmF0ZWQgbGlzdCBvZiB0YWdzIGlzXG4gIC8vIHVzZWQuXG4gIHRpdGxlOiBzdHJpbmcsXG5cbiAgLy8gQSBsaXN0IG9mIHJlZ2V4ZXMgZm9yIHRhZ3MgdGhhdCBzaG91bGQgYmUgbG9uZyBpbiB0aGlzIGNoYXJ0LlxuICB0YWc6IHN0cmluZ1tdLFxufVxuXG4vKipcbiAqIEEgY2F0ZWdvcnkgc3BlY2lmaWVzIGNoYXJ0cyB3aXRoaW4gYSBzaW5nbGUgY29sbGFwc2libGUuXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ2F0ZWdvcnkge1xuICB0aXRsZTogc3RyaW5nLFxuXG4gIC8vIEEgbGlzdCBvZiBjaGFydHMgdG8gc2hvdyBpbiB0aGlzIGNhdGVnb3J5LlxuICBjaGFydDogQ2hhcnRbXSxcbn1cblxuLyoqXG4gKiBBIGxheW91dCBzcGVjaWZpZXMgaG93IHRoZSB2YXJpb3VzIGNhdGVnb3JpZXMgYW5kIGNoYXJ0cyBzaG91bGQgYmUgbGFpZCBvdXRcbiAqIHdpdGhpbiB0aGUgZGFzaGJvYXJkLlxuICovXG5leHBvcnQgaW50ZXJmYWNlIExheW91dCB7XG4gIGNhdGVnb3J5OiBDYXRlZ29yeVtdLFxufVxuXG4vKipcbiAqIEEgY2xhc3MgdGhhdCByZXByZXNlbnRzIGEgZGF0YSBzZXJpZXMgZm9yIGEgY3VzdG9tIHNjYWxhcnMgY2hhcnQuXG4gKi9cbmV4cG9ydCBjbGFzcyBEYXRhU2VyaWVzIHtcbiAgcHJpdmF0ZSBydW46IHN0cmluZztcbiAgcHJpdmF0ZSB0YWc6IHN0cmluZztcbiAgcHJpdmF0ZSBuYW1lOiBzdHJpbmc7XG4gIHByaXZhdGUgc2NhbGFyRGF0YTogdnpfY2hhcnRfaGVscGVycy5TY2FsYXJEYXR1bVtdO1xuICBwcml2YXRlIHN5bWJvbDogdnpfY2hhcnRfaGVscGVycy5MaW5lQ2hhcnRTeW1ib2w7XG5cbiAgY29uc3RydWN0b3IocnVuOiBzdHJpbmcsXG4gICAgICAgICAgICAgIHRhZzogc3RyaW5nLFxuICAgICAgICAgICAgICBuYW1lOiBzdHJpbmcsXG4gICAgICAgICAgICAgIHNjYWxhckRhdGE6IHZ6X2NoYXJ0X2hlbHBlcnMuU2NhbGFyRGF0dW1bXSxcbiAgICAgICAgICAgICAgc3ltYm9sOiB2el9jaGFydF9oZWxwZXJzLkxpbmVDaGFydFN5bWJvbCkge1xuICAgIHRoaXMucnVuID0gcnVuO1xuICAgIHRoaXMudGFnID0gdGFnO1xuICAgIHRoaXMubmFtZSA9IG5hbWU7XG4gICAgdGhpcy5zY2FsYXJEYXRhID0gc2NhbGFyRGF0YTtcbiAgICB0aGlzLnN5bWJvbCA9IHN5bWJvbDtcbiAgfVxuXG4gIGdldE5hbWUoKTogc3RyaW5nIHtcbiAgICByZXR1cm4gdGhpcy5uYW1lO1xuICB9XG5cbiAgc2V0RGF0YShzY2FsYXJEYXRhOiB2el9jaGFydF9oZWxwZXJzLlNjYWxhckRhdHVtW10pIHtcbiAgICB0aGlzLnNjYWxhckRhdGEgPSBzY2FsYXJEYXRhO1xuICB9XG5cbiAgZ2V0RGF0YSgpOiB2el9jaGFydF9oZWxwZXJzLlNjYWxhckRhdHVtW10ge1xuICAgIHJldHVybiB0aGlzLnNjYWxhckRhdGE7XG4gIH1cblxuICBnZXRSdW4oKTogc3RyaW5nIHtcbiAgICByZXR1cm4gdGhpcy5ydW47XG4gIH1cblxuICBnZXRUYWcoKTogc3RyaW5nIHtcbiAgICByZXR1cm4gdGhpcy50YWc7XG4gIH1cblxuICBnZXRTeW1ib2woKTogdnpfY2hhcnRfaGVscGVycy5MaW5lQ2hhcnRTeW1ib2wge1xuICAgIHJldHVybiB0aGlzLnN5bWJvbDtcbiAgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gZ2VuZXJhdGVEYXRhU2VyaWVzTmFtZShydW46IHN0cmluZywgdGFnOiBzdHJpbmcpOiBzdHJpbmcge1xuICByZXR1cm4gYCR7dGFnfSAoJHtydW59KWA7XG59XG5cbi8qKlxuICogQSBjb2xvciBzY2FsZSB0aGF0IHdyYXBzIHRoZSB1c3VhbCBjb2xvciBzY2FsZSB0aGF0IHJlbGllcyBvbiBydW5zLiBUaGlzXG4gKiBwYXJ0aWN1bGFyIGNvbG9yIHNjYWxlIHBhcnNlcyB0aGUgcnVuIGZyb20gYSBzZXJpZXMgbmFtZSBhbmQgZGVmZXJzIHRvIHRoYXRcbiAqIGZvcm1lciBjb2xvciBzY2FsZS5cbiAqL1xuZXhwb3J0IGNsYXNzIERhdGFTZXJpZXNDb2xvclNjYWxlIHtcbiAgcHJpdmF0ZSBydW5CYXNlZENvbG9yU2NhbGU6IFBsb3R0YWJsZS5TY2FsZXMuQ29sb3I7XG5cbiAgY29uc3RydWN0b3IocnVuQmFzZWRDb2xvclNjYWxlOiBQbG90dGFibGUuU2NhbGVzLkNvbG9yKSB7XG4gICAgdGhpcy5ydW5CYXNlZENvbG9yU2NhbGUgPSBydW5CYXNlZENvbG9yU2NhbGU7XG4gIH1cblxuICAvKipcbiAgICogT2J0YWlucyB0aGUgY29ycmVjdCBjb2xvciBiYXNlZCBvbiB0aGUgcnVuLlxuICAgKiBAcGFyYW0ge3N0cmluZ30gZGF0YVNlcmllc1xuICAgKiBAcmV0dXJuIHtzdHJpbmd9IFRoZSBjb2xvci5cbiAgICovXG4gIHNjYWxlKGRhdGFTZXJpZXM6IHN0cmluZyk6IHN0cmluZyB7XG4gICAgcmV0dXJuIHRoaXMucnVuQmFzZWRDb2xvclNjYWxlLnNjYWxlKHRoaXMucGFyc2VSdW5OYW1lKGRhdGFTZXJpZXMpKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBQYXJzZXMgdGhlIHJ1biBuYW1lIGZyb20gYSBkYXRhIHNlcmllcyBzdHJpbmcuIFJldHVybnMgdGhlIGVtcHR5IHN0cmluZyBpZlxuICAgKiBwYXJzaW5nIGZhaWxzLlxuICAgKi9cbiAgcHJpdmF0ZSBwYXJzZVJ1bk5hbWUoZGF0YVNlcmllczogc3RyaW5nKTogc3RyaW5nIHtcbiAgICBjb25zdCBtYXRjaCA9IGRhdGFTZXJpZXMubWF0Y2goL1xcKCguKilcXCkkLyk7XG4gICAgaWYgKCFtYXRjaCkge1xuICAgICAgLy8gTm8gbWF0Y2ggZm91bmQuXG4gICAgICByZXR1cm4gJyc7XG4gICAgfVxuICAgIHJldHVybiBtYXRjaFsxXTtcbiAgfVxufVxuXG59ICAvLyBuYW1lc3BhY2UgdGZfY3VzdG9tX3NjYWxhcl9kYXNoYm9hcmRcbiJdfQ==