declare namespace tf_debugger_dashboard {
    /**
     * Get the default slicing given a tensor shape.
     * @param shape: The tensor shape, represented as an Array of number.
     * @return: Numpy-style slicing string, with the surrounding brackets, e.g.,
     *   '[::2, 0:10]'.
     */
    function getDefaultSlicing(shape: number[]): string;
    /**
     * Determine rank of a slicing string.
     * @param slicing The slicing string.
     * @return The rank.
     */
    function rankFromSlicing(slicing: string): number;
}
