/* Copyright 2018 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the 'License');
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an 'AS IS' BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
/* TypeScript module for predicates on health pills. */
var tf_debugger_dashboard;
(function (tf_debugger_dashboard) {
    function checkRefValue(refValue, condition) {
        if (refValue == null) {
            throw new Error("Missing refValue for condition (" + condition + ").");
        }
    }
    function isHealthPillUninitializedOrUnsupported(healthPill) {
        return healthPill == null || healthPill.length == 0 || healthPill[0] !== 1;
    }
    /**
     * A collection of tensor value conditions.
     *
     * With the human-readable description and the predicate function for each
     *   condition.
     */
    var tensorConditions = {
        INF_OR_NAN: {
            description: 'Contains +/-∞ or NaN',
            predicate: function (healthPill, refValue) {
                return healthPill[2] > 0 || healthPill[3] > 0 || healthPill[7] > 0;
            },
        },
        INF: {
            description: 'Contains +/-∞',
            predicate: function (healthPill, refValue) {
                return healthPill[3] > 0 || healthPill[7] > 0;
            },
        },
        NAN: {
            description: 'Contains NaN',
            predicate: function (healthPill, refValue) {
                return healthPill[2] > 0;
            },
        },
        MAX_GT: {
            description: 'Max >',
            predicate: function (healthPill, refValue) {
                checkRefValue(refValue, 'MAX_GT');
                return healthPill[9] > refValue;
            },
        },
        MAX_LT: {
            description: 'Max <',
            predicate: function (healthPill, refValue) {
                checkRefValue(refValue, 'MAX_LT');
                return healthPill[9] < refValue;
            },
        },
        MIN_GT: {
            description: 'Min >',
            predicate: function (healthPill, refValue) {
                checkRefValue(refValue, 'MIN_GT');
                return healthPill[8] > refValue;
            },
        },
        MIN_LT: {
            description: 'Min <',
            predicate: function (healthPill, refValue) {
                checkRefValue(refValue, 'MIN_LT');
                return healthPill[8] < refValue;
            },
        },
        MEAN_GT: {
            description: 'Mean >',
            predicate: function (healthPill, refValue) {
                checkRefValue(refValue, 'MEAN_GT');
                return healthPill[10] > refValue;
            },
        },
        MEAN_LT: {
            description: 'Mean <',
            predicate: function (healthPill, refValue) {
                checkRefValue(refValue, 'MEAN_LT');
                return healthPill[10] < refValue;
            },
        },
        RANGE_GT: {
            description: 'Max - Min >',
            predicate: function (healthPill, refValue) {
                checkRefValue(refValue, 'RANGE_GT');
                return healthPill[9] - healthPill[8] > refValue;
            },
        },
        RANGE_LT: {
            description: 'Max - Min <',
            predicate: function (healthPill, refValue) {
                checkRefValue(refValue, 'RANGE_LT');
                return healthPill[9] - healthPill[8] < refValue;
            },
        },
        STDDEV_GT: {
            description: 'Standard deviation >',
            predicate: function (healthPill, refValue) {
                checkRefValue(refValue, 'STDDEV_GT');
                return Math.sqrt(healthPill[11]) > refValue;
            },
        },
        STDDEV_LT: {
            description: 'Standard deviation <',
            predicate: function (healthPill, refValue) {
                checkRefValue(refValue, 'STDDEV_LT');
                return Math.sqrt(healthPill[11]) < refValue;
            },
        },
    };
    /**
     * Convert human-readable description of a tensor-value condition to its key.
     * @param description Human-readable description.
     * @returns The key, if exists. Else, `null`.
     */
    function tensorConditionDescription2Key(description) {
        for (var key in tensorConditions) {
            if (!tensorConditions.hasOwnProperty(key)) {
                continue;
            }
            if (tensorConditions[key].description === description) {
                return key;
            }
        }
        return null;
    }
    tf_debugger_dashboard.tensorConditionDescription2Key = tensorConditionDescription2Key;
    /**
     * Test a health pill against a tensor-value condition.
     * @param key Key for the tensor-value condition, see `tensorConditions` for
     *   details.
     * @param healthPill The health pill.
     * @param refValue The reference value required by some of the tensor-value
     *   conditions, e.g., `MEAN_LT`.
     * @returns Whether the tensor condition specified by `key` (and potentially
     *   also `revValue` for some `key` values) is satisfied by `healthPill`.
     */
    function checkHealthPillAgainstTensorConditionKey(key, healthPill, refValue) {
        if (isHealthPillUninitializedOrUnsupported(healthPill)) {
            return false;
        }
        var predicate = tensorConditions[key].predicate;
        return predicate(healthPill, refValue);
    }
    tf_debugger_dashboard.checkHealthPillAgainstTensorConditionKey = checkHealthPillAgainstTensorConditionKey;
})(tf_debugger_dashboard || (tf_debugger_dashboard = {}));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaGVhbHRoLXBpbGxzLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiaGVhbHRoLXBpbGxzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7Ozs7Ozs7Ozs7O2dGQWFnRjtBQUNoRix1REFBdUQ7QUFFdkQsSUFBVSxxQkFBcUIsQ0F1SzlCO0FBdktELFdBQVUscUJBQXFCO0lBRS9CLHVCQUF1QixRQUFnQixFQUFFLFNBQWlCO1FBQ3hELElBQUksUUFBUSxJQUFJLElBQUksRUFBRTtZQUNwQixNQUFNLElBQUksS0FBSyxDQUFDLHFDQUFtQyxTQUFTLE9BQUksQ0FBQyxDQUFDO1NBQ25FO0lBQ0gsQ0FBQztJQXVCRCxnREFBZ0QsVUFBb0I7UUFDbEUsT0FBTyxVQUFVLElBQUksSUFBSSxJQUFJLFVBQVUsQ0FBQyxNQUFNLElBQUksQ0FBQyxJQUFJLFVBQVUsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDN0UsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsSUFBTSxnQkFBZ0IsR0FBcUM7UUFDekQsVUFBVSxFQUFFO1lBQ1YsV0FBVyxFQUFFLHNCQUFzQjtZQUNuQyxTQUFTLEVBQUUsVUFBQyxVQUFvQixFQUFFLFFBQWlCO2dCQUNqRCxPQUFPLFVBQVUsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksVUFBVSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxVQUFVLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ3JFLENBQUM7U0FDRjtRQUNELEdBQUcsRUFBRTtZQUNILFdBQVcsRUFBRSxlQUFlO1lBQzVCLFNBQVMsRUFBRSxVQUFDLFVBQW9CLEVBQUUsUUFBaUI7Z0JBQ2pELE9BQU8sVUFBVSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxVQUFVLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ2hELENBQUM7U0FDRjtRQUNELEdBQUcsRUFBRTtZQUNILFdBQVcsRUFBRSxjQUFjO1lBQzNCLFNBQVMsRUFBRSxVQUFDLFVBQW9CLEVBQUUsUUFBaUI7Z0JBQ2pELE9BQU8sVUFBVSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUMzQixDQUFDO1NBQ0Y7UUFDRCxNQUFNLEVBQUU7WUFDTixXQUFXLEVBQUUsT0FBTztZQUNwQixTQUFTLEVBQUUsVUFBQyxVQUFvQixFQUFFLFFBQWlCO2dCQUNqRCxhQUFhLENBQUMsUUFBUSxFQUFFLFFBQVEsQ0FBQyxDQUFDO2dCQUNsQyxPQUFPLFVBQVUsQ0FBQyxDQUFDLENBQUMsR0FBRyxRQUFRLENBQUM7WUFDbEMsQ0FBQztTQUNGO1FBQ0QsTUFBTSxFQUFFO1lBQ04sV0FBVyxFQUFFLE9BQU87WUFDcEIsU0FBUyxFQUFFLFVBQUMsVUFBb0IsRUFBRSxRQUFpQjtnQkFDakQsYUFBYSxDQUFDLFFBQVEsRUFBRSxRQUFRLENBQUMsQ0FBQztnQkFDbEMsT0FBTyxVQUFVLENBQUMsQ0FBQyxDQUFDLEdBQUcsUUFBUSxDQUFDO1lBQ2xDLENBQUM7U0FDRjtRQUNELE1BQU0sRUFBRTtZQUNOLFdBQVcsRUFBRSxPQUFPO1lBQ3BCLFNBQVMsRUFBRSxVQUFDLFVBQW9CLEVBQUUsUUFBaUI7Z0JBQ2pELGFBQWEsQ0FBQyxRQUFRLEVBQUUsUUFBUSxDQUFDLENBQUM7Z0JBQ2xDLE9BQU8sVUFBVSxDQUFDLENBQUMsQ0FBQyxHQUFHLFFBQVEsQ0FBQztZQUNsQyxDQUFDO1NBQ0Y7UUFDRCxNQUFNLEVBQUU7WUFDTixXQUFXLEVBQUUsT0FBTztZQUNwQixTQUFTLEVBQUUsVUFBQyxVQUFvQixFQUFFLFFBQWlCO2dCQUNqRCxhQUFhLENBQUMsUUFBUSxFQUFFLFFBQVEsQ0FBQyxDQUFDO2dCQUNsQyxPQUFPLFVBQVUsQ0FBQyxDQUFDLENBQUMsR0FBRyxRQUFRLENBQUM7WUFDbEMsQ0FBQztTQUNGO1FBQ0QsT0FBTyxFQUFFO1lBQ1AsV0FBVyxFQUFFLFFBQVE7WUFDckIsU0FBUyxFQUFFLFVBQUMsVUFBb0IsRUFBRSxRQUFpQjtnQkFDakQsYUFBYSxDQUFDLFFBQVEsRUFBRSxTQUFTLENBQUMsQ0FBQztnQkFDbkMsT0FBTyxVQUFVLENBQUMsRUFBRSxDQUFDLEdBQUcsUUFBUSxDQUFDO1lBQ25DLENBQUM7U0FDRjtRQUNELE9BQU8sRUFBRTtZQUNQLFdBQVcsRUFBRSxRQUFRO1lBQ3JCLFNBQVMsRUFBRSxVQUFDLFVBQW9CLEVBQUUsUUFBaUI7Z0JBQ2pELGFBQWEsQ0FBQyxRQUFRLEVBQUUsU0FBUyxDQUFDLENBQUM7Z0JBQ25DLE9BQU8sVUFBVSxDQUFDLEVBQUUsQ0FBQyxHQUFHLFFBQVEsQ0FBQztZQUNuQyxDQUFDO1NBQ0Y7UUFDRCxRQUFRLEVBQUU7WUFDUixXQUFXLEVBQUUsYUFBYTtZQUMxQixTQUFTLEVBQUUsVUFBQyxVQUFvQixFQUFFLFFBQWlCO2dCQUNqRCxhQUFhLENBQUMsUUFBUSxFQUFFLFVBQVUsQ0FBQyxDQUFDO2dCQUNwQyxPQUFPLFVBQVUsQ0FBQyxDQUFDLENBQUMsR0FBRyxVQUFVLENBQUMsQ0FBQyxDQUFDLEdBQUcsUUFBUSxDQUFDO1lBQ2xELENBQUM7U0FDRjtRQUNELFFBQVEsRUFBRTtZQUNSLFdBQVcsRUFBRSxhQUFhO1lBQzFCLFNBQVMsRUFBRSxVQUFDLFVBQW9CLEVBQUUsUUFBaUI7Z0JBQ2pELGFBQWEsQ0FBQyxRQUFRLEVBQUUsVUFBVSxDQUFDLENBQUM7Z0JBQ3BDLE9BQU8sVUFBVSxDQUFDLENBQUMsQ0FBQyxHQUFHLFVBQVUsQ0FBQyxDQUFDLENBQUMsR0FBRyxRQUFRLENBQUM7WUFDbEQsQ0FBQztTQUNGO1FBQ0QsU0FBUyxFQUFFO1lBQ1QsV0FBVyxFQUFFLHNCQUFzQjtZQUNuQyxTQUFTLEVBQUUsVUFBQyxVQUFvQixFQUFFLFFBQWlCO2dCQUNqRCxhQUFhLENBQUMsUUFBUSxFQUFFLFdBQVcsQ0FBQyxDQUFDO2dCQUNyQyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEdBQUcsUUFBUSxDQUFDO1lBQzlDLENBQUM7U0FDRjtRQUNELFNBQVMsRUFBRTtZQUNULFdBQVcsRUFBRSxzQkFBc0I7WUFDbkMsU0FBUyxFQUFFLFVBQUMsVUFBb0IsRUFBRSxRQUFpQjtnQkFDakQsYUFBYSxDQUFDLFFBQVEsRUFBRSxXQUFXLENBQUMsQ0FBQztnQkFDckMsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFHLFFBQVEsQ0FBQztZQUM5QyxDQUFDO1NBQ0Y7S0FDRixDQUFDO0lBRUY7Ozs7T0FJRztJQUNILHdDQUErQyxXQUFtQjtRQUNoRSxLQUFLLElBQU0sR0FBRyxJQUFJLGdCQUFnQixFQUFFO1lBQ2xDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLEVBQUU7Z0JBQ3pDLFNBQVM7YUFDVjtZQUNELElBQUksZ0JBQWdCLENBQUMsR0FBRyxDQUFDLENBQUMsV0FBVyxLQUFLLFdBQVcsRUFBRTtnQkFDckQsT0FBTyxHQUFHLENBQUM7YUFDWjtTQUNGO1FBQ0QsT0FBTyxJQUFJLENBQUM7SUFDZCxDQUFDO0lBVmUsb0RBQThCLGlDQVU3QyxDQUFBO0lBR0Q7Ozs7Ozs7OztPQVNHO0lBQ0gsa0RBQ0ksR0FBVyxFQUFFLFVBQW9CLEVBQUUsUUFBaUI7UUFDdEQsSUFBSSxzQ0FBc0MsQ0FBQyxVQUFVLENBQUMsRUFBRTtZQUN0RCxPQUFPLEtBQUssQ0FBQztTQUNkO1FBQ0QsSUFBTSxTQUFTLEdBQUcsZ0JBQWdCLENBQUMsR0FBRyxDQUFDLENBQUMsU0FBUyxDQUFDO1FBQ2xELE9BQU8sU0FBUyxDQUFDLFVBQVUsRUFBRSxRQUFRLENBQUMsQ0FBQztJQUN6QyxDQUFDO0lBUGUsOERBQXdDLDJDQU92RCxDQUFBO0FBRUQsQ0FBQyxFQXZLUyxxQkFBcUIsS0FBckIscUJBQXFCLFFBdUs5QiIsInNvdXJjZXNDb250ZW50IjpbIi8qIENvcHlyaWdodCAyMDE4IFRoZSBUZW5zb3JGbG93IEF1dGhvcnMuIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG5cbkxpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSAnTGljZW5zZScpO1xueW91IG1heSBub3QgdXNlIHRoaXMgZmlsZSBleGNlcHQgaW4gY29tcGxpYW5jZSB3aXRoIHRoZSBMaWNlbnNlLlxuWW91IG1heSBvYnRhaW4gYSBjb3B5IG9mIHRoZSBMaWNlbnNlIGF0XG5cbiAgICBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcblxuVW5sZXNzIHJlcXVpcmVkIGJ5IGFwcGxpY2FibGUgbGF3IG9yIGFncmVlZCB0byBpbiB3cml0aW5nLCBzb2Z0d2FyZVxuZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIExpY2Vuc2UgaXMgZGlzdHJpYnV0ZWQgb24gYW4gJ0FTIElTJyBCQVNJUyxcbldJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWSBLSU5ELCBlaXRoZXIgZXhwcmVzcyBvciBpbXBsaWVkLlxuU2VlIHRoZSBMaWNlbnNlIGZvciB0aGUgc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nIHBlcm1pc3Npb25zIGFuZFxubGltaXRhdGlvbnMgdW5kZXIgdGhlIExpY2Vuc2UuXG49PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0qL1xuLyogVHlwZVNjcmlwdCBtb2R1bGUgZm9yIHByZWRpY2F0ZXMgb24gaGVhbHRoIHBpbGxzLiAqL1xuXG5uYW1lc3BhY2UgdGZfZGVidWdnZXJfZGFzaGJvYXJkIHtcblxuZnVuY3Rpb24gY2hlY2tSZWZWYWx1ZShyZWZWYWx1ZTogbnVtYmVyLCBjb25kaXRpb246IHN0cmluZykge1xuICBpZiAocmVmVmFsdWUgPT0gbnVsbCkge1xuICAgIHRocm93IG5ldyBFcnJvcihgTWlzc2luZyByZWZWYWx1ZSBmb3IgY29uZGl0aW9uICgke2NvbmRpdGlvbn0pLmApO1xuICB9XG59XG5cbi8qKlxuICogQ2hlY2sgaWYgYSBoZWFsdGggcGlsbCBtZWV0cyB0aGUgZ2l2ZW4gY29uZGl0aW9uLlxuICpcbiAqIEFueSBjb25kaXRpb24gdmFsdWUgdGhhdCBpbnZvbHZlcyBudW1lcmljYWwgY29tcGFyaXNvbiByZXF1aXJlIGEgdmFsdWVcbiAqICAgaW4gdGhlIGByZWZWYWx1ZWAgYXJndW1lbnQgKHNlZSBiZWxvdykuXG4gKiBAcGFyYW0gaGVhbHRoUGlsbCBUaGUgaGVhbHRoIHBpbGwuXG4gKiBAcGFyYW0gcmVmVmFsdWUgVGhyZXNob2xkIHJlcXVpcmVkIGJ5IHNvbWUgb2YgdGhlIGNvbmRpdGlvbiB2YWx1ZXMuIElmIG5vdFxuICogICBwcm92aWRlZCBmb3Igc3VjaCBjb25kaXRpb25zLCBhbiBFcnJvciB3aWxsIGJlIHRocm93bi5cbiAqIEByZXR1cm4gV2hldGhlciB0aGUgY29uZGl0aW9uIGlzIG1ldC5cbiAqIEB0aHJvd3MgRXJyb3Igb24gaW4gdmFsaWQgY29uZGl0aW9uIHZhbHVlcyBvciBtaXNzaW5nIHJlZlZhbHVlIGZvciBjb25kaXRpb25zXG4gKiAgIHRoYXQgcmVxdWlyZXMgaXQuXG4gKi9cbmV4cG9ydCB0eXBlIFRlbnNvckNvbmRpdGlvblByZWRpY2F0ZSA9XG4gICAgKGhlYWx0aFBpbGw6IG51bWJlcltdLCByZWZWYWx1ZT86IG51bWJlcikgPT4gYm9vbGVhbjtcblxuXG5leHBvcnQgaW50ZXJmYWNlIFRlbnNvckNvbmRpdGlvbiB7XG4gIGRlc2NyaXB0aW9uOiBzdHJpbmc7XG4gIHByZWRpY2F0ZTogVGVuc29yQ29uZGl0aW9uUHJlZGljYXRlO1xufVxuXG5mdW5jdGlvbiBpc0hlYWx0aFBpbGxVbmluaXRpYWxpemVkT3JVbnN1cHBvcnRlZChoZWFsdGhQaWxsOiBudW1iZXJbXSk6IGJvb2xlYW4ge1xuICByZXR1cm4gaGVhbHRoUGlsbCA9PSBudWxsIHx8IGhlYWx0aFBpbGwubGVuZ3RoID09IDAgfHwgaGVhbHRoUGlsbFswXSAhPT0gMTtcbn1cblxuLyoqXG4gKiBBIGNvbGxlY3Rpb24gb2YgdGVuc29yIHZhbHVlIGNvbmRpdGlvbnMuXG4gKlxuICogV2l0aCB0aGUgaHVtYW4tcmVhZGFibGUgZGVzY3JpcHRpb24gYW5kIHRoZSBwcmVkaWNhdGUgZnVuY3Rpb24gZm9yIGVhY2hcbiAqICAgY29uZGl0aW9uLlxuICovXG5jb25zdCB0ZW5zb3JDb25kaXRpb25zOiB7W2tleTogc3RyaW5nXTogVGVuc29yQ29uZGl0aW9ufSA9IHtcbiAgSU5GX09SX05BTjoge1xuICAgIGRlc2NyaXB0aW9uOiAnQ29udGFpbnMgKy8t4oieIG9yIE5hTicsXG4gICAgcHJlZGljYXRlOiAoaGVhbHRoUGlsbDogbnVtYmVyW10sIHJlZlZhbHVlPzogbnVtYmVyKSA9PiB7XG4gICAgICByZXR1cm4gaGVhbHRoUGlsbFsyXSA+IDAgfHwgaGVhbHRoUGlsbFszXSA+IDAgfHwgaGVhbHRoUGlsbFs3XSA+IDA7XG4gICAgfSxcbiAgfSxcbiAgSU5GOiB7XG4gICAgZGVzY3JpcHRpb246ICdDb250YWlucyArLy3iiJ4nLFxuICAgIHByZWRpY2F0ZTogKGhlYWx0aFBpbGw6IG51bWJlcltdLCByZWZWYWx1ZT86IG51bWJlcikgPT4ge1xuICAgICAgcmV0dXJuIGhlYWx0aFBpbGxbM10gPiAwIHx8IGhlYWx0aFBpbGxbN10gPiAwO1xuICAgIH0sXG4gIH0sXG4gIE5BTjoge1xuICAgIGRlc2NyaXB0aW9uOiAnQ29udGFpbnMgTmFOJyxcbiAgICBwcmVkaWNhdGU6IChoZWFsdGhQaWxsOiBudW1iZXJbXSwgcmVmVmFsdWU/OiBudW1iZXIpID0+IHtcbiAgICAgIHJldHVybiBoZWFsdGhQaWxsWzJdID4gMDtcbiAgICB9LFxuICB9LFxuICBNQVhfR1Q6IHtcbiAgICBkZXNjcmlwdGlvbjogJ01heCA+JyxcbiAgICBwcmVkaWNhdGU6IChoZWFsdGhQaWxsOiBudW1iZXJbXSwgcmVmVmFsdWU/OiBudW1iZXIpID0+IHtcbiAgICAgIGNoZWNrUmVmVmFsdWUocmVmVmFsdWUsICdNQVhfR1QnKTtcbiAgICAgIHJldHVybiBoZWFsdGhQaWxsWzldID4gcmVmVmFsdWU7XG4gICAgfSxcbiAgfSxcbiAgTUFYX0xUOiB7XG4gICAgZGVzY3JpcHRpb246ICdNYXggPCcsXG4gICAgcHJlZGljYXRlOiAoaGVhbHRoUGlsbDogbnVtYmVyW10sIHJlZlZhbHVlPzogbnVtYmVyKSA9PiB7XG4gICAgICBjaGVja1JlZlZhbHVlKHJlZlZhbHVlLCAnTUFYX0xUJyk7XG4gICAgICByZXR1cm4gaGVhbHRoUGlsbFs5XSA8IHJlZlZhbHVlO1xuICAgIH0sXG4gIH0sXG4gIE1JTl9HVDoge1xuICAgIGRlc2NyaXB0aW9uOiAnTWluID4nLFxuICAgIHByZWRpY2F0ZTogKGhlYWx0aFBpbGw6IG51bWJlcltdLCByZWZWYWx1ZT86IG51bWJlcikgPT4ge1xuICAgICAgY2hlY2tSZWZWYWx1ZShyZWZWYWx1ZSwgJ01JTl9HVCcpO1xuICAgICAgcmV0dXJuIGhlYWx0aFBpbGxbOF0gPiByZWZWYWx1ZTtcbiAgICB9LFxuICB9LFxuICBNSU5fTFQ6IHtcbiAgICBkZXNjcmlwdGlvbjogJ01pbiA8JyxcbiAgICBwcmVkaWNhdGU6IChoZWFsdGhQaWxsOiBudW1iZXJbXSwgcmVmVmFsdWU/OiBudW1iZXIpID0+IHtcbiAgICAgIGNoZWNrUmVmVmFsdWUocmVmVmFsdWUsICdNSU5fTFQnKTtcbiAgICAgIHJldHVybiBoZWFsdGhQaWxsWzhdIDwgcmVmVmFsdWU7XG4gICAgfSxcbiAgfSxcbiAgTUVBTl9HVDoge1xuICAgIGRlc2NyaXB0aW9uOiAnTWVhbiA+JyxcbiAgICBwcmVkaWNhdGU6IChoZWFsdGhQaWxsOiBudW1iZXJbXSwgcmVmVmFsdWU/OiBudW1iZXIpID0+IHtcbiAgICAgIGNoZWNrUmVmVmFsdWUocmVmVmFsdWUsICdNRUFOX0dUJyk7XG4gICAgICByZXR1cm4gaGVhbHRoUGlsbFsxMF0gPiByZWZWYWx1ZTtcbiAgICB9LFxuICB9LFxuICBNRUFOX0xUOiB7XG4gICAgZGVzY3JpcHRpb246ICdNZWFuIDwnLFxuICAgIHByZWRpY2F0ZTogKGhlYWx0aFBpbGw6IG51bWJlcltdLCByZWZWYWx1ZT86IG51bWJlcikgPT4ge1xuICAgICAgY2hlY2tSZWZWYWx1ZShyZWZWYWx1ZSwgJ01FQU5fTFQnKTtcbiAgICAgIHJldHVybiBoZWFsdGhQaWxsWzEwXSA8IHJlZlZhbHVlO1xuICAgIH0sXG4gIH0sXG4gIFJBTkdFX0dUOiB7XG4gICAgZGVzY3JpcHRpb246ICdNYXggLSBNaW4gPicsXG4gICAgcHJlZGljYXRlOiAoaGVhbHRoUGlsbDogbnVtYmVyW10sIHJlZlZhbHVlPzogbnVtYmVyKSA9PiB7XG4gICAgICBjaGVja1JlZlZhbHVlKHJlZlZhbHVlLCAnUkFOR0VfR1QnKTtcbiAgICAgIHJldHVybiBoZWFsdGhQaWxsWzldIC0gaGVhbHRoUGlsbFs4XSA+IHJlZlZhbHVlO1xuICAgIH0sXG4gIH0sXG4gIFJBTkdFX0xUOiB7XG4gICAgZGVzY3JpcHRpb246ICdNYXggLSBNaW4gPCcsXG4gICAgcHJlZGljYXRlOiAoaGVhbHRoUGlsbDogbnVtYmVyW10sIHJlZlZhbHVlPzogbnVtYmVyKSA9PiB7XG4gICAgICBjaGVja1JlZlZhbHVlKHJlZlZhbHVlLCAnUkFOR0VfTFQnKTtcbiAgICAgIHJldHVybiBoZWFsdGhQaWxsWzldIC0gaGVhbHRoUGlsbFs4XSA8IHJlZlZhbHVlO1xuICAgIH0sXG4gIH0sXG4gIFNURERFVl9HVDoge1xuICAgIGRlc2NyaXB0aW9uOiAnU3RhbmRhcmQgZGV2aWF0aW9uID4nLFxuICAgIHByZWRpY2F0ZTogKGhlYWx0aFBpbGw6IG51bWJlcltdLCByZWZWYWx1ZT86IG51bWJlcikgPT4ge1xuICAgICAgY2hlY2tSZWZWYWx1ZShyZWZWYWx1ZSwgJ1NURERFVl9HVCcpO1xuICAgICAgcmV0dXJuIE1hdGguc3FydChoZWFsdGhQaWxsWzExXSkgPiByZWZWYWx1ZTtcbiAgICB9LFxuICB9LFxuICBTVERERVZfTFQ6IHtcbiAgICBkZXNjcmlwdGlvbjogJ1N0YW5kYXJkIGRldmlhdGlvbiA8JyxcbiAgICBwcmVkaWNhdGU6IChoZWFsdGhQaWxsOiBudW1iZXJbXSwgcmVmVmFsdWU/OiBudW1iZXIpID0+IHtcbiAgICAgIGNoZWNrUmVmVmFsdWUocmVmVmFsdWUsICdTVERERVZfTFQnKTtcbiAgICAgIHJldHVybiBNYXRoLnNxcnQoaGVhbHRoUGlsbFsxMV0pIDwgcmVmVmFsdWU7XG4gICAgfSxcbiAgfSxcbn07XG5cbi8qKlxuICogQ29udmVydCBodW1hbi1yZWFkYWJsZSBkZXNjcmlwdGlvbiBvZiBhIHRlbnNvci12YWx1ZSBjb25kaXRpb24gdG8gaXRzIGtleS5cbiAqIEBwYXJhbSBkZXNjcmlwdGlvbiBIdW1hbi1yZWFkYWJsZSBkZXNjcmlwdGlvbi5cbiAqIEByZXR1cm5zIFRoZSBrZXksIGlmIGV4aXN0cy4gRWxzZSwgYG51bGxgLlxuICovXG5leHBvcnQgZnVuY3Rpb24gdGVuc29yQ29uZGl0aW9uRGVzY3JpcHRpb24yS2V5KGRlc2NyaXB0aW9uOiBzdHJpbmcpOiBzdHJpbmcge1xuICBmb3IgKGNvbnN0IGtleSBpbiB0ZW5zb3JDb25kaXRpb25zKSB7XG4gICAgaWYgKCF0ZW5zb3JDb25kaXRpb25zLmhhc093blByb3BlcnR5KGtleSkpIHtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBpZiAodGVuc29yQ29uZGl0aW9uc1trZXldLmRlc2NyaXB0aW9uID09PSBkZXNjcmlwdGlvbikge1xuICAgICAgcmV0dXJuIGtleTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIG51bGw7XG59XG5cblxuLyoqXG4gKiBUZXN0IGEgaGVhbHRoIHBpbGwgYWdhaW5zdCBhIHRlbnNvci12YWx1ZSBjb25kaXRpb24uXG4gKiBAcGFyYW0ga2V5IEtleSBmb3IgdGhlIHRlbnNvci12YWx1ZSBjb25kaXRpb24sIHNlZSBgdGVuc29yQ29uZGl0aW9uc2AgZm9yXG4gKiAgIGRldGFpbHMuXG4gKiBAcGFyYW0gaGVhbHRoUGlsbCBUaGUgaGVhbHRoIHBpbGwuXG4gKiBAcGFyYW0gcmVmVmFsdWUgVGhlIHJlZmVyZW5jZSB2YWx1ZSByZXF1aXJlZCBieSBzb21lIG9mIHRoZSB0ZW5zb3ItdmFsdWVcbiAqICAgY29uZGl0aW9ucywgZS5nLiwgYE1FQU5fTFRgLlxuICogQHJldHVybnMgV2hldGhlciB0aGUgdGVuc29yIGNvbmRpdGlvbiBzcGVjaWZpZWQgYnkgYGtleWAgKGFuZCBwb3RlbnRpYWxseVxuICogICBhbHNvIGByZXZWYWx1ZWAgZm9yIHNvbWUgYGtleWAgdmFsdWVzKSBpcyBzYXRpc2ZpZWQgYnkgYGhlYWx0aFBpbGxgLlxuICovXG5leHBvcnQgZnVuY3Rpb24gY2hlY2tIZWFsdGhQaWxsQWdhaW5zdFRlbnNvckNvbmRpdGlvbktleShcbiAgICBrZXk6IHN0cmluZywgaGVhbHRoUGlsbDogbnVtYmVyW10sIHJlZlZhbHVlPzogbnVtYmVyKTogYm9vbGVhbiB7XG4gIGlmIChpc0hlYWx0aFBpbGxVbmluaXRpYWxpemVkT3JVbnN1cHBvcnRlZChoZWFsdGhQaWxsKSkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBjb25zdCBwcmVkaWNhdGUgPSB0ZW5zb3JDb25kaXRpb25zW2tleV0ucHJlZGljYXRlO1xuICByZXR1cm4gcHJlZGljYXRlKGhlYWx0aFBpbGwsIHJlZlZhbHVlKTtcbn1cblxufVxuIl19