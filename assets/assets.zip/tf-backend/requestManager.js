var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
/* Copyright 2015 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the 'License');
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an 'AS IS' BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
var tf_backend;
(function (tf_backend) {
    /*==============================================================================
    
      Please do not use RequestManager for new code.
    
      We've generally found code that uses XMLHttpRequest without promises is
      easier to understand and maintain. This API also makes it difficult to use
      the HTTP protocol in an idiomatic RESTful manner.
    
    ==============================================================================*/
    /**
     * Manages many fetch requests. Launches up to nSimultaneousRequests
     * simultaneously, and maintains a LIFO queue of requests to process when
     * more urls are requested than can be handled at once. The queue can be
     * cleared.
     *
     * When a request is made, a Promise is returned which resolves with the
     * parsed JSON result from the request.
     */
    var RequestCancellationError = /** @class */ (function (_super) {
        __extends(RequestCancellationError, _super);
        function RequestCancellationError() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.name = 'RequestCancellationError';
            return _this;
        }
        return RequestCancellationError;
    }(Error));
    tf_backend.RequestCancellationError = RequestCancellationError;
    var RequestNetworkError = /** @class */ (function (_super) {
        __extends(RequestNetworkError, _super);
        function RequestNetworkError(req, url) {
            var _this = _super.call(this) || this;
            _this.message = "RequestNetworkError: " + req.status + " at " + url;
            _this.name = 'RequestNetworkError';
            _this.req = req;
            _this.url = url;
            return _this;
        }
        return RequestNetworkError;
    }(Error));
    tf_backend.RequestNetworkError = RequestNetworkError;
    var RequestManager = /** @class */ (function () {
        function RequestManager(nSimultaneousRequests, maxRetries) {
            if (nSimultaneousRequests === void 0) { nSimultaneousRequests = 10; }
            if (maxRetries === void 0) { maxRetries = 3; }
            this._queue = [];
            this._nActiveRequests = 0;
            this._nSimultaneousRequests = nSimultaneousRequests;
            this._maxRetries = maxRetries;
        }
        /**
         * Gives a promise that loads assets from given url (respects queuing). If
         * postData is provided, this request will use POST, not GET. This is an
         * object mapping POST keys to string values.
         */
        RequestManager.prototype.request = function (url, postData) {
            var _this = this;
            var promise = new Promise(function (resolve, reject) {
                var resolver = { resolve: resolve, reject: reject };
                _this._queue.push(resolver);
                _this.launchRequests();
            })
                .then(function () {
                return _this.promiseWithRetries(url, _this._maxRetries, postData);
            })
                .then(function (response) {
                // Success - Let's free space for another active
                // request, and launch it
                _this._nActiveRequests--;
                _this.launchRequests();
                return response;
            }, function (rejection) {
                if (rejection.name === 'RequestNetworkError') {
                    // If we failed due to network error, we should
                    // decrement
                    // _nActiveRequests because this request was
                    // active
                    _this._nActiveRequests--;
                    _this.launchRequests();
                }
                return Promise.reject(rejection);
            });
            return promise;
        };
        RequestManager.prototype.clearQueue = function () {
            while (this._queue.length > 0) {
                this._queue.pop().reject(new RequestCancellationError('Request cancelled by clearQueue'));
            }
        };
        /* Return number of currently pending requests */
        RequestManager.prototype.activeRequests = function () {
            return this._nActiveRequests;
        };
        /* Return total number of outstanding requests (includes queue) */
        RequestManager.prototype.outstandingRequests = function () {
            return this._nActiveRequests + this._queue.length;
        };
        RequestManager.prototype.launchRequests = function () {
            while (this._nActiveRequests < this._nSimultaneousRequests &&
                this._queue.length > 0) {
                this._nActiveRequests++;
                this._queue.pop().resolve();
            }
        };
        /**
         * Try to request a given URL using overwritable _promiseFromUrl method.
         * If the request fails for any reason, we will retry up to maxRetries
         * times. In practice, this will help us paper over transient network issues
         * like '502 Bad Gateway'.
         * By default, Chrome displays network errors in console, so
         * the user will be able to tell when the requests are failing. I think this
         * is a feature, if the request failures and retries are causing any
         * pain to users, they can see it and file issues.
         */
        RequestManager.prototype.promiseWithRetries = function (url, maxRetries, postData) {
            var _this = this;
            var success = function (x) { return x; };
            var failure = function (x) {
                if (maxRetries > 0) {
                    return _this.promiseWithRetries(url, maxRetries - 1, postData);
                }
                else {
                    return Promise.reject(x);
                }
            };
            return this._promiseFromUrl(url, postData).then(success, failure);
        };
        /* Actually get promise from url using XMLHttpRequest */
        RequestManager.prototype._promiseFromUrl = function (url, postData) {
            return new Promise(function (resolve, reject) {
                var req = new XMLHttpRequest();
                req.open(postData ? 'POST' : 'GET', url);
                var formData;
                if (postData) {
                    // We are to make a POST request.
                    formData = new FormData();
                    for (var postKey in postData) {
                        if (postKey) {
                            // The linter requires 'for in' loops to be filtered by an if
                            // condition.
                            formData.append(postKey, postData[postKey]);
                        }
                    }
                }
                req.onload = function () {
                    if (req.status === 200) {
                        resolve(JSON.parse(req.responseText));
                    }
                    else {
                        reject(new RequestNetworkError(req, url));
                    }
                };
                req.onerror = function () {
                    reject(new RequestNetworkError(req, url));
                };
                req.send(formData);
            });
        };
        return RequestManager;
    }());
    tf_backend.RequestManager = RequestManager;
})(tf_backend || (tf_backend = {})); // namespace tf_backend
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVxdWVzdE1hbmFnZXIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJyZXF1ZXN0TWFuYWdlci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7O0FBQUE7Ozs7Ozs7Ozs7Ozs7Z0ZBYWdGO0FBQ2hGLElBQVUsVUFBVSxDQWtMbkI7QUFsTEQsV0FBVSxVQUFVO0lBR3BCOzs7Ozs7OztvRkFRZ0Y7SUFRaEY7Ozs7Ozs7O09BUUc7SUFDSDtRQUE4Qyw0Q0FBSztRQUFuRDtZQUFBLHFFQUVDO1lBRFEsVUFBSSxHQUFHLDBCQUEwQixDQUFDOztRQUMzQyxDQUFDO1FBQUQsK0JBQUM7SUFBRCxDQUFDLEFBRkQsQ0FBOEMsS0FBSyxHQUVsRDtJQUZZLG1DQUF3QiwyQkFFcEMsQ0FBQTtJQUVEO1FBQXlDLHVDQUFLO1FBSzVDLDZCQUFZLEdBQW1CLEVBQUUsR0FBRztZQUFwQyxZQUNFLGlCQUFPLFNBS1I7WUFKQyxLQUFJLENBQUMsT0FBTyxHQUFHLDBCQUF3QixHQUFHLENBQUMsTUFBTSxZQUFPLEdBQUssQ0FBQztZQUM5RCxLQUFJLENBQUMsSUFBSSxHQUFHLHFCQUFxQixDQUFDO1lBQ2xDLEtBQUksQ0FBQyxHQUFHLEdBQUcsR0FBRyxDQUFDO1lBQ2YsS0FBSSxDQUFDLEdBQUcsR0FBRyxHQUFHLENBQUM7O1FBQ2pCLENBQUM7UUFDSCwwQkFBQztJQUFELENBQUMsQUFaRCxDQUF5QyxLQUFLLEdBWTdDO0lBWlksOEJBQW1CLHNCQVkvQixDQUFBO0lBRUQ7UUFNRSx3QkFBWSxxQkFBMEIsRUFBRSxVQUFjO1lBQTFDLHNDQUFBLEVBQUEsMEJBQTBCO1lBQUUsMkJBQUEsRUFBQSxjQUFjO1lBQ3BELElBQUksQ0FBQyxNQUFNLEdBQUcsRUFBRSxDQUFDO1lBQ2pCLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxDQUFDLENBQUM7WUFDMUIsSUFBSSxDQUFDLHNCQUFzQixHQUFHLHFCQUFxQixDQUFDO1lBQ3BELElBQUksQ0FBQyxXQUFXLEdBQUcsVUFBVSxDQUFDO1FBQ2hDLENBQUM7UUFFRDs7OztXQUlHO1FBQ0ksZ0NBQU8sR0FBZCxVQUFlLEdBQVcsRUFBRSxRQUFrQztZQUE5RCxpQkErQkM7WUE3QkMsSUFBTSxPQUFPLEdBQ1QsSUFBSSxPQUFPLENBQUMsVUFBQyxPQUFPLEVBQUUsTUFBTTtnQkFDMUIsSUFBTSxRQUFRLEdBQUcsRUFBQyxPQUFPLEVBQUUsT0FBTyxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUMsQ0FBQztnQkFDcEQsS0FBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7Z0JBQzNCLEtBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztZQUN4QixDQUFDLENBQUM7aUJBQ0csSUFBSSxDQUFDO2dCQUNKLE9BQU8sS0FBSSxDQUFDLGtCQUFrQixDQUFDLEdBQUcsRUFBRSxLQUFJLENBQUMsV0FBVyxFQUFFLFFBQVEsQ0FBQyxDQUFDO1lBQ2xFLENBQUMsQ0FBQztpQkFDRCxJQUFJLENBQ0QsVUFBQyxRQUFRO2dCQUNQLGdEQUFnRDtnQkFDaEQseUJBQXlCO2dCQUN6QixLQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztnQkFDeEIsS0FBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO2dCQUN0QixPQUFPLFFBQVEsQ0FBQztZQUNsQixDQUFDLEVBQ0QsVUFBQyxTQUFTO2dCQUNSLElBQUksU0FBUyxDQUFDLElBQUksS0FBSyxxQkFBcUIsRUFBRTtvQkFDNUMsK0NBQStDO29CQUMvQyxZQUFZO29CQUNaLDRDQUE0QztvQkFDNUMsU0FBUztvQkFDVCxLQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztvQkFDeEIsS0FBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO2lCQUN2QjtnQkFDRCxPQUFPLE9BQU8sQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUM7WUFDbkMsQ0FBQyxDQUFDLENBQUM7WUFDZixPQUFPLE9BQU8sQ0FBQztRQUNqQixDQUFDO1FBRU0sbUNBQVUsR0FBakI7WUFDRSxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtnQkFDN0IsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLEVBQUUsQ0FBQyxNQUFNLENBQ3BCLElBQUksd0JBQXdCLENBQUMsaUNBQWlDLENBQUMsQ0FBQyxDQUFDO2FBQ3RFO1FBQ0gsQ0FBQztRQUVELGlEQUFpRDtRQUMxQyx1Q0FBYyxHQUFyQjtZQUNFLE9BQU8sSUFBSSxDQUFDLGdCQUFnQixDQUFDO1FBQy9CLENBQUM7UUFFRCxrRUFBa0U7UUFDM0QsNENBQW1CLEdBQTFCO1lBQ0UsT0FBTyxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7UUFDcEQsQ0FBQztRQUVPLHVDQUFjLEdBQXRCO1lBQ0UsT0FBTyxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLHNCQUFzQjtnQkFDbkQsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO2dCQUM3QixJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztnQkFDeEIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLEVBQUUsQ0FBQzthQUM3QjtRQUNILENBQUM7UUFFRDs7Ozs7Ozs7O1dBU0c7UUFDSywyQ0FBa0IsR0FBMUIsVUFDSSxHQUFXLEVBQUUsVUFBa0IsRUFBRSxRQUFrQztZQUR2RSxpQkFXQztZQVRDLElBQUksT0FBTyxHQUFHLFVBQUMsQ0FBQyxJQUFLLE9BQUEsQ0FBQyxFQUFELENBQUMsQ0FBQztZQUN2QixJQUFJLE9BQU8sR0FBRyxVQUFDLENBQUM7Z0JBQ2QsSUFBSSxVQUFVLEdBQUcsQ0FBQyxFQUFFO29CQUNsQixPQUFPLEtBQUksQ0FBQyxrQkFBa0IsQ0FBQyxHQUFHLEVBQUUsVUFBVSxHQUFHLENBQUMsRUFBRSxRQUFRLENBQUMsQ0FBQztpQkFDL0Q7cUJBQU07b0JBQ0wsT0FBTyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO2lCQUMxQjtZQUNILENBQUMsQ0FBQztZQUNGLE9BQU8sSUFBSSxDQUFDLGVBQWUsQ0FBQyxHQUFHLEVBQUUsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUMsQ0FBQztRQUNwRSxDQUFDO1FBRUQsd0RBQXdEO1FBQzlDLHdDQUFlLEdBQXpCLFVBQTBCLEdBQVcsRUFBRSxRQUFrQztZQUN2RSxPQUFPLElBQUksT0FBTyxDQUFDLFVBQUMsT0FBTyxFQUFFLE1BQU07Z0JBQ2pDLElBQUksR0FBRyxHQUFHLElBQUksY0FBYyxFQUFFLENBQUM7Z0JBQy9CLEdBQUcsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEtBQUssRUFBRSxHQUFHLENBQUMsQ0FBQztnQkFFekMsSUFBSSxRQUFRLENBQUM7Z0JBQ2IsSUFBSSxRQUFRLEVBQUU7b0JBQ1osaUNBQWlDO29CQUNqQyxRQUFRLEdBQUcsSUFBSSxRQUFRLEVBQUUsQ0FBQztvQkFDMUIsS0FBSyxJQUFJLE9BQU8sSUFBSSxRQUFRLEVBQUU7d0JBQzVCLElBQUksT0FBTyxFQUFFOzRCQUNYLDZEQUE2RDs0QkFDN0QsYUFBYTs0QkFDYixRQUFRLENBQUMsTUFBTSxDQUFDLE9BQU8sRUFBRSxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQzt5QkFDN0M7cUJBQ0Y7aUJBQ0Y7Z0JBQ0QsR0FBRyxDQUFDLE1BQU0sR0FBRztvQkFDWCxJQUFJLEdBQUcsQ0FBQyxNQUFNLEtBQUssR0FBRyxFQUFFO3dCQUN0QixPQUFPLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQztxQkFDdkM7eUJBQU07d0JBQ0wsTUFBTSxDQUFDLElBQUksbUJBQW1CLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUM7cUJBQzNDO2dCQUNILENBQUMsQ0FBQztnQkFDRixHQUFHLENBQUMsT0FBTyxHQUFHO29CQUNaLE1BQU0sQ0FBQyxJQUFJLG1CQUFtQixDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDO2dCQUM1QyxDQUFDLENBQUM7Z0JBQ0YsR0FBRyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUNyQixDQUFDLENBQUMsQ0FBQztRQUNMLENBQUM7UUFDSCxxQkFBQztJQUFELENBQUMsQUFsSUQsSUFrSUM7SUFsSVkseUJBQWMsaUJBa0kxQixDQUFBO0FBRUQsQ0FBQyxFQWxMUyxVQUFVLEtBQVYsVUFBVSxRQWtMbkIsQ0FBRSx1QkFBdUIiLCJzb3VyY2VzQ29udGVudCI6WyIvKiBDb3B5cmlnaHQgMjAxNSBUaGUgVGVuc29yRmxvdyBBdXRob3JzLiBBbGwgUmlnaHRzIFJlc2VydmVkLlxuXG5MaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UsIFZlcnNpb24gMi4wICh0aGUgJ0xpY2Vuc2UnKTtcbnlvdSBtYXkgbm90IHVzZSB0aGlzIGZpbGUgZXhjZXB0IGluIGNvbXBsaWFuY2Ugd2l0aCB0aGUgTGljZW5zZS5cbllvdSBtYXkgb2J0YWluIGEgY29weSBvZiB0aGUgTGljZW5zZSBhdFxuXG4gICAgaHR0cDovL3d3dy5hcGFjaGUub3JnL2xpY2Vuc2VzL0xJQ0VOU0UtMi4wXG5cblVubGVzcyByZXF1aXJlZCBieSBhcHBsaWNhYmxlIGxhdyBvciBhZ3JlZWQgdG8gaW4gd3JpdGluZywgc29mdHdhcmVcbmRpc3RyaWJ1dGVkIHVuZGVyIHRoZSBMaWNlbnNlIGlzIGRpc3RyaWJ1dGVkIG9uIGFuICdBUyBJUycgQkFTSVMsXG5XSVRIT1VUIFdBUlJBTlRJRVMgT1IgQ09ORElUSU9OUyBPRiBBTlkgS0lORCwgZWl0aGVyIGV4cHJlc3Mgb3IgaW1wbGllZC5cblNlZSB0aGUgTGljZW5zZSBmb3IgdGhlIHNwZWNpZmljIGxhbmd1YWdlIGdvdmVybmluZyBwZXJtaXNzaW9ucyBhbmRcbmxpbWl0YXRpb25zIHVuZGVyIHRoZSBMaWNlbnNlLlxuPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09Ki9cbm5hbWVzcGFjZSB0Zl9iYWNrZW5kIHtcblxuXG4vKj09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuXG4gIFBsZWFzZSBkbyBub3QgdXNlIFJlcXVlc3RNYW5hZ2VyIGZvciBuZXcgY29kZS5cblxuICBXZSd2ZSBnZW5lcmFsbHkgZm91bmQgY29kZSB0aGF0IHVzZXMgWE1MSHR0cFJlcXVlc3Qgd2l0aG91dCBwcm9taXNlcyBpc1xuICBlYXNpZXIgdG8gdW5kZXJzdGFuZCBhbmQgbWFpbnRhaW4uIFRoaXMgQVBJIGFsc28gbWFrZXMgaXQgZGlmZmljdWx0IHRvIHVzZVxuICB0aGUgSFRUUCBwcm90b2NvbCBpbiBhbiBpZGlvbWF0aWMgUkVTVGZ1bCBtYW5uZXIuXG5cbj09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSovXG5cblxuaW50ZXJmYWNlIFJlc29sdmVSZWplY3Qge1xuICByZXNvbHZlOiBGdW5jdGlvbjtcbiAgcmVqZWN0OiBGdW5jdGlvbjtcbn1cblxuLyoqXG4gKiBNYW5hZ2VzIG1hbnkgZmV0Y2ggcmVxdWVzdHMuIExhdW5jaGVzIHVwIHRvIG5TaW11bHRhbmVvdXNSZXF1ZXN0c1xuICogc2ltdWx0YW5lb3VzbHksIGFuZCBtYWludGFpbnMgYSBMSUZPIHF1ZXVlIG9mIHJlcXVlc3RzIHRvIHByb2Nlc3Mgd2hlblxuICogbW9yZSB1cmxzIGFyZSByZXF1ZXN0ZWQgdGhhbiBjYW4gYmUgaGFuZGxlZCBhdCBvbmNlLiBUaGUgcXVldWUgY2FuIGJlXG4gKiBjbGVhcmVkLlxuICpcbiAqIFdoZW4gYSByZXF1ZXN0IGlzIG1hZGUsIGEgUHJvbWlzZSBpcyByZXR1cm5lZCB3aGljaCByZXNvbHZlcyB3aXRoIHRoZVxuICogcGFyc2VkIEpTT04gcmVzdWx0IGZyb20gdGhlIHJlcXVlc3QuXG4gKi9cbmV4cG9ydCBjbGFzcyBSZXF1ZXN0Q2FuY2VsbGF0aW9uRXJyb3IgZXh0ZW5kcyBFcnJvciB7XG4gIHB1YmxpYyBuYW1lID0gJ1JlcXVlc3RDYW5jZWxsYXRpb25FcnJvcic7XG59XG5cbmV4cG9ydCBjbGFzcyBSZXF1ZXN0TmV0d29ya0Vycm9yIGV4dGVuZHMgRXJyb3Ige1xuICBwdWJsaWMgbmFtZTogc3RyaW5nO1xuICBwdWJsaWMgcmVxOiBYTUxIdHRwUmVxdWVzdDtcbiAgcHVibGljIHVybDogc3RyaW5nO1xuXG4gIGNvbnN0cnVjdG9yKHJlcTogWE1MSHR0cFJlcXVlc3QsIHVybCkge1xuICAgIHN1cGVyKCk7XG4gICAgdGhpcy5tZXNzYWdlID0gYFJlcXVlc3ROZXR3b3JrRXJyb3I6ICR7cmVxLnN0YXR1c30gYXQgJHt1cmx9YDtcbiAgICB0aGlzLm5hbWUgPSAnUmVxdWVzdE5ldHdvcmtFcnJvcic7XG4gICAgdGhpcy5yZXEgPSByZXE7XG4gICAgdGhpcy51cmwgPSB1cmw7XG4gIH1cbn1cblxuZXhwb3J0IGNsYXNzIFJlcXVlc3RNYW5hZ2VyIHtcbiAgcHJpdmF0ZSBfcXVldWU6IFJlc29sdmVSZWplY3RbXTtcbiAgcHJpdmF0ZSBfbWF4UmV0cmllczogbnVtYmVyO1xuICBwcml2YXRlIF9uQWN0aXZlUmVxdWVzdHM6IG51bWJlcjtcbiAgcHJpdmF0ZSBfblNpbXVsdGFuZW91c1JlcXVlc3RzOiBudW1iZXI7XG5cbiAgY29uc3RydWN0b3IoblNpbXVsdGFuZW91c1JlcXVlc3RzID0gMTAsIG1heFJldHJpZXMgPSAzKSB7XG4gICAgdGhpcy5fcXVldWUgPSBbXTtcbiAgICB0aGlzLl9uQWN0aXZlUmVxdWVzdHMgPSAwO1xuICAgIHRoaXMuX25TaW11bHRhbmVvdXNSZXF1ZXN0cyA9IG5TaW11bHRhbmVvdXNSZXF1ZXN0cztcbiAgICB0aGlzLl9tYXhSZXRyaWVzID0gbWF4UmV0cmllcztcbiAgfVxuXG4gIC8qKlxuICAgKiBHaXZlcyBhIHByb21pc2UgdGhhdCBsb2FkcyBhc3NldHMgZnJvbSBnaXZlbiB1cmwgKHJlc3BlY3RzIHF1ZXVpbmcpLiBJZlxuICAgKiBwb3N0RGF0YSBpcyBwcm92aWRlZCwgdGhpcyByZXF1ZXN0IHdpbGwgdXNlIFBPU1QsIG5vdCBHRVQuIFRoaXMgaXMgYW5cbiAgICogb2JqZWN0IG1hcHBpbmcgUE9TVCBrZXlzIHRvIHN0cmluZyB2YWx1ZXMuXG4gICAqL1xuICBwdWJsaWMgcmVxdWVzdCh1cmw6IHN0cmluZywgcG9zdERhdGE/OiB7W2tleTogc3RyaW5nXTogc3RyaW5nfSk6XG4gICAgICBQcm9taXNlPGFueT4ge1xuICAgIGNvbnN0IHByb21pc2UgPVxuICAgICAgICBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICAgICAgY29uc3QgcmVzb2x2ZXIgPSB7cmVzb2x2ZTogcmVzb2x2ZSwgcmVqZWN0OiByZWplY3R9O1xuICAgICAgICAgIHRoaXMuX3F1ZXVlLnB1c2gocmVzb2x2ZXIpO1xuICAgICAgICAgIHRoaXMubGF1bmNoUmVxdWVzdHMoKTtcbiAgICAgICAgfSlcbiAgICAgICAgICAgIC50aGVuKCgpID0+IHtcbiAgICAgICAgICAgICAgcmV0dXJuIHRoaXMucHJvbWlzZVdpdGhSZXRyaWVzKHVybCwgdGhpcy5fbWF4UmV0cmllcywgcG9zdERhdGEpO1xuICAgICAgICAgICAgfSlcbiAgICAgICAgICAgIC50aGVuKFxuICAgICAgICAgICAgICAgIChyZXNwb25zZSkgPT4ge1xuICAgICAgICAgICAgICAgICAgLy8gU3VjY2VzcyAtIExldCdzIGZyZWUgc3BhY2UgZm9yIGFub3RoZXIgYWN0aXZlXG4gICAgICAgICAgICAgICAgICAvLyByZXF1ZXN0LCBhbmQgbGF1bmNoIGl0XG4gICAgICAgICAgICAgICAgICB0aGlzLl9uQWN0aXZlUmVxdWVzdHMtLTtcbiAgICAgICAgICAgICAgICAgIHRoaXMubGF1bmNoUmVxdWVzdHMoKTtcbiAgICAgICAgICAgICAgICAgIHJldHVybiByZXNwb25zZTtcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIChyZWplY3Rpb24pID0+IHtcbiAgICAgICAgICAgICAgICAgIGlmIChyZWplY3Rpb24ubmFtZSA9PT0gJ1JlcXVlc3ROZXR3b3JrRXJyb3InKSB7XG4gICAgICAgICAgICAgICAgICAgIC8vIElmIHdlIGZhaWxlZCBkdWUgdG8gbmV0d29yayBlcnJvciwgd2Ugc2hvdWxkXG4gICAgICAgICAgICAgICAgICAgIC8vIGRlY3JlbWVudFxuICAgICAgICAgICAgICAgICAgICAvLyBfbkFjdGl2ZVJlcXVlc3RzIGJlY2F1c2UgdGhpcyByZXF1ZXN0IHdhc1xuICAgICAgICAgICAgICAgICAgICAvLyBhY3RpdmVcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fbkFjdGl2ZVJlcXVlc3RzLS07XG4gICAgICAgICAgICAgICAgICAgIHRoaXMubGF1bmNoUmVxdWVzdHMoKTtcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIHJldHVybiBQcm9taXNlLnJlamVjdChyZWplY3Rpb24pO1xuICAgICAgICAgICAgICAgIH0pO1xuICAgIHJldHVybiBwcm9taXNlO1xuICB9XG5cbiAgcHVibGljIGNsZWFyUXVldWUoKSB7XG4gICAgd2hpbGUgKHRoaXMuX3F1ZXVlLmxlbmd0aCA+IDApIHtcbiAgICAgIHRoaXMuX3F1ZXVlLnBvcCgpLnJlamVjdChcbiAgICAgICAgICBuZXcgUmVxdWVzdENhbmNlbGxhdGlvbkVycm9yKCdSZXF1ZXN0IGNhbmNlbGxlZCBieSBjbGVhclF1ZXVlJykpO1xuICAgIH1cbiAgfVxuXG4gIC8qIFJldHVybiBudW1iZXIgb2YgY3VycmVudGx5IHBlbmRpbmcgcmVxdWVzdHMgKi9cbiAgcHVibGljIGFjdGl2ZVJlcXVlc3RzKCk6IG51bWJlciB7XG4gICAgcmV0dXJuIHRoaXMuX25BY3RpdmVSZXF1ZXN0cztcbiAgfVxuXG4gIC8qIFJldHVybiB0b3RhbCBudW1iZXIgb2Ygb3V0c3RhbmRpbmcgcmVxdWVzdHMgKGluY2x1ZGVzIHF1ZXVlKSAqL1xuICBwdWJsaWMgb3V0c3RhbmRpbmdSZXF1ZXN0cygpOiBudW1iZXIge1xuICAgIHJldHVybiB0aGlzLl9uQWN0aXZlUmVxdWVzdHMgKyB0aGlzLl9xdWV1ZS5sZW5ndGg7XG4gIH1cblxuICBwcml2YXRlIGxhdW5jaFJlcXVlc3RzKCkge1xuICAgIHdoaWxlICh0aGlzLl9uQWN0aXZlUmVxdWVzdHMgPCB0aGlzLl9uU2ltdWx0YW5lb3VzUmVxdWVzdHMgJiZcbiAgICAgICAgICAgdGhpcy5fcXVldWUubGVuZ3RoID4gMCkge1xuICAgICAgdGhpcy5fbkFjdGl2ZVJlcXVlc3RzKys7XG4gICAgICB0aGlzLl9xdWV1ZS5wb3AoKS5yZXNvbHZlKCk7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIFRyeSB0byByZXF1ZXN0IGEgZ2l2ZW4gVVJMIHVzaW5nIG92ZXJ3cml0YWJsZSBfcHJvbWlzZUZyb21VcmwgbWV0aG9kLlxuICAgKiBJZiB0aGUgcmVxdWVzdCBmYWlscyBmb3IgYW55IHJlYXNvbiwgd2Ugd2lsbCByZXRyeSB1cCB0byBtYXhSZXRyaWVzXG4gICAqIHRpbWVzLiBJbiBwcmFjdGljZSwgdGhpcyB3aWxsIGhlbHAgdXMgcGFwZXIgb3ZlciB0cmFuc2llbnQgbmV0d29yayBpc3N1ZXNcbiAgICogbGlrZSAnNTAyIEJhZCBHYXRld2F5Jy5cbiAgICogQnkgZGVmYXVsdCwgQ2hyb21lIGRpc3BsYXlzIG5ldHdvcmsgZXJyb3JzIGluIGNvbnNvbGUsIHNvXG4gICAqIHRoZSB1c2VyIHdpbGwgYmUgYWJsZSB0byB0ZWxsIHdoZW4gdGhlIHJlcXVlc3RzIGFyZSBmYWlsaW5nLiBJIHRoaW5rIHRoaXNcbiAgICogaXMgYSBmZWF0dXJlLCBpZiB0aGUgcmVxdWVzdCBmYWlsdXJlcyBhbmQgcmV0cmllcyBhcmUgY2F1c2luZyBhbnlcbiAgICogcGFpbiB0byB1c2VycywgdGhleSBjYW4gc2VlIGl0IGFuZCBmaWxlIGlzc3Vlcy5cbiAgICovXG4gIHByaXZhdGUgcHJvbWlzZVdpdGhSZXRyaWVzKFxuICAgICAgdXJsOiBzdHJpbmcsIG1heFJldHJpZXM6IG51bWJlciwgcG9zdERhdGE/OiB7W2tleTogc3RyaW5nXTogc3RyaW5nfSkge1xuICAgIHZhciBzdWNjZXNzID0gKHgpID0+IHg7XG4gICAgdmFyIGZhaWx1cmUgPSAoeCkgPT4ge1xuICAgICAgaWYgKG1heFJldHJpZXMgPiAwKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnByb21pc2VXaXRoUmV0cmllcyh1cmwsIG1heFJldHJpZXMgLSAxLCBwb3N0RGF0YSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICByZXR1cm4gUHJvbWlzZS5yZWplY3QoeCk7XG4gICAgICB9XG4gICAgfTtcbiAgICByZXR1cm4gdGhpcy5fcHJvbWlzZUZyb21VcmwodXJsLCBwb3N0RGF0YSkudGhlbihzdWNjZXNzLCBmYWlsdXJlKTtcbiAgfVxuXG4gIC8qIEFjdHVhbGx5IGdldCBwcm9taXNlIGZyb20gdXJsIHVzaW5nIFhNTEh0dHBSZXF1ZXN0ICovXG4gIHByb3RlY3RlZCBfcHJvbWlzZUZyb21VcmwodXJsOiBzdHJpbmcsIHBvc3REYXRhPzoge1trZXk6IHN0cmluZ106IHN0cmluZ30pIHtcbiAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgbGV0IHJlcSA9IG5ldyBYTUxIdHRwUmVxdWVzdCgpO1xuICAgICAgcmVxLm9wZW4ocG9zdERhdGEgPyAnUE9TVCcgOiAnR0VUJywgdXJsKTtcblxuICAgICAgbGV0IGZvcm1EYXRhO1xuICAgICAgaWYgKHBvc3REYXRhKSB7XG4gICAgICAgIC8vIFdlIGFyZSB0byBtYWtlIGEgUE9TVCByZXF1ZXN0LlxuICAgICAgICBmb3JtRGF0YSA9IG5ldyBGb3JtRGF0YSgpO1xuICAgICAgICBmb3IgKGxldCBwb3N0S2V5IGluIHBvc3REYXRhKSB7XG4gICAgICAgICAgaWYgKHBvc3RLZXkpIHtcbiAgICAgICAgICAgIC8vIFRoZSBsaW50ZXIgcmVxdWlyZXMgJ2ZvciBpbicgbG9vcHMgdG8gYmUgZmlsdGVyZWQgYnkgYW4gaWZcbiAgICAgICAgICAgIC8vIGNvbmRpdGlvbi5cbiAgICAgICAgICAgIGZvcm1EYXRhLmFwcGVuZChwb3N0S2V5LCBwb3N0RGF0YVtwb3N0S2V5XSk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXEub25sb2FkID0gZnVuY3Rpb24oKSB7XG4gICAgICAgIGlmIChyZXEuc3RhdHVzID09PSAyMDApIHtcbiAgICAgICAgICByZXNvbHZlKEpTT04ucGFyc2UocmVxLnJlc3BvbnNlVGV4dCkpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHJlamVjdChuZXcgUmVxdWVzdE5ldHdvcmtFcnJvcihyZXEsIHVybCkpO1xuICAgICAgICB9XG4gICAgICB9O1xuICAgICAgcmVxLm9uZXJyb3IgPSBmdW5jdGlvbigpIHtcbiAgICAgICAgcmVqZWN0KG5ldyBSZXF1ZXN0TmV0d29ya0Vycm9yKHJlcSwgdXJsKSk7XG4gICAgICB9O1xuICAgICAgcmVxLnNlbmQoZm9ybURhdGEpO1xuICAgIH0pO1xuICB9XG59XG5cbn0gIC8vIG5hbWVzcGFjZSB0Zl9iYWNrZW5kXG4iXX0=