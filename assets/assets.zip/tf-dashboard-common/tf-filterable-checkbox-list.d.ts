declare namespace tf_dashboard_common {
    type FilterableCheckboxListItem = {
        id: string | number;
        title: string;
        subtitle?: string;
    };
}
