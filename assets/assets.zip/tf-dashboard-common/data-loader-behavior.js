/* Copyright 2015 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
var tf_dashboard_common;
(function (tf_dashboard_common) {
    /**
     * @polymerBehavior
     */
    tf_dashboard_common.DataLoaderBehavior = {
        properties: {
            /**
             * An unique identifiable string. When changes, it expunges the data
             * cache.
             */
            loadKey: {
                type: String,
                value: '',
            },
            // List of data to be loaded. A datum is passed to `getDataLoadUrl` to ge
            // URL of an API endpoint and, when request resolves, invokes
            // `loadDataCallback` with the datum and its response.
            dataToLoad: {
                type: Array,
                value: function () { return []; }
            },
            /**
             * A function that takes a datum as an input and returns a unique
             * identifiable string. Used for caching purposes.
             */
            getDataLoadName: {
                type: Function,
                value: function () { return function (datum) { return String(datum); }; },
            },
            /**
             * A function that takes as inputs:
             * 1. Implementing component of data-loader-behavior.
             * 2. datum of the request.
             * 3. The response received from the data URL.
             * This function will be called when a response from a request to that
             * data URL is successfully received.
             */
            loadDataCallback: Function,
            // A function that takes a datum and returns a string URL for fetching
            // data.
            getDataLoadUrl: Function,
            dataLoading: {
                type: Boolean,
                readOnly: true,
                reflectToAttribute: true,
                value: false,
            },
            /*
             * A set of data that has been loaded the data already. This exists to
             * prevent fetching same data again.
             * Invoking `reload` or a change in `loadKey` clears the cache.
             */
            _loadedData: {
                type: Object,
                value: function () { return new Set(); },
            },
            _canceller: {
                type: Object,
                value: function () { return new tf_backend.Canceller(); },
            },
        },
        observers: [
            '_dataToLoadChanged(isAttached, dataToLoad.*)',
        ],
        onLoadFinish: function () {
            // Override to do something useful.
        },
        reload: function () {
            this._loadedData.clear();
            this._loadData();
        },
        reset: function () {
            // https://github.com/tensorflow/tensorboard/issues/1499
            // Cannot use the observer to observe `loadKey` changes directly.
            if (this._canceller)
                this._canceller.cancelAll();
            if (this._loadedData)
                this._loadedData.clear();
            if (this.isAttached)
                this._loadData();
        },
        _dataToLoadChanged: function () {
            if (this.isAttached)
                this._loadData();
        },
        created: function () {
            this._loadData = _.debounce(this._loadDataImpl, 100, { leading: true, trailing: true });
        },
        detached: function () {
            this._canceller.cancelAll();
            this.cancelAsync(this._loadDataAsync);
        },
        _loadDataImpl: function () {
            var _this = this;
            this.cancelAsync(this._loadDataAsync);
            if (!this.isAttached)
                return;
            this._loadDataAsync = this.async(function () {
                // Read-only property have a special setter.
                _this._setDataLoading(true);
                // Before updating, cancel any network-pending updates, to
                // prevent race conditions where older data stomps newer data.
                _this._canceller.cancelAll();
                var promises = _this.dataToLoad.filter(function (datum) {
                    var name = _this.getDataLoadName(datum);
                    return !_this._loadedData.has(name);
                }).map(function (datum) {
                    var name = _this.getDataLoadName(datum);
                    var url = _this.getDataLoadUrl(datum);
                    var updateSeries = _this._canceller.cancellable(function (result) {
                        if (result.cancelled)
                            return;
                        _this._loadedData.add(name);
                        _this.loadDataCallback(_this, datum, result.value);
                    });
                    return _this.requestManager.request(url).then(updateSeries);
                });
                return Promise.all(promises).then(_this._canceller.cancellable(function (result) {
                    // Read-only property have a special setter.
                    _this._setDataLoading(false);
                    if (result.cancelled)
                        return;
                    _this.onLoadFinish();
                }));
            });
        },
    };
})(tf_dashboard_common || (tf_dashboard_common = {})); // namespace tf_line_chart_data_loader
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGF0YS1sb2FkZXItYmVoYXZpb3IuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJkYXRhLWxvYWRlci1iZWhhdmlvci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7Ozs7Ozs7OztnRkFhZ0Y7QUFDaEYsSUFBVSxtQkFBbUIsQ0FnSjVCO0FBaEpELFdBQVUsbUJBQW1CO0lBRTdCOztPQUVHO0lBQ1Usc0NBQWtCLEdBQUc7UUFDaEMsVUFBVSxFQUFFO1lBQ1Y7OztlQUdHO1lBQ0gsT0FBTyxFQUFFO2dCQUNQLElBQUksRUFBRSxNQUFNO2dCQUNaLEtBQUssRUFBRSxFQUFFO2FBQ1Y7WUFFRCx5RUFBeUU7WUFDekUsNkRBQTZEO1lBQzdELHNEQUFzRDtZQUN0RCxVQUFVLEVBQUU7Z0JBQ1YsSUFBSSxFQUFFLEtBQUs7Z0JBQ1gsS0FBSyxFQUFFLGNBQU0sT0FBQSxFQUFFLEVBQUYsQ0FBRTthQUNoQjtZQUVEOzs7ZUFHRztZQUNILGVBQWUsRUFBRTtnQkFDZixJQUFJLEVBQUUsUUFBUTtnQkFDZCxLQUFLLEVBQUUsY0FBTSxPQUFBLFVBQUMsS0FBSyxJQUFLLE9BQUEsTUFBTSxDQUFDLEtBQUssQ0FBQyxFQUFiLENBQWEsRUFBeEIsQ0FBd0I7YUFDdEM7WUFFRDs7Ozs7OztlQU9HO1lBQ0gsZ0JBQWdCLEVBQUUsUUFBUTtZQUUxQixzRUFBc0U7WUFDdEUsUUFBUTtZQUNSLGNBQWMsRUFBRSxRQUFRO1lBRXhCLFdBQVcsRUFBRTtnQkFDWCxJQUFJLEVBQUUsT0FBTztnQkFDYixRQUFRLEVBQUUsSUFBSTtnQkFDZCxrQkFBa0IsRUFBRSxJQUFJO2dCQUN4QixLQUFLLEVBQUUsS0FBSzthQUNiO1lBRUQ7Ozs7ZUFJRztZQUNILFdBQVcsRUFBRTtnQkFDWCxJQUFJLEVBQUUsTUFBTTtnQkFDWixLQUFLLEVBQUUsY0FBTSxPQUFBLElBQUksR0FBRyxFQUFFLEVBQVQsQ0FBUzthQUN2QjtZQUVELFVBQVUsRUFBRTtnQkFDVixJQUFJLEVBQUUsTUFBTTtnQkFDWixLQUFLLEVBQUUsY0FBTSxPQUFBLElBQUksVUFBVSxDQUFDLFNBQVMsRUFBRSxFQUExQixDQUEwQjthQUN4QztTQUVGO1FBRUQsU0FBUyxFQUFFO1lBQ1QsOENBQThDO1NBQy9DO1FBRUQsWUFBWTtZQUNWLG1DQUFtQztRQUNyQyxDQUFDO1FBRUQsTUFBTTtZQUNKLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDekIsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO1FBQ25CLENBQUM7UUFFRCxLQUFLO1lBQ0gsd0RBQXdEO1lBQ3hELGlFQUFpRTtZQUNqRSxJQUFJLElBQUksQ0FBQyxVQUFVO2dCQUFFLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxFQUFFLENBQUM7WUFDakQsSUFBSSxJQUFJLENBQUMsV0FBVztnQkFBRSxJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssRUFBRSxDQUFDO1lBQy9DLElBQUksSUFBSSxDQUFDLFVBQVU7Z0JBQUUsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO1FBQ3hDLENBQUM7UUFFRCxrQkFBa0I7WUFDaEIsSUFBSSxJQUFJLENBQUMsVUFBVTtnQkFBRSxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7UUFDeEMsQ0FBQztRQUVELE9BQU87WUFDTCxJQUFJLENBQUMsU0FBUyxHQUFHLENBQUMsQ0FBQyxRQUFRLENBQ3ZCLElBQUksQ0FBQyxhQUFhLEVBQ2xCLEdBQUcsRUFDSCxFQUFDLE9BQU8sRUFBRSxJQUFJLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBQyxDQUFDLENBQUM7UUFDdkMsQ0FBQztRQUVELFFBQVE7WUFDTixJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsRUFBRSxDQUFDO1lBQzVCLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDO1FBQ3hDLENBQUM7UUFFRCxhQUFhO1lBQWIsaUJBZ0NDO1lBL0JDLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDO1lBRXRDLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVTtnQkFBRSxPQUFPO1lBQzdCLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQztnQkFDL0IsNENBQTRDO2dCQUM1QyxLQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUUzQiwwREFBMEQ7Z0JBQzFELDhEQUE4RDtnQkFDOUQsS0FBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLEVBQUUsQ0FBQztnQkFDNUIsSUFBTSxRQUFRLEdBQUcsS0FBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsVUFBQSxLQUFLO29CQUMzQyxJQUFNLElBQUksR0FBRyxLQUFJLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN6QyxPQUFPLENBQUMsS0FBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUM7Z0JBQ3JDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxVQUFBLEtBQUs7b0JBQ1YsSUFBTSxJQUFJLEdBQUcsS0FBSSxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDekMsSUFBTSxHQUFHLEdBQUcsS0FBSSxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkMsSUFBTSxZQUFZLEdBQUcsS0FBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLENBQUMsVUFBQSxNQUFNO3dCQUNyRCxJQUFJLE1BQU0sQ0FBQyxTQUFTOzRCQUFFLE9BQU87d0JBQzdCLEtBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDO3dCQUMzQixLQUFJLENBQUMsZ0JBQWdCLENBQUMsS0FBSSxFQUFFLEtBQUssRUFBRSxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ25ELENBQUMsQ0FBQyxDQUFDO29CQUNILE9BQU8sS0FBSSxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDO2dCQUM3RCxDQUFDLENBQUMsQ0FBQztnQkFFSCxPQUFPLE9BQU8sQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxDQUFDLFVBQUEsTUFBTTtvQkFDbEUsNENBQTRDO29CQUM1QyxLQUFJLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUM1QixJQUFJLE1BQU0sQ0FBQyxTQUFTO3dCQUFFLE9BQU87b0JBQzdCLEtBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztnQkFDdEIsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUNOLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQztLQUVGLENBQUM7QUFFRixDQUFDLEVBaEpTLG1CQUFtQixLQUFuQixtQkFBbUIsUUFnSjVCLENBQUUsc0NBQXNDIiwic291cmNlc0NvbnRlbnQiOlsiLyogQ29weXJpZ2h0IDIwMTUgVGhlIFRlbnNvckZsb3cgQXV0aG9ycy4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cblxuTGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlLCBWZXJzaW9uIDIuMCAodGhlIFwiTGljZW5zZVwiKTtcbnlvdSBtYXkgbm90IHVzZSB0aGlzIGZpbGUgZXhjZXB0IGluIGNvbXBsaWFuY2Ugd2l0aCB0aGUgTGljZW5zZS5cbllvdSBtYXkgb2J0YWluIGEgY29weSBvZiB0aGUgTGljZW5zZSBhdFxuXG4gICAgaHR0cDovL3d3dy5hcGFjaGUub3JnL2xpY2Vuc2VzL0xJQ0VOU0UtMi4wXG5cblVubGVzcyByZXF1aXJlZCBieSBhcHBsaWNhYmxlIGxhdyBvciBhZ3JlZWQgdG8gaW4gd3JpdGluZywgc29mdHdhcmVcbmRpc3RyaWJ1dGVkIHVuZGVyIHRoZSBMaWNlbnNlIGlzIGRpc3RyaWJ1dGVkIG9uIGFuIFwiQVMgSVNcIiBCQVNJUyxcbldJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWSBLSU5ELCBlaXRoZXIgZXhwcmVzcyBvciBpbXBsaWVkLlxuU2VlIHRoZSBMaWNlbnNlIGZvciB0aGUgc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nIHBlcm1pc3Npb25zIGFuZFxubGltaXRhdGlvbnMgdW5kZXIgdGhlIExpY2Vuc2UuXG49PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0qL1xubmFtZXNwYWNlIHRmX2Rhc2hib2FyZF9jb21tb24ge1xuXG4vKipcbiAqIEBwb2x5bWVyQmVoYXZpb3JcbiAqL1xuZXhwb3J0IGNvbnN0IERhdGFMb2FkZXJCZWhhdmlvciA9IHtcbiAgcHJvcGVydGllczoge1xuICAgIC8qKlxuICAgICAqIEFuIHVuaXF1ZSBpZGVudGlmaWFibGUgc3RyaW5nLiBXaGVuIGNoYW5nZXMsIGl0IGV4cHVuZ2VzIHRoZSBkYXRhXG4gICAgICogY2FjaGUuXG4gICAgICovXG4gICAgbG9hZEtleToge1xuICAgICAgdHlwZTogU3RyaW5nLFxuICAgICAgdmFsdWU6ICcnLFxuICAgIH0sXG5cbiAgICAvLyBMaXN0IG9mIGRhdGEgdG8gYmUgbG9hZGVkLiBBIGRhdHVtIGlzIHBhc3NlZCB0byBgZ2V0RGF0YUxvYWRVcmxgIHRvIGdlXG4gICAgLy8gVVJMIG9mIGFuIEFQSSBlbmRwb2ludCBhbmQsIHdoZW4gcmVxdWVzdCByZXNvbHZlcywgaW52b2tlc1xuICAgIC8vIGBsb2FkRGF0YUNhbGxiYWNrYCB3aXRoIHRoZSBkYXR1bSBhbmQgaXRzIHJlc3BvbnNlLlxuICAgIGRhdGFUb0xvYWQ6IHtcbiAgICAgIHR5cGU6IEFycmF5LFxuICAgICAgdmFsdWU6ICgpID0+IFtdXG4gICAgfSxcblxuICAgIC8qKlxuICAgICAqIEEgZnVuY3Rpb24gdGhhdCB0YWtlcyBhIGRhdHVtIGFzIGFuIGlucHV0IGFuZCByZXR1cm5zIGEgdW5pcXVlXG4gICAgICogaWRlbnRpZmlhYmxlIHN0cmluZy4gVXNlZCBmb3IgY2FjaGluZyBwdXJwb3Nlcy5cbiAgICAgKi9cbiAgICBnZXREYXRhTG9hZE5hbWU6IHtcbiAgICAgIHR5cGU6IEZ1bmN0aW9uLFxuICAgICAgdmFsdWU6ICgpID0+IChkYXR1bSkgPT4gU3RyaW5nKGRhdHVtKSxcbiAgICB9LFxuXG4gICAgLyoqXG4gICAgICogQSBmdW5jdGlvbiB0aGF0IHRha2VzIGFzIGlucHV0czpcbiAgICAgKiAxLiBJbXBsZW1lbnRpbmcgY29tcG9uZW50IG9mIGRhdGEtbG9hZGVyLWJlaGF2aW9yLlxuICAgICAqIDIuIGRhdHVtIG9mIHRoZSByZXF1ZXN0LlxuICAgICAqIDMuIFRoZSByZXNwb25zZSByZWNlaXZlZCBmcm9tIHRoZSBkYXRhIFVSTC5cbiAgICAgKiBUaGlzIGZ1bmN0aW9uIHdpbGwgYmUgY2FsbGVkIHdoZW4gYSByZXNwb25zZSBmcm9tIGEgcmVxdWVzdCB0byB0aGF0XG4gICAgICogZGF0YSBVUkwgaXMgc3VjY2Vzc2Z1bGx5IHJlY2VpdmVkLlxuICAgICAqL1xuICAgIGxvYWREYXRhQ2FsbGJhY2s6IEZ1bmN0aW9uLFxuXG4gICAgLy8gQSBmdW5jdGlvbiB0aGF0IHRha2VzIGEgZGF0dW0gYW5kIHJldHVybnMgYSBzdHJpbmcgVVJMIGZvciBmZXRjaGluZ1xuICAgIC8vIGRhdGEuXG4gICAgZ2V0RGF0YUxvYWRVcmw6IEZ1bmN0aW9uLFxuXG4gICAgZGF0YUxvYWRpbmc6IHtcbiAgICAgIHR5cGU6IEJvb2xlYW4sXG4gICAgICByZWFkT25seTogdHJ1ZSxcbiAgICAgIHJlZmxlY3RUb0F0dHJpYnV0ZTogdHJ1ZSxcbiAgICAgIHZhbHVlOiBmYWxzZSxcbiAgICB9LFxuXG4gICAgLypcbiAgICAgKiBBIHNldCBvZiBkYXRhIHRoYXQgaGFzIGJlZW4gbG9hZGVkIHRoZSBkYXRhIGFscmVhZHkuIFRoaXMgZXhpc3RzIHRvXG4gICAgICogcHJldmVudCBmZXRjaGluZyBzYW1lIGRhdGEgYWdhaW4uXG4gICAgICogSW52b2tpbmcgYHJlbG9hZGAgb3IgYSBjaGFuZ2UgaW4gYGxvYWRLZXlgIGNsZWFycyB0aGUgY2FjaGUuXG4gICAgICovXG4gICAgX2xvYWRlZERhdGE6IHtcbiAgICAgIHR5cGU6IE9iamVjdCxcbiAgICAgIHZhbHVlOiAoKSA9PiBuZXcgU2V0KCksXG4gICAgfSxcblxuICAgIF9jYW5jZWxsZXI6IHtcbiAgICAgIHR5cGU6IE9iamVjdCxcbiAgICAgIHZhbHVlOiAoKSA9PiBuZXcgdGZfYmFja2VuZC5DYW5jZWxsZXIoKSxcbiAgICB9LFxuXG4gIH0sXG5cbiAgb2JzZXJ2ZXJzOiBbXG4gICAgJ19kYXRhVG9Mb2FkQ2hhbmdlZChpc0F0dGFjaGVkLCBkYXRhVG9Mb2FkLiopJyxcbiAgXSxcblxuICBvbkxvYWRGaW5pc2goKSB7XG4gICAgLy8gT3ZlcnJpZGUgdG8gZG8gc29tZXRoaW5nIHVzZWZ1bC5cbiAgfSxcblxuICByZWxvYWQoKSB7XG4gICAgdGhpcy5fbG9hZGVkRGF0YS5jbGVhcigpO1xuICAgIHRoaXMuX2xvYWREYXRhKCk7XG4gIH0sXG5cbiAgcmVzZXQoKSB7XG4gICAgLy8gaHR0cHM6Ly9naXRodWIuY29tL3RlbnNvcmZsb3cvdGVuc29yYm9hcmQvaXNzdWVzLzE0OTlcbiAgICAvLyBDYW5ub3QgdXNlIHRoZSBvYnNlcnZlciB0byBvYnNlcnZlIGBsb2FkS2V5YCBjaGFuZ2VzIGRpcmVjdGx5LlxuICAgIGlmICh0aGlzLl9jYW5jZWxsZXIpIHRoaXMuX2NhbmNlbGxlci5jYW5jZWxBbGwoKTtcbiAgICBpZiAodGhpcy5fbG9hZGVkRGF0YSkgdGhpcy5fbG9hZGVkRGF0YS5jbGVhcigpO1xuICAgIGlmICh0aGlzLmlzQXR0YWNoZWQpIHRoaXMuX2xvYWREYXRhKCk7XG4gIH0sXG5cbiAgX2RhdGFUb0xvYWRDaGFuZ2VkKCkge1xuICAgIGlmICh0aGlzLmlzQXR0YWNoZWQpIHRoaXMuX2xvYWREYXRhKCk7XG4gIH0sXG5cbiAgY3JlYXRlZCgpIHtcbiAgICB0aGlzLl9sb2FkRGF0YSA9IF8uZGVib3VuY2UoXG4gICAgICAgIHRoaXMuX2xvYWREYXRhSW1wbCxcbiAgICAgICAgMTAwLFxuICAgICAgICB7bGVhZGluZzogdHJ1ZSwgdHJhaWxpbmc6IHRydWV9KTtcbiAgfSxcblxuICBkZXRhY2hlZCgpIHtcbiAgICB0aGlzLl9jYW5jZWxsZXIuY2FuY2VsQWxsKCk7XG4gICAgdGhpcy5jYW5jZWxBc3luYyh0aGlzLl9sb2FkRGF0YUFzeW5jKTtcbiAgfSxcblxuICBfbG9hZERhdGFJbXBsKCkge1xuICAgIHRoaXMuY2FuY2VsQXN5bmModGhpcy5fbG9hZERhdGFBc3luYyk7XG5cbiAgICBpZiAoIXRoaXMuaXNBdHRhY2hlZCkgcmV0dXJuO1xuICAgIHRoaXMuX2xvYWREYXRhQXN5bmMgPSB0aGlzLmFzeW5jKCgpID0+IHtcbiAgICAgIC8vIFJlYWQtb25seSBwcm9wZXJ0eSBoYXZlIGEgc3BlY2lhbCBzZXR0ZXIuXG4gICAgICB0aGlzLl9zZXREYXRhTG9hZGluZyh0cnVlKTtcblxuICAgICAgLy8gQmVmb3JlIHVwZGF0aW5nLCBjYW5jZWwgYW55IG5ldHdvcmstcGVuZGluZyB1cGRhdGVzLCB0b1xuICAgICAgLy8gcHJldmVudCByYWNlIGNvbmRpdGlvbnMgd2hlcmUgb2xkZXIgZGF0YSBzdG9tcHMgbmV3ZXIgZGF0YS5cbiAgICAgIHRoaXMuX2NhbmNlbGxlci5jYW5jZWxBbGwoKTtcbiAgICAgIGNvbnN0IHByb21pc2VzID0gdGhpcy5kYXRhVG9Mb2FkLmZpbHRlcihkYXR1bSA9PiB7XG4gICAgICAgIGNvbnN0IG5hbWUgPSB0aGlzLmdldERhdGFMb2FkTmFtZShkYXR1bSk7XG4gICAgICAgIHJldHVybiAhdGhpcy5fbG9hZGVkRGF0YS5oYXMobmFtZSk7XG4gICAgICB9KS5tYXAoZGF0dW0gPT4ge1xuICAgICAgICBjb25zdCBuYW1lID0gdGhpcy5nZXREYXRhTG9hZE5hbWUoZGF0dW0pO1xuICAgICAgICBjb25zdCB1cmwgPSB0aGlzLmdldERhdGFMb2FkVXJsKGRhdHVtKTtcbiAgICAgICAgY29uc3QgdXBkYXRlU2VyaWVzID0gdGhpcy5fY2FuY2VsbGVyLmNhbmNlbGxhYmxlKHJlc3VsdCA9PiB7XG4gICAgICAgICAgaWYgKHJlc3VsdC5jYW5jZWxsZWQpIHJldHVybjtcbiAgICAgICAgICB0aGlzLl9sb2FkZWREYXRhLmFkZChuYW1lKTtcbiAgICAgICAgICB0aGlzLmxvYWREYXRhQ2FsbGJhY2sodGhpcywgZGF0dW0sIHJlc3VsdC52YWx1ZSk7XG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gdGhpcy5yZXF1ZXN0TWFuYWdlci5yZXF1ZXN0KHVybCkudGhlbih1cGRhdGVTZXJpZXMpO1xuICAgICAgfSk7XG5cbiAgICAgIHJldHVybiBQcm9taXNlLmFsbChwcm9taXNlcykudGhlbih0aGlzLl9jYW5jZWxsZXIuY2FuY2VsbGFibGUocmVzdWx0ID0+IHtcbiAgICAgICAgLy8gUmVhZC1vbmx5IHByb3BlcnR5IGhhdmUgYSBzcGVjaWFsIHNldHRlci5cbiAgICAgICAgdGhpcy5fc2V0RGF0YUxvYWRpbmcoZmFsc2UpO1xuICAgICAgICBpZiAocmVzdWx0LmNhbmNlbGxlZCkgcmV0dXJuO1xuICAgICAgICB0aGlzLm9uTG9hZEZpbmlzaCgpO1xuICAgICAgfSkpO1xuICAgIH0pO1xuICB9LFxuXG59O1xuXG59ICAvLyBuYW1lc3BhY2UgdGZfbGluZV9jaGFydF9kYXRhX2xvYWRlclxuIl19