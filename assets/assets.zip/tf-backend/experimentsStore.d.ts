declare namespace tf_backend {
    class ExperimentsStore extends BaseStore {
        private _experiments;
        load(): Promise<void>;
        /**
         * Get the current list of experiments. If no data is available, this will be
         * an empty array (i.e., there is no distinction between "no experiment" and
         * "no experiment yet").
         */
        getExperiments(): Experiment[];
    }
    const experimentsStore: ExperimentsStore;
}
