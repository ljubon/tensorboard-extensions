/* Copyright 2015 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
var vz_distribution_chart;
(function (vz_distribution_chart) {
    var DistributionChart = /** @class */ (function () {
        function DistributionChart(xType, colorScale) {
            this.run2datasets = {};
            this.colorScale = colorScale;
            this.buildChart(xType);
        }
        DistributionChart.prototype.getDataset = function (run) {
            if (this.run2datasets[run] === undefined) {
                this.run2datasets[run] = new Plottable.Dataset([], { run: run });
            }
            return this.run2datasets[run];
        };
        DistributionChart.prototype.buildChart = function (xType) {
            if (this.outer) {
                this.outer.destroy();
            }
            var xComponents = vz_chart_helpers.getXComponents(xType);
            this.xAccessor = xComponents.accessor;
            this.xScale = xComponents.scale;
            this.xAxis = xComponents.axis;
            this.xAxis.margin(0).tickLabelPadding(3);
            this.yScale = new Plottable.Scales.Linear();
            this.yAxis = new Plottable.Axes.Numeric(this.yScale, 'left');
            var yFormatter = vz_chart_helpers.multiscaleFormatter(vz_chart_helpers.Y_AXIS_FORMATTER_PRECISION);
            this.yAxis.margin(0).tickLabelPadding(5).formatter(yFormatter);
            this.yAxis.usesTextWidthApproximation(true);
            var center = this.buildPlot(this.xAccessor, this.xScale, this.yScale);
            this.gridlines =
                new Plottable.Components.Gridlines(this.xScale, this.yScale);
            this.center = new Plottable.Components.Group([this.gridlines, center]);
            this.outer = new Plottable.Components.Table([[this.yAxis, this.center], [null, this.xAxis]]);
        };
        DistributionChart.prototype.buildPlot = function (xAccessor, xScale, yScale) {
            var _this = this;
            var percents = [0, 228, 1587, 3085, 5000, 6915, 8413, 9772, 10000];
            var opacities = _.range(percents.length - 1)
                .map(function (i) { return (percents[i + 1] - percents[i]) / 2500; });
            var accessors = percents.map(function (p, i) { return function (datum) { return datum[i][1]; }; });
            var median = 4;
            var medianAccessor = accessors[median];
            var plots = _.range(accessors.length - 1).map(function (i) {
                var p = new Plottable.Plots.Area();
                p.x(xAccessor, xScale);
                var y0 = i > median ? accessors[i] : accessors[i + 1];
                var y = i > median ? accessors[i + 1] : accessors[i];
                p.y(y, yScale);
                p.y0(y0);
                p.attr('fill', function (d, i, dataset) {
                    return _this.colorScale.scale(dataset.metadata().run);
                });
                p.attr('stroke', function (d, i, dataset) {
                    return _this.colorScale.scale(dataset.metadata().run);
                });
                p.attr('stroke-weight', function (d, i, m) { return '0.5px'; });
                p.attr('stroke-opacity', function () { return opacities[i]; });
                p.attr('fill-opacity', function () { return opacities[i]; });
                return p;
            });
            var medianPlot = new Plottable.Plots.Line();
            medianPlot.x(xAccessor, xScale);
            medianPlot.y(medianAccessor, yScale);
            medianPlot.attr('stroke', function (d, i, m) { return _this.colorScale.scale(m.run); });
            this.plots = plots;
            return new Plottable.Components.Group(plots);
        };
        DistributionChart.prototype.setVisibleSeries = function (runs) {
            var _this = this;
            this.runs = runs;
            var datasets = runs.map(function (r) { return _this.getDataset(r); });
            this.plots.forEach(function (p) { return p.datasets(datasets); });
        };
        /**
         * Set the data of a series on the chart.
         */
        DistributionChart.prototype.setSeriesData = function (name, data) {
            this.getDataset(name).data(data);
        };
        DistributionChart.prototype.renderTo = function (targetSVG) {
            this.targetSVG = targetSVG;
            this.outer.renderTo(targetSVG);
        };
        DistributionChart.prototype.redraw = function () {
            this.outer.redraw();
        };
        DistributionChart.prototype.destroy = function () {
            this.outer.destroy();
        };
        return DistributionChart;
    }());
    vz_distribution_chart.DistributionChart = DistributionChart;
    Polymer({
        is: 'vz-distribution-chart',
        properties: {
            /**
             * Scale that maps series names to colors. The default colors are from
             * d3.d3.schemeCategory10. Use this property to replace the default
             * line colors with colors of your own choice.
             * @type {Plottable.Scales.Color}
             * @required
             */
            colorScale: {
                type: Object,
                value: function () {
                    return new Plottable.Scales.Color().range(d3.schemeCategory10);
                }
            },
            /**
             * The way to display the X values. Allows:
             * - "step" - Linear scale using the  "step" property of the datum.
             * - "wall_time" - Temporal scale using the "wall_time" property of the
             * datum.
             * - "relative" - Temporal scale using the "relative" property of the
             * datum if it is present or calculating from "wall_time" if it isn't.
             */
            xType: { type: String, value: 'step' },
            _attached: Boolean,
            _chart: Object,
            _visibleSeriesCache: {
                type: Array,
                value: function () {
                    return [];
                }
            },
            _seriesDataCache: {
                type: Object,
                value: function () {
                    return {};
                }
            },
            _makeChartAsyncCallbackId: { type: Number, value: null }
        },
        observers: [
            '_makeChart(xType, colorScale, _attached)',
            '_reloadFromCache(_chart)',
        ],
        setVisibleSeries: function (names) {
            this._visibleSeriesCache = names;
            if (this._chart) {
                this._chart.setVisibleSeries(names);
                this.redraw();
            }
        },
        setSeriesData: function (name, data) {
            this._seriesDataCache[name] = data;
            if (this._chart) {
                this._chart.setSeriesData(name, data);
            }
        },
        redraw: function () {
            this._chart.redraw();
        },
        ready: function () {
            this.scopeSubtree(this.$.chartdiv, true);
        },
        _makeChart: function (xType, colorScale, _attached) {
            if (this._makeChartAsyncCallbackId === null) {
                this.cancelAsync(this._makeChartAsyncCallbackId);
            }
            this._makeChartAsyncCallbackId = this.async(function () {
                this._makeChartAsyncCallbackId = null;
                if (!_attached)
                    return;
                if (this._chart)
                    this._chart.destroy();
                var chart = new DistributionChart(xType, colorScale);
                var svg = d3.select(this.$.chartdiv);
                chart.renderTo(svg);
                this._chart = chart;
            }, 350);
        },
        _reloadFromCache: function () {
            if (this._chart) {
                this._chart.setVisibleSeries(this._visibleSeriesCache);
                this._visibleSeriesCache.forEach(function (name) {
                    this._chart.setSeriesData(name, this._seriesDataCache[name] || []);
                }.bind(this));
            }
        },
        attached: function () {
            this._attached = true;
        },
        detached: function () {
            this._attached = false;
        }
    });
})(vz_distribution_chart || (vz_distribution_chart = {})); // namespace vz_distribution_chart
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidnotZGlzdHJpYnV0aW9uLWNoYXJ0LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsidnotZGlzdHJpYnV0aW9uLWNoYXJ0LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7Ozs7Ozs7Ozs7O2dGQWFnRjtBQUNoRixJQUFVLHFCQUFxQixDQStOOUI7QUEvTkQsV0FBVSxxQkFBcUI7SUFFL0I7UUFtQkUsMkJBQVksS0FBYSxFQUFFLFVBQWtDO1lBQzNELElBQUksQ0FBQyxZQUFZLEdBQUcsRUFBRSxDQUFDO1lBQ3ZCLElBQUksQ0FBQyxVQUFVLEdBQUcsVUFBVSxDQUFDO1lBQzdCLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDekIsQ0FBQztRQUVTLHNDQUFVLEdBQXBCLFVBQXFCLEdBQVc7WUFDOUIsSUFBSSxJQUFJLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FBQyxLQUFLLFNBQVMsRUFBRTtnQkFDeEMsSUFBSSxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsR0FBRyxJQUFJLFNBQVMsQ0FBQyxPQUFPLENBQUMsRUFBRSxFQUFFLEVBQUMsR0FBRyxFQUFFLEdBQUcsRUFBQyxDQUFDLENBQUM7YUFDaEU7WUFDRCxPQUFPLElBQUksQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDaEMsQ0FBQztRQUVTLHNDQUFVLEdBQXBCLFVBQXFCLEtBQWE7WUFDaEMsSUFBSSxJQUFJLENBQUMsS0FBSyxFQUFFO2dCQUNkLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxFQUFFLENBQUM7YUFDdEI7WUFDRCxJQUFJLFdBQVcsR0FBRyxnQkFBZ0IsQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDekQsSUFBSSxDQUFDLFNBQVMsR0FBRyxXQUFXLENBQUMsUUFBUSxDQUFDO1lBQ3RDLElBQUksQ0FBQyxNQUFNLEdBQUcsV0FBVyxDQUFDLEtBQUssQ0FBQztZQUNoQyxJQUFJLENBQUMsS0FBSyxHQUFHLFdBQVcsQ0FBQyxJQUFJLENBQUM7WUFDOUIsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDekMsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLFNBQVMsQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFLENBQUM7WUFDNUMsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLFNBQVMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsTUFBTSxDQUFDLENBQUM7WUFDN0QsSUFBSSxVQUFVLEdBQUcsZ0JBQWdCLENBQUMsbUJBQW1CLENBQ2pELGdCQUFnQixDQUFDLDBCQUEwQixDQUFDLENBQUM7WUFDakQsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBQy9ELElBQUksQ0FBQyxLQUFLLENBQUMsMEJBQTBCLENBQUMsSUFBSSxDQUFDLENBQUM7WUFFNUMsSUFBSSxNQUFNLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBRXRFLElBQUksQ0FBQyxTQUFTO2dCQUNWLElBQUksU0FBUyxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7WUFFakUsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLFNBQVMsQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDO1lBQ3ZFLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxTQUFTLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FDdkMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDdkQsQ0FBQztRQUVTLHFDQUFTLEdBQW5CLFVBQW9CLFNBQVMsRUFBRSxNQUFNLEVBQUUsTUFBTTtZQUE3QyxpQkFzQ0M7WUFyQ0MsSUFBSSxRQUFRLEdBQUcsQ0FBQyxDQUFDLEVBQUUsR0FBRyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLEtBQUssQ0FBQyxDQUFDO1lBQ25FLElBQUksU0FBUyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7aUJBQ3ZCLEdBQUcsQ0FBQyxVQUFDLENBQUMsSUFBSyxPQUFBLENBQUMsUUFBUSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxJQUFJLEVBQXRDLENBQXNDLENBQUMsQ0FBQztZQUN4RSxJQUFJLFNBQVMsR0FBRyxRQUFRLENBQUMsR0FBRyxDQUFDLFVBQUMsQ0FBQyxFQUFFLENBQUMsSUFBSyxPQUFBLFVBQUMsS0FBSyxJQUFLLE9BQUEsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFYLENBQVcsRUFBdEIsQ0FBc0IsQ0FBQyxDQUFDO1lBQy9ELElBQUksTUFBTSxHQUFHLENBQUMsQ0FBQztZQUNmLElBQUksY0FBYyxHQUFHLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUV2QyxJQUFJLEtBQUssR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLFVBQUMsQ0FBQztnQkFDOUMsSUFBSSxDQUFDLEdBQUcsSUFBSSxTQUFTLENBQUMsS0FBSyxDQUFDLElBQUksRUFBZSxDQUFDO2dCQUNoRCxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsRUFBRSxNQUFNLENBQUMsQ0FBQztnQkFFdkIsSUFBSSxFQUFFLEdBQUcsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO2dCQUN0RCxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ3JELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDO2dCQUNmLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUM7Z0JBQ1QsQ0FBQyxDQUFDLElBQUksQ0FDRixNQUFNLEVBQ04sVUFBQyxDQUFNLEVBQUUsQ0FBUyxFQUFFLE9BQTBCO29CQUMxQyxPQUFBLEtBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxRQUFRLEVBQUUsQ0FBQyxHQUFHLENBQUM7Z0JBQTdDLENBQTZDLENBQUMsQ0FBQztnQkFDdkQsQ0FBQyxDQUFDLElBQUksQ0FDRixRQUFRLEVBQ1IsVUFBQyxDQUFNLEVBQUUsQ0FBUyxFQUFFLE9BQTBCO29CQUMxQyxPQUFBLEtBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxRQUFRLEVBQUUsQ0FBQyxHQUFHLENBQUM7Z0JBQTdDLENBQTZDLENBQUMsQ0FBQztnQkFDdkQsQ0FBQyxDQUFDLElBQUksQ0FBQyxlQUFlLEVBQUUsVUFBQyxDQUFNLEVBQUUsQ0FBUyxFQUFFLENBQU0sSUFBSyxPQUFBLE9BQU8sRUFBUCxDQUFPLENBQUMsQ0FBQztnQkFDaEUsQ0FBQyxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxjQUFNLE9BQUEsU0FBUyxDQUFDLENBQUMsQ0FBQyxFQUFaLENBQVksQ0FBQyxDQUFDO2dCQUM3QyxDQUFDLENBQUMsSUFBSSxDQUFDLGNBQWMsRUFBRSxjQUFNLE9BQUEsU0FBUyxDQUFDLENBQUMsQ0FBQyxFQUFaLENBQVksQ0FBQyxDQUFDO2dCQUMzQyxPQUFPLENBQUMsQ0FBQztZQUNYLENBQUMsQ0FBQyxDQUFDO1lBRUgsSUFBSSxVQUFVLEdBQUcsSUFBSSxTQUFTLENBQUMsS0FBSyxDQUFDLElBQUksRUFBZSxDQUFDO1lBQ3pELFVBQVUsQ0FBQyxDQUFDLENBQUMsU0FBUyxFQUFFLE1BQU0sQ0FBQyxDQUFDO1lBQ2hDLFVBQVUsQ0FBQyxDQUFDLENBQUMsY0FBYyxFQUFFLE1BQU0sQ0FBQyxDQUFDO1lBQ3JDLFVBQVUsQ0FBQyxJQUFJLENBQ1gsUUFBUSxFQUFFLFVBQUMsQ0FBTSxFQUFFLENBQVMsRUFBRSxDQUFNLElBQUssT0FBQSxLQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQTVCLENBQTRCLENBQUMsQ0FBQztZQUUzRSxJQUFJLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQztZQUNuQixPQUFPLElBQUksU0FBUyxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDL0MsQ0FBQztRQUVNLDRDQUFnQixHQUF2QixVQUF3QixJQUFjO1lBQXRDLGlCQUlDO1lBSEMsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUM7WUFDakIsSUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxVQUFDLENBQUMsSUFBSyxPQUFBLEtBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLEVBQWxCLENBQWtCLENBQUMsQ0FBQztZQUNuRCxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxVQUFDLENBQUMsSUFBSyxPQUFBLENBQUMsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLEVBQXBCLENBQW9CLENBQUMsQ0FBQztRQUNsRCxDQUFDO1FBRUQ7O1dBRUc7UUFDSSx5Q0FBYSxHQUFwQixVQUFxQixJQUFZLEVBQUUsSUFBUztZQUMxQyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUNuQyxDQUFDO1FBRU0sb0NBQVEsR0FBZixVQUFnQixTQUEyQztZQUN6RCxJQUFJLENBQUMsU0FBUyxHQUFHLFNBQVMsQ0FBQztZQUMzQixJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUNqQyxDQUFDO1FBRU0sa0NBQU0sR0FBYjtZQUNFLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDdEIsQ0FBQztRQUVTLG1DQUFPLEdBQWpCO1lBQ0UsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLEVBQUUsQ0FBQztRQUN2QixDQUFDO1FBQ0gsd0JBQUM7SUFBRCxDQUFDLEFBM0hELElBMkhDO0lBM0hZLHVDQUFpQixvQkEySDdCLENBQUE7SUFHRCxPQUFPLENBQUM7UUFDTixFQUFFLEVBQUUsdUJBQXVCO1FBQzNCLFVBQVUsRUFBRTtZQUNWOzs7Ozs7ZUFNRztZQUNILFVBQVUsRUFBRTtnQkFDVixJQUFJLEVBQUUsTUFBTTtnQkFDWixLQUFLLEVBQUU7b0JBQ0wsT0FBTyxJQUFJLFNBQVMsQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO2dCQUNqRSxDQUFDO2FBQ0Y7WUFDRDs7Ozs7OztlQU9HO1lBQ0gsS0FBSyxFQUFFLEVBQUMsSUFBSSxFQUFFLE1BQU0sRUFBRSxLQUFLLEVBQUUsTUFBTSxFQUFDO1lBQ3BDLFNBQVMsRUFBRSxPQUFPO1lBQ2xCLE1BQU0sRUFBRSxNQUFNO1lBQ2QsbUJBQW1CLEVBQUU7Z0JBQ25CLElBQUksRUFBRSxLQUFLO2dCQUNYLEtBQUssRUFBRTtvQkFDTCxPQUFPLEVBQUUsQ0FBQTtnQkFDWCxDQUFDO2FBQ0Y7WUFDRCxnQkFBZ0IsRUFBRTtnQkFDaEIsSUFBSSxFQUFFLE1BQU07Z0JBQ1osS0FBSyxFQUFFO29CQUNMLE9BQU8sRUFBRSxDQUFBO2dCQUNYLENBQUM7YUFDRjtZQUNELHlCQUF5QixFQUFFLEVBQUMsSUFBSSxFQUFFLE1BQU0sRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFDO1NBQ3ZEO1FBQ0QsU0FBUyxFQUFFO1lBQ1QsMENBQTBDO1lBQzFDLDBCQUEwQjtTQUMzQjtRQUNELGdCQUFnQixFQUFFLFVBQVMsS0FBSztZQUM5QixJQUFJLENBQUMsbUJBQW1CLEdBQUcsS0FBSyxDQUFDO1lBQ2pDLElBQUksSUFBSSxDQUFDLE1BQU0sRUFBRTtnQkFDZixJQUFJLENBQUMsTUFBTSxDQUFDLGdCQUFnQixDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUNwQyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7YUFDZjtRQUNILENBQUM7UUFDRCxhQUFhLEVBQUUsVUFBUyxJQUFJLEVBQUUsSUFBSTtZQUNoQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDO1lBQ25DLElBQUksSUFBSSxDQUFDLE1BQU0sRUFBRTtnQkFDZixJQUFJLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLENBQUM7YUFDdkM7UUFDSCxDQUFDO1FBQ0QsTUFBTSxFQUFFO1lBQ04sSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUN2QixDQUFDO1FBQ0QsS0FBSyxFQUFFO1lBQ0wsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsQ0FBQztRQUMzQyxDQUFDO1FBQ0QsVUFBVSxFQUFFLFVBQVMsS0FBSyxFQUFFLFVBQVUsRUFBRSxTQUFTO1lBQy9DLElBQUksSUFBSSxDQUFDLHlCQUF5QixLQUFLLElBQUksRUFBRTtnQkFDM0MsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMseUJBQXlCLENBQUMsQ0FBQzthQUNsRDtZQUVELElBQUksQ0FBQyx5QkFBeUIsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDO2dCQUMxQyxJQUFJLENBQUMseUJBQXlCLEdBQUcsSUFBSSxDQUFDO2dCQUN0QyxJQUFJLENBQUMsU0FBUztvQkFBRSxPQUFPO2dCQUN2QixJQUFJLElBQUksQ0FBQyxNQUFNO29CQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFLENBQUM7Z0JBQ3ZDLElBQUksS0FBSyxHQUFHLElBQUksaUJBQWlCLENBQUMsS0FBSyxFQUFFLFVBQVUsQ0FBQyxDQUFDO2dCQUNyRCxJQUFJLEdBQUcsR0FBRyxFQUFFLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUM7Z0JBQ3JDLEtBQUssQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQ3BCLElBQUksQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDO1lBQ3RCLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQztRQUNWLENBQUM7UUFDRCxnQkFBZ0IsRUFBRTtZQUNoQixJQUFJLElBQUksQ0FBQyxNQUFNLEVBQUU7Z0JBQ2YsSUFBSSxDQUFDLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsQ0FBQztnQkFDdkQsSUFBSSxDQUFDLG1CQUFtQixDQUFDLE9BQU8sQ0FBQyxVQUFTLElBQUk7b0JBQzVDLElBQUksQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDLENBQUM7Z0JBQ3JFLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQzthQUNmO1FBQ0gsQ0FBQztRQUNELFFBQVEsRUFBRTtZQUNSLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDO1FBQ3hCLENBQUM7UUFDRCxRQUFRLEVBQUU7WUFDUixJQUFJLENBQUMsU0FBUyxHQUFHLEtBQUssQ0FBQztRQUN6QixDQUFDO0tBQ0YsQ0FBQyxDQUFDO0FBRUgsQ0FBQyxFQS9OUyxxQkFBcUIsS0FBckIscUJBQXFCLFFBK045QixDQUFFLGtDQUFrQyIsInNvdXJjZXNDb250ZW50IjpbIi8qIENvcHlyaWdodCAyMDE1IFRoZSBUZW5zb3JGbG93IEF1dGhvcnMuIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG5cbkxpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSBcIkxpY2Vuc2VcIik7XG55b3UgbWF5IG5vdCB1c2UgdGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlIHdpdGggdGhlIExpY2Vuc2UuXG5Zb3UgbWF5IG9idGFpbiBhIGNvcHkgb2YgdGhlIExpY2Vuc2UgYXRcblxuICAgIGh0dHA6Ly93d3cuYXBhY2hlLm9yZy9saWNlbnNlcy9MSUNFTlNFLTIuMFxuXG5Vbmxlc3MgcmVxdWlyZWQgYnkgYXBwbGljYWJsZSBsYXcgb3IgYWdyZWVkIHRvIGluIHdyaXRpbmcsIHNvZnR3YXJlXG5kaXN0cmlidXRlZCB1bmRlciB0aGUgTGljZW5zZSBpcyBkaXN0cmlidXRlZCBvbiBhbiBcIkFTIElTXCIgQkFTSVMsXG5XSVRIT1VUIFdBUlJBTlRJRVMgT1IgQ09ORElUSU9OUyBPRiBBTlkgS0lORCwgZWl0aGVyIGV4cHJlc3Mgb3IgaW1wbGllZC5cblNlZSB0aGUgTGljZW5zZSBmb3IgdGhlIHNwZWNpZmljIGxhbmd1YWdlIGdvdmVybmluZyBwZXJtaXNzaW9ucyBhbmRcbmxpbWl0YXRpb25zIHVuZGVyIHRoZSBMaWNlbnNlLlxuPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09Ki9cbm5hbWVzcGFjZSB2el9kaXN0cmlidXRpb25fY2hhcnQge1xuXG5leHBvcnQgY2xhc3MgRGlzdHJpYnV0aW9uQ2hhcnQge1xuICBwcml2YXRlIHJ1bjJkYXRhc2V0czoge1tydW46IHN0cmluZ106IFBsb3R0YWJsZS5EYXRhc2V0fTtcbiAgcHJvdGVjdGVkIHJ1bnM6IHN0cmluZ1tdO1xuXG4gIHByb3RlY3RlZCB4QWNjZXNzb3I6IFBsb3R0YWJsZS5JQWNjZXNzb3I8bnVtYmVyfERhdGU+O1xuICBwcm90ZWN0ZWQgeFNjYWxlOiBQbG90dGFibGUuUXVhbnRpdGF0aXZlU2NhbGU8bnVtYmVyfERhdGU+O1xuICBwcm90ZWN0ZWQgeVNjYWxlOiBQbG90dGFibGUuUXVhbnRpdGF0aXZlU2NhbGU8bnVtYmVyPjtcbiAgcHJvdGVjdGVkIGdyaWRsaW5lczogUGxvdHRhYmxlLkNvbXBvbmVudHMuR3JpZGxpbmVzO1xuICBwcm90ZWN0ZWQgY2VudGVyOiBQbG90dGFibGUuQ29tcG9uZW50cy5Hcm91cDtcbiAgcHJvdGVjdGVkIHhBeGlzOiBQbG90dGFibGUuQXhlcy5OdW1lcmljfFBsb3R0YWJsZS5BeGVzLlRpbWU7XG4gIHByb3RlY3RlZCB5QXhpczogUGxvdHRhYmxlLkF4ZXMuTnVtZXJpYztcbiAgcHJvdGVjdGVkIHhMYWJlbDogUGxvdHRhYmxlLkNvbXBvbmVudHMuQXhpc0xhYmVsO1xuICBwcm90ZWN0ZWQgeUxhYmVsOiBQbG90dGFibGUuQ29tcG9uZW50cy5BeGlzTGFiZWw7XG4gIHByb3RlY3RlZCBvdXRlcjogUGxvdHRhYmxlLkNvbXBvbmVudHMuVGFibGU7XG4gIHByb3RlY3RlZCBjb2xvclNjYWxlOiBQbG90dGFibGUuU2NhbGVzLkNvbG9yO1xuICBwcml2YXRlIHBsb3RzOiBQbG90dGFibGUuWFlQbG90PG51bWJlcnxEYXRlLCBudW1iZXI+W107XG5cbiAgcHJpdmF0ZSB0YXJnZXRTVkc6IGQzLlNlbGVjdGlvbjxhbnksIGFueSwgYW55LCBhbnk+O1xuXG4gIGNvbnN0cnVjdG9yKHhUeXBlOiBzdHJpbmcsIGNvbG9yU2NhbGU6IFBsb3R0YWJsZS5TY2FsZXMuQ29sb3IpIHtcbiAgICB0aGlzLnJ1bjJkYXRhc2V0cyA9IHt9O1xuICAgIHRoaXMuY29sb3JTY2FsZSA9IGNvbG9yU2NhbGU7XG4gICAgdGhpcy5idWlsZENoYXJ0KHhUeXBlKTtcbiAgfVxuXG4gIHByb3RlY3RlZCBnZXREYXRhc2V0KHJ1bjogc3RyaW5nKSB7XG4gICAgaWYgKHRoaXMucnVuMmRhdGFzZXRzW3J1bl0gPT09IHVuZGVmaW5lZCkge1xuICAgICAgdGhpcy5ydW4yZGF0YXNldHNbcnVuXSA9IG5ldyBQbG90dGFibGUuRGF0YXNldChbXSwge3J1bjogcnVufSk7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLnJ1bjJkYXRhc2V0c1tydW5dO1xuICB9XG5cbiAgcHJvdGVjdGVkIGJ1aWxkQ2hhcnQoeFR5cGU6IHN0cmluZykge1xuICAgIGlmICh0aGlzLm91dGVyKSB7XG4gICAgICB0aGlzLm91dGVyLmRlc3Ryb3koKTtcbiAgICB9XG4gICAgbGV0IHhDb21wb25lbnRzID0gdnpfY2hhcnRfaGVscGVycy5nZXRYQ29tcG9uZW50cyh4VHlwZSk7XG4gICAgdGhpcy54QWNjZXNzb3IgPSB4Q29tcG9uZW50cy5hY2Nlc3NvcjtcbiAgICB0aGlzLnhTY2FsZSA9IHhDb21wb25lbnRzLnNjYWxlO1xuICAgIHRoaXMueEF4aXMgPSB4Q29tcG9uZW50cy5heGlzO1xuICAgIHRoaXMueEF4aXMubWFyZ2luKDApLnRpY2tMYWJlbFBhZGRpbmcoMyk7XG4gICAgdGhpcy55U2NhbGUgPSBuZXcgUGxvdHRhYmxlLlNjYWxlcy5MaW5lYXIoKTtcbiAgICB0aGlzLnlBeGlzID0gbmV3IFBsb3R0YWJsZS5BeGVzLk51bWVyaWModGhpcy55U2NhbGUsICdsZWZ0Jyk7XG4gICAgbGV0IHlGb3JtYXR0ZXIgPSB2el9jaGFydF9oZWxwZXJzLm11bHRpc2NhbGVGb3JtYXR0ZXIoXG4gICAgICAgIHZ6X2NoYXJ0X2hlbHBlcnMuWV9BWElTX0ZPUk1BVFRFUl9QUkVDSVNJT04pO1xuICAgIHRoaXMueUF4aXMubWFyZ2luKDApLnRpY2tMYWJlbFBhZGRpbmcoNSkuZm9ybWF0dGVyKHlGb3JtYXR0ZXIpO1xuICAgIHRoaXMueUF4aXMudXNlc1RleHRXaWR0aEFwcHJveGltYXRpb24odHJ1ZSk7XG5cbiAgICBsZXQgY2VudGVyID0gdGhpcy5idWlsZFBsb3QodGhpcy54QWNjZXNzb3IsIHRoaXMueFNjYWxlLCB0aGlzLnlTY2FsZSk7XG5cbiAgICB0aGlzLmdyaWRsaW5lcyA9XG4gICAgICAgIG5ldyBQbG90dGFibGUuQ29tcG9uZW50cy5HcmlkbGluZXModGhpcy54U2NhbGUsIHRoaXMueVNjYWxlKTtcblxuICAgIHRoaXMuY2VudGVyID0gbmV3IFBsb3R0YWJsZS5Db21wb25lbnRzLkdyb3VwKFt0aGlzLmdyaWRsaW5lcywgY2VudGVyXSk7XG4gICAgdGhpcy5vdXRlciA9IG5ldyBQbG90dGFibGUuQ29tcG9uZW50cy5UYWJsZShcbiAgICAgICAgW1t0aGlzLnlBeGlzLCB0aGlzLmNlbnRlcl0sIFtudWxsLCB0aGlzLnhBeGlzXV0pO1xuICB9XG5cbiAgcHJvdGVjdGVkIGJ1aWxkUGxvdCh4QWNjZXNzb3IsIHhTY2FsZSwgeVNjYWxlKTogUGxvdHRhYmxlLkNvbXBvbmVudCB7XG4gICAgbGV0IHBlcmNlbnRzID0gWzAsIDIyOCwgMTU4NywgMzA4NSwgNTAwMCwgNjkxNSwgODQxMywgOTc3MiwgMTAwMDBdO1xuICAgIGxldCBvcGFjaXRpZXMgPSBfLnJhbmdlKHBlcmNlbnRzLmxlbmd0aCAtIDEpXG4gICAgICAgICAgICAgICAgICAgICAgICAubWFwKChpKSA9PiAocGVyY2VudHNbaSArIDFdIC0gcGVyY2VudHNbaV0pIC8gMjUwMCk7XG4gICAgbGV0IGFjY2Vzc29ycyA9IHBlcmNlbnRzLm1hcCgocCwgaSkgPT4gKGRhdHVtKSA9PiBkYXR1bVtpXVsxXSk7XG4gICAgbGV0IG1lZGlhbiA9IDQ7XG4gICAgbGV0IG1lZGlhbkFjY2Vzc29yID0gYWNjZXNzb3JzW21lZGlhbl07XG5cbiAgICBsZXQgcGxvdHMgPSBfLnJhbmdlKGFjY2Vzc29ycy5sZW5ndGggLSAxKS5tYXAoKGkpID0+IHtcbiAgICAgIGxldCBwID0gbmV3IFBsb3R0YWJsZS5QbG90cy5BcmVhPG51bWJlcnxEYXRlPigpO1xuICAgICAgcC54KHhBY2Nlc3NvciwgeFNjYWxlKTtcblxuICAgICAgbGV0IHkwID0gaSA+IG1lZGlhbiA/IGFjY2Vzc29yc1tpXSA6IGFjY2Vzc29yc1tpICsgMV07XG4gICAgICBsZXQgeSA9IGkgPiBtZWRpYW4gPyBhY2Nlc3NvcnNbaSArIDFdIDogYWNjZXNzb3JzW2ldO1xuICAgICAgcC55KHksIHlTY2FsZSk7XG4gICAgICBwLnkwKHkwKTtcbiAgICAgIHAuYXR0cihcbiAgICAgICAgICAnZmlsbCcsXG4gICAgICAgICAgKGQ6IGFueSwgaTogbnVtYmVyLCBkYXRhc2V0OiBQbG90dGFibGUuRGF0YXNldCkgPT5cbiAgICAgICAgICAgICAgdGhpcy5jb2xvclNjYWxlLnNjYWxlKGRhdGFzZXQubWV0YWRhdGEoKS5ydW4pKTtcbiAgICAgIHAuYXR0cihcbiAgICAgICAgICAnc3Ryb2tlJyxcbiAgICAgICAgICAoZDogYW55LCBpOiBudW1iZXIsIGRhdGFzZXQ6IFBsb3R0YWJsZS5EYXRhc2V0KSA9PlxuICAgICAgICAgICAgICB0aGlzLmNvbG9yU2NhbGUuc2NhbGUoZGF0YXNldC5tZXRhZGF0YSgpLnJ1bikpO1xuICAgICAgcC5hdHRyKCdzdHJva2Utd2VpZ2h0JywgKGQ6IGFueSwgaTogbnVtYmVyLCBtOiBhbnkpID0+ICcwLjVweCcpO1xuICAgICAgcC5hdHRyKCdzdHJva2Utb3BhY2l0eScsICgpID0+IG9wYWNpdGllc1tpXSk7XG4gICAgICBwLmF0dHIoJ2ZpbGwtb3BhY2l0eScsICgpID0+IG9wYWNpdGllc1tpXSk7XG4gICAgICByZXR1cm4gcDtcbiAgICB9KTtcblxuICAgIGxldCBtZWRpYW5QbG90ID0gbmV3IFBsb3R0YWJsZS5QbG90cy5MaW5lPG51bWJlcnxEYXRlPigpO1xuICAgIG1lZGlhblBsb3QueCh4QWNjZXNzb3IsIHhTY2FsZSk7XG4gICAgbWVkaWFuUGxvdC55KG1lZGlhbkFjY2Vzc29yLCB5U2NhbGUpO1xuICAgIG1lZGlhblBsb3QuYXR0cihcbiAgICAgICAgJ3N0cm9rZScsIChkOiBhbnksIGk6IG51bWJlciwgbTogYW55KSA9PiB0aGlzLmNvbG9yU2NhbGUuc2NhbGUobS5ydW4pKTtcblxuICAgIHRoaXMucGxvdHMgPSBwbG90cztcbiAgICByZXR1cm4gbmV3IFBsb3R0YWJsZS5Db21wb25lbnRzLkdyb3VwKHBsb3RzKTtcbiAgfVxuXG4gIHB1YmxpYyBzZXRWaXNpYmxlU2VyaWVzKHJ1bnM6IHN0cmluZ1tdKSB7XG4gICAgdGhpcy5ydW5zID0gcnVucztcbiAgICBsZXQgZGF0YXNldHMgPSBydW5zLm1hcCgocikgPT4gdGhpcy5nZXREYXRhc2V0KHIpKTtcbiAgICB0aGlzLnBsb3RzLmZvckVhY2goKHApID0+IHAuZGF0YXNldHMoZGF0YXNldHMpKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBTZXQgdGhlIGRhdGEgb2YgYSBzZXJpZXMgb24gdGhlIGNoYXJ0LlxuICAgKi9cbiAgcHVibGljIHNldFNlcmllc0RhdGEobmFtZTogc3RyaW5nLCBkYXRhOiBhbnkpIHtcbiAgICB0aGlzLmdldERhdGFzZXQobmFtZSkuZGF0YShkYXRhKTtcbiAgfVxuXG4gIHB1YmxpYyByZW5kZXJUbyh0YXJnZXRTVkc6IGQzLlNlbGVjdGlvbjxhbnksIGFueSwgYW55LCBhbnk+KSB7XG4gICAgdGhpcy50YXJnZXRTVkcgPSB0YXJnZXRTVkc7XG4gICAgdGhpcy5vdXRlci5yZW5kZXJUbyh0YXJnZXRTVkcpO1xuICB9XG5cbiAgcHVibGljIHJlZHJhdygpIHtcbiAgICB0aGlzLm91dGVyLnJlZHJhdygpO1xuICB9XG5cbiAgcHJvdGVjdGVkIGRlc3Ryb3koKSB7XG4gICAgdGhpcy5vdXRlci5kZXN0cm95KCk7XG4gIH1cbn1cblxuXG5Qb2x5bWVyKHtcbiAgaXM6ICd2ei1kaXN0cmlidXRpb24tY2hhcnQnLFxuICBwcm9wZXJ0aWVzOiB7XG4gICAgLyoqXG4gICAgICogU2NhbGUgdGhhdCBtYXBzIHNlcmllcyBuYW1lcyB0byBjb2xvcnMuIFRoZSBkZWZhdWx0IGNvbG9ycyBhcmUgZnJvbVxuICAgICAqIGQzLmQzLnNjaGVtZUNhdGVnb3J5MTAuIFVzZSB0aGlzIHByb3BlcnR5IHRvIHJlcGxhY2UgdGhlIGRlZmF1bHRcbiAgICAgKiBsaW5lIGNvbG9ycyB3aXRoIGNvbG9ycyBvZiB5b3VyIG93biBjaG9pY2UuXG4gICAgICogQHR5cGUge1Bsb3R0YWJsZS5TY2FsZXMuQ29sb3J9XG4gICAgICogQHJlcXVpcmVkXG4gICAgICovXG4gICAgY29sb3JTY2FsZToge1xuICAgICAgdHlwZTogT2JqZWN0LFxuICAgICAgdmFsdWU6IGZ1bmN0aW9uKCkge1xuICAgICAgICByZXR1cm4gbmV3IFBsb3R0YWJsZS5TY2FsZXMuQ29sb3IoKS5yYW5nZShkMy5zY2hlbWVDYXRlZ29yeTEwKTtcbiAgICAgIH1cbiAgICB9LFxuICAgIC8qKlxuICAgICAqIFRoZSB3YXkgdG8gZGlzcGxheSB0aGUgWCB2YWx1ZXMuIEFsbG93czpcbiAgICAgKiAtIFwic3RlcFwiIC0gTGluZWFyIHNjYWxlIHVzaW5nIHRoZSAgXCJzdGVwXCIgcHJvcGVydHkgb2YgdGhlIGRhdHVtLlxuICAgICAqIC0gXCJ3YWxsX3RpbWVcIiAtIFRlbXBvcmFsIHNjYWxlIHVzaW5nIHRoZSBcIndhbGxfdGltZVwiIHByb3BlcnR5IG9mIHRoZVxuICAgICAqIGRhdHVtLlxuICAgICAqIC0gXCJyZWxhdGl2ZVwiIC0gVGVtcG9yYWwgc2NhbGUgdXNpbmcgdGhlIFwicmVsYXRpdmVcIiBwcm9wZXJ0eSBvZiB0aGVcbiAgICAgKiBkYXR1bSBpZiBpdCBpcyBwcmVzZW50IG9yIGNhbGN1bGF0aW5nIGZyb20gXCJ3YWxsX3RpbWVcIiBpZiBpdCBpc24ndC5cbiAgICAgKi9cbiAgICB4VHlwZToge3R5cGU6IFN0cmluZywgdmFsdWU6ICdzdGVwJ30sXG4gICAgX2F0dGFjaGVkOiBCb29sZWFuLFxuICAgIF9jaGFydDogT2JqZWN0LFxuICAgIF92aXNpYmxlU2VyaWVzQ2FjaGU6IHtcbiAgICAgIHR5cGU6IEFycmF5LFxuICAgICAgdmFsdWU6IGZ1bmN0aW9uKCkge1xuICAgICAgICByZXR1cm4gW11cbiAgICAgIH1cbiAgICB9LFxuICAgIF9zZXJpZXNEYXRhQ2FjaGU6IHtcbiAgICAgIHR5cGU6IE9iamVjdCxcbiAgICAgIHZhbHVlOiBmdW5jdGlvbigpIHtcbiAgICAgICAgcmV0dXJuIHt9XG4gICAgICB9XG4gICAgfSxcbiAgICBfbWFrZUNoYXJ0QXN5bmNDYWxsYmFja0lkOiB7dHlwZTogTnVtYmVyLCB2YWx1ZTogbnVsbH1cbiAgfSxcbiAgb2JzZXJ2ZXJzOiBbXG4gICAgJ19tYWtlQ2hhcnQoeFR5cGUsIGNvbG9yU2NhbGUsIF9hdHRhY2hlZCknLFxuICAgICdfcmVsb2FkRnJvbUNhY2hlKF9jaGFydCknLFxuICBdLFxuICBzZXRWaXNpYmxlU2VyaWVzOiBmdW5jdGlvbihuYW1lcykge1xuICAgIHRoaXMuX3Zpc2libGVTZXJpZXNDYWNoZSA9IG5hbWVzO1xuICAgIGlmICh0aGlzLl9jaGFydCkge1xuICAgICAgdGhpcy5fY2hhcnQuc2V0VmlzaWJsZVNlcmllcyhuYW1lcyk7XG4gICAgICB0aGlzLnJlZHJhdygpO1xuICAgIH1cbiAgfSxcbiAgc2V0U2VyaWVzRGF0YTogZnVuY3Rpb24obmFtZSwgZGF0YSkge1xuICAgIHRoaXMuX3Nlcmllc0RhdGFDYWNoZVtuYW1lXSA9IGRhdGE7XG4gICAgaWYgKHRoaXMuX2NoYXJ0KSB7XG4gICAgICB0aGlzLl9jaGFydC5zZXRTZXJpZXNEYXRhKG5hbWUsIGRhdGEpO1xuICAgIH1cbiAgfSxcbiAgcmVkcmF3OiBmdW5jdGlvbigpIHtcbiAgICB0aGlzLl9jaGFydC5yZWRyYXcoKTtcbiAgfSxcbiAgcmVhZHk6IGZ1bmN0aW9uKCkge1xuICAgIHRoaXMuc2NvcGVTdWJ0cmVlKHRoaXMuJC5jaGFydGRpdiwgdHJ1ZSk7XG4gIH0sXG4gIF9tYWtlQ2hhcnQ6IGZ1bmN0aW9uKHhUeXBlLCBjb2xvclNjYWxlLCBfYXR0YWNoZWQpIHtcbiAgICBpZiAodGhpcy5fbWFrZUNoYXJ0QXN5bmNDYWxsYmFja0lkID09PSBudWxsKSB7XG4gICAgICB0aGlzLmNhbmNlbEFzeW5jKHRoaXMuX21ha2VDaGFydEFzeW5jQ2FsbGJhY2tJZCk7XG4gICAgfVxuXG4gICAgdGhpcy5fbWFrZUNoYXJ0QXN5bmNDYWxsYmFja0lkID0gdGhpcy5hc3luYyhmdW5jdGlvbigpIHtcbiAgICAgIHRoaXMuX21ha2VDaGFydEFzeW5jQ2FsbGJhY2tJZCA9IG51bGw7XG4gICAgICBpZiAoIV9hdHRhY2hlZCkgcmV0dXJuO1xuICAgICAgaWYgKHRoaXMuX2NoYXJ0KSB0aGlzLl9jaGFydC5kZXN0cm95KCk7XG4gICAgICB2YXIgY2hhcnQgPSBuZXcgRGlzdHJpYnV0aW9uQ2hhcnQoeFR5cGUsIGNvbG9yU2NhbGUpO1xuICAgICAgdmFyIHN2ZyA9IGQzLnNlbGVjdCh0aGlzLiQuY2hhcnRkaXYpO1xuICAgICAgY2hhcnQucmVuZGVyVG8oc3ZnKTtcbiAgICAgIHRoaXMuX2NoYXJ0ID0gY2hhcnQ7XG4gICAgfSwgMzUwKTtcbiAgfSxcbiAgX3JlbG9hZEZyb21DYWNoZTogZnVuY3Rpb24oKSB7XG4gICAgaWYgKHRoaXMuX2NoYXJ0KSB7XG4gICAgICB0aGlzLl9jaGFydC5zZXRWaXNpYmxlU2VyaWVzKHRoaXMuX3Zpc2libGVTZXJpZXNDYWNoZSk7XG4gICAgICB0aGlzLl92aXNpYmxlU2VyaWVzQ2FjaGUuZm9yRWFjaChmdW5jdGlvbihuYW1lKSB7XG4gICAgICAgIHRoaXMuX2NoYXJ0LnNldFNlcmllc0RhdGEobmFtZSwgdGhpcy5fc2VyaWVzRGF0YUNhY2hlW25hbWVdIHx8IFtdKTtcbiAgICAgIH0uYmluZCh0aGlzKSk7XG4gICAgfVxuICB9LFxuICBhdHRhY2hlZDogZnVuY3Rpb24oKSB7XG4gICAgdGhpcy5fYXR0YWNoZWQgPSB0cnVlO1xuICB9LFxuICBkZXRhY2hlZDogZnVuY3Rpb24oKSB7XG4gICAgdGhpcy5fYXR0YWNoZWQgPSBmYWxzZTtcbiAgfVxufSk7XG5cbn0gIC8vIG5hbWVzcGFjZSB2el9kaXN0cmlidXRpb25fY2hhcnRcbiJdfQ==