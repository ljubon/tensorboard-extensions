/* Copyright 2015 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the 'License');
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an 'AS IS' BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
var tf;
(function (tf) {
    var graph;
    (function (graph) {
        var scene;
        (function (scene) {
            var annotation;
            (function (annotation_1) {
                /**
                 * Populate a given annotation container group
                 *
                 *     <g class='{in|out}-annotations'></g>
                 *
                 * with annotation group of the following structure:
                 *
                 * <g class='annotation'>
                 *   <g class='annotation-node'>
                 *   <!--
                 *   Content here determined by Scene.node.buildGroup.
                 *   -->
                 *   </g>
                 * </g>
                 *
                 * @param container selection of the container.
                 * @param annotationData node.{in|out}Annotations
                 * @param d node to build group for.
                 * @param sceneElement <tf-graph-scene> polymer element.
                 * @return selection of appended objects
                 */
                function buildGroup(container, annotationData, d, sceneElement) {
                    // Select all children and join with data.
                    var annotationGroups = container
                        .selectAll(function () {
                        // using d3's selector function
                        // See https://github.com/mbostock/d3/releases/tag/v2.0.0
                        // (It's not listed in the d3 wiki.)
                        return this.childNodes;
                    })
                        .data(annotationData.list, function (d) { return d.node.name; });
                    annotationGroups.enter()
                        .append('g')
                        .attr('data-name', function (a) { return a.node.name; })
                        .each(function (a) {
                        var aGroup = d3.select(this);
                        // Add annotation to the index in the scene
                        sceneElement.addAnnotationGroup(a, d, aGroup);
                        // Append annotation edge
                        var edgeType = scene.Class.Annotation.EDGE;
                        var metaedge = a.renderMetaedgeInfo && a.renderMetaedgeInfo.metaedge;
                        if (metaedge && !metaedge.numRegularEdges) {
                            edgeType += ' ' + scene.Class.Annotation.CONTROL_EDGE;
                        }
                        // If any edges are reference edges, add the reference edge class.
                        if (metaedge && metaedge.numRefEdges) {
                            edgeType += ' ' + scene.Class.Edge.REF_LINE;
                        }
                        scene.edge.appendEdge(aGroup, a, sceneElement, edgeType);
                        if (a.annotationType !== graph.render.AnnotationType.ELLIPSIS) {
                            addAnnotationLabelFromNode(aGroup, a);
                            buildShape(aGroup, a);
                        }
                        else {
                            addAnnotationLabel(aGroup, a.node.name, a, scene.Class.Annotation.ELLIPSIS);
                        }
                    }).merge(annotationGroups)
                        .attr('class', function (a) {
                        return scene.Class.Annotation.GROUP + ' ' +
                            annotationToClassName(a.annotationType) + ' ' +
                            scene.node.nodeClass(a);
                    })
                        .each(function (a) {
                        var aGroup = d3.select(this);
                        update(aGroup, d, a, sceneElement);
                        if (a.annotationType !== graph.render.AnnotationType.ELLIPSIS) {
                            addInteraction(aGroup, d, a, sceneElement);
                        }
                    });
                    annotationGroups.exit()
                        .each(function (a) {
                        var aGroup = d3.select(this);
                        // Remove annotation from the index in the scene
                        sceneElement.removeAnnotationGroup(a, d, aGroup);
                    })
                        .remove();
                    return annotationGroups;
                }
                annotation_1.buildGroup = buildGroup;
                ;
                /**
                 * Maps an annotation enum to a class name used in css rules.
                 */
                function annotationToClassName(annotationType) {
                    return (graph.render.AnnotationType[annotationType] || '').toLowerCase() || null;
                }
                function buildShape(aGroup, a) {
                    if (a.annotationType === graph.render.AnnotationType.SUMMARY) {
                        var summary = scene.selectOrCreateChild(aGroup, 'use');
                        summary
                            .attr('class', 'summary')
                            .attr('xlink:href', '#summary-icon')
                            .attr('cursor', 'pointer');
                    }
                    else {
                        var shape = scene.node.buildShape(aGroup, a, scene.Class.Annotation.NODE);
                        // add title tag to get native tooltips
                        scene.selectOrCreateChild(shape, 'title').text(a.node.name);
                    }
                }
                function addAnnotationLabelFromNode(aGroup, a) {
                    var namePath = a.node.name.split('/');
                    var text = namePath[namePath.length - 1];
                    return addAnnotationLabel(aGroup, text, a, null);
                }
                function addAnnotationLabel(aGroup, label, a, additionalClassNames) {
                    var classNames = scene.Class.Annotation.LABEL;
                    if (additionalClassNames) {
                        classNames += ' ' + additionalClassNames;
                    }
                    var txtElement = aGroup.append('text')
                        .attr('class', classNames)
                        .attr('dy', '.35em')
                        .attr('text-anchor', a.isIn ? 'end' : 'start')
                        .text(label);
                    return tf.graph.scene.node.enforceLabelWidth(txtElement, -1);
                }
                function addInteraction(selection, d, annotation, sceneElement) {
                    selection
                        .on('mouseover', function (a) {
                        sceneElement.fire('annotation-highlight', { name: a.node.name, hostName: d.node.name });
                    })
                        .on('mouseout', function (a) {
                        sceneElement.fire('annotation-unhighlight', { name: a.node.name, hostName: d.node.name });
                    })
                        .on('click', function (a) {
                        // Stop this event's propagation so that it isn't also considered a
                        // graph-select.
                        d3.event.stopPropagation();
                        sceneElement.fire('annotation-select', { name: a.node.name, hostName: d.node.name });
                    });
                    if (annotation.annotationType !== graph.render.AnnotationType.SUMMARY &&
                        annotation.annotationType !== graph.render.AnnotationType.CONSTANT) {
                        selection.on('contextmenu', scene.contextmenu.getMenu(sceneElement, scene.node.getContextMenu(annotation.node, sceneElement)));
                    }
                }
                ;
                /**
                 * Adjust annotation's position.
                 *
                 * @param aGroup selection of a 'g.annotation' element.
                 * @param d Host node data.
                 * @param a annotation node data.
                 * @param sceneElement <tf-graph-scene> polymer element.
                 */
                function update(aGroup, d, a, sceneElement) {
                    var cx = graph.layout.computeCXPositionOfNodeShape(d);
                    // Annotations that point to embedded nodes (constants,summary)
                    // don't have a render information attached so we don't stylize these.
                    // Also we don't stylize ellipsis annotations (the string '... and X more').
                    if (a.renderNodeInfo &&
                        a.annotationType !== graph.render.AnnotationType.ELLIPSIS) {
                        scene.node.stylize(aGroup, a.renderNodeInfo, sceneElement, scene.Class.Annotation.NODE);
                    }
                    if (a.annotationType === graph.render.AnnotationType.SUMMARY) {
                        // Update the width of the annotation to give space for the image.
                        a.width += 10;
                    }
                    // label position
                    aGroup.select('text.' + scene.Class.Annotation.LABEL).transition()
                        .attr('x', cx + a.dx + (a.isIn ? -1 : 1) * (a.width / 2 + a.labelOffset))
                        .attr('y', d.y + a.dy);
                    // Some annotations (such as summary) are represented using a 12x12 image tag.
                    // Purposely omitted units (e.g. pixels) since the images are vector graphics.
                    // If there is an image, we adjust the location of the image to be vertically
                    // centered with the node and horizontally centered between the arrow and the
                    // text label.
                    aGroup.select('use.summary').transition()
                        .attr('x', cx + a.dx - 3)
                        .attr('y', d.y + a.dy - 6);
                    // Node position (only one of the shape selection will be non-empty.)
                    scene.positionEllipse(aGroup.select('.' + scene.Class.Annotation.NODE + ' ellipse'), cx + a.dx, d.y + a.dy, a.width, a.height);
                    scene.positionRect(aGroup.select('.' + scene.Class.Annotation.NODE + ' rect'), cx + a.dx, d.y + a.dy, a.width, a.height);
                    scene.positionRect(aGroup.select('.' + scene.Class.Annotation.NODE + ' use'), cx + a.dx, d.y + a.dy, a.width, a.height);
                    // Edge position
                    aGroup.select('path.' + scene.Class.Annotation.EDGE).transition().attr('d', function (a) {
                        // map relative position to absolute position
                        var points = a.points.map(function (p) { return { x: p.dx + cx, y: p.dy + d.y }; });
                        return scene.edge.interpolate(points);
                    });
                }
                ;
            })(annotation = scene.annotation || (scene.annotation = {}));
        })(scene = graph.scene || (graph.scene = {}));
    })(graph = tf.graph || (tf.graph = {}));
})(tf || (tf = {})); // close module
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYW5ub3RhdGlvbi5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImFubm90YXRpb24udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7Ozs7Ozs7Z0ZBYWdGO0FBQ2hGLElBQU8sRUFBRSxDQTZOUjtBQTdORCxXQUFPLEVBQUU7SUFBQyxJQUFBLEtBQUssQ0E2TmQ7SUE3TlMsV0FBQSxLQUFLO1FBQUMsSUFBQSxLQUFLLENBNk5wQjtRQTdOZSxXQUFBLEtBQUs7WUFBQyxJQUFBLFVBQVUsQ0E2Ti9CO1lBN05xQixXQUFBLFlBQVU7Z0JBQzlCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OzttQkFvQkc7Z0JBQ0gsb0JBQ0ksU0FBUyxFQUFFLGNBQXFDLEVBQ2hELENBQXdCLEVBQUUsWUFBWTtvQkFDeEMsMENBQTBDO29CQUMxQyxJQUFJLGdCQUFnQixHQUNoQixTQUFTO3lCQUNKLFNBQVMsQ0FBQzt3QkFDVCwrQkFBK0I7d0JBQy9CLHlEQUF5RDt3QkFDekQsb0NBQW9DO3dCQUNwQyxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUM7b0JBQ3pCLENBQUMsQ0FBQzt5QkFDRCxJQUFJLENBQUMsY0FBYyxDQUFDLElBQUksRUFBRSxVQUFBLENBQUMsSUFBTSxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBRWpFLGdCQUFnQixDQUFDLEtBQUssRUFBRTt5QkFDbkIsTUFBTSxDQUFDLEdBQUcsQ0FBQzt5QkFDWCxJQUFJLENBQUMsV0FBVyxFQUFFLFVBQUEsQ0FBQyxJQUFNLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7eUJBQy9DLElBQUksQ0FBQyxVQUFTLENBQUM7d0JBQ2QsSUFBSSxNQUFNLEdBQUcsRUFBRSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQzt3QkFFN0IsMkNBQTJDO3dCQUMzQyxZQUFZLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxNQUFNLENBQUMsQ0FBQzt3QkFDOUMseUJBQXlCO3dCQUN6QixJQUFJLFFBQVEsR0FBRyxNQUFBLEtBQUssQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDO3dCQUNyQyxJQUFJLFFBQVEsR0FBRyxDQUFDLENBQUMsa0JBQWtCLElBQUksQ0FBQyxDQUFDLGtCQUFrQixDQUFDLFFBQVEsQ0FBQzt3QkFDckUsSUFBSSxRQUFRLElBQUksQ0FBQyxRQUFRLENBQUMsZUFBZSxFQUFFOzRCQUN6QyxRQUFRLElBQUksR0FBRyxHQUFHLE1BQUEsS0FBSyxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUM7eUJBQ2pEO3dCQUNELGtFQUFrRTt3QkFDbEUsSUFBSSxRQUFRLElBQUksUUFBUSxDQUFDLFdBQVcsRUFBRTs0QkFDcEMsUUFBUSxJQUFJLEdBQUcsR0FBRyxNQUFBLEtBQUssQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDO3lCQUN2Qzt3QkFDRCxNQUFBLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxZQUFZLEVBQUUsUUFBUSxDQUFDLENBQUM7d0JBRW5ELElBQUksQ0FBQyxDQUFDLGNBQWMsS0FBSyxNQUFBLE1BQU0sQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFOzRCQUN2RCwwQkFBMEIsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUFDLENBQUM7NEJBQ3RDLFVBQVUsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUFDLENBQUM7eUJBQ3ZCOzZCQUFNOzRCQUNMLGtCQUFrQixDQUNkLE1BQU0sRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDLEVBQUUsTUFBQSxLQUFLLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDO3lCQUN4RDtvQkFDSCxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsZ0JBQWdCLENBQUM7eUJBQ3pCLElBQUksQ0FDRCxPQUFPLEVBQ1AsVUFBQSxDQUFDO3dCQUNDLE9BQU8sTUFBQSxLQUFLLENBQUMsVUFBVSxDQUFDLEtBQUssR0FBRyxHQUFHOzRCQUMvQixxQkFBcUIsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLEdBQUcsR0FBRzs0QkFDN0MsTUFBQSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUN4QixDQUFDLENBQUM7eUJBQ0wsSUFBSSxDQUFDLFVBQVMsQ0FBQzt3QkFDZCxJQUFJLE1BQU0sR0FBRyxFQUFFLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDO3dCQUM3QixNQUFNLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsWUFBWSxDQUFDLENBQUM7d0JBQ25DLElBQUksQ0FBQyxDQUFDLGNBQWMsS0FBSyxNQUFBLE1BQU0sQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFOzRCQUN2RCxjQUFjLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsWUFBWSxDQUFDLENBQUM7eUJBQzVDO29CQUNILENBQUMsQ0FBQyxDQUFDO29CQUVQLGdCQUFnQixDQUFDLElBQUksRUFBRTt5QkFDbEIsSUFBSSxDQUFDLFVBQVMsQ0FBQzt3QkFDZCxJQUFJLE1BQU0sR0FBRyxFQUFFLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDO3dCQUU3QixnREFBZ0Q7d0JBQ2hELFlBQVksQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDO29CQUNuRCxDQUFDLENBQUM7eUJBQ0QsTUFBTSxFQUFFLENBQUM7b0JBQ2QsT0FBTyxnQkFBZ0IsQ0FBQztnQkFDNUIsQ0FBQztnQkFsRWlCLHVCQUFVLGFBa0UzQixDQUFBO2dCQUFBLENBQUM7Z0JBRUY7O21CQUVHO2dCQUNILCtCQUErQixjQUFxQztvQkFDbEUsT0FBTyxDQUFDLE1BQUEsTUFBTSxDQUFDLGNBQWMsQ0FBQyxjQUFjLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxXQUFXLEVBQUUsSUFBSSxJQUFJLENBQUM7Z0JBQzdFLENBQUM7Z0JBRUQsb0JBQW9CLE1BQU0sRUFBRSxDQUFvQjtvQkFDOUMsSUFBSSxDQUFDLENBQUMsY0FBYyxLQUFLLE1BQUEsTUFBTSxDQUFDLGNBQWMsQ0FBQyxPQUFPLEVBQUU7d0JBQ3RELElBQUksT0FBTyxHQUFHLE1BQUEsbUJBQW1CLENBQUMsTUFBTSxFQUFFLEtBQUssQ0FBQyxDQUFDO3dCQUNqRCxPQUFPOzZCQUNKLElBQUksQ0FBQyxPQUFPLEVBQUUsU0FBUyxDQUFDOzZCQUN4QixJQUFJLENBQUMsWUFBWSxFQUFFLGVBQWUsQ0FBQzs2QkFDbkMsSUFBSSxDQUFDLFFBQVEsRUFBRSxTQUFTLENBQUMsQ0FBQztxQkFDOUI7eUJBQU07d0JBQ0wsSUFBSSxLQUFLLEdBQUcsTUFBQSxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsTUFBQSxLQUFLLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDO3dCQUM5RCx1Q0FBdUM7d0JBQ3ZDLE1BQUEsbUJBQW1CLENBQUMsS0FBSyxFQUFFLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO3FCQUN2RDtnQkFDSCxDQUFDO2dCQUVELG9DQUFvQyxNQUFNLEVBQUUsQ0FBb0I7b0JBQzlELElBQUksUUFBUSxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztvQkFDdEMsSUFBSSxJQUFJLEdBQUcsUUFBUSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUM7b0JBQ3pDLE9BQU8sa0JBQWtCLENBQUMsTUFBTSxFQUFFLElBQUksRUFBRSxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQ25ELENBQUM7Z0JBRUQsNEJBQ0ksTUFBTSxFQUFFLEtBQWEsRUFBRSxDQUFvQixFQUFFLG9CQUFvQjtvQkFDbkUsSUFBSSxVQUFVLEdBQUcsTUFBQSxLQUFLLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQztvQkFDeEMsSUFBSSxvQkFBb0IsRUFBRTt3QkFDeEIsVUFBVSxJQUFJLEdBQUcsR0FBRyxvQkFBb0IsQ0FBQztxQkFDMUM7b0JBQ0QsSUFBSSxVQUFVLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7eUJBQ2hCLElBQUksQ0FBQyxPQUFPLEVBQUUsVUFBVSxDQUFDO3lCQUN6QixJQUFJLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQzt5QkFDbkIsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQzt5QkFDN0MsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUVsQyxPQUFPLEVBQUUsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxVQUFVLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDL0QsQ0FBQztnQkFFRCx3QkFBd0IsU0FBUyxFQUFFLENBQXdCLEVBQ3ZELFVBQTZCLEVBQUUsWUFBWTtvQkFDN0MsU0FBUzt5QkFDSixFQUFFLENBQUMsV0FBVyxFQUNYLFVBQUEsQ0FBQzt3QkFDQyxZQUFZLENBQUMsSUFBSSxDQUNiLHNCQUFzQixFQUN0QixFQUFDLElBQUksRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxRQUFRLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUMsQ0FBQyxDQUFDO29CQUNsRCxDQUFDLENBQUM7eUJBQ0wsRUFBRSxDQUFDLFVBQVUsRUFDVixVQUFBLENBQUM7d0JBQ0MsWUFBWSxDQUFDLElBQUksQ0FDYix3QkFBd0IsRUFDeEIsRUFBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsUUFBUSxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFDLENBQUMsQ0FBQztvQkFDbEQsQ0FBQyxDQUFDO3lCQUNMLEVBQUUsQ0FBQyxPQUFPLEVBQUUsVUFBQSxDQUFDO3dCQUNaLG1FQUFtRTt3QkFDbkUsZ0JBQWdCO3dCQUNSLEVBQUUsQ0FBQyxLQUFNLENBQUMsZUFBZSxFQUFFLENBQUM7d0JBQ3BDLFlBQVksQ0FBQyxJQUFJLENBQ2IsbUJBQW1CLEVBQUUsRUFBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsUUFBUSxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFDLENBQUMsQ0FBQztvQkFDdkUsQ0FBQyxDQUFDLENBQUM7b0JBQ1AsSUFBSSxVQUFVLENBQUMsY0FBYyxLQUFLLE1BQUEsTUFBTSxDQUFDLGNBQWMsQ0FBQyxPQUFPO3dCQUMzRCxVQUFVLENBQUMsY0FBYyxLQUFLLE1BQUEsTUFBTSxDQUFDLGNBQWMsQ0FBQyxRQUFRLEVBQUU7d0JBQ2hFLFNBQVMsQ0FBQyxFQUFFLENBQ1IsYUFBYSxFQUFFLE1BQUEsV0FBVyxDQUFDLE9BQU8sQ0FDZixZQUFZLEVBQ1osTUFBQSxJQUFJLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUUsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDO3FCQUM3RTtnQkFDSCxDQUFDO2dCQUFBLENBQUM7Z0JBRUY7Ozs7Ozs7bUJBT0c7Z0JBQ0gsZ0JBQWdCLE1BQU0sRUFBRSxDQUF3QixFQUFFLENBQW9CLEVBQ2xFLFlBQVk7b0JBQ2QsSUFBSSxFQUFFLEdBQUcsTUFBQSxNQUFNLENBQUMsNEJBQTRCLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQ2hELCtEQUErRDtvQkFDL0Qsc0VBQXNFO29CQUN0RSw0RUFBNEU7b0JBQzVFLElBQUksQ0FBQyxDQUFDLGNBQWM7d0JBQ2hCLENBQUMsQ0FBQyxjQUFjLEtBQUssTUFBQSxNQUFNLENBQUMsY0FBYyxDQUFDLFFBQVEsRUFBRTt3QkFDdkQsTUFBQSxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUMsY0FBYyxFQUFFLFlBQVksRUFDakQsTUFBQSxLQUFLLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDO3FCQUMxQjtvQkFFRCxJQUFJLENBQUMsQ0FBQyxjQUFjLEtBQUssTUFBQSxNQUFNLENBQUMsY0FBYyxDQUFDLE9BQU8sRUFBRTt3QkFDdEQsa0VBQWtFO3dCQUNsRSxDQUFDLENBQUMsS0FBSyxJQUFJLEVBQUUsQ0FBQztxQkFDZjtvQkFFRCxpQkFBaUI7b0JBQ2pCLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxHQUFHLE1BQUEsS0FBSyxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxVQUFVLEVBQUU7eUJBQ3pELElBQUksQ0FBQyxHQUFHLEVBQUUsRUFBRSxHQUFHLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUM7eUJBQ3hFLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7b0JBRXpCLDhFQUE4RTtvQkFDOUUsOEVBQThFO29CQUM5RSw2RUFBNkU7b0JBQzdFLDZFQUE2RTtvQkFDN0UsY0FBYztvQkFDZCxNQUFNLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxDQUFDLFVBQVUsRUFBRTt5QkFDdEMsSUFBSSxDQUFDLEdBQUcsRUFBRSxFQUFFLEdBQUcsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7eUJBQ3hCLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDO29CQUU3QixxRUFBcUU7b0JBQ3JFLE1BQUEsZUFBZSxDQUNYLE1BQU0sQ0FBQyxNQUFNLENBQUMsR0FBRyxHQUFHLE1BQUEsS0FBSyxDQUFDLFVBQVUsQ0FBQyxJQUFJLEdBQUcsVUFBVSxDQUFDLEVBQUUsRUFBRSxHQUFHLENBQUMsQ0FBQyxFQUFFLEVBQ2xFLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDbkMsTUFBQSxZQUFZLENBQ1IsTUFBTSxDQUFDLE1BQU0sQ0FBQyxHQUFHLEdBQUcsTUFBQSxLQUFLLENBQUMsVUFBVSxDQUFDLElBQUksR0FBRyxPQUFPLENBQUMsRUFBRSxFQUFFLEdBQUcsQ0FBQyxDQUFDLEVBQUUsRUFDL0QsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxLQUFLLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUNuQyxNQUFBLFlBQVksQ0FDUixNQUFNLENBQUMsTUFBTSxDQUFDLEdBQUcsR0FBRyxNQUFBLEtBQUssQ0FBQyxVQUFVLENBQUMsSUFBSSxHQUFHLE1BQU0sQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUMsRUFBRSxFQUM5RCxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7b0JBRW5DLGdCQUFnQjtvQkFDaEIsTUFBTSxDQUFDLE1BQU0sQ0FBQyxPQUFPLEdBQUcsTUFBQSxLQUFLLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDLFVBQVUsRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsVUFBQSxDQUFDO3dCQUNyRSw2Q0FBNkM7d0JBQzdDLElBQUksTUFBTSxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLFVBQUEsQ0FBQyxJQUFNLE9BQU8sRUFBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsR0FBRyxFQUFFLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQzFFLE9BQU8sTUFBQSxJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUNsQyxDQUFDLENBQUMsQ0FBQztnQkFDTCxDQUFDO2dCQUFBLENBQUM7WUFFRixDQUFDLEVBN05xQixVQUFVLEdBQVYsZ0JBQVUsS0FBVixnQkFBVSxRQTZOL0I7UUFBRCxDQUFDLEVBN05lLEtBQUssR0FBTCxXQUFLLEtBQUwsV0FBSyxRQTZOcEI7SUFBRCxDQUFDLEVBN05TLEtBQUssR0FBTCxRQUFLLEtBQUwsUUFBSyxRQTZOZDtBQUFELENBQUMsRUE3Tk0sRUFBRSxLQUFGLEVBQUUsUUE2TlIsQ0FBQyxlQUFlIiwic291cmNlc0NvbnRlbnQiOlsiLyogQ29weXJpZ2h0IDIwMTUgVGhlIFRlbnNvckZsb3cgQXV0aG9ycy4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cblxuTGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlLCBWZXJzaW9uIDIuMCAodGhlICdMaWNlbnNlJyk7XG55b3UgbWF5IG5vdCB1c2UgdGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlIHdpdGggdGhlIExpY2Vuc2UuXG5Zb3UgbWF5IG9idGFpbiBhIGNvcHkgb2YgdGhlIExpY2Vuc2UgYXRcblxuICAgIGh0dHA6Ly93d3cuYXBhY2hlLm9yZy9saWNlbnNlcy9MSUNFTlNFLTIuMFxuXG5Vbmxlc3MgcmVxdWlyZWQgYnkgYXBwbGljYWJsZSBsYXcgb3IgYWdyZWVkIHRvIGluIHdyaXRpbmcsIHNvZnR3YXJlXG5kaXN0cmlidXRlZCB1bmRlciB0aGUgTGljZW5zZSBpcyBkaXN0cmlidXRlZCBvbiBhbiAnQVMgSVMnIEJBU0lTLFxuV0lUSE9VVCBXQVJSQU5USUVTIE9SIENPTkRJVElPTlMgT0YgQU5ZIEtJTkQsIGVpdGhlciBleHByZXNzIG9yIGltcGxpZWQuXG5TZWUgdGhlIExpY2Vuc2UgZm9yIHRoZSBzcGVjaWZpYyBsYW5ndWFnZSBnb3Zlcm5pbmcgcGVybWlzc2lvbnMgYW5kXG5saW1pdGF0aW9ucyB1bmRlciB0aGUgTGljZW5zZS5cbj09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSovXG5tb2R1bGUgdGYuZ3JhcGguc2NlbmUuYW5ub3RhdGlvbiB7XG4gIC8qKlxuICAgKiBQb3B1bGF0ZSBhIGdpdmVuIGFubm90YXRpb24gY29udGFpbmVyIGdyb3VwXG4gICAqXG4gICAqICAgICA8ZyBjbGFzcz0ne2lufG91dH0tYW5ub3RhdGlvbnMnPjwvZz5cbiAgICpcbiAgICogd2l0aCBhbm5vdGF0aW9uIGdyb3VwIG9mIHRoZSBmb2xsb3dpbmcgc3RydWN0dXJlOlxuICAgKlxuICAgKiA8ZyBjbGFzcz0nYW5ub3RhdGlvbic+XG4gICAqICAgPGcgY2xhc3M9J2Fubm90YXRpb24tbm9kZSc+XG4gICAqICAgPCEtLVxuICAgKiAgIENvbnRlbnQgaGVyZSBkZXRlcm1pbmVkIGJ5IFNjZW5lLm5vZGUuYnVpbGRHcm91cC5cbiAgICogICAtLT5cbiAgICogICA8L2c+XG4gICAqIDwvZz5cbiAgICpcbiAgICogQHBhcmFtIGNvbnRhaW5lciBzZWxlY3Rpb24gb2YgdGhlIGNvbnRhaW5lci5cbiAgICogQHBhcmFtIGFubm90YXRpb25EYXRhIG5vZGUue2lufG91dH1Bbm5vdGF0aW9uc1xuICAgKiBAcGFyYW0gZCBub2RlIHRvIGJ1aWxkIGdyb3VwIGZvci5cbiAgICogQHBhcmFtIHNjZW5lRWxlbWVudCA8dGYtZ3JhcGgtc2NlbmU+IHBvbHltZXIgZWxlbWVudC5cbiAgICogQHJldHVybiBzZWxlY3Rpb24gb2YgYXBwZW5kZWQgb2JqZWN0c1xuICAgKi9cbiAgZXhwb3J0IGZ1bmN0aW9uIGJ1aWxkR3JvdXAoXG4gICAgICBjb250YWluZXIsIGFubm90YXRpb25EYXRhOiByZW5kZXIuQW5ub3RhdGlvbkxpc3QsXG4gICAgICBkOiByZW5kZXIuUmVuZGVyTm9kZUluZm8sIHNjZW5lRWxlbWVudCkge1xuICAgIC8vIFNlbGVjdCBhbGwgY2hpbGRyZW4gYW5kIGpvaW4gd2l0aCBkYXRhLlxuICAgIGxldCBhbm5vdGF0aW9uR3JvdXBzID1cbiAgICAgICAgY29udGFpbmVyXG4gICAgICAgICAgICAuc2VsZWN0QWxsKGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgICAvLyB1c2luZyBkMydzIHNlbGVjdG9yIGZ1bmN0aW9uXG4gICAgICAgICAgICAgIC8vIFNlZSBodHRwczovL2dpdGh1Yi5jb20vbWJvc3RvY2svZDMvcmVsZWFzZXMvdGFnL3YyLjAuMFxuICAgICAgICAgICAgICAvLyAoSXQncyBub3QgbGlzdGVkIGluIHRoZSBkMyB3aWtpLilcbiAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuY2hpbGROb2RlcztcbiAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAuZGF0YShhbm5vdGF0aW9uRGF0YS5saXN0LCBkID0+IHsgcmV0dXJuIGQubm9kZS5uYW1lOyB9KTtcblxuICAgIGFubm90YXRpb25Hcm91cHMuZW50ZXIoKVxuICAgICAgICAuYXBwZW5kKCdnJylcbiAgICAgICAgLmF0dHIoJ2RhdGEtbmFtZScsIGEgPT4geyByZXR1cm4gYS5ub2RlLm5hbWU7IH0pXG4gICAgICAgIC5lYWNoKGZ1bmN0aW9uKGEpIHtcbiAgICAgICAgICBsZXQgYUdyb3VwID0gZDMuc2VsZWN0KHRoaXMpO1xuXG4gICAgICAgICAgLy8gQWRkIGFubm90YXRpb24gdG8gdGhlIGluZGV4IGluIHRoZSBzY2VuZVxuICAgICAgICAgIHNjZW5lRWxlbWVudC5hZGRBbm5vdGF0aW9uR3JvdXAoYSwgZCwgYUdyb3VwKTtcbiAgICAgICAgICAvLyBBcHBlbmQgYW5ub3RhdGlvbiBlZGdlXG4gICAgICAgICAgbGV0IGVkZ2VUeXBlID0gQ2xhc3MuQW5ub3RhdGlvbi5FREdFO1xuICAgICAgICAgIGxldCBtZXRhZWRnZSA9IGEucmVuZGVyTWV0YWVkZ2VJbmZvICYmIGEucmVuZGVyTWV0YWVkZ2VJbmZvLm1ldGFlZGdlO1xuICAgICAgICAgIGlmIChtZXRhZWRnZSAmJiAhbWV0YWVkZ2UubnVtUmVndWxhckVkZ2VzKSB7XG4gICAgICAgICAgICBlZGdlVHlwZSArPSAnICcgKyBDbGFzcy5Bbm5vdGF0aW9uLkNPTlRST0xfRURHRTtcbiAgICAgICAgICB9XG4gICAgICAgICAgLy8gSWYgYW55IGVkZ2VzIGFyZSByZWZlcmVuY2UgZWRnZXMsIGFkZCB0aGUgcmVmZXJlbmNlIGVkZ2UgY2xhc3MuXG4gICAgICAgICAgaWYgKG1ldGFlZGdlICYmIG1ldGFlZGdlLm51bVJlZkVkZ2VzKSB7XG4gICAgICAgICAgICBlZGdlVHlwZSArPSAnICcgKyBDbGFzcy5FZGdlLlJFRl9MSU5FO1xuICAgICAgICAgIH1cbiAgICAgICAgICBlZGdlLmFwcGVuZEVkZ2UoYUdyb3VwLCBhLCBzY2VuZUVsZW1lbnQsIGVkZ2VUeXBlKTtcblxuICAgICAgICAgIGlmIChhLmFubm90YXRpb25UeXBlICE9PSByZW5kZXIuQW5ub3RhdGlvblR5cGUuRUxMSVBTSVMpIHtcbiAgICAgICAgICAgIGFkZEFubm90YXRpb25MYWJlbEZyb21Ob2RlKGFHcm91cCwgYSk7XG4gICAgICAgICAgICBidWlsZFNoYXBlKGFHcm91cCwgYSk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGFkZEFubm90YXRpb25MYWJlbChcbiAgICAgICAgICAgICAgICBhR3JvdXAsIGEubm9kZS5uYW1lLCBhLCBDbGFzcy5Bbm5vdGF0aW9uLkVMTElQU0lTKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0pLm1lcmdlKGFubm90YXRpb25Hcm91cHMpXG4gICAgICAgIC5hdHRyKFxuICAgICAgICAgICAgJ2NsYXNzJyxcbiAgICAgICAgICAgIGEgPT4ge1xuICAgICAgICAgICAgICByZXR1cm4gQ2xhc3MuQW5ub3RhdGlvbi5HUk9VUCArICcgJyArXG4gICAgICAgICAgICAgICAgICBhbm5vdGF0aW9uVG9DbGFzc05hbWUoYS5hbm5vdGF0aW9uVHlwZSkgKyAnICcgK1xuICAgICAgICAgICAgICAgICAgbm9kZS5ub2RlQ2xhc3MoYSk7XG4gICAgICAgICAgICB9KVxuICAgICAgICAuZWFjaChmdW5jdGlvbihhKSB7XG4gICAgICAgICAgbGV0IGFHcm91cCA9IGQzLnNlbGVjdCh0aGlzKTtcbiAgICAgICAgICB1cGRhdGUoYUdyb3VwLCBkLCBhLCBzY2VuZUVsZW1lbnQpO1xuICAgICAgICAgIGlmIChhLmFubm90YXRpb25UeXBlICE9PSByZW5kZXIuQW5ub3RhdGlvblR5cGUuRUxMSVBTSVMpIHtcbiAgICAgICAgICAgIGFkZEludGVyYWN0aW9uKGFHcm91cCwgZCwgYSwgc2NlbmVFbGVtZW50KTtcbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuXG4gICAgYW5ub3RhdGlvbkdyb3Vwcy5leGl0KClcbiAgICAgICAgLmVhY2goZnVuY3Rpb24oYSkge1xuICAgICAgICAgIGxldCBhR3JvdXAgPSBkMy5zZWxlY3QodGhpcyk7XG5cbiAgICAgICAgICAvLyBSZW1vdmUgYW5ub3RhdGlvbiBmcm9tIHRoZSBpbmRleCBpbiB0aGUgc2NlbmVcbiAgICAgICAgICBzY2VuZUVsZW1lbnQucmVtb3ZlQW5ub3RhdGlvbkdyb3VwKGEsIGQsIGFHcm91cCk7XG4gICAgICAgIH0pXG4gICAgICAgIC5yZW1vdmUoKTtcbiAgICByZXR1cm4gYW5ub3RhdGlvbkdyb3Vwcztcbn07XG5cbi8qKlxuICogTWFwcyBhbiBhbm5vdGF0aW9uIGVudW0gdG8gYSBjbGFzcyBuYW1lIHVzZWQgaW4gY3NzIHJ1bGVzLlxuICovXG5mdW5jdGlvbiBhbm5vdGF0aW9uVG9DbGFzc05hbWUoYW5ub3RhdGlvblR5cGU6IHJlbmRlci5Bbm5vdGF0aW9uVHlwZSkge1xuICByZXR1cm4gKHJlbmRlci5Bbm5vdGF0aW9uVHlwZVthbm5vdGF0aW9uVHlwZV0gfHwgJycpLnRvTG93ZXJDYXNlKCkgfHwgbnVsbDtcbn1cblxuZnVuY3Rpb24gYnVpbGRTaGFwZShhR3JvdXAsIGE6IHJlbmRlci5Bbm5vdGF0aW9uKSB7XG4gIGlmIChhLmFubm90YXRpb25UeXBlID09PSByZW5kZXIuQW5ub3RhdGlvblR5cGUuU1VNTUFSWSkge1xuICAgIGxldCBzdW1tYXJ5ID0gc2VsZWN0T3JDcmVhdGVDaGlsZChhR3JvdXAsICd1c2UnKTtcbiAgICBzdW1tYXJ5XG4gICAgICAuYXR0cignY2xhc3MnLCAnc3VtbWFyeScpXG4gICAgICAuYXR0cigneGxpbms6aHJlZicsICcjc3VtbWFyeS1pY29uJylcbiAgICAgIC5hdHRyKCdjdXJzb3InLCAncG9pbnRlcicpO1xuICB9IGVsc2Uge1xuICAgIGxldCBzaGFwZSA9IG5vZGUuYnVpbGRTaGFwZShhR3JvdXAsIGEsIENsYXNzLkFubm90YXRpb24uTk9ERSk7XG4gICAgLy8gYWRkIHRpdGxlIHRhZyB0byBnZXQgbmF0aXZlIHRvb2x0aXBzXG4gICAgc2VsZWN0T3JDcmVhdGVDaGlsZChzaGFwZSwgJ3RpdGxlJykudGV4dChhLm5vZGUubmFtZSk7XG4gIH1cbn1cblxuZnVuY3Rpb24gYWRkQW5ub3RhdGlvbkxhYmVsRnJvbU5vZGUoYUdyb3VwLCBhOiByZW5kZXIuQW5ub3RhdGlvbikge1xuICBsZXQgbmFtZVBhdGggPSBhLm5vZGUubmFtZS5zcGxpdCgnLycpO1xuICBsZXQgdGV4dCA9IG5hbWVQYXRoW25hbWVQYXRoLmxlbmd0aCAtIDFdO1xuICByZXR1cm4gYWRkQW5ub3RhdGlvbkxhYmVsKGFHcm91cCwgdGV4dCwgYSwgbnVsbCk7XG59XG5cbmZ1bmN0aW9uIGFkZEFubm90YXRpb25MYWJlbChcbiAgICBhR3JvdXAsIGxhYmVsOiBzdHJpbmcsIGE6IHJlbmRlci5Bbm5vdGF0aW9uLCBhZGRpdGlvbmFsQ2xhc3NOYW1lcykge1xuICBsZXQgY2xhc3NOYW1lcyA9IENsYXNzLkFubm90YXRpb24uTEFCRUw7XG4gIGlmIChhZGRpdGlvbmFsQ2xhc3NOYW1lcykge1xuICAgIGNsYXNzTmFtZXMgKz0gJyAnICsgYWRkaXRpb25hbENsYXNzTmFtZXM7XG4gIH1cbiAgbGV0IHR4dEVsZW1lbnQgPSBhR3JvdXAuYXBwZW5kKCd0ZXh0JylcbiAgICAgICAgICAgICAgICAgICAgICAgLmF0dHIoJ2NsYXNzJywgY2xhc3NOYW1lcylcbiAgICAgICAgICAgICAgICAgICAgICAgLmF0dHIoJ2R5JywgJy4zNWVtJylcbiAgICAgICAgICAgICAgICAgICAgICAgLmF0dHIoJ3RleHQtYW5jaG9yJywgYS5pc0luID8gJ2VuZCcgOiAnc3RhcnQnKVxuICAgICAgICAgICAgICAgICAgICAgICAudGV4dChsYWJlbCk7XG5cbiAgcmV0dXJuIHRmLmdyYXBoLnNjZW5lLm5vZGUuZW5mb3JjZUxhYmVsV2lkdGgodHh0RWxlbWVudCwgLTEpO1xufVxuXG5mdW5jdGlvbiBhZGRJbnRlcmFjdGlvbihzZWxlY3Rpb24sIGQ6IHJlbmRlci5SZW5kZXJOb2RlSW5mbyxcbiAgICBhbm5vdGF0aW9uOiByZW5kZXIuQW5ub3RhdGlvbiwgc2NlbmVFbGVtZW50KSB7XG4gIHNlbGVjdGlvblxuICAgICAgLm9uKCdtb3VzZW92ZXInLFxuICAgICAgICAgIGEgPT4ge1xuICAgICAgICAgICAgc2NlbmVFbGVtZW50LmZpcmUoXG4gICAgICAgICAgICAgICAgJ2Fubm90YXRpb24taGlnaGxpZ2h0JyxcbiAgICAgICAgICAgICAgICB7bmFtZTogYS5ub2RlLm5hbWUsIGhvc3ROYW1lOiBkLm5vZGUubmFtZX0pO1xuICAgICAgICAgIH0pXG4gICAgICAub24oJ21vdXNlb3V0JyxcbiAgICAgICAgICBhID0+IHtcbiAgICAgICAgICAgIHNjZW5lRWxlbWVudC5maXJlKFxuICAgICAgICAgICAgICAgICdhbm5vdGF0aW9uLXVuaGlnaGxpZ2h0JyxcbiAgICAgICAgICAgICAgICB7bmFtZTogYS5ub2RlLm5hbWUsIGhvc3ROYW1lOiBkLm5vZGUubmFtZX0pO1xuICAgICAgICAgIH0pXG4gICAgICAub24oJ2NsaWNrJywgYSA9PiB7XG4gICAgICAgIC8vIFN0b3AgdGhpcyBldmVudCdzIHByb3BhZ2F0aW9uIHNvIHRoYXQgaXQgaXNuJ3QgYWxzbyBjb25zaWRlcmVkIGFcbiAgICAgICAgLy8gZ3JhcGgtc2VsZWN0LlxuICAgICAgICAoPEV2ZW50PmQzLmV2ZW50KS5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICAgICAgc2NlbmVFbGVtZW50LmZpcmUoXG4gICAgICAgICAgICAnYW5ub3RhdGlvbi1zZWxlY3QnLCB7bmFtZTogYS5ub2RlLm5hbWUsIGhvc3ROYW1lOiBkLm5vZGUubmFtZX0pO1xuICAgICAgfSk7XG4gIGlmIChhbm5vdGF0aW9uLmFubm90YXRpb25UeXBlICE9PSByZW5kZXIuQW5ub3RhdGlvblR5cGUuU1VNTUFSWSAmJlxuICAgICAgYW5ub3RhdGlvbi5hbm5vdGF0aW9uVHlwZSAhPT0gcmVuZGVyLkFubm90YXRpb25UeXBlLkNPTlNUQU5UKSB7XG4gICAgc2VsZWN0aW9uLm9uKFxuICAgICAgICAnY29udGV4dG1lbnUnLCBjb250ZXh0bWVudS5nZXRNZW51KFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgc2NlbmVFbGVtZW50LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgbm9kZS5nZXRDb250ZXh0TWVudShhbm5vdGF0aW9uLm5vZGUsIHNjZW5lRWxlbWVudCkpKTtcbiAgfVxufTtcblxuLyoqXG4gKiBBZGp1c3QgYW5ub3RhdGlvbidzIHBvc2l0aW9uLlxuICpcbiAqIEBwYXJhbSBhR3JvdXAgc2VsZWN0aW9uIG9mIGEgJ2cuYW5ub3RhdGlvbicgZWxlbWVudC5cbiAqIEBwYXJhbSBkIEhvc3Qgbm9kZSBkYXRhLlxuICogQHBhcmFtIGEgYW5ub3RhdGlvbiBub2RlIGRhdGEuXG4gKiBAcGFyYW0gc2NlbmVFbGVtZW50IDx0Zi1ncmFwaC1zY2VuZT4gcG9seW1lciBlbGVtZW50LlxuICovXG5mdW5jdGlvbiB1cGRhdGUoYUdyb3VwLCBkOiByZW5kZXIuUmVuZGVyTm9kZUluZm8sIGE6IHJlbmRlci5Bbm5vdGF0aW9uLFxuICAgIHNjZW5lRWxlbWVudCkge1xuICBsZXQgY3ggPSBsYXlvdXQuY29tcHV0ZUNYUG9zaXRpb25PZk5vZGVTaGFwZShkKTtcbiAgLy8gQW5ub3RhdGlvbnMgdGhhdCBwb2ludCB0byBlbWJlZGRlZCBub2RlcyAoY29uc3RhbnRzLHN1bW1hcnkpXG4gIC8vIGRvbid0IGhhdmUgYSByZW5kZXIgaW5mb3JtYXRpb24gYXR0YWNoZWQgc28gd2UgZG9uJ3Qgc3R5bGl6ZSB0aGVzZS5cbiAgLy8gQWxzbyB3ZSBkb24ndCBzdHlsaXplIGVsbGlwc2lzIGFubm90YXRpb25zICh0aGUgc3RyaW5nICcuLi4gYW5kIFggbW9yZScpLlxuICBpZiAoYS5yZW5kZXJOb2RlSW5mbyAmJlxuICAgICAgYS5hbm5vdGF0aW9uVHlwZSAhPT0gcmVuZGVyLkFubm90YXRpb25UeXBlLkVMTElQU0lTKSB7XG4gICAgbm9kZS5zdHlsaXplKGFHcm91cCwgYS5yZW5kZXJOb2RlSW5mbywgc2NlbmVFbGVtZW50LFxuICAgICAgQ2xhc3MuQW5ub3RhdGlvbi5OT0RFKTtcbiAgfVxuXG4gIGlmIChhLmFubm90YXRpb25UeXBlID09PSByZW5kZXIuQW5ub3RhdGlvblR5cGUuU1VNTUFSWSkge1xuICAgIC8vIFVwZGF0ZSB0aGUgd2lkdGggb2YgdGhlIGFubm90YXRpb24gdG8gZ2l2ZSBzcGFjZSBmb3IgdGhlIGltYWdlLlxuICAgIGEud2lkdGggKz0gMTA7XG4gIH1cblxuICAvLyBsYWJlbCBwb3NpdGlvblxuICBhR3JvdXAuc2VsZWN0KCd0ZXh0LicgKyBDbGFzcy5Bbm5vdGF0aW9uLkxBQkVMKS50cmFuc2l0aW9uKClcbiAgICAuYXR0cigneCcsIGN4ICsgYS5keCArIChhLmlzSW4gPyAtMSA6IDEpICogKGEud2lkdGggLyAyICsgYS5sYWJlbE9mZnNldCkpXG4gICAgLmF0dHIoJ3knLCBkLnkgKyBhLmR5KTtcblxuICAvLyBTb21lIGFubm90YXRpb25zIChzdWNoIGFzIHN1bW1hcnkpIGFyZSByZXByZXNlbnRlZCB1c2luZyBhIDEyeDEyIGltYWdlIHRhZy5cbiAgLy8gUHVycG9zZWx5IG9taXR0ZWQgdW5pdHMgKGUuZy4gcGl4ZWxzKSBzaW5jZSB0aGUgaW1hZ2VzIGFyZSB2ZWN0b3IgZ3JhcGhpY3MuXG4gIC8vIElmIHRoZXJlIGlzIGFuIGltYWdlLCB3ZSBhZGp1c3QgdGhlIGxvY2F0aW9uIG9mIHRoZSBpbWFnZSB0byBiZSB2ZXJ0aWNhbGx5XG4gIC8vIGNlbnRlcmVkIHdpdGggdGhlIG5vZGUgYW5kIGhvcml6b250YWxseSBjZW50ZXJlZCBiZXR3ZWVuIHRoZSBhcnJvdyBhbmQgdGhlXG4gIC8vIHRleHQgbGFiZWwuXG4gIGFHcm91cC5zZWxlY3QoJ3VzZS5zdW1tYXJ5JykudHJhbnNpdGlvbigpXG4gICAgLmF0dHIoJ3gnLCBjeCArIGEuZHggLSAzKVxuICAgIC5hdHRyKCd5JywgZC55ICsgYS5keSAtIDYpO1xuXG4gIC8vIE5vZGUgcG9zaXRpb24gKG9ubHkgb25lIG9mIHRoZSBzaGFwZSBzZWxlY3Rpb24gd2lsbCBiZSBub24tZW1wdHkuKVxuICBwb3NpdGlvbkVsbGlwc2UoXG4gICAgICBhR3JvdXAuc2VsZWN0KCcuJyArIENsYXNzLkFubm90YXRpb24uTk9ERSArICcgZWxsaXBzZScpLCBjeCArIGEuZHgsXG4gICAgICBkLnkgKyBhLmR5LCBhLndpZHRoLCBhLmhlaWdodCk7XG4gIHBvc2l0aW9uUmVjdChcbiAgICAgIGFHcm91cC5zZWxlY3QoJy4nICsgQ2xhc3MuQW5ub3RhdGlvbi5OT0RFICsgJyByZWN0JyksIGN4ICsgYS5keCxcbiAgICAgIGQueSArIGEuZHksIGEud2lkdGgsIGEuaGVpZ2h0KTtcbiAgcG9zaXRpb25SZWN0KFxuICAgICAgYUdyb3VwLnNlbGVjdCgnLicgKyBDbGFzcy5Bbm5vdGF0aW9uLk5PREUgKyAnIHVzZScpLCBjeCArIGEuZHgsXG4gICAgICBkLnkgKyBhLmR5LCBhLndpZHRoLCBhLmhlaWdodCk7XG5cbiAgLy8gRWRnZSBwb3NpdGlvblxuICBhR3JvdXAuc2VsZWN0KCdwYXRoLicgKyBDbGFzcy5Bbm5vdGF0aW9uLkVER0UpLnRyYW5zaXRpb24oKS5hdHRyKCdkJywgYSA9PiB7XG4gICAgLy8gbWFwIHJlbGF0aXZlIHBvc2l0aW9uIHRvIGFic29sdXRlIHBvc2l0aW9uXG4gICAgbGV0IHBvaW50cyA9IGEucG9pbnRzLm1hcChwID0+IHsgcmV0dXJuIHt4OiBwLmR4ICsgY3gsIHk6IHAuZHkgKyBkLnl9OyB9KTtcbiAgICByZXR1cm4gZWRnZS5pbnRlcnBvbGF0ZShwb2ludHMpO1xuICB9KTtcbn07XG5cbn0gLy8gY2xvc2UgbW9kdWxlXG4iXX0=