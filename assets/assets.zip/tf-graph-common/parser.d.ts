declare module tf.graph.parser {
    /**
     * Fetches a text file and returns a promise of the result.
     */
    function fetchPbTxt(filepath: string): Promise<ArrayBuffer>;
    /**
     * Fetches the metadata file, parses it and returns a promise of the result.
     */
    function fetchAndParseMetadata(path: string, tracker: ProgressTracker): Promise<any>;
    /**
     * Fetches the graph file, parses it and returns a promise of the result. The
     * result will be undefined if the graph is empty.
     */
    function fetchAndParseGraphData(path: string, pbTxtFile: Blob, tracker: ProgressTracker): Promise<proto.GraphDef>;
    /**
     * Parse a file object in a streaming fashion line by line (or custom delim).
     * Can handle very large files.
     * @param input The file object as an array buffer.
     * @param callback The callback called on each line
     * @param chunkSize The size of each read chunk. (optional)
     * @param delim The delimiter used to split a line. (optional)
     * @returns A promise for when it is finished.
     */
    function streamParse(arrayBuffer: ArrayBuffer, callback: (string: any) => void, chunkSize?: number, delim?: string): Promise<boolean>;
    /**
     * Parses an ArrayBuffer of a proto txt file into a raw Graph object.
     */
    function parseGraphPbTxt(input: ArrayBuffer): Promise<tf.graph.proto.GraphDef>;
    /**
     * Parses an ArrayBuffer of a proto txt file into a StepStats object.
     */
    function parseStatsPbTxt(input: ArrayBuffer): Promise<tf.graph.proto.StepStats>;
}
