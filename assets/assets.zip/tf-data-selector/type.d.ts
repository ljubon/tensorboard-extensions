declare namespace tf_data_selector {
    enum Type {
        WITHOUT_EXPERIMENT = 0,
        SINGLE = 1,
        COMPARISON = 2
    }
    type Selection = {
        experiment?: tf_backend.Experiment;
        runs: Array<tf_backend.Run>;
        tagRegex: string;
    };
    type DataSelection = {
        type: Type;
        selections: Array<Selection>;
    };
}
