declare namespace tf_backend {
    type Listener = () => void;
    class ListenKey {
        readonly listener: Listener;
        constructor(listener: Listener);
    }
    abstract class BaseStore {
        protected requestManager: RequestManager;
        private _listeners;
        initialized: boolean;
        /**
         * Asynchronously load or reload the runs data. Listeners will be
         * invoked if this causes the runs data to change.
         *
         * @see addListener
         * @return {Promise<void>} a promise that resolves when new data have loaded.
         */
        protected abstract load(): Promise<void>;
        refresh(): Promise<void>;
        /**
         * Register a listener (nullary function) to be called when new runs are
         * available.
         */
        addListener(listener: Listener): ListenKey;
        /**
         * Remove a listener registered with `addListener`.
         */
        removeListenerByKey(listenKey: ListenKey): void;
        protected emitChange(): void;
    }
}
