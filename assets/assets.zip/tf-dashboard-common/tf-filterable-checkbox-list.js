/* Copyright 2018 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the 'License');
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an 'AS IS' BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
var tf_dashboard_common;
(function (tf_dashboard_common) {
    Polymer({
        is: 'tf-filterable-checkbox-list',
        properties: {
            label: { type: String },
            useCheckboxColors: {
                type: Boolean,
                value: true,
            },
            coloring: {
                type: Object,
                value: {
                    getColor: function (item) { return ''; },
                },
            },
            // `items` are Array of {id: string, title: string, subtitle: ?string}.
            items: {
                type: Array,
                value: function () { return []; },
                observer: '_pruneSelectionState',
            },
            _regexString: {
                type: String,
                value: '',
            },
            _regex: { type: Object, computed: '_makeRegex(_regexString)' },
            _itemsMatchingRegex: {
                type: Array,
                computed: 'computeItemsMatchingRegex(items.*, _regex)'
            },
            selectionState: {
                // if an item is explicitly enabled, True, if explicitly disabled, False.
                // if undefined, default value (enable for first k items, disable after).
                type: Object,
                value: function () { return ({}); },
            },
            selectedItems: {
                type: Array,
                notify: true,
                computed: '_computeSelectedItems(_itemsMatchingRegex.*, selectionState.*)',
            },
            maxItemsToEnableByDefault: {
                // When TB first loads, if it has k or fewer items, they are all enabled
                // by default. If there are more, then all items are disabled.
                type: Number,
                value: 40,
            },
            allToggleDisabled: {
                type: Boolean,
                value: false,
            },
        },
        listeners: {
            'dom-change': '_synchronizeColors',
        },
        observers: [
            '_synchronizeColors(useCheckboxColors)',
            '_synchronizeColors(coloring)',
        ],
        detached: function () {
            this.cancelDebouncer('_setRegex');
        },
        // ====================== COMPUTED ======================
        _makeRegex: function (regexString) {
            try {
                return new RegExp(regexString);
            }
            catch (e) {
                return null;
            }
        },
        computeItemsMatchingRegex: function (__, ___) {
            var regex = this._regex;
            return regex ? this.items.filter(function (n) { return regex.test(n.title); }) : this.items;
        },
        _computeSelectedItems: function (__, ___) {
            var selectionState = this.selectionState;
            var num = this.maxItemsToEnableByDefault;
            var allEnabled = this._itemsMatchingRegex.length <= num;
            return this._itemsMatchingRegex
                .filter(function (n) {
                return selectionState[n.id] == null ?
                    allEnabled : selectionState[n.id];
            });
        },
        _isChecked: function (item, _) {
            return this.selectedItems.indexOf(item) != -1;
        },
        // ================== EVENT LISTENERS ===================
        _debouncedRegexChange: function () {
            var _this = this;
            var val = this.$.input.value;
            if (val == '') {
                // If the user cleared the field, they may be done typing, so
                // update more quickly.
                window.requestAnimationFrame(function () {
                    _this._regexString = val;
                });
            }
            else {
                this.debounce('_setRegex', function () {
                    _this._regexString = val;
                }, 150);
            }
            ;
        },
        _synchronizeColors: function (e) {
            var _this = this;
            var checkboxes = this.querySelectorAll('paper-checkbox');
            checkboxes.forEach(function (cb) {
                // Setting the null value will clear previously set color.
                var color = _this.useCheckboxColors ?
                    _this.coloring.getColor(cb.name) :
                    null;
                cb.customStyle['--paper-checkbox-checked-color'] = color;
                cb.customStyle['--paper-checkbox-checked-ink-color'] = color;
                cb.customStyle['--paper-checkbox-unchecked-color'] = color;
                cb.customStyle['--paper-checkbox-unchecked-ink-color'] = color;
            });
            // The updateStyles call fails silently if the browser does not have focus,
            // e.g., if TensorBoard was opened into a new tab that is not visible.
            // So we wait for requestAnimationFrame.
            window.requestAnimationFrame(function () { return _this.updateStyles(); });
        },
        _checkboxTapped: function (e) {
            var _a;
            var checkbox = e.currentTarget;
            var newSelectedNames = Object.assign({}, this.selectionState, (_a = {},
                _a[checkbox.name.id] = checkbox.checked,
                _a));
            // If user presses alt while toggling checkbox, it deselects all items but
            // the clicked one.
            if (e.detail.sourceEvent instanceof MouseEvent &&
                e.detail.sourceEvent.altKey) {
                Object.keys(newSelectedNames).forEach(function (key) {
                    newSelectedNames[key] = key == checkbox.name.id;
                });
            }
            // n.b. notifyPath won't work because names may have periods.
            this.selectionState = newSelectedNames;
        },
        _toggleAll: function () {
            var _this = this;
            var anyToggledOn = this._itemsMatchingRegex
                .some(function (n) { return _this.selectionState[n.id]; });
            var selectionStateIsDefault = Object.keys(this.selectionState).length == 0;
            var defaultOff = this._itemsMatchingRegex.length > this.maxItemsToEnableByDefault;
            // We have names toggled either if some were explicitly toggled on, or if
            // we are in the default state, and there are few enough that we default
            // to toggling on.
            anyToggledOn = anyToggledOn || selectionStateIsDefault && !defaultOff;
            // If any are toggled on, we turn everything off. Or, if none are toggled
            // on, we turn everything on.
            var newSelection = {};
            this.items.forEach(function (n) {
                newSelection[n.id] = !anyToggledOn;
            });
            this.selectionState = newSelection;
        },
        /**
         * Remove selection state of an item that no longer exists in the `items`.
         */
        _pruneSelectionState: function () {
            // Object key turns numbered keys into string.
            var itemIds = new Set(this.items.map(function (_a) {
                var id = _a.id;
                return String(id);
            }));
            var newSelection = Object.assign({}, this.selectionState);
            Object.keys(newSelection).forEach(function (key) {
                if (!itemIds.has(key))
                    delete newSelection[key];
            });
            this.selectionState = newSelection;
        },
    });
})(tf_dashboard_common || (tf_dashboard_common = {})); // namespace tf_dashboard_common
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGYtZmlsdGVyYWJsZS1jaGVja2JveC1saXN0LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsidGYtZmlsdGVyYWJsZS1jaGVja2JveC1saXN0LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7Ozs7Ozs7Ozs7O2dGQWFnRjtBQUNoRixJQUFVLG1CQUFtQixDQWdONUI7QUFoTkQsV0FBVSxtQkFBbUI7SUFRN0IsT0FBTyxDQUFDO1FBQ04sRUFBRSxFQUFFLDZCQUE2QjtRQUNqQyxVQUFVLEVBQUU7WUFDVixLQUFLLEVBQUUsRUFBQyxJQUFJLEVBQUUsTUFBTSxFQUFDO1lBRXJCLGlCQUFpQixFQUFFO2dCQUNqQixJQUFJLEVBQUUsT0FBTztnQkFDYixLQUFLLEVBQUUsSUFBSTthQUNaO1lBRUQsUUFBUSxFQUFFO2dCQUNSLElBQUksRUFBRSxNQUFNO2dCQUNaLEtBQUssRUFBRTtvQkFDTCxRQUFRLEVBQUUsVUFBQyxJQUFnQyxJQUFhLE9BQUEsRUFBRSxFQUFGLENBQUU7aUJBQzNEO2FBQ0Y7WUFFRCx1RUFBdUU7WUFDdkUsS0FBSyxFQUFFO2dCQUNMLElBQUksRUFBRSxLQUFLO2dCQUNYLEtBQUssRUFBRSxjQUF5QyxPQUFBLEVBQUUsRUFBRixDQUFFO2dCQUNsRCxRQUFRLEVBQUUsc0JBQXNCO2FBQ2pDO1lBRUQsWUFBWSxFQUFFO2dCQUNaLElBQUksRUFBRSxNQUFNO2dCQUNaLEtBQUssRUFBRSxFQUFFO2FBQ1Y7WUFFRCxNQUFNLEVBQUUsRUFBQyxJQUFJLEVBQUUsTUFBTSxFQUFFLFFBQVEsRUFBRSwwQkFBMEIsRUFBQztZQUU1RCxtQkFBbUIsRUFBRTtnQkFDbkIsSUFBSSxFQUFFLEtBQUs7Z0JBQ1gsUUFBUSxFQUFFLDRDQUE0QzthQUN2RDtZQUVELGNBQWMsRUFBRTtnQkFDZCx5RUFBeUU7Z0JBQ3pFLHlFQUF5RTtnQkFDekUsSUFBSSxFQUFFLE1BQU07Z0JBQ1osS0FBSyxFQUFFLGNBQU0sT0FBQSxDQUFDLEVBQUUsQ0FBQyxFQUFKLENBQUk7YUFDbEI7WUFFRCxhQUFhLEVBQUU7Z0JBQ2IsSUFBSSxFQUFFLEtBQUs7Z0JBQ1gsTUFBTSxFQUFFLElBQUk7Z0JBQ1osUUFBUSxFQUNKLGdFQUFnRTthQUNyRTtZQUVELHlCQUF5QixFQUFFO2dCQUN6Qix3RUFBd0U7Z0JBQ3hFLDhEQUE4RDtnQkFDOUQsSUFBSSxFQUFFLE1BQU07Z0JBQ1osS0FBSyxFQUFFLEVBQUU7YUFDVjtZQUVELGlCQUFpQixFQUFFO2dCQUNqQixJQUFJLEVBQUUsT0FBTztnQkFDYixLQUFLLEVBQUUsS0FBSzthQUNiO1NBQ0Y7UUFFRCxTQUFTLEVBQUU7WUFDVCxZQUFZLEVBQUUsb0JBQW9CO1NBQ25DO1FBRUQsU0FBUyxFQUFFO1lBQ1QsdUNBQXVDO1lBQ3ZDLDhCQUE4QjtTQUMvQjtRQUVELFFBQVE7WUFDTixJQUFJLENBQUMsZUFBZSxDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBQ3BDLENBQUM7UUFFRCx5REFBeUQ7UUFFekQsVUFBVSxZQUFDLFdBQVc7WUFDcEIsSUFBSTtnQkFDRixPQUFPLElBQUksTUFBTSxDQUFDLFdBQVcsQ0FBQyxDQUFDO2FBQ2hDO1lBQUMsT0FBTyxDQUFDLEVBQUU7Z0JBQ1YsT0FBTyxJQUFJLENBQUM7YUFDYjtRQUNILENBQUM7UUFFRCx5QkFBeUIsWUFBQyxFQUFFLEVBQUUsR0FBRztZQUMvQixJQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDO1lBQzFCLE9BQU8sS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxVQUFBLENBQUMsSUFBSSxPQUFBLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxFQUFuQixDQUFtQixDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUM7UUFDMUUsQ0FBQztRQUVELHFCQUFxQixZQUFDLEVBQUUsRUFBRSxHQUFHO1lBQzNCLElBQU0sY0FBYyxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUM7WUFDM0MsSUFBTSxHQUFHLEdBQUcsSUFBSSxDQUFDLHlCQUF5QixDQUFDO1lBQzNDLElBQU0sVUFBVSxHQUFHLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxNQUFNLElBQUksR0FBRyxDQUFDO1lBQzFELE9BQU8sSUFBSSxDQUFDLG1CQUFtQjtpQkFDMUIsTUFBTSxDQUFDLFVBQUEsQ0FBQztnQkFDUCxPQUFPLGNBQWMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLElBQUksSUFBSSxDQUFDLENBQUM7b0JBQ2pDLFVBQVUsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQztZQUN4QyxDQUFDLENBQUMsQ0FBQztRQUNULENBQUM7UUFFRCxVQUFVLFlBQUMsSUFBSSxFQUFFLENBQUM7WUFDaEIsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztRQUNoRCxDQUFDO1FBR0QseURBQXlEO1FBRXpELHFCQUFxQjtZQUFyQixpQkFhQztZQVpDLElBQU0sR0FBRyxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQztZQUMvQixJQUFJLEdBQUcsSUFBSSxFQUFFLEVBQUU7Z0JBQ2IsNkRBQTZEO2dCQUM3RCx1QkFBdUI7Z0JBQ3ZCLE1BQU0sQ0FBQyxxQkFBcUIsQ0FBQztvQkFDM0IsS0FBSSxDQUFDLFlBQVksR0FBRyxHQUFHLENBQUM7Z0JBQzFCLENBQUMsQ0FBQyxDQUFDO2FBQ0o7aUJBQU07Z0JBQ0wsSUFBSSxDQUFDLFFBQVEsQ0FBQyxXQUFXLEVBQUU7b0JBQ3pCLEtBQUksQ0FBQyxZQUFZLEdBQUcsR0FBRyxDQUFDO2dCQUMxQixDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7YUFDVDtZQUFBLENBQUM7UUFDSixDQUFDO1FBRUQsa0JBQWtCLFlBQUMsQ0FBQztZQUFwQixpQkFrQkM7WUFqQkMsSUFBTSxVQUFVLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixDQUFDLENBQUM7WUFFM0QsVUFBVSxDQUFDLE9BQU8sQ0FBQyxVQUFBLEVBQUU7Z0JBQ25CLDBEQUEwRDtnQkFDMUQsSUFBTSxLQUFLLEdBQUcsS0FBSSxDQUFDLGlCQUFpQixDQUFDLENBQUM7b0JBQ2xDLEtBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO29CQUNqQyxJQUFJLENBQUM7Z0JBQ1QsRUFBRSxDQUFDLFdBQVcsQ0FBQyxnQ0FBZ0MsQ0FBQyxHQUFHLEtBQUssQ0FBQztnQkFDekQsRUFBRSxDQUFDLFdBQVcsQ0FBQyxvQ0FBb0MsQ0FBQyxHQUFHLEtBQUssQ0FBQztnQkFDN0QsRUFBRSxDQUFDLFdBQVcsQ0FBQyxrQ0FBa0MsQ0FBQyxHQUFHLEtBQUssQ0FBQztnQkFDM0QsRUFBRSxDQUFDLFdBQVcsQ0FBQyxzQ0FBc0MsQ0FBQyxHQUFHLEtBQUssQ0FBQztZQUNqRSxDQUFDLENBQUMsQ0FBQztZQUVILDJFQUEyRTtZQUMzRSxzRUFBc0U7WUFDdEUsd0NBQXdDO1lBQ3hDLE1BQU0sQ0FBQyxxQkFBcUIsQ0FBQyxjQUFNLE9BQUEsS0FBSSxDQUFDLFlBQVksRUFBRSxFQUFuQixDQUFtQixDQUFDLENBQUM7UUFDMUQsQ0FBQztRQUVELGVBQWUsWUFBQyxDQUFDOztZQUNmLElBQU0sUUFBUSxHQUFHLENBQUMsQ0FBQyxhQUFhLENBQUM7WUFDakMsSUFBTSxnQkFBZ0IsR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxJQUFJLENBQUMsY0FBYztnQkFDNUQsR0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEVBQUUsSUFBRyxRQUFRLENBQUMsT0FBTztvQkFDcEMsQ0FBQztZQUVILDBFQUEwRTtZQUMxRSxtQkFBbUI7WUFDbkIsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDLFdBQVcsWUFBWSxVQUFVO2dCQUMxQyxDQUFDLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxNQUFNLEVBQUU7Z0JBQy9CLE1BQU0sQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxPQUFPLENBQUMsVUFBQSxHQUFHO29CQUN2QyxnQkFBZ0IsQ0FBQyxHQUFHLENBQUMsR0FBRyxHQUFHLElBQUksUUFBUSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUM7Z0JBQ2xELENBQUMsQ0FBQyxDQUFDO2FBQ0o7WUFFRCw2REFBNkQ7WUFDN0QsSUFBSSxDQUFDLGNBQWMsR0FBRyxnQkFBZ0IsQ0FBQztRQUN6QyxDQUFDO1FBRUQsVUFBVTtZQUFWLGlCQXFCQztZQXBCQyxJQUFJLFlBQVksR0FBRyxJQUFJLENBQUMsbUJBQW1CO2lCQUN0QyxJQUFJLENBQUMsVUFBQyxDQUFDLElBQUssT0FBQSxLQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBekIsQ0FBeUIsQ0FBQyxDQUFDO1lBRTVDLElBQU0sdUJBQXVCLEdBQ3pCLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUM7WUFFakQsSUFBTSxVQUFVLEdBQ1osSUFBSSxDQUFDLG1CQUFtQixDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMseUJBQXlCLENBQUM7WUFDckUseUVBQXlFO1lBQ3pFLHdFQUF3RTtZQUN4RSxrQkFBa0I7WUFDbEIsWUFBWSxHQUFHLFlBQVksSUFBSSx1QkFBdUIsSUFBSSxDQUFDLFVBQVUsQ0FBQztZQUV0RSx5RUFBeUU7WUFDekUsNkJBQTZCO1lBQzdCLElBQU0sWUFBWSxHQUFHLEVBQUUsQ0FBQztZQUN4QixJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxVQUFDLENBQUM7Z0JBQ25CLFlBQVksQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUM7WUFDckMsQ0FBQyxDQUFDLENBQUM7WUFDSCxJQUFJLENBQUMsY0FBYyxHQUFHLFlBQVksQ0FBQztRQUNyQyxDQUFDO1FBRUQ7O1dBRUc7UUFDSCxvQkFBb0I7WUFDbEIsOENBQThDO1lBQzlDLElBQU0sT0FBTyxHQUFHLElBQUksR0FBRyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLFVBQUMsRUFBSTtvQkFBSCxVQUFFO2dCQUFNLE9BQUEsTUFBTSxDQUFDLEVBQUUsQ0FBQztZQUFWLENBQVUsQ0FBQyxDQUFDLENBQUM7WUFDOUQsSUFBTSxZQUFZLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDO1lBQzVELE1BQU0sQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsT0FBTyxDQUFDLFVBQUEsR0FBRztnQkFDbkMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDO29CQUFFLE9BQU8sWUFBWSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ2xELENBQUMsQ0FBQyxDQUFDO1lBQ0gsSUFBSSxDQUFDLGNBQWMsR0FBRyxZQUFZLENBQUM7UUFDckMsQ0FBQztLQUNGLENBQUMsQ0FBQztBQUVILENBQUMsRUFoTlMsbUJBQW1CLEtBQW5CLG1CQUFtQixRQWdONUIsQ0FBRSxnQ0FBZ0MiLCJzb3VyY2VzQ29udGVudCI6WyIvKiBDb3B5cmlnaHQgMjAxOCBUaGUgVGVuc29yRmxvdyBBdXRob3JzLiBBbGwgUmlnaHRzIFJlc2VydmVkLlxuXG5MaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UsIFZlcnNpb24gMi4wICh0aGUgJ0xpY2Vuc2UnKTtcbnlvdSBtYXkgbm90IHVzZSB0aGlzIGZpbGUgZXhjZXB0IGluIGNvbXBsaWFuY2Ugd2l0aCB0aGUgTGljZW5zZS5cbllvdSBtYXkgb2J0YWluIGEgY29weSBvZiB0aGUgTGljZW5zZSBhdFxuXG4gICAgaHR0cDovL3d3dy5hcGFjaGUub3JnL2xpY2Vuc2VzL0xJQ0VOU0UtMi4wXG5cblVubGVzcyByZXF1aXJlZCBieSBhcHBsaWNhYmxlIGxhdyBvciBhZ3JlZWQgdG8gaW4gd3JpdGluZywgc29mdHdhcmVcbmRpc3RyaWJ1dGVkIHVuZGVyIHRoZSBMaWNlbnNlIGlzIGRpc3RyaWJ1dGVkIG9uIGFuICdBUyBJUycgQkFTSVMsXG5XSVRIT1VUIFdBUlJBTlRJRVMgT1IgQ09ORElUSU9OUyBPRiBBTlkgS0lORCwgZWl0aGVyIGV4cHJlc3Mgb3IgaW1wbGllZC5cblNlZSB0aGUgTGljZW5zZSBmb3IgdGhlIHNwZWNpZmljIGxhbmd1YWdlIGdvdmVybmluZyBwZXJtaXNzaW9ucyBhbmRcbmxpbWl0YXRpb25zIHVuZGVyIHRoZSBMaWNlbnNlLlxuPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09Ki9cbm5hbWVzcGFjZSB0Zl9kYXNoYm9hcmRfY29tbW9uIHtcblxuZXhwb3J0IHR5cGUgRmlsdGVyYWJsZUNoZWNrYm94TGlzdEl0ZW0gPSB7XG4gIGlkOiBzdHJpbmd8bnVtYmVyLFxuICB0aXRsZTogc3RyaW5nLFxuICBzdWJ0aXRsZT86IHN0cmluZyxcbn1cblxuUG9seW1lcih7XG4gIGlzOiAndGYtZmlsdGVyYWJsZS1jaGVja2JveC1saXN0JyxcbiAgcHJvcGVydGllczoge1xuICAgIGxhYmVsOiB7dHlwZTogU3RyaW5nfSxcblxuICAgIHVzZUNoZWNrYm94Q29sb3JzOiB7XG4gICAgICB0eXBlOiBCb29sZWFuLFxuICAgICAgdmFsdWU6IHRydWUsXG4gICAgfSxcblxuICAgIGNvbG9yaW5nOiB7XG4gICAgICB0eXBlOiBPYmplY3QsXG4gICAgICB2YWx1ZToge1xuICAgICAgICBnZXRDb2xvcjogKGl0ZW06IEZpbHRlcmFibGVDaGVja2JveExpc3RJdGVtKTogc3RyaW5nID0+ICcnLFxuICAgICAgfSxcbiAgICB9LFxuXG4gICAgLy8gYGl0ZW1zYCBhcmUgQXJyYXkgb2Yge2lkOiBzdHJpbmcsIHRpdGxlOiBzdHJpbmcsIHN1YnRpdGxlOiA/c3RyaW5nfS5cbiAgICBpdGVtczoge1xuICAgICAgdHlwZTogQXJyYXksXG4gICAgICB2YWx1ZTogKCk6IEFycmF5PEZpbHRlcmFibGVDaGVja2JveExpc3RJdGVtPiA9PiBbXSxcbiAgICAgIG9ic2VydmVyOiAnX3BydW5lU2VsZWN0aW9uU3RhdGUnLFxuICAgIH0sXG5cbiAgICBfcmVnZXhTdHJpbmc6IHtcbiAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgIHZhbHVlOiAnJyxcbiAgICB9LFxuXG4gICAgX3JlZ2V4OiB7dHlwZTogT2JqZWN0LCBjb21wdXRlZDogJ19tYWtlUmVnZXgoX3JlZ2V4U3RyaW5nKSd9LFxuXG4gICAgX2l0ZW1zTWF0Y2hpbmdSZWdleDoge1xuICAgICAgdHlwZTogQXJyYXksXG4gICAgICBjb21wdXRlZDogJ2NvbXB1dGVJdGVtc01hdGNoaW5nUmVnZXgoaXRlbXMuKiwgX3JlZ2V4KSdcbiAgICB9LFxuXG4gICAgc2VsZWN0aW9uU3RhdGU6IHtcbiAgICAgIC8vIGlmIGFuIGl0ZW0gaXMgZXhwbGljaXRseSBlbmFibGVkLCBUcnVlLCBpZiBleHBsaWNpdGx5IGRpc2FibGVkLCBGYWxzZS5cbiAgICAgIC8vIGlmIHVuZGVmaW5lZCwgZGVmYXVsdCB2YWx1ZSAoZW5hYmxlIGZvciBmaXJzdCBrIGl0ZW1zLCBkaXNhYmxlIGFmdGVyKS5cbiAgICAgIHR5cGU6IE9iamVjdCxcbiAgICAgIHZhbHVlOiAoKSA9PiAoe30pLFxuICAgIH0sXG5cbiAgICBzZWxlY3RlZEl0ZW1zOiB7XG4gICAgICB0eXBlOiBBcnJheSxcbiAgICAgIG5vdGlmeTogdHJ1ZSxcbiAgICAgIGNvbXB1dGVkOlxuICAgICAgICAgICdfY29tcHV0ZVNlbGVjdGVkSXRlbXMoX2l0ZW1zTWF0Y2hpbmdSZWdleC4qLCBzZWxlY3Rpb25TdGF0ZS4qKScsXG4gICAgfSxcblxuICAgIG1heEl0ZW1zVG9FbmFibGVCeURlZmF1bHQ6IHtcbiAgICAgIC8vIFdoZW4gVEIgZmlyc3QgbG9hZHMsIGlmIGl0IGhhcyBrIG9yIGZld2VyIGl0ZW1zLCB0aGV5IGFyZSBhbGwgZW5hYmxlZFxuICAgICAgLy8gYnkgZGVmYXVsdC4gSWYgdGhlcmUgYXJlIG1vcmUsIHRoZW4gYWxsIGl0ZW1zIGFyZSBkaXNhYmxlZC5cbiAgICAgIHR5cGU6IE51bWJlcixcbiAgICAgIHZhbHVlOiA0MCxcbiAgICB9LFxuXG4gICAgYWxsVG9nZ2xlRGlzYWJsZWQ6IHtcbiAgICAgIHR5cGU6IEJvb2xlYW4sXG4gICAgICB2YWx1ZTogZmFsc2UsXG4gICAgfSxcbiAgfSxcblxuICBsaXN0ZW5lcnM6IHtcbiAgICAnZG9tLWNoYW5nZSc6ICdfc3luY2hyb25pemVDb2xvcnMnLFxuICB9LFxuXG4gIG9ic2VydmVyczogW1xuICAgICdfc3luY2hyb25pemVDb2xvcnModXNlQ2hlY2tib3hDb2xvcnMpJyxcbiAgICAnX3N5bmNocm9uaXplQ29sb3JzKGNvbG9yaW5nKScsXG4gIF0sXG5cbiAgZGV0YWNoZWQoKSB7XG4gICAgdGhpcy5jYW5jZWxEZWJvdW5jZXIoJ19zZXRSZWdleCcpO1xuICB9LFxuXG4gIC8vID09PT09PT09PT09PT09PT09PT09PT0gQ09NUFVURUQgPT09PT09PT09PT09PT09PT09PT09PVxuXG4gIF9tYWtlUmVnZXgocmVnZXhTdHJpbmcpIHtcbiAgICB0cnkge1xuICAgICAgcmV0dXJuIG5ldyBSZWdFeHAocmVnZXhTdHJpbmcpO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgfSxcblxuICBjb21wdXRlSXRlbXNNYXRjaGluZ1JlZ2V4KF9fLCBfX18pIHtcbiAgICBjb25zdCByZWdleCA9IHRoaXMuX3JlZ2V4O1xuICAgIHJldHVybiByZWdleCA/IHRoaXMuaXRlbXMuZmlsdGVyKG4gPT4gcmVnZXgudGVzdChuLnRpdGxlKSkgOiB0aGlzLml0ZW1zO1xuICB9LFxuXG4gIF9jb21wdXRlU2VsZWN0ZWRJdGVtcyhfXywgX19fKSB7XG4gICAgY29uc3Qgc2VsZWN0aW9uU3RhdGUgPSB0aGlzLnNlbGVjdGlvblN0YXRlO1xuICAgIGNvbnN0IG51bSA9IHRoaXMubWF4SXRlbXNUb0VuYWJsZUJ5RGVmYXVsdDtcbiAgICBjb25zdCBhbGxFbmFibGVkID0gdGhpcy5faXRlbXNNYXRjaGluZ1JlZ2V4Lmxlbmd0aCA8PSBudW07XG4gICAgcmV0dXJuIHRoaXMuX2l0ZW1zTWF0Y2hpbmdSZWdleFxuICAgICAgICAuZmlsdGVyKG4gPT4ge1xuICAgICAgICAgIHJldHVybiBzZWxlY3Rpb25TdGF0ZVtuLmlkXSA9PSBudWxsID9cbiAgICAgICAgICAgICAgYWxsRW5hYmxlZCA6IHNlbGVjdGlvblN0YXRlW24uaWRdO1xuICAgICAgICB9KTtcbiAgfSxcblxuICBfaXNDaGVja2VkKGl0ZW0sIF8pIHtcbiAgICByZXR1cm4gdGhpcy5zZWxlY3RlZEl0ZW1zLmluZGV4T2YoaXRlbSkgIT0gLTE7XG4gIH0sXG5cblxuICAvLyA9PT09PT09PT09PT09PT09PT0gRVZFTlQgTElTVEVORVJTID09PT09PT09PT09PT09PT09PT1cblxuICBfZGVib3VuY2VkUmVnZXhDaGFuZ2UoKSB7XG4gICAgY29uc3QgdmFsID0gdGhpcy4kLmlucHV0LnZhbHVlO1xuICAgIGlmICh2YWwgPT0gJycpIHtcbiAgICAgIC8vIElmIHRoZSB1c2VyIGNsZWFyZWQgdGhlIGZpZWxkLCB0aGV5IG1heSBiZSBkb25lIHR5cGluZywgc29cbiAgICAgIC8vIHVwZGF0ZSBtb3JlIHF1aWNrbHkuXG4gICAgICB3aW5kb3cucmVxdWVzdEFuaW1hdGlvbkZyYW1lKCgpID0+IHtcbiAgICAgICAgdGhpcy5fcmVnZXhTdHJpbmcgPSB2YWw7XG4gICAgICB9KTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5kZWJvdW5jZSgnX3NldFJlZ2V4JywgKCkgPT4ge1xuICAgICAgICB0aGlzLl9yZWdleFN0cmluZyA9IHZhbDtcbiAgICAgIH0sIDE1MCk7XG4gICAgfTtcbiAgfSxcblxuICBfc3luY2hyb25pemVDb2xvcnMoZSkge1xuICAgIGNvbnN0IGNoZWNrYm94ZXMgPSB0aGlzLnF1ZXJ5U2VsZWN0b3JBbGwoJ3BhcGVyLWNoZWNrYm94Jyk7XG5cbiAgICBjaGVja2JveGVzLmZvckVhY2goY2IgPT4ge1xuICAgICAgLy8gU2V0dGluZyB0aGUgbnVsbCB2YWx1ZSB3aWxsIGNsZWFyIHByZXZpb3VzbHkgc2V0IGNvbG9yLlxuICAgICAgY29uc3QgY29sb3IgPSB0aGlzLnVzZUNoZWNrYm94Q29sb3JzID9cbiAgICAgICAgICB0aGlzLmNvbG9yaW5nLmdldENvbG9yKGNiLm5hbWUpIDpcbiAgICAgICAgICBudWxsO1xuICAgICAgY2IuY3VzdG9tU3R5bGVbJy0tcGFwZXItY2hlY2tib3gtY2hlY2tlZC1jb2xvciddID0gY29sb3I7XG4gICAgICBjYi5jdXN0b21TdHlsZVsnLS1wYXBlci1jaGVja2JveC1jaGVja2VkLWluay1jb2xvciddID0gY29sb3I7XG4gICAgICBjYi5jdXN0b21TdHlsZVsnLS1wYXBlci1jaGVja2JveC11bmNoZWNrZWQtY29sb3InXSA9IGNvbG9yO1xuICAgICAgY2IuY3VzdG9tU3R5bGVbJy0tcGFwZXItY2hlY2tib3gtdW5jaGVja2VkLWluay1jb2xvciddID0gY29sb3I7XG4gICAgfSk7XG5cbiAgICAvLyBUaGUgdXBkYXRlU3R5bGVzIGNhbGwgZmFpbHMgc2lsZW50bHkgaWYgdGhlIGJyb3dzZXIgZG9lcyBub3QgaGF2ZSBmb2N1cyxcbiAgICAvLyBlLmcuLCBpZiBUZW5zb3JCb2FyZCB3YXMgb3BlbmVkIGludG8gYSBuZXcgdGFiIHRoYXQgaXMgbm90IHZpc2libGUuXG4gICAgLy8gU28gd2Ugd2FpdCBmb3IgcmVxdWVzdEFuaW1hdGlvbkZyYW1lLlxuICAgIHdpbmRvdy5yZXF1ZXN0QW5pbWF0aW9uRnJhbWUoKCkgPT4gdGhpcy51cGRhdGVTdHlsZXMoKSk7XG4gIH0sXG5cbiAgX2NoZWNrYm94VGFwcGVkKGUpIHtcbiAgICBjb25zdCBjaGVja2JveCA9IGUuY3VycmVudFRhcmdldDtcbiAgICBjb25zdCBuZXdTZWxlY3RlZE5hbWVzID0gT2JqZWN0LmFzc2lnbih7fSwgdGhpcy5zZWxlY3Rpb25TdGF0ZSwge1xuICAgICAgW2NoZWNrYm94Lm5hbWUuaWRdOiBjaGVja2JveC5jaGVja2VkLFxuICAgIH0pO1xuXG4gICAgLy8gSWYgdXNlciBwcmVzc2VzIGFsdCB3aGlsZSB0b2dnbGluZyBjaGVja2JveCwgaXQgZGVzZWxlY3RzIGFsbCBpdGVtcyBidXRcbiAgICAvLyB0aGUgY2xpY2tlZCBvbmUuXG4gICAgaWYgKGUuZGV0YWlsLnNvdXJjZUV2ZW50IGluc3RhbmNlb2YgTW91c2VFdmVudCAmJlxuICAgICAgICBlLmRldGFpbC5zb3VyY2VFdmVudC5hbHRLZXkpIHtcbiAgICAgIE9iamVjdC5rZXlzKG5ld1NlbGVjdGVkTmFtZXMpLmZvckVhY2goa2V5ID0+IHtcbiAgICAgICAgbmV3U2VsZWN0ZWROYW1lc1trZXldID0ga2V5ID09IGNoZWNrYm94Lm5hbWUuaWQ7XG4gICAgICB9KTtcbiAgICB9XG5cbiAgICAvLyBuLmIuIG5vdGlmeVBhdGggd29uJ3Qgd29yayBiZWNhdXNlIG5hbWVzIG1heSBoYXZlIHBlcmlvZHMuXG4gICAgdGhpcy5zZWxlY3Rpb25TdGF0ZSA9IG5ld1NlbGVjdGVkTmFtZXM7XG4gIH0sXG5cbiAgX3RvZ2dsZUFsbCgpIHtcbiAgICBsZXQgYW55VG9nZ2xlZE9uID0gdGhpcy5faXRlbXNNYXRjaGluZ1JlZ2V4XG4gICAgICAgIC5zb21lKChuKSA9PiB0aGlzLnNlbGVjdGlvblN0YXRlW24uaWRdKTtcblxuICAgIGNvbnN0IHNlbGVjdGlvblN0YXRlSXNEZWZhdWx0ID1cbiAgICAgICAgT2JqZWN0LmtleXModGhpcy5zZWxlY3Rpb25TdGF0ZSkubGVuZ3RoID09IDA7XG5cbiAgICBjb25zdCBkZWZhdWx0T2ZmID1cbiAgICAgICAgdGhpcy5faXRlbXNNYXRjaGluZ1JlZ2V4Lmxlbmd0aCA+IHRoaXMubWF4SXRlbXNUb0VuYWJsZUJ5RGVmYXVsdDtcbiAgICAvLyBXZSBoYXZlIG5hbWVzIHRvZ2dsZWQgZWl0aGVyIGlmIHNvbWUgd2VyZSBleHBsaWNpdGx5IHRvZ2dsZWQgb24sIG9yIGlmXG4gICAgLy8gd2UgYXJlIGluIHRoZSBkZWZhdWx0IHN0YXRlLCBhbmQgdGhlcmUgYXJlIGZldyBlbm91Z2ggdGhhdCB3ZSBkZWZhdWx0XG4gICAgLy8gdG8gdG9nZ2xpbmcgb24uXG4gICAgYW55VG9nZ2xlZE9uID0gYW55VG9nZ2xlZE9uIHx8IHNlbGVjdGlvblN0YXRlSXNEZWZhdWx0ICYmICFkZWZhdWx0T2ZmO1xuXG4gICAgLy8gSWYgYW55IGFyZSB0b2dnbGVkIG9uLCB3ZSB0dXJuIGV2ZXJ5dGhpbmcgb2ZmLiBPciwgaWYgbm9uZSBhcmUgdG9nZ2xlZFxuICAgIC8vIG9uLCB3ZSB0dXJuIGV2ZXJ5dGhpbmcgb24uXG4gICAgY29uc3QgbmV3U2VsZWN0aW9uID0ge307XG4gICAgdGhpcy5pdGVtcy5mb3JFYWNoKChuKSA9PiB7XG4gICAgICBuZXdTZWxlY3Rpb25bbi5pZF0gPSAhYW55VG9nZ2xlZE9uO1xuICAgIH0pO1xuICAgIHRoaXMuc2VsZWN0aW9uU3RhdGUgPSBuZXdTZWxlY3Rpb247XG4gIH0sXG5cbiAgLyoqXG4gICAqIFJlbW92ZSBzZWxlY3Rpb24gc3RhdGUgb2YgYW4gaXRlbSB0aGF0IG5vIGxvbmdlciBleGlzdHMgaW4gdGhlIGBpdGVtc2AuXG4gICAqL1xuICBfcHJ1bmVTZWxlY3Rpb25TdGF0ZSgpIHtcbiAgICAvLyBPYmplY3Qga2V5IHR1cm5zIG51bWJlcmVkIGtleXMgaW50byBzdHJpbmcuXG4gICAgY29uc3QgaXRlbUlkcyA9IG5ldyBTZXQodGhpcy5pdGVtcy5tYXAoKHtpZH0pID0+IFN0cmluZyhpZCkpKTtcbiAgICBjb25zdCBuZXdTZWxlY3Rpb24gPSBPYmplY3QuYXNzaWduKHt9LCB0aGlzLnNlbGVjdGlvblN0YXRlKTtcbiAgICBPYmplY3Qua2V5cyhuZXdTZWxlY3Rpb24pLmZvckVhY2goa2V5ID0+IHtcbiAgICAgIGlmICghaXRlbUlkcy5oYXMoa2V5KSkgZGVsZXRlIG5ld1NlbGVjdGlvbltrZXldO1xuICAgIH0pO1xuICAgIHRoaXMuc2VsZWN0aW9uU3RhdGUgPSBuZXdTZWxlY3Rpb247XG4gIH0sXG59KTtcblxufSAgLy8gbmFtZXNwYWNlIHRmX2Rhc2hib2FyZF9jb21tb25cbiJdfQ==