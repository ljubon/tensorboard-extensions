declare namespace tf_backend {
    /**
     * Manages many fetch requests. Launches up to nSimultaneousRequests
     * simultaneously, and maintains a LIFO queue of requests to process when
     * more urls are requested than can be handled at once. The queue can be
     * cleared.
     *
     * When a request is made, a Promise is returned which resolves with the
     * parsed JSON result from the request.
     */
    class RequestCancellationError extends Error {
        name: string;
    }
    class RequestNetworkError extends Error {
        name: string;
        req: XMLHttpRequest;
        url: string;
        constructor(req: XMLHttpRequest, url: any);
    }
    class RequestManager {
        private _queue;
        private _maxRetries;
        private _nActiveRequests;
        private _nSimultaneousRequests;
        constructor(nSimultaneousRequests?: number, maxRetries?: number);
        /**
         * Gives a promise that loads assets from given url (respects queuing). If
         * postData is provided, this request will use POST, not GET. This is an
         * object mapping POST keys to string values.
         */
        request(url: string, postData?: {
            [key: string]: string;
        }): Promise<any>;
        clearQueue(): void;
        activeRequests(): number;
        outstandingRequests(): number;
        private launchRequests;
        /**
         * Try to request a given URL using overwritable _promiseFromUrl method.
         * If the request fails for any reason, we will retry up to maxRetries
         * times. In practice, this will help us paper over transient network issues
         * like '502 Bad Gateway'.
         * By default, Chrome displays network errors in console, so
         * the user will be able to tell when the requests are failing. I think this
         * is a feature, if the request failures and retries are causing any
         * pain to users, they can see it and file issues.
         */
        private promiseWithRetries;
        protected _promiseFromUrl(url: string, postData?: {
            [key: string]: string;
        }): Promise<{}>;
    }
}
