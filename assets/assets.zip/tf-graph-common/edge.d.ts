declare module tf.graph.scene.edge {
    /** The minimum stroke width of an edge. */
    const MIN_EDGE_WIDTH = 0.75;
    /** The maximum stroke width of an edge. */
    const MAX_EDGE_WIDTH = 12;
    const EDGE_WIDTH_SIZE_BASED_SCALE: d3.ScalePower<number, number>;
    type EdgeData = {
        v: string;
        w: string;
        label: render.RenderMetaedgeInfo;
    };
    /**
     * Function run when an edge is selected.
     */
    interface EdgeSelectionCallback {
        (edgeData: scene.edge.EdgeData): void;
    }
    function getEdgeKey(edgeObj: EdgeData): string;
    /**
     * Select or Create a 'g.edges' group to a given sceneGroup
     * and builds a number of 'g.edge' groups inside the group.
     *
     * Structure Pattern:
     *
     * <g class='edges'>
     *   <g class='edge'>
     *     <path class='edgeline'/>
     *   </g>
     *   ...
     * </g>
     *
     *
     * @param sceneGroup container
     * @param graph
     * @param sceneElement <tf-graph-scene> polymer element.
     * @return selection of the created nodeGroups
     */
    function buildGroup(sceneGroup: any, graph: graphlib.Graph<render.RenderNodeInfo, render.RenderMetaedgeInfo>, sceneElement: any): any;
    /**
     * Returns the label for the given base edge.
     * The label is the shape of the underlying tensor.
     */
    function getLabelForBaseEdge(baseEdge: BaseEdge, renderInfo: render.RenderGraphInfo): string;
    /**
     * Creates the label for the given metaedge. If the metaedge consists
     * of only 1 tensor, and it's shape is known, the label will contain that
     * shape. Otherwise, the label will say the number of tensors in the metaedge.
     */
    function getLabelForEdge(metaedge: Metaedge, renderInfo: render.RenderGraphInfo): string;
    /**
     * For a given d3 selection and data object, create a path to represent the
     * edge described in d.label.
     *
     * If d.label is defined, it will be a RenderMetaedgeInfo instance. It
     * will sometimes be undefined, for example for some Annotation edges for which
     * there is no underlying Metaedge in the hierarchical graph.
     */
    function appendEdge(edgeGroup: any, d: EdgeData, sceneElement: {
        renderHierarchy: render.RenderGraphInfo;
        handleEdgeSelected: Function;
    }, edgeClass?: string): void;
    let interpolate: d3.Line<{
        x: number;
        y: number;
    }>;
}
