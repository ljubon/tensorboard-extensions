/* Copyright 2015 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the 'License');
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an 'AS IS' BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
var tf;
(function (tf) {
    var graph;
    (function (graph) {
        var scene;
        (function (scene) {
            var contextmenu;
            (function (contextmenu) {
                /**
                 * Returns the top and left distance of the scene element from the top left
                 * corner of the screen.
                 */
                function getOffset(sceneElement) {
                    var leftDistance = 0;
                    var topDistance = 0;
                    var currentElement = sceneElement;
                    while (currentElement &&
                        currentElement.offsetLeft >= 0 &&
                        currentElement.offsetTop >= 0) {
                        leftDistance += currentElement.offsetLeft - currentElement.scrollLeft;
                        topDistance += currentElement.offsetTop - currentElement.scrollTop;
                        currentElement = currentElement.offsetParent;
                    }
                    return {
                        left: leftDistance,
                        top: topDistance
                    };
                }
                /**
                 * Returns the event listener, which can be used as an argument for the d3
                 * selection.on function. Renders the context menu that is to be displayed
                 * in response to the event.
                 */
                function getMenu(sceneElement, menu) {
                    var menuSelection = d3.select('.context-menu');
                    // Close the menu when anything else is clicked.
                    d3.select('body').on('click.context', function () { menuSelection.style('display', 'none'); });
                    // Function called to populate the context menu.
                    return function (data, index) {
                        var _this = this;
                        // Position and display the menu.
                        var event = d3.event;
                        var sceneOffset = getOffset(sceneElement);
                        menuSelection
                            .style('display', 'block')
                            .style('left', (event.clientX - sceneOffset.left + 1) + 'px')
                            .style('top', (event.clientY - sceneOffset.top + 1) + 'px');
                        // Stop the event from propagating further.
                        event.preventDefault();
                        event.stopPropagation();
                        // Add provided items to the context menu.
                        menuSelection.html('');
                        var list = menuSelection.append('ul');
                        list.selectAll('li')
                            .data(menu)
                            .enter()
                            .append('li')
                            .html(function (d) { return d.title(data); })
                            .on('click', function (d, i) {
                            d.action(_this, data, index);
                            menuSelection.style('display', 'none');
                        });
                    };
                }
                contextmenu.getMenu = getMenu;
                ;
            })(contextmenu = scene.contextmenu || (scene.contextmenu = {}));
        })(scene = graph.scene || (graph.scene = {}));
    })(graph = tf.graph || (tf.graph = {}));
})(tf || (tf = {})); // close module
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29udGV4dG1lbnUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJjb250ZXh0bWVudS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7Ozs7Ozs7OztnRkFhZ0Y7QUFFaEYsSUFBTyxFQUFFLENBaUZSO0FBakZELFdBQU8sRUFBRTtJQUFDLElBQUEsS0FBSyxDQWlGZDtJQWpGUyxXQUFBLEtBQUs7UUFBQyxJQUFBLEtBQUssQ0FpRnBCO1FBakZlLFdBQUEsS0FBSztZQUFDLElBQUEsV0FBVyxDQWlGaEM7WUFqRnFCLFdBQUEsV0FBVztnQkFvQmpDOzs7bUJBR0c7Z0JBQ0gsbUJBQW1CLFlBQVk7b0JBQzNCLElBQUksWUFBWSxHQUFHLENBQUMsQ0FBQztvQkFDckIsSUFBSSxXQUFXLEdBQUcsQ0FBQyxDQUFDO29CQUNwQixJQUFJLGNBQWMsR0FBRyxZQUFZLENBQUM7b0JBQ2xDLE9BQU8sY0FBYzt3QkFDZCxjQUFjLENBQUMsVUFBVSxJQUFJLENBQUM7d0JBQzlCLGNBQWMsQ0FBQyxTQUFTLElBQUksQ0FBQyxFQUFFO3dCQUNsQyxZQUFZLElBQUksY0FBYyxDQUFDLFVBQVUsR0FBRyxjQUFjLENBQUMsVUFBVSxDQUFDO3dCQUN0RSxXQUFXLElBQUksY0FBYyxDQUFDLFNBQVMsR0FBRyxjQUFjLENBQUMsU0FBUyxDQUFDO3dCQUNuRSxjQUFjLEdBQUcsY0FBYyxDQUFDLFlBQVksQ0FBQztxQkFDaEQ7b0JBQ0QsT0FBTzt3QkFDSCxJQUFJLEVBQUUsWUFBWTt3QkFDbEIsR0FBRyxFQUFFLFdBQVc7cUJBQ25CLENBQUM7Z0JBQ04sQ0FBQztnQkFFRDs7OzttQkFJRztnQkFDSCxpQkFBd0IsWUFBWSxFQUFFLElBQXVCO29CQUMzRCxJQUFJLGFBQWEsR0FBRyxFQUFFLENBQUMsTUFBTSxDQUFDLGVBQWUsQ0FBQyxDQUFDO29CQUMvQyxnREFBZ0Q7b0JBQ2hELEVBQUUsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUNoQixlQUFlLEVBQUUsY0FBYSxhQUFhLENBQUMsS0FBSyxDQUFDLFNBQVMsRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUU3RSxnREFBZ0Q7b0JBQ2hELE9BQU8sVUFBUyxJQUFJLEVBQUUsS0FBYTt3QkFBNUIsaUJBeUJOO3dCQXhCQyxpQ0FBaUM7d0JBQ2pDLElBQUksS0FBSyxHQUFlLEVBQUUsQ0FBQyxLQUFLLENBQUM7d0JBQ2pDLElBQU0sV0FBVyxHQUFHLFNBQVMsQ0FBQyxZQUFZLENBQUMsQ0FBQzt3QkFDNUMsYUFBYTs2QkFDVixLQUFLLENBQUMsU0FBUyxFQUFFLE9BQU8sQ0FBQzs2QkFDekIsS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsV0FBVyxDQUFDLElBQUksR0FBRyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUM7NkJBQzVELEtBQUssQ0FBQyxLQUFLLEVBQUUsQ0FBQyxLQUFLLENBQUMsT0FBTyxHQUFHLFdBQVcsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUM7d0JBRTlELDJDQUEyQzt3QkFDM0MsS0FBSyxDQUFDLGNBQWMsRUFBRSxDQUFDO3dCQUN2QixLQUFLLENBQUMsZUFBZSxFQUFFLENBQUM7d0JBRXhCLDBDQUEwQzt3QkFDMUMsYUFBYSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQzt3QkFDdkIsSUFBSSxJQUFJLEdBQUcsYUFBYSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQzt3QkFDdEMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUM7NkJBQ2YsSUFBSSxDQUFDLElBQUksQ0FBQzs2QkFDVixLQUFLLEVBQUU7NkJBQ1AsTUFBTSxDQUFDLElBQUksQ0FBQzs2QkFDWixJQUFJLENBQUMsVUFBUyxDQUFDLElBQUksT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDOzZCQUMzQyxFQUFFLENBQUMsT0FBTyxFQUFFLFVBQUMsQ0FBQyxFQUFFLENBQUM7NEJBQ2hCLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSSxFQUFFLElBQUksRUFBRSxLQUFLLENBQUMsQ0FBQzs0QkFDNUIsYUFBYSxDQUFDLEtBQUssQ0FBQyxTQUFTLEVBQUUsTUFBTSxDQUFDLENBQUM7d0JBQ3pDLENBQUMsQ0FBQyxDQUFDO29CQUNULENBQUMsQ0FBQztnQkFDSixDQUFDO2dCQWpDZSxtQkFBTyxVQWlDdEIsQ0FBQTtnQkFBQSxDQUFDO1lBRUYsQ0FBQyxFQWpGcUIsV0FBVyxHQUFYLGlCQUFXLEtBQVgsaUJBQVcsUUFpRmhDO1FBQUQsQ0FBQyxFQWpGZSxLQUFLLEdBQUwsV0FBSyxLQUFMLFdBQUssUUFpRnBCO0lBQUQsQ0FBQyxFQWpGUyxLQUFLLEdBQUwsUUFBSyxLQUFMLFFBQUssUUFpRmQ7QUFBRCxDQUFDLEVBakZNLEVBQUUsS0FBRixFQUFFLFFBaUZSLENBQUMsZUFBZSIsInNvdXJjZXNDb250ZW50IjpbIi8qIENvcHlyaWdodCAyMDE1IFRoZSBUZW5zb3JGbG93IEF1dGhvcnMuIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG5cbkxpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSAnTGljZW5zZScpO1xueW91IG1heSBub3QgdXNlIHRoaXMgZmlsZSBleGNlcHQgaW4gY29tcGxpYW5jZSB3aXRoIHRoZSBMaWNlbnNlLlxuWW91IG1heSBvYnRhaW4gYSBjb3B5IG9mIHRoZSBMaWNlbnNlIGF0XG5cbiAgICBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcblxuVW5sZXNzIHJlcXVpcmVkIGJ5IGFwcGxpY2FibGUgbGF3IG9yIGFncmVlZCB0byBpbiB3cml0aW5nLCBzb2Z0d2FyZVxuZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIExpY2Vuc2UgaXMgZGlzdHJpYnV0ZWQgb24gYW4gJ0FTIElTJyBCQVNJUyxcbldJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWSBLSU5ELCBlaXRoZXIgZXhwcmVzcyBvciBpbXBsaWVkLlxuU2VlIHRoZSBMaWNlbnNlIGZvciB0aGUgc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nIHBlcm1pc3Npb25zIGFuZFxubGltaXRhdGlvbnMgdW5kZXIgdGhlIExpY2Vuc2UuXG49PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0qL1xuXG5tb2R1bGUgdGYuZ3JhcGguc2NlbmUuY29udGV4dG1lbnUge1xuXG4vKiogRnVuY3Rpb24gdGhhdCBjb252ZXJ0cyBkYXRhIHRvIGEgdGl0bGUgc3RyaW5nLiAqL1xuZXhwb3J0IGludGVyZmFjZSBUaXRsZUZ1bmN0aW9uIHtcbiAgKGRhdGE6IGFueSk6IHN0cmluZztcbn1cblxuLyoqIEZ1bmN0aW9uIHRoYXQgdGFrZXMgYWN0aW9uIGJhc2VkIG9uIGl0ZW0gY2xpY2tlZCBpbiB0aGUgY29udGV4dCBtZW51LiAqL1xuZXhwb3J0IGludGVyZmFjZSBBY3Rpb25GdW5jdGlvbiB7XG4gIChlbGVtOiBhbnksIGQ6IGFueSwgaTogbnVtYmVyKTogdm9pZDtcbn1cblxuLyoqXG4gKiBUaGUgaW50ZXJmYWNlIGZvciBhbiBpdGVtIGluIHRoZSBjb250ZXh0IG1lbnVcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBDb250ZXh0TWVudUl0ZW0ge1xuICB0aXRsZTogVGl0bGVGdW5jdGlvbjtcbiAgYWN0aW9uOiBBY3Rpb25GdW5jdGlvbjtcbn1cblxuLyoqXG4gKiBSZXR1cm5zIHRoZSB0b3AgYW5kIGxlZnQgZGlzdGFuY2Ugb2YgdGhlIHNjZW5lIGVsZW1lbnQgZnJvbSB0aGUgdG9wIGxlZnRcbiAqIGNvcm5lciBvZiB0aGUgc2NyZWVuLlxuICovXG5mdW5jdGlvbiBnZXRPZmZzZXQoc2NlbmVFbGVtZW50KSB7XG4gICAgbGV0IGxlZnREaXN0YW5jZSA9IDA7XG4gICAgbGV0IHRvcERpc3RhbmNlID0gMDtcbiAgICBsZXQgY3VycmVudEVsZW1lbnQgPSBzY2VuZUVsZW1lbnQ7XG4gICAgd2hpbGUgKGN1cnJlbnRFbGVtZW50ICYmXG4gICAgICAgICAgIGN1cnJlbnRFbGVtZW50Lm9mZnNldExlZnQgPj0gMCAmJlxuICAgICAgICAgICBjdXJyZW50RWxlbWVudC5vZmZzZXRUb3AgPj0gMCkge1xuICAgICAgICBsZWZ0RGlzdGFuY2UgKz0gY3VycmVudEVsZW1lbnQub2Zmc2V0TGVmdCAtIGN1cnJlbnRFbGVtZW50LnNjcm9sbExlZnQ7XG4gICAgICAgIHRvcERpc3RhbmNlICs9IGN1cnJlbnRFbGVtZW50Lm9mZnNldFRvcCAtIGN1cnJlbnRFbGVtZW50LnNjcm9sbFRvcDtcbiAgICAgICAgY3VycmVudEVsZW1lbnQgPSBjdXJyZW50RWxlbWVudC5vZmZzZXRQYXJlbnQ7XG4gICAgfVxuICAgIHJldHVybiB7XG4gICAgICAgIGxlZnQ6IGxlZnREaXN0YW5jZSxcbiAgICAgICAgdG9wOiB0b3BEaXN0YW5jZVxuICAgIH07XG59XG5cbi8qKlxuICogUmV0dXJucyB0aGUgZXZlbnQgbGlzdGVuZXIsIHdoaWNoIGNhbiBiZSB1c2VkIGFzIGFuIGFyZ3VtZW50IGZvciB0aGUgZDNcbiAqIHNlbGVjdGlvbi5vbiBmdW5jdGlvbi4gUmVuZGVycyB0aGUgY29udGV4dCBtZW51IHRoYXQgaXMgdG8gYmUgZGlzcGxheWVkXG4gKiBpbiByZXNwb25zZSB0byB0aGUgZXZlbnQuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZXRNZW51KHNjZW5lRWxlbWVudCwgbWVudTogQ29udGV4dE1lbnVJdGVtW10pIHtcbiAgbGV0IG1lbnVTZWxlY3Rpb24gPSBkMy5zZWxlY3QoJy5jb250ZXh0LW1lbnUnKTtcbiAgLy8gQ2xvc2UgdGhlIG1lbnUgd2hlbiBhbnl0aGluZyBlbHNlIGlzIGNsaWNrZWQuXG4gIGQzLnNlbGVjdCgnYm9keScpLm9uKFxuICAgICAgJ2NsaWNrLmNvbnRleHQnLCBmdW5jdGlvbigpIHsgbWVudVNlbGVjdGlvbi5zdHlsZSgnZGlzcGxheScsICdub25lJyk7IH0pO1xuXG4gIC8vIEZ1bmN0aW9uIGNhbGxlZCB0byBwb3B1bGF0ZSB0aGUgY29udGV4dCBtZW51LlxuICByZXR1cm4gZnVuY3Rpb24oZGF0YSwgaW5kZXg6IG51bWJlcik6IHZvaWQge1xuICAgIC8vIFBvc2l0aW9uIGFuZCBkaXNwbGF5IHRoZSBtZW51LlxuICAgIGxldCBldmVudCA9IDxNb3VzZUV2ZW50PmQzLmV2ZW50O1xuICAgIGNvbnN0IHNjZW5lT2Zmc2V0ID0gZ2V0T2Zmc2V0KHNjZW5lRWxlbWVudCk7XG4gICAgbWVudVNlbGVjdGlvblxuICAgICAgLnN0eWxlKCdkaXNwbGF5JywgJ2Jsb2NrJylcbiAgICAgIC5zdHlsZSgnbGVmdCcsIChldmVudC5jbGllbnRYIC0gc2NlbmVPZmZzZXQubGVmdCArIDEpICsgJ3B4JylcbiAgICAgIC5zdHlsZSgndG9wJywgKGV2ZW50LmNsaWVudFkgLSBzY2VuZU9mZnNldC50b3AgKyAxKSArICdweCcpO1xuXG4gICAgLy8gU3RvcCB0aGUgZXZlbnQgZnJvbSBwcm9wYWdhdGluZyBmdXJ0aGVyLlxuICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG4gICAgZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCk7XG5cbiAgICAvLyBBZGQgcHJvdmlkZWQgaXRlbXMgdG8gdGhlIGNvbnRleHQgbWVudS5cbiAgICBtZW51U2VsZWN0aW9uLmh0bWwoJycpO1xuICAgIGxldCBsaXN0ID0gbWVudVNlbGVjdGlvbi5hcHBlbmQoJ3VsJyk7XG4gICAgbGlzdC5zZWxlY3RBbGwoJ2xpJylcbiAgICAgICAgLmRhdGEobWVudSlcbiAgICAgICAgLmVudGVyKClcbiAgICAgICAgLmFwcGVuZCgnbGknKVxuICAgICAgICAuaHRtbChmdW5jdGlvbihkKSB7IHJldHVybiBkLnRpdGxlKGRhdGEpOyB9KVxuICAgICAgICAub24oJ2NsaWNrJywgKGQsIGkpID0+IHtcbiAgICAgICAgICBkLmFjdGlvbih0aGlzLCBkYXRhLCBpbmRleCk7XG4gICAgICAgICAgbWVudVNlbGVjdGlvbi5zdHlsZSgnZGlzcGxheScsICdub25lJyk7XG4gICAgICAgIH0pO1xuICB9O1xufTtcblxufSAvLyBjbG9zZSBtb2R1bGVcbiJdfQ==