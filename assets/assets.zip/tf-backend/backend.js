/* Copyright 2015 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
var tf_backend;
(function (tf_backend) {
    tf_backend.TYPES = [];
    /** Given a RunToTag, return sorted array of all runs */
    function getRunsNamed(r) {
        return _.keys(r).sort(vz_sorting.compareTagNames);
    }
    tf_backend.getRunsNamed = getRunsNamed;
    /** Given a RunToTag, return array of all tags (sorted + dedup'd) */
    function getTags(r) {
        return _.union.apply(null, _.values(r)).sort(vz_sorting.compareTagNames);
    }
    tf_backend.getTags = getTags;
    /**
     * Given a RunToTag and an array of runs, return every tag that appears for
     * at least one run.
     * Sorted, deduplicated.
     */
    function filterTags(r, runs) {
        var result = [];
        runs.forEach(function (x) { return result = result.concat(r[x]); });
        return _.uniq(result).sort(vz_sorting.compareTagNames);
    }
    tf_backend.filterTags = filterTags;
    function timeToDate(x) {
        return new Date(x * 1000);
    }
    ;
    /**  Just a curryable map to make things cute and tidy. */
    function map(f) {
        return function (arr) {
            return arr.map(f);
        };
    }
    ;
    /**
     * This is a higher order function that takes a function that transforms a
     * T into a G, and returns a function that takes TupleData<T>s and converts
     * them into the intersection of a G and a Datum.
     */
    function detupler(xform) {
        return function (x) {
            // Create a G, assert it has type <G & Datum>
            var obj = xform(x[2]);
            // ... patch in the properties of datum
            obj.wall_time = timeToDate(x[0]);
            obj.step = x[1];
            return obj;
        };
    }
    ;
})(tf_backend || (tf_backend = {})); // namespace tf_backend
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYmFja2VuZC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImJhY2tlbmQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7Ozs7Ozs7Z0ZBYWdGO0FBQ2hGLElBQVUsVUFBVSxDQWtGbkI7QUFsRkQsV0FBVSxVQUFVO0lBMEJQLGdCQUFLLEdBQUcsRUFBRSxDQUFDO0lBRXhCLHdEQUF3RDtJQUN4RCxzQkFBNkIsQ0FBVztRQUN0QyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxlQUFlLENBQUMsQ0FBQztJQUNwRCxDQUFDO0lBRmUsdUJBQVksZUFFM0IsQ0FBQTtJQUVELG9FQUFvRTtJQUNwRSxpQkFBd0IsQ0FBVztRQUNqQyxPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxlQUFlLENBQUMsQ0FBQztJQUMzRSxDQUFDO0lBRmUsa0JBQU8sVUFFdEIsQ0FBQTtJQUVEOzs7O09BSUc7SUFDSCxvQkFBMkIsQ0FBVyxFQUFFLElBQWM7UUFDcEQsSUFBSSxNQUFNLEdBQUcsRUFBRSxDQUFDO1FBQ2hCLElBQUksQ0FBQyxPQUFPLENBQUMsVUFBQyxDQUFDLElBQUssT0FBQSxNQUFNLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBNUIsQ0FBNEIsQ0FBQyxDQUFDO1FBQ2xELE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGVBQWUsQ0FBQyxDQUFDO0lBQ3pELENBQUM7SUFKZSxxQkFBVSxhQUl6QixDQUFBO0lBRUQsb0JBQW9CLENBQVM7UUFDM0IsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUM7SUFDNUIsQ0FBQztJQUFBLENBQUM7SUFFRiwwREFBMEQ7SUFDMUQsYUFBbUIsQ0FBYztRQUMvQixPQUFPLFVBQVMsR0FBUTtZQUN0QixPQUFPLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDcEIsQ0FBQyxDQUFDO0lBQ0osQ0FBQztJQUFBLENBQUM7SUFFRjs7OztPQUlHO0lBQ0gsa0JBQXdCLEtBQWtCO1FBQ3hDLE9BQU8sVUFBUyxDQUFlO1lBQzdCLDZDQUE2QztZQUM3QyxJQUFJLEdBQUcsR0FBWSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDL0IsdUNBQXVDO1lBQ3ZDLEdBQUcsQ0FBQyxTQUFTLEdBQUcsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ2pDLEdBQUcsQ0FBQyxJQUFJLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ2hCLE9BQU8sR0FBRyxDQUFDO1FBQ2IsQ0FBQyxDQUFDO0lBQ0osQ0FBQztJQUFBLENBQUM7QUFRRixDQUFDLEVBbEZTLFVBQVUsS0FBVixVQUFVLFFBa0ZuQixDQUFFLHVCQUF1QiIsInNvdXJjZXNDb250ZW50IjpbIi8qIENvcHlyaWdodCAyMDE1IFRoZSBUZW5zb3JGbG93IEF1dGhvcnMuIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG5cbkxpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSBcIkxpY2Vuc2VcIik7XG55b3UgbWF5IG5vdCB1c2UgdGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlIHdpdGggdGhlIExpY2Vuc2UuXG5Zb3UgbWF5IG9idGFpbiBhIGNvcHkgb2YgdGhlIExpY2Vuc2UgYXRcblxuICAgIGh0dHA6Ly93d3cuYXBhY2hlLm9yZy9saWNlbnNlcy9MSUNFTlNFLTIuMFxuXG5Vbmxlc3MgcmVxdWlyZWQgYnkgYXBwbGljYWJsZSBsYXcgb3IgYWdyZWVkIHRvIGluIHdyaXRpbmcsIHNvZnR3YXJlXG5kaXN0cmlidXRlZCB1bmRlciB0aGUgTGljZW5zZSBpcyBkaXN0cmlidXRlZCBvbiBhbiBcIkFTIElTXCIgQkFTSVMsXG5XSVRIT1VUIFdBUlJBTlRJRVMgT1IgQ09ORElUSU9OUyBPRiBBTlkgS0lORCwgZWl0aGVyIGV4cHJlc3Mgb3IgaW1wbGllZC5cblNlZSB0aGUgTGljZW5zZSBmb3IgdGhlIHNwZWNpZmljIGxhbmd1YWdlIGdvdmVybmluZyBwZXJtaXNzaW9ucyBhbmRcbmxpbWl0YXRpb25zIHVuZGVyIHRoZSBMaWNlbnNlLlxuPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09Ki9cbm5hbWVzcGFjZSB0Zl9iYWNrZW5kIHtcblxuZXhwb3J0IHR5cGUgUnVuVG9UYWcgPSB7XG4gIFtydW46IHN0cmluZ106IHN0cmluZ1tdO1xufTtcblxuZXhwb3J0IGludGVyZmFjZSBEYXR1bSB7XG4gIHdhbGxfdGltZTogRGF0ZTtcbiAgc3RlcDogbnVtYmVyO1xufVxuXG4vLyBBbiBvYmplY3QgdGhhdCBlbmNhcHN1bGF0ZXMgYW4gYWxlcnQgaXNzdWVkIGJ5IHRoZSBkZWJ1Z2dlci4gVGhpcyBhbGVydCBpc1xuLy8gc2VudCBieSBkZWJ1Z2dpbmcgbGlicmFyaWVzIGFmdGVyIGJhZCB2YWx1ZXMgKE5hTiwgKy8tIEluZikgYXJlIGVuY291bnRlcmVkLlxuZXhwb3J0IGludGVyZmFjZSBEZWJ1Z2dlck51bWVyaWNzQWxlcnRSZXBvcnQge1xuICBkZXZpY2VfbmFtZTogc3RyaW5nO1xuICB0ZW5zb3JfbmFtZTogc3RyaW5nO1xuICBmaXJzdF90aW1lc3RhbXA6IG51bWJlcjtcbiAgbmFuX2V2ZW50X2NvdW50OiBudW1iZXI7XG4gIG5lZ19pbmZfZXZlbnRfY291bnQ6IG51bWJlcjtcbiAgcG9zX2luZl9ldmVudF9jb3VudDogbnVtYmVyO1xufVxuLy8gQSBEZWJ1Z2dlck51bWVyaWNzQWxlcnRSZXBvcnRSZXNwb25zZSBjb250YWlucyBhbGVydHMgaXNzdWVkIGJ5IHRoZSBkZWJ1Z2dlclxuLy8gaW4gYXNjZW5kaW5nIG9yZGVyIG9mIHRpbWVzdGFtcC4gVGhpcyBoZWxwcyB0aGUgdXNlciBpZGVudGlmeSBmb3IgaW5zdGFuY2Vcbi8vIHdoZW4gYmFkIHZhbHVlcyBmaXJzdCBhcHBlYXJlZCBpbiB0aGUgbW9kZWwuXG5leHBvcnQgdHlwZSBEZWJ1Z2dlck51bWVyaWNzQWxlcnRSZXBvcnRSZXNwb25zZSA9IERlYnVnZ2VyTnVtZXJpY3NBbGVydFJlcG9ydFtdO1xuXG5leHBvcnQgY29uc3QgVFlQRVMgPSBbXTtcblxuLyoqIEdpdmVuIGEgUnVuVG9UYWcsIHJldHVybiBzb3J0ZWQgYXJyYXkgb2YgYWxsIHJ1bnMgKi9cbmV4cG9ydCBmdW5jdGlvbiBnZXRSdW5zTmFtZWQocjogUnVuVG9UYWcpOiBzdHJpbmdbXSB7XG4gIHJldHVybiBfLmtleXMocikuc29ydCh2el9zb3J0aW5nLmNvbXBhcmVUYWdOYW1lcyk7XG59XG5cbi8qKiBHaXZlbiBhIFJ1blRvVGFnLCByZXR1cm4gYXJyYXkgb2YgYWxsIHRhZ3MgKHNvcnRlZCArIGRlZHVwJ2QpICovXG5leHBvcnQgZnVuY3Rpb24gZ2V0VGFncyhyOiBSdW5Ub1RhZyk6IHN0cmluZ1tdIHtcbiAgcmV0dXJuIF8udW5pb24uYXBwbHkobnVsbCwgXy52YWx1ZXMocikpLnNvcnQodnpfc29ydGluZy5jb21wYXJlVGFnTmFtZXMpO1xufVxuXG4vKipcbiAqIEdpdmVuIGEgUnVuVG9UYWcgYW5kIGFuIGFycmF5IG9mIHJ1bnMsIHJldHVybiBldmVyeSB0YWcgdGhhdCBhcHBlYXJzIGZvclxuICogYXQgbGVhc3Qgb25lIHJ1bi5cbiAqIFNvcnRlZCwgZGVkdXBsaWNhdGVkLlxuICovXG5leHBvcnQgZnVuY3Rpb24gZmlsdGVyVGFncyhyOiBSdW5Ub1RhZywgcnVuczogc3RyaW5nW10pOiBzdHJpbmdbXSB7XG4gIGxldCByZXN1bHQgPSBbXTtcbiAgcnVucy5mb3JFYWNoKCh4KSA9PiByZXN1bHQgPSByZXN1bHQuY29uY2F0KHJbeF0pKTtcbiAgcmV0dXJuIF8udW5pcShyZXN1bHQpLnNvcnQodnpfc29ydGluZy5jb21wYXJlVGFnTmFtZXMpO1xufVxuXG5mdW5jdGlvbiB0aW1lVG9EYXRlKHg6IG51bWJlcik6IERhdGUge1xuICByZXR1cm4gbmV3IERhdGUoeCAqIDEwMDApO1xufTtcblxuLyoqICBKdXN0IGEgY3VycnlhYmxlIG1hcCB0byBtYWtlIHRoaW5ncyBjdXRlIGFuZCB0aWR5LiAqL1xuZnVuY3Rpb24gbWFwPFQsIFU+KGY6ICh4OiBUKSA9PiBVKTogKGFycjogVFtdKSA9PiBVW10ge1xuICByZXR1cm4gZnVuY3Rpb24oYXJyOiBUW10pOiBVW10ge1xuICAgIHJldHVybiBhcnIubWFwKGYpO1xuICB9O1xufTtcblxuLyoqXG4gKiBUaGlzIGlzIGEgaGlnaGVyIG9yZGVyIGZ1bmN0aW9uIHRoYXQgdGFrZXMgYSBmdW5jdGlvbiB0aGF0IHRyYW5zZm9ybXMgYVxuICogVCBpbnRvIGEgRywgYW5kIHJldHVybnMgYSBmdW5jdGlvbiB0aGF0IHRha2VzIFR1cGxlRGF0YTxUPnMgYW5kIGNvbnZlcnRzXG4gKiB0aGVtIGludG8gdGhlIGludGVyc2VjdGlvbiBvZiBhIEcgYW5kIGEgRGF0dW0uXG4gKi9cbmZ1bmN0aW9uIGRldHVwbGVyPFQsIEc+KHhmb3JtOiAoeDogVCkgPT4gRyk6ICh0OiBUdXBsZURhdGE8VD4pID0+IERhdHVtICYgRyB7XG4gIHJldHVybiBmdW5jdGlvbih4OiBUdXBsZURhdGE8VD4pOiBEYXR1bSAmIEcge1xuICAgIC8vIENyZWF0ZSBhIEcsIGFzc2VydCBpdCBoYXMgdHlwZSA8RyAmIERhdHVtPlxuICAgIGxldCBvYmogPSA8RyZEYXR1bT54Zm9ybSh4WzJdKTtcbiAgICAvLyAuLi4gcGF0Y2ggaW4gdGhlIHByb3BlcnRpZXMgb2YgZGF0dW1cbiAgICBvYmoud2FsbF90aW1lID0gdGltZVRvRGF0ZSh4WzBdKTtcbiAgICBvYmouc3RlcCA9IHhbMV07XG4gICAgcmV0dXJuIG9iajtcbiAgfTtcbn07XG5cbi8qKlxuICogVGhlIGZvbGxvd2luZyBpbnRlcmZhY2UgKFR1cGxlRGF0YSkgZGVzY3JpYmVzIGhvdyB0aGUgZGF0YSBpcyBzZW50XG4gKiBvdmVyIGZyb20gdGhlIGJhY2tlbmQuXG4gKi9cbnR5cGUgVHVwbGVEYXRhPFQ+ID0gW251bWJlciwgbnVtYmVyLCBUXTsgIC8vIHdhbGxfdGltZSwgc3RlcFxuXG59ICAvLyBuYW1lc3BhY2UgdGZfYmFja2VuZFxuIl19