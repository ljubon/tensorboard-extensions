declare namespace gr_paramplot_dashboard {
    class DataSeries {
        private name;
        private scalarData;
        constructor(name: string, scalarData: vz_chart_helpers.ScalarDatum[]);
        getName(): string;
        setData(scalarData: vz_chart_helpers.ScalarDatum[]): void;
        getData(): vz_chart_helpers.ScalarDatum[];
    }
}
