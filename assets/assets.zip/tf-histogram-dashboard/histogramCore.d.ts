declare namespace tf_histogram_dashboard {
    /**
     * Functions for converting between the different representations of
     * histograms.
     */
    type BackendHistogramBin = [number, // left
    number, // right
    number];
    type BackendHistogram = [number, // wall_time, in seconds
    number, // step
    BackendHistogramBin[]];
    type IntermediateHistogram = {
        wall_time: number;
        step: number;
        min: number;
        max: number;
        buckets: {
            left: number;
            right: number;
            count: number;
        }[];
    };
    type D3HistogramBin = {
        x: number;
        dx: number;
        y: number;
    };
    type VzHistogram = {
        wall_time: number;
        step: number;
        bins: D3HistogramBin[];
    };
    function backendToIntermediate(histogram: BackendHistogram): IntermediateHistogram;
    /**
     * Convert histogram data to the standard D3 format to make it more
     * compatible and easier to visualize. When rendering histograms, having
     * access to the left edge and width of each bin makes things quite a
     * bit easier, so we include these in the result. We also convert the
     * bins to have a uniform width, which makes the visualization easier to
     * understand.
     *
     * @param histogram
     * @param min The leftmost edge. The binning will start on it.
     * @param max The rightmost edge. The binning will end on it.
     * @param numBins The number of bins of the converted data. The default
     * of 30 is sensible: if you use more, you start to get artifacts
     * because the event data is stored in buckets, and you start being able
     * to see the aliased borders between each bucket.
     *
     * @return A list of histogram bins. Each bin has an `x` (left
     *     edge), a `dx` (width), and a `y` (count). If the given
     *     right edges are inclusive, then these left edges (`x`) are
     *     exclusive.
     */
    function intermediateToD3(histogram: IntermediateHistogram, min: number, max: number, numBins?: number): D3HistogramBin[];
    function backendToVz(histograms: BackendHistogram[]): VzHistogram[];
}
