/* Copyright 2016 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
var tf_color_scale;
(function (tf_color_scale) {
    tf_color_scale.palettes = {
        googleStandard: [
            '#db4437',
            '#ff7043',
            '#f4b400',
            '#0f9d58',
            '#00796b',
            '#00acc1',
            '#4285f4',
            '#5c6bc0',
            '#ab47bc' // purple 400
        ],
        googleCool: [
            '#9e9d24',
            '#0f9d58',
            '#00796b',
            '#00acc1',
            '#4285f4',
            '#5c6bc0',
            '#607d8b' // blue gray 500
        ],
        googleWarm: [
            '#795548',
            '#ab47bc',
            '#f06292',
            '#c2185b',
            '#db4437',
            '#ff7043',
            '#f4b400' // google yellow 700
        ],
        googleColorBlindAssist: [
            '#ff7043',
            '#00ACC1',
            '#AB47BC',
            '#2A56C6',
            '#0b8043',
            '#F7CB4D',
            '#c0ca33',
            '#5e35b1',
            '#A52714',
        ],
        // A colorblind-friendly palette designed for TensorBoard by Paul Tol
        // (https://personal.sron.nl/~pault/).
        tensorboardColorBlindAssist: [
            '#ff7043',
            '#0077bb',
            '#cc3311',
            '#33bbee',
            '#ee3377',
            '#009988',
            '#bbbbbb',
        ],
        // These palettes try to be better for color differentiation.
        // https://personal.sron.nl/~pault/
        colorBlindAssist1: ['#4477aa', '#44aaaa', '#aaaa44', '#aa7744', '#aa4455', '#aa4488'],
        colorBlindAssist2: [
            '#88ccee', '#44aa99', '#117733', '#999933', '#ddcc77', '#cc6677', '#882255',
            '#aa4499'
        ],
        colorBlindAssist3: [
            '#332288', '#6699cc', '#88ccee', '#44aa99', '#117733', '#999933', '#ddcc77',
            '#cc6677', '#aa4466', '#882255', '#661100', '#aa4499'
        ],
        colorBlindAssist4: [
            // Paul Tol's "Alternative Scheme for Qualitative Data". Preferred
            // if `tensorboardColorBlindAssist` cannot be used for any reason.
            '#4477aa',
            '#66ccee',
            '#228833',
            '#ccbb44',
            '#ee6677',
            '#aa3377',
            '#bbbbbb',
        ],
        // based on this palette: http://mkweb.bcgsc.ca/biovis2012/
        colorBlindAssist5: [
            '#FF6DB6', '#920000', '#924900', '#DBD100', '#24FF24', '#006DDB', '#490092'
        ],
        mldash: [
            '#E47EAD', '#F4640D', '#FAA300', '#F5E636', '#00A077', '#0077B8', '#00B7ED'
        ]
    };
    tf_color_scale.standard = tf_color_scale.palettes.tensorboardColorBlindAssist;
})(tf_color_scale || (tf_color_scale = {})); // namespace tf_color_scale
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGFsZXR0ZXMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJwYWxldHRlcy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7Ozs7Ozs7OztnRkFhZ0Y7QUFDaEYsSUFBVSxjQUFjLENBd0Z2QjtBQXhGRCxXQUFVLGNBQWM7SUFFWCx1QkFBUSxHQUFHO1FBQ3RCLGNBQWMsRUFBRTtZQUNkLFNBQVM7WUFDVCxTQUFTO1lBQ1QsU0FBUztZQUNULFNBQVM7WUFDVCxTQUFTO1lBQ1QsU0FBUztZQUNULFNBQVM7WUFDVCxTQUFTO1lBQ1QsU0FBUyxDQUFHLGFBQWE7U0FDMUI7UUFDRCxVQUFVLEVBQUU7WUFDVixTQUFTO1lBQ1QsU0FBUztZQUNULFNBQVM7WUFDVCxTQUFTO1lBQ1QsU0FBUztZQUNULFNBQVM7WUFDVCxTQUFTLENBQUcsZ0JBQWdCO1NBQzdCO1FBQ0QsVUFBVSxFQUFFO1lBQ1YsU0FBUztZQUNULFNBQVM7WUFDVCxTQUFTO1lBQ1QsU0FBUztZQUNULFNBQVM7WUFDVCxTQUFTO1lBQ1QsU0FBUyxDQUFHLG9CQUFvQjtTQUNqQztRQUNELHNCQUFzQixFQUFFO1lBQ3RCLFNBQVM7WUFDVCxTQUFTO1lBQ1QsU0FBUztZQUNULFNBQVM7WUFDVCxTQUFTO1lBQ1QsU0FBUztZQUNULFNBQVM7WUFDVCxTQUFTO1lBQ1QsU0FBUztTQUNWO1FBQ0QscUVBQXFFO1FBQ3JFLHNDQUFzQztRQUN0QywyQkFBMkIsRUFBRTtZQUMzQixTQUFTO1lBQ1QsU0FBUztZQUNULFNBQVM7WUFDVCxTQUFTO1lBQ1QsU0FBUztZQUNULFNBQVM7WUFDVCxTQUFTO1NBQ1Y7UUFDRCw2REFBNkQ7UUFDN0QsbUNBQW1DO1FBQ25DLGlCQUFpQixFQUNiLENBQUMsU0FBUyxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBRSxTQUFTLENBQUM7UUFDdEUsaUJBQWlCLEVBQUU7WUFDakIsU0FBUyxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUUsU0FBUztZQUMzRSxTQUFTO1NBQ1Y7UUFDRCxpQkFBaUIsRUFBRTtZQUNqQixTQUFTLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBRSxTQUFTO1lBQzNFLFNBQVMsRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBRSxTQUFTO1NBQ3REO1FBQ0QsaUJBQWlCLEVBQUU7WUFDakIsa0VBQWtFO1lBQ2xFLGtFQUFrRTtZQUNsRSxTQUFTO1lBQ1QsU0FBUztZQUNULFNBQVM7WUFDVCxTQUFTO1lBQ1QsU0FBUztZQUNULFNBQVM7WUFDVCxTQUFTO1NBQ1Y7UUFDRCwyREFBMkQ7UUFDM0QsaUJBQWlCLEVBQUU7WUFDakIsU0FBUyxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUUsU0FBUztTQUM1RTtRQUNELE1BQU0sRUFBRTtZQUNOLFNBQVMsRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFFLFNBQVM7U0FDNUU7S0FDRixDQUFDO0lBRVcsdUJBQVEsR0FBRyxlQUFBLFFBQVEsQ0FBQywyQkFBMkIsQ0FBQztBQUU3RCxDQUFDLEVBeEZTLGNBQWMsS0FBZCxjQUFjLFFBd0Z2QixDQUFFLDJCQUEyQiIsInNvdXJjZXNDb250ZW50IjpbIi8qIENvcHlyaWdodCAyMDE2IFRoZSBUZW5zb3JGbG93IEF1dGhvcnMuIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG5cbkxpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSBcIkxpY2Vuc2VcIik7XG55b3UgbWF5IG5vdCB1c2UgdGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlIHdpdGggdGhlIExpY2Vuc2UuXG5Zb3UgbWF5IG9idGFpbiBhIGNvcHkgb2YgdGhlIExpY2Vuc2UgYXRcblxuICAgIGh0dHA6Ly93d3cuYXBhY2hlLm9yZy9saWNlbnNlcy9MSUNFTlNFLTIuMFxuXG5Vbmxlc3MgcmVxdWlyZWQgYnkgYXBwbGljYWJsZSBsYXcgb3IgYWdyZWVkIHRvIGluIHdyaXRpbmcsIHNvZnR3YXJlXG5kaXN0cmlidXRlZCB1bmRlciB0aGUgTGljZW5zZSBpcyBkaXN0cmlidXRlZCBvbiBhbiBcIkFTIElTXCIgQkFTSVMsXG5XSVRIT1VUIFdBUlJBTlRJRVMgT1IgQ09ORElUSU9OUyBPRiBBTlkgS0lORCwgZWl0aGVyIGV4cHJlc3Mgb3IgaW1wbGllZC5cblNlZSB0aGUgTGljZW5zZSBmb3IgdGhlIHNwZWNpZmljIGxhbmd1YWdlIGdvdmVybmluZyBwZXJtaXNzaW9ucyBhbmRcbmxpbWl0YXRpb25zIHVuZGVyIHRoZSBMaWNlbnNlLlxuPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09Ki9cbm5hbWVzcGFjZSB0Zl9jb2xvcl9zY2FsZSB7XG5cbmV4cG9ydCBjb25zdCBwYWxldHRlcyA9IHtcbiAgZ29vZ2xlU3RhbmRhcmQ6IFtcbiAgICAnI2RiNDQzNycsICAvLyBnb29nbGUgcmVkIDUwMFxuICAgICcjZmY3MDQzJywgIC8vIGRlZXAgb3JhbmdlIDQwMFxuICAgICcjZjRiNDAwJywgIC8vIGdvb2dsZSB5ZWxsb3cgNTAwXG4gICAgJyMwZjlkNTgnLCAgLy8gZ29vZ2xlIGdyZWVuIDUwMFxuICAgICcjMDA3OTZiJywgIC8vIHRlYWwgNzAwXG4gICAgJyMwMGFjYzEnLCAgLy8gY3lhbiA2MDBcbiAgICAnIzQyODVmNCcsICAvLyBnb29nbGUgYmx1ZSA1MDBcbiAgICAnIzVjNmJjMCcsICAvLyBpbmRpZ28gNDAwXG4gICAgJyNhYjQ3YmMnICAgLy8gcHVycGxlIDQwMFxuICBdLFxuICBnb29nbGVDb29sOiBbXG4gICAgJyM5ZTlkMjQnLCAgLy8gbGltZSA4MDBcbiAgICAnIzBmOWQ1OCcsICAvLyBnb29nbGUgZ3JlZW4gNTAwXG4gICAgJyMwMDc5NmInLCAgLy8gdGVhbCA3MDBcbiAgICAnIzAwYWNjMScsICAvLyBjeWFuIDYwMFxuICAgICcjNDI4NWY0JywgIC8vIGdvb2dsZSBibHVlIDUwMFxuICAgICcjNWM2YmMwJywgIC8vIGluZGlnbyA0MDBcbiAgICAnIzYwN2Q4YicgICAvLyBibHVlIGdyYXkgNTAwXG4gIF0sXG4gIGdvb2dsZVdhcm06IFtcbiAgICAnIzc5NTU0OCcsICAvLyBicm93biA1MDBcbiAgICAnI2FiNDdiYycsICAvLyBwdXJwbGUgNDAwXG4gICAgJyNmMDYyOTInLCAgLy8gcGluayAzMDBcbiAgICAnI2MyMTg1YicsICAvLyBwaW5rIDcwMFxuICAgICcjZGI0NDM3JywgIC8vIGdvb2dsZSByZWQgNTAwXG4gICAgJyNmZjcwNDMnLCAgLy8gZGVlcCBvcmFuZ2UgNDAwXG4gICAgJyNmNGI0MDAnICAgLy8gZ29vZ2xlIHllbGxvdyA3MDBcbiAgXSxcbiAgZ29vZ2xlQ29sb3JCbGluZEFzc2lzdDogW1xuICAgICcjZmY3MDQzJywgIC8vIG9yYW5nZVxuICAgICcjMDBBQ0MxJywgIC8vIGRhcmsgY3lhblxuICAgICcjQUI0N0JDJywgIC8vIGJyaWdodCBwdXJwbGVcbiAgICAnIzJBNTZDNicsICAvLyBkYXJrIGJsdWVcbiAgICAnIzBiODA0MycsICAvLyBncmVlblxuICAgICcjRjdDQjREJywgIC8vIHllbGxvd1xuICAgICcjYzBjYTMzJywgIC8vIGxpbWVcbiAgICAnIzVlMzViMScsICAvLyBwdXJwbGVcbiAgICAnI0E1MjcxNCcsICAvLyByZWRcbiAgXSxcbiAgLy8gQSBjb2xvcmJsaW5kLWZyaWVuZGx5IHBhbGV0dGUgZGVzaWduZWQgZm9yIFRlbnNvckJvYXJkIGJ5IFBhdWwgVG9sXG4gIC8vIChodHRwczovL3BlcnNvbmFsLnNyb24ubmwvfnBhdWx0LykuXG4gIHRlbnNvcmJvYXJkQ29sb3JCbGluZEFzc2lzdDogW1xuICAgICcjZmY3MDQzJywgIC8vIG9yYW5nZVxuICAgICcjMDA3N2JiJywgIC8vIGJsdWUgICAgXG4gICAgJyNjYzMzMTEnLCAgLy8gcmVkXG4gICAgJyMzM2JiZWUnLCAgLy8gY3lhbiAgICBcbiAgICAnI2VlMzM3NycsICAvLyBtYWdlbnRhXG4gICAgJyMwMDk5ODgnLCAgLy8gdGVhbFxuICAgICcjYmJiYmJiJywgIC8vIGdyZXlcbiAgXSxcbiAgLy8gVGhlc2UgcGFsZXR0ZXMgdHJ5IHRvIGJlIGJldHRlciBmb3IgY29sb3IgZGlmZmVyZW50aWF0aW9uLlxuICAvLyBodHRwczovL3BlcnNvbmFsLnNyb24ubmwvfnBhdWx0L1xuICBjb2xvckJsaW5kQXNzaXN0MTpcbiAgICAgIFsnIzQ0NzdhYScsICcjNDRhYWFhJywgJyNhYWFhNDQnLCAnI2FhNzc0NCcsICcjYWE0NDU1JywgJyNhYTQ0ODgnXSxcbiAgY29sb3JCbGluZEFzc2lzdDI6IFtcbiAgICAnIzg4Y2NlZScsICcjNDRhYTk5JywgJyMxMTc3MzMnLCAnIzk5OTkzMycsICcjZGRjYzc3JywgJyNjYzY2NzcnLCAnIzg4MjI1NScsXG4gICAgJyNhYTQ0OTknXG4gIF0sXG4gIGNvbG9yQmxpbmRBc3Npc3QzOiBbXG4gICAgJyMzMzIyODgnLCAnIzY2OTljYycsICcjODhjY2VlJywgJyM0NGFhOTknLCAnIzExNzczMycsICcjOTk5OTMzJywgJyNkZGNjNzcnLFxuICAgICcjY2M2Njc3JywgJyNhYTQ0NjYnLCAnIzg4MjI1NScsICcjNjYxMTAwJywgJyNhYTQ0OTknXG4gIF0sXG4gIGNvbG9yQmxpbmRBc3Npc3Q0OiBbXG4gICAgLy8gUGF1bCBUb2wncyBcIkFsdGVybmF0aXZlIFNjaGVtZSBmb3IgUXVhbGl0YXRpdmUgRGF0YVwiLiBQcmVmZXJyZWRcbiAgICAvLyBpZiBgdGVuc29yYm9hcmRDb2xvckJsaW5kQXNzaXN0YCBjYW5ub3QgYmUgdXNlZCBmb3IgYW55IHJlYXNvbi5cbiAgICAnIzQ0NzdhYScsXG4gICAgJyM2NmNjZWUnLFxuICAgICcjMjI4ODMzJyxcbiAgICAnI2NjYmI0NCcsXG4gICAgJyNlZTY2NzcnLFxuICAgICcjYWEzMzc3JyxcbiAgICAnI2JiYmJiYicsXG4gIF0sXG4gIC8vIGJhc2VkIG9uIHRoaXMgcGFsZXR0ZTogaHR0cDovL21rd2ViLmJjZ3NjLmNhL2Jpb3ZpczIwMTIvXG4gIGNvbG9yQmxpbmRBc3Npc3Q1OiBbXG4gICAgJyNGRjZEQjYnLCAnIzkyMDAwMCcsICcjOTI0OTAwJywgJyNEQkQxMDAnLCAnIzI0RkYyNCcsICcjMDA2RERCJywgJyM0OTAwOTInXG4gIF0sXG4gIG1sZGFzaDogW1xuICAgICcjRTQ3RUFEJywgJyNGNDY0MEQnLCAnI0ZBQTMwMCcsICcjRjVFNjM2JywgJyMwMEEwNzcnLCAnIzAwNzdCOCcsICcjMDBCN0VEJ1xuICBdXG59O1xuXG5leHBvcnQgY29uc3Qgc3RhbmRhcmQgPSBwYWxldHRlcy50ZW5zb3Jib2FyZENvbG9yQmxpbmRBc3Npc3Q7XG5cbn0gIC8vIG5hbWVzcGFjZSB0Zl9jb2xvcl9zY2FsZVxuIl19