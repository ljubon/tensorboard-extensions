declare namespace tf_storage {
    class ListenKey {
        readonly listener: Function;
        constructor(listener: Function);
    }
    function addHashListener(fn: Function): ListenKey;
    function addStorageListener(fn: Function): ListenKey;
    function fireStorageChanged(): void;
    function removeHashListenerByKey(key: ListenKey): void;
    function removeStorageListenerByKey(key: ListenKey): void;
}
